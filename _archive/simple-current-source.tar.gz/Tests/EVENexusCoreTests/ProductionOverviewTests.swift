import Foundation
import Testing

@testable import EVENexusCore

@Suite("Production overview")
struct ProductionOverviewTests {
  @Test
  func allocatesSharedRecursiveCostsOnceAcrossFinishedProducts() throws {
    let firstID = UUID()
    let secondID = UUID()
    let source = SourceIdentity(provider: "fixture", version: "1")
    func quote(typeID: Int64, quantity: Int64, total: Double) -> PriceQuote {
      PriceQuote(
        id: UUID(),
        typeID: typeID,
        quantity: quantity,
        scenario: .materialBuy,
        total: total,
        weightedUnitPrice: total / Double(quantity),
        filledQuantity: quantity,
        capturedAt: Date(timeIntervalSince1970: 100),
        source: source,
        warnings: []
      )
    }
    let firstQuote = quote(typeID: 34, quantity: 10, total: 100)
    let secondQuote = quote(typeID: 35, quantity: 30, total: 300)
    let requests = [
      ProductionRequestLine(
        id: firstID,
        lineNumber: 1,
        productName: "First Product",
        wantedQuantity: 1,
        materialEfficiency: 0,
        timeEfficiency: 0
      ),
      ProductionRequestLine(
        id: secondID,
        lineNumber: 2,
        productName: "Second Product",
        wantedQuantity: 1,
        materialEfficiency: 0,
        timeEfficiency: 0
      ),
    ]
    let plan = IndustryPlanSnapshot(
      id: UUID(),
      createdAt: Date(timeIntervalSince1970: 100),
      requests: requests,
      nodes: [
        PlanNode(
          id: UUID(), typeID: 100, name: "First Product",
          requiredQuantity: 1, action: .produce, activity: .manufacturing,
          runs: 1, materialEfficiency: 0, timeEfficiency: 0, children: [],
          topLevelRequestID: firstID
        ),
        PlanNode(
          id: UUID(), typeID: 34, name: "First Material",
          requiredQuantity: 10, action: .buy, activity: nil, runs: nil,
          materialEfficiency: nil, timeEfficiency: nil, children: [],
          topLevelRequestID: firstID
        ),
        PlanNode(
          id: UUID(), typeID: 200, name: "Second Product",
          requiredQuantity: 1, action: .produce, activity: .manufacturing,
          runs: 1, materialEfficiency: 0, timeEfficiency: 0, children: [],
          topLevelRequestID: secondID
        ),
        PlanNode(
          id: UUID(), typeID: 35, name: "Second Material",
          requiredQuantity: 30, action: .buy, activity: nil, runs: nil,
          materialEfficiency: nil, timeEfficiency: nil, children: [],
          topLevelRequestID: secondID
        ),
      ],
      materials: [
        MaterialRequirement(
          typeID: 34, name: "First Material", required: 10, fromStock: 0,
          toBuy: 10, toProduce: 0, quote: firstQuote,
          replacementQuote: firstQuote
        ),
        MaterialRequirement(
          typeID: 35, name: "Second Material", required: 30, fromStock: 0,
          toBuy: 30, toProduce: 0, quote: secondQuote,
          replacementQuote: secondQuote
        ),
      ],
      stockAllocations: [],
      jobs: [],
      materialCost: 400,
      installationCost: 80,
      costBreakdown: IndustryCostBreakdown(
        materialCost: 400,
        purchasedMaterialCost: 400,
        stockMaterialCost: 0,
        blueprintCosts: BlueprintCostBreakdown(
          entries: [], requestsWithoutEnteredCost: [], total: 40
        ),
        systemIndexCost: 80,
        facilityTax: 0,
        sccSurcharge: 0,
        alphaSurcharge: 0,
        installationCost: 80,
        logistics: nil,
        logisticsCost: 20,
        totalProductionCost: 540
      ),
      immediateSale: Self.emptySale(.immediateSale),
      listedSale: Self.emptySale(.listedSale),
      mainContractSale: nil,
      homeImmediateSale: nil,
      homeListedSale: nil,
      homeContractSale: nil,
      coalitionImmediateSale: nil,
      coalitionListedSale: nil,
      coalitionContractSale: nil,
      totalJobSeconds: 1,
      makespanSeconds: 1,
      warnings: [],
      explanations: [],
      provenance: PlanProvenance(
        sdeBuild: 1,
        esiCompatibilityDate: "fixture",
        snapshotIDs: [],
        priceTimestamp: Date(timeIntervalSince1970: 100),
        ruleVersion: "fixture"
      )
    )

    let first = try #require(
      ProductionOverviewProjector.projection(for: firstID, in: plan)
    )
    let second = try #require(
      ProductionOverviewProjector.projection(for: secondID, in: plan)
    )
    #expect(first.materialCost == 100)
    #expect(second.materialCost == 300)
    #expect(first.installationCost == 20)
    #expect(second.installationCost == 60)
    #expect(first.blueprintCost == 10)
    #expect(second.blueprintCost == 30)
    #expect(first.logisticsCost == 5)
    #expect(second.logisticsCost == 15)

    var legacyObject = try #require(
      JSONSerialization.jsonObject(
        with: JSONEncoder().encode(plan)
      ) as? [String: Any]
    )
    for key in [
      "mainContractSale",
      "homeContractSale",
      "coalitionImmediateSale",
      "coalitionListedSale",
      "coalitionContractSale",
    ] {
      legacyObject.removeValue(forKey: key)
    }
    let legacyData = try JSONSerialization.data(withJSONObject: legacyObject)
    let restored = try JSONDecoder().decode(
      IndustryPlanSnapshot.self,
      from: legacyData
    )
    #expect(restored.mainContractSale == nil)
    #expect(restored.homeContractSale == nil)
    #expect(restored.coalitionImmediateSale == nil)
    #expect(restored.coalitionListedSale == nil)
    #expect(restored.coalitionContractSale == nil)
  }

  @Test
  func projectionCarriesLogisticsAndSeparateFeeRatesFromThePlanSnapshot()
    throws
  {
    let requestID = UUID()
    let source = SourceIdentity(provider: "fixture", version: "1")
    let materialQuote = PriceQuote(
      id: UUID(),
      typeID: 34,
      quantity: 10,
      scenario: .materialBuy,
      total: 1_000,
      weightedUnitPrice: 100,
      filledQuantity: 10,
      capturedAt: Date(timeIntervalSince1970: 100),
      source: source,
      warnings: []
    )
    let listedQuote = PriceQuote(
      id: UUID(),
      typeID: 100,
      quantity: 1,
      scenario: .listedSale,
      total: 1_880,
      weightedUnitPrice: 1_880,
      filledQuantity: 1,
      capturedAt: Date(timeIntervalSince1970: 100),
      source: source,
      warnings: []
    )
    let homeListedQuote = PriceQuote(
      id: UUID(),
      typeID: 100,
      quantity: 1,
      scenario: .listedSale,
      total: 1_275,
      weightedUnitPrice: 1_275,
      filledQuantity: 1,
      capturedAt: Date(timeIntervalSince1970: 100),
      source: source,
      warnings: []
    )
    let request = ProductionRequestLine(
      id: requestID,
      lineNumber: 1,
      productName: "Fixture Ship",
      wantedQuantity: 1,
      materialEfficiency: 4,
      timeEfficiency: 2,
      blueprintKind: .bpc,
      blueprintCostISK: 50
    )
    let plan = IndustryPlanSnapshot(
      id: UUID(),
      createdAt: Date(timeIntervalSince1970: 100),
      requests: [request],
      nodes: [
        PlanNode(
          id: UUID(),
          typeID: 100,
          name: "Fixture Ship",
          requiredQuantity: 1,
          action: .produce,
          activity: .manufacturing,
          runs: 1,
          materialEfficiency: 4,
          timeEfficiency: 2,
          children: [],
          topLevelRequestID: requestID
        ),
        PlanNode(
          id: UUID(),
          typeID: 34,
          name: "Fixture Mineral",
          requiredQuantity: 10,
          action: .buy,
          activity: nil,
          runs: nil,
          materialEfficiency: nil,
          timeEfficiency: nil,
          children: [],
          topLevelRequestID: requestID
        ),
      ],
      materials: [
        MaterialRequirement(
          typeID: 34,
          name: "Fixture Mineral",
          required: 10,
          fromStock: 0,
          toBuy: 10,
          toProduce: 0,
          quote: materialQuote,
          replacementQuote: materialQuote
        )
      ],
      stockAllocations: [],
      jobs: [],
      materialCost: 1_000,
      installationCost: 200,
      costBreakdown: IndustryCostBreakdown(
        materialCost: 1_000,
        purchasedMaterialCost: 1_000,
        stockMaterialCost: 0,
        blueprintCosts: BlueprintCostBreakdown(
          entries: [
            BlueprintCostEntry(
              requestID: requestID,
              productName: "Fixture Ship",
              kind: .bpc,
              amount: 50,
              treatment: ManualBlueprintKind.bpc.costTreatment
            )
          ],
          requestsWithoutEnteredCost: [],
          total: 50
        ),
        systemIndexCost: 200,
        facilityTax: 0,
        sccSurcharge: 0,
        alphaSurcharge: 0,
        installationCost: 200,
        logistics: nil,
        logisticsCost: 300,
        totalProductionCost: 1_550
      ),
      immediateSale: SaleScenarioResult(
        scenario: .immediateSale,
        grossRevenue: 2_000,
        salesTax: 100,
        brokerFee: 0,
        outboundLogisticsCost: 400,
        totalCost: 1_950,
        grossOrNetRevenue: 1_900,
        profit: 350,
        margin: 350 / 1_900,
        roi: 350 / 1_550,
        quotes: []
      ),
      listedSale: SaleScenarioResult(
        scenario: .listedSale,
        grossRevenue: 2_000,
        salesTax: 100,
        brokerFee: 20,
        outboundLogisticsCost: 400,
        totalCost: 1_950,
        grossOrNetRevenue: 1_880,
        profit: 330,
        margin: 330 / 1_880,
        roi: 330 / 1_550,
        quotes: [listedQuote]
      ),
      mainContractSale: nil,
      homeImmediateSale: SaleScenarioResult(
        scenario: .immediateSale,
        grossRevenue: 1_400,
        salesTax: 140,
        brokerFee: 0,
        outboundLogisticsCost: 0,
        totalCost: 1_550,
        grossOrNetRevenue: 1_260,
        profit: -290,
        margin: -290 / 1_260,
        roi: -290 / 1_550,
        quotes: []
      ),
      homeListedSale: SaleScenarioResult(
        scenario: .listedSale,
        grossRevenue: 1_500,
        salesTax: 150,
        brokerFee: 75,
        outboundLogisticsCost: 0,
        totalCost: 1_550,
        grossOrNetRevenue: 1_275,
        profit: -275,
        margin: -275 / 1_275,
        roi: -275 / 1_550,
        quotes: [homeListedQuote]
      ),
      homeContractSale: nil,
      coalitionImmediateSale: nil,
      coalitionListedSale: nil,
      coalitionContractSale: nil,
      totalJobSeconds: 1,
      makespanSeconds: 1,
      warnings: [],
      explanations: [],
      provenance: PlanProvenance(
        sdeBuild: 1,
        esiCompatibilityDate: "fixture",
        snapshotIDs: [],
        priceTimestamp: Date(timeIntervalSince1970: 100),
        ruleVersion: "fixture"
      )
    )

    let projection = try #require(
      ProductionOverviewProjector.projection(
        for: requestID,
        in: plan
      )
    )

    #expect(projection.materialCost == 1_000)
    #expect(projection.installationCost == 200)
    #expect(projection.blueprintCost == 50)
    #expect(projection.logisticsCost == 300)
    #expect(projection.salesTaxRate == 0.05)
    #expect(projection.brokerFeeRate == 0.01)
    #expect(projection.suggestedSalePricePerUnit == 2_000)

    let homePlan = ProductionOverviewProjector.reconstructedPlan(
      plan,
      route: .mainToHome
    )
    let homeProjection = try #require(
      ProductionOverviewProjector.projection(for: requestID, in: homePlan)
    )
    #expect(homeProjection.logisticsCost == 300)
    #expect(homeProjection.salesTaxRate == 0.10)
    #expect(homeProjection.brokerFeeRate == 0.05)
    #expect(homeProjection.suggestedSalePricePerUnit == 1_500)
    #expect(homePlan.costBreakdown?.totalProductionCost == 1_550)

    let returnPlan = ProductionOverviewProjector.reconstructedPlan(
      plan,
      route: .mainToHomeToMain
    )
    let returnProjection = try #require(
      ProductionOverviewProjector.projection(for: requestID, in: returnPlan)
    )
    #expect(returnProjection.logisticsCost == 700)
    #expect(returnProjection.salesTaxRate == 0.05)
    #expect(returnProjection.brokerFeeRate == 0.01)
    #expect(returnPlan.costBreakdown?.totalProductionCost == 1_950)
  }

  @Test
  func separatesProductionCostFromSaleFeesAndIncludesLogistics() {
    let calculation = ProductionOverviewCalculation(
      units: 10,
      materialCost: 100,
      installationCost: 20,
      blueprintCost: 10,
      logisticsCost: 5,
      salesTaxRate: 0.05,
      brokerFeeRate: 0.01,
      salePricePerUnit: 20,
      soldUnits: 4
    )

    #expect(calculation.productionCost == 135)
    #expect(calculation.saleTotal == 200)
    #expect(calculation.salesTax == 10)
    #expect(calculation.brokerFee == 2)
    #expect(calculation.netSaleTotal == 188)
    #expect(calculation.costPerUnit == 13.5)
    #expect(
      abs((calculation.minimumSalePricePerUnit ?? 0) - 15.797_872_34)
        < 0.000_001
    )
    #expect(calculation.projectedProfit == 53)
    #expect(abs((calculation.margin ?? 0) - 53 / 188) < 0.000_001)
    #expect(calculation.realProfit == -61)
  }

  @Test
  func salePriceChangesRecalculateTaxAndBrokerFee() {
    let calculation = ProductionOverviewCalculation(
      units: 10,
      materialCost: 100,
      installationCost: 20,
      blueprintCost: 10,
      logisticsCost: 5,
      salesTaxRate: 0.05,
      brokerFeeRate: 0.01,
      salePricePerUnit: 30,
      soldUnits: 10
    )

    #expect(calculation.saleTotal == 300)
    #expect(calculation.salesTax == 15)
    #expect(calculation.brokerFee == 3)
    #expect(calculation.projectedProfit == 147)
    #expect(calculation.realProfit == 147)
  }

  @Test
  func knownSalesTaxRemainsVisibleWhenBrokerFeeIsUnavailable() {
    let calculation = ProductionOverviewCalculation(
      units: 10,
      materialCost: 100,
      installationCost: 20,
      blueprintCost: 10,
      logisticsCost: 5,
      salesTaxRate: 0.05,
      brokerFeeRate: nil,
      salePricePerUnit: 20,
      soldUnits: 4
    )

    #expect(calculation.productionCost == 135)
    #expect(calculation.costPerUnit == 13.5)
    #expect(calculation.saleTotal == 200)
    #expect(calculation.salesTax == 10)
    #expect(calculation.brokerFee == nil)
    #expect(calculation.netSaleTotal == nil)
    #expect(calculation.minimumSalePricePerUnit == nil)
    #expect(calculation.projectedProfit == nil)
    #expect(calculation.margin == nil)
    #expect(calculation.realProfit == nil)
  }

  @Test
  func capitalWithoutApplicableBrokerFeeStillCalculatesMinimumAndProfit() {
    let calculation = ProductionOverviewCalculation(
      units: 10,
      materialCost: 100,
      installationCost: 20,
      blueprintCost: 10,
      logisticsCost: 5,
      salesTaxRate: 0.05,
      brokerFeeRate: nil,
      brokerFeeIsApplicable: false,
      salePricePerUnit: 20,
      soldUnits: 4
    )

    #expect(calculation.productionCost == 135)
    #expect(calculation.salesTax == 10)
    #expect(calculation.brokerFee == nil)
    #expect(calculation.netSaleTotal == 190)
    #expect(
      abs((calculation.minimumSalePricePerUnit ?? 0) - 15.631_578_947)
        < 0.000_001
    )
    #expect(calculation.projectedProfit == 55)
    #expect(abs((calculation.margin ?? 0) - 55 / 190) < 0.000_001)
    #expect(calculation.realProfit == -59)
  }

  @Test
  func realProfitUsesSoldTaxAndFullListingBrokerFee() {
    func calculation(soldUnits: Int64) -> ProductionOverviewCalculation {
      ProductionOverviewCalculation(
        units: 10,
        materialCost: 100,
        installationCost: 20,
        blueprintCost: 10,
        logisticsCost: 5,
        salesTaxRate: 0.05,
        brokerFeeRate: 0.01,
        salePricePerUnit: 20,
        soldUnits: soldUnits
      )
    }

    #expect(calculation(soldUnits: 0).realProfit == -137)
    #expect(calculation(soldUnits: 4).realProfit == -61)
    #expect(calculation(soldUnits: 10).realProfit == 53)
  }

  @Test
  func keepsUnavailableProductionInputsUnavailableInsteadOfInventingZero() {
    let calculation = ProductionOverviewCalculation(
      units: 1,
      materialCost: 10,
      installationCost: 20,
      blueprintCost: 5,
      logisticsCost: nil,
      salesTaxRate: 0.05,
      brokerFeeRate: 0.01,
      salePricePerUnit: 30,
      soldUnits: 1
    )

    #expect(calculation.productionCost == nil)
    #expect(calculation.costPerUnit == nil)
    #expect(calculation.minimumSalePricePerUnit == nil)
    #expect(calculation.projectedProfit == nil)
    #expect(calculation.margin == nil)
    #expect(calculation.realProfit == nil)
  }

  @Test
  func rejectsNonFiniteNegativeAndImpossibleStoredValues() {
    let calculation = ProductionOverviewCalculation(
      units: 10,
      materialCost: .infinity,
      installationCost: 20,
      blueprintCost: -1,
      logisticsCost: 5,
      salesTaxRate: 0.05,
      brokerFeeRate: 0.01,
      salePricePerUnit: .nan,
      soldUnits: 11
    )

    #expect(calculation.productionCost == nil)
    #expect(calculation.saleTotal == nil)
    #expect(calculation.projectedProfit == nil)
    #expect(calculation.realProfit == nil)
  }

  private static func emptySale(
    _ scenario: PriceScenario
  ) -> SaleScenarioResult {
    SaleScenarioResult(
      scenario: scenario,
      grossOrNetRevenue: nil,
      profit: nil,
      margin: nil,
      roi: nil,
      quotes: []
    )
  }
}
