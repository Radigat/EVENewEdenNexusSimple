import NewEdenNexusApplication
import NewEdenNexusPersistence
import SwiftData
import SwiftUI

@MainActor
final class NexusAppRuntime: ObservableObject {
    enum StartupState {
        case loading
        case ready(ModelContainer)
        case failed(NexusFailure)
    }

    @Published private(set) var startupState: StartupState = .loading
    @Published private(set) var presentedFailure: NexusFailure?
    @Published private(set) var sdeManagement:
        SDEManagementViewModel?
    @Published private(set) var projectManagement:
        ProjectLifecycleViewModel?
    @Published private(set) var productionGraphManagement:
        ProductionGraphViewModel?
    @Published private(set) var buildOrBuyManagement:
        BuildOrBuyWorkspaceViewModel?
    @Published private(set) var dashboardManagement:
        DashboardViewModel?
    @Published private(set) var inventoryManagement:
        InventoryViewModel?
    @Published private(set) var inventoryAvailabilityManagement:
        InventoryAvailabilityViewModel?
    @Published private(set) var safetyStockManagement:
        SafetyStockViewModel?
    @Published private(set) var projectReservationManagement:
        ProjectReservationViewModel?
    @Published private(set) var reservationConflictManagement:
        ReservationConflictViewModel?
    @Published private(set) var priceProfileManagement:
        PriceProfileViewModel?
    @Published private(set) var purchasingManagement:
        PurchasingViewModel?
    @Published private(set) var productionLedgerManagement:
        ProductionLedgerViewModel?
    @Published private(set) var accountManagement:
        AccountsViewModel?
    @Published private(set) var recoveryPreview:
        LocalBackupRestorePreview?
    @Published private(set) var lastBackup:
        LocalBackupDescriptor?
    @Published private(set) var lastRestore:
        LocalBackupRestoreResult?
    @Published private(set) var isRecoveryOperationRunning = false

    private let logger: any DiagnosticLogging
    private var presentedFailureRetryAction: (@MainActor () -> Void)?
    private let containerFactory:
        (@MainActor () throws -> ModelContainer)?
    private let migrationAwareContainerFactory:
        (@MainActor () async throws -> (
            ModelContainer,
            LocalBackupDescriptor?
        ))?
    private let recoveryConfiguration: RecoveryConfiguration?
    private let sdeManagementFactory:
        @MainActor (
            ModelContainer,
            any DiagnosticLogging
        ) throws -> SDEManagementViewModel?

    init(
        logger: any DiagnosticLogging,
        containerFactory: @escaping @MainActor () throws -> ModelContainer
    ) {
        self.logger = logger
        self.containerFactory = containerFactory
        migrationAwareContainerFactory = nil
        recoveryConfiguration = nil
        sdeManagementFactory = { container, logger in
            guard !AppExecutionEnvironment.isRunningTests else {
                return nil
            }
            return try SDEAppComposition.makeViewModel(
                container: container,
                logger: logger
            )
        }
        openStore()
    }

    init(
        logger: any DiagnosticLogging,
        migrationAwareContainerFactory:
            @escaping @MainActor () async throws -> (
                ModelContainer,
                LocalBackupDescriptor?
            ),
        recoveryConfiguration: RecoveryConfiguration
    ) {
        self.logger = logger
        containerFactory = nil
        self.migrationAwareContainerFactory =
            migrationAwareContainerFactory
        self.recoveryConfiguration = recoveryConfiguration
        sdeManagementFactory = { container, logger in
            guard !AppExecutionEnvironment.isRunningTests else {
                return nil
            }
            return try SDEAppComposition.makeViewModel(
                container: container,
                logger: logger
            )
        }
        Task { await openStoreAsynchronously() }
    }

    func retryStartup() {
        if migrationAwareContainerFactory != nil {
            Task { await openStoreAsynchronously() }
        } else {
            openStore()
        }
    }

    var canRetryPresentedFailure: Bool {
        presentedFailureRetryAction != nil
    }

    func report(
        _ error: any Error,
        operation: NexusOperation,
        retry: (@MainActor () -> Void)? = nil
    ) {
        let failure = NexusFailureMapper.map(error, operation: operation)
        logger.log(failure.diagnosticEvent)
        if case .idempotentRead = operation.userRetryPolicy {
            presentedFailureRetryAction = retry
        } else {
            presentedFailureRetryAction = nil
        }
        presentedFailure = failure
    }

    func dismissPresentedFailure() {
        presentedFailureRetryAction = nil
        presentedFailure = nil
    }

    func retryPresentedFailure() {
        guard let retry = presentedFailureRetryAction else {
            return
        }
        presentedFailureRetryAction = nil
        presentedFailure = nil
        retry()
    }

    func startSDEAutomationIfNeeded() {
        sdeManagement?.startAutomationIfNeeded()
    }

    var isRecoveryAvailable: Bool {
        recoveryConfiguration != nil
    }

    func createManualBackup() async {
        guard let configuration = recoveryConfiguration else {
            return
        }
        isRecoveryOperationRunning = true
        defer { isRecoveryOperationRunning = false }
        do {
            lastBackup = try await configuration.backupService.createBackup(
                sourceStoreURL: configuration.storeURL,
                destinationDirectoryURL: configuration.backupDirectoryURL,
                kind: .manual
            )
        } catch {
            report(error, operation: .backupCreate)
        }
    }

    func inspectBackupForRestore(_ packageURL: URL) async {
        guard let configuration = recoveryConfiguration else {
            return
        }
        isRecoveryOperationRunning = true
        defer { isRecoveryOperationRunning = false }
        do {
            recoveryPreview =
                try await configuration.backupService.previewRestore(
                    packageURL: packageURL,
                    targetStoreURL: configuration.storeURL
                )
        } catch {
            recoveryPreview = nil
            report(error, operation: .backupInspect)
        }
    }

    func discardRecoveryPreview() {
        recoveryPreview = nil
    }

    func restoreInspectedBackup() async {
        guard let configuration = recoveryConfiguration,
              let preview = recoveryPreview else {
            return
        }
        isRecoveryOperationRunning = true
        sdeManagement?.cancelCurrentOperation()
        releaseStoreBoundState()
        startupState = .loading

        // Give SwiftUI one main-actor turn to remove views and their
        // ModelContext references before the target store is replaced.
        await Task.yield()

        do {
            let result = try await configuration.backupService.restore(
                preview: preview,
                confirmation: .confirmed,
                targetStoreState: .closed,
                safetyBackupDirectoryURL:
                    configuration.backupDirectoryURL
            )
            recoveryPreview = nil
            lastRestore = result
            await openStoreAsynchronously()
        } catch {
            await openStoreAsynchronously()
            report(error, operation: .backupRestore)
        }
        isRecoveryOperationRunning = false
    }

    private func openStore() {
        startupState = .loading

        do {
            guard let containerFactory else {
                return
            }
            try finishOpening(containerFactory())
        } catch {
            failStartup(error)
        }
    }

    private func openStoreAsynchronously() async {
        startupState = .loading
        do {
            guard let migrationAwareContainerFactory else {
                return
            }
            let (container, migrationBackup) =
                try await migrationAwareContainerFactory()
            if let migrationBackup {
                lastBackup = migrationBackup
            }
            try finishOpening(container)
        } catch {
            failStartup(error)
        }
    }

    private func finishOpening(_ container: ModelContainer) throws {
        presentedFailureRetryAction = nil
        presentedFailure = nil
        sdeManagement = try sdeManagementFactory(container, logger)
        projectManagement = ProjectAppComposition.makeViewModel(
            container: container
        )
        productionGraphManagement =
            ProjectAppComposition.makeGraphViewModel(container: container)
        buildOrBuyManagement =
            try ProjectAppComposition.makeBuildOrBuyViewModel(
                container: container
            )
        dashboardManagement =
            ProjectAppComposition.makeDashboardViewModel(
                container: container
            )
        inventoryManagement = InventoryAppComposition.makeViewModel(
            container: container
        )
        inventoryAvailabilityManagement =
            InventoryAppComposition.makeAvailabilityViewModel(
                container: container
            )
        safetyStockManagement =
            InventoryAppComposition.makeSafetyStockViewModel(
                container: container
            )
        projectReservationManagement =
            InventoryAppComposition.makeProjectReservationViewModel(
                container: container
            )
        reservationConflictManagement =
            InventoryAppComposition.makeReservationConflictViewModel(
                container: container
            )
        priceProfileManagement =
            PriceProfileAppComposition.makeViewModel(container: container)
        purchasingManagement =
            try ProjectAppComposition.makePurchasingViewModel(
                container: container
            )
        productionLedgerManagement =
            try ProjectAppComposition.makeProductionLedgerViewModel(
                container: container
            )
        accountManagement =
            try AccountAppComposition.makeViewModel(container: container)
        startupState = .ready(container)
    }

    private func failStartup(_ error: any Error) {
        presentedFailureRetryAction = nil
        presentedFailure = nil
        let failure = NexusFailureMapper.map(
            error,
            operation: .applicationStartup
        )
        logger.log(failure.diagnosticEvent)
        releaseStoreBoundState()
        startupState = .failed(failure)
    }

    private func releaseStoreBoundState() {
        sdeManagement = nil
        projectManagement = nil
        productionGraphManagement = nil
        buildOrBuyManagement = nil
        dashboardManagement = nil
        inventoryManagement = nil
        inventoryAvailabilityManagement = nil
        safetyStockManagement = nil
        projectReservationManagement = nil
        reservationConflictManagement = nil
        priceProfileManagement = nil
        purchasingManagement = nil
        productionLedgerManagement = nil
        accountManagement = nil
    }
}

struct RecoveryConfiguration {
    let storeURL: URL
    let backupDirectoryURL: URL
    let backupService: any LocalBackupManaging
}
