import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI
import UniformTypeIdentifiers

struct InventoryCSVImportSheet: View {
    @ObservedObject var model: InventoryCSVImportViewModel
    let location: StorageLocationSnapshot
    let reloadInventory: () async throws -> Void
    let reportError: (any Error, NexusOperation) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var showingFileImporter = false
    @State private var showingApplyConfirmation = false
    @State private var operationTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            Form {
                sourceSection
                if let inspection = model.inspection {
                    formatSection(inspection)
                    mappingSection(inspection)
                }
                if let preview = model.preview {
                    previewSection(preview)
                }
                if let report = model.report {
                    reportSection(report)
                }
            }
            .formStyle(.grouped)
            .navigationTitle("CSV-Bestand importieren")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") { dismiss() }
                }
            }
        }
        .frame(minWidth: 780, minHeight: 680)
        .fileImporter(
            isPresented: $showingFileImporter,
            allowedContentTypes: [
                .commaSeparatedText,
                .tabSeparatedText,
                .plainText
            ],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                run(operation: .inventoryImportInspect) {
                    try await model.selectFile(url)
                }
            case .failure(let error):
                reportError(error, .inventoryImportInspect)
            }
        }
        .confirmationDialog(
            "Vorgeschlagene Änderungen importieren?",
            isPresented: $showingApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button("Jetzt atomar importieren") {
                run(operation: .inventoryImportApply) {
                    _ = try await model.applyConfirmed()
                    try await reloadInventory()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Erst diese Bestätigung schreibt die sichtbaren Einfügungen und Ersetzungen gemeinsam mit dem Importbericht."
            )
        }
        .onDisappear { operationTask?.cancel() }
    }

    private var sourceSection: some View {
        Section("Quelle und Ziel") {
            LabeledContent("Ziel-Lager", value: location.name)
            if let sourceName = model.sourceName {
                LabeledContent("Datei", value: sourceName)
            } else {
                Text(
                    "Noch keine Datei gewählt. Bis zur bestätigten Übernahme wird kein Bestand verändert."
                )
                .foregroundStyle(.secondary)
            }
            HStack {
                Button("CSV-Datei wählen") {
                    showingFileImporter = true
                }
                .keyboardShortcut("o", modifiers: .command)
                Button("Prüfung abbrechen") {
                    operationTask?.cancel()
                }
                .disabled(!model.isWorking)
            }
            if model.isWorking {
                ProgressView("CSV wird geprüft …")
            }
        }
    }

    private func formatSection(
        _ inspection: InventoryCSVInspection
    ) -> some View {
        Section("Format") {
            Picker("Kodierung", selection: $model.encoding) {
                ForEach(InventoryCSVEncodingOption.allCases, id: \.self) {
                    Text($0.localizedName).tag($0)
                }
            }
            Picker("Trennzeichen", selection: $model.delimiter) {
                ForEach(InventoryCSVDelimiterOption.allCases, id: \.self) {
                    Text($0.localizedName).tag($0)
                }
            }
            Picker("Mengenformat", selection: $model.quantityFormat) {
                ForEach(InventoryCSVQuantityFormat.allCases, id: \.self) {
                    Text($0.localizedName).tag($0)
                }
            }
            HStack {
                LabeledContent(
                    "Erkannt",
                    value: "\(inspection.encoding.localizedName), \(inspection.delimiter.localizedName)"
                )
                Spacer()
                Button("Format neu prüfen") {
                    run(operation: .inventoryImportInspect) {
                        try await model.reinspect()
                    }
                }
                .disabled(model.isWorking)
            }
        }
    }

    private func mappingSection(
        _ inspection: InventoryCSVInspection
    ) -> some View {
        Section("Spalten zuordnen") {
            columnPicker(
                "Type-ID",
                selection: $model.typeIDColumn,
                headers: inspection.headers,
                optional: false
            )
            columnPicker(
                "Menge",
                selection: $model.quantityColumn,
                headers: inspection.headers,
                optional: false
            )
            columnPicker(
                "Itemname zur Gegenprüfung",
                selection: $model.itemNameColumn,
                headers: inspection.headers,
                optional: true
            )
            HStack {
                Text(
                    "\(NexusNumberFormat.quantity(inspection.dataRowCount)) Datenzeilen · Vorschau schreibt nichts"
                )
                .foregroundStyle(.secondary)
                Spacer()
                Button("Vorschau erzeugen") {
                    run(operation: .inventoryImportInspect) {
                        try await model.createPreview(locationID: location.id)
                    }
                }
                .keyboardShortcut(.return, modifiers: .command)
                .disabled(model.mapping == nil || model.isWorking)
            }
        }
    }

    private func columnPicker(
        _ title: String,
        selection: Binding<Int?>,
        headers: [String],
        optional: Bool
    ) -> some View {
        Picker(title, selection: selection) {
            Text(optional ? "Nicht verwenden" : "Bitte auswählen")
                .tag(Int?.none)
            ForEach(headers.indices, id: \.self) { index in
                Text(headers[index]).tag(Int?.some(index))
            }
        }
        .accessibilityLabel("\(title)-Spalte")
    }

    private func previewSection(
        _ preview: InventoryCSVImportPreview
    ) -> some View {
        Section("Detailvorschau") {
            HStack {
                Text(
                    "\(NexusNumberFormat.quantity(preview.insertCount)) neu · \(NexusNumberFormat.quantity(preview.requiresDecisions.count)) Konflikte · \(NexusNumberFormat.quantity(preview.invalidCount)) Fehler"
                )
                .font(.headline)
                Spacer()
                Button("Import bestätigen") {
                    showingApplyConfirmation = true
                }
                .keyboardShortcut(.return, modifiers: [.command, .shift])
                .disabled(!model.canApply)
            }
            Text(
                "Fehlerzeilen und übersprungene Konflikte werden nicht geschrieben. Jede Ersetzung muss einzeln gewählt werden."
            )
            .font(.caption)
            .foregroundStyle(.secondary)

            ForEach(preview.lines) { line in
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .firstTextBaseline) {
                        Text("Zeile \(line.rowNumber)")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                            .frame(width: 72, alignment: .leading)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(line.itemName ?? "Nicht aufgelöst")
                            if let typeID = line.typeID,
                               let quantity = line.quantity {
                                Text(
                                    "Type-ID \(typeID) · CSV \(NexusNumberFormat.quantity(quantity))"
                                )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        stateLabel(line)
                    }
                    if line.state == .replacementRequired {
                        Picker(
                            "Entscheidung für Zeile \(line.rowNumber)",
                            selection: decisionBinding(for: line.rowNumber)
                        ) {
                            Text("Entscheidung erforderlich")
                                .tag(InventoryCSVImportDecision?.none)
                            Text("Ersetzen")
                                .tag(InventoryCSVImportDecision?.some(.replace))
                            Text("Überspringen")
                                .tag(InventoryCSVImportDecision?.some(.skip))
                        }
                        .pickerStyle(.segmented)
                    }
                    ForEach(line.issues, id: \.code) { issue in
                        Label(issue.message, systemImage: "exclamationmark.triangle")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }
                .padding(.vertical, 4)
                .accessibilityElement(children: .contain)
            }
        }
    }

    private func reportSection(
        _ report: InventoryImportReport
    ) -> some View {
        Section("Importbericht") {
            Label("Import vollständig gespeichert", systemImage: "checkmark.circle.fill")
                .foregroundStyle(.green)
            LabeledContent(
                "Ergebnis",
                value: "\(NexusNumberFormat.quantity(report.insertedCount)) neu, \(NexusNumberFormat.quantity(report.replacedCount)) ersetzt, \(NexusNumberFormat.quantity(report.skippedCount)) übersprungen, \(NexusNumberFormat.quantity(report.invalidCount)) fehlerhaft"
            )
            LabeledContent("Berichts-ID", value: report.id.uuidString)
                .textSelection(.enabled)
            Text(
                "Der zeilengenaue Bericht wurde ohne Rohdatei und ohne Dateipfad lokal gespeichert."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private func stateLabel(
        _ line: InventoryCSVPreviewLine
    ) -> some View {
        let label: String
        let color: Color
        switch line.state {
        case .insert:
            label = "Hinzufügen"
            color = .green
        case .unchanged:
            label = "Unverändert"
            color = .secondary
        case .replacementRequired:
            label = "Konflikt"
            color = .orange
        case .invalid:
            label = "Fehler"
            color = .red
        }
        return Text(label)
            .font(.caption.bold())
            .foregroundStyle(color)
    }

    private func decisionBinding(
        for rowNumber: Int
    ) -> Binding<InventoryCSVImportDecision?> {
        Binding(
            get: { model.decisions[rowNumber] },
            set: { model.decisions[rowNumber] = $0 }
        )
    }

    private func run(
        operation: NexusOperation,
        _ action: @escaping @MainActor () async throws -> Void
    ) {
        operationTask?.cancel()
        operationTask = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                reportError(error, operation)
            }
        }
    }
}

private extension InventoryCSVEncodingOption {
    var localizedName: String {
        switch self {
        case .automatic: "Automatisch"
        case .utf8: "UTF-8"
        case .windows1252: "Windows-1252"
        case .isoLatin1: "ISO-8859-1"
        }
    }
}

private extension InventoryCSVDetectedEncoding {
    var localizedName: String {
        switch self {
        case .utf8: "UTF-8"
        case .utf16LittleEndian: "UTF-16 LE"
        case .utf16BigEndian: "UTF-16 BE"
        case .windows1252: "Windows-1252"
        case .isoLatin1: "ISO-8859-1"
        }
    }
}

private extension InventoryCSVDelimiterOption {
    var localizedName: String {
        switch self {
        case .automatic: "Automatisch"
        case .comma: "Komma"
        case .semicolon: "Semikolon"
        case .tab: "Tabulator"
        }
    }
}

private extension InventoryCSVDetectedDelimiter {
    var localizedName: String {
        switch self {
        case .comma: "Komma"
        case .semicolon: "Semikolon"
        case .tab: "Tabulator"
        }
    }
}

private extension InventoryCSVQuantityFormat {
    var localizedName: String {
        switch self {
        case .integer: "Ganzzahl"
        case .decimalComma: "Dezimalkomma, nur Nullbruch"
        case .decimalPoint: "Dezimalpunkt, nur Nullbruch"
        }
    }
}
