import AppKit
import Foundation
import NewEdenNexusInfrastructure
import NewEdenNexusPersistence
import SwiftData
import SwiftUI

@main
struct NewEdenNexusApp: App {
    @StateObject private var runtime: NexusAppRuntime

    init() {
        EVEPublicConfiguration.applyDefaults()
        if let isolatedStoreURL = AppExecutionEnvironment.isolatedStoreURL {
            _runtime = Self.makePersistentRuntime(
                storeURL: isolatedStoreURL
            )
        } else if AppExecutionEnvironment.isRunningTests {
            _runtime = StateObject(
                wrappedValue: NexusAppRuntime(
                    logger: UnifiedDiagnosticLogger(),
                    containerFactory:
                        NexusModelContainerFactory.makeInMemory
                )
            )
        } else {
            _runtime = Self.makePersistentRuntime(
                storeURL: NexusModelContainerFactory.defaultStoreURL
            )
        }
    }

    private static func makePersistentRuntime(
        storeURL: URL
    ) -> StateObject<NexusAppRuntime> {
        let backupService = SQLiteLocalBackupService()
        let backupDirectoryURL = storeURL
            .deletingLastPathComponent()
            .appendingPathComponent("Backups", isDirectory: true)
        let migrationCoordinator = NexusMigrationBackupCoordinator(
            backupService: backupService
        )
        return StateObject(
            wrappedValue: NexusAppRuntime(
                logger: UnifiedDiagnosticLogger(),
                migrationAwareContainerFactory: {
                    let backup =
                        try await migrationCoordinator.prepareForOpening(
                            storeURL: storeURL,
                            backupDirectoryURL: backupDirectoryURL
                        )
                    let container = try NexusModelContainerFactory.make(
                        at: storeURL
                    )
                    return (container, backup)
                },
                recoveryConfiguration: RecoveryConfiguration(
                    storeURL: storeURL,
                    backupDirectoryURL: backupDirectoryURL,
                    backupService: backupService
                )
            )
        )
    }

    var body: some Scene {
        WindowGroup("New Eden Nexus", id: "main") {
            content
                .background(MainWindowMarker())
                .task {
                    await SingleMainWindowCoordinator
                        .closeRestoredDuplicates()
                }
        }
        .defaultSize(width: 1_280, height: 800)
        .commands {
            SingleMainWindowCommands()
        }

        Settings {
            SettingsView()
                .environmentObject(runtime)
                .nexusErrorAlert(runtime: runtime)
                .frame(width: 860, height: 700)
        }
    }

    @ViewBuilder
    private var content: some View {
        switch runtime.startupState {
        case .loading:
            ProgressView("Lokale Datenbank wird geöffnet …")
                .frame(minWidth: 520, minHeight: 360)
        case .ready(let container):
            RootView()
                .environmentObject(runtime)
                .nexusErrorAlert(runtime: runtime)
                .frame(minWidth: 780, minHeight: 500)
                .modelContainer(container)
                .task {
                    runtime.startSDEAutomationIfNeeded()
                }
        case .failed(let failure):
            StartupFailureView(
                failure: failure,
                retry: runtime.retryStartup
            )
        }
    }
}

private struct SingleMainWindowCommands: Commands {
    @Environment(\.openWindow) private var openWindow

    var body: some Commands {
        CommandGroup(replacing: .newItem) {
            Button("New Eden Nexus") {
                if let window = SingleMainWindowCoordinator.mainWindow {
                    window.makeKeyAndOrderFront(nil)
                } else {
                    openWindow(id: "main")
                }
            }
            .keyboardShortcut("n")
        }
    }
}

@MainActor
private enum SingleMainWindowCoordinator {
    static let identifier = NSUserInterfaceItemIdentifier(
        "NewEdenNexus.MainWindow"
    )

    static var mainWindow: NSWindow? {
        NSApplication.shared.windows.first {
            $0.isVisible && $0.identifier == identifier
        }
    }

    static func closeRestoredDuplicates() async {
        do {
            try await Task.sleep(for: .milliseconds(250))
        } catch {
            return
        }

        let mainWindows = NSApplication.shared.windows.filter {
            $0.isVisible && $0.identifier == identifier
        }
        for window in mainWindows.dropFirst() {
            window.close()
        }
    }
}

private struct MainWindowMarker: NSViewRepresentable {
    func makeNSView(context: Context) -> NSView {
        MainWindowMarkerView()
    }

    func updateNSView(_ nsView: NSView, context: Context) {}
}

@MainActor
private final class MainWindowMarkerView: NSView {
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        window?.identifier = SingleMainWindowCoordinator.identifier
    }
}
