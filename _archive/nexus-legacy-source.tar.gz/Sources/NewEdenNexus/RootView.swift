import SwiftUI

struct RootView: View {
    @EnvironmentObject private var runtime: NexusAppRuntime
    @State private var selection: NexusModule? = .dashboard
    @State private var searchText = ""

    var body: some View {
        NavigationSplitView {
            Group {
                if filteredModules.isEmpty {
                    ContentUnavailableView {
                        Label(
                            "Kein Bereich gefunden",
                            systemImage: "magnifyingglass"
                        )
                    } description: {
                        Text(
                            "Prüfe den Suchbegriff oder zeige wieder alle Bereiche an."
                        )
                    } actions: {
                        Button("Suche löschen") {
                            searchText = ""
                        }
                        .keyboardShortcut(.cancelAction)
                    }
                } else {
                    List(filteredModules, selection: $selection) { module in
                        Label(
                            module.rawValue,
                            systemImage: module.symbol
                        )
                        .tag(module)
                    }
                }
            }
            .searchable(
                text: $searchText,
                placement: .sidebar,
                prompt: "Bereiche durchsuchen"
            )
            .navigationSplitViewColumnWidth(min: 190, ideal: 220)
            .safeAreaInset(edge: .bottom) {
                VStack(alignment: .leading, spacing: 4) {
                    Label("Local First", systemImage: "externaldrive.fill")
                    Text("Daten bleiben auf diesem Mac")
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding()
                .accessibilityElement(children: .combine)
                .accessibilityLabel(
                    "Local First. Daten bleiben auf diesem Mac."
                )
                .accessibilityIdentifier("nexus.localFirstStatus")
            }
        } detail: {
            Group {
                switch selection ?? .dashboard {
                case .dashboard:
                    if let model = runtime.dashboardManagement {
                        DashboardView(model: model)
                    } else {
                        ProgressView("Dashboard wird vorbereitet …")
                    }
                case .accounts:
                    if let model = runtime.accountManagement {
                        AccountsView(model: model)
                    } else {
                        ProgressView(
                            "Kontoverwaltung wird vorbereitet …"
                        )
                    }
                case .projects:
                    if let model = runtime.projectManagement,
                       let graphModel =
                        runtime.productionGraphManagement,
                       let availabilityModel =
                        runtime.inventoryAvailabilityManagement,
                       let safetyStockModel =
                        runtime.safetyStockManagement,
                       let reservationModel =
                        runtime.projectReservationManagement,
                       let conflictModel =
                        runtime.reservationConflictManagement,
                       let buildOrBuyModel =
                        runtime.buildOrBuyManagement {
                        ProjectsView(
                            model: model,
                            graphModel: graphModel,
                            buildOrBuyModel: buildOrBuyModel,
                            availabilityModel: availabilityModel,
                            safetyStockModel: safetyStockModel,
                            reservationModel: reservationModel,
                            conflictModel: conflictModel
                        )
                    } else {
                        ProgressView("Projektverwaltung wird vorbereitet …")
                    }
                case .productionLedger:
                    if let model = runtime.productionLedgerManagement {
                        ProductionLedgerView(model: model)
                    } else {
                        ProgressView(
                            "Produktionsbuch wird vorbereitet …"
                        )
                    }
                case .synchronization:
                    if let model = runtime.accountManagement {
                        SynchronizationView(model: model)
                    } else {
                        ProgressView(
                            "Synchronisation wird vorbereitet …"
                        )
                    }
                case .sdeData:
                    if let model = runtime.sdeManagement {
                        SDEDataManagementView(model: model)
                    } else {
                        ProgressView("SDE-Verwaltung wird vorbereitet …")
                    }
                case .roadmap: RoadmapView()
                case .assets:
                    if let model = runtime.inventoryManagement {
                        InventoryView(model: model)
                    } else {
                        ProgressView("Lagerverwaltung wird vorbereitet …")
                    }
                case .blueprints:
                    EmptyModuleView(
                        title: "Blueprints",
                        symbol: "doc.text.magnifyingglass",
                        explanation:
                            "Eigene EVE-Blueprints findest du bei "
                            + "Accounts unter Details. Eine zentrale "
                            + "Blueprint-Bibliothek bleibt ein späterer "
                            + "Ausbau."
                    )
                case .purchasing:
                    if let model = runtime.purchasingManagement {
                        PurchasingView(
                            model: model,
                            reportError: { error, operation in
                                runtime.report(
                                    error,
                                    operation: operation
                                )
                            }
                        )
                    } else {
                        ProgressView(
                            "Einkaufsworkflow wird vorbereitet …"
                        )
                    }
                case .prices:
                    if let model = runtime.priceProfileManagement {
                        PriceProfileView(model: model)
                    } else {
                        ProgressView("Preissätze werden vorbereitet …")
                    }
                }
            }
        }
        .tint(NexusTheme.accent)
    }

    private var filteredModules: [NexusModule] {
        NexusModule.allCases.filter {
            $0.matches(searchText: searchText)
        }
    }
}
