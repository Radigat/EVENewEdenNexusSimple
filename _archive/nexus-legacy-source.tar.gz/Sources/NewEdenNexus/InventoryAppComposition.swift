import NewEdenNexusApplication
import NewEdenNexusInfrastructure
import NewEdenNexusPersistence
import SwiftData

@MainActor
enum InventoryAppComposition {
    static func makeViewModel(
        container: ModelContainer
    ) -> InventoryViewModel {
        let repository = SwiftDataInventoryRepository(
            modelContainer: container
        )
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let management = InventoryManagementService(
            repository: repository,
            catalog: catalog
        )
        return InventoryViewModel(
            inventory: management,
            csvImporter: InventoryCSVImportService(
                parser: DelimitedInventoryCSVParser(),
                repository: repository,
                catalog: catalog
            ),
            csvFileReader: LocalInventoryCSVFileReader()
        )
    }

    static func makeAvailabilityViewModel(
        container: ModelContainer
    ) -> InventoryAvailabilityViewModel {
        InventoryAvailabilityViewModel(
            service: makeAvailabilityService(container: container)
        )
    }

    static func makeSafetyStockViewModel(
        container: ModelContainer
    ) -> SafetyStockViewModel {
        SafetyStockViewModel(
            service: makeSafetyStockService(container: container)
        )
    }

    static func makeProjectReservationViewModel(
        container: ModelContainer
    ) -> ProjectReservationViewModel {
        ProjectReservationViewModel(
            service: ProjectReservationService(
                safetyStock: makeSafetyStockService(
                    container: container
                ),
                repository: SwiftDataProjectReservationRepository(
                    modelContainer: container
                )
            )
        )
    }

    static func makeReservationConflictViewModel(
        container: ModelContainer
    ) -> ReservationConflictViewModel {
        ReservationConflictViewModel(
            service: ReservationConflictService(
                safetyStock: makeSafetyStockService(
                    container: container
                ),
                reservations: SwiftDataProjectReservationRepository(
                    modelContainer: container
                ),
                projects: SwiftDataProductionProjectRepository(
                    modelContainer: container
                ),
                catalog: SwiftDataItemBlueprintCatalog(
                    modelContainer: container
                )
            )
        )
    }

    private static func makeAvailabilityService(
        container: ModelContainer
    ) -> InventoryAvailabilityService {
        InventoryAvailabilityService(
            repository: SwiftDataInventoryAvailabilityRepository(
                modelContainer: container
            ),
            projectRepository: SwiftDataProductionProjectRepository(
                modelContainer: container
            ),
            graphRepository: SwiftDataProductionGraphRepository(
                modelContainer: container
            )
        )
    }

    private static func makeSafetyStockService(
        container: ModelContainer
    ) -> SafetyStockService {
        SafetyStockService(
            availability: makeAvailabilityService(
                container: container
            ),
            repository: SwiftDataSafetyStockPolicyRepository(
                modelContainer: container
            )
        )
    }
}
