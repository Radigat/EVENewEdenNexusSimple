import NewEdenNexusDomain

enum ProductionGraphDisplayBudget {
    static let outlineNodeLimit = 500
    static let initialVisibleNodeCount = 1_000
    static let visibleNodeIncrement = 1_000
}

struct ProductionGraphDisplayRow: Identifiable, Equatable {
    let node: ProductionGraphNode
    let incomingQuantity: Int64?
    let incomingCalculation: ProductionMaterialCalculation?
    let incomingReactionCalculation: ReactionMaterialCalculation?

    var id: ProductionGraphNodeID {
        node.id
    }
}

struct ProductionGraphDisplayProjection: Equatable {
    let rows: [ProductionGraphDisplayRow]
    let totalNodeCount: Int

    var omittedNodeCount: Int {
        max(0, totalNodeCount - rows.count)
    }

    init?(graph: ProductionGraphSnapshot, visibleNodeLimit: Int) {
        guard visibleNodeLimit > 0 else {
            return nil
        }
        let nodesByID = Dictionary(
            uniqueKeysWithValues: graph.nodes.map { ($0.id, $0) }
        )
        guard nodesByID[graph.rootNodeID] != nil else {
            return nil
        }
        let edgesByParent = Dictionary(
            grouping: graph.edges,
            by: \.parentID
        ).mapValues {
            $0.sorted {
                if $0.sortOrder != $1.sortOrder {
                    return $0.sortOrder < $1.sortOrder
                }
                return $0.childID.rawValue < $1.childID.rawValue
            }
        }

        struct Pending {
            let nodeID: ProductionGraphNodeID
            let incomingEdge: ProductionGraphEdge?
        }

        var rows: [ProductionGraphDisplayRow] = []
        rows.reserveCapacity(min(visibleNodeLimit, graph.nodes.count))
        var pending = [
            Pending(nodeID: graph.rootNodeID, incomingEdge: nil)
        ]
        var visited: Set<ProductionGraphNodeID> = []
        visited.reserveCapacity(min(visibleNodeLimit, graph.nodes.count))

        while rows.count < visibleNodeLimit,
              let current = pending.popLast() {
            guard visited.insert(current.nodeID).inserted,
                  let node = nodesByID[current.nodeID] else {
                return nil
            }
            let edge = current.incomingEdge
            rows.append(
                ProductionGraphDisplayRow(
                    node: node,
                    incomingQuantity: edge?.baseQuantityPerRun,
                    incomingCalculation: edge?.materialCalculation,
                    incomingReactionCalculation:
                        edge?.reactionMaterialCalculation
                )
            )
            for child in (edgesByParent[current.nodeID] ?? []).reversed() {
                pending.append(
                    Pending(
                        nodeID: child.childID,
                        incomingEdge: child
                    )
                )
            }
        }

        self.rows = rows
        totalNodeCount = graph.nodes.count
    }
}
