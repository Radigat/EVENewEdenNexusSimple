import NewEdenNexusApplication
import SwiftUI

struct StartupFailureView: View {
    let failure: NexusFailure
    let retry: () -> Void

    var body: some View {
        ContentUnavailableView {
            Label(failure.title, systemImage: "externaldrive.badge.exclamationmark")
        } description: {
            VStack(spacing: 8) {
                Text(failure.message)
                Text(failure.recoverySuggestion)
                Text("Diagnosecode: \(failure.code.rawValue)")
                    .font(.caption.monospaced())
                    .foregroundStyle(.secondary)
            }
            .multilineTextAlignment(.center)
        } actions: {
            Button("Erneut versuchen", action: retry)
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
        }
        .padding(32)
        .frame(minWidth: 520, minHeight: 360)
    }
}

private struct RuntimeErrorAlertModifier: ViewModifier {
    @ObservedObject var runtime: NexusAppRuntime

    func body(content: Content) -> some View {
        content.alert(
            runtime.presentedFailure?.title ?? "Fehler",
            isPresented: Binding(
                get: { runtime.presentedFailure != nil },
                set: { isPresented in
                    if !isPresented {
                        runtime.dismissPresentedFailure()
                    }
                }
            ),
            presenting: runtime.presentedFailure
        ) { _ in
            if runtime.canRetryPresentedFailure {
                Button("Erneut versuchen") {
                    runtime.retryPresentedFailure()
                }
                .keyboardShortcut(.defaultAction)
            }
            Button("OK") {
                runtime.dismissPresentedFailure()
            }
            .keyboardShortcut(.cancelAction)
        } message: { failure in
            Text(
                "\(failure.message)\n\n\(failure.recoverySuggestion)\n\n"
                    + "Diagnosecode: \(failure.code.rawValue)"
            )
        }
    }
}

struct NexusValidationSummary: View {
    let issues: [NexusValidationIssue]

    var body: some View {
        if !issues.isEmpty {
            VStack(alignment: .leading, spacing: 6) {
                Label(
                    "Bitte Eingaben prüfen",
                    systemImage: "exclamationmark.triangle.fill"
                )
                .font(.headline)
                .foregroundStyle(.orange)
                ForEach(issues) { issue in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(issue.field): \(issue.message)")
                        Text(issue.recoverySuggestion)
                            .foregroundStyle(.secondary)
                    }
                    .font(.caption)
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel(
                        "\(issue.field). \(issue.message) \(issue.recoverySuggestion)"
                    )
                }
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                Color.orange.opacity(0.12),
                in: RoundedRectangle(cornerRadius: 8)
            )
            .accessibilityIdentifier("nexus.validation.summary")
        }
    }
}

struct NexusOperationFailureView: View {
    let title: String
    let message: String
    let retry: () -> Void

    var body: some View {
        ContentUnavailableView {
            Label(title, systemImage: "exclamationmark.triangle")
        } description: {
            Text(message)
        } actions: {
            Button("Erneut versuchen", action: retry)
                .keyboardShortcut(.defaultAction)
        }
    }
}

extension View {
    func nexusErrorAlert(runtime: NexusAppRuntime) -> some View {
        modifier(RuntimeErrorAlertModifier(runtime: runtime))
    }
}
