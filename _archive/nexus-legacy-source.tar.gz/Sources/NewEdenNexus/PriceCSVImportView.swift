import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI
import UniformTypeIdentifiers

struct PriceCSVImportSheet: View {
    @ObservedObject var model: PriceCSVImportViewModel
    let profile: PriceProfileSnapshot
    let reloadPrices: () async throws -> Void
    let reportError: (any Error, NexusOperation) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var showingFileImporter = false
    @State private var showingConfirmation = false
    @State private var task: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            Form {
                sourceSection
                if let inspection = model.inspection {
                    formatSection(inspection)
                    mappingSection(inspection)
                }
                validitySection
                if let preview = model.preview {
                    previewSection(preview)
                }
                if let report = model.report {
                    reportSection(report)
                }
            }
            .formStyle(.grouped)
            .navigationTitle("CSV-Preise importieren")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") { dismiss() }
                }
            }
        }
        .frame(minWidth: 820, minHeight: 720)
        .fileImporter(
            isPresented: $showingFileImporter,
            allowedContentTypes: [
                .commaSeparatedText,
                .tabSeparatedText,
                .plainText
            ],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                run(.priceImportInspect) {
                    try await model.selectFile(url)
                }
            case .failure(let error):
                reportError(error, .priceImportInspect)
            }
        }
        .confirmationDialog(
            "Vorgeschlagene Preisänderungen importieren?",
            isPresented: $showingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Jetzt atomar importieren") {
                run(.priceImportApply) {
                    _ = try await model.applyConfirmed()
                    try await reloadPrices()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Erst diese Bestätigung speichert Einfügungen, Ersetzungen und den zeilengenauen Importbericht gemeinsam."
            )
        }
        .onDisappear { task?.cancel() }
    }

    private var sourceSection: some View {
        Section("Quelle und Ziel") {
            LabeledContent("Zielprofil", value: profile.name)
            LabeledContent("Währung", value: "ISK")
            if let sourceName = model.sourceName {
                LabeledContent("Datei", value: sourceName)
            } else {
                Text(
                    "Noch keine Datei gewählt. Vorschau und Abbruch verändern keine Preise."
                )
                .foregroundStyle(.secondary)
            }
            HStack {
                Button("CSV-Datei wählen") {
                    showingFileImporter = true
                }
                .keyboardShortcut("o", modifiers: .command)
                Button("Prüfung abbrechen") { task?.cancel() }
                    .disabled(!model.isWorking)
            }
            if model.isWorking {
                ProgressView("Preisdatei wird geprüft …")
            }
        }
    }

    private func formatSection(
        _ inspection: PriceCSVInspection
    ) -> some View {
        Section("Format") {
            Picker("Kodierung", selection: $model.encoding) {
                ForEach(InventoryCSVEncodingOption.allCases, id: \.self) {
                    Text($0.priceImportName).tag($0)
                }
            }
            Picker("Trennzeichen", selection: $model.delimiter) {
                ForEach(InventoryCSVDelimiterOption.allCases, id: \.self) {
                    Text($0.priceImportName).tag($0)
                }
            }
            Picker("Dezimalformat", selection: $model.decimalFormat) {
                Text("Dezimalpunkt, z. B. 12.34")
                    .tag(PriceCSVDecimalFormat.decimalPoint)
                Text("Dezimalkomma, z. B. 12,34")
                    .tag(PriceCSVDecimalFormat.decimalComma)
            }
            HStack {
                Text(
                    "\(NexusNumberFormat.quantity(inspection.dataRowCount)) Datenzeilen · Vorschau schreibt nichts"
                )
                .foregroundStyle(.secondary)
                Spacer()
                Button("Format neu prüfen") {
                    run(.priceImportInspect) {
                        try await model.reinspect()
                    }
                }
                .disabled(model.isWorking)
            }
        }
    }

    private func mappingSection(
        _ inspection: PriceCSVInspection
    ) -> some View {
        Section("Spalten zuordnen") {
            columnPicker(
                "Type-ID",
                selection: $model.typeIDColumn,
                headers: inspection.headers,
                optional: false
            )
            columnPicker(
                "Einheitspreis",
                selection: $model.priceColumn,
                headers: inspection.headers,
                optional: false
            )
            columnPicker(
                "Itemname zur Gegenprüfung",
                selection: $model.itemNameColumn,
                headers: inspection.headers,
                optional: true
            )
            HStack {
                Spacer()
                Button("Detailvorschau erzeugen") {
                    run(.priceImportInspect) {
                        try await model.createPreview(profileID: profile.id)
                    }
                }
                .keyboardShortcut(.return, modifiers: .command)
                .disabled(
                    model.mapping == nil
                        || model.isWorking
                        || (model.hasExpiration
                            && model.validUntil <= model.validFrom)
                )
            }
        }
    }

    private var validitySection: some View {
        Section("Gültigkeit für diesen Import") {
            DatePicker(
                "Gültig ab",
                selection: $model.validFrom,
                displayedComponents: [.date, .hourAndMinute]
            )
            Toggle(
                "Ablaufdatum verwenden",
                isOn: $model.hasExpiration
            )
            if model.hasExpiration {
                DatePicker(
                    "Gültig bis",
                    selection: $model.validUntil,
                    displayedComponents: [.date, .hourAndMinute]
                )
            }
        }
    }

    private func columnPicker(
        _ title: String,
        selection: Binding<Int?>,
        headers: [String],
        optional: Bool
    ) -> some View {
        Picker(title, selection: selection) {
            Text(optional ? "Nicht verwenden" : "Bitte auswählen")
                .tag(Int?.none)
            ForEach(headers.indices, id: \.self) {
                Text(headers[$0]).tag(Int?.some($0))
            }
        }
        .accessibilityLabel("\(title)-Spalte")
    }

    private func previewSection(
        _ preview: PriceCSVImportPreview
    ) -> some View {
        Section("Detailvorschau") {
            HStack {
                Text(
                    "\(NexusNumberFormat.quantity(preview.insertCount)) neu · \(NexusNumberFormat.quantity(preview.requiresDecisions.count)) Konflikte · \(NexusNumberFormat.quantity(preview.invalidCount)) Fehler"
                )
                .font(.headline)
                Spacer()
                Button("Import bestätigen") {
                    showingConfirmation = true
                }
                .disabled(!model.canApply)
            }
            ForEach(preview.lines) { line in
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Text("Zeile \(line.rowNumber)")
                            .font(.caption.monospacedDigit())
                            .frame(width: 72, alignment: .leading)
                        Text(line.itemName ?? "Nicht aufgelöst")
                        Spacer()
                        Text(line.state.priceImportName)
                            .font(.caption.bold())
                    }
                    if let typeID = line.typeID,
                       let amount = line.amount {
                        Text(
                            "Type-ID \(typeID) · \(NexusNumberFormat.isk(hundredths: amount.hundredths))"
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }
                    if line.state == .replacementRequired {
                        Picker(
                            "Entscheidung für Zeile \(line.rowNumber)",
                            selection: decision(for: line.rowNumber)
                        ) {
                            Text("Entscheidung erforderlich")
                                .tag(PriceCSVImportDecision?.none)
                            Text("Ersetzen")
                                .tag(PriceCSVImportDecision?.some(.replace))
                            Text("Überspringen")
                                .tag(PriceCSVImportDecision?.some(.skip))
                        }
                        .pickerStyle(.segmented)
                    }
                    ForEach(line.issues, id: \.code) {
                        Label(
                            $0.message,
                            systemImage: "exclamationmark.triangle"
                        )
                        .font(.caption)
                        .foregroundStyle(.orange)
                    }
                }
                .padding(.vertical, 4)
                .accessibilityElement(children: .contain)
            }
        }
    }

    private func reportSection(
        _ report: PriceImportReport
    ) -> some View {
        Section("Importbericht") {
            Label(
                "Import vollständig gespeichert",
                systemImage: "checkmark.circle.fill"
            )
            .foregroundStyle(.green)
            LabeledContent(
                "Ergebnis",
                value: "\(NexusNumberFormat.quantity(report.insertedCount)) neu, \(NexusNumberFormat.quantity(report.replacedCount)) ersetzt, \(NexusNumberFormat.quantity(report.skippedCount)) übersprungen, \(NexusNumberFormat.quantity(report.invalidCount)) fehlerhaft"
            )
            LabeledContent("Berichts-ID", value: report.id.uuidString)
                .textSelection(.enabled)
            Text(
                "Gespeichert wurden Bericht, Dateiname und SHA-256 – nicht die Rohdatei oder der lokale Dateipfad."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private func decision(
        for rowNumber: Int
    ) -> Binding<PriceCSVImportDecision?> {
        Binding(
            get: { model.decisions[rowNumber] },
            set: { model.decisions[rowNumber] = $0 }
        )
    }

    private func run(
        _ operation: NexusOperation,
        action: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                reportError(error, operation)
            }
        }
    }
}

private extension InventoryCSVEncodingOption {
    var priceImportName: String {
        switch self {
        case .automatic: "Automatisch"
        case .utf8: "UTF-8"
        case .windows1252: "Windows-1252"
        case .isoLatin1: "ISO-8859-1"
        }
    }
}

private extension InventoryCSVDelimiterOption {
    var priceImportName: String {
        switch self {
        case .automatic: "Automatisch"
        case .comma: "Komma"
        case .semicolon: "Semikolon"
        case .tab: "Tabulator"
        }
    }
}

private extension PriceCSVPreviewState {
    var priceImportName: String {
        switch self {
        case .insert: "Hinzufügen"
        case .unchanged: "Unverändert"
        case .replacementRequired: "Konflikt"
        case .invalid: "Fehler"
        }
    }
}
