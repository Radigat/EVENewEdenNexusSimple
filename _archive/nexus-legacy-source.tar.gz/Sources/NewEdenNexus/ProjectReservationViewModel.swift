import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum ProjectReservationViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case invalidQuantity(typeID: Int64)
    case activeReservationRequired(typeID: Int64)
    case previewRequired
}

enum ProjectReservationEditMode:
    String,
    CaseIterable,
    Identifiable
{
    case reserve = "Reservieren/Ändern"
    case consume = "Verbrauchen"
    case release = "Freigeben"

    var id: String { rawValue }
}

struct ProjectReservationFieldState: Equatable {
    var mode: ProjectReservationEditMode = .reserve
    var quantity = ""
    var priority = 2
    var hasExpiry = false
    var expiresAt = Date()
}

@MainActor
final class ProjectReservationViewModel: ObservableObject {
    @Published private(set) var preview: ProjectReservationPreview?
    @Published private(set) var isLoading = false
    @Published private(set) var isPreviewing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreviewCurrent = false
    @Published private(set) var fields:
        [Int64: ProjectReservationFieldState] = [:]

    private let service: any ProjectReservationManaging
    private var projectID: UUID?
    private var defaultPriority = 2

    init(service: any ProjectReservationManaging) {
        self.service = service
    }

    var canApply: Bool {
        preview?.changes.isEmpty == false
            && isPreviewCurrent
            && !isSaving
    }

    func load(projectID: UUID, defaultPriority: Int) async throws {
        guard !isBusy else {
            throw ProjectReservationViewModelError
                .operationAlreadyRunning
        }
        self.projectID = projectID
        self.defaultPriority = defaultPriority
        isLoading = true
        defer { isLoading = false }
        let loaded = try await service.preview(
            projectID: projectID,
            changes: nil
        )
        try Task.checkCancellation()
        applyToFields(loaded)
        preview = loaded
        isPreviewCurrent = true
    }

    func state(typeID: Int64) -> ProjectReservationFieldState {
        fields[typeID] ?? ProjectReservationFieldState(
            priority: defaultPriority
        )
    }

    func setState(
        _ state: ProjectReservationFieldState,
        typeID: Int64
    ) {
        fields[typeID] = state
        isPreviewCurrent = false
    }

    func calculatePreview() async throws {
        guard !isBusy else {
            throw ProjectReservationViewModelError
                .operationAlreadyRunning
        }
        guard let projectID, let preview else {
            throw ProjectReservationViewModelError.previewRequired
        }
        let changes = try makeChanges(from: preview)
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await service.preview(
            projectID: projectID,
            changes: changes
        )
        try Task.checkCancellation()
        self.preview = calculated
        isPreviewCurrent = true
    }

    func applyConfirmedPreview() async throws {
        guard !isBusy else {
            throw ProjectReservationViewModelError
                .operationAlreadyRunning
        }
        guard let preview, canApply else {
            throw ProjectReservationViewModelError.previewRequired
        }
        isSaving = true
        defer { isSaving = false }
        let saved = try await service.apply(preview, confirmed: true)
        self.preview = saved
        applyToFields(saved)
        isPreviewCurrent = true
    }

    private var isBusy: Bool {
        isLoading || isPreviewing || isSaving
    }

    private func makeChanges(
        from preview: ProjectReservationPreview
    ) throws -> [ProjectReservationChange] {
        try preview.calculation.lines.compactMap { line in
            let typeID = line.safetyStock.availability.typeID
            let state = state(typeID: typeID)
            switch state.mode {
            case .reserve:
                let text = state.quantity.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                guard !text.isEmpty else { return nil }
                guard let quantity = Int64(text), quantity > 0 else {
                    throw ProjectReservationViewModelError
                        .invalidQuantity(typeID: typeID)
                }
                let expiresAt = state.hasExpiry
                    ? state.expiresAt
                    : nil
                if let current = line.currentReservation,
                   current.remainingQuantity == quantity,
                   current.priority == state.priority,
                   current.expiresAt == expiresAt {
                    return nil
                }
                return .reserve(
                    typeID: typeID,
                    remainingQuantity: quantity,
                    priority: state.priority,
                    expiresAt: expiresAt
                )
            case .consume:
                guard line.currentReservation != nil else {
                    throw ProjectReservationViewModelError
                        .activeReservationRequired(typeID: typeID)
                }
                let text = state.quantity.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                guard let quantity = Int64(text), quantity > 0 else {
                    throw ProjectReservationViewModelError
                        .invalidQuantity(typeID: typeID)
                }
                return .consume(typeID: typeID, quantity: quantity)
            case .release:
                guard line.currentReservation != nil else {
                    throw ProjectReservationViewModelError
                        .activeReservationRequired(typeID: typeID)
                }
                return .release(typeID: typeID)
            }
        }
    }

    private func applyToFields(
        _ preview: ProjectReservationPreview
    ) {
        fields = Dictionary(
            uniqueKeysWithValues: preview.calculation.lines.map { line in
                let typeID = line.safetyStock.availability.typeID
                let current = line.currentReservation
                return (
                    typeID,
                    ProjectReservationFieldState(
                        mode: .reserve,
                        quantity: current.map {
                            String($0.remainingQuantity)
                        } ?? "",
                        priority: current?.priority ?? defaultPriority,
                        hasExpiry: current?.expiresAt != nil,
                        expiresAt: current?.expiresAt ?? Date()
                    )
                )
            }
        )
    }
}
