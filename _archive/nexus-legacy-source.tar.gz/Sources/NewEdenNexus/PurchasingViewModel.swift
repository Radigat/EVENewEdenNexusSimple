import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum PurchasingViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case previewRequired
}

@MainActor
final class PurchasingViewModel: ObservableObject {
    @Published private(set) var preview: PurchasingWorkflowPreview?
    @Published private(set) var isLoading = false
    @Published private(set) var isPreviewing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreviewCurrent = false
    @Published private(set) var copiedTextList = false
    @Published var purchasedQuantityTexts:
        [PurchaseAllocationKey: String] = [:]

    private let service: any PurchasingWorkflowManaging

    init(service: any PurchasingWorkflowManaging) {
        self.service = service
    }

    var positions: [PurchasingWorkflowPosition] {
        preview?.aggregation.positions ?? []
    }

    var issues: [PurchasingProjectIssue] {
        preview?.issues ?? []
    }

    var canApply: Bool {
        isPreviewCurrent
            && preview?.hasChanges == true
            && validationIssues.isEmpty
            && !isBusy
    }

    var validationIssues: [NexusValidationIssue] {
        positions.flatMap { position in
            position.sources.compactMap { source in
                let key = PurchaseAllocationKey(
                    projectID: source.projectID,
                    typeID: position.typeID
                )
                let text = purchasedQuantityTexts[key]?
                    .trimmingCharacters(
                        in: .whitespacesAndNewlines
                    ) ?? ""
                guard let quantity = Int64(text),
                      quantity >= 0,
                      quantity <= source.targetQuantity else {
                    return .integerRange(
                        field:
                            "\(position.name) – \(source.projectName)",
                        minimum: 0,
                        maximum: source.targetQuantity,
                        identifier:
                            "\(source.projectID.uuidString):\(position.typeID)"
                    )
                }
                return nil
            }
        }
    }

    var textList: String {
        guard isPreviewCurrent else { return "" }
        return preview?.aggregation.textList ?? ""
    }

    var csv: String {
        guard isPreviewCurrent else { return "" }
        return preview?.aggregation.csv ?? ""
    }

    func load() async throws {
        guard !isBusy else {
            throw PurchasingViewModelError.operationAlreadyRunning
        }
        isLoading = true
        defer { isLoading = false }
        let loaded = try await service.load()
        try Task.checkCancellation()
        apply(loaded)
    }

    func setPurchasedQuantityText(
        _ value: String,
        projectID: UUID,
        typeID: Int64
    ) {
        let key = PurchaseAllocationKey(
            projectID: projectID,
            typeID: typeID
        )
        guard purchasedQuantityTexts[key] != nil else { return }
        purchasedQuantityTexts[key] = value
        invalidatePreview()
    }

    func markPurchased(typeID: Int64) {
        guard let position = positions.first(where: {
            $0.typeID == typeID
        }) else { return }
        for source in position.sources {
            purchasedQuantityTexts[
                PurchaseAllocationKey(
                    projectID: source.projectID,
                    typeID: typeID
                )
            ] = String(source.targetQuantity)
        }
        invalidatePreview()
    }

    func resetPurchased(typeID: Int64) {
        guard let position = positions.first(where: {
            $0.typeID == typeID
        }) else { return }
        for source in position.sources {
            purchasedQuantityTexts[
                PurchaseAllocationKey(
                    projectID: source.projectID,
                    typeID: typeID
                )
            ] = "0"
        }
        invalidatePreview()
    }

    func calculatePreview() async throws {
        guard !isBusy else {
            throw PurchasingViewModelError.operationAlreadyRunning
        }
        guard preview != nil else {
            throw PurchasingViewModelError.previewRequired
        }
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await service.preview(
            progress: try drafts()
        )
        try Task.checkCancellation()
        apply(calculated)
    }

    func applyConfirmed() async throws {
        guard !isBusy else {
            throw PurchasingViewModelError.operationAlreadyRunning
        }
        guard let preview, canApply else {
            throw PurchasingViewModelError.previewRequired
        }
        isSaving = true
        defer { isSaving = false }
        let saved = try await service.apply(preview, confirmed: true)
        try Task.checkCancellation()
        apply(saved)
    }

    func markTextListCopied() {
        copiedTextList = !textList.isEmpty
    }

    private var isBusy: Bool {
        isLoading || isPreviewing || isSaving
    }

    private func drafts() throws -> [PurchaseProgressDraft] {
        try positions.flatMap { position in
            try position.sources.map { source in
                let key = PurchaseAllocationKey(
                    projectID: source.projectID,
                    typeID: position.typeID
                )
                let text = purchasedQuantityTexts[key]?
                    .trimmingCharacters(
                        in: .whitespacesAndNewlines
                    ) ?? ""
                guard let quantity = Int64(text),
                      quantity >= 0,
                      quantity <= source.targetQuantity else {
                    throw PurchasingWorkflowManagementError
                        .invalidDraft(key, quantity: -1)
                }
                return PurchaseProgressDraft(
                    projectID: source.projectID,
                    typeID: position.typeID,
                    purchasedQuantity: quantity
                )
            }
        }
    }

    private func apply(_ loaded: PurchasingWorkflowPreview) {
        preview = loaded
        purchasedQuantityTexts = Dictionary(
            uniqueKeysWithValues:
                loaded.aggregation.positions.flatMap { position in
                    position.sources.map {
                        (
                            PurchaseAllocationKey(
                                projectID: $0.projectID,
                                typeID: position.typeID
                            ),
                            String($0.recordedPurchasedQuantity)
                        )
                    }
                }
        )
        isPreviewCurrent = true
        copiedTextList = false
    }

    private func invalidatePreview() {
        isPreviewCurrent = false
        copiedTextList = false
    }
}
