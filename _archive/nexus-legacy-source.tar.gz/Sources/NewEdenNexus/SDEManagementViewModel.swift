import Foundation
import NewEdenNexusApplication

@MainActor
final class SDEManagementViewModel: ObservableObject {
    struct Dependencies {
        var check: (Bool) async throws -> SDEUpdateCheckReport
        var loadState: () async throws -> SDEUpdateCheckState
        var activeVersion: () async throws -> ActiveSDEVersion?
        var readLogs: () async throws -> [SDEInstallationLog]
        var prefetch: (Int) async throws -> SDEPrefetchedArchive
        var prefetched: (Int) async throws -> SDEPrefetchedArchive?
        var install:
            (Int, Bool, SDEInstallationProgressHandler?) async throws
                -> SDEInstallationResult
        var recover: () async throws -> Int
        var retentionPreview:
            (Int) async throws -> SDECatalogRetentionPreview
        var applyRetention:
            (
                SDECatalogRetentionPreview,
                SDECatalogRetentionConfirmation
            ) async throws -> SDECatalogRetentionResult
        var storeByteCount: () throws -> Int64
        var hasOwnerContact: () -> Bool
        var saveOwnerContact: (String) throws -> Void
        var loadOwnerContact: () -> String
        var now: () -> Date
    }

    @Published private(set) var settings: SDEAutomationSettings
    @Published private(set) var phase: SDEManagementPhase = .idle
    @Published private(set) var report: SDEUpdateCheckReport?
    @Published private(set) var state = SDEUpdateCheckState()
    @Published private(set) var activeVersion: ActiveSDEVersion?
    @Published private(set) var logs: [SDEInstallationLog] = []
    @Published private(set) var prefetchedArchive: SDEPrefetchedArchive?
    @Published private(set) var storeByteCount: Int64 = 0
    @Published private(set) var retentionPreview:
        SDECatalogRetentionPreview?
    @Published private(set) var safeFailureCode: String?
    @Published private(set) var statusMessage: String?
    @Published private(set) var contactStatusMessage: String?
    @Published private(set) var hasStoredOwnerContact: Bool
    @Published var ownerContact: String
    @Published var logSearchText = ""
    @Published var newestLogsFirst = true
    @Published var diagnosticExportData: Data?
    @Published var diagnosticExportPreview = ""

    private let dependencies: Dependencies
    private let defaults: UserDefaults
    private var operationTask: Task<Void, Never>?
    private var schedulerTask: Task<Void, Never>?
    private var automationStarted = false

    init(
        dependencies: Dependencies,
        defaults: UserDefaults = .standard
    ) {
        self.dependencies = dependencies
        self.defaults = defaults
        settings = Self.loadSettings(defaults: defaults)
        ownerContact = dependencies.loadOwnerContact()
        hasStoredOwnerContact = dependencies.hasOwnerContact()
    }

    deinit {
        operationTask?.cancel()
        schedulerTask?.cancel()
    }

    var isBusy: Bool {
        operationTask != nil
    }

    var filteredLogs: [SDEInstallationLog] {
        let filtered: [SDEInstallationLog]
        let query = logSearchText
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        if query.isEmpty {
            filtered = logs
        } else {
            filtered = logs.filter { log in
                String(log.requestedBuildNumber).contains(query)
                    || log.events.contains {
                        $0.phase.rawValue.lowercased().contains(query)
                            || ($0.safeCode?.lowercased().contains(query)
                                ?? false)
                    }
            }
        }
        return filtered.sorted {
            let left = $0.events.first?.occurredAt ?? .distantPast
            let right = $1.events.first?.occurredAt ?? .distantPast
            return newestLogsFirst ? left > right : left < right
        }
    }

    func updateSettings(
        _ update: (inout SDEAutomationSettings) -> Void
    ) {
        var next = settings
        update(&next)
        next.normalize()
        settings = next
        saveSettings()
        restartSchedulerIfNeeded(runImmediately: true)
    }

    func saveContact() {
        contactStatusMessage = nil
        do {
            let normalized = ownerContact
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !normalized.isEmpty else {
                safeFailureCode = "NEN-SDE-008-CONTACT-EMPTY"
                contactStatusMessage =
                    "Gib zuerst eine Kontaktangabe ein."
                return
            }
            try dependencies.saveOwnerContact(normalized)
            ownerContact = normalized
            hasStoredOwnerContact = true
            let message =
                "Die Kontaktangabe wurde im macOS-Schlüsselbund gespeichert."
            statusMessage = message
            contactStatusMessage = message
            safeFailureCode = nil
        } catch {
            fail(error, fallback: "NEN-SDE-008-CONTACT")
            contactStatusMessage =
                "Die Kontaktangabe konnte nicht gespeichert werden. "
                + "Diagnosecode: NEN-SDE-008-CONTACT"
        }
    }

    func removeContact() {
        contactStatusMessage = nil
        do {
            try dependencies.saveOwnerContact("")
            ownerContact = ""
            hasStoredOwnerContact = false
            let message =
                "Die Kontaktangabe wurde aus dem Schlüsselbund entfernt."
            statusMessage = message
            contactStatusMessage = message
            safeFailureCode = nil
        } catch {
            fail(error, fallback: "NEN-SDE-008-CONTACT")
            contactStatusMessage =
                "Die Kontaktangabe konnte nicht entfernt werden. "
                + "Diagnosecode: NEN-SDE-008-CONTACT"
        }
    }

    func refresh() {
        guard operationTask == nil else {
            return
        }
        operationTask = Task { [weak self] in
            guard let self else {
                return
            }
            await self.refreshSnapshot()
            self.operationTask = nil
        }
    }

    func checkNow() {
        startOperation { model in
            await model.performCheck(force: true, applyAutomation: true)
        }
    }

    func installAvailableUpdate() {
        guard let build = report?.officialBuildNumber
                ?? state.lastKnownOfficialBuildNumber else {
            statusMessage = "Es ist keine geprüfte Buildnummer verfügbar."
            safeFailureCode = "NEN-SDE-008-NO-BUILD"
            return
        }
        startOperation { model in
            await model.performInstall(buildNumber: build)
        }
    }

    func cancelCurrentOperation() {
        operationTask?.cancel()
        phase = .cancelled
        statusMessage = "Der laufende Vorgang wird kontrolliert abgebrochen."
    }

    func prepareRetentionPreview() {
        startOperation { model in
            do {
                let preview = try await model.dependencies.retentionPreview(
                    model.settings.rollbackVersionsToKeep
                )
                model.retentionPreview = preview
                model.statusMessage = preview.deletionCandidates.isEmpty
                    ? "Es gibt keine löschbaren alten Katalogversionen."
                    : nil
            } catch {
                model.fail(error, fallback: "NEN-SDE-008-RETENTION")
            }
        }
    }

    func confirmRetentionDeletion() {
        guard let preview = retentionPreview,
              !preview.deletionCandidates.isEmpty else {
            return
        }
        startOperation { model in
            do {
                let confirmation = SDECatalogRetentionConfirmation(
                    confirmationID: preview.confirmationID,
                    confirmedBuildNumbers:
                        preview.deletionCandidates.map(\.buildNumber)
                )
                let result = try await model.dependencies.applyRetention(
                    preview,
                    confirmation
                )
                model.retentionPreview = nil
                model.statusMessage =
                    "Gelöscht: Build "
                    + result.deletedBuildNumbers
                        .map(String.init)
                        .joined(separator: ", ")
                await model.refreshSnapshot()
            } catch {
                model.fail(error, fallback: "NEN-SDE-008-RETENTION")
            }
        }
    }

    func cancelRetentionDeletion() {
        retentionPreview = nil
    }

    func prepareDiagnosticExport() {
        do {
            let export = SDEDiagnosticExporter.makeExport(
                logs: filteredLogs,
                generatedAt: dependencies.now()
            )
            let data = try SDEDiagnosticExporter.encoded(export)
            diagnosticExportData = data
            diagnosticExportPreview =
                String(data: data, encoding: .utf8) ?? ""
        } catch {
            fail(error, fallback: "NEN-SDE-008-EXPORT")
        }
    }

    func clearDiagnosticExport() {
        diagnosticExportData = nil
        diagnosticExportPreview = ""
    }

    func startAutomationIfNeeded() {
        guard !automationStarted else {
            return
        }
        automationStarted = true
        startOperation { model in
            guard await model.performRecovery() else {
                return
            }
            await model.refreshSnapshot()
            if model.settings.automaticCheckEnabled {
                await model.performCheck(
                    force: false,
                    applyAutomation: true
                )
            }
            model.restartSchedulerIfNeeded(runImmediately: false)
        }
    }

    private func restartSchedulerIfNeeded(runImmediately: Bool) {
        schedulerTask?.cancel()
        schedulerTask = nil
        guard automationStarted, settings.automaticCheckEnabled else {
            return
        }
        schedulerTask = Task { [weak self] in
            if runImmediately {
                await self?.runAutomaticCycle()
            }
            while !Task.isCancelled {
                guard let checkIntervalHours =
                        self?.settings.checkIntervalHours else {
                    return
                }
                let seconds = Double(
                    max(
                        SDEAutomationSettings.minimumCheckIntervalHours,
                        checkIntervalHours
                    )
                ) * 3_600
                do {
                    try await Task.sleep(for: .seconds(seconds))
                } catch {
                    return
                }
                await self?.runAutomaticCycle()
            }
        }
    }

    private func performRecovery() async -> Bool {
        do {
            let recoveredCount = try await dependencies.recover()
            if recoveredCount > 0 {
                statusMessage =
                    "\(NexusNumberFormat.quantity(recoveredCount)) unterbrochene SDE-Aktualisierung wurde sicher bereinigt."
            }
            return true
        } catch {
            fail(error, fallback: "NEN-SDE-008-RECOVERY")
            return false
        }
    }

    private func runAutomaticCycle() async {
        while operationTask != nil, !Task.isCancelled {
            do {
                try await Task.sleep(for: .milliseconds(25))
            } catch {
                return
            }
        }
        guard !Task.isCancelled else {
            return
        }
        operationTask = Task { [weak self] in
            guard let self else {
                return
            }
            await self.performCheck(force: false, applyAutomation: true)
            self.operationTask = nil
        }
        await operationTask?.value
    }

    private func startOperation(
        _ operation: @escaping @MainActor
            (SDEManagementViewModel) async -> Void
    ) {
        guard operationTask == nil else {
            statusMessage = "Ein SDE-Vorgang läuft bereits."
            safeFailureCode = "NEN-SDE-008-BUSY"
            return
        }
        operationTask = Task { [weak self] in
            guard let self else {
                return
            }
            await operation(self)
            self.operationTask = nil
        }
    }

    private func performCheck(
        force: Bool,
        applyAutomation: Bool
    ) async {
        phase = .checking
        statusMessage = nil
        safeFailureCode = nil
        do {
            let report = try await dependencies.check(force)
            self.report = report
            phase = Self.phase(for: report.status)
            safeFailureCode = report.safeFailureCode
            await refreshSnapshot()
            guard applyAutomation else {
                return
            }
            switch SDEAutomationPolicy.action(
                for: report,
                settings: settings,
                hasOwnerContact: dependencies.hasOwnerContact()
            ) {
            case .none:
                break
            case .prefetch(let build):
                await performPrefetch(buildNumber: build)
            case .install(let build):
                await performPrefetch(buildNumber: build)
                guard !Task.isCancelled else {
                    return
                }
                await performInstall(buildNumber: build)
            }
        } catch is CancellationError {
            phase = .cancelled
        } catch {
            fail(error, fallback: "NEN-SDE-008-CHECK")
        }
    }

    private func performPrefetch(buildNumber: Int) async {
        phase = .downloading
        do {
            prefetchedArchive = try await dependencies.prefetch(buildNumber)
            phase = .updateAvailable
            statusMessage =
                "Build \(buildNumber) wurde sicher vorbereitet."
        } catch is CancellationError {
            phase = .cancelled
        } catch {
            fail(error, fallback: "NEN-SDE-008-DOWNLOAD")
        }
    }

    private func performInstall(buildNumber: Int) async {
        guard settings.ownerComplianceReviewed else {
            phase = .failed
            safeFailureCode = "NEN-SDE-008-COMPLIANCE"
            statusMessage =
                "Bestätige zuerst deine persönliche Prüfung der CCP-Bedingungen."
            return
        }
        guard dependencies.hasOwnerContact() else {
            phase = .failed
            safeFailureCode = "NEN-SDE-008-CONTACT"
            statusMessage =
                "Speichere zuerst eine reale Kontaktangabe im Schlüsselbund."
            return
        }
        do {
            _ = try await dependencies.install(
                buildNumber,
                true
            ) { [weak self] installationPhase in
                Task { @MainActor [weak self] in
                    self?.phase = Self.phase(for: installationPhase)
                }
            }
            phase = .completed
            statusMessage = "Build \(buildNumber) wurde sicher aktiviert."
            await refreshSnapshot()
            if settings.proposeOldVersionDeletion {
                retentionPreview = try await dependencies.retentionPreview(
                    settings.rollbackVersionsToKeep
                )
            }
        } catch is CancellationError {
            phase = .cancelled
        } catch let error as SDEInstallationError {
            fail(error, fallback: error.safeCode)
        } catch {
            fail(error, fallback: "NEN-SDE-008-INSTALL")
        }
    }

    private func refreshSnapshot() async {
        do {
            state = try await dependencies.loadState()
            activeVersion = try await dependencies.activeVersion()
            logs = try await dependencies.readLogs()
            storeByteCount = try dependencies.storeByteCount()
            if let build = report?.officialBuildNumber
                ?? state.lastKnownOfficialBuildNumber {
                prefetchedArchive = try await dependencies.prefetched(build)
            }
        } catch {
            fail(error, fallback: "NEN-SDE-008-REFRESH")
        }
    }

    private func fail(_ error: any Error, fallback: String) {
        phase = .failed
        safeFailureCode = fallback
        statusMessage =
            "Der Vorgang wurde nicht abgeschlossen. Der lokale Datenstand bleibt aktiv."
    }

    private func saveSettings() {
        do {
            defaults.set(
                try JSONEncoder().encode(settings),
                forKey: SDEAppConfiguration.automationDefaultsKey
            )
        } catch {
            fail(error, fallback: "NEN-SDE-008-SETTINGS")
        }
    }

    private static func loadSettings(
        defaults: UserDefaults
    ) -> SDEAutomationSettings {
        guard let data = defaults.data(
            forKey: SDEAppConfiguration.automationDefaultsKey
        ), var settings = try? JSONDecoder().decode(
            SDEAutomationSettings.self,
            from: data
        ) else {
            return SDEAutomationSettings()
        }
        settings.normalize()
        return settings
    }

    private static func phase(
        for status: SDEUpdateCheckStatus
    ) -> SDEManagementPhase {
        switch status {
        case .current, .notModified:
            .current
        case .updateAvailable:
            .updateAvailable
        case .offline:
            .offline
        case .schemaReviewRequired:
            .schemaReviewRequired
        case .failed:
            .failed
        }
    }

    private static func phase(
        for installation: SDEInstallationPhase
    ) -> SDEManagementPhase {
        switch installation {
        case .started, .downloading:
            .downloading
        case .inspectingArchive:
            .inspectingArchive
        case .extractingArchive:
            .extractingArchive
        case .validatingSource:
            .validatingSource
        case .stagingPackage, .mappingCatalog, .validatingStagingStore:
            .importing
        case .creatingSafetyBackup, .promoting:
            .activating
        case .completed, .recovered:
            .completed
        case .failed:
            .failed
        case .cancelled:
            .cancelled
        }
    }
}
