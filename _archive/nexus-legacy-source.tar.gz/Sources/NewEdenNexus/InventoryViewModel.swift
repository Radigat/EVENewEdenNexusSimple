import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum InventoryViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case invalidQuantityText
}

@MainActor
final class InventoryViewModel: ObservableObject {
    @Published var scope: StorageLocationListScope = .active
    @Published var selectedLocationID: UUID?
    @Published var selectedStockID: UUID?
    @Published private(set) var locations: [StorageLocationSnapshot] = []
    @Published private(set) var stocks: [ManualStockSnapshot] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isMutating = false

    private let inventory: any InventoryManaging
    private let csvImporter: any InventoryCSVImporting
    private let csvFileReader: any InventoryCSVFileReading

    init(
        inventory: any InventoryManaging,
        csvImporter: any InventoryCSVImporting,
        csvFileReader: any InventoryCSVFileReading
    ) {
        self.inventory = inventory
        self.csvImporter = csvImporter
        self.csvFileReader = csvFileReader
    }

    var selectedLocation: StorageLocationSnapshot? {
        locations.first { $0.id == selectedLocationID }
    }

    var selectedStock: ManualStockSnapshot? {
        stocks.first { $0.id == selectedStockID }
    }

    var canEditLocation: Bool {
        selectedLocation.map { !$0.isArchived } ?? false
    }

    var canArchiveLocation: Bool {
        canEditLocation
    }

    var canRestoreLocation: Bool {
        selectedLocation?.isArchived == true
    }

    var canEditStock: Bool {
        selectedStock != nil && canEditLocation
    }

    func makeCSVImportViewModel() -> InventoryCSVImportViewModel {
        InventoryCSVImportViewModel(
            importer: csvImporter,
            fileReader: csvFileReader
        )
    }

    func load() async throws {
        isLoading = true
        defer { isLoading = false }
        let loaded = try await inventory.locations(scope: scope)
        try Task.checkCancellation()
        locations = loaded
        if !loaded.contains(where: { $0.id == selectedLocationID }) {
            selectedLocationID = loaded.first?.id
        }
        try await loadStocks()
    }

    func selectLocation(_ id: UUID?) async throws {
        selectedLocationID = id
        selectedStockID = nil
        try await loadStocks()
    }

    func createLocation(draft: StorageLocationDraft) async throws {
        try await mutate {
            try await inventory.createLocation(draft: draft)
        }
    }

    func updateLocation(
        id: UUID,
        draft: StorageLocationDraft
    ) async throws {
        try await mutate {
            try await inventory.updateLocation(id: id, draft: draft)
        }
    }

    func archiveSelectedLocation() async throws {
        guard let selectedLocationID else { return }
        try await mutate {
            try await inventory.archiveLocation(id: selectedLocationID)
        }
    }

    func restoreSelectedLocation() async throws {
        guard let selectedLocationID else { return }
        try await mutate {
            try await inventory.restoreLocation(id: selectedLocationID)
        }
    }

    func searchItems(query: String) async throws -> CatalogSearchPage {
        try await inventory.searchItems(query: query)
    }

    func saveStock(typeID: Int64, quantityText: String) async throws {
        guard let selectedLocationID,
              let quantity = Int64(quantityText),
              quantity > 0 else {
            throw InventoryViewModelError.invalidQuantityText
        }
        try await mutateStock {
            try await inventory.saveManualStock(
                draft: ManualStockDraft(
                    locationID: selectedLocationID,
                    typeID: typeID,
                    quantity: quantity
                )
            )
        }
    }

    func deleteSelectedStock() async throws {
        guard let selectedStockID else { return }
        try await mutateStock {
            try await inventory.deleteManualStock(id: selectedStockID)
            return nil
        }
    }

    private func loadStocks() async throws {
        guard let selectedLocationID else {
            stocks = []
            selectedStockID = nil
            return
        }
        let loaded = try await inventory.stocks(locationID: selectedLocationID)
        try Task.checkCancellation()
        stocks = loaded
        if !loaded.contains(where: { $0.id == selectedStockID }) {
            selectedStockID = nil
        }
    }

    private func mutate(
        _ action: () async throws -> StorageLocationSnapshot
    ) async throws {
        guard !isMutating else {
            throw InventoryViewModelError.operationAlreadyRunning
        }
        isMutating = true
        defer { isMutating = false }
        let result = try await action()
        let loaded = try await inventory.locations(scope: scope)
        locations = loaded
        selectedLocationID = loaded.contains { $0.id == result.id }
            ? result.id
            : loaded.first?.id
        selectedStockID = nil
        try await loadStocks()
    }

    private func mutateStock(
        _ action: () async throws -> ManualStockSnapshot?
    ) async throws {
        guard !isMutating else {
            throw InventoryViewModelError.operationAlreadyRunning
        }
        isMutating = true
        defer { isMutating = false }
        let result = try await action()
        try await loadStocks()
        selectedStockID = result?.id
    }
}
