import SwiftUI
import UniformTypeIdentifiers
import NewEdenNexusApplication

struct SDEDataManagementView: View {
    @ObservedObject var model: SDEManagementViewModel
    @State private var showLog = true
    @State private var showExportPreview = false
    @State private var showFileExporter = false
    @State private var showContactRemovalConfirmation = false
    @State private var exportDocument: SDEDiagnosticDocument?

    var body: some View {
        Form {
            statusSection
            actionsSection
            automationSection
            contactSection
            retentionSection
            logSection
        }
        .formStyle(.grouped)
        .navigationTitle("EVE-Daten und SDE")
        .onAppear {
            model.refresh()
        }
        .confirmationDialog(
            "Alte SDE-Versionen löschen?",
            isPresented: Binding(
                get: {
                    model.retentionPreview?.deletionCandidates.isEmpty
                        == false
                },
                set: { presented in
                    if !presented {
                        model.cancelRetentionDeletion()
                    }
                }
            ),
            titleVisibility: .visible
        ) {
            Button("Angezeigte Versionen löschen", role: .destructive) {
                model.confirmRetentionDeletion()
            }
            Button("Abbrechen", role: .cancel) {
                model.cancelRetentionDeletion()
            }
        } message: {
            Text(retentionConfirmationMessage)
        }
        .confirmationDialog(
            "Kontaktangabe aus dem Schlüsselbund entfernen?",
            isPresented: $showContactRemovalConfirmation,
            titleVisibility: .visible
        ) {
            Button("Kontakt entfernen", role: .destructive) {
                model.removeContact()
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "ESI- und SDE-Aufrufe, die einen User-Agent-Kontakt "
                    + "benötigen, bleiben anschließend gesperrt."
            )
        }
        .sheet(isPresented: $showExportPreview) {
            DiagnosticExportPreview(
                preview: model.diagnosticExportPreview,
                export: {
                    guard let data = model.diagnosticExportData else {
                        return
                    }
                    exportDocument = SDEDiagnosticDocument(data: data)
                    showExportPreview = false
                    showFileExporter = true
                },
                cancel: {
                    showExportPreview = false
                    model.clearDiagnosticExport()
                }
            )
        }
        .fileExporter(
            isPresented: $showFileExporter,
            document: exportDocument,
            contentType: .json,
            defaultFilename: "NewEdenNexus-SDE-Diagnose.json"
        ) { _ in
            exportDocument = nil
            model.clearDiagnosticExport()
        }
    }

    private var statusSection: some View {
        Section("Datenstatus") {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: statusSymbol)
                    .font(.title2)
                    .foregroundStyle(statusColor)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text(statusTitle)
                        .font(.headline)
                    Text(statusDescription)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if model.isBusy {
                    ProgressView()
                        .controlSize(.small)
                        .accessibilityLabel("SDE-Vorgang läuft")
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(
                "SDE-Datenstatus: \(statusTitle). \(statusDescription)"
            )
            .accessibilityValue(
                model.isBusy ? "Vorgang läuft" : "Kein Vorgang aktiv"
            )
            .accessibilityAddTraits(.updatesFrequently)
            LabeledContent(
                "Installierter Build",
                value: model.activeVersion?.buildNumber
                    .formatted() ?? "Keiner"
            )
            LabeledContent(
                "Verfügbarer Build",
                value: model.report?.officialBuildNumber?.formatted()
                    ?? model.state.lastKnownOfficialBuildNumber?.formatted()
                    ?? "Nicht geprüft"
            )
            LabeledContent(
                "Veröffentlichung",
                value: formatted(model.state.officialReleaseDate)
            )
            LabeledContent(
                "Letzte erfolgreiche Prüfung",
                value: formatted(model.state.lastSuccessfulCheckAt)
            )
            LabeledContent(
                "Letzter erfolgreicher Import",
                value: formatted(lastSuccessfulImport)
            )
            LabeledContent("Format", value: "JSON Lines")
            LabeledContent(
                "Lokaler Datenbankumfang",
                value: ByteCountFormatter.string(
                    fromByteCount: model.storeByteCount,
                    countStyle: .file
                )
            )
            Text(
                "Der Datenbankumfang umfasst die SQLite-Hauptdatei sowie vorhandene WAL- und SHM-Dateien. SDE-Downloadcache und Backups sind nicht enthalten."
            )
            .font(.caption)
            .foregroundStyle(.secondary)

            if let code = model.safeFailureCode {
                Label(
                    "Diagnosecode: \(code)",
                    systemImage: "exclamationmark.triangle"
                )
                .font(.caption.monospaced())
                .foregroundStyle(.orange)
            }
            if let message = model.statusMessage {
                Text(message)
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var actionsSection: some View {
        Section("Aktionen") {
            ViewThatFits(in: .horizontal) {
                HStack {
                    sdeActionButtons
                }
                VStack(alignment: .leading, spacing: 8) {
                    sdeActionButtons
                }
            }
            if model.prefetchedArchive != nil {
                Label(
                    "Das geprüfte Archiv ist lokal vorbereitet.",
                    systemImage: "arrow.down.circle.fill"
                )
                .foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder
    private var sdeActionButtons: some View {
        Button("Nach Update suchen") {
            model.checkNow()
        }
        .keyboardShortcut("r", modifiers: [.command, .shift])
        .accessibilityHint(
            "Prüft die offiziellen CCP-SDE-Metadaten unter Beachtung des Servercaches."
        )
        .disabled(model.isBusy)

        Button("Update installieren") {
            model.installAvailableUpdate()
        }
        .buttonStyle(.borderedProminent)
        .keyboardShortcut(.defaultAction)
        .disabled(!installationAllowed)
        .accessibilityHint(
            installationAllowed
                ? "Installiert den vollständig geprüften verfügbaren SDE-Build."
                : "Erfordert ein verfügbares Update, bestätigte Bedingungen und eine gespeicherte Kontaktangabe."
        )

        if model.isBusy {
            Button("Abbrechen", role: .cancel) {
                model.cancelCurrentOperation()
            }
            .keyboardShortcut(.cancelAction)
            .accessibilityHint(
                "Bricht den laufenden Vorgang kontrolliert ab; der aktive Datenstand bleibt erhalten."
            )
        }
    }

    private var automationSection: some View {
        Section("Automatisierung") {
            Toggle(
                "Automatisch nach Updates suchen",
                isOn: settingBinding(\.automaticCheckEnabled)
            )
            Toggle(
                "Neue Archive automatisch herunterladen",
                isOn: settingBinding(\.automaticDownloadEnabled)
            )
            Toggle(
                "Geprüfte Updates automatisch installieren",
                isOn: settingBinding(\.automaticInstallationEnabled)
            )
            .disabled(!model.settings.automaticDownloadEnabled)

            Picker(
                "Prüfintervall",
                selection: settingBinding(\.checkIntervalHours)
            ) {
                Text("24 Stunden").tag(24)
                Text("48 Stunden").tag(48)
                Text("72 Stunden").tag(72)
                Text("7 Tage").tag(168)
            }

            Toggle(
                "Persönliche Prüfung der aktuellen CCP-Bedingungen bestätigt",
                isOn: settingBinding(\.ownerComplianceReviewed)
            )
            Text(
                "Diese Bestätigung dokumentiert nur deine eigene Prüfung. New Eden Nexus akzeptiert keine Verträge in deinem Namen und behauptet keine rechtliche Freigabe."
            )
            .font(.caption)
            .foregroundStyle(.secondary)

            Text(
                "Eine WLAN-only-Option wird nicht angeboten, weil die Zielplattform die gewünschte Netzart für diesen Prozess nicht zuverlässig genug als Sicherheitsgrenze garantiert."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var contactSection: some View {
        Section("User-Agent-Kontakt") {
            ViewThatFits(in: .horizontal) {
                HStack {
                    contactControls
                }
                VStack(alignment: .leading, spacing: 8) {
                    contactControls
                }
            }
            if let message = model.contactStatusMessage {
                Label(
                    message,
                    systemImage: model.safeFailureCode == nil
                        ? "checkmark.circle.fill"
                        : "exclamationmark.triangle.fill"
                )
                .font(.callout)
                .foregroundStyle(
                    model.safeFailureCode == nil ? .green : .orange
                )
                .accessibilityAddTraits(.updatesFrequently)
            }
            Text(
                "Die Kontaktangabe wird ausschließlich für den von CCP empfohlenen User-Agent verwendet und im macOS-Schlüsselbund gespeichert. Sie erscheint nicht im Diagnoseexport."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var contactControls: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("Kontaktangabe eingeben")
                .font(.callout.weight(.semibold))
            TextField(
                "E-Mail, URL, Discord oder EVE-Charakter",
                text: $model.ownerContact
            )
            .textFieldStyle(.roundedBorder)
            .controlSize(.large)
            .frame(minWidth: 320)
            .accessibilityLabel("Kontaktangabe für CCP")
            Text("Zum Beispiel eine erreichbare E-Mail-Adresse.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .layoutPriority(1)
        Button("Im Schlüsselbund speichern") {
            model.saveContact()
        }
        .buttonStyle(.borderedProminent)
        .disabled(
            model.ownerContact
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .isEmpty
        )
        .accessibilityHint(
            "Speichert die Kontaktangabe geschützt im macOS-Schlüsselbund."
        )
        if model.hasStoredOwnerContact {
            Button("Kontakt entfernen", role: .destructive) {
                showContactRemovalConfirmation = true
            }
            .accessibilityHint(
                "Verlangt vor dem Entfernen eine eigene Bestätigung."
            )
        }
    }

    private var retentionSection: some View {
        Section("Rollback und Aufbewahrung") {
            Stepper(
                "Rollback-Versionen behalten: \(model.settings.rollbackVersionsToKeep)",
                value: settingBinding(\.rollbackVersionsToKeep),
                in: 1...5
            )
            Toggle(
                "Nach erfolgreichem Update Bereinigung vorschlagen",
                isOn: settingBinding(\.proposeOldVersionDeletion)
            )
            Button("Alte Versionen prüfen …", role: .destructive) {
                model.prepareRetentionPreview()
            }
            .disabled(model.isBusy)
            Text(
                "Die aktive und mindestens die letzte funktionierende Version werden immer geschützt. Vor jeder Löschung zeigt die App die betroffenen Buildnummern und verlangt eine eigene Bestätigung."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var logSection: some View {
        Section {
            DisclosureGroup("Updateprotokoll", isExpanded: $showLog) {
                ViewThatFits(in: .horizontal) {
                    HStack {
                        logFilterControls
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        logFilterControls
                    }
                }

                if model.filteredLogs.isEmpty {
                    ContentUnavailableView(
                        "Kein Updateprotokoll",
                        systemImage: "doc.text.magnifyingglass",
                        description: Text(
                            "Nach der ersten Installation erscheinen hier die bereinigten Phasen."
                        )
                    )
                    .frame(minHeight: 120)
                } else {
                    ForEach(model.filteredLogs, id: \.operationID) { log in
                        SDELogRow(log: log)
                    }
                }

                Button("Bereinigten Diagnoseexport vorbereiten …") {
                    model.prepareDiagnosticExport()
                    showExportPreview = true
                }
                .disabled(model.filteredLogs.isEmpty)
                .accessibilityHint(
                    "Zeigt vor dem Speichern eine Vorschau ohne Tokens, Kontakte oder lokale Pfade."
                )
            }
        }
    }

    @ViewBuilder
    private var logFilterControls: some View {
        TextField(
            "Build, Phase oder Diagnosecode filtern",
            text: $model.logSearchText
        )
        .accessibilityLabel("SDE-Updateprotokoll filtern")
        Picker(
            "Sortierung",
            selection: $model.newestLogsFirst
        ) {
            Text("Neueste zuerst").tag(true)
            Text("Älteste zuerst").tag(false)
        }
        .frame(maxWidth: 180)
    }

    private var installationAllowed: Bool {
        !model.isBusy
            && model.report?.status == .updateAvailable
            && model.settings.ownerComplianceReviewed
            && !model.ownerContact
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .isEmpty
    }

    private var lastSuccessfulImport: Date? {
        model.logs.first {
            $0.events.last?.phase == .completed
        }?
        .events.last?.occurredAt
    }

    private var retentionConfirmationMessage: String {
        guard let preview = model.retentionPreview else {
            return ""
        }
        let builds = preview.deletionCandidates
            .map { String($0.buildNumber) }
            .joined(separator: ", ")
        let retained = preview.retainedVersions
            .map { String($0.buildNumber) }
            .joined(separator: ", ")
        return "Löschen: \(builds). Geschützt und behalten: \(retained). Die gelöschten SDE-Versionen können später erneut von CCP geladen werden."
    }

    private var statusTitle: String {
        switch model.phase {
        case .idle: "Noch nicht geprüft"
        case .checking: "Prüfung läuft"
        case .updateAvailable: "Update verfügbar"
        case .current: "Aktuell"
        case .downloading: "Download läuft"
        case .inspectingArchive: "Archivprüfung läuft"
        case .extractingArchive: "Archiv wird sicher entpackt"
        case .validatingSource: "Quelldaten werden geprüft"
        case .importing: "Import läuft"
        case .activating: "Aktivierung läuft"
        case .completed: "Update abgeschlossen"
        case .offline: "Offline – lokale Daten werden verwendet"
        case .schemaReviewRequired:
            "Schemaänderung erkannt – Prüfung erforderlich"
        case .failed:
            "Update fehlgeschlagen – bisherige Version bleibt aktiv"
        case .cancelled: "Vorgang abgebrochen"
        }
    }

    private var statusDescription: String {
        switch model.phase {
        case .idle:
            "Der lokal aktive Datenstand bleibt unabhängig vom Netzwerk verfügbar."
        case .checking:
            "CCP-Build- und Schemametadaten werden cachekonform abgefragt."
        case .updateAvailable:
            "Ein neuer offizieller SDE-Build kann vorbereitet werden."
        case .current, .completed:
            "Der lokale Katalog ist vollständig nutzbar."
        case .offline:
            "Es wird keine bestehende Version deaktiviert oder gelöscht."
        case .schemaReviewRequired:
            "Die neue Version wird vor einer Parserprüfung nicht installiert."
        case .failed:
            "Prüfe den Diagnosecode und das Updateprotokoll."
        case .cancelled:
            "Temporäre Daten werden kontrolliert bereinigt."
        default:
            "Der aktive Datenstand bleibt bis zum erfolgreichen Abschluss unverändert."
        }
    }

    private var statusSymbol: String {
        switch model.phase {
        case .current, .completed: "checkmark.circle.fill"
        case .updateAvailable: "arrow.down.circle.fill"
        case .offline: "wifi.slash"
        case .failed, .schemaReviewRequired:
            "exclamationmark.triangle.fill"
        case .cancelled: "xmark.circle"
        case .idle: "questionmark.circle"
        default: "arrow.triangle.2.circlepath"
        }
    }

    private var statusColor: Color {
        switch model.phase {
        case .current, .completed: .green
        case .updateAvailable: NexusTheme.accent
        case .failed, .schemaReviewRequired: NexusTheme.warning
        case .offline, .cancelled: .secondary
        default: NexusTheme.accent
        }
    }

    private func settingBinding<Value>(
        _ keyPath: WritableKeyPath<SDEAutomationSettings, Value>
    ) -> Binding<Value> {
        Binding(
            get: { model.settings[keyPath: keyPath] },
            set: { value in
                model.updateSettings {
                    $0[keyPath: keyPath] = value
                }
            }
        )
    }

    private func formatted(_ date: Date?) -> String {
        date?.formatted(date: .abbreviated, time: .shortened)
            ?? "Nicht verfügbar"
    }
}

private struct SDELogRow: View {
    let log: SDEInstallationLog

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text("Build \(log.requestedBuildNumber)")
                    .font(.headline)
                Spacer()
                Text(log.events.last?.phase.rawValue ?? "unbekannt")
                    .font(.caption.monospaced())
            }
            Text(
                log.events.first?.occurredAt.formatted(
                    date: .abbreviated,
                    time: .standard
                ) ?? "Zeit unbekannt"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            if let code = log.events.last?.safeCode {
                Text("Diagnosecode: \(code)")
                    .font(.caption.monospaced())
                    .foregroundStyle(.orange)
            }
            if let counts = log.counts {
                Text(
                    "\(NexusNumberFormat.quantity(counts.itemTypes)) Typen · "
                        + "\(NexusNumberFormat.quantity(counts.blueprints)) Blueprints · "
                        + "\(NexusNumberFormat.quantity(counts.materials)) Materialien"
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 5)
        .accessibilityElement(children: .combine)
    }
}

private struct DiagnosticExportPreview: View {
    let preview: String
    let export: () -> Void
    let cancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Vorschau des Diagnoseexports")
                .font(.title2.bold())
            Text(
                "Der Export enthält ausschließlich SDE-Builds, technische Phasen, Mengen und sichere Diagnosecodes."
            )
            .foregroundStyle(.secondary)
            TextEditor(text: .constant(preview))
                .font(.system(.caption, design: .monospaced))
                .frame(minWidth: 520, minHeight: 360)
                .accessibilityLabel("Bereinigte Exportvorschau")
            HStack {
                Spacer()
                Button("Abbrechen", action: cancel)
                    .keyboardShortcut(.cancelAction)
                Button("Datei auswählen …", action: export)
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)
            }
        }
        .padding(24)
    }
}

private struct SDEDiagnosticDocument: FileDocument {
    static var readableContentTypes: [UTType] {
        [.json]
    }

    let data: Data

    init(data: Data) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(
        configuration: WriteConfiguration
    ) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}
