import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct WalletEvidenceAssignmentView: View {
    private struct TransactionOption: Identifiable {
        let transaction: ESIWalletTransaction
        let remainingQuantity: Int64

        var id: Int64 { transaction.id }
    }

    private struct JournalOption: Identifiable {
        let entry: ESIWalletJournalEntry
        let remainingAmountHundredths: Int64

        var id: Int64 { entry.id }
    }

    let account: EVECharacterAccount
    let snapshot: ESIWalletSnapshot
    @ObservedObject var model: AccountsViewModel

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var runtime: NexusAppRuntime
    @State private var projectID: UUID?
    @State private var sourceKind =
        WalletAssignmentSourceKind.transaction
    @State private var transactionID: Int64?
    @State private var journalID: Int64?
    @State private var quantity = "1"
    @State private var amount = ""
    @State private var validationMessage: String?

    private var assignableJournal: [ESIWalletJournalEntry] {
        snapshot.journal.filter(snapshot.isVerifiablyAssignable)
    }

    private var transactionOptions: [TransactionOption] {
        snapshot.transactions.compactMap { transaction in
            guard case let .available(remainingQuantity, _) =
                WalletAssignmentSourceCapacityCalculator.transaction(
                    transaction,
                    characterID: account.characterID,
                    assignments: assignments
                ) else {
                return nil
            }
            return TransactionOption(
                transaction: transaction,
                remainingQuantity: remainingQuantity
            )
        }
    }

    private var journalOptions: [JournalOption] {
        assignableJournal.compactMap { entry in
            guard case let .available(_, remainingAmount) =
                WalletAssignmentSourceCapacityCalculator.journal(
                    entry,
                    characterID: account.characterID,
                    assignments: assignments
                ) else {
                return nil
            }
            return JournalOption(
                entry: entry,
                remainingAmountHundredths: remainingAmount
            )
        }
    }

    private var projects: [ProductionProjectSnapshot] {
        model.projects
    }

    private var selectedProject: ProductionProjectSnapshot? {
        guard let projectID else { return nil }
        return projects.first { $0.id == projectID }
    }

    private var assignments: [WalletProjectAssignmentSnapshot] {
        model.walletAssignments.filter {
            $0.characterID == account.characterID
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Lokaler Wallet-Snapshot") {
                    LabeledContent(
                        "Kontostand",
                        value: isk(snapshot.balanceHundredths)
                    )
                    LabeledContent(
                        "Stand",
                        value: snapshot.synchronizedAt.formatted(
                            date: .abbreviated,
                            time: .shortened
                        )
                    )
                    LabeledContent(
                        "Datensätze",
                        value: "\(NexusNumberFormat.quantity(snapshot.transactions.count)) Transaktionen · "
                            + "\(NexusNumberFormat.quantity(snapshot.journal.count)) Journaleinträge"
                    )
                }

                Section("Projektzuordnung") {
                    if projects.isEmpty {
                        ContentUnavailableView(
                            "Kein aktives Projekt",
                            systemImage: "folder.badge.questionmark",
                            description: Text(
                                "Lege zuerst ein Produktionsprojekt an."
                            )
                        )
                    } else {
                        Picker("Projekt", selection: $projectID) {
                            Text("Auswählen").tag(UUID?.none)
                            ForEach(projects) { project in
                                Text(
                                    project.name
                                        + (
                                            project.status == .archived
                                                ? " · archiviert"
                                                : ""
                                        )
                                )
                                    .tag(Optional(project.id))
                            }
                        }
                        if selectedProject?.status == .archived {
                            Label(
                                "Archivierte Projekte sind für neue "
                                    + "Zuordnungen schreibgeschützt.",
                                systemImage: "archivebox"
                            )
                            .foregroundStyle(.secondary)
                        } else {
                            Picker("Quelle", selection: $sourceKind) {
                                Text("Transaktion")
                                    .tag(
                                        WalletAssignmentSourceKind.transaction
                                    )
                                Text("Gebühr / Job")
                                    .tag(
                                        WalletAssignmentSourceKind.journal
                                    )
                            }
                            .pickerStyle(.segmented)

                            if sourceKind == .transaction {
                                transactionEditor
                            } else {
                                journalEditor
                            }
                            if let validationMessage {
                                Label(
                                    validationMessage,
                                    systemImage:
                                        "exclamationmark.triangle"
                                )
                                .foregroundStyle(.red)
                                .font(.caption)
                            }
                        }
                    }
                }

                Section("Bereits bestätigt") {
                    if assignments.isEmpty {
                        Text("Noch keine Wallet-Buchung zugeordnet.")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(assignments) { assignment in
                            HStack {
                                Text(
                                    assignment.sourceKind == .transaction
                                        ? "Transaktion \(assignment.sourceID)"
                                        : "Journal \(assignment.sourceID)"
                                )
                                Spacer()
                                Text(isk(
                                    assignment.assignedAmountHundredths
                                ))
                            }
                        }
                    }
                }

            }
            .navigationTitle("Wallet-Nachweise · \(account.name)")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
            }
            .onAppear {
                projectID = projectID ?? projects.first?.id
                synchronizeSourceSelections()
            }
            .onChange(of: assignments) {
                synchronizeSourceSelections()
            }
        }
        .frame(minWidth: 650, minHeight: 560)
        .sheet(
            isPresented: Binding(
                get: { model.walletAssignmentPreview != nil },
                set: { isPresented in
                    if !isPresented {
                        Task {
                            await model
                                .discardWalletAssignmentPreview()
                        }
                    }
                }
            )
        ) {
            if let preview = model.walletAssignmentPreview {
                WalletAssignmentPreviewView(
                    preview: preview,
                    projectName: projects.first {
                        $0.id == preview.assignment.projectID
                    }?.name ?? "Unbekanntes Projekt",
                    apply: {
                        Task {
                            do {
                                try await model
                                    .applyWalletAssignmentPreview()
                            } catch {
                                runtime.report(
                                    error,
                                    operation: .walletAssignmentSave
                                )
                            }
                        }
                    },
                    cancel: {
                        Task {
                            await model
                                .discardWalletAssignmentPreview()
                        }
                    }
                )
            }
        }
    }

    @ViewBuilder
    private var transactionEditor: some View {
        if snapshot.transactions.isEmpty {
            Text("Keine Transaktionen im Snapshot.")
                .foregroundStyle(.secondary)
        } else if transactionOptions.isEmpty {
            Text(
                "Keine Transaktion mit noch zuordenbarer Menge vorhanden."
            )
            .foregroundStyle(.secondary)
        } else {
            Picker("Transaktion", selection: $transactionID) {
                Text("Auswählen").tag(Int64?.none)
                ForEach(transactionOptions) { option in
                    Text(transactionLabel(option))
                        .tag(Optional(option.id))
                }
            }
            TextField("Zuzuordnende Menge", text: $quantity)
            Button("Zuordnung prüfen") {
                requestTransactionPreview()
            }
            .disabled(projectID == nil || transactionID == nil)
        }
    }

    @ViewBuilder
    private var journalEditor: some View {
        if assignableJournal.isEmpty {
            Text(
                "Keine eindeutig zuordenbare Gebühr oder Jobbuchung vorhanden."
            )
            .foregroundStyle(.secondary)
        } else if journalOptions.isEmpty {
            Text(
                "Keine Gebühr oder Jobbuchung mit zuordenbarem Restbetrag "
                    + "vorhanden."
            )
            .foregroundStyle(.secondary)
        } else {
            Picker("Journalbuchung", selection: $journalID) {
                Text("Auswählen").tag(Int64?.none)
                ForEach(journalOptions) { option in
                    Text(
                        "\(option.entry.refType) · noch "
                            + isk(option.remainingAmountHundredths)
                    )
                    .tag(Optional(option.id))
                }
            }
            TextField("Zuzuordnender Betrag in ISK", text: $amount)
            Button("Zuordnung prüfen", action: requestJournalPreview)
            .disabled(projectID == nil || journalID == nil)
        }
    }

    private func requestTransactionPreview() {
        guard let projectID, let transactionID,
              let parsedQuantity = Int64(quantity),
              parsedQuantity > 0 else {
            validationMessage =
                "Wähle ein Projekt und gib eine positive ganze Menge ein."
            return
        }
        guard let option = transactionOptions.first(where: {
            $0.id == transactionID
        }), parsedQuantity <= option.remainingQuantity else {
            validationMessage =
                "Die Menge überschreitet den noch zuordenbaren Anteil."
            synchronizeSourceSelections()
            return
        }
        validationMessage = nil
        Task {
            do {
                try await model.previewTransactionAssignment(
                    projectID: projectID,
                    characterID: account.characterID,
                    transactionID: transactionID,
                    quantity: parsedQuantity
                )
            } catch {
                handlePreviewError(error)
            }
        }
    }

    private func requestJournalPreview() {
        let normalized = amount.replacingOccurrences(of: ",", with: ".")
        guard let projectID, let journalID,
              let decimal = Decimal(
                string: normalized,
                locale: Locale(identifier: "en_US_POSIX")
              ) else {
            validationMessage =
                "Wähle ein Projekt und gib einen positiven ISK-Betrag ein."
            return
        }
        let hundredths: Int64
        do {
            hundredths = try WalletMoneyNormalizer.hundredths(
                from: decimal,
                allowsNegative: false
            )
        } catch {
            validationMessage =
                "Wähle ein Projekt und gib einen positiven ISK-Betrag ein."
            return
        }
        guard hundredths > 0 else {
            validationMessage =
                "Wähle ein Projekt und gib einen positiven ISK-Betrag ein."
            return
        }
        guard let option = journalOptions.first(where: {
            $0.id == journalID
        }), hundredths <= option.remainingAmountHundredths else {
            validationMessage =
                "Der Betrag überschreitet den noch zuordenbaren Anteil."
            synchronizeSourceSelections()
            return
        }
        validationMessage = nil
        Task {
            do {
                try await model.previewJournalAssignment(
                    projectID: projectID,
                    characterID: account.characterID,
                    journalID: journalID,
                    amountHundredths: hundredths
                )
            } catch {
                handlePreviewError(error)
            }
        }
    }

    private func transactionLabel(
        _ option: TransactionOption
    ) -> String {
        let transaction = option.transaction
        let direction = transaction.isBuy ? "Kauf" : "Verkauf"
        return "\(direction) · Typ \(transaction.typeID) · "
            + "\(NexusNumberFormat.quantity(transaction.quantity)) × "
            + isk(transaction.unitPriceHundredths)
            + " · noch \(NexusNumberFormat.quantity(option.remainingQuantity))"
    }

    private func synchronizeSourceSelections() {
        if !transactionOptions.contains(where: {
            $0.id == transactionID
        }) {
            transactionID = transactionOptions.first?.id
        }
        if !journalOptions.contains(where: {
            $0.id == journalID
        }) {
            journalID = journalOptions.first?.id
        }
    }

    private func handlePreviewError(_ error: Error) {
        if error as? WalletFinanceError == .allocationExceeded {
            validationMessage =
                "Diese Quelle ist bereits vollständig zugeordnet oder "
                    + "der eingegebene Anteil überschreitet den Rest."
            synchronizeSourceSelections()
            return
        }
        if let serviceError =
            error as? WalletAssignmentServiceError {
            switch serviceError {
            case .sourceNotFound, .sourceNotAssignable:
                validationMessage =
                    "Die gewählte Quelle ist nicht mehr verfügbar. "
                        + "Wähle eine andere Quelle oder aktualisiere "
                        + "den Wallet-Snapshot."
                synchronizeSourceSelections()
                return
            case .confirmationRequired, .stalePreview,
                 .previewNotFound, .persistenceFailure:
                break
            }
        }
        runtime.report(
            error,
            operation: .walletAssignmentSave
        )
    }

    private func isk(_ hundredths: Int64) -> String {
        NexusNumberFormat.isk(hundredths: hundredths)
    }
}

struct ESIWalletPreviewView: View {
    let preview: ESIWalletPreview
    let isApplying: Bool
    let apply: () -> Void
    let cancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Wallet-Änderungen prüfen")
                .font(.title2.bold())
            Text(
                "Die Daten werden erst nach deiner Bestätigung lokal ersetzt."
            )
            Grid(alignment: .leading, horizontalSpacing: 24) {
                GridRow {
                    Text("Kontostand vorher")
                    Text(
                        preview.balanceBeforeHundredths.map(isk)
                            ?? "Kein lokaler Stand"
                    )
                }
                GridRow {
                    Text("Kontostand neu")
                    Text(isk(preview.balanceAfterHundredths))
                }
                GridRow {
                    Text("Journal")
                    Text(
                        "+\(NexusNumberFormat.quantity(preview.addedJournalCount)) / "
                            + "−\(NexusNumberFormat.quantity(preview.removedJournalCount))"
                    )
                }
                GridRow {
                    Text("Transaktionen")
                    Text(
                        "+\(NexusNumberFormat.quantity(preview.addedTransactionCount)) / "
                            + "−\(NexusNumberFormat.quantity(preview.removedTransactionCount))"
                    )
                }
            }
            HStack {
                Spacer()
                Button("Verwerfen", role: .cancel, action: cancel)
                Button("Wallet-Snapshot übernehmen", action: apply)
                    .buttonStyle(.borderedProminent)
                    .disabled(isApplying)
            }
        }
        .padding(24)
        .frame(minWidth: 520)
    }

    private func isk(_ hundredths: Int64) -> String {
        NexusNumberFormat.isk(hundredths: hundredths)
    }
}

struct WalletAssignmentPreviewView: View {
    let preview: WalletAssignmentPreview
    let projectName: String
    let apply: () -> Void
    let cancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Projektzuordnung bestätigen")
                .font(.title2.bold())
            Text(
                "Die Zuordnung erfolgt nicht automatisch und verändert "
                    + "weder den Wallet-Snapshot noch die Planwerte."
            )
            LabeledContent("Projekt", value: projectName)
            LabeledContent(
                "Quelle",
                value: "\(preview.assignment.sourceKind.rawValue) "
                    + "\(preview.assignment.sourceID)"
            )
            LabeledContent(
                "Betrag",
                value: isk(preview.assignment.assignedAmountHundredths)
            )
            if preview.assignment.assignedQuantity > 0 {
                LabeledContent(
                    "Menge",
                    value: NexusNumberFormat.quantity(
                        preview.assignment.assignedQuantity
                    )
                )
            }
            if !preview.existingAssignments.isEmpty {
                Text(
                    "Für diese Quelle bestehen bereits "
                        + "\(NexusNumberFormat.quantity(preview.existingAssignments.count)) "
                        + "bestätigte Zuordnungen."
                )
                .foregroundStyle(.orange)
            }
            HStack {
                Spacer()
                Button("Abbrechen", role: .cancel, action: cancel)
                Button("Verbindlich zuordnen", action: apply)
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(24)
        .frame(minWidth: 520)
    }

    private func isk(_ hundredths: Int64) -> String {
        NexusNumberFormat.isk(hundredths: hundredths)
    }
}
