import Foundation

enum NexusModule: String, CaseIterable, Identifiable {
    case dashboard = "Dashboard"
    case accounts = "Accounts"
    case projects = "Projekte"
    case productionLedger = "Produktionsbuch"
    case assets = "Assets"
    case blueprints = "Blueprints"
    case purchasing = "Einkaufsliste"
    case prices = "Preise"
    case synchronization = "Synchronisation"
    case sdeData = "EVE-Daten"
    case roadmap = "Roadmap"

    var id: String { rawValue }

    var searchTerms: [String] {
        switch self {
        case .dashboard:
            ["Dashboard", "Übersicht", "Start"]
        case .accounts:
            ["Accounts", "Konten", "Charaktere", "SSO"]
        case .projects:
            ["Projekte", "Produktion", "Invention", "Industrie"]
        case .productionLedger:
            ["Produktionsbuch", "Chargen", "Produktion", "Historie"]
        case .assets:
            ["Assets", "Lager", "Bestände", "Materialien"]
        case .blueprints:
            ["Blueprints", "Baupläne", "Rezepte"]
        case .purchasing:
            ["Einkaufsliste", "Einkauf", "Beschaffung", "Fehlmengen"]
        case .prices:
            ["Preise", "Kosten", "Gewinn", "ROI"]
        case .synchronization:
            ["Synchronisation", "ESI", "Abgleich"]
        case .sdeData:
            ["EVE-Daten", "SDE", "statische Daten", "Update"]
        case .roadmap:
            ["Roadmap", "Planung", "Zukunft"]
        }
    }

    func matches(searchText: String) -> Bool {
        let query = Self.normalized(searchText)
        guard !query.isEmpty else {
            return true
        }
        return searchTerms.contains {
            Self.normalized($0).contains(query)
        }
    }

    var symbol: String {
        switch self {
        case .dashboard: "rectangle.3.group"
        case .accounts: "person.2"
        case .projects: "shippingbox"
        case .productionLedger: "list.number"
        case .assets: "archivebox"
        case .blueprints: "doc.text.magnifyingglass"
        case .purchasing: "cart"
        case .prices: "tag"
        case .synchronization: "arrow.triangle.2.circlepath"
        case .sdeData: "externaldrive.badge.icloud"
        case .roadmap: "map"
        }
    }

    private static func normalized(_ value: String) -> String {
        value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(
                options: [.caseInsensitive, .diacriticInsensitive],
                locale: Locale(identifier: "de_DE")
            )
    }
}
