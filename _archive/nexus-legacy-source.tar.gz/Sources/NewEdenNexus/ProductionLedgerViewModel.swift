import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

struct ProductionLedgerJobOption: Identifiable, Sendable {
    let characterName: String
    let job: ESICharacterIndustryJob

    var id: Int64 { job.jobID }

    var label: String {
        "\(characterName) · Job \(job.jobID)"
    }
}

enum ProductionSaleSourceChoice: String, CaseIterable, Sendable {
    case walletTransaction
    case walletJournal
    case manualSale
    case manualFee
}

@MainActor
final class ProductionLedgerViewModel: ObservableObject {
    struct FormState: Equatable {
        var projectID: UUID?
        var productionDate = Date()
        var status: ProductionBatchStatus = .produced
        var runs = "1"
        var materialEfficiency = "0"
        var timeEfficiency = "0"
        var outputUnits = "1"
        var characterID = ""
        var characterName = ""
        var blueprintInstanceID = ""
        var esiIndustryJobID = ""
        var solarSystemID = ""
        var solarSystemName = ""
        var locationID = ""
        var locationName = ""
        var facilityID = ""
        var facilityName = ""
    }

    struct CostFormState: Equatable {
        var priceProfileID: UUID?
        var alternativeRegionID: Int64?
        var alternativeLocationID: Int64?
        var selectedSaleQuote: ProductionBatchSaleQuoteSelection = .jita
        var allowManualPriceSetFallback = false
        var facilityAndTaxCost = ""
        var blueprintAndInventionCost = ""
        var marketFees = ""
        var manualOtherCost = "0"
    }

    struct SaleFormState: Equatable {
        var source: ProductionSaleSourceChoice = .walletTransaction
        var transactionAssignmentID: UUID?
        var journalAssignmentID: UUID?
        var quantity = "1"
        var amount = ""
        var date = Date()
        var reason = ""
    }

    @Published private(set) var projects: [ProductionProjectSnapshot] = []
    @Published private(set) var batches: [ProductionBatchSnapshot] = []
    @Published private(set) var jobs: [ProductionLedgerJobOption] = []
    @Published var selectedBatchID: UUID?
    @Published var selectedJobID: Int64?
    @Published var form = FormState()
    @Published private(set) var preview: ProductionBatchPreview?
    @Published private(set) var isWorking = false
    @Published var yearFilter: Int?
    @Published var statusFilter: ProductionBatchStatus?
    @Published var projectFilter: UUID?
    @Published var characterFilter: Int64?
    @Published var productFilter = ""
    @Published var locationFilter = ""
    @Published private(set) var errorMessage: String?
    @Published private(set) var successMessage: String?
    @Published private(set) var priceProfiles: [PriceProfileSnapshot] = []
    @Published private(set) var marketRegions: [MarketRegionOption] = []
    @Published private(set) var marketLocations: [MarketLocationOption] = []
    @Published var costForm = CostFormState()
    @Published private(set) var costPreview: ProductionBatchCostPreview?
    @Published private(set) var costSnapshots: [ProductionBatchCostSnapshot] = []
    @Published var saleForm = SaleFormState()
    @Published private(set) var saleWorkspace:
        ProductionBatchSaleWorkspace?
    @Published private(set) var salePreview:
        ProductionBatchSalePreview?

    private let service: any ProductionBatchManaging
    private let costService: (any ProductionBatchCostManaging)?
    private let saleService: (any ProductionBatchSaleManaging)?
    private let marketDirectory: (any MarketLocationDirectoryLoading)?
    private let jobLoader: @Sendable () async throws -> [ProductionLedgerJobOption]

    init(
        service: any ProductionBatchManaging,
        costService: (any ProductionBatchCostManaging)? = nil,
        saleService: (any ProductionBatchSaleManaging)? = nil,
        marketDirectory:
            (any MarketLocationDirectoryLoading)? = nil,
        jobLoader:
            @escaping @Sendable () async throws
            -> [ProductionLedgerJobOption] = { [] }
    ) {
        self.service = service
        self.costService = costService
        self.saleService = saleService
        self.marketDirectory = marketDirectory
        self.jobLoader = jobLoader
    }

    var selectedBatch: ProductionBatchSnapshot? {
        batches.first { $0.id == selectedBatchID }
    }

    var latestCostSnapshot: ProductionBatchCostSnapshot? {
        costSnapshots.first
    }

    var alternativeLocations: [MarketLocationOption] {
        guard let regionID = costForm.alternativeRegionID else {
            return []
        }
        return marketLocations.filter {
            $0.regionID == regionID
                && $0.kind != .accessibleStructure
        }
    }

    var availableYears: [Int] {
        Array(Set(batches.map(\.calendarYear))).sorted(by: >)
    }

    var availableCharacters: [(id: Int64, name: String)] {
        let values = batches.compactMap { batch in
            batch.characterID.map {
                (
                    id: $0,
                    name: batch.characterName
                        ?? "Name nicht aufgelöst"
                )
            }
        }
        return Dictionary(
            values.map { ($0.id, $0.name) },
            uniquingKeysWith: { first, _ in first }
        )
        .map { (id: $0.key, name: $0.value) }
        .sorted {
            if $0.name != $1.name {
                return $0.name.localizedStandardCompare($1.name)
                    == .orderedAscending
            }
            return $0.id < $1.id
        }
    }

    var selectedJob: ProductionLedgerJobOption? {
        jobs.first { $0.id == selectedJobID }
    }

    var canCreatePreview: Bool {
        form.projectID != nil
            && parsePositive(form.runs) != nil
            && parsePositive(form.outputUnits) != nil
            && parseRange(form.materialEfficiency, range: 0...10)
                != nil
            && parseRange(form.timeEfficiency, range: 0...20)
                != nil
    }

    func load() async {
        await perform {
            async let projects = service.projects()
            async let jobs = jobLoader()
            self.projects = try await projects
            self.jobs = try await jobs.sorted {
                if $0.characterName != $1.characterName {
                    return $0.characterName < $1.characterName
                }
                return $0.job.endDate > $1.job.endDate
            }
            if form.projectID == nil {
                form.projectID = self.projects.first?.id
                applyProjectDefaults()
            }
            try await reloadBatches()
            try await loadCostSupport()
        }
    }

    func reloadForFilters() async {
        await perform {
            try await reloadBatches()
        }
    }

    func selectBatch(_ id: UUID?) async {
        selectedBatchID = id
        costPreview = nil
        salePreview = nil
        await perform {
            try await reloadCostSnapshots()
            try await reloadSaleWorkspace()
        }
    }

    func prepareCostEditor() async {
        await perform {
            try await loadCostSupport()
            try await reloadCostSnapshots()
        }
    }

    func selectAlternativeRegion(_ id: Int64?) {
        costForm.alternativeRegionID = id
        if !alternativeLocations.contains(where: {
            $0.locationID == costForm.alternativeLocationID
        }) {
            costForm.alternativeLocationID = nil
        }
        costPreview = nil
    }

    func selectAlternativeLocation(_ id: Int64?) {
        costForm.alternativeLocationID = id
        if let location = marketLocations.first(where: {
            $0.locationID == id
        }) {
            costForm.alternativeRegionID = location.regionID
        }
        costPreview = nil
    }

    func createCostPreview() async {
        guard let draft = costDraft() else {
            errorMessage =
                "Wähle eine Charge und prüfe alle eingegebenen ISK-Beträge."
            return
        }
        await perform {
            guard let costService else { return }
            costPreview = try await costService.preview(draft)
            successMessage = nil
        }
    }

    func discardCostPreview() {
        costPreview = nil
        successMessage =
            "Kostenvorschau verworfen. Es wurde nichts gespeichert."
    }

    func applyCostPreview() async {
        guard let costPreview, let costService else { return }
        await perform {
            let stored = try await costService.apply(
                costPreview,
                confirmed: true
            )
            self.costPreview = nil
            try await reloadCostSnapshots()
            successMessage =
                "Kostenbasis vom \(stored.createdAt.formatted(date: .abbreviated, time: .shortened)) wurde gespeichert."
        }
    }

    func prepareSaleEditor() async {
        await perform {
            try await reloadSaleWorkspace()
        }
    }

    func selectSaleSource(_ source: ProductionSaleSourceChoice) {
        saleForm.source = source
        salePreview = nil
        switch source {
        case .walletTransaction:
            saleForm.transactionAssignmentID =
                saleWorkspace?.transactions.first?.id
        case .walletJournal:
            saleForm.journalAssignmentID =
                saleWorkspace?.journals.first?.id
        case .manualSale, .manualFee:
            break
        }
    }

    func createSalePreview() async {
        guard let draft = saleDraft() else {
            errorMessage =
                "Wähle einen Nachweis und prüfe Menge, ISK-Betrag, Datum sowie die Begründung."
            return
        }
        await perform {
            guard let saleService else { return }
            salePreview = try await saleService.preview(draft)
            successMessage = nil
        }
    }

    func discardSalePreview() async {
        if let id = salePreview?.id {
            await saleService?.discard(previewID: id)
        }
        salePreview = nil
        successMessage =
            "Verkaufsvorschau verworfen. Es wurde nichts gespeichert."
    }

    func applySalePreview() async {
        guard let preview = salePreview, let saleService else {
            return
        }
        await perform {
            _ = try await saleService.apply(
                previewID: preview.id,
                confirmed: true
            )
            salePreview = nil
            try await reloadSaleWorkspace()
            successMessage =
                "Verkaufs- oder Gebührenzuordnung wurde gespeichert."
        }
    }

    func selectProject(_ id: UUID?) {
        form.projectID = id
        selectedJobID = nil
        preview = nil
        applyProjectDefaults()
    }

    func preloadSelectedJob() async {
        guard let projectID = form.projectID,
            let job = selectedJob?.job
        else {
            return
        }
        await perform {
            let loaded = try await service.preview(
                projectID: projectID,
                industryJob: job
            )
            copyRequestToForm(loaded.request)
            preview = nil
            successMessage =
                "ESI-Job wurde als bearbeitbare Grundlage übernommen."
        }
    }

    func createPreview() async {
        guard let draft = draft() else {
            errorMessage =
                "Prüfe Runs, ME, TE, Ausgabemenge und Projektauswahl."
            return
        }
        await perform {
            preview = try await service.preview(draft)
            successMessage = nil
        }
    }

    func discardPreview() {
        preview = nil
        successMessage = "Vorschau verworfen. Es wurde nichts gespeichert."
    }

    func applyPreview() async {
        guard let preview else {
            return
        }
        await perform {
            let stored = try await service.apply(
                preview,
                confirmed: true
            )
            self.preview = nil
            successMessage =
                "Charge \(stored.displayNumber) wurde gespeichert."
            selectedBatchID = stored.id
            try await reloadBatches()
        }
    }

    func clearMessages() {
        errorMessage = nil
        successMessage = nil
    }

    private func reloadBatches() async throws {
        batches = try await service.batches(
            filter: ProductionBatchFilter(
                calendarYear: yearFilter,
                productQuery: productFilter,
                projectID: projectFilter,
                characterID: characterFilter,
                locationQuery: locationFilter,
                status: statusFilter
            )
        )
        if !batches.contains(where: { $0.id == selectedBatchID }) {
            selectedBatchID = batches.first?.id
        }
        try await reloadCostSnapshots()
        try await reloadSaleWorkspace()
    }

    private func loadCostSupport() async throws {
        guard let costService else { return }
        priceProfiles = try await costService.priceProfiles()
        if costForm.priceProfileID == nil {
            costForm.priceProfileID =
                priceProfiles.first(where: \.isActive)?.id
                ?? priceProfiles.first?.id
        }
        guard marketRegions.isEmpty, let marketDirectory else {
            return
        }
        let directory = try await marketDirectory.load()
        marketRegions = directory.regions
        marketLocations = directory.locations
        if costForm.alternativeRegionID == nil {
            costForm.alternativeRegionID =
                marketRegions.first?.regionID
        }
    }

    private func reloadCostSnapshots() async throws {
        guard let selectedBatchID, let costService else {
            costSnapshots = []
            return
        }
        costSnapshots = try await costService.snapshots(
            batchID: selectedBatchID
        )
    }

    private func reloadSaleWorkspace() async throws {
        guard let selectedBatchID, let saleService else {
            saleWorkspace = nil
            return
        }
        let workspace = try await saleService.workspace(
            batchID: selectedBatchID
        )
        saleWorkspace = workspace
        if !workspace.transactions.contains(where: {
            $0.id == saleForm.transactionAssignmentID
        }) {
            saleForm.transactionAssignmentID =
                workspace.transactions.first?.id
        }
        if !workspace.journals.contains(where: {
            $0.id == saleForm.journalAssignmentID
        }) {
            saleForm.journalAssignmentID =
                workspace.journals.first?.id
        }
    }

    private func costDraft() -> ProductionBatchCostDraft? {
        guard let batchID = selectedBatchID else { return nil }
        let alternative: MarketPriceConfiguration?
        let alternativeName: String?
        if let regionID = costForm.alternativeRegionID {
            let location = marketLocations.first {
                $0.locationID == costForm.alternativeLocationID
            }
            let region = marketRegions.first {
                $0.regionID == regionID
            }
            alternative = MarketPriceConfiguration(
                regionID: regionID,
                locationID: location?.locationID,
                locationLabel: location?.name ?? region?.name
            )
            alternativeName = location?.name ?? region?.name
        } else {
            alternative = nil
            alternativeName = nil
        }
        do {
            return ProductionBatchCostDraft(
                batchID: batchID,
                priceProfileID: costForm.priceProfileID,
                alternativeMarket: alternative,
                alternativeMarketName: alternativeName,
                selectedSaleQuote: costForm.selectedSaleQuote,
                allowManualPriceSetFallback:
                    costForm.allowManualPriceSetFallback,
                facilityAndTaxCost: try optionalAmount(
                    costForm.facilityAndTaxCost
                ),
                blueprintAndInventionCost: try optionalAmount(
                    costForm.blueprintAndInventionCost
                ),
                marketFees: try optionalAmount(costForm.marketFees),
                manualOtherCost: try optionalAmount(
                    costForm.manualOtherCost
                )
            )
        } catch {
            return nil
        }
    }

    private func saleDraft() -> ProductionBatchSaleDraft? {
        guard let batchID = selectedBatchID else { return nil }
        do {
            let source: ProductionBatchSaleDraftSource
            switch saleForm.source {
            case .walletTransaction:
                guard let assignmentID =
                    saleForm.transactionAssignmentID,
                    let quantity = parsePositive(saleForm.quantity)
                else {
                    return nil
                }
                source = .walletTransaction(
                    projectAssignmentID: assignmentID,
                    quantity: quantity
                )
            case .walletJournal:
                guard let assignmentID =
                    saleForm.journalAssignmentID,
                    let amount = try positiveAmount(saleForm.amount)
                else {
                    return nil
                }
                source = .walletJournal(
                    projectAssignmentID: assignmentID,
                    amountHundredths: amount.hundredths
                )
            case .manualSale:
                guard let quantity = parsePositive(saleForm.quantity),
                    let amount = try positiveAmount(saleForm.amount)
                else {
                    return nil
                }
                source = .manualSale(
                    quantity: quantity,
                    amountHundredths: amount.hundredths,
                    date: saleForm.date,
                    reason: saleForm.reason
                )
            case .manualFee:
                guard let amount = try positiveAmount(saleForm.amount)
                else {
                    return nil
                }
                source = .manualFee(
                    amountHundredths: amount.hundredths,
                    date: saleForm.date,
                    reason: saleForm.reason
                )
            }
            return ProductionBatchSaleDraft(
                batchID: batchID,
                source: source
            )
        } catch {
            return nil
        }
    }

    private func optionalAmount(
        _ text: String
    ) throws -> NonNegativeISKAmount? {
        let normalized = text.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        return normalized.isEmpty
            ? nil
            : try NonNegativeISKAmount.parse(normalized)
    }

    private func positiveAmount(
        _ text: String
    ) throws -> NonNegativeISKAmount? {
        let value = try optionalAmount(text)
        guard let value, value.hundredths > 0 else {
            return nil
        }
        return value
    }

    private func applyProjectDefaults() {
        guard
            let project = projects.first(where: {
                $0.id == form.projectID
            })
        else {
            return
        }
        form.materialEfficiency = String(project.materialEfficiency)
        form.outputUnits = String(project.targetQuantity)
    }

    private func copyRequestToForm(
        _ request: ProductionBatchCreationRequest
    ) {
        form.productionDate = request.productionDate
        form.status = request.status
        form.runs = String(request.runs)
        form.materialEfficiency = String(request.materialEfficiency)
        form.timeEfficiency = String(request.timeEfficiency)
        form.outputUnits = String(request.outputUnits)
        form.characterID = request.characterID.map(String.init) ?? ""
        form.characterName = request.characterName ?? ""
        form.blueprintInstanceID =
            request.blueprintInstanceID.map(String.init) ?? ""
        form.esiIndustryJobID =
            request.esiIndustryJobID.map(String.init) ?? ""
        form.solarSystemID =
            request.solarSystemID.map(String.init) ?? ""
        form.solarSystemName = request.solarSystemName ?? ""
        form.locationID = request.locationID.map(String.init) ?? ""
        form.locationName = request.locationName ?? ""
        form.facilityID = request.facilityID.map(String.init) ?? ""
        form.facilityName = request.facilityName ?? ""
    }

    private func draft() -> ProductionBatchDraft? {
        guard let projectID = form.projectID,
            let runs = parsePositive(form.runs),
            let outputUnits = parsePositive(form.outputUnits),
            let materialEfficiency = parseRange(
                form.materialEfficiency,
                range: 0...10
            ),
            let timeEfficiency = parseRange(
                form.timeEfficiency,
                range: 0...20
            )
        else {
            return nil
        }
        return ProductionBatchDraft(
            projectID: projectID,
            productionDate: form.productionDate,
            status: form.status,
            runs: runs,
            materialEfficiency: materialEfficiency,
            timeEfficiency: timeEfficiency,
            outputUnits: outputUnits,
            characterID: parseOptionalPositive(form.characterID),
            characterName: form.characterName,
            blueprintInstanceID:
                parseOptionalPositive(form.blueprintInstanceID),
            esiIndustryJobID:
                parseOptionalPositive(form.esiIndustryJobID),
            solarSystemID:
                parseOptionalPositive(form.solarSystemID),
            solarSystemName: form.solarSystemName,
            locationID: parseOptionalPositive(form.locationID),
            locationName: form.locationName,
            facilityID: parseOptionalPositive(form.facilityID),
            facilityName: form.facilityName
        )
    }

    private func parsePositive(_ text: String) -> Int64? {
        guard let value = Int64(text), value > 0 else {
            return nil
        }
        return value
    }

    private func parseOptionalPositive(_ text: String) -> Int64? {
        let trimmed = text.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !trimmed.isEmpty else {
            return nil
        }
        return parsePositive(trimmed)
    }

    private func parseRange(
        _ text: String,
        range: ClosedRange<Int>
    ) -> Int? {
        guard let value = Int(text), range.contains(value) else {
            return nil
        }
        return value
    }

    private func perform(
        _ action: () async throws -> Void
    ) async {
        guard !isWorking else {
            return
        }
        isWorking = true
        errorMessage = nil
        defer { isWorking = false }
        do {
            try await action()
        } catch is CancellationError {
            errorMessage = "Der Vorgang wurde abgebrochen."
        } catch {
            errorMessage = Self.message(for: error)
        }
    }

    private static func message(for error: any Error) -> String {
        switch error as? ProductionBatchManagementError {
        case .staleProject, .staleGraph, .staleCatalog,
            .staleIndustryJob:
            return
                "Projekt, Produktionsgraph oder SDE-Daten haben sich geändert. Erzeuge eine neue Vorschau."
        case .industryJobMismatch:
            return "Der ESI-Industry-Job gehört nicht zum gewählten Projektziel."
        case .productionGraphMissing:
            return "Für das Projekt fehlt ein Produktionsgraph."
        case .requiredFieldMissing:
            return
                "Eine für diesen Datensatz benötigte Angabe fehlt. Erzeuge eine neue Zusammenfassung."
        case .confirmationRequired:
            return "Die Charge wurde nicht bestätigt."
        default:
            break
        }
        switch error as? ProductionBatchCostManagementError {
        case .incompleteCostBasis:
            return
                "Die Kostenbasis ist unvollständig. Unbekannte Werte müssen geklärt oder ausdrücklich mit 0 ISK bestätigt werden."
        case .staleBatch:
            return "Die Charge hat sich geändert. Erzeuge eine neue Kostenvorschau."
        case .stalePlanningBasis:
            return
                "Diese historische Charge gehört zu einem älteren Projekt- "
                    + "oder Graphstand und kann nicht sicher mit den "
                    + "aktuellen Materialien bewertet werden. Erzeuge aus "
                    + "dem aktuellen Projekt, Graph und Budget eine neue "
                    + "Charge. Die vorhandene Charge bleibt unverändert."
        case .confirmationRequired:
            return "Die Kostenbasis wurde nicht bestätigt."
        default:
            break
        }
        switch error as? ProductionBatchSaleManagementError {
        case .costBasisMissing:
            return
                "Für die Charge fehlt eine vollständige bestätigte Kostenbasis."
        case .projectAssignmentNotFound, .sourceNotFound,
            .sourceNotEligible:
            return
                "Der Wallet-Nachweis ist nicht mehr verfügbar oder nicht für diese Charge geeignet."
        case .sourceCapacityExceeded:
            return
                "Menge oder Betrag überschreiten die noch verfügbare Wallet-Zuordnung."
        case .stalePreview:
            return
                "Charge, Kostenbasis oder Wallet-Nachweis haben sich geändert. Erzeuge eine neue Vorschau."
        case .confirmationRequired:
            return "Die Zuordnung wurde nicht bestätigt."
        case .persistenceFailure:
            return
                "Die Zuordnung konnte nicht sicher gespeichert werden. Der bisherige Stand bleibt erhalten."
        default:
            break
        }
        switch error as? ProductionBatchSaleError {
        case .overSale:
            return
                "Die Verkaufsmenge überschreitet die Ausgabemenge der Charge."
        case .duplicateAllocation:
            return "Dieser Nachweis wurde bereits zugeordnet."
        case .arithmeticOverflow:
            return "Menge oder ISK-Betrag sind zu groß."
        default:
            return
                "Die Produktionscharge, Kostenbasis oder Verkaufszuordnung konnte nicht verarbeitet werden."
        }
    }
}
