import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum ProjectLifecycleViewModelError: Error, Equatable {
    case operationAlreadyRunning
}

@MainActor
final class ProjectLifecycleViewModel: ObservableObject {
    @Published var scope: ProductionProjectListScope = .current
    @Published var selectedProjectID: UUID?
    @Published private(set) var projects: [ProductionProjectSnapshot] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isMutating = false

    private let lifecycle: any ProductionProjectLifecycleManaging
    private let targetSelection: any ProductionTargetSelectionManaging

    init(
        lifecycle: any ProductionProjectLifecycleManaging,
        targetSelection: any ProductionTargetSelectionManaging
    ) {
        self.lifecycle = lifecycle
        self.targetSelection = targetSelection
    }

    var selectedProject: ProductionProjectSnapshot? {
        projects.first { $0.id == selectedProjectID }
    }

    var availableStatusTransitions: [ProjectStatus] {
        guard let selectedProject else {
            return []
        }
        return ProductionProjectStatusPolicy
            .allowedTransitions(from: selectedProject.status)
            .filter { $0 != .archived }
    }

    var canEdit: Bool {
        selectedProject.map { $0.status != .archived } ?? false
    }

    var canDuplicate: Bool {
        selectedProject != nil
    }

    var canArchive: Bool {
        selectedProject.map { $0.status != .archived } ?? false
    }

    var canRestore: Bool {
        selectedProject?.status == .archived
    }

    func load() async throws {
        isLoading = true
        defer { isLoading = false }
        let loaded = try await lifecycle.projects(scope: scope)
        try Task.checkCancellation()
        projects = loaded
        if !loaded.contains(where: { $0.id == selectedProjectID }) {
            selectedProjectID = nil
        }
    }

    func create(draft: ProductionProjectDraft) async throws {
        try await mutate(
            {
                try await lifecycle.create(draft: draft)
            },
            showingResultIn: .current
        )
    }

    func update(
        id: UUID,
        draft: ProductionProjectDraft
    ) async throws {
        try await mutate {
            try await lifecycle.update(id: id, draft: draft)
        }
    }

    func transition(to status: ProjectStatus) async throws {
        guard let selectedProjectID else {
            return
        }
        try await mutate {
            try await lifecycle.transition(
                id: selectedProjectID,
                to: status
            )
        }
    }

    func duplicateSelected() async throws {
        guard let selectedProjectID else {
            return
        }
        try await mutate(
            {
                try await lifecycle.duplicate(id: selectedProjectID)
            },
            showingResultIn: .current
        )
    }

    func archiveSelected() async throws {
        guard let selectedProjectID else {
            return
        }
        try await mutate {
            try await lifecycle.archive(id: selectedProjectID)
        }
    }

    func restoreSelected() async throws {
        guard let selectedProjectID else {
            return
        }
        try await mutate(
            {
                try await lifecycle.restore(id: selectedProjectID)
            },
            showingResultIn: .current
        )
    }

    func searchTargets(
        query: String?,
        activity: ProductionTargetActivity?,
        categoryID: Int64?,
        groupID: Int64?
    ) async throws -> ProductionTargetSearchPage {
        try await targetSelection.search(
            query: query,
            activity: activity,
            categoryID: categoryID,
            groupID: groupID
        )
    }

    func targetOptions(
        productTypeID: Int64,
        activity: ProductionTargetActivity
    ) async throws -> ProductionTargetOptions {
        try await targetSelection.options(
            productTypeID: productTypeID,
            activity: activity
        )
    }

    func selectTarget(
        productTypeID: Int64,
        activity: ProductionTargetActivity,
        blueprintTypeID: Int64?
    ) async throws -> ProductionTargetSelection {
        try await targetSelection.select(
            productTypeID: productTypeID,
            activity: activity,
            blueprintTypeID: blueprintTypeID
        )
    }

    func revalidateTarget(
        _ selection: ProductionTargetSelection
    ) async throws -> ProductionTargetSelection {
        try await targetSelection.revalidate(selection)
    }

    func targetQuantity(from text: String) -> Int? {
        do {
            return try ProductionTargetQuantityParser.parse(text)
        } catch {
            return nil
        }
    }

    private func mutate(
        _ action: () async throws -> ProductionProjectSnapshot,
        showingResultIn requestedScope: ProductionProjectListScope? = nil
    ) async throws {
        guard !isMutating else {
            throw ProjectLifecycleViewModelError.operationAlreadyRunning
        }
        isMutating = true
        defer { isMutating = false }

        let result = try await action()
        if let requestedScope {
            scope = requestedScope
        }
        let loaded = try await lifecycle.projects(scope: scope)
        try Task.checkCancellation()
        projects = loaded
        selectedProjectID = loaded.contains(where: { $0.id == result.id })
            ? result.id
            : nil
    }
}
