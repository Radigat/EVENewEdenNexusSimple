import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

@MainActor
final class ProductionGraphViewModel: ObservableObject {
    @Published private(set) var graph: ProductionGraphSnapshot?
    @Published private(set) var isLoading = false
    @Published private(set) var isGenerating = false

    private let service: any ProductionGraphManaging

    init(service: any ProductionGraphManaging) {
        self.service = service
    }

    func load(for project: ProductionProjectSnapshot) async throws {
        isLoading = true
        defer { isLoading = false }
        let loaded = try await service.graph(for: project)
        try Task.checkCancellation()
        graph = loaded
    }

    func generate(
        for project: ProductionProjectSnapshot
    ) async throws {
        isGenerating = true
        defer { isGenerating = false }
        let generated = try await service.generate(for: project)
        try Task.checkCancellation()
        graph = generated
    }

    func isStale(for project: ProductionProjectSnapshot) -> Bool {
        graph.map {
            ProductionGraphFreshness.isStale($0, for: project)
        } ?? false
    }
}
