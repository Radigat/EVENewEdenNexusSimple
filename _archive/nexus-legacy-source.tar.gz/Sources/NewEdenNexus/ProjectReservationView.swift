import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct ProjectReservationSheet: View {
    let project: ProductionProjectSnapshot
    @ObservedObject var model: ProjectReservationViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @Environment(\.dismiss) private var dismiss
    @State private var task: Task<Void, Never>?
    @State private var showingConfirmation = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header
            Divider()
            content
            Divider()
            footer
        }
        .padding(24)
        .frame(minWidth: 980, idealWidth: 1_140, minHeight: 700)
        .task { await load() }
        .onDisappear { task?.cancel() }
        .confirmationDialog(
            "Projektreservierungen übernehmen?",
            isPresented: $showingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Reservierungsänderungen übernehmen") {
                run(operation: .reservationSave) {
                    try await model.applyConfirmedPreview()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "\(NexusNumberFormat.quantity(model.preview?.changes.count ?? 0)) bestätigte Änderung(en) werden atomar gespeichert. Physische Bestände werden nicht verändert."
            )
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Projektreservierungen")
                .font(.title2.bold())
            Text(project.name)
                .foregroundStyle(.secondary)
            Label(
                "P24 bindet globale Type-ID-Mengen. P25 prüft konkurrierende Bindungen in der separaten Konfliktansicht.",
                systemImage: "lock.square.stack"
            )
            .font(.callout)
            .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var content: some View {
        if model.isLoading && model.preview == nil {
            ProgressView("Projektreservierungen werden geladen …")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let preview = model.preview {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    summary(preview)
                    if !model.isPreviewCurrent {
                        Label(
                            "Änderungen vorhanden – Detailvorschau neu berechnen.",
                            systemImage: "exclamationmark.triangle"
                        )
                        .foregroundStyle(.orange)
                    }
                    if preview.calculation.lines.isEmpty {
                        Text(
                            "Der Produktionsgraph enthält keine Endmaterialien."
                        )
                        .foregroundStyle(.secondary)
                    }
                    ForEach(
                        preview.calculation.lines,
                        id: \.safetyStock.availability.typeID
                    ) { line in
                        materialRow(line)
                    }
                }
            }
        } else {
            ContentUnavailableView {
                Label(
                    "Keine Reservierungsvorschau",
                    systemImage: "lock.slash"
                )
            } description: {
                Text(
                    "Ein aktueller Produktionsgraph sowie gültige P22- und P23-Bestandsstände sind erforderlich."
                )
            }
        }
    }

    private func summary(
        _ preview: ProjectReservationPreview
    ) -> some View {
        HStack(spacing: 24) {
            summaryTile(
                "Reservierte Materialien",
                preview.calculation.reservedMaterialCount,
                color: .blue
            )
            summaryTile(
                "Vollständig reserviert",
                preview.calculation.fullyReservedMaterialCount,
                color: .green
            )
            summaryTile(
                "Abgelaufen",
                preview.calculation.expiredReservationCount,
                color: .orange
            )
            Spacer()
            Text(
                "Reservierungsformel v\(preview.calculation.formulaVersion)"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    private func summaryTile(
        _ title: String,
        _ value: Int,
        color: Color
    ) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(value))
                .font(.title3.bold())
                .foregroundStyle(color)
                .monospacedDigit()
        }
    }

    private func materialRow(
        _ line: ProjectReservationLine
    ) -> some View {
        let typeID = line.safetyStock.availability.typeID
        let state = model.state(typeID: typeID)
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(line.safetyStock.availability.name)
                        .fontWeight(.semibold)
                    Text("Type-ID \(typeID)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if line.isCurrentReservationExpired {
                    Label(
                        "Reservierung abgelaufen – bleibt gebunden",
                        systemImage: "clock.badge.exclamationmark"
                    )
                    .foregroundStyle(.orange)
                } else if let reservation = line.currentReservation {
                    Label(
                        statusLabel(reservation.status),
                        systemImage: "lock.fill"
                    )
                    .foregroundStyle(.blue)
                } else {
                    Label(
                        "Nicht reserviert",
                        systemImage: "lock.open"
                    )
                    .foregroundStyle(.secondary)
                }
            }

            Picker(
                "Aktion",
                selection: stateBinding(typeID).mode
            ) {
                ForEach(ProjectReservationEditMode.allCases) {
                    Text($0.rawValue).tag($0)
                }
            }
            .pickerStyle(.segmented)
            .accessibilityLabel(
                "Reservierungsaktion für Type-ID \(typeID)"
            )

            editControls(typeID: typeID, state: state)

            Grid(
                alignment: .trailing,
                horizontalSpacing: 16,
                verticalSpacing: 4
            ) {
                valueRow(
                    "Projektbedarf",
                    line.safetyStock.availability.requiredQuantity,
                    "Nach P23 verfügbar",
                    line.safetyStock
                        .availableAfterSafetyStockQuantity
                )
                valueRow(
                    "Andere Projekte reserviert",
                    line.otherProjectsReservedQuantity,
                    "Aktuelles Projekt reserviert",
                    line.currentProjectReservedQuantity
                )
                valueRow(
                    "Maximal reservierbar",
                    line.maximumReservableQuantity,
                    "Nach Vorschlag frei",
                    line.freeAfterCurrentProjectQuantity
                )
                valueRow(
                    "Noch nicht reserviert",
                    line.unreservedRequirementQuantity,
                    "Bereits verbraucht",
                    line.currentReservation?.consumedQuantity ?? 0
                )
            }
            .font(.caption)
            .monospacedDigit()
        }
        .padding(12)
        .background(.secondary.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .accessibilityElement(children: .contain)
    }

    @ViewBuilder
    private func editControls(
        typeID: Int64,
        state: ProjectReservationFieldState
    ) -> some View {
        switch state.mode {
        case .reserve:
            HStack {
                TextField(
                    "Aktiv zu reservierende Restmenge",
                    text: stateBinding(typeID).quantity
                )
                .accessibilityLabel(
                    "Reservierte Restmenge für Type-ID \(typeID)"
                )
                Picker(
                    "Priorität",
                    selection: stateBinding(typeID).priority
                ) {
                    Text("1 – hoch").tag(1)
                    Text("2 – mittel").tag(2)
                    Text("3 – normal").tag(3)
                }
                Toggle(
                    "Ablaufdatum",
                    isOn: stateBinding(typeID).hasExpiry
                )
                if state.hasExpiry {
                    DatePicker(
                        "Gültig bis",
                        selection: stateBinding(typeID).expiresAt,
                        displayedComponents: [.date, .hourAndMinute]
                    )
                }
            }
        case .consume:
            TextField(
                "Jetzt verbrauchte Menge",
                text: stateBinding(typeID).quantity
            )
            .accessibilityLabel(
                "Zu verbrauchende Reservierungsmenge für Type-ID \(typeID)"
            )
        case .release:
            Label(
                "Die aktive Restmenge wird nach Bestätigung freigegeben. Der historische Datensatz bleibt erhalten.",
                systemImage: "lock.open"
            )
            .foregroundStyle(.orange)
        }
    }

    private func stateBinding(
        _ typeID: Int64
    ) -> Binding<ProjectReservationFieldState> {
        Binding(
            get: { model.state(typeID: typeID) },
            set: { model.setState($0, typeID: typeID) }
        )
    }

    private func valueRow(
        _ leftTitle: String,
        _ leftValue: Int64,
        _ rightTitle: String,
        _ rightValue: Int64
    ) -> some View {
        GridRow {
            Text(leftTitle).foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(leftValue))
            Text(rightTitle).foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(rightValue))
        }
    }

    private func statusLabel(
        _ status: StockReservationStatus
    ) -> String {
        switch status {
        case .reserved: "Reserviert"
        case .partiallyConsumed: "Teilweise verwendet"
        case .consumed: "Verbraucht"
        case .released: "Freigegeben"
        }
    }

    private var footer: some View {
        HStack {
            Button("Schließen") { dismiss() }
            Spacer()
            if model.isPreviewing || model.isSaving {
                ProgressView(
                    model.isSaving
                        ? "Reservierungen werden gespeichert …"
                        : "Reservierungsvorschau wird berechnet …"
                )
                Button("Abbrechen") { task?.cancel() }
            }
            Button("Vorschau berechnen") {
                run(operation: .reservationLoad) {
                    try await model.calculatePreview()
                }
            }
            .keyboardShortcut("r", modifiers: [.command, .shift])
            .disabled(
                model.isLoading || model.isPreviewing || model.isSaving
            )
            Button("Reservierungsänderungen übernehmen") {
                showingConfirmation = true
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut(.defaultAction)
            .disabled(!model.canApply)
        }
    }

    private func load() async {
        do {
            try await model.load(
                projectID: project.id,
                defaultPriority: project.priority
            )
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .reservationLoad,
                retry: {
                    Task {
                        await load()
                    }
                }
            )
        }
    }

    private func run(
        operation: NexusOperation,
        _ action: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: operation)
            }
        }
    }
}
