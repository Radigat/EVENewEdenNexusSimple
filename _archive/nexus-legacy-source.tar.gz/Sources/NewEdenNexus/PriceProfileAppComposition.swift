import NewEdenNexusApplication
import NewEdenNexusInfrastructure
import NewEdenNexusPersistence
import SwiftData

@MainActor
enum PriceProfileAppComposition {
    static func makeViewModel(
        container: ModelContainer
    ) -> PriceProfileViewModel {
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let repository = SwiftDataPriceProfileRepository(
            modelContainer: container
        )
        let service = PriceProfileManagementService(
            repository: repository,
            catalog: catalog
        )
        return PriceProfileViewModel(
            service: service,
            csvImporter: PriceCSVImportService(
                parser: DelimitedInventoryCSVParser(),
                repository: repository,
                catalog: catalog
            ),
            csvFileReader: LocalInventoryCSVFileReader(),
            marketRepository: repository
        )
    }
}
