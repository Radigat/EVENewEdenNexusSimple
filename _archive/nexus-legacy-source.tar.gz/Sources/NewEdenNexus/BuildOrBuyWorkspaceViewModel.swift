import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum BuildOrBuyStageCategory:
    String,
    CaseIterable,
    Hashable,
    Identifiable
{
    case manufacturing
    case invention
    case biochemicalReaction
    case compositeReaction
    case hybridPolymerReaction
    case unclassifiedReaction
    case mixed

    var id: Self { self }

    var title: String {
        switch self {
        case .manufacturing:
            "Produktion"
        case .invention:
            "T2 und Invention"
        case .biochemicalReaction:
            "Biochemical Reactions"
        case .compositeReaction:
            "Composite Reactions"
        case .hybridPolymerReaction:
            "Hybrid Polymer Reactions"
        case .unclassifiedReaction:
            "Unklassifizierte Reaktionen"
        case .mixed:
            "Weitere Produktionsstufen"
        }
    }

    var explanation: String {
        switch self {
        case .manufacturing:
            "Herstellbare Komponenten und Zwischenprodukte."
        case .invention:
            "T2-Stufen, deren Herstellung eine Invention voraussetzt."
        case .biochemicalReaction:
            "Biochemische Reaktionen für Booster- und verwandte Materialien."
        case .compositeReaction:
            "Composite-Reaktionen für T2-Rohstoffe und Komponentenketten."
        case .hybridPolymerReaction:
            "Hybrid-Polymer-Reaktionen für die zugehörigen Materialketten."
        case .unclassifiedReaction:
            "Reaktionsstufen ohne belastbare Unterklassifikation."
        case .mixed:
            "Mehrdeutig klassifizierte Stufen bleiben sichtbar und steuerbar."
        }
    }

    var systemImage: String {
        switch self {
        case .manufacturing:
            "hammer"
        case .invention:
            "sparkles"
        case .biochemicalReaction:
            "leaf"
        case .compositeReaction:
            "atom"
        case .hybridPolymerReaction:
            "link"
        case .unclassifiedReaction:
            "questionmark.circle"
        case .mixed:
            "square.stack.3d.up"
        }
    }

    fileprivate var sortOrder: Int {
        switch self {
        case .manufacturing:
            0
        case .invention:
            1
        case .biochemicalReaction:
            2
        case .compositeReaction:
            3
        case .hybridPolymerReaction:
            4
        case .unclassifiedReaction:
            5
        case .mixed:
            6
        }
    }

    init(recipe: ProductionGraphRecipeReference) {
        if recipe.activity == .reaction {
            switch recipe.reactionKind {
            case .some(.biochemical):
                self = .biochemicalReaction
            case .some(.composite):
                self = .compositeReaction
            case .some(.hybrid):
                self = .hybridPolymerReaction
            case nil:
                self = .unclassifiedReaction
            }
        } else if recipe.invention != nil {
            self = .invention
        } else {
            self = .manufacturing
        }
    }
}

struct BuildOrBuyStage: Identifiable, Equatable {
    let typeID: Int64
    let name: String
    let category: BuildOrBuyStageCategory

    var id: Int64 { typeID }
}

struct BuildOrBuyStageGroup: Identifiable, Equatable {
    let category: BuildOrBuyStageCategory
    let stages: [BuildOrBuyStage]

    var id: BuildOrBuyStageCategory { category }
}

enum BuildOrBuyWorkspaceViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case projectChanged
    case previewRequired
}

@MainActor
final class BuildOrBuyWorkspaceViewModel: ObservableObject {
    @Published private(set) var preview: BuildOrBuyPlanPreview?
    @Published private(set) var stages: [BuildOrBuyStage] = []
    @Published private(set) var choices: [Int64: BuildOrBuyChoice] = [:]
    @Published private(set) var isLoading = false
    @Published private(set) var isPreviewing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreviewCurrent = false
    @Published private(set) var lastErrorMessage: String?
    @Published private(set) var copiedShoppingList = false
    @Published private(set) var economicsPreview: ProjectEconomicsPreview?
    @Published private(set) var selectedEconomicsProfileID: UUID?
    @Published private(set) var manualJobCostText = "0.00"
    @Published private(set) var isEconomicsPreviewCurrent = false
    @Published private(set) var budgetPreview: ProjectBudgetPreview?
    @Published private(set) var selectedBudgetProfileID: UUID?
    @Published private(set) var logisticsCostText = "0.00"
    @Published private(set) var productionCostText = "0.00"
    @Published private(set) var isBudgetPreviewCurrent = false
    @Published private(set) var shoppingPreview: ShoppingListPreview?
    @Published private(set) var shoppingQuantityTexts: [Int64: String] = [:]
    @Published private(set) var isShoppingPreviewCurrent = false

    private let service: any BuildOrBuyPlanning
    private let economicsService: (any ProjectEconomicsManaging)?
    private let budgetService: (any ProjectBudgetManaging)?
    private let shoppingService: (any ShoppingListManaging)?
    private let marketPriceService: (any MarketPriceImporting)?
    private let priceProfileService: (any PriceProfileManaging)?
    private let marketLocationDirectory: (any MarketLocationDirectoryLoading)?
    private var projectID: UUID?
    private var graphID: UUID?
    private var targetTypeID: Int64?
    private var targetName: String?
    private var targetQuantity: Int64?

    init(
        service: any BuildOrBuyPlanning,
        economicsService: (any ProjectEconomicsManaging)? = nil,
        budgetService: (any ProjectBudgetManaging)? = nil,
        shoppingService: (any ShoppingListManaging)? = nil,
        marketPriceService: (any MarketPriceImporting)? = nil,
        priceProfileService: (any PriceProfileManaging)? = nil,
        marketLocationDirectory:
            (any MarketLocationDirectoryLoading)? = nil
    ) {
        self.service = service
        self.economicsService = economicsService
        self.budgetService = budgetService
        self.shoppingService = shoppingService
        self.marketPriceService = marketPriceService
        self.priceProfileService = priceProfileService
        self.marketLocationDirectory = marketLocationDirectory
    }

    var canApply: Bool {
        preview != nil
            && isPreviewCurrent
            && hasDecisionChanges
            && preview?.staleDecisionTypeIDs.isEmpty == true
            && !isSaving
    }

    var hasDecisionChanges: Bool {
        guard let preview else { return false }
        let stored = Set(preview.storedDecisions.map(\.typeID))
        let proposed = Set(
            choices.compactMap { typeID, choice in
                choice == .buy ? typeID : nil
            }
        )
        return stored != proposed
    }

    var stageGroups: [BuildOrBuyStageGroup] {
        Dictionary(grouping: stages, by: \.category)
            .map {
                BuildOrBuyStageGroup(
                    category: $0.key,
                    stages: $0.value
                )
            }
            .sorted {
                $0.category.sortOrder < $1.category.sortOrder
            }
    }

    var missingRequirements: [BuildOrBuyRequirementLine] {
        guard isPreviewCurrent else { return [] }
        return preview?.plan.requirements.filter {
            $0.missingQuantity > 0
        } ?? []
    }

    var shoppingListText: String {
        if shoppingService != nil {
            guard isShoppingPreviewCurrent else { return "" }
            return shoppingPreview?.aggregation.textList ?? ""
        }
        return missingRequirements.map {
            "\($0.name)\t\($0.missingQuantity)"
        }.joined(separator: "\n")
    }

    var shoppingPositions: [ShoppingListPosition] {
        shoppingPreview?.aggregation.positions ?? []
    }

    var canApplyShopping: Bool {
        guard shoppingService != nil,
            let shoppingPreview,
            isShoppingPreviewCurrent,
            !hasDecisionChanges,
            !isSaving
        else {
            return false
        }
        let stored = Dictionary(
            uniqueKeysWithValues:
                shoppingPreview.storedOverrides.map {
                    ($0.typeID, $0.quantity)
                }
        )
        let proposed = Dictionary(
            uniqueKeysWithValues:
                shoppingPreview.proposedOverrides.map {
                    ($0.typeID, $0.quantity)
                }
        )
        return stored != proposed
            || !shoppingPreview.staleStoredOverrideTypeIDs.isEmpty
    }

    var economicsProfiles: [PriceProfileSnapshot] {
        budgetPreview?.profiles ?? economicsPreview?.profiles ?? []
    }

    var canStartMarketPriceImport: Bool {
        marketPriceService != nil
            && isShoppingPreviewCurrent
            && shoppingPositions.contains { $0.purchaseQuantity > 0 }
            && !isBusy
    }

    func makeMarketPriceImportViewModel()
        -> MarketPriceImportViewModel?
    {
        guard let marketPriceService, canStartMarketPriceImport else {
            return nil
        }
        return MarketPriceImportViewModel(
            service: marketPriceService,
            profiles: economicsProfiles,
            selectedProfileID:
                selectedBudgetProfileID ?? selectedEconomicsProfileID,
            requirements: shoppingPositions.compactMap { position in
                guard position.purchaseQuantity > 0 else { return nil }
                return MarketPriceRequestLine(
                    typeID: position.typeID,
                    itemName: position.name,
                    quantity: position.purchaseQuantity
                )
            },
            priceProfiles: priceProfileService,
            locationDirectory: marketLocationDirectory
        )
    }

    func refreshAfterMarketPriceImport(
        profileID: UUID
    ) async throws {
        selectedBudgetProfileID = profileID
        try await refreshBudget()
    }

    var canApplyBudget: Bool {
        guard let budgetPreview,
            isBudgetPreviewCurrent,
            budgetPreview.draft.priceProfileID != nil
        else {
            return false
        }
        let stored = budgetPreview.storedConfiguration
        return stored?.priceProfileID
            != budgetPreview.draft.priceProfileID
            || stored?.logisticsCost
                != budgetPreview.draft.logisticsCost
            || stored?.productionCost
                != budgetPreview.draft.productionCost
    }

    var canApplyEconomics: Bool {
        guard let economicsPreview,
            isEconomicsPreviewCurrent,
            economicsPreview.draft.priceProfileID != nil
        else {
            return false
        }
        let stored = economicsPreview.storedConfiguration
        return stored?.priceProfileID
            != economicsPreview.draft.priceProfileID
            || stored?.manualJobCost
                != economicsPreview.draft.manualJobCost
    }

    func load(
        projectID requestedProjectID: UUID,
        graph: ProductionGraphSnapshot
    ) async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        projectID = requestedProjectID
        graphID = graph.id
        let target = graph.nodes.first {
            $0.id == graph.rootNodeID
        }
        targetTypeID = target?.typeID
        targetName = target?.name
        targetQuantity = Int64(graph.projectTargetQuantity)
        preview = nil
        stages = Self.buildableStages(in: graph)
        choices = Dictionary(
            uniqueKeysWithValues: stages.map {
                ($0.typeID, BuildOrBuyChoice.build)
            }
        )
        isPreviewCurrent = false
        lastErrorMessage = nil
        copiedShoppingList = false
        economicsPreview = nil
        selectedEconomicsProfileID = nil
        manualJobCostText = "0.00"
        isEconomicsPreviewCurrent = false
        budgetPreview = nil
        selectedBudgetProfileID = nil
        logisticsCostText = "0.00"
        productionCostText = "0.00"
        isBudgetPreviewCurrent = false
        shoppingPreview = nil
        shoppingQuantityTexts = [:]
        isShoppingPreviewCurrent = false
        isLoading = true
        defer {
            if projectID == requestedProjectID, graphID == graph.id {
                isLoading = false
            }
        }
        do {
            let loaded = try await service.preview(
                projectID: requestedProjectID,
                decisions: nil
            )
            try Task.checkCancellation()
            guard projectID == requestedProjectID,
                graphID == graph.id,
                loaded.sourceVersion.graphID == graph.id
            else {
                throw BuildOrBuyWorkspaceViewModelError.projectChanged
            }
            apply(loaded)
            try await loadShopping(planPreview: loaded)
            try await loadBudget()
            try await loadEconomics(plan: loaded.plan)
        } catch {
            if !(error is CancellationError) {
                lastErrorMessage =
                    "Der Produktionsplan konnte nicht geladen werden."
            }
            throw error
        }
    }

    func choice(typeID: Int64) -> BuildOrBuyChoice {
        choices[typeID] ?? .build
    }

    func setChoice(_ choice: BuildOrBuyChoice, typeID: Int64) {
        guard stages.contains(where: { $0.typeID == typeID }) else {
            return
        }
        choices[typeID] = choice
        markDecisionsChanged()
    }

    func setChoice(
        _ choice: BuildOrBuyChoice,
        for category: BuildOrBuyStageCategory
    ) {
        let matchingTypeIDs = stages.lazy
            .filter { $0.category == category }
            .map(\.typeID)
        guard !matchingTypeIDs.isEmpty else { return }
        for typeID in matchingTypeIDs {
            choices[typeID] = choice
        }
        markDecisionsChanged()
    }

    func setChoiceForAllStages(_ choice: BuildOrBuyChoice) {
        guard !stages.isEmpty else { return }
        for stage in stages {
            choices[stage.typeID] = choice
        }
        markDecisionsChanged()
    }

    var uniformChoiceForAllStages: BuildOrBuyChoice? {
        uniformChoice(for: stages)
    }

    func uniformChoice(
        in category: BuildOrBuyStageCategory
    ) -> BuildOrBuyChoice? {
        uniformChoice(
            for: stages.filter { $0.category == category }
        )
    }

    func calculatePreview() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let projectID else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        let requestedGraphID = graphID
        isPreviewing = true
        defer { isPreviewing = false }
        do {
            let calculated = try await service.preview(
                projectID: projectID,
                decisions: decisionDrafts
            )
            try Task.checkCancellation()
            guard self.projectID == projectID,
                graphID == requestedGraphID
            else {
                throw BuildOrBuyWorkspaceViewModelError.projectChanged
            }
            preview = calculated
            isPreviewCurrent = true
            try await refreshShopping(planPreview: calculated)
            try await refreshBudget()
            try await refreshEconomics(plan: calculated.plan)
            copiedShoppingList = false
            lastErrorMessage = nil
        } catch {
            if !(error is CancellationError) {
                lastErrorMessage =
                    "Die geänderte Produktionsplanung konnte nicht berechnet werden."
            }
            throw error
        }
    }

    func applyConfirmedPreview() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let preview, canApply else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        let requestedProjectID = projectID
        let requestedGraphID = graphID
        isSaving = true
        defer { isSaving = false }
        do {
            let saved = try await service.apply(preview, confirmed: true)
            try Task.checkCancellation()
            guard projectID == requestedProjectID,
                graphID == requestedGraphID
            else {
                throw BuildOrBuyWorkspaceViewModelError.projectChanged
            }
            apply(saved)
            try await refreshShopping(planPreview: saved)
            try await refreshBudget()
            try await refreshEconomics(plan: saved.plan)
        } catch {
            if !(error is CancellationError) {
                lastErrorMessage =
                    "Die Build-or-Buy-Entscheidungen wurden nicht gespeichert."
            }
            throw error
        }
    }

    func markShoppingListCopied() {
        copiedShoppingList = !shoppingListText.isEmpty
    }

    func setShoppingQuantityText(_ value: String, typeID: Int64) {
        guard shoppingQuantityTexts[typeID] != nil else { return }
        shoppingQuantityTexts[typeID] = value
        isShoppingPreviewCurrent = false
        isBudgetPreviewCurrent = false
        copiedShoppingList = false
    }

    func resetShoppingQuantity(typeID: Int64) {
        guard
            let position = shoppingPositions.first(where: {
                $0.typeID == typeID
            })
        else { return }
        shoppingQuantityTexts[typeID] =
            String(position.calculatedQuantity)
        isShoppingPreviewCurrent = false
        isBudgetPreviewCurrent = false
        copiedShoppingList = false
    }

    func calculateShoppingPreview() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let shoppingService, let preview else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        let requestedProjectID = projectID
        let requestedGraphID = graphID
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await shoppingService.preview(
            planPreview: preview,
            quantities: try shoppingDrafts()
        )
        try Task.checkCancellation()
        guard projectID == requestedProjectID,
            graphID == requestedGraphID
        else {
            throw BuildOrBuyWorkspaceViewModelError.projectChanged
        }
        applyShopping(calculated)
        try await refreshBudget()
    }

    func applyConfirmedShopping() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let shoppingService,
            let shoppingPreview,
            canApplyShopping
        else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        let requestedProjectID = projectID
        let requestedGraphID = graphID
        isSaving = true
        defer { isSaving = false }
        let saved = try await shoppingService.apply(
            shoppingPreview,
            confirmed: true
        )
        guard projectID == requestedProjectID,
            graphID == requestedGraphID
        else {
            throw BuildOrBuyWorkspaceViewModelError.projectChanged
        }
        applyShopping(saved)
        try await refreshBudget()
    }

    func setBudgetProfile(_ profileID: UUID?) {
        selectedBudgetProfileID = profileID
        isBudgetPreviewCurrent = false
    }

    func setLogisticsCostText(_ value: String) {
        logisticsCostText = value
        isBudgetPreviewCurrent = false
    }

    func setProductionCostText(_ value: String) {
        productionCostText = value
        isBudgetPreviewCurrent = false
    }

    func calculateBudgetPreview() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let budgetService,
            let draft = try budgetDraft()
        else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await budgetService.preview(
            draft: draft,
            storedConfiguration:
                budgetPreview?.storedConfiguration,
            at: Date()
        )
        try Task.checkCancellation()
        guard projectID == draft.projectID, graphID == draft.graphID else {
            throw BuildOrBuyWorkspaceViewModelError.projectChanged
        }
        applyBudget(calculated)
    }

    func applyConfirmedBudget() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let budgetService,
            let budgetPreview,
            canApplyBudget
        else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        let requestedProjectID = projectID
        let requestedGraphID = graphID
        isSaving = true
        defer { isSaving = false }
        let saved = try await budgetService.apply(
            budgetPreview,
            confirmed: true,
            at: Date()
        )
        try Task.checkCancellation()
        guard projectID == requestedProjectID,
            graphID == requestedGraphID
        else {
            throw BuildOrBuyWorkspaceViewModelError.projectChanged
        }
        applyBudget(saved)
    }

    func setEconomicsProfile(_ profileID: UUID?) {
        selectedEconomicsProfileID = profileID
        isEconomicsPreviewCurrent = false
    }

    func setManualJobCostText(_ value: String) {
        manualJobCostText = value
        isEconomicsPreviewCurrent = false
    }

    func calculateEconomicsPreview() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let economicsService,
            let plan = preview?.plan,
            let draft = try economicsDraft(plan: plan)
        else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await economicsService.preview(
            draft: draft,
            storedConfiguration:
                economicsPreview?.storedConfiguration,
            at: Date()
        )
        try Task.checkCancellation()
        guard projectID == draft.projectID, graphID == draft.graphID else {
            throw BuildOrBuyWorkspaceViewModelError.projectChanged
        }
        applyEconomics(calculated)
    }

    func applyConfirmedEconomics() async throws {
        guard !isBusy else {
            throw BuildOrBuyWorkspaceViewModelError.operationAlreadyRunning
        }
        guard let economicsService,
            let economicsPreview,
            canApplyEconomics
        else {
            throw BuildOrBuyWorkspaceViewModelError.previewRequired
        }
        let requestedProjectID = projectID
        let requestedGraphID = graphID
        isSaving = true
        defer { isSaving = false }
        let saved = try await economicsService.apply(
            economicsPreview,
            confirmed: true,
            at: Date()
        )
        try Task.checkCancellation()
        guard projectID == requestedProjectID,
            graphID == requestedGraphID
        else {
            throw BuildOrBuyWorkspaceViewModelError.projectChanged
        }
        applyEconomics(saved)
    }

    private var isBusy: Bool {
        isLoading || isPreviewing || isSaving
    }

    private var decisionDrafts: [BuildOrBuyDecisionDraft] {
        stages.map {
            BuildOrBuyDecisionDraft(
                typeID: $0.typeID,
                choice: choice(typeID: $0.typeID)
            )
        }
    }

    private func apply(_ loaded: BuildOrBuyPlanPreview) {
        preview = loaded
        var loadedChoices = Dictionary(
            uniqueKeysWithValues: stages.map {
                ($0.typeID, BuildOrBuyChoice.build)
            }
        )
        for decision in loaded.proposedDecisions {
            loadedChoices[decision.typeID] = decision.choice
        }
        choices = loadedChoices
        isPreviewCurrent = true
        copiedShoppingList = false
        lastErrorMessage = nil
    }

    private func loadEconomics(plan: BuildOrBuyPlan) async throws {
        guard let economicsService,
            let projectID,
            let graphID,
            let targetTypeID,
            let targetName,
            let targetQuantity
        else {
            return
        }
        let loaded = try await economicsService.load(
            projectID: projectID,
            graphID: graphID,
            targetTypeID: targetTypeID,
            targetName: targetName,
            targetQuantity: targetQuantity,
            plan: plan,
            at: Date()
        )
        applyEconomics(loaded)
    }

    private func refreshEconomics(plan: BuildOrBuyPlan) async throws {
        guard let economicsService else { return }
        guard economicsPreview != nil else {
            try await loadEconomics(plan: plan)
            return
        }
        guard let draft = try economicsDraft(plan: plan) else { return }
        let calculated = try await economicsService.preview(
            draft: draft,
            storedConfiguration:
                economicsPreview?.storedConfiguration,
            at: Date()
        )
        applyEconomics(calculated)
    }

    private func loadShopping(
        planPreview: BuildOrBuyPlanPreview
    ) async throws {
        guard let shoppingService else { return }
        let loaded = try await shoppingService.load(
            planPreview: planPreview
        )
        applyShopping(loaded)
    }

    private func loadBudget() async throws {
        guard let budgetService,
            let projectID,
            let graphID,
            let shoppingPreview
        else {
            return
        }
        applyBudget(
            try await budgetService.load(
                projectID: projectID,
                graphID: graphID,
                purchases: shoppingPreview.aggregation.positions,
                at: Date()
            )
        )
    }

    private func refreshBudget() async throws {
        guard let budgetService else { return }
        guard budgetPreview != nil else {
            try await loadBudget()
            return
        }
        guard let draft = try budgetDraft() else { return }
        applyBudget(
            try await budgetService.preview(
                draft: draft,
                storedConfiguration:
                    budgetPreview?.storedConfiguration,
                at: Date()
            )
        )
    }

    private func refreshShopping(
        planPreview: BuildOrBuyPlanPreview
    ) async throws {
        guard let shoppingService else { return }
        let loaded = try await shoppingService.load(
            planPreview: planPreview
        )
        applyShopping(loaded)
    }

    private func shoppingDrafts() throws -> [ShoppingQuantityDraft] {
        try shoppingPositions.map { position in
            let text =
                shoppingQuantityTexts[position.typeID]?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            guard let quantity = Int64(text), quantity >= 0 else {
                throw ShoppingListManagementError.invalidDraft(
                    typeID: position.typeID,
                    quantity: -1
                )
            }
            return ShoppingQuantityDraft(
                typeID: position.typeID,
                quantity: quantity
            )
        }
    }

    private func applyShopping(_ loaded: ShoppingListPreview) {
        shoppingPreview = loaded
        shoppingQuantityTexts = Dictionary(
            uniqueKeysWithValues: loaded.aggregation.positions.map {
                ($0.typeID, String($0.purchaseQuantity))
            }
        )
        isShoppingPreviewCurrent = true
        copiedShoppingList = false
    }

    private func budgetDraft() throws -> ProjectBudgetDraft? {
        guard let projectID,
            let graphID,
            let shoppingPreview
        else {
            return nil
        }
        return ProjectBudgetDraft(
            projectID: projectID,
            graphID: graphID,
            priceProfileID: selectedBudgetProfileID,
            logisticsCost: try NonNegativeISKAmount.parse(
                logisticsCostText
            ),
            productionCost: try NonNegativeISKAmount.parse(
                productionCostText
            ),
            purchases: shoppingPreview.aggregation.positions
        )
    }

    private func applyBudget(_ loaded: ProjectBudgetPreview) {
        budgetPreview = loaded
        selectedBudgetProfileID = loaded.draft.priceProfileID
        logisticsCostText = loaded.draft.logisticsCost.displayText
        productionCostText = loaded.draft.productionCost.displayText
        isBudgetPreviewCurrent = true
    }

    private func economicsDraft(
        plan: BuildOrBuyPlan
    ) throws -> ProjectEconomicsDraft? {
        guard let projectID,
            let graphID,
            let targetTypeID,
            let targetName,
            let targetQuantity
        else {
            return nil
        }
        return ProjectEconomicsDraft(
            projectID: projectID,
            graphID: graphID,
            targetTypeID: targetTypeID,
            targetName: targetName,
            targetQuantity: targetQuantity,
            priceProfileID: selectedEconomicsProfileID,
            manualJobCost: try NonNegativeISKAmount.parse(
                manualJobCostText
            ),
            plan: plan
        )
    }

    private func applyEconomics(
        _ loaded: ProjectEconomicsPreview
    ) {
        economicsPreview = loaded
        selectedEconomicsProfileID = loaded.draft.priceProfileID
        manualJobCostText = loaded.draft.manualJobCost.displayText
        isEconomicsPreviewCurrent = true
    }

    private static func buildableStages(
        in graph: ProductionGraphSnapshot
    ) -> [BuildOrBuyStage] {
        var stagesByTypeID:
            [Int64: (
                names: Set<String>,
                categories:
                    Set<BuildOrBuyStageCategory>
            )] = [:]
        for node in graph.nodes
        where node.kind == .intermediate {
            guard let recipe = node.recipe else { continue }
            var value =
                stagesByTypeID[node.typeID]
                ?? (names: [], categories: [])
            value.names.insert(node.name)
            value.categories.insert(
                BuildOrBuyStageCategory(recipe: recipe)
            )
            stagesByTypeID[node.typeID] = value
        }
        return stagesByTypeID.map {
            BuildOrBuyStage(
                typeID: $0.key,
                name: $0.value.names.sorted().first
                    ?? String($0.key),
                category: $0.value.categories.count == 1
                    ? $0.value.categories.first ?? .mixed
                    : .mixed
            )
        }.sorted {
            if $0.category.sortOrder != $1.category.sortOrder {
                return $0.category.sortOrder
                    < $1.category.sortOrder
            }
            return $0.name == $1.name
                ? $0.typeID < $1.typeID
                : $0.name.localizedStandardCompare($1.name)
                    == .orderedAscending
        }
    }

    private func markDecisionsChanged() {
        isPreviewCurrent = false
        isEconomicsPreviewCurrent = false
        isBudgetPreviewCurrent = false
        isShoppingPreviewCurrent = false
        copiedShoppingList = false
        lastErrorMessage = nil
    }

    private func uniformChoice(
        for stages: [BuildOrBuyStage]
    ) -> BuildOrBuyChoice? {
        guard let firstStage = stages.first else { return nil }
        let firstChoice = choice(typeID: firstStage.typeID)
        return stages.dropFirst().allSatisfy {
            choice(typeID: $0.typeID) == firstChoice
        } ? firstChoice : nil
    }
}
