import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

@MainActor
final class MarketPriceImportViewModel: ObservableObject, Identifiable {
    let id = UUID()

    @Published var selectedProfileID: UUID?
    @Published var newProfileName = ""
    @Published var regionIDText = ""
    @Published var locationIDText = ""
    @Published var locationLabel = ""
    @Published private(set) var regions: [MarketRegionOption] = []
    @Published private(set) var locations: [MarketLocationOption] = []
    @Published private(set) var directoryWarnings: [String] = []
    @Published private(set) var isLoadingDirectory = false
    @Published private(set) var hasLoadedDirectory = false
    @Published private(set) var selectedRegionID: Int64?
    @Published private(set) var selectedLocationID: Int64?
    @Published private(set) var preview: MarketPriceImportPreview?
    @Published private(set) var report: MarketPriceImportReport?
    @Published private(set) var isWorking = false

    @Published private(set) var profiles: [PriceProfileSnapshot]
    let requirements: [MarketPriceRequestLine]
    private let service: any MarketPriceImporting
    private let priceProfiles: (any PriceProfileManaging)?
    private let locationDirectory: (any MarketLocationDirectoryLoading)?

    init(
        service: any MarketPriceImporting,
        profiles: [PriceProfileSnapshot],
        selectedProfileID: UUID?,
        requirements: [MarketPriceRequestLine],
        priceProfiles: (any PriceProfileManaging)? = nil,
        locationDirectory:
            (any MarketLocationDirectoryLoading)? = nil
    ) {
        self.service = service
        self.profiles = profiles
        self.requirements = requirements
        self.priceProfiles = priceProfiles
        self.locationDirectory = locationDirectory
        self.selectedProfileID =
            selectedProfileID
            ?? profiles.first(where: \.isActive)?.id
            ?? profiles.first?.id
    }

    var canPreview: Bool {
        !isWorking
            && !isLoadingDirectory
            && Int64(regionIDText).map({ $0 > 0 }) == true
            && optionalLocationID != .invalid
            && !requirements.isEmpty
    }

    var canApply: Bool {
        !isWorking
            && preview?.profile != nil
            && preview?.changedLines.isEmpty == false
    }

    var canCreateProfile: Bool {
        !isWorking
            && priceProfiles != nil
            && !newProfileName.trimmingCharacters(
                in: .whitespacesAndNewlines
            ).isEmpty
    }

    func createTargetProfile() async throws {
        guard let priceProfiles, canCreateProfile else {
            return
        }
        isWorking = true
        defer { isWorking = false }
        let created = try await priceProfiles.createProfile(
            draft: PriceProfileDraft(name: newProfileName)
        )
        profiles = try await priceProfiles.profiles()
        selectedProfileID = created.id
        newProfileName = ""
        markInputsChanged()
    }

    func markInputsChanged() {
        preview = nil
        report = nil
    }

    var locationsForSelectedRegion: [MarketLocationOption] {
        guard let selectedRegionID else { return [] }
        return locations.filter { $0.regionID == selectedRegionID }
    }

    var selectedRegion: MarketRegionOption? {
        regions.first { $0.regionID == selectedRegionID }
    }

    var selectedLocation: MarketLocationOption? {
        locations.first { $0.locationID == selectedLocationID }
    }

    func loadLocationDirectory() async {
        guard !hasLoadedDirectory, !isLoadingDirectory else { return }
        isLoadingDirectory = true
        defer {
            isLoadingDirectory = false
            hasLoadedDirectory = true
        }
        let snapshot: MarketLocationDirectorySnapshot
        if let locationDirectory {
            do {
                snapshot = try await locationDirectory.load()
            } catch is CancellationError {
                return
            } catch {
                snapshot = Self.fallbackDirectory
            }
        } else {
            snapshot = Self.fallbackDirectory
        }
        regions = snapshot.regions
        locations = snapshot.locations
        directoryWarnings = snapshot.warnings
        let previousRegion = Int64(regionIDText)
        let initialRegion =
            previousRegion.flatMap { value in
                regions.contains(where: { $0.regionID == value })
                    ? value
                    : nil
            } ?? MarketTradeHubPreset.all.first?.regionID
            ?? regions.first?.regionID
        selectRegion(initialRegion)
    }

    func selectRegion(_ regionID: Int64?) {
        guard let regionID,
            regions.contains(where: { $0.regionID == regionID })
        else {
            selectedRegionID = nil
            selectedLocationID = nil
            regionIDText = ""
            locationIDText = ""
            locationLabel = ""
            markInputsChanged()
            return
        }
        selectedRegionID = regionID
        regionIDText = String(regionID)
        if selectedLocation?.regionID != regionID {
            selectedLocationID = nil
            locationIDText = ""
            locationLabel = ""
        }
        markInputsChanged()
    }

    func selectLocation(_ locationID: Int64?) {
        guard let locationID else {
            selectedLocationID = nil
            locationIDText = ""
            locationLabel = ""
            markInputsChanged()
            return
        }
        guard
            let location = locations.first(where: {
                $0.locationID == locationID
            }), location.kind != .accessibleStructure
        else {
            return
        }
        if selectedRegionID != location.regionID {
            selectedRegionID = location.regionID
            regionIDText = String(location.regionID)
        }
        selectedLocationID = location.locationID
        locationIDText = String(location.locationID)
        locationLabel = location.name
        markInputsChanged()
    }

    func createPreview() async throws {
        guard let regionID = Int64(regionIDText),
            regionID > 0
        else {
            throw MarketPriceImportError.invalidRegionID
        }
        let locationID: Int64?
        switch optionalLocationID {
        case .none:
            locationID = nil
        case .value(let value):
            locationID = value
        case .invalid:
            throw MarketPriceImportError.invalidLocationID
        }
        isWorking = true
        defer { isWorking = false }
        preview = try await service.preview(
            profileID: selectedProfileID,
            configuration: MarketPriceConfiguration(
                regionID: regionID,
                locationID: locationID,
                locationLabel: locationLabel
            ),
            requirements: requirements
        )
        report = nil
    }

    func applyConfirmedPreview() async throws -> UUID {
        guard let preview else {
            throw MarketPriceImportError.stalePreview
        }
        guard let profileID = preview.profile?.id else {
            throw MarketPriceImportError.targetPriceSetRequired
        }
        isWorking = true
        defer { isWorking = false }
        report = try await service.apply(
            preview: preview,
            confirmed: true
        )
        self.preview = nil
        return profileID
    }

    private enum OptionalLocationID: Equatable {
        case none
        case value(Int64)
        case invalid
    }

    private var optionalLocationID: OptionalLocationID {
        let text = locationIDText.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !text.isEmpty else { return .none }
        guard let value = Int64(text), value > 0 else {
            return .invalid
        }
        return .value(value)
    }

    private static var fallbackDirectory: MarketLocationDirectorySnapshot {
        let names: [Int64: String] = [
            10_000_002: "The Forge",
            10_000_030: "Heimatar",
            10_000_032: "Sinq Laison",
            10_000_042: "Metropolis",
            10_000_043: "Domain",
        ]
        let regions = names.compactMap {
            try? MarketRegionOption(regionID: $0.key, name: $0.value)
        }.sorted {
            $0.name.localizedCaseInsensitiveCompare($1.name)
                == .orderedAscending
        }
        return MarketLocationDirectorySnapshot(
            regions: regions,
            locations: MarketTradeHubPreset.all,
            warnings: [
                "Das vollständige ESI-Regionsverzeichnis ist derzeit nicht verfügbar."
            ]
        )
    }
}
