import AppKit
import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI
import UniformTypeIdentifiers

struct PurchasingView: View {
    @ObservedObject var model: PurchasingViewModel
    let reportError: (any Error, NexusOperation) -> Void

    @State private var errorMessage: String?
    @State private var showingConfirmation = false
    @State private var showingExporter = false
    @State private var exportDocument =
        PurchasingCSVDocument(text: "")

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            content
        }
        .navigationTitle("Einkaufsliste")
        .task {
            guard model.preview == nil else { return }
            await load()
        }
        .confirmationDialog(
            "Kauf-Fortschritt speichern?",
            isPresented: $showingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Bestätigt speichern") {
                run(operation: .purchasingSave) {
                    try await model.applyConfirmed()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Nur die projektbezogene Einkaufszuordnung wird geändert. Lagerbestände bleiben unverändert."
            )
        }
        .fileExporter(
            isPresented: $showingExporter,
            document: exportDocument,
            contentType: .commaSeparatedText,
            defaultFilename: "New-Eden-Nexus-Einkaufsliste"
        ) { result in
            if case .failure(let error) = result {
                errorMessage = "Die CSV-Datei wurde nicht gespeichert."
                reportError(error, .purchasingExport)
            }
        }
    }

    private var header: some View {
        ViewThatFits(in: .horizontal) {
            HStack {
                purchasingHeading
                Spacer()
                refreshButton
            }
            VStack(alignment: .leading, spacing: 10) {
                purchasingHeading
                refreshButton
            }
        }
        .padding()
    }

    private var purchasingHeading: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("Projektübergreifender Einkauf")
                .font(.title2.bold())
                .accessibilityAddTraits(.isHeader)
            Text(
                "Teilkäufe werden Projekten zugeordnet und verändern den Lagerbestand nicht."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var refreshButton: some View {
        Button {
            Task { await load() }
        } label: {
            Label("Aktualisieren", systemImage: "arrow.clockwise")
        }
        .keyboardShortcut("r", modifiers: [.command, .shift])
        .disabled(
            model.isLoading
                || model.isPreviewing
                || model.isSaving
        )
        .accessibilityLabel("Projektübergreifende Einkaufsliste aktualisieren")
    }

    @ViewBuilder
    private var content: some View {
        if model.isLoading, model.preview == nil {
            ProgressView("Einkaufslisten werden berechnet …")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let errorMessage, model.preview == nil {
            NexusOperationFailureView(
                title: "Einkaufsliste nicht verfügbar",
                message: errorMessage,
                retry: { Task { await load() } }
            )
        } else if let preview = model.preview {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 14) {
                    summary(preview)
                    warnings(preview)
                    if preview.aggregation.positions.isEmpty {
                        ContentUnavailableView {
                            Label(
                                "Nichts einzukaufen",
                                systemImage: "checkmark.circle.fill"
                            )
                        } description: {
                            Text(
                                "Aktuelle Projekte enthalten keine wirksamen Zielkaufmengen."
                            )
                        }
                    } else {
                        ForEach(
                            preview.aggregation.positions,
                            id: \.typeID
                        ) {
                            positionCard($0)
                        }
                    }
                    actions
                }
                .padding()
                .frame(maxWidth: 1_100, alignment: .leading)
            }
        }
    }

    private func summary(
        _ preview: PurchasingWorkflowPreview
    ) -> some View {
        LazyVGrid(
            columns: [
                GridItem(
                    .adaptive(minimum: 170, maximum: 320),
                    spacing: 16
                )
            ],
            spacing: 12
        ) {
            metric(
                title: "Offene Positionen",
                value: NexusNumberFormat.quantity(
                    preview.aggregation.openPositionCount
                )
            )
            metric(
                title: "Offene Einheiten",
                value: NexusNumberFormat.quantity(
                    preview.aggregation.totalRemainingQuantity
                )
            )
            metric(
                title: "Berücksichtigte Projekte",
                value: NexusNumberFormat.quantity(
                    preview.scopedProjectIDs.count
                )
            )
        }
    }

    @ViewBuilder
    private func warnings(
        _ preview: PurchasingWorkflowPreview
    ) -> some View {
        if !preview.issues.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Label(
                    "\(NexusNumberFormat.quantity(preview.issues.count)) Projekt(e) ohne berechenbaren aktuellen Plan",
                    systemImage: "exclamationmark.triangle.fill"
                )
                .foregroundStyle(.orange)
                ForEach(preview.issues) {
                    Text("• \($0.projectName)")
                        .font(.caption)
                }
            }
            .padding(10)
            .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
        }
        if !preview.staleProgressKeys.isEmpty {
            Label(
                "\(NexusNumberFormat.quantity(preview.staleProgressKeys.count)) gespeicherte Zuordnung(en) gehören nicht mehr zu einer aktuellen Zielkaufmenge und bleiben geschützt.",
                systemImage: "archivebox"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        if !model.isPreviewCurrent {
            Label(
                "Eingaben geändert – vor dem Speichern neu berechnen.",
                systemImage: "arrow.triangle.2.circlepath"
            )
            .foregroundStyle(.orange)
        }
        NexusValidationSummary(issues: model.validationIssues)
        if let errorMessage {
            Label(errorMessage, systemImage: "exclamationmark.triangle")
                .foregroundStyle(.red)
        }
    }

    private func positionCard(
        _ position: PurchasingWorkflowPosition
    ) -> some View {
        DisclosureGroup {
            VStack(alignment: .leading, spacing: 9) {
                ForEach(position.sources, id: \.projectID) { source in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(source.projectName)
                                .fontWeight(.medium)
                            Text(
                                "Ziel \(NexusNumberFormat.quantity(source.targetQuantity)) · offen \(NexusNumberFormat.quantity(source.remainingQuantity))"
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            if source.hasExcessProgress {
                                Text(
                                    "Gespeicherter Fortschritt übersteigt das aktuelle Ziel; angerechnet werden \(NexusNumberFormat.quantity(source.creditedPurchasedQuantity))."
                                )
                                .font(.caption)
                                .foregroundStyle(.orange)
                            }
                        }
                        Spacer()
                        TextField(
                            "Gekauft",
                            text: Binding(
                                get: {
                                    model.purchasedQuantityTexts[
                                        PurchaseAllocationKey(
                                            projectID: source.projectID,
                                            typeID: position.typeID
                                        )
                                    ] ?? ""
                                },
                                set: {
                                    model.setPurchasedQuantityText(
                                        $0,
                                        projectID: source.projectID,
                                        typeID: position.typeID
                                    )
                                }
                            )
                        )
                        .frame(width: 105)
                        .multilineTextAlignment(.trailing)
                        .monospacedDigit()
                        .accessibilityLabel(
                            "Gekaufte Menge \(position.name) für Projekt \(source.projectName), höchstens \(NexusNumberFormat.quantity(source.targetQuantity))"
                        )
                    }
                }
            }
            .padding(.top, 8)
        } label: {
            HStack(spacing: 10) {
                Image(
                    systemName: position.isPurchased
                        ? "checkmark.circle.fill"
                        : "cart"
                )
                .foregroundStyle(
                    position.isPurchased ? NexusTheme.teal : .orange
                )
                VStack(alignment: .leading, spacing: 2) {
                    Text(position.name)
                        .fontWeight(.semibold)
                    Text("Type-ID \(position.typeID)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Text(
                    "Ziel \(NexusNumberFormat.quantity(position.targetQuantity)) · gekauft \(NexusNumberFormat.quantity(position.purchasedQuantity)) · offen \(NexusNumberFormat.quantity(position.remainingQuantity))"
                )
                .font(.caption)
                .monospacedDigit()
                Button("Gekauft") {
                    model.markPurchased(typeID: position.typeID)
                }
                .disabled(position.isPurchased)
                .accessibilityLabel(
                    "\(position.name) für alle Projekte als gekauft markieren"
                )
                Button("Offen") {
                    model.resetPurchased(typeID: position.typeID)
                }
                .disabled(position.purchasedQuantity == 0)
                .accessibilityLabel(
                    "Kaufzuordnung für \(position.name) zurücksetzen"
                )
            }
            .accessibilityElement(children: .contain)
        }
        .padding(12)
        .background(
            Color.secondary.opacity(0.07),
            in: RoundedRectangle(cornerRadius: 10)
        )
    }

    private var actions: some View {
        HStack {
            Button("Vorschau berechnen") {
                run(operation: .purchasingLoad) {
                    try await model.calculatePreview()
                }
            }
            .disabled(
                model.isPreviewCurrent
                    || model.isLoading
                    || model.isPreviewing
                    || model.isSaving
            )
            Button("Fortschritt speichern") {
                showingConfirmation = true
            }
            .buttonStyle(.borderedProminent)
            .disabled(!model.canApply)
            Spacer()
            if model.copiedTextList {
                Label("Kopiert", systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(NexusTheme.teal)
            }
            Button("Text kopieren") {
                let pasteboard = NSPasteboard.general
                pasteboard.clearContents()
                pasteboard.setString(
                    model.textList,
                    forType: .string
                )
                model.markTextListCopied()
            }
            .disabled(model.textList.isEmpty)
            Button("CSV sichern") {
                exportDocument = PurchasingCSVDocument(
                    text: model.csv
                )
                showingExporter = true
            }
            .disabled(model.csv.isEmpty)
        }
    }

    private func metric(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(.title3.bold())
                .monospacedDigit()
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(
            Color.secondary.opacity(0.07),
            in: RoundedRectangle(cornerRadius: 8)
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(title): \(value)")
    }

    private func load() async {
        do {
            try await model.load()
            errorMessage = nil
        } catch {
            if !(error is CancellationError) {
                errorMessage =
                    "Die projektübergreifende Einkaufsliste konnte nicht geladen werden."
                reportError(error, .purchasingLoad)
            }
        }
    }

    private func run(
        operation: NexusOperation,
        _ work: @escaping @MainActor () async throws -> Void
    ) {
        Task {
            do {
                try await work()
                errorMessage = nil
            } catch {
                if !(error is CancellationError) {
                    errorMessage =
                        "Der Einkaufsworkflow konnte nicht abgeschlossen werden."
                    reportError(error, operation)
                }
            }
        }
    }
}

struct PurchasingCSVDocument: FileDocument {
    static var readableContentTypes: [UTType] {
        [.commaSeparatedText]
    }

    let text: String

    init(text: String) {
        self.text = text
    }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents,
              let text = String(data: data, encoding: .utf8) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.text = text
    }

    func fileWrapper(
        configuration: WriteConfiguration
    ) throws -> FileWrapper {
        FileWrapper(
            regularFileWithContents: Data(text.utf8)
        )
    }
}
