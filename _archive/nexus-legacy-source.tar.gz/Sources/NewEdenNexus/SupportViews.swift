import SwiftUI
import NewEdenNexusApplication

struct SynchronizationView: View {
    @ObservedObject var model: AccountsViewModel

    var body: some View {
        List {
            Section("ESI-Synchronisation") {
                if model.accounts.isEmpty {
                    Text("Verbinde zuerst einen Charakter.")
                        .foregroundStyle(.secondary)
                }
                ForEach(model.accounts) { account in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(account.name)
                                .fontWeight(.medium)
                            Text(
                                account.lastSync?.formatted(
                                    date: .abbreviated,
                                    time: .shortened
                                ) ?? "Noch nicht synchronisiert"
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        }
                        Spacer()
                            Text(account.syncState)
                                .font(.caption)
                            Text(permissionSummary(account))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 5)
                }
            }
            Section("Basisumfang") {
                Label(
                    "SSO-Verbindung und sichere Token-Erneuerung",
                    systemImage: "checkmark.circle.fill"
                )
                Label(
                    "Assets, Blueprints und Industry Jobs: drei Leserechte",
                    systemImage: "checkmark.circle.fill"
                )
                Label(
                    "Wallet: getrenntes optionales viertes Leserecht",
                    systemImage: "wallet.pass"
                )
                Label(
                    "Lokale Daten bleiben offline verfügbar",
                    systemImage: "externaldrive.fill"
                )
            }
        }
        .navigationTitle("Synchronisation")
        .task {
            await model.load()
        }
    }

    private func permissionSummary(
        _ account: EVECharacterAccount
    ) -> String {
        guard account.authorizationUpdatedAt != nil else {
            return "Berechtigungsstand lokal nicht bestätigt"
        }
        let personal = EVEAuthorizationScope.personalIndustry.filter {
            account.authorizes($0)
        }.count
        return "\(personal)/3 Produktionsrechte"
            + (
                account.authorizes(EVEAuthorizationScope.wallet)
                    ? " · Wallet erlaubt"
                    : " · Wallet nicht erlaubt"
            )
    }
}

struct RoadmapView: View {
    private let stages = [
        (
            "Lokales Fundament",
            "Native App, Datenbank, Backups, Navigation und SSO-PKCE",
            true
        ),
        (
            "Produktionsplaner",
            "SDE, T1/T2, Invention, Reaktionen und Produktionsgraph",
            true
        ),
        (
            "Lokaler MVP-Workflow",
            "Lager, Reservierungen, Bauen/Kaufen, Preise und Einkauf",
            true
        ),
        (
            "Persönliche EVE-Daten",
            "Assets, Blueprints, aktive Jobs, Marktpreise und Wallet",
            true
        ),
        (
            "Aktuelle Restabnahme",
            "Projektzuordnung und lokale Steuerungsbereinigung",
            false
        ),
        (
            "Optional später",
            "Corporation, Cloud, Optimierung und öffentliche Verteilung",
            false
        )
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Entwicklungsstruktur").font(.largeTitle.bold())
                Text("Die Reihenfolge folgt dem Projektbuch: erst ein belastbares Fundament, dann ein nutzbarer Produktionskern.").foregroundStyle(.secondary)
                ForEach(Array(stages.enumerated()), id: \.offset) { index, stage in
                    HStack(alignment: .top, spacing: 16) {
                        ZStack { Circle().fill(stage.2 ? NexusTheme.teal : Color.secondary.opacity(0.18)).frame(width: 34, height: 34); Text("\(index + 1)").font(.callout.bold()).foregroundStyle(stage.2 ? Color.white : Color.secondary) }
                        VStack(alignment: .leading, spacing: 5) { Text(stage.0).font(.headline); Text(stage.1).foregroundStyle(.secondary) }
                    }.padding(16).frame(maxWidth: .infinity, alignment: .leading).background(NexusTheme.panel, in: RoundedRectangle(cornerRadius: 12))
                }
            }.padding(28).frame(maxWidth: 850)
        }.navigationTitle("Roadmap")
    }
}

struct SettingsView: View {
    @EnvironmentObject private var runtime: NexusAppRuntime
    @AppStorage("eve.clientID")
    private var clientID = EVEPublicConfiguration.clientID
    @AppStorage("eve.redirectURI")
    private var redirectURI = EVEPublicConfiguration.redirectURI

    var body: some View {
        TabView {
            Group {
                if let model = runtime.sdeManagement {
                    SDEDataManagementView(model: model)
                } else {
                    ProgressView("SDE-Verwaltung wird vorbereitet …")
                }
            }
            .tabItem {
                Label("EVE-Daten", systemImage: "externaldrive.badge.icloud")
            }

            if runtime.isRecoveryAvailable {
                LocalRecoveryView()
                    .tabItem {
                        Label(
                            "Sicherung",
                            systemImage: "externaldrive.badge.timemachine"
                        )
                    }
            }

            Form {
                Section("EVE Online SSO") {
                    TextField("Client-ID", text: $clientID)
                    TextField("Callback-URL", text: $redirectURI)
                    Text("Im EVE Developer Portal exakt http://localhost:52721/callback registrieren. Die App startet beim Login lokal einen kurzlebigen Listener und verwendet PKCE ohne Client-Secret.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Section("Angeforderte Berechtigungen") {
                    Label(
                        "Öffentliche Charakterdaten benötigen keinen Scope",
                        systemImage: "person.text.rectangle"
                    )
                    Text(
                        "Der normale Login fordert genau drei Leserechte "
                            + "für Assets, Blueprints und persönliche "
                            + "Industry Jobs. Walletdaten bleiben davon "
                            + "getrennt und werden erst nach einer eigenen "
                            + "Erklärung und Neuautorisierung angefordert."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Label(
                        "Optional: Wallet-Kontostand, Journal und "
                            + "Transaktionen",
                        systemImage: "wallet.pass"
                    )
                    Text(
                        "Der optionale vierte Scope lautet "
                            + "esi-wallet.read_character_wallet.v1. "
                            + "Er verändert weder Projekte noch Planwerte "
                            + "automatisch."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    if let model = runtime.accountManagement {
                        ForEach(model.accounts) { account in
                            LabeledContent(
                                account.name,
                                value: permissionSummary(account)
                            )
                        }
                    }
                }
                Section("Datenschutz") {
                    Label(
                        "Refresh-Tokens: macOS-Schlüsselbund",
                        systemImage: "key.fill"
                    )
                    Label(
                        "Fachdaten: lokale SwiftData-Datenbank",
                        systemImage: "externaldrive.fill"
                    )
                    Text(
                        "Nicht geheime Berechtigungsmetadaten werden lokal "
                            + "gespeichert. Beim Trennen werden Token, "
                            + "Metadaten und persönliche Snapshots gelöscht; "
                            + "Produktionsprojekte und manuelle Bestände "
                            + "bleiben erhalten."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
            }
            .formStyle(.grouped)
            .padding()
            .tabItem {
                Label("SSO", systemImage: "person.badge.key")
            }
            .task {
                await runtime.accountManagement?.load()
            }

            if let model = runtime.sdeManagement {
                SDELegalNoticesView(model: model)
                    .tabItem {
                        Label(
                            "Rechtliche Hinweise",
                            systemImage: "checkmark.shield"
                        )
                    }
            }
        }
    }

    private func permissionSummary(
        _ account: EVECharacterAccount
    ) -> String {
        guard account.authorizationUpdatedAt != nil else {
            return "nicht lokal bestätigt"
        }
        let personal = EVEAuthorizationScope.personalIndustry.filter {
            account.authorizes($0)
        }.count
        return "\(personal)/3 Produktion"
            + (
                account.authorizes(EVEAuthorizationScope.wallet)
                    ? ", Wallet erlaubt"
                    : ", Wallet nicht erlaubt"
            )
    }
}
