import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum SafetyStockViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case invalidQuantity(typeID: Int64, field: String)
    case previewRequired
}

struct SafetyStockFieldTexts: Equatable {
    var safety = ""
    var minimum = ""
    var warning = ""
    var target = ""
}

@MainActor
final class SafetyStockViewModel: ObservableObject {
    @Published private(set) var preview: SafetyStockPreview?
    @Published private(set) var isLoading = false
    @Published private(set) var isPreviewing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreviewCurrent = false
    @Published private(set) var fieldTexts:
        [Int64: SafetyStockFieldTexts] = [:]

    private let service: any SafetyStockManaging
    private var projectID: UUID?

    init(service: any SafetyStockManaging) {
        self.service = service
    }

    var canApply: Bool {
        preview != nil && isPreviewCurrent && !isSaving
    }

    func load(projectID: UUID) async throws {
        guard !isBusy else {
            throw SafetyStockViewModelError.operationAlreadyRunning
        }
        self.projectID = projectID
        isLoading = true
        defer { isLoading = false }
        let loaded = try await service.preview(
            projectID: projectID,
            drafts: nil
        )
        try Task.checkCancellation()
        applyToDraft(loaded.proposedPolicies)
        preview = loaded
        isPreviewCurrent = true
    }

    func texts(typeID: Int64) -> SafetyStockFieldTexts {
        fieldTexts[typeID] ?? .init()
    }

    func setText(
        _ text: String,
        typeID: Int64,
        keyPath: WritableKeyPath<SafetyStockFieldTexts, String>
    ) {
        var values = fieldTexts[typeID] ?? .init()
        values[keyPath: keyPath] = text
        fieldTexts[typeID] = values
        isPreviewCurrent = false
    }

    func calculatePreview() async throws {
        guard !isBusy else {
            throw SafetyStockViewModelError.operationAlreadyRunning
        }
        guard let projectID else {
            throw SafetyStockViewModelError.previewRequired
        }
        let drafts = try makeDrafts()
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await service.preview(
            projectID: projectID,
            drafts: drafts
        )
        try Task.checkCancellation()
        preview = calculated
        isPreviewCurrent = true
    }

    func applyConfirmedPreview() async throws {
        guard !isBusy else {
            throw SafetyStockViewModelError.operationAlreadyRunning
        }
        guard let preview, isPreviewCurrent else {
            throw SafetyStockViewModelError.previewRequired
        }
        isSaving = true
        defer { isSaving = false }
        let saved = try await service.apply(preview, confirmed: true)
        self.preview = saved
        applyToDraft(saved.proposedPolicies)
        isPreviewCurrent = true
    }

    private var isBusy: Bool {
        isLoading || isPreviewing || isSaving
    }

    private func makeDrafts() throws -> [SafetyStockPolicyDraft] {
        try fieldTexts.compactMap { typeID, texts in
            let safetyText = trimmed(texts.safety)
            let minimumText = trimmed(texts.minimum)
            let warningText = trimmed(texts.warning)
            let targetText = trimmed(texts.target)
            guard !safetyText.isEmpty
                    || !minimumText.isEmpty
                    || !warningText.isEmpty
                    || !targetText.isEmpty else {
                return nil
            }
            return SafetyStockPolicyDraft(
                typeID: typeID,
                safetyStockQuantity: try quantity(
                    safetyText,
                    defaultValue: 0,
                    typeID: typeID,
                    field: "Sicherheitsbestand"
                ),
                minimumQuantity: try optionalQuantity(
                    minimumText,
                    typeID: typeID,
                    field: "Mindestbestand"
                ),
                warningQuantity: try optionalQuantity(
                    warningText,
                    typeID: typeID,
                    field: "Warnschwelle"
                ),
                targetQuantity: try optionalQuantity(
                    targetText,
                    typeID: typeID,
                    field: "Zielbestand"
                )
            )
        }
    }

    private func applyToDraft(
        _ policies: [SafetyStockPolicySnapshot]
    ) {
        fieldTexts = Dictionary(
            uniqueKeysWithValues: policies.map { policy in
                (
                    policy.typeID,
                    SafetyStockFieldTexts(
                        safety: policy.safetyStockQuantity == 0
                            ? ""
                            : String(policy.safetyStockQuantity),
                        minimum: policy.minimumQuantity.map(String.init)
                            ?? "",
                        warning: policy.warningQuantity.map(String.init)
                            ?? "",
                        target: policy.targetQuantity.map(String.init)
                            ?? ""
                    )
                )
            }
        )
    }

    private func quantity(
        _ text: String,
        defaultValue: Int64,
        typeID: Int64,
        field: String
    ) throws -> Int64 {
        guard !text.isEmpty else { return defaultValue }
        guard let value = Int64(text), value >= 0 else {
            throw SafetyStockViewModelError.invalidQuantity(
                typeID: typeID,
                field: field
            )
        }
        return value
    }

    private func optionalQuantity(
        _ text: String,
        typeID: Int64,
        field: String
    ) throws -> Int64? {
        guard !text.isEmpty else { return nil }
        return try quantity(
            text,
            defaultValue: 0,
            typeID: typeID,
            field: field
        )
    }

    private func trimmed(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
