import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct ProjectsView: View {
    @ObservedObject var model: ProjectLifecycleViewModel
    @ObservedObject var graphModel: ProductionGraphViewModel
    @ObservedObject var buildOrBuyModel:
        BuildOrBuyWorkspaceViewModel
    @ObservedObject var availabilityModel: InventoryAvailabilityViewModel
    @ObservedObject var safetyStockModel: SafetyStockViewModel
    @ObservedObject var reservationModel:
        ProjectReservationViewModel
    @ObservedObject var conflictModel:
        ReservationConflictViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @State private var editor: ProjectEditorContext?
    @State private var showingArchiveConfirmation = false
    @State private var operationTask: Task<Void, Never>?
    @State private var graphProject: ProductionProjectSnapshot?

    var body: some View {
        Group {
            if model.isLoading && model.projects.isEmpty {
                ProgressView("Projekte werden geladen …")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if model.projects.isEmpty {
                emptyState
            } else {
                projectTable
            }
        }
        .navigationTitle("Produktionsprojekte")
        .toolbar { projectToolbar }
        .task(id: model.scope) {
            await loadProjects()
        }
        .onDisappear {
            operationTask?.cancel()
        }
        .sheet(item: $editor) { context in
            ProjectEditorSheet(
                model: model,
                project: context.project,
                save: { draft in
                    if let project = context.project {
                        try await model.update(id: project.id, draft: draft)
                    } else {
                        try await model.create(draft: draft)
                    }
                },
                reportError: {
                    runtime.report($0, operation: .projectSave)
                }
            )
        }
        .sheet(item: $graphProject) { project in
            ProductionGraphView(
                project: project,
                model: graphModel,
                buildOrBuyModel: buildOrBuyModel,
                availabilityModel: availabilityModel,
                safetyStockModel: safetyStockModel,
                reservationModel: reservationModel,
                conflictModel: conflictModel
            )
        }
        .confirmationDialog(
            "Projekt archivieren?",
            isPresented: $showingArchiveConfirmation,
            titleVisibility: .visible
        ) {
            Button("Archivieren", role: .destructive) {
                runMutation {
                    try await model.archiveSelected()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Das Projekt bleibt lokal erhalten und kann im Archiv wiederhergestellt werden."
            )
        }
    }

    private var emptyState: some View {
        ContentUnavailableView {
            Label(emptyTitle, systemImage: emptySymbol)
        } description: {
            Text(emptyDescription)
        } actions: {
            if model.scope != .archived {
                Button("Projekt anlegen") {
                    editor = ProjectEditorContext(project: nil)
                }
                .buttonStyle(.borderedProminent)
                .accessibilityLabel("Neues Produktionsprojekt anlegen")
            }
            Button("Erneut laden") {
                runLoad()
            }
            .accessibilityLabel("Produktionsprojekte erneut laden")
        }
    }

    private var projectTable: some View {
        Table(model.projects, selection: $model.selectedProjectID) {
            TableColumn("Projekt") { project in
                VStack(alignment: .leading, spacing: 2) {
                    Text(project.name)
                        .fontWeight(.medium)
                    if let targetDate = project.targetDate {
                        Text(targetDate, style: .date)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            TableColumn("Zielprodukt") { project in
                Text(project.productName)
            }
            TableColumn("Menge") { project in
                Text(NexusNumberFormat.quantity(project.targetQuantity))
                    .monospacedDigit()
            }
            .width(min: 80, ideal: 100)
            TableColumn("ME") { project in
                Text(
                    project.target?.activity == .reaction
                        ? "–"
                        : "\(project.materialEfficiency) %"
                )
                .monospacedDigit()
            }
            .width(60)
            TableColumn("Status") { project in
                Text(project.status.rawValue)
                    .foregroundStyle(statusColor(project.status))
            }
            .width(min: 120, ideal: 150)
            TableColumn("Priorität") { project in
                Text("P\(project.priority)")
                    .monospacedDigit()
            }
            .width(70)
        }
        .contextMenu(forSelectionType: UUID.self) { selection in
            if selection.count == 1 {
                Button("Bearbeiten") {
                    openEditor()
                }
                .disabled(!model.canEdit)
                Button("Duplizieren") {
                    runMutation {
                        try await model.duplicateSelected()
                    }
                }
                .disabled(!model.canDuplicate)
                Button("Produktionsgraph") {
                    openGraph()
                }
                .disabled(model.selectedProject?.target == nil)
                Divider()
                if model.canRestore {
                    Button("Wiederherstellen") {
                        runMutation {
                            try await model.restoreSelected()
                        }
                    }
                } else {
                    Button("Archivieren") {
                        showingArchiveConfirmation = true
                    }
                    .disabled(!model.canArchive)
                }
            }
        } primaryAction: { _ in
            openEditor()
        }
        .overlay(alignment: .topTrailing) {
            if model.isLoading || model.isMutating {
                ProgressView()
                    .controlSize(.small)
                    .padding(12)
                    .accessibilityLabel("Projektvorgang läuft")
            }
        }
    }

    @ToolbarContentBuilder
    private var projectToolbar: some ToolbarContent {
        ToolbarItemGroup {
            Picker("Projektfilter", selection: $model.scope) {
                Text("Nicht archiviert")
                    .tag(ProductionProjectListScope.current)
                Text("Archiv")
                    .tag(ProductionProjectListScope.archived)
                Text("Alle")
                    .tag(ProductionProjectListScope.all)
            }
            .pickerStyle(.segmented)
            .frame(width: 300)
            .accessibilityLabel("Produktionsprojekte filtern")

            Button {
                runLoad()
            } label: {
                Label("Aktualisieren", systemImage: "arrow.clockwise")
            }
            .keyboardShortcut("r", modifiers: .command)
            .disabled(model.isLoading || model.isMutating)
            .accessibilityLabel("Produktionsprojekte aktualisieren")

            Menu {
                ForEach(model.availableStatusTransitions, id: \.self) {
                    status in
                    Button(status.rawValue) {
                        runMutation {
                            try await model.transition(to: status)
                        }
                    }
                }
            } label: {
                Label("Status ändern", systemImage: "arrow.triangle.2.circlepath")
            }
            .disabled(
                model.availableStatusTransitions.isEmpty
                    || model.isMutating
            )
            .accessibilityLabel("Projektstatus ändern")

            Button {
                openEditor()
            } label: {
                Label("Bearbeiten", systemImage: "pencil")
            }
            .keyboardShortcut("e", modifiers: .command)
            .disabled(!model.canEdit || model.isMutating)
            .accessibilityLabel("Ausgewähltes Produktionsprojekt bearbeiten")

            Button {
                openGraph()
            } label: {
                Label(
                    "Produktionsgraph",
                    systemImage: "point.3.connected.trianglepath.dotted"
                )
            }
            .keyboardShortcut("g", modifiers: .command)
            .disabled(
                model.selectedProject?.target == nil
                    || model.isMutating
            )
            .accessibilityLabel(
                "Produktionsgraph des ausgewählten Projekts öffnen"
            )

            Button {
                runMutation {
                    try await model.duplicateSelected()
                }
            } label: {
                Label("Duplizieren", systemImage: "plus.square.on.square")
            }
            .keyboardShortcut("d", modifiers: .command)
            .disabled(!model.canDuplicate || model.isMutating)
            .accessibilityLabel("Ausgewähltes Produktionsprojekt duplizieren")

            if model.canRestore {
                Button {
                    runMutation {
                        try await model.restoreSelected()
                    }
                } label: {
                    Label("Wiederherstellen", systemImage: "arrow.uturn.backward")
                }
                .disabled(model.isMutating)
                .accessibilityLabel(
                    "Ausgewähltes Produktionsprojekt wiederherstellen"
                )
            } else {
                Button {
                    showingArchiveConfirmation = true
                } label: {
                    Label("Archivieren", systemImage: "archivebox")
                }
                .disabled(!model.canArchive || model.isMutating)
                .accessibilityLabel(
                    "Ausgewähltes Produktionsprojekt archivieren"
                )
            }

            Button {
                editor = ProjectEditorContext(project: nil)
            } label: {
                Label("Neues Projekt", systemImage: "plus")
            }
            .keyboardShortcut("n", modifiers: .command)
            .disabled(model.isMutating)
            .accessibilityLabel("Neues Produktionsprojekt anlegen")
        }
    }

    private var emptyTitle: String {
        switch model.scope {
        case .current:
            "Noch keine Projekte"
        case .archived:
            "Das Archiv ist leer"
        case .all:
            "Keine Projekte vorhanden"
        }
    }

    private var emptyDescription: String {
        switch model.scope {
        case .current:
            "Lege ein lokales Produktionsziel an."
        case .archived:
            "Archivierte Projekte werden hier angezeigt und können wiederhergestellt werden."
        case .all:
            "Für den gewählten Filter wurden keine Produktionsprojekte gefunden."
        }
    }

    private var emptySymbol: String {
        model.scope == .archived ? "archivebox" : "shippingbox"
    }

    private func statusColor(_ status: ProjectStatus) -> Color {
        switch status {
        case .completed:
            NexusTheme.teal
        case .archived:
            .secondary
        case .active:
            NexusTheme.accent
        default:
            .primary
        }
    }

    private func openEditor() {
        guard model.canEdit, let project = model.selectedProject else {
            return
        }
        editor = ProjectEditorContext(project: project)
    }

    private func openGraph() {
        guard let project = model.selectedProject,
              project.target != nil else {
            return
        }
        graphProject = project
    }

    private func runLoad() {
        operationTask?.cancel()
        operationTask = Task {
            await loadProjects()
        }
    }

    private func loadProjects() async {
        do {
            try await model.load()
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .projectLoad,
                retry: { runLoad() }
            )
        }
    }

    private func runMutation(
        _ operation: @escaping @MainActor () async throws -> Void
    ) {
        operationTask?.cancel()
        operationTask = Task {
            do {
                try await operation()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: .projectSave)
            }
        }
    }
}
