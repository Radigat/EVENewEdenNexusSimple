import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct ReservationConflictSheet: View {
    let project: ProductionProjectSnapshot
    @ObservedObject var model: ReservationConflictViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @Environment(\.dismiss) private var dismiss
    @State private var task: Task<Void, Never>?
    @State private var showingConfirmation = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header
            Divider()
            content
            Divider()
            footer
        }
        .padding(24)
        .frame(minWidth: 980, idealWidth: 1_160, minHeight: 700)
        .task { await load() }
        .onDisappear { task?.cancel() }
        .confirmationDialog(
            "Konfliktauflösung übernehmen?",
            isPresented: $showingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Bestätigte Auflösung übernehmen") {
                run(operation: .reservationConflictSave) {
                    try await model.applyConfirmedPreview()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "\(NexusNumberFormat.quantity(model.preview?.changedReservations.count ?? 0)) Reservierung(en) werden atomar reduziert oder freigegeben. Physische Bestände werden nicht verändert."
            )
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Reservierungskonflikte")
                .font(.title2.bold())
            Text(project.name)
                .foregroundStyle(.secondary)
            Label(
                "Die Prüfung verwendet die P22-/P23-Verfügbarkeit dieses Projekts. Vorschläge verändern nichts ohne Vorschau und Bestätigung.",
                systemImage: "exclamationmark.lock"
            )
            .font(.callout)
            .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var content: some View {
        if model.isLoading && model.preview == nil {
            ProgressView("Reservierungskonflikte werden geprüft …")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let preview = model.preview {
            if preview.analysisBefore.conflicts.isEmpty {
                ContentUnavailableView {
                    Label(
                        "Keine Reservierungskonflikte",
                        systemImage: "checkmark.shield"
                    )
                } description: {
                    Text(
                        "Die aktiven Projektreservierungen passen zum aktuellen Bedarf und zum nach Sicherheitsbeständen verfügbaren Bestand."
                    )
                }
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        summary(preview)
                        if !model.isPreviewCurrent {
                            Label(
                                "Entscheidungen geändert – Auflösung erneut prüfen.",
                                systemImage: "exclamationmark.triangle"
                            )
                            .foregroundStyle(.orange)
                        } else if preview.analysisAfter.hasConflicts {
                            Label(
                                "Die Vorschau enthält weiterhin Konflikte.",
                                systemImage: "xmark.octagon"
                            )
                            .foregroundStyle(.red)
                        } else if !preview.resolutions.isEmpty {
                            Label(
                                "Die Vorschau löst alle sichtbaren Konflikte.",
                                systemImage: "checkmark.circle"
                            )
                            .foregroundStyle(.green)
                        }
                        ForEach(
                            preview.analysisBefore.conflicts
                        ) { conflict in
                            conflictCard(conflict)
                        }
                    }
                }
            }
        } else {
            ContentUnavailableView {
                Label(
                    "Konfliktprüfung nicht verfügbar",
                    systemImage: "exclamationmark.lock"
                )
            } description: {
                Text(
                    "Ein aktueller Produktionsgraph sowie gültige P22-, P23- und P24-Daten sind erforderlich."
                )
            }
        }
    }

    private func summary(
        _ preview: ReservationConflictPreview
    ) -> some View {
        HStack(spacing: 24) {
            summaryTile(
                "Konfliktmaterialien",
                preview.analysisBefore.conflicts.count,
                color: .red
            )
            summaryTile(
                "Betroffene Reservierungen",
                preview.analysisBefore.affectedReservationCount,
                color: .orange
            )
            summaryTile(
                "Abgelaufen, weiter gebunden",
                preview.analysisBefore.expiredActiveReservationCount,
                color: .orange
            )
            summaryTile(
                "Nach Vorschau offen",
                preview.analysisAfter.conflicts.count,
                color: preview.analysisAfter.hasConflicts
                    ? .red
                    : .green
            )
            Spacer()
            Text(
                "Konfliktformel v\(preview.analysisBefore.formulaVersion)"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    private func summaryTile(
        _ title: String,
        _ value: Int,
        color: Color
    ) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(value))
                .font(.title3.bold())
                .foregroundStyle(color)
                .monospacedDigit()
        }
    }

    private func conflictCard(
        _ conflict: ReservationConflictLine
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(conflict.materialName)
                        .font(.headline)
                    Text("Type-ID \(conflict.typeID)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                ForEach(conflict.reasons, id: \.rawValue) {
                    Label(
                        reasonName($0),
                        systemImage: reasonSymbol($0)
                    )
                    .font(.caption)
                    .foregroundStyle(.red)
                }
            }

            Grid(
                alignment: .trailing,
                horizontalSpacing: 16,
                verticalSpacing: 4
            ) {
                valueRow(
                    "Projektbedarf",
                    conflict.requiredQuantity,
                    "Nach P23 verfügbar",
                    conflict.availableAfterSafetyStockQuantity
                )
                valueRow(
                    "Aktiv reserviert",
                    conflict.totalActiveReservedQuantity,
                    "Vorgeschlagene Reduktion",
                    conflict.requiredReductionQuantity
                )
            }
            .font(.caption)
            .monospacedDigit()

            ForEach(conflict.participants) { participant in
                participantRow(participant)
            }
        }
        .padding(12)
        .background(.secondary.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .accessibilityElement(children: .contain)
    }

    private func participantRow(
        _ participant: ReservationConflictParticipant
    ) -> some View {
        let state = model.state(reservationID: participant.id)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(participant.project.name)
                        .fontWeight(.semibold)
                    Text(
                        "Projektpriorität \(priorityName(participant.project.priority)) · Reservierungspriorität \(priorityName(participant.reservation.priority))"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                if participant.isCurrentProject {
                    Text("Aktuelles Projekt")
                        .font(.caption.bold())
                        .foregroundStyle(.blue)
                }
                if participant.isExpired {
                    Label(
                        "Abgelaufen – bleibt gebunden",
                        systemImage: "clock.badge.exclamationmark"
                    )
                    .font(.caption)
                    .foregroundStyle(.orange)
                }
                Spacer()
                Text(
                    "\(NexusNumberFormat.quantity(participant.reservation.remainingQuantity)) → \(NexusNumberFormat.quantity(participant.suggestedRemainingQuantity)) vorgeschlagen"
                )
                .monospacedDigit()
            }

            HStack {
                Picker(
                    "Entscheidung",
                    selection: stateBinding(participant.id).mode
                ) {
                    ForEach(ReservationConflictEditMode.allCases) {
                        Text($0.rawValue).tag($0)
                    }
                }
                .pickerStyle(.segmented)
                .accessibilityLabel(
                    "Konfliktentscheidung für \(participant.project.name), Type-ID \(participant.reservation.typeID)"
                )
                if state.mode == .reduce {
                    TextField(
                        "Neue aktive Restmenge",
                        text: stateBinding(participant.id).quantity
                    )
                    .frame(width: 180)
                    .accessibilityLabel(
                        "Reduzierte Restmenge für Reservierung \(participant.id.uuidString)"
                    )
                }
            }
        }
        .padding(10)
        .background(.background.opacity(0.55))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .accessibilityElement(children: .contain)
    }

    private var footer: some View {
        HStack {
            Button("Schließen") { dismiss() }
                .keyboardShortcut(.cancelAction)
            Spacer()
            if model.isPreviewing || model.isSaving {
                ProgressView(
                    model.isSaving
                        ? "Konfliktauflösung wird gespeichert …"
                        : "Konfliktauflösung wird geprüft …"
                )
                Button("Abbrechen") { task?.cancel() }
            }
            Button("Vorschläge übernehmen") {
                model.applySuggestions()
            }
            .disabled(
                model.preview?.analysisBefore.conflicts.isEmpty != false
                    || model.isLoading
                    || model.isPreviewing
                    || model.isSaving
            )
            Button("Auflösung prüfen") {
                run(operation: .reservationConflictLoad) {
                    try await model.calculatePreview()
                }
            }
            .keyboardShortcut("k", modifiers: [.command, .shift])
            .disabled(
                model.preview?.analysisBefore.conflicts.isEmpty != false
                    || model.isLoading
                    || model.isPreviewing
                    || model.isSaving
            )
            Button("Konfliktauflösung übernehmen") {
                showingConfirmation = true
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut(.defaultAction)
            .disabled(!model.canApply)
        }
    }

    private func stateBinding(
        _ reservationID: UUID
    ) -> Binding<ReservationConflictFieldState> {
        Binding(
            get: { model.state(reservationID: reservationID) },
            set: {
                model.setState(
                    $0,
                    reservationID: reservationID
                )
            }
        )
    }

    private func valueRow(
        _ leftTitle: String,
        _ leftValue: Int64?,
        _ rightTitle: String,
        _ rightValue: Int64?
    ) -> some View {
        GridRow {
            Text(leftTitle).foregroundStyle(.secondary)
            Text(leftValue.map(NexusNumberFormat.quantity) ?? "—")
            Text(rightTitle).foregroundStyle(.secondary)
            Text(rightValue.map(NexusNumberFormat.quantity) ?? "—")
        }
    }

    private func reasonName(
        _ reason: ReservationConflictReason
    ) -> String {
        switch reason {
        case .stockShortage: "Bestandskonflikt"
        case .requirementExceeded: "Bedarf überschritten"
        case .noLongerRequired: "Nicht mehr benötigt"
        }
    }

    private func reasonSymbol(
        _ reason: ReservationConflictReason
    ) -> String {
        switch reason {
        case .stockShortage: "shippingbox.and.arrow.backward"
        case .requirementExceeded: "arrow.up.right"
        case .noLongerRequired: "questionmark.diamond"
        }
    }

    private func priorityName(_ priority: Int) -> String {
        switch priority {
        case 1: "1 – hoch"
        case 2: "2 – mittel"
        default: "3 – normal"
        }
    }

    private func load() async {
        do {
            try await model.load(projectID: project.id)
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .reservationConflictLoad,
                retry: {
                    Task {
                        await load()
                    }
                }
            )
        }
    }

    private func run(
        operation: NexusOperation,
        action: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: operation)
            }
        }
    }
}
