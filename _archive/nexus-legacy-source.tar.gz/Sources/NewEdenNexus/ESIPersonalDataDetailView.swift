import NewEdenNexusApplication
import SwiftUI

struct ESIPersonalDataDetailView: View {
    private enum SectionKind:
        String,
        CaseIterable,
        Identifiable,
        Sendable
    {
        case assets = "Assets"
        case blueprints = "Blueprints"
        case jobs = "Industry Jobs"
        var id: Self { self }
    }

    private enum SortKind:
        String,
        CaseIterable,
        Identifiable,
        Sendable
    {
        case name = "Name"
        case quantity = "Menge"
        case location = "Ort"
        case date = "Datum"
        var id: Self { self }
    }

    private struct ProjectionKey: Hashable {
        let section: SectionKind
        let query: String
        let sort: SortKind
        let typeNameCount: Int
        let locationNameCount: Int
    }

    private struct ProjectionOutput: Sendable {
        let locationIndex: ESIPersonalDataLocationIndex
        let assets: ESIPersonalDataGroupedPage<ESICharacterAsset>?
        let blueprints:
            ESIPersonalDataGroupedPage<ESICharacterBlueprint>?
        let jobs:
            ESIPersonalDataGroupedPage<ESICharacterIndustryJob>?
    }

    @EnvironmentObject private var runtime: NexusAppRuntime
    @Environment(\.dismiss) private var dismiss
    let account: EVECharacterAccount
    let snapshot: ESIPersonalDataSnapshot
    @ObservedObject var model: AccountsViewModel

    @State private var section = SectionKind.assets
    @State private var query = ""
    @State private var sort = SortKind.name
    @State private var selectedProjectID: UUID?
    @State private var selectedAvailabilityLocations: Set<Int64> = []
    @State private var confirmsAvailabilityApply = false
    @State private var locationIndex = ESIPersonalDataLocationIndex()
    @State private var assetGroups = ESIPersonalDataGroupedPage<
        ESICharacterAsset
    >(groups: [], totalMatchCount: 0)
    @State private var blueprintGroups = ESIPersonalDataGroupedPage<
        ESICharacterBlueprint
    >(groups: [], totalMatchCount: 0)
    @State private var jobGroups = ESIPersonalDataGroupedPage<
        ESICharacterIndustryJob
    >(groups: [], totalMatchCount: 0)
    @State private var expandedAssetGroups = Set<String>()
    @State private var expandedBlueprintGroups = Set<String>()
    @State private var expandedJobGroups = Set<String>()
    @State private var visibleRowsByGroup: [String: Int] = [:]
    @State private var isProjecting = false

    private let rowBatchSize = 100

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            controls
            Group {
                switch section {
                case .assets:
                    assetsView
                case .blueprints:
                    blueprintsView
                case .jobs:
                    jobsView
                }
            }
            if section == .assets {
                availabilityControls
            }
        }
        .padding(20)
        .frame(minWidth: 900, minHeight: 650)
        .task {
            await model.loadPersonalTypeNames(
                characterID: account.characterID
            )
            await model.loadPersonalLocationNames(
                characterID: account.characterID
            )
        }
        .task(id: projectionKey) {
            await refreshProjection()
        }
        .onChange(of: selectedProjectID) {
            Task {
                await model.discardAssetAvailabilityPreview()
                await model.discardAssetAvailabilityRemoval()
            }
        }
        .onChange(of: selectedAvailabilityLocations) {
            Task {
                await model.discardAssetAvailabilityPreview()
            }
        }
        .confirmationDialog(
            "EVE-Assets für dieses Projekt verwenden?",
            isPresented: $confirmsAvailabilityApply
        ) {
            Button("Auswahl jetzt übernehmen") {
                Task { await applyAvailability() }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Erst diese zweite Bestätigung speichert die Auswahl. "
                    + "Manuelle und importierte Bestände bleiben unverändert."
            )
        }
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("\(account.name) – persönliche ESI-Daten")
                    .font(.title2.bold())
                Text("Quelle: lokaler ESI-Lesesnapshot")
                    .font(.caption)
                Text(
                    "Abruf \(snapshot.synchronizedAt.formatted(date: .abbreviated, time: .standard))"
                        + " · \(freshnessText)"
                        + " · Compatibility-Date "
                        + metadata.compatibilityDate
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                if model.personalDetailLoadingCharacterID
                    == account.characterID {
                    ProgressView("Lokale Typnamen werden geladen …")
                        .controlSize(.small)
                }
                if let error = model.personalDetailErrorDescription {
                    Label(error, systemImage: "exclamationmark.triangle")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            }
            Spacer()
            Button("Schließen") {
                dismiss()
            }
            .keyboardShortcut(.cancelAction)
        }
    }

    private var controls: some View {
        HStack {
            Picker("Bereich", selection: $section) {
                ForEach(SectionKind.allCases) {
                    Text($0.rawValue).tag($0)
                }
            }
            .pickerStyle(.segmented)
            TextField("Name, Ort oder Status suchen", text: $query)
                .textFieldStyle(.roundedBorder)
            Picker("Sortierung", selection: $sort) {
                ForEach(SortKind.allCases) {
                    Text($0.rawValue).tag($0)
                }
            }
            .frame(width: 150)
        }
    }

    @ViewBuilder
    private var assetsView: some View {
        if assetGroups.groups.isEmpty {
            ContentUnavailableView(
                "Keine passenden Assets",
                systemImage: "shippingbox",
                description: Text(
                    snapshot.assets.isEmpty
                        ? "Der lokale ESI-Snapshot enthält keine Assets."
                        : "Passe die globale Suche an."
                )
            )
        } else {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(
                        "\(NexusNumberFormat.quantity(assetGroups.totalMatchCount)) Assets an "
                            + "\(NexusNumberFormat.quantity(assetGroups.groups.count)) Stationen"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Spacer()
                    projectionProgress
                }
                List {
                    ForEach(assetGroups.groups) { group in
                        DisclosureGroup(
                            isExpanded: assetExpansionBinding(group.id)
                        ) {
                            if expandedAssetGroups.contains(group.id) {
                                ForEach(
                                    Array(
                                        group.items.prefix(
                                            visibleRowCount(for: group.id)
                                        )
                                    ),
                                    id: \.itemID
                                ) { asset in
                                    assetRow(asset)
                                }
                                moreRowsButton(
                                    groupID: group.id,
                                    total: group.items.count
                                )
                            }
                        } label: {
                            stationGroupLabel(
                                name: group.name,
                                count: group.items.count,
                                noun: "Assets",
                                isExpanded: assetExpansionBinding(group.id)
                            )
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var blueprintsView: some View {
        if blueprintGroups.groups.isEmpty {
            ContentUnavailableView(
                "Keine passenden Blueprints",
                systemImage: "doc.text.magnifyingglass",
                description: Text(
                    snapshot.blueprints.isEmpty
                        ? "Der lokale ESI-Snapshot enthält keine Blueprints."
                        : "Passe die Suche an."
                )
            )
        } else {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(
                        "\(NexusNumberFormat.quantity(blueprintGroups.totalMatchCount)) Blueprints an "
                            + "\(NexusNumberFormat.quantity(blueprintGroups.groups.count)) Stationen"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Spacer()
                    projectionProgress
                }
                List {
                    ForEach(blueprintGroups.groups) { group in
                        DisclosureGroup(
                            isExpanded: blueprintExpansionBinding(
                                group.id
                            )
                        ) {
                            if expandedBlueprintGroups.contains(group.id) {
                                ForEach(
                                    Array(
                                        group.items.prefix(
                                            visibleRowCount(for: group.id)
                                        )
                                    ),
                                    id: \.itemID
                                ) { blueprint in
                                    blueprintRow(blueprint)
                                }
                                moreRowsButton(
                                    groupID: group.id,
                                    total: group.items.count
                                )
                            }
                        } label: {
                            stationGroupLabel(
                                name: group.name,
                                count: group.items.count,
                                noun: "Blueprints",
                                isExpanded: blueprintExpansionBinding(
                                    group.id
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var jobsView: some View {
        if jobGroups.groups.isEmpty {
            ContentUnavailableView(
                "Keine aktiven Industry Jobs",
                systemImage: "hammer",
                description: Text(
                    snapshot.industryJobs.isEmpty
                        ? "Der lokale ESI-Snapshot enthält keine Jobs."
                        : "Ausgelieferte und andere historische Jobs "
                            + "bleiben gespeichert, werden hier aber "
                            + "nicht angezeigt."
                )
            )
        } else {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Label(
                        "\(NexusNumberFormat.quantity(jobGroups.totalMatchCount)) aktive Jobs an "
                            + "\(NexusNumberFormat.quantity(jobGroups.groups.count)) Stationen",
                        systemImage: "play.circle"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Spacer()
                    projectionProgress
                }
                List {
                    ForEach(jobGroups.groups) { group in
                        DisclosureGroup(
                            isExpanded: jobExpansionBinding(group.id)
                        ) {
                            if expandedJobGroups.contains(group.id) {
                                ForEach(
                                    Array(
                                        group.items.prefix(
                                            visibleRowCount(for: group.id)
                                        )
                                    ),
                                    id: \.jobID
                                ) { job in
                                    jobRow(job)
                                }
                                moreRowsButton(
                                    groupID: group.id,
                                    total: group.items.count
                                )
                            }
                        } label: {
                            stationGroupLabel(
                                name: group.name,
                                count: group.items.count,
                                noun: "aktive Jobs",
                                isExpanded: jobExpansionBinding(group.id)
                            )
                        }
                    }
                }
            }
        }
    }

    private var availabilityControls: some View {
        GroupBox("Assets kontrolliert für ein Projekt verwenden") {
            VStack(alignment: .leading, spacing: 8) {
                Text(
                    "Die Auswahl bleibt eine getrennte, schreibgeschützte "
                        + "ESI-Quelle. Manuelle und importierte Bestände "
                        + "werden nicht verändert. Überschneidungen werden "
                        + "als mögliche Doppelzählung blockiert."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                HStack {
                    Picker("Projekt", selection: $selectedProjectID) {
                        Text("Projekt wählen").tag(UUID?.none)
                        ForEach(model.projects) { project in
                            Text(project.name).tag(UUID?.some(project.id))
                        }
                    }
                    .frame(width: 280)
                    Menu("EVE-Lagerorte auswählen") {
                        ForEach(assetLocationIDs, id: \.self) { id in
                            Toggle(
                                locationLabel(id),
                                isOn: Binding(
                                    get: {
                                        selectedAvailabilityLocations
                                            .contains(id)
                                    },
                                    set: { enabled in
                                        if enabled {
                                            selectedAvailabilityLocations
                                                .insert(id)
                                        } else {
                                            selectedAvailabilityLocations
                                                .remove(id)
                                        }
                                    }
                                )
                            )
                        }
                    }
                    Button("Vorschau erstellen") {
                        Task { await previewAvailability() }
                    }
                    .disabled(
                        selectedProjectID == nil
                            || selectedAvailabilityLocations.isEmpty
                    )
                }
                if let projectID = selectedProjectID,
                   let current = model.assetSelections[projectID] {
                    HStack(alignment: .firstTextBaseline) {
                        Text(activeSelectionDescription(current))
                            .font(.caption)
                            .foregroundStyle(
                                current.sourceRevision == snapshot.revision
                                    ? Color.secondary
                                    : Color.orange
                            )
                        Spacer()
                        Button(
                            "Aktive Auswahl zurücknehmen",
                            role: .destructive
                        ) {
                            Task {
                                await previewAvailabilityRemoval(
                                    projectID: projectID
                                )
                            }
                        }
                    }
                }
                if let preview = model.assetAvailabilityPreview,
                   preview.characterID == account.characterID {
                    Divider()
                    Text(
                        "\(NexusNumberFormat.quantity(preview.lines.count)) Positionen aus "
                            + "\(NexusNumberFormat.quantity(preview.selectedLocationIDs.count)) Lagerorten"
                    )
                    .fontWeight(.semibold)
                    List(preview.lines) { line in
                        HStack {
                            typeLabel(line.typeID)
                            Spacer()
                            Text(
                                "Menge \(NexusNumberFormat.quantity(line.quantity))"
                            )
                            Text(locationName(line.locationID))
                            if line.hasPossibleDoubleCount {
                                Label(
                                    "blockiert: \(NexusNumberFormat.quantity(line.manualStockQuantity)) manuell/importiert",
                                    systemImage: "exclamationmark.triangle"
                                )
                                .foregroundStyle(.orange)
                            }
                        }
                    }
                    .frame(height: 130)
                    HStack {
                        Button("Verwerfen", role: .cancel) {
                            Task {
                                await model
                                    .discardAssetAvailabilityPreview()
                            }
                        }
                        Spacer()
                        Button("Auswahl ausdrücklich übernehmen") {
                            confirmsAvailabilityApply = true
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(!preview.canApply)
                    }
                }
                if let removal =
                    model.assetAvailabilityRemovalPreview,
                   removal.characterID == account.characterID {
                    Divider()
                    VStack(alignment: .leading, spacing: 8) {
                        Label(
                            "Rücknahmevorschau",
                            systemImage: "arrow.uturn.backward.circle"
                        )
                        .fontWeight(.semibold)
                        Text(
                            "\(NexusNumberFormat.quantity(removal.lineCount)) Positionen aus "
                                + "\(NexusNumberFormat.quantity(removal.locationIDs.count)) Lagerorten "
                                + "werden aus der Projektverfügbarkeit entfernt. "
                                + "Der ESI-Snapshot und die EVE-Assets selbst "
                                + "bleiben unverändert."
                        )
                        .font(.caption)
                        Text(
                            uniqueLocationNames(removal.locationIDs)
                                .joined(separator: " · ")
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        HStack {
                            Button("Rücknahme verwerfen", role: .cancel) {
                                Task {
                                    await model
                                        .discardAssetAvailabilityRemoval()
                                }
                            }
                            Spacer()
                            Button(
                                "Auswahl wirklich zurücknehmen",
                                role: .destructive
                            ) {
                                Task {
                                    await applyAvailabilityRemoval()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private var metadata: ESIPersonalEndpointMetadata {
        switch section {
        case .assets: snapshot.assetMetadata
        case .blueprints: snapshot.blueprintMetadata
        case .jobs: snapshot.jobMetadata
        }
    }

    private var freshnessText: String {
        metadata.isFresh(at: Date())
            ? "lokaler Cache aktuell"
            : "offline-fähiger lokaler Stand, Cache abgelaufen"
    }

    private var presentation: ESIPersonalDataPresentation {
        ESIPersonalDataPresentation()
    }

    private var projectionKey: ProjectionKey {
        ProjectionKey(
            section: section,
            query: query,
            sort: sort,
            typeNameCount: model.personalTypeNames.count,
            locationNameCount: model.personalLocationNames.count
        )
    }

    private var assetLocationIDs: [Int64] {
        locationIndex.assetLocationIDs
    }

    private var detailSort: ESIPersonalDataDetailSort {
        switch sort {
        case .name: .name
        case .quantity: .quantity
        case .location: .location
        case .date: .date
        }
    }

    private func refreshProjection() async {
        isProjecting = true
        if !query.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty {
            try? await Task.sleep(for: .milliseconds(120))
        }
        guard !Task.isCancelled else { return }

        let selectedSection = section
        let selectedSort = detailSort
        let selectedQuery = query
        let typeNames = model.personalTypeNames
        let resolvedLocationNames = model.personalLocationNames
        let currentSnapshot = snapshot
        let activityNames = Dictionary(
            uniqueKeysWithValues: Set(
                currentSnapshot.industryJobs.map(\.activityID)
            ).map {
                ($0, presentation.activityName($0))
            }
        )
        let output = await Task.detached(
            priority: .userInitiated
        ) {
            let presentation = ESIPersonalDataPresentation()
            let index = presentation.locationIndex(
                snapshot: currentSnapshot,
                names: resolvedLocationNames
            )
            let projector = ESIPersonalDataDetailProjector()
            switch selectedSection {
            case .assets:
                return ProjectionOutput(
                    locationIndex: index,
                    assets: projector.groupedAssets(
                        currentSnapshot.assets,
                        names: typeNames,
                        locationNames: index.namesByLocationID,
                        query: selectedQuery,
                        sort: selectedSort
                    ),
                    blueprints: nil,
                    jobs: nil
                )
            case .blueprints:
                return ProjectionOutput(
                    locationIndex: index,
                    assets: nil,
                    blueprints: projector.groupedBlueprints(
                        currentSnapshot.blueprints,
                        names: typeNames,
                        locationNames: index.namesByLocationID,
                        query: selectedQuery,
                        sort: selectedSort
                    ),
                    jobs: nil
                )
            case .jobs:
                return ProjectionOutput(
                    locationIndex: index,
                    assets: nil,
                    blueprints: nil,
                    jobs: projector.groupedActiveJobs(
                        currentSnapshot.industryJobs,
                        names: typeNames,
                        locationNames: index.namesByLocationID,
                        activityNames: activityNames,
                        query: selectedQuery,
                        sort: selectedSort
                    )
                )
            }
        }.value
        guard !Task.isCancelled else { return }

        locationIndex = output.locationIndex
        let opensSearchResults = !selectedQuery.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty
        if let groups = output.assets {
            assetGroups = groups
            if opensSearchResults {
                expandedAssetGroups = Set(groups.groups.map(\.id))
            }
        }
        if let groups = output.blueprints {
            blueprintGroups = groups
            if opensSearchResults {
                expandedBlueprintGroups = Set(groups.groups.map(\.id))
            }
        }
        if let groups = output.jobs {
            jobGroups = groups
            if opensSearchResults {
                expandedJobGroups = Set(groups.groups.map(\.id))
            }
        }
        isProjecting = false
    }

    @ViewBuilder
    private var projectionProgress: some View {
        if isProjecting {
            ProgressView()
                .controlSize(.small)
                .accessibilityLabel("Liste wird aktualisiert")
        }
    }

    private func stationGroupLabel(
        name: String,
        count: Int,
        noun: String,
        isExpanded: Binding<Bool>
    ) -> some View {
        Button {
            isExpanded.wrappedValue.toggle()
        } label: {
            HStack {
                Label(name, systemImage: "building.2")
                    .fontWeight(.semibold)
                Spacer()
                Text("\(NexusNumberFormat.quantity(count)) \(noun)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityLabel(
            "\(name), \(NexusNumberFormat.quantity(count)) \(noun)"
        )
        .accessibilityValue(
            isExpanded.wrappedValue ? "geöffnet" : "geschlossen"
        )
        .accessibilityHint(
            isExpanded.wrappedValue ? "Station schließen" : "Station öffnen"
        )
    }

    private func assetRow(_ asset: ESICharacterAsset) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                typeLabel(asset.typeID)
                Spacer()
                Text("Menge \(NexusNumberFormat.quantity(asset.quantity))")
                    .monospacedDigit()
            }
            HStack {
                Text(
                    presentation.locationFlagName(
                        asset.locationFlag
                    )
                )
                if let copy = asset.isBlueprintCopy {
                    Text(copy ? "BPC" : "BPO")
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private func blueprintRow(
        _ blueprint: ESICharacterBlueprint
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                typeLabel(blueprint.typeID)
                Text(blueprintKind(blueprint.quantity))
                    .fontWeight(.semibold)
                Spacer()
                Text("ME \(blueprint.materialEfficiency)")
                Text("TE \(blueprint.timeEfficiency)")
                Text(
                    blueprint.runs < 0
                        ? "Runs unbegrenzt"
                        : "Runs \(NexusNumberFormat.quantity(blueprint.runs))"
                )
            }
            Text(
                presentation.locationFlagName(
                    blueprint.locationFlag
                )
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private func jobRow(
        _ job: ESICharacterIndustryJob
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                typeLabel(job.blueprintTypeID)
                Spacer()
                Text(presentation.activityName(job.activityID))
                Text("Runs \(NexusNumberFormat.quantity(job.runs))")
            }
            Text("Ergebnis: \(jobProductName(job))")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(
                "\(job.startDate.formatted(date: .abbreviated, time: .shortened)) – "
                    + job.endDate.formatted(
                        date: .abbreviated,
                        time: .shortened
                    )
            )
            .font(.caption)
        }
    }

    @ViewBuilder
    private func moreRowsButton(
        groupID: String,
        total: Int
    ) -> some View {
        let visible = visibleRowCount(for: groupID)
        if visible < total {
            Button(
                "Weitere \(NexusNumberFormat.quantity(min(rowBatchSize, total - visible))) anzeigen"
            ) {
                visibleRowsByGroup[groupID] = min(
                    total,
                    visible + rowBatchSize
                )
            }
        }
    }

    private func visibleRowCount(for groupID: String) -> Int {
        visibleRowsByGroup[groupID] ?? rowBatchSize
    }

    private func assetExpansionBinding(
        _ groupID: String
    ) -> Binding<Bool> {
        Binding(
            get: { expandedAssetGroups.contains(groupID) },
            set: { expanded in
                if expanded {
                    expandedAssetGroups.insert(groupID)
                } else {
                    expandedAssetGroups.remove(groupID)
                }
            }
        )
    }

    private func blueprintExpansionBinding(
        _ groupID: String
    ) -> Binding<Bool> {
        Binding(
            get: { expandedBlueprintGroups.contains(groupID) },
            set: { expanded in
                if expanded {
                    expandedBlueprintGroups.insert(groupID)
                } else {
                    expandedBlueprintGroups.remove(groupID)
                }
            }
        )
    }

    private func jobExpansionBinding(
        _ groupID: String
    ) -> Binding<Bool> {
        Binding(
            get: { expandedJobGroups.contains(groupID) },
            set: { expanded in
                if expanded {
                    expandedJobGroups.insert(groupID)
                } else {
                    expandedJobGroups.remove(groupID)
                }
            }
        )
    }

    private func typeName(_ typeID: Int64) -> String {
        if let name = model.personalTypeNames[typeID] {
            return name
        }
        if model.personalDetailLoadingCharacterID
            == account.characterID {
            return "Gegenstandsname wird geladen …"
        }
        if model.personalMissingTypeIDs.contains(typeID) {
            return "Typ im lokalen SDE nicht enthalten"
        }
        return "Gegenstandsname noch nicht geladen"
    }

    private func typeLabel(_ typeID: Int64) -> some View {
        Text(typeName(typeID))
    }

    private func blueprintKind(_ quantity: Int64) -> String {
        switch quantity {
        case -2: "BPC"
        case -1: "BPO"
        default: "Blueprint"
        }
    }

    private func activeSelectionDescription(
        _ selection: ESIAssetAvailabilitySelectionSnapshot
    ) -> String {
        let locations = uniqueLocationNames(selection.locationIDs)
            .joined(separator: " · ")
        let revision = selection.sourceRevision == snapshot.revision
            ? "Revision aktuell"
            : "Revision veraltet, wird nicht verrechnet"
        return "Aktiv: \(NexusNumberFormat.quantity(selection.lines.count)) Positionen · "
            + locations + " · " + revision
    }

    private func locationName(_ id: Int64) -> String {
        locationIndex.namesByLocationID[id]
            ?? presentation.locationName(
                id,
                snapshot: snapshot,
                names: model.personalLocationNames
            )
    }

    private func locationLabel(_ id: Int64) -> String {
        locationIndex.assetLabelsByLocationID[id]
            ?? locationName(id)
    }

    private func uniqueLocationNames(_ ids: [Int64]) -> [String] {
        var seen = Set<String>()
        return ids.map(locationName).filter {
            seen.insert($0).inserted
        }
    }

    private func jobProductName(
        _ job: ESICharacterIndustryJob
    ) -> String {
        guard let productTypeID = job.productTypeID else {
            return "noch nicht gemeldet"
        }
        return typeName(productTypeID)
    }

    private func previewAvailability() async {
        guard let projectID = selectedProjectID else { return }
        do {
            try await model.previewAssetAvailability(
                projectID: projectID,
                characterID: account.characterID,
                locationIDs: Array(selectedAvailabilityLocations)
            )
        } catch {
            runtime.report(error, operation: .esiPersonalDataInspect)
        }
    }

    private func applyAvailability() async {
        do {
            try await model.applyAssetAvailabilityPreview()
        } catch {
            runtime.report(error, operation: .esiPersonalDataApply)
        }
    }

    private func previewAvailabilityRemoval(projectID: UUID) async {
        do {
            try await model.previewAssetAvailabilityRemoval(
                projectID: projectID
            )
        } catch {
            runtime.report(error, operation: .esiPersonalDataInspect)
        }
    }

    private func applyAvailabilityRemoval() async {
        do {
            try await model.applyAssetAvailabilityRemoval()
        } catch {
            runtime.report(error, operation: .esiPersonalDataApply)
        }
    }
}
