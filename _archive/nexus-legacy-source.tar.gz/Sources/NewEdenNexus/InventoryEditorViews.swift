import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct LocationEditorContext: Identifiable {
    let id = UUID()
    let location: StorageLocationSnapshot?
}

struct StockEditorContext: Identifiable {
    let id = UUID()
    let stock: ManualStockSnapshot?
}

extension StorageLocationKind {
    var localizedName: String {
        switch self {
        case .main: "Hauptlager"
        case .production: "Produktionslager"
        case .trade: "Handelslager"
        case .intermediate: "Zwischenlager"
        case .reaction: "Reaktionslager"
        case .capitalProduction: "Capital-Produktion"
        case .sales: "Verkaufslager"
        case .other: "Sonstig"
        }
    }
}

struct StorageLocationEditorSheet: View {
    let location: StorageLocationSnapshot?
    let save: (StorageLocationDraft) async throws -> Void
    let reportError: (any Error) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var kind: StorageLocationKind
    @State private var notes: String
    @State private var isSaving = false
    @State private var saveTask: Task<Void, Never>?

    init(
        location: StorageLocationSnapshot?,
        save: @escaping (StorageLocationDraft) async throws -> Void,
        reportError: @escaping (any Error) -> Void
    ) {
        self.location = location
        self.save = save
        self.reportError = reportError
        _name = State(initialValue: location?.name ?? "")
        _kind = State(initialValue: location?.kind ?? .main)
        _notes = State(initialValue: location?.notes ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                TextField("Name", text: $name)
                Picker("Lagertyp", selection: $kind) {
                    ForEach(StorageLocationKind.allCases, id: \.self) {
                        Text($0.localizedName).tag($0)
                    }
                }
                TextField("Notiz", text: $notes, axis: .vertical)
                    .lineLimit(2...6)
                NexusValidationSummary(issues: validationIssues)
            }
            .formStyle(.grouped)
            .navigationTitle(
                location == nil ? "Lager anlegen" : "Lager bearbeiten"
            )
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern") {
                        isSaving = true
                        saveTask?.cancel()
                        saveTask = Task {
                            do {
                                try await save(
                                    StorageLocationDraft(
                                        name: name,
                                        kind: kind,
                                        notes: notes
                                    )
                                )
                                dismiss()
                            } catch is CancellationError {
                                isSaving = false
                            } catch {
                                isSaving = false
                                reportError(error)
                            }
                        }
                    }
                    .disabled(!validationIssues.isEmpty || isSaving)
                }
            }
        }
        .frame(minWidth: 480, minHeight: 320)
        .onDisappear { saveTask?.cancel() }
    }

    private var validationIssues: [NexusValidationIssue] {
        guard name.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty else {
            return []
        }
        return [.requiredText(field: "Lagername")]
    }
}

struct ManualStockEditorSheet: View {
    @ObservedObject var model: InventoryViewModel
    let stock: ManualStockSnapshot?
    let reportError: (any Error) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var results: [CatalogItemSummary] = []
    @State private var selectedTypeID: Int64?
    @State private var quantity: String
    @State private var isSearching = false
    @State private var isSaving = false
    @State private var operationTask: Task<Void, Never>?

    init(
        model: InventoryViewModel,
        stock: ManualStockSnapshot?,
        reportError: @escaping (any Error) -> Void
    ) {
        self.model = model
        self.stock = stock
        self.reportError = reportError
        _selectedTypeID = State(initialValue: stock?.typeID)
        _quantity = State(
            initialValue: stock.map { String($0.quantity) } ?? ""
        )
    }

    var body: some View {
        NavigationStack {
            Form {
                if let stock {
                    LabeledContent("Item", value: stock.itemName)
                    LabeledContent("Type-ID", value: "\(stock.typeID)")
                } else {
                    Section("Item auswählen") {
                        HStack {
                            TextField("Itemname", text: $query)
                                .onSubmit { search() }
                            Button("Suchen") { search() }
                                .disabled(
                                    query.trimmingCharacters(
                                        in: .whitespacesAndNewlines
                                    ).isEmpty || isSearching
                                )
                        }
                        if isSearching {
                            ProgressView("Katalog wird durchsucht …")
                        } else if results.isEmpty {
                            Text(
                                "Suche nach einem veröffentlichten Item im lokalen SDE-Katalog."
                            )
                            .foregroundStyle(.secondary)
                        } else {
                            List(
                                results,
                                id: \.typeID,
                                selection: $selectedTypeID
                            ) { item in
                                VStack(alignment: .leading) {
                                    Text(item.name)
                                    Text(
                                        "\(item.groupName) · Type-ID \(item.typeID)"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                                .tag(item.typeID)
                            }
                            .frame(minHeight: 180)
                        }
                    }
                }

                Section("Menge") {
                    TextField("Positive Stückzahl", text: $quantity)
                        .monospacedDigit()
                    Text(
                        "Die Eingabe ersetzt die bisherige Menge; sie wird nicht addiert."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                NexusValidationSummary(issues: validationIssues)
            }
            .formStyle(.grouped)
            .navigationTitle(
                stock == nil ? "Bestand erfassen" : "Menge bearbeiten"
            )
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern") {
                        guard let typeID = stock?.typeID ?? selectedTypeID else {
                            return
                        }
                        isSaving = true
                        operationTask?.cancel()
                        operationTask = Task {
                            do {
                                try await model.saveStock(
                                    typeID: typeID,
                                    quantityText: quantity
                                )
                                dismiss()
                            } catch is CancellationError {
                                isSaving = false
                            } catch {
                                isSaving = false
                                reportError(error)
                            }
                        }
                    }
                    .disabled(!validationIssues.isEmpty || isSaving)
                }
            }
        }
        .frame(minWidth: 560, minHeight: stock == nil ? 520 : 300)
        .onDisappear { operationTask?.cancel() }
    }

    private var validationIssues: [NexusValidationIssue] {
        var issues: [NexusValidationIssue] = []
        if (stock?.typeID ?? selectedTypeID) == nil {
            issues.append(.requiredSelection(field: "Item"))
        }
        if Int64(quantity).map({ $0 > 0 }) != true {
            issues.append(.positiveInteger(field: "Bestandsmenge"))
        }
        return issues
    }

    private func search() {
        isSearching = true
        operationTask?.cancel()
        operationTask = Task {
            do {
                let page = try await model.searchItems(query: query)
                results = page.items
                selectedTypeID = nil
                isSearching = false
            } catch is CancellationError {
                isSearching = false
            } catch {
                isSearching = false
                reportError(error)
            }
        }
    }
}
