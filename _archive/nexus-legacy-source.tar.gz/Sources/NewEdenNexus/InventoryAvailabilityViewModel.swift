import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum InventoryAvailabilityViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case invalidCap(typeID: Int64)
    case previewRequired
}

@MainActor
final class InventoryAvailabilityViewModel: ObservableObject {
    @Published private(set) var preview: InventoryAvailabilityPreview?
    @Published private(set) var isLoading = false
    @Published private(set) var isPreviewing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreviewCurrent = false
    @Published var mode: InventoryAvailabilityMode = .allActiveLocations
    @Published var includedLocationIDs: Set<UUID> = []
    @Published var excludedTypeIDs: Set<Int64> = []
    @Published var capTexts: [Int64: String] = [:]

    private let service: any InventoryAvailabilityManaging
    private var projectID: UUID?

    init(service: any InventoryAvailabilityManaging) {
        self.service = service
    }

    var canApply: Bool {
        isPreviewCurrent && preview != nil && !isSaving
    }

    func load(projectID: UUID) async throws {
        guard !isBusy else {
            throw InventoryAvailabilityViewModelError.operationAlreadyRunning
        }
        self.projectID = projectID
        isLoading = true
        defer { isLoading = false }
        let loaded = try await service.preview(
            projectID: projectID,
            draft: nil
        )
        try Task.checkCancellation()
        applyToDraft(loaded.proposedConfiguration)
        preview = loaded
        isPreviewCurrent = true
    }

    func setMode(_ newMode: InventoryAvailabilityMode) {
        mode = newMode
        if newMode != .selectedLocations {
            includedLocationIDs = []
        }
        invalidatePreview()
    }

    func toggleLocation(_ id: UUID) {
        if includedLocationIDs.contains(id) {
            includedLocationIDs.remove(id)
        } else {
            includedLocationIDs.insert(id)
        }
        invalidatePreview()
    }

    func setExcluded(_ excluded: Bool, typeID: Int64) {
        if excluded {
            excludedTypeIDs.insert(typeID)
            capTexts[typeID] = nil
        } else {
            excludedTypeIDs.remove(typeID)
        }
        invalidatePreview()
    }

    func setCapText(_ text: String, typeID: Int64) {
        capTexts[typeID] = text
        invalidatePreview()
    }

    func calculatePreview() async throws {
        guard !isBusy else {
            throw InventoryAvailabilityViewModelError.operationAlreadyRunning
        }
        guard let projectID else {
            throw InventoryAvailabilityViewModelError.previewRequired
        }
        let draft = try makeDraft()
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await service.preview(
            projectID: projectID,
            draft: draft
        )
        try Task.checkCancellation()
        preview = calculated
        isPreviewCurrent = true
    }

    func applyConfirmedPreview() async throws {
        guard !isBusy else {
            throw InventoryAvailabilityViewModelError.operationAlreadyRunning
        }
        guard let preview, isPreviewCurrent else {
            throw InventoryAvailabilityViewModelError.previewRequired
        }
        isSaving = true
        defer { isSaving = false }
        let saved = try await service.apply(preview, confirmed: true)
        self.preview = saved
        applyToDraft(saved.proposedConfiguration)
        isPreviewCurrent = true
    }

    private var isBusy: Bool {
        isLoading || isPreviewing || isSaving
    }

    private func makeDraft() throws
        -> InventoryAvailabilityConfigurationDraft {
        let caps = try capTexts.compactMap {
            element -> InventoryAvailabilityCap? in
            let (typeID, text) = element
            let trimmed = text.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            guard !trimmed.isEmpty else { return nil }
            guard let value = Int64(trimmed), value >= 0 else {
                throw InventoryAvailabilityViewModelError
                    .invalidCap(typeID: typeID)
            }
            return InventoryAvailabilityCap(
                typeID: typeID,
                maximumQuantity: value
            )
        }
        return InventoryAvailabilityConfigurationDraft(
            mode: mode,
            includedLocationIDs: Array(includedLocationIDs),
            excludedTypeIDs: Array(excludedTypeIDs),
            caps: caps
        )
    }

    private func applyToDraft(
        _ configuration: InventoryAvailabilityConfigurationSnapshot
    ) {
        mode = configuration.mode
        includedLocationIDs = Set(configuration.includedLocationIDs)
        excludedTypeIDs = Set(configuration.excludedTypeIDs)
        capTexts = Dictionary(
            uniqueKeysWithValues: configuration.caps.map {
                ($0.typeID, String($0.maximumQuantity))
            }
        )
    }

    private func invalidatePreview() {
        isPreviewCurrent = false
    }
}
