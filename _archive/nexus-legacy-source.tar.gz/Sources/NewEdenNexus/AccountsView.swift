import SwiftUI
import NewEdenNexusApplication

struct AccountsView: View {
    @EnvironmentObject private var runtime: NexusAppRuntime
    @ObservedObject var model: AccountsViewModel
    @State private var pendingDisconnect: EVECharacterAccount?
    @State private var pendingWalletAuthorization: EVECharacterAccount?
    @State private var pendingStructureAuthorization:
        EVECharacterAccount?
    @State private var detailAccount: EVECharacterAccount?
    @State private var walletEvidenceAccount: EVECharacterAccount?

    var body: some View {
        Group {
            if model.isLoading && model.accounts.isEmpty {
                ProgressView("Charaktere werden geladen …")
            } else if let error = model.loadErrorDescription,
                      model.accounts.isEmpty {
                NexusOperationFailureView(
                    title: "Charaktere nicht geladen",
                    message: error,
                    retry: {
                        Task {
                            await model.load()
                        }
                    }
                )
            } else if model.accounts.isEmpty {
                VStack(spacing: 14) {
                    ContentUnavailableView(
                        "Kein Charakter verbunden",
                        systemImage: "person.crop.circle.badge.plus",
                        description: Text(
                            "Verbinde einen EVE-Charakter sicher per "
                                + "Authorization Code und PKCE. Das "
                                + "Refresh-Token bleibt im Schlüsselbund."
                        )
                    )
                    connectButton
                        .buttonStyle(.borderedProminent)
                }
            } else {
                List {
                    if model.accounts.contains(where: {
                        !model.hasWalletAuthorization(
                            characterID: $0.characterID
                        )
                    }) {
                        Section {
                            Label(
                                "Wallet-Zugriff benötigt eine einmalige "
                                    + "erneute Zustimmung bei EVE SSO. "
                                    + "„Wallet prüfen“ erklärt und startet "
                                    + "die zusätzliche Autorisierung. Der "
                                    + "normale Login fordert nur Assets, "
                                    + "Blueprints und Industry Jobs an.",
                                systemImage: "wallet.pass"
                            )
                        } header: {
                            Text("Neue optionale Leseberechtigung")
                        }
                    }
                    if model.accounts.contains(where: {
                        model.hasPrivateStructureLocations(
                            characterID: $0.characterID
                        )
                            && !model.hasStructureAuthorization(
                                characterID: $0.characterID
                            )
                    }) {
                        Section {
                            Label(
                                "Namen zugänglicher Spielerstrukturen "
                                    + "benötigen die optionale ESI-"
                                    + "Leseberechtigung für Strukturen. "
                                    + "Ohne Zustimmung bleiben gespeicherte "
                                    + "Daten nutzbar und die App zeigt einen "
                                    + "neutralen Platzhalter.",
                                systemImage: "building.2"
                            )
                        } header: {
                            Text("Optionale Strukturnamen")
                        }
                    }
                    ForEach(model.accounts) { account in
                        HStack(spacing: 14) {
                            Image(systemName: "person.crop.circle.fill")
                                .font(.title)
                                .foregroundStyle(NexusTheme.accent)
                            VStack(alignment: .leading) {
                                Text(account.name)
                                    .fontWeight(.semibold)
                                Text("Character ID \(account.characterID)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text(scopeSummary(account))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                accessRefreshStatus(account)
                                if let profile = model.profileSnapshots[
                                    account.characterID
                                ]?.profile {
                                    Text(
                                        "Corporation \(profile.corporationID)"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    if let security =
                                        profile.securityStatus {
                                        Text(
                                            "Sicherheitsstatus "
                                                + security.formatted(
                                                    .number.precision(
                                                        .fractionLength(2)
                                                    )
                                                )
                                        )
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    }
                                }
                                if let personal = model.personalSnapshots[
                                    account.characterID
                                ] {
                                    Text(
                                        "\(NexusNumberFormat.quantity(personal.assets.count)) Assets · "
                                            + "\(NexusNumberFormat.quantity(personal.blueprints.count)) Blueprints · "
                                            + "\(NexusNumberFormat.quantity(personal.industryJobs.count)) Jobs"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                                if let wallet = model.walletSnapshots[
                                    account.characterID
                                ] {
                                    Text(
                                        "Wallet: "
                                            + isk(
                                                wallet.balanceHundredths
                                            )
                                            + " · "
                                            + "\(NexusNumberFormat.quantity(wallet.transactions.count)) Transaktionen"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                                walletPreviewActionStatus(account)
                            }
                            Spacer()
                            VStack(alignment: .trailing) {
                                Text(profileStatus(account))
                                Text(
                                    model.profileSnapshots[
                                        account.characterID
                                    ]?.metadata.checkedAt.formatted(
                                        date: .abbreviated,
                                        time: .shortened
                                    ) ?? "Noch keine ESI-Daten"
                                )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                            Button("Zugang erneuern") {
                                Task {
                                    await refresh(account)
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(
                                model.activeOperationCharacterID != nil
                            )
                            Button("Charakterdaten aktualisieren") {
                                Task {
                                    await synchronize(account)
                                }
                            }
                            .disabled(
                                model.activeOperationCharacterID != nil
                            )
                            Button("Persönliche Daten prüfen") {
                                Task {
                                    await inspectPersonalData(account)
                                }
                            }
                            .disabled(
                                model.activeOperationCharacterID != nil
                            )
                            Button("Wallet prüfen") {
                                if model.hasWalletAuthorization(
                                    characterID: account.characterID
                                ) {
                                    Task {
                                        await inspectWallet(account)
                                    }
                                } else {
                                    pendingWalletAuthorization = account
                                }
                            }
                            .disabled(
                                model.activeOperationCharacterID != nil
                            )
                            if model.walletSnapshots[
                                account.characterID
                            ] != nil {
                                Button("Wallet-Nachweise zuordnen") {
                                    walletEvidenceAccount = account
                                }
                                .disabled(
                                    model.activeOperationCharacterID
                                        != nil
                                )
                            }
                            Button("Details") {
                                detailAccount = account
                            }
                            .disabled(
                                model.personalSnapshots[
                                    account.characterID
                                ] == nil
                            )
                            if model.hasPrivateStructureLocations(
                                characterID: account.characterID
                            ),
                            !model.hasStructureAuthorization(
                                characterID: account.characterID
                            ) {
                                Button("Strukturnamen freigeben") {
                                    pendingStructureAuthorization =
                                        account
                                }
                                .disabled(
                                    model.activeOperationCharacterID
                                        != nil
                                )
                            }
                            Button(
                                "Trennen",
                                role: .destructive
                            ) {
                                pendingDisconnect = account
                            }
                            .disabled(
                                model.activeOperationCharacterID != nil
                            )
                        }
                        .padding(.vertical, 7)
                    }
                }
            }
        }
        .navigationTitle("Accounts & Charaktere")
        .toolbar {
            connectButton
        }
        .task {
            await model.load()
        }
        .confirmationDialog(
            "Optionalen Wallet-Lesezugriff erlauben?",
            isPresented: Binding(
                get: { pendingWalletAuthorization != nil },
                set: { isPresented in
                    if !isPresented {
                        pendingWalletAuthorization = nil
                    }
                }
            ),
            presenting: pendingWalletAuthorization
        ) { account in
            Button("Wallet-Zugriff bei EVE autorisieren") {
                pendingWalletAuthorization = nil
                Task {
                    await authorizeWallet(account)
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: { _ in
            Text(
                "Zusätzlich zu den drei persönlichen Produktions-Leserechten wird ausschließlich esi-wallet.read_character_wallet.v1 angefordert. Damit liest die App Kontostand, Journal und Transaktionen für bestätigte Projektzuordnungen. Daten bleiben lokal; Abbrechen verändert Konto, Token, Snapshots und Zuordnungen nicht. Trennen entfernt Token, Berechtigungsmetadaten und persönliche Snapshots."
            )
        }
        .confirmationDialog(
            "Namen zugänglicher Spielerstrukturen lesen?",
            isPresented: Binding(
                get: { pendingStructureAuthorization != nil },
                set: { isPresented in
                    if !isPresented {
                        pendingStructureAuthorization = nil
                    }
                }
            ),
            presenting: pendingStructureAuthorization
        ) { account in
            Button("Struktur-Lesezugriff bei EVE autorisieren") {
                pendingStructureAuthorization = nil
                Task {
                    await authorizeStructureNames(account)
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: { _ in
            Text(
                "Zusätzlich wird ausschließlich "
                    + "esi-universe.read_structures.v1 angefordert. "
                    + "Damit kann New Eden Nexus die Namen der in deinen "
                    + "persönlichen ESI-Daten referenzierten "
                    + "Spielerstrukturen abrufen, sofern dein Charakter "
                    + "Zugriff darauf hat. Abbrechen verändert Konto, "
                    + "Token und lokale Snapshots nicht."
            )
        }
        .confirmationDialog(
            "EVE-Charakter lokal trennen?",
            isPresented: Binding(
                get: { pendingDisconnect != nil },
                set: { isPresented in
                    if !isPresented {
                        pendingDisconnect = nil
                    }
                }
            ),
            presenting: pendingDisconnect
        ) { account in
            Button(
                "\(account.name) trennen",
                role: .destructive
            ) {
                Task {
                    await disconnect(account)
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: { _ in
            Text(
                "Refresh-Token, lokale Berechtigungsmetadaten, Kontoeintrag, öffentliche und persönliche ESI-Snapshots, Wallet-Snapshot sowie bestätigte Wallet-Projektzuordnungen werden entfernt. "
                    + "Produktionsprojekte und Bestände bleiben erhalten."
            )
        }
        .sheet(
            isPresented: Binding(
                get: { model.personalPreview != nil },
                set: { isPresented in
                    if !isPresented {
                        Task {
                            await model.discardPersonalDataPreview()
                        }
                    }
                }
            )
        ) {
            if let preview = model.personalPreview {
                ESIPersonalDataPreviewView(
                    preview: preview,
                    typeNames: model.personalTypeNames,
                    missingTypeIDs: model.personalMissingTypeIDs,
                    isApplying:
                        model.activeOperationCharacterID
                            == preview.characterID,
                    apply: {
                        Task {
                            await applyPersonalDataPreview()
                        }
                    },
                    cancel: {
                        Task {
                            await model.discardPersonalDataPreview()
                        }
                    }
                )
            }
        }
        .sheet(
            isPresented: Binding(
                get: { model.walletPreview != nil },
                set: { isPresented in
                    if !isPresented {
                        Task {
                            await model.discardWalletPreview()
                        }
                    }
                }
            )
        ) {
            if let preview = model.walletPreview {
                ESIWalletPreviewView(
                    preview: preview,
                    isApplying:
                        model.activeOperationCharacterID
                            == preview.characterID,
                    apply: {
                        Task {
                            await applyWalletPreview()
                        }
                    },
                    cancel: {
                        Task {
                            await model.discardWalletPreview()
                        }
                    }
                )
            }
        }
        .sheet(item: $walletEvidenceAccount) { account in
            if let snapshot = model.walletSnapshots[
                account.characterID
            ] {
                WalletEvidenceAssignmentView(
                    account: account,
                    snapshot: snapshot,
                    model: model
                )
            } else {
                ContentUnavailableView(
                    "Kein lokaler Wallet-Snapshot",
                    systemImage: "wallet.pass",
                    description: Text(
                        "Prüfe und übernimm zuerst den Wallet-Snapshot."
                    )
                )
                .frame(minWidth: 520, minHeight: 360)
            }
        }
        .sheet(item: $detailAccount) { account in
            if let snapshot = model.personalSnapshots[
                account.characterID
            ] {
                ESIPersonalDataDetailView(
                    account: account,
                    snapshot: snapshot,
                    model: model
                )
            }
        }
    }

    private var connectButton: some View {
        Button {
            Task {
                await connect()
            }
        } label: {
            Label(
                model.isConnecting
                    ? "Anmeldung läuft …"
                    : "Mit EVE Online verbinden",
                systemImage: "person.badge.key"
            )
        }
        .disabled(
            model.isConnecting
                || model.activeOperationCharacterID != nil
        )
    }

    private func connect() async {
        do {
            try await model.connect()
        } catch {
            runtime.report(
                error,
                operation: accountOperation(
                    for: error,
                    fallback: .authentication
                )
            )
        }
    }

    private func refresh(_ account: EVECharacterAccount) async {
        do {
            try await model.refresh(characterID: account.characterID)
        } catch {
            runtime.report(
                error,
                operation: accountOperation(
                    for: error,
                    fallback: .authentication
                )
            )
        }
    }

    @ViewBuilder
    private func accessRefreshStatus(
        _ account: EVECharacterAccount
    ) -> some View {
        switch model.accessRefreshFeedback[account.characterID] {
        case .running:
            HStack(spacing: 6) {
                ProgressView()
                    .controlSize(.small)
                Text("Zugang wird erneuert …")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.updatesFrequently)
        case .succeeded:
            Label(
                "Zugang wurde erfolgreich erneuert.",
                systemImage: "checkmark.circle.fill"
            )
            .font(.caption)
            .foregroundStyle(.green)
            .accessibilityAddTraits(.updatesFrequently)
        case .failed:
            Label(
                "Zugang konnte nicht erneuert werden.",
                systemImage: "exclamationmark.triangle.fill"
            )
            .font(.caption)
            .foregroundStyle(.orange)
            .accessibilityAddTraits(.updatesFrequently)
        case nil:
            EmptyView()
        }
    }

    @ViewBuilder
    private func walletPreviewActionStatus(
        _ account: EVECharacterAccount
    ) -> some View {
        switch model.walletPreviewActionFeedback[account.characterID] {
        case .applied:
            Label(
                "Wallet-Snapshot wurde gespeichert.",
                systemImage: "checkmark.circle.fill"
            )
            .font(.caption)
            .foregroundStyle(.green)
            .accessibilityAddTraits(.updatesFrequently)
        case .discardedKeepingSnapshot:
            Label(
                "Vorschau verworfen. Der gespeicherte Wallet-Snapshot "
                    + "bleibt erhalten.",
                systemImage: "info.circle.fill"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityAddTraits(.updatesFrequently)
        case .discardedWithoutSnapshot:
            Label(
                "Vorschau verworfen. Es wurde kein Wallet-Snapshot "
                    + "gespeichert.",
                systemImage: "info.circle.fill"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityAddTraits(.updatesFrequently)
        case .failed:
            Label(
                "Wallet-Snapshot konnte nicht gespeichert werden.",
                systemImage: "exclamationmark.triangle.fill"
            )
            .font(.caption)
            .foregroundStyle(.orange)
            .accessibilityAddTraits(.updatesFrequently)
        case nil:
            EmptyView()
        }
    }

    private func synchronize(_ account: EVECharacterAccount) async {
        do {
            try await model.synchronize(
                characterID: account.characterID
            )
        } catch {
            runtime.report(
                error,
                operation: .esiCharacterRead,
                retry: {
                    Task {
                        await synchronize(account)
                    }
                }
            )
        }
    }

    private func inspectPersonalData(
        _ account: EVECharacterAccount
    ) async {
        do {
            try await model.inspectPersonalData(
                characterID: account.characterID
            )
        } catch {
            runtime.report(
                error,
                operation: .esiPersonalDataInspect,
                retry: {
                    Task {
                        await inspectPersonalData(account)
                    }
                }
            )
        }
    }

    private func applyPersonalDataPreview() async {
        do {
            try await model.applyPersonalDataPreview()
        } catch {
            runtime.report(
                error,
                operation: .esiPersonalDataApply
            )
        }
    }

    private func inspectWallet(
        _ account: EVECharacterAccount
    ) async {
        do {
            try await model.inspectWallet(
                characterID: account.characterID
            )
        } catch {
            runtime.report(
                error,
                operation: .esiWalletInspect,
                retry: {
                    Task {
                        await inspectWallet(account)
                    }
                }
            )
        }
    }

    private func applyWalletPreview() async {
        do {
            try await model.applyWalletPreview()
        } catch {
            runtime.report(
                error,
                operation: .esiWalletApply
            )
        }
    }

    private func authorizeWallet(
        _ account: EVECharacterAccount
    ) async {
        do {
            try await model.authorizeWallet(
                characterID: account.characterID
            )
        } catch {
            runtime.report(
                error,
                operation: accountOperation(
                    for: error,
                    fallback: .authentication
                )
            )
        }
    }

    private func authorizeStructureNames(
        _ account: EVECharacterAccount
    ) async {
        do {
            try await model.authorizeStructureNames(
                characterID: account.characterID
            )
        } catch {
            runtime.report(
                error,
                operation: accountOperation(
                    for: error,
                    fallback: .authentication
                )
            )
        }
    }

    private func profileStatus(_ account: EVECharacterAccount) -> String {
        guard let snapshot = model.profileSnapshots[
            account.characterID
        ] else {
            return "Noch nicht synchronisiert"
        }
        if let source = model.profileSources[account.characterID] {
            switch source {
            case .offlineCache:
                return "Offline – lokaler Stand"
            case .limitedCache:
                return "Begrenzt – lokaler Stand"
            case .serverFallback:
                return "ESI nicht verfügbar – lokaler Stand"
            default:
                break
            }
        }
        return snapshot.isFresh(at: Date())
            ? "Aktuell"
            : "Veraltet"
    }

    private func disconnect(_ account: EVECharacterAccount) async {
        pendingDisconnect = nil
        do {
            try await model.disconnect(characterID: account.characterID)
        } catch {
            runtime.report(
                error,
                operation: accountOperation(
                    for: error,
                    fallback: .characterDelete
                )
            )
        }
    }

    private func accountOperation(
        for error: any Error,
        fallback: NexusOperation
    ) -> NexusOperation {
        guard let authenticationError =
            error as? EVEAuthenticationError,
            authenticationError == .localCredentialAccessFailed else {
            return fallback
        }
        return fallback == .characterDelete
            ? .keychainDelete
            : .keychainAccess
    }

    private func isk(_ hundredths: Int64) -> String {
        NexusNumberFormat.isk(hundredths: hundredths)
    }

    private func scopeSummary(
        _ account: EVECharacterAccount
    ) -> String {
        guard account.authorizationUpdatedAt != nil else {
            return "Berechtigungen: lokal noch nicht bestätigt"
        }
        let personalCount = EVEAuthorizationScope.personalIndustry.filter {
            account.authorizes($0)
        }.count
        let wallet = account.authorizes(EVEAuthorizationScope.wallet)
        let structures = account.authorizes(
            EVEAuthorizationScope.structures
        )
        return "Berechtigungen: \(NexusNumberFormat.quantity(personalCount))/3 Produktion"
            + (wallet ? " · Wallet erlaubt" : " · Wallet nicht erlaubt")
            + (structures
                ? " · Strukturnamen erlaubt"
                : " · Strukturnamen nicht erlaubt")
    }
}
