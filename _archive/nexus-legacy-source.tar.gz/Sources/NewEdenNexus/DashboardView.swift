import SwiftUI

struct DashboardView: View {
    @ObservedObject var model: DashboardViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Operations Center").font(.largeTitle.bold())
                        .accessibilityAddTraits(.isHeader)
                    Text("Deine lokale Übersicht für New Eden").foregroundStyle(.secondary)
                }
                LazyVGrid(
                    columns: [
                        GridItem(
                            .adaptive(minimum: 210, maximum: 360),
                            spacing: 14
                        )
                    ],
                    spacing: 14
                ) {
                    MetricCard(title: "Produktionsprojekte", value: NexusNumberFormat.quantity(model.projects.count), detail: "lokal gespeichert", symbol: "shippingbox.fill")
                    MetricCard(title: "Aktive Projekte", value: NexusNumberFormat.quantity(model.activeProjectCount), detail: "Produktionsplanung", symbol: "hammer.fill", tint: NexusTheme.teal)
                    MetricCard(title: "Geplante Einheiten", value: NexusNumberFormat.quantity(model.plannedProductQuantity), detail: "nicht archiviert", symbol: "number", tint: NexusTheme.warning)
                }
                .accessibilityElement(children: .contain)
                .accessibilityLabel("Projektübersicht")

                GroupBox("Produktionskern – lokal verfügbar") {
                    VStack(alignment: .leading, spacing: 13) {
                        StepRow(done: !model.projects.isEmpty, text: "Produktionsprojekt auswählen")
                        StepRow(done: true, text: "Produktionsworkspace öffnen")
                        StepRow(done: true, text: "Zwischenstufen bauen oder kaufen")
                        StepRow(done: true, text: "Fehlmengenliste kopieren")
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(8)
                }

                if !model.projects.isEmpty {
                    GroupBox("Zuletzt bearbeitete Projekte") {
                        VStack(spacing: 0) {
                            ForEach(model.projects.prefix(5)) { project in
                                HStack {
                                    Image(systemName: "shippingbox")
                                        .foregroundStyle(NexusTheme.teal)
                                        .accessibilityHidden(true)
                                    VStack(alignment: .leading) {
                                        Text(project.name).fontWeight(.medium)
                                        Text("\(NexusNumberFormat.quantity(project.targetQuantity)) × \(project.productName)").font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Text(project.status.rawValue).font(.caption).padding(.horizontal, 8).padding(.vertical, 4).background(.quaternary, in: Capsule())
                                }
                                .padding(.vertical, 9)
                                .accessibilityElement(children: .ignore)
                                .accessibilityLabel(
                                    "\(project.name), \(NexusNumberFormat.quantity(project.targetQuantity)) mal \(project.productName), Status \(project.status.rawValue)"
                                )
                                if project.id != model.projects.prefix(5).last?.id { Divider() }
                            }
                        }.padding(.horizontal, 8)
                    }
                }
            }.padding(28)
        }.navigationTitle("Dashboard")
        .overlay(alignment: .topTrailing) {
            if model.isLoading {
                ProgressView()
                    .padding()
                    .accessibilityLabel("Dashboard wird aktualisiert")
            }
        }
        .task { await load() }
    }

    private func load() async {
        do {
            try await model.load()
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .projectLoad,
                retry: { Task { await load() } }
            )
        }
    }
}

private struct StepRow: View {
    let done: Bool
    let text: String
    var body: some View {
        Label(text, systemImage: done ? "checkmark.circle.fill" : "circle")
            .foregroundStyle(done ? .primary : .secondary)
            .accessibilityLabel(
                "\(text): \(done ? "erledigt" : "offen")"
            )
    }
}
