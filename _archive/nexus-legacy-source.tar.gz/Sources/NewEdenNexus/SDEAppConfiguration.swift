import Foundation
import NewEdenNexusApplication

enum SDEAppConfiguration {
    static let applicationName = "NewEdenNexus"
    static let applicationVersion = "0.1.0"
    static let schemaUnderstoodThroughBuildNumber = 3_444_265
    static let ownerContactKeychainAccount = "sde.owner-contact"
    static let automationDefaultsKey = "sde.automation-settings.v1"

    // These are fixed, reviewed HTTPS literals from CCP's official domains.
    // A failed construction would be a programming error, not user input.
    static let developerLicenseURL = URL(
        string: "https://developers.eveonline.com/license-agreement"
    )!
    static let staticDataURL = URL(
        string: "https://developers.eveonline.com/docs/services/static-data/"
    )!
    static let eulaURL = URL(
        string: "https://support.eveonline.com/hc/en-us/articles/8413329735580-EVE-Online-End-User-License-Agreement"
    )!
    static let termsURL = URL(
        string: "https://support.eveonline.com/hc/en-us/articles/8414770561948-EVE-Online-Terms-of-Service"
    )!
    static let thirdPartyPoliciesURL = URL(
        string: "https://support.eveonline.com/hc/en-us/articles/8564030965660-Third-Party-Policies"
    )!
}

struct SDEAppDirectories {
    let root: URL
    let downloads: URL
    let cache: URL
    let staging: URL
    let packages: URL
    let logs: URL
    let backups: URL

    init(fileManager: FileManager = .default) throws {
        guard let applicationSupport = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw SDEInstallationError.transport
        }
        root = applicationSupport
            .appendingPathComponent("New Eden Nexus", isDirectory: true)
            .appendingPathComponent("SDE", isDirectory: true)
        downloads = root.appendingPathComponent(
            "Downloads",
            isDirectory: true
        )
        cache = root.appendingPathComponent("Cache", isDirectory: true)
        staging = root.appendingPathComponent("Staging", isDirectory: true)
        packages = root.appendingPathComponent("Packages", isDirectory: true)
        logs = root.appendingPathComponent("Logs", isDirectory: true)
        backups = root.appendingPathComponent("Backups", isDirectory: true)
    }
}
