import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct InventoryAvailabilitySheet: View {
    let project: ProductionProjectSnapshot
    @ObservedObject var model: InventoryAvailabilityViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @Environment(\.dismiss) private var dismiss
    @State private var task: Task<Void, Never>?
    @State private var showingApplyConfirmation = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header
            Divider()
            content
            Divider()
            footer
        }
        .padding(24)
        .frame(minWidth: 900, idealWidth: 1_050, minHeight: 680)
        .task {
            await load()
        }
        .onDisappear {
            task?.cancel()
        }
        .confirmationDialog(
            "Bestandsfreigaben übernehmen?",
            isPresented: $showingApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button("Ausschlüsse übernehmen") {
                run(operation: .inventorySave) {
                    try await model.applyConfirmedPreview()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Gespeichert werden nur die gezeigten Lager-, Material- und Mengenfreigaben. Bestände selbst bleiben unverändert."
            )
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Bestand abgleichen")
                .font(.title2.bold())
            Text(project.name)
                .foregroundStyle(.secondary)
            Label(
                "P22 zeigt physischen Bestand nach Ausschlüssen. Sicherheitsbestände werden in P23 geschützt; Reservierungen folgen P24 und P25.",
                systemImage: "info.circle"
            )
            .font(.callout)
            .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var content: some View {
        if model.isLoading && model.preview == nil {
            ProgressView("Bestandsabgleich wird geladen …")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let preview = model.preview {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    policyControls(preview)
                    Divider()
                    resultSummary(preview)
                    materialRows(preview)
                }
            }
        } else {
            ContentUnavailableView {
                Label(
                    "Keine Verfügbarkeitsvorschau",
                    systemImage: "shippingbox.and.arrow.backward"
                )
            } description: {
                Text(
                    "Ein aktueller Produktionsgraph mit Materialaggregation ist erforderlich."
                )
            }
        }
    }

    private func policyControls(
        _ preview: InventoryAvailabilityPreview
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Bestandsfreigabe")
                .font(.headline)
            Picker(
                "Freigabemodus",
                selection: Binding(
                    get: { model.mode },
                    set: { model.setMode($0) }
                )
            ) {
                Text("Alle aktiven Lager")
                    .tag(InventoryAvailabilityMode.allActiveLocations)
                Text("Ausgewählte Lager")
                    .tag(InventoryAvailabilityMode.selectedLocations)
                Text("Bestand ignorieren")
                    .tag(InventoryAvailabilityMode.ignoreInventory)
            }
            .pickerStyle(.segmented)
            .accessibilityLabel("Freigabemodus für vorhandene Bestände")

            if model.mode == .selectedLocations {
                Text("Verwendbare Lager")
                    .font(.subheadline.bold())
                ForEach(preview.locations) { location in
                    Toggle(
                        isOn: Binding(
                            get: {
                                model.includedLocationIDs.contains(location.id)
                            },
                            set: { _ in model.toggleLocation(location.id) }
                        )
                    ) {
                        HStack {
                            Text(location.name)
                            if location.isArchived {
                                Text("Archiviert – ausgeschlossen")
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .disabled(
                        location.isArchived
                            && !model.includedLocationIDs.contains(location.id)
                    )
                    .accessibilityLabel(
                        "Lager \(location.name) einbeziehen"
                    )
                }
            }
            if !model.isPreviewCurrent {
                Label(
                    "Einstellungen geändert – Detailvorschau neu berechnen.",
                    systemImage: "exclamationmark.triangle"
                )
                .foregroundStyle(.orange)
            }
        }
    }

    private func resultSummary(
        _ preview: InventoryAvailabilityPreview
    ) -> some View {
        HStack(spacing: 20) {
            summaryTile(
                "Vollständig gedeckt",
                preview.calculation.fullyCoveredMaterialCount,
                color: .green
            )
            summaryTile(
                "Teilweise gedeckt",
                preview.calculation.partiallyCoveredMaterialCount,
                color: .orange
            )
            summaryTile(
                "Ungedeckt",
                preview.calculation.uncoveredMaterialCount,
                color: .red
            )
            Spacer()
            Text(
                "Formel v\(preview.calculation.formulaVersion)"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    private func summaryTile(
        _ title: String,
        _ count: Int,
        color: Color
    ) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(count))
                .font(.title3.bold())
                .foregroundStyle(color)
                .monospacedDigit()
        }
    }

    private func materialRows(
        _ preview: InventoryAvailabilityPreview
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Detailvorschau")
                .font(.headline)
            if preview.calculation.lines.isEmpty {
                Text("Der Produktionsgraph enthält keine Endmaterialien.")
                    .foregroundStyle(.secondary)
            }
            ForEach(preview.calculation.lines, id: \.typeID) { line in
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(line.name)
                                .fontWeight(.semibold)
                            Text("Type-ID \(line.typeID)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Toggle(
                            "Material ausschließen",
                            isOn: Binding(
                                get: {
                                    model.excludedTypeIDs.contains(line.typeID)
                                },
                                set: {
                                    model.setExcluded($0, typeID: line.typeID)
                                }
                            )
                        )
                        .toggleStyle(.checkbox)
                        TextField(
                            "Maximalmenge",
                            text: Binding(
                                get: { model.capTexts[line.typeID] ?? "" },
                                set: {
                                    model.setCapText($0, typeID: line.typeID)
                                }
                            )
                        )
                        .frame(width: 130)
                        .disabled(model.excludedTypeIDs.contains(line.typeID))
                        .accessibilityLabel(
                            "Maximal verwendbare Menge für \(line.name)"
                        )
                    }
                    Grid(
                        alignment: .trailing,
                        horizontalSpacing: 18,
                        verticalSpacing: 4
                    ) {
                        availabilityGridRow(
                            "Bruttobedarf",
                            line.requiredQuantity,
                            "Physisch gespeichert",
                            line.storedPhysicalQuantity
                        )
                        availabilityGridRow(
                            "Archiv ausgeschlossen",
                            line.archivedExcludedQuantity,
                            "Lager/Modus ausgeschlossen",
                            line.selectionExcludedQuantity
                        )
                        availabilityGridRow(
                            "Material ausgeschlossen",
                            line.materialExcludedQuantity,
                            "Obergrenze ausgeschlossen",
                            line.capExcludedQuantity
                        )
                        availabilityGridRow(
                            "P22 einbeziehbar",
                            line.eligiblePhysicalQuantity,
                            "Für Bedarf verwendbar",
                            line.usableQuantity
                        )
                        availabilityGridRow(
                            "Ungedeckt",
                            line.uncoveredQuantity,
                            "Einbeziehbarer Rest",
                            line.unusedEligibleQuantity
                        )
                    }
                    .font(.caption)
                    .monospacedDigit()
                }
                .padding(12)
                .background(.secondary.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .accessibilityElement(children: .contain)
            }
        }
    }

    private func availabilityGridRow(
        _ leftTitle: String,
        _ leftValue: Int64,
        _ rightTitle: String,
        _ rightValue: Int64
    ) -> some View {
        GridRow {
            Text(leftTitle).foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(leftValue))
            Text(rightTitle).foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(rightValue))
        }
    }

    private var footer: some View {
        HStack {
            Button("Schließen") {
                dismiss()
            }
            Spacer()
            if model.isPreviewing || model.isSaving {
                ProgressView(
                    model.isSaving
                        ? "Ausschlüsse werden gespeichert …"
                        : "Vorschau wird berechnet …"
                )
                Button("Abbrechen") {
                    task?.cancel()
                }
            }
            Button("Vorschau berechnen") {
                run(operation: .inventoryLoad) {
                    try await model.calculatePreview()
                }
            }
            .keyboardShortcut("r", modifiers: [.command, .shift])
            .disabled(model.isLoading || model.isPreviewing || model.isSaving)

            Button("Ausschlüsse übernehmen") {
                showingApplyConfirmation = true
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut(.defaultAction)
            .disabled(!model.canApply)
        }
    }

    private func load() async {
        do {
            try await model.load(projectID: project.id)
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .inventoryLoad,
                retry: {
                    Task {
                        await load()
                    }
                }
            )
        }
    }

    private func run(
        operation: NexusOperation,
        _ action: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: operation)
            }
        }
    }
}
