import Foundation
import NewEdenNexusApplication

enum InventoryCSVImportViewModelError: Error, Equatable {
    case noSource
    case incompleteMapping
    case noPreview
}

@MainActor
final class InventoryCSVImportViewModel: ObservableObject, Identifiable {
    let id = UUID()

    @Published var encoding: InventoryCSVEncodingOption = .automatic
    @Published var delimiter: InventoryCSVDelimiterOption = .automatic
    @Published var quantityFormat: InventoryCSVQuantityFormat = .integer
    @Published var typeIDColumn: Int?
    @Published var quantityColumn: Int?
    @Published var itemNameColumn: Int?
    @Published var decisions: [Int: InventoryCSVImportDecision] = [:]
    @Published private(set) var sourceName: String?
    @Published private(set) var inspection: InventoryCSVInspection?
    @Published private(set) var preview: InventoryCSVImportPreview?
    @Published private(set) var report: InventoryImportReport?
    @Published private(set) var isWorking = false

    private let importer: any InventoryCSVImporting
    private let fileReader: any InventoryCSVFileReading
    private var source: InventoryCSVImportSource?

    init(
        importer: any InventoryCSVImporting,
        fileReader: any InventoryCSVFileReading
    ) {
        self.importer = importer
        self.fileReader = fileReader
    }

    var mapping: InventoryCSVColumnMapping? {
        guard let typeIDColumn, let quantityColumn,
              typeIDColumn != quantityColumn,
              itemNameColumn != typeIDColumn,
              itemNameColumn != quantityColumn else {
            return nil
        }
        return InventoryCSVColumnMapping(
            typeIDColumn: typeIDColumn,
            quantityColumn: quantityColumn,
            itemNameColumn: itemNameColumn
        )
    }

    var canApply: Bool {
        guard let preview else { return false }
        let conflictsResolved = preview.requiresDecisions.allSatisfy {
            decisions[$0.rowNumber] != nil
        }
        let replacementCount = preview.requiresDecisions.count {
            decisions[$0.rowNumber] == .replace
        }
        return conflictsResolved
            && preview.insertCount + replacementCount > 0
            && !isWorking
    }

    func selectFile(_ url: URL) async throws {
        try await withWorkingState {
            let reader = fileReader
            let loaded = try await Task.detached {
                try reader.read(url: url)
            }.value
            try Task.checkCancellation()
            source = loaded
            sourceName = loaded.displayName
            preview = nil
            report = nil
            decisions = [:]
            try await inspectLoadedSource(resetMapping: true)
        }
    }

    func reinspect() async throws {
        try await withWorkingState {
            preview = nil
            report = nil
            decisions = [:]
            try await inspectLoadedSource(resetMapping: true)
        }
    }

    func createPreview(locationID: UUID) async throws {
        guard let source else {
            throw InventoryCSVImportViewModelError.noSource
        }
        guard let mapping else {
            throw InventoryCSVImportViewModelError.incompleteMapping
        }
        try await withWorkingState {
            let generated = try await importer.preview(
                source: source,
                options: .init(
                    encoding: encoding,
                    delimiter: delimiter
                ),
                mapping: mapping,
                quantityFormat: quantityFormat,
                locationID: locationID
            )
            try Task.checkCancellation()
            preview = generated
            report = nil
            decisions = [:]
        }
    }

    func applyConfirmed() async throws -> InventoryImportReport {
        guard let preview else {
            throw InventoryCSVImportViewModelError.noPreview
        }
        return try await withWorkingState {
            let result = try await importer.apply(
                preview: preview,
                decisions: decisions,
                confirmed: true
            )
            try Task.checkCancellation()
            report = result
            return result
        }
    }

    private func inspectLoadedSource(resetMapping: Bool) async throws {
        guard let source else {
            throw InventoryCSVImportViewModelError.noSource
        }
        let result = try await importer.inspect(
            source: source,
            options: .init(
                encoding: encoding,
                delimiter: delimiter
            )
        )
        try Task.checkCancellation()
        inspection = result
        if resetMapping {
            typeIDColumn = uniqueHeaderIndex(
                in: result.headers,
                aliases: ["type_id", "typeid", "type id", "typ-id"]
            )
            quantityColumn = uniqueHeaderIndex(
                in: result.headers,
                aliases: ["quantity", "qty", "menge", "bestand"]
            )
            itemNameColumn = uniqueHeaderIndex(
                in: result.headers,
                aliases: ["item_name", "item name", "name", "item"]
            )
        }
    }

    private func uniqueHeaderIndex(
        in headers: [String],
        aliases: Set<String>
    ) -> Int? {
        let matches = headers.indices.filter {
            aliases.contains(CatalogSearchText.normalize(headers[$0]))
        }
        return matches.count == 1 ? matches[0] : nil
    }

    private func withWorkingState<T>(
        _ action: () async throws -> T
    ) async throws -> T {
        isWorking = true
        defer { isWorking = false }
        return try await action()
    }
}
