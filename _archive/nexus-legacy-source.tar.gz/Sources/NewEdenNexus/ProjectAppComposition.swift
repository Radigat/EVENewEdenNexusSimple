import Foundation
import NewEdenNexusApplication
import NewEdenNexusInfrastructure
import NewEdenNexusPersistence
import SwiftData

@MainActor
enum ProjectAppComposition {
    static func makeViewModel(
        container: ModelContainer
    ) -> ProjectLifecycleViewModel {
        let repository = SwiftDataProductionProjectRepository(
            modelContainer: container
        )
        let lifecycle = ProductionProjectLifecycleService(
            repository: repository
        )
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let targetSelection = ProductionTargetSelectionService(
            catalog: catalog,
            resolver: ResolveRecipeUseCase(source: catalog)
        )
        return ProjectLifecycleViewModel(
            lifecycle: lifecycle,
            targetSelection: targetSelection
        )
    }

    static func makeGraphViewModel(
        container: ModelContainer
    ) -> ProductionGraphViewModel {
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let repository = SwiftDataProductionGraphRepository(
            modelContainer: container
        )
        let service = ProductionGraphService(
            repository: repository,
            catalog: catalog,
            resolver: ResolveRecipeUseCase(source: catalog),
            t2IndustryData: RecipeBackedT2IndustryData(
                source: catalog,
                blueprintCatalog: catalog
            ),
            reactionIndustryData: SwiftDataReactionIndustryData(
                modelContainer: container
            )
        )
        return ProductionGraphViewModel(service: service)
    }

    static func makeBuildOrBuyViewModel(
        container: ModelContainer
    ) throws -> BuildOrBuyWorkspaceViewModel {
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let priceRepository = SwiftDataPriceProfileRepository(
            modelContainer: container
        )
        let planning = try makePlanning(
            container: container,
            catalog: catalog
        )
        let market = makeMarketServices(
            container: container,
            repository: priceRepository,
            catalog: catalog
        )
        let priceProfiles = PriceProfileManagementService(
            repository: priceRepository,
            catalog: catalog
        )
        return BuildOrBuyWorkspaceViewModel(
            service: planning,
            economicsService: ProjectEconomicsService(
                repository: SwiftDataProjectEconomicsRepository(
                    modelContainer: container
                ),
                prices: priceProfiles
            ),
            budgetService: ProjectBudgetService(
                repository: SwiftDataProjectBudgetRepository(
                    modelContainer: container
                ),
                prices: priceProfiles
            ),
            shoppingService: makeShoppingManagement(
                container: container,
                planning: planning
            ),
            marketPriceService: market.importer,
            priceProfileService: priceProfiles,
            marketLocationDirectory: market.directory
        )
    }

    static func makePurchasingViewModel(
        container: ModelContainer
    ) throws -> PurchasingViewModel {
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let planning = try makePlanning(
            container: container,
            catalog: catalog
        )
        let shopping = makeShoppingManagement(
            container: container,
            planning: planning
        )
        return PurchasingViewModel(
            service: PurchasingWorkflowManagementService(
                projects: ProductionProjectLifecycleService(
                    repository:
                        SwiftDataProductionProjectRepository(
                            modelContainer: container
                        )
                ),
                planning: planning,
                shopping: shopping,
                progress: SwiftDataPurchaseProgressRepository(
                    modelContainer: container
                )
            )
        )
    }

    static func makeDashboardViewModel(
        container: ModelContainer
    ) -> DashboardViewModel {
        DashboardViewModel(
            lifecycle: ProductionProjectLifecycleService(
                repository: SwiftDataProductionProjectRepository(
                    modelContainer: container
                )
            )
        )
    }

    static func makeProductionLedgerViewModel(
        container: ModelContainer
    ) throws -> ProductionLedgerViewModel {
        let projects = SwiftDataProductionProjectRepository(
            modelContainer: container
        )
        let graphs = SwiftDataProductionGraphRepository(
            modelContainer: container
        )
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let accounts = SwiftDataCharacterAccountRepository(
            modelContainer: container
        )
        let personalData = try FileESIPersonalDataStore(
            directoryURL:
                try FileESIPersonalDataStore
                .defaultDirectoryURL()
        )
        let batches = SwiftDataProductionBatchRepository(
            modelContainer: container
        )
        let planning = try makePlanning(
            container: container,
            catalog: catalog,
            personalDataStore: personalData
        )
        let shopping = makeShoppingManagement(
            container: container,
            planning: planning
        )
        let priceRepository = SwiftDataPriceProfileRepository(
            modelContainer: container
        )
        let priceProfiles = PriceProfileManagementService(
            repository: priceRepository,
            catalog: catalog
        )
        let walletStore = try FileESIWalletStore(
            directoryURL:
                try FileESIWalletStore.defaultDirectoryURL()
        )
        let walletAssignments =
            SwiftDataWalletProjectAssignmentRepository(
                modelContainer: container
            )
        let market = makeMarketServices(
            container: container,
            repository: priceRepository,
            catalog: catalog
        )
        return ProductionLedgerViewModel(
            service: ProductionBatchManagementService(
                projects: projects,
                graphs: graphs,
                batches: batches,
                catalog: catalog,
                industryJobs: ESIPersonalDataIndustryJobSource(
                    store: personalData
                )
            ),
            costService: ProductionBatchCostManagementService(
                batches: batches,
                costs: SwiftDataProductionBatchCostRepository(
                    modelContainer: container
                ),
                planning: planning,
                shopping: shopping,
                budget: ProjectBudgetService(
                    repository: SwiftDataProjectBudgetRepository(
                        modelContainer: container
                    ),
                    prices: priceProfiles
                ),
                prices: priceProfiles,
                market: market.importer
            ),
            saleService: ProductionBatchSaleManagementService(
                batches: batches,
                costs: SwiftDataProductionBatchCostRepository(
                    modelContainer: container
                ),
                wallets: walletStore,
                projectAssignments: walletAssignments,
                sales: SwiftDataProductionBatchSaleRepository(
                    modelContainer: container
                )
            ),
            marketDirectory: market.directory,
            jobLoader: {
                var options: [ProductionLedgerJobOption] = []
                for account in try await accounts.accounts() {
                    try Task.checkCancellation()
                    guard
                        let snapshot = try await personalData.snapshot(
                            characterID: account.characterID
                        )
                    else {
                        continue
                    }
                    options.append(
                        contentsOf: snapshot.industryJobs.map {
                            ProductionLedgerJobOption(
                                characterName: account.name,
                                job: $0
                            )
                        }
                    )
                }
                return options
            }
        )
    }

    static func makePlanning(
        container: ModelContainer,
        catalog: SwiftDataItemBlueprintCatalog,
        personalDataStore:
            (any ESIPersonalDataPersisting)? = nil
    ) throws -> BuildOrBuyPlanningService {
        let projectRepository = SwiftDataProductionProjectRepository(
            modelContainer: container
        )
        let inventoryRepository =
            SwiftDataInventoryAvailabilityRepository(
                modelContainer: container
            )
        let resolvedPersonalDataStore: any ESIPersonalDataPersisting
        if let personalDataStore {
            resolvedPersonalDataStore = personalDataStore
        } else {
            resolvedPersonalDataStore = try FileESIPersonalDataStore(
                directoryURL:
                    try FileESIPersonalDataStore
                    .defaultDirectoryURL()
            )
        }
        let esiAssets = ESIAssetAvailabilityService(
            personalData: resolvedPersonalDataStore,
            inventory: inventoryRepository,
            projects: projectRepository,
            repository:
                SwiftDataESIAssetAvailabilitySelectionRepository(
                    modelContainer: container
                )
        )
        return BuildOrBuyPlanningService(
            projects: projectRepository,
            graphs: SwiftDataProductionGraphRepository(
                modelContainer: container
            ),
            decisions:
                SwiftDataBuildOrBuyDecisionRepository(
                    modelContainer: container
                ),
            inventory: inventoryRepository,
            policies:
                SwiftDataSafetyStockPolicyRepository(
                    modelContainer: container
                ),
            reservations:
                SwiftDataProjectReservationRepository(
                    modelContainer: container
                ),
            recipes: catalog,
            catalog: catalog,
            esiAssets: esiAssets
        )
    }

    private static func makeShoppingManagement(
        container: ModelContainer,
        planning: BuildOrBuyPlanningService
    ) -> ShoppingListManagementService {
        ShoppingListManagementService(
            repository:
                SwiftDataShoppingQuantityOverrideRepository(
                    modelContainer: container
                ),
            planning: planning
        )
    }

    private static func makeMarketServices(
        container: ModelContainer,
        repository: SwiftDataPriceProfileRepository,
        catalog: SwiftDataItemBlueprintCatalog
    ) -> (
        importer: any MarketPriceImporting,
        directory: (any MarketLocationDirectoryLoading)?
    ) {
        do {
            guard
                let contact = KeychainStore.read(
                    account:
                        SDEAppConfiguration.ownerContactKeychainAccount
                )?.trimmingCharacters(in: .whitespacesAndNewlines),
                !contact.isEmpty
            else {
                return (UnavailableMarketPriceImportService(), nil)
            }
            let userAgent = try SDEUserAgentConfiguration(
                applicationName: SDEAppConfiguration.applicationName,
                applicationVersion:
                    SDEAppConfiguration.applicationVersion,
                contact: contact,
                purpose: "ESI market integration"
            )
            let configuration = try ESIMarketOrderClientConfiguration(
                compatibilityDate:
                    AccountAppComposition.esiCompatibilityDate,
                userAgent: userAgent
            )
            let remote = URLSessionESIMarketOrderClient(
                configuration: configuration
            )
            let cache = try FileESIMarketOrderPageCache(
                directoryURL:
                    try FileESIMarketOrderPageCache
                    .defaultDirectoryURL()
            )
            let personalData = try FileESIPersonalDataStore(
                directoryURL:
                    try FileESIPersonalDataStore
                    .defaultDirectoryURL()
            )
            let locationNames = try FileESILocationNameStore(
                directoryURL:
                    try FileESILocationNameStore
                    .defaultDirectoryURL()
            )
            return (
                MarketPriceImportService(
                    remote: remote,
                    cache: cache,
                    repository: repository,
                    catalog: catalog
                ),
                MarketLocationDirectoryService(
                    remote: URLSessionMarketUniverseDirectoryClient(
                        configuration: configuration
                    ),
                    accounts: SwiftDataCharacterAccountRepository(
                        modelContainer: container
                    ),
                    personalData: personalData,
                    locationNames: locationNames
                )
            )
        } catch {
            return (UnavailableMarketPriceImportService(), nil)
        }
    }
}

private struct UnavailableMarketPriceImportService:
    MarketPriceImporting
{
    func preview(
        profileID: UUID?,
        configuration: MarketPriceConfiguration,
        requirements: [MarketPriceRequestLine]
    ) async throws -> MarketPriceImportPreview {
        throw ESIMarketPriceError.invalidConfiguration
    }

    func apply(
        preview: MarketPriceImportPreview,
        confirmed: Bool
    ) async throws -> MarketPriceImportReport {
        throw ESIMarketPriceError.invalidConfiguration
    }
}
