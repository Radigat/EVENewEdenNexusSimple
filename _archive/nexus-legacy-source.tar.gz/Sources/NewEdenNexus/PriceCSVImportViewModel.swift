import Foundation
import NewEdenNexusApplication

enum PriceCSVImportViewModelError: Error, Equatable {
    case noSource
    case incompleteMapping
    case noPreview
}

@MainActor
final class PriceCSVImportViewModel: ObservableObject, Identifiable {
    let id = UUID()

    @Published var encoding: InventoryCSVEncodingOption = .automatic
    @Published var delimiter: InventoryCSVDelimiterOption = .automatic
    @Published var decimalFormat: PriceCSVDecimalFormat = .decimalPoint
    @Published var typeIDColumn: Int?
    @Published var priceColumn: Int?
    @Published var itemNameColumn: Int?
    @Published var validFrom = Date()
    @Published var hasExpiration = false
    @Published var validUntil =
        Calendar.current.date(byAdding: .month, value: 1, to: Date()) ?? Date()
    @Published var decisions: [Int: PriceCSVImportDecision] = [:]
    @Published private(set) var sourceName: String?
    @Published private(set) var inspection: PriceCSVInspection?
    @Published private(set) var preview: PriceCSVImportPreview?
    @Published private(set) var report: PriceImportReport?
    @Published private(set) var isWorking = false

    private let importer: any PriceCSVImporting
    private let fileReader: any InventoryCSVFileReading
    private var source: InventoryCSVImportSource?

    init(
        importer: any PriceCSVImporting,
        fileReader: any InventoryCSVFileReading
    ) {
        self.importer = importer
        self.fileReader = fileReader
    }

    var mapping: PriceCSVColumnMapping? {
        guard let typeIDColumn, let priceColumn,
              typeIDColumn != priceColumn,
              itemNameColumn != typeIDColumn,
              itemNameColumn != priceColumn else {
            return nil
        }
        return PriceCSVColumnMapping(
            typeIDColumn: typeIDColumn,
            priceColumn: priceColumn,
            itemNameColumn: itemNameColumn
        )
    }

    var canApply: Bool {
        guard let preview else { return false }
        let resolved = preview.requiresDecisions.allSatisfy {
            decisions[$0.rowNumber] != nil
        }
        let replacements = preview.requiresDecisions.count {
            decisions[$0.rowNumber] == .replace
        }
        return resolved
            && preview.insertCount + replacements > 0
            && !isWorking
    }

    func selectFile(_ url: URL) async throws {
        try await withWorking {
            let reader = fileReader
            let loaded = try await Task.detached {
                try reader.read(url: url)
            }.value
            source = loaded
            sourceName = loaded.displayName
            preview = nil
            report = nil
            decisions = [:]
            try await inspectSource(resetMapping: true)
        }
    }

    func reinspect() async throws {
        try await withWorking {
            preview = nil
            report = nil
            decisions = [:]
            try await inspectSource(resetMapping: true)
        }
    }

    func createPreview(profileID: UUID) async throws {
        guard let source else {
            throw PriceCSVImportViewModelError.noSource
        }
        guard let mapping else {
            throw PriceCSVImportViewModelError.incompleteMapping
        }
        try await withWorking {
            preview = try await importer.preview(
                source: source,
                options: .init(
                    encoding: encoding,
                    delimiter: delimiter
                ),
                mapping: mapping,
                decimalFormat: decimalFormat,
                profileID: profileID,
                validFrom: validFrom,
                validUntil: hasExpiration ? validUntil : nil
            )
            report = nil
            decisions = [:]
        }
    }

    func applyConfirmed() async throws -> PriceImportReport {
        guard let preview else {
            throw PriceCSVImportViewModelError.noPreview
        }
        return try await withWorking {
            let result = try await importer.apply(
                preview: preview,
                decisions: decisions,
                confirmed: true
            )
            report = result
            return result
        }
    }

    private func inspectSource(resetMapping: Bool) async throws {
        guard let source else {
            throw PriceCSVImportViewModelError.noSource
        }
        let value = try await importer.inspect(
            source: source,
            options: .init(encoding: encoding, delimiter: delimiter)
        )
        inspection = value
        if resetMapping {
            typeIDColumn = uniqueHeader(
                value.headers,
                aliases: ["type_id", "typeid", "type id", "typ-id"]
            )
            priceColumn = uniqueHeader(
                value.headers,
                aliases: ["price", "unit_price", "unit price", "preis"]
            )
            itemNameColumn = uniqueHeader(
                value.headers,
                aliases: ["item_name", "item name", "name", "item"]
            )
        }
    }

    private func uniqueHeader(
        _ headers: [String],
        aliases: Set<String>
    ) -> Int? {
        let matches = headers.indices.filter {
            aliases.contains(CatalogSearchText.normalize(headers[$0]))
        }
        return matches.count == 1 ? matches[0] : nil
    }

    private func withWorking<T>(
        _ action: () async throws -> T
    ) async throws -> T {
        isWorking = true
        defer { isWorking = false }
        return try await action()
    }
}
