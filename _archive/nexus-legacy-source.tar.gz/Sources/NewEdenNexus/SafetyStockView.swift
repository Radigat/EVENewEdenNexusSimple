import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct SafetyStockSheet: View {
    let project: ProductionProjectSnapshot
    @ObservedObject var model: SafetyStockViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @Environment(\.dismiss) private var dismiss
    @State private var task: Task<Void, Never>?
    @State private var showingConfirmation = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header
            Divider()
            content
            Divider()
            footer
        }
        .padding(24)
        .frame(minWidth: 980, idealWidth: 1_120, minHeight: 700)
        .task { await load() }
        .onDisappear { task?.cancel() }
        .confirmationDialog(
            "Sicherheitsbestände übernehmen?",
            isPresented: $showingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Bestandsregeln übernehmen") {
                run(operation: .inventorySave) {
                    try await model.applyConfirmedPreview()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Globale Regeln werden für die gezeigten Type-IDs atomar gespeichert. Physische Bestände und P22-Ausschlüsse bleiben unverändert."
            )
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Sicherheitsbestände")
                .font(.title2.bold())
            Text(project.name)
                .foregroundStyle(.secondary)
            Label(
                "P23 schützt globale Materialmengen. P24 reserviert sie; P25 prüft konkurrierende Bindungen.",
                systemImage: "shield.checkered"
            )
            .font(.callout)
            .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var content: some View {
        if model.isLoading && model.preview == nil {
            ProgressView("Sicherheitsbestände werden geladen …")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let preview = model.preview {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    summary(preview)
                    if !model.isPreviewCurrent {
                        Label(
                            "Regeln geändert – Detailvorschau neu berechnen.",
                            systemImage: "exclamationmark.triangle"
                        )
                        .foregroundStyle(.orange)
                    }
                    materialRows(preview)
                }
            }
        } else {
            ContentUnavailableView {
                Label(
                    "Keine Sicherheitsbestandsvorschau",
                    systemImage: "shield.slash"
                )
            } description: {
                Text(
                    "Ein aktueller Produktionsgraph und ein gültiger P22-Bestandsabgleich sind erforderlich."
                )
            }
        }
    }

    private func summary(_ preview: SafetyStockPreview) -> some View {
        HStack(spacing: 24) {
            summaryTile(
                "Geschützte Materialien",
                preview.calculation.protectedMaterialCount,
                color: .blue
            )
            summaryTile(
                "Mit Hinweisen",
                preview.calculation.warningMaterialCount,
                color: .orange
            )
            summaryTile(
                "Vollständig gedeckt",
                preview.calculation.fullyCoveredMaterialCount,
                color: .green
            )
            Spacer()
            Text("Schutzformel v\(preview.calculation.formulaVersion)")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    private func summaryTile(
        _ title: String,
        _ value: Int,
        color: Color
    ) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(value))
                .font(.title3.bold())
                .foregroundStyle(color)
                .monospacedDigit()
        }
    }

    private func materialRows(
        _ preview: SafetyStockPreview
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Bestandsregeln und Detailvorschau")
                .font(.headline)
            if preview.calculation.lines.isEmpty {
                Text("Der Produktionsgraph enthält keine Endmaterialien.")
                    .foregroundStyle(.secondary)
            }
            ForEach(
                preview.calculation.lines,
                id: \.availability.typeID
            ) { line in
                materialRow(line)
            }
        }
    }

    private func materialRow(_ line: SafetyStockLine) -> some View {
        let typeID = line.availability.typeID
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(line.availability.name)
                        .fontWeight(.semibold)
                    Text("Type-ID \(typeID)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if let alert = line.primaryAlert {
                    Label(
                        alertLabel(alert),
                        systemImage: alertSymbol(alert.kind)
                    )
                    .foregroundStyle(alertColor(alert.kind))
                } else {
                    Label(
                        "Keine Schwelle unterschritten",
                        systemImage: "checkmark.circle"
                    )
                    .foregroundStyle(.green)
                }
            }
            HStack(spacing: 12) {
                quantityField(
                    "Sicherheitsbestand",
                    typeID: typeID,
                    keyPath: \.safety
                )
                quantityField(
                    "Mindestbestand",
                    typeID: typeID,
                    keyPath: \.minimum
                )
                quantityField(
                    "Warnschwelle",
                    typeID: typeID,
                    keyPath: \.warning
                )
                quantityField(
                    "Zielbestand",
                    typeID: typeID,
                    keyPath: \.target
                )
            }
            Grid(
                alignment: .trailing,
                horizontalSpacing: 16,
                verticalSpacing: 4
            ) {
                valueRow(
                    "Bruttobedarf",
                    line.availability.requiredQuantity,
                    "P22 einbeziehbar",
                    line.availability.eligiblePhysicalQuantity
                )
                valueRow(
                    "Aktiv außerhalb P22",
                    line.activeOutsideP22Quantity,
                    "Schutz außerhalb P22 gedeckt",
                    line.safetyCoveredOutsideP22Quantity
                )
                valueRow(
                    "Aus P22 geschützt",
                    line.protectedFromP22Quantity,
                    "Nach Schutz verfügbar",
                    line.availableAfterSafetyStockQuantity
                )
                valueRow(
                    "Für Projekt verwendbar",
                    line.usableQuantity,
                    "P23-Fehlmenge",
                    line.uncoveredQuantity
                )
                valueRow(
                    "Prognostizierter aktiver Rest",
                    line.projectedActiveRemainingQuantity,
                    "Auffüllung bis Ziel",
                    line.targetReplenishmentQuantity
                )
            }
            .font(.caption)
            .monospacedDigit()

            ForEach(line.alerts, id: \.kind) { alert in
                Label(
                    alertDetail(alert),
                    systemImage: alertSymbol(alert.kind)
                )
                .font(.caption)
                .foregroundStyle(alertColor(alert.kind))
            }
        }
        .padding(12)
        .background(.secondary.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .accessibilityElement(children: .contain)
    }

    private func quantityField(
        _ title: String,
        typeID: Int64,
        keyPath: WritableKeyPath<SafetyStockFieldTexts, String>
    ) -> some View {
        TextField(
            title,
            text: Binding(
                get: { model.texts(typeID: typeID)[keyPath: keyPath] },
                set: {
                    model.setText(
                        $0,
                        typeID: typeID,
                        keyPath: keyPath
                    )
                }
            )
        )
        .frame(minWidth: 130)
        .accessibilityLabel("\(title) für Type-ID \(typeID)")
    }

    private func valueRow(
        _ leftTitle: String,
        _ leftValue: Int64,
        _ rightTitle: String,
        _ rightValue: Int64
    ) -> some View {
        GridRow {
            Text(leftTitle).foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(leftValue))
            Text(rightTitle).foregroundStyle(.secondary)
            Text(NexusNumberFormat.quantity(rightValue))
        }
    }

    private func alertLabel(_ alert: SafetyStockAlert) -> String {
        switch alert.kind {
        case .safetyStock: "Sicherheitsbestand unterschritten"
        case .minimum: "Mindestbestand unterschritten"
        case .warning: "Warnschwelle unterschritten"
        case .target: "Zielbestand unterschritten"
        }
    }

    private func alertDetail(_ alert: SafetyStockAlert) -> String {
        "\(alertLabel(alert)): Rest \(NexusNumberFormat.quantity(alert.projectedQuantity)), Schwelle \(NexusNumberFormat.quantity(alert.thresholdQuantity)), Differenz \(NexusNumberFormat.quantity(alert.shortfallQuantity))."
    }

    private func alertSymbol(_ kind: SafetyStockAlertKind) -> String {
        switch kind {
        case .safetyStock: "exclamationmark.octagon.fill"
        case .minimum: "exclamationmark.triangle.fill"
        case .warning: "exclamationmark.circle"
        case .target: "info.circle"
        }
    }

    private func alertColor(_ kind: SafetyStockAlertKind) -> Color {
        switch kind {
        case .safetyStock: .red
        case .minimum: .orange
        case .warning: .yellow
        case .target: .blue
        }
    }

    private var footer: some View {
        HStack {
            Button("Schließen") { dismiss() }
            Spacer()
            if model.isPreviewing || model.isSaving {
                ProgressView(
                    model.isSaving
                        ? "Bestandsregeln werden gespeichert …"
                        : "Schutzvorschau wird berechnet …"
                )
                Button("Abbrechen") { task?.cancel() }
            }
            Button("Vorschau berechnen") {
                run(operation: .inventoryLoad) {
                    try await model.calculatePreview()
                }
            }
            .keyboardShortcut("s", modifiers: [.command, .shift])
            .disabled(
                model.isLoading || model.isPreviewing || model.isSaving
            )
            Button("Bestandsregeln übernehmen") {
                showingConfirmation = true
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut(.defaultAction)
            .disabled(!model.canApply)
        }
    }

    private func load() async {
        do {
            try await model.load(projectID: project.id)
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .inventoryLoad,
                retry: {
                    Task {
                        await load()
                    }
                }
            )
        }
    }

    private func run(
        operation: NexusOperation,
        _ action: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: operation)
            }
        }
    }
}
