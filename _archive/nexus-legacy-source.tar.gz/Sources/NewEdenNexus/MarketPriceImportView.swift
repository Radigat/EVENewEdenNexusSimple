import NewEdenNexusApplication
import SwiftUI

struct MarketPriceImportSheet: View {
    @ObservedObject var model: MarketPriceImportViewModel
    let applied: @MainActor (UUID) async throws -> Void
    let reportError: @MainActor (any Error, NexusOperation) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var showingConfirmation = false
    @State private var task: Task<Void, Never>?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("ESI-Materialpreise")
                        .font(.title2.bold())
                    Text(
                        "Nur aktuelle Einkaufsmengen werden geprüft. Die Vorschau schreibt keine Daten."
                    )
                    .foregroundStyle(.secondary)
                }
                Spacer()
                Button("Schließen") { dismiss() }
                    .keyboardShortcut(.cancelAction)
            }
            configuration
            Divider()
            content
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(minWidth: 900, minHeight: 660)
        .task {
            await model.loadLocationDirectory()
        }
        .onDisappear { task?.cancel() }
        .confirmationDialog(
            "ESI-Materialpreise übernehmen?",
            isPresented: $showingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Geprüfte Preise speichern") {
                run(.marketPriceApply) {
                    let profileID =
                        try await model.applyConfirmedPreview()
                    try await applied(profileID)
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Nur markierte Materialpreise werden atomar eingefügt oder ersetzt. Zielerlös, Lager und Projekte bleiben unverändert."
            )
        }
    }

    private var configuration: some View {
        Grid(alignment: .leading, horizontalSpacing: 14, verticalSpacing: 8) {
            GridRow {
                Text("Ziel-Preissatz")
                Picker(
                    "Ziel-Preissatz",
                    selection: Binding(
                        get: { model.selectedProfileID },
                        set: {
                            model.selectedProfileID = $0
                            model.markInputsChanged()
                        }
                    )
                ) {
                    Text("Keiner – nur Vorschau")
                        .tag(Optional<UUID>.none)
                    ForEach(model.profiles) { profile in
                        Text(profile.name).tag(Optional(profile.id))
                    }
                }
                .labelsHidden()
            }
            GridRow {
                Color.clear.frame(width: 100, height: 1)
                Text(
                    "Preissätze trennen Preisstände wie „Jita Einkauf“ oder „manuell konservativ“. Alle Werte bleiben ISK. Ohne Ziel-Preissatz ist nur die schreibfreie Vorschau möglich."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            GridRow {
                Text("Neu anlegen")
                HStack {
                    TextField(
                        "Zum Beispiel Jita Einkauf",
                        text: $model.newProfileName
                    )
                    .textFieldStyle(.roundedBorder)
                    Button("Preissatz anlegen") {
                        run(.marketPriceApply) {
                            try await model.createTargetProfile()
                        }
                    }
                    .disabled(!model.canCreateProfile)
                    .accessibilityIdentifier(
                        "marketPrices.createTargetPriceSet"
                    )
                }
            }
            GridRow {
                Text("Region")
                Picker(
                    "Region",
                    selection: Binding(
                        get: { model.selectedRegionID },
                        set: { model.selectRegion($0) }
                    )
                ) {
                    Text("Region wählen")
                        .tag(Optional<Int64>.none)
                    ForEach(model.regions) { region in
                        Text(region.name)
                            .tag(Optional(region.regionID))
                    }
                }
                .labelsHidden()
                .disabled(model.isLoadingDirectory)
            }
            GridRow {
                Text("Schnellwahl")
                Menu("Trade Hub wählen") {
                    ForEach(MarketTradeHubPreset.all) { hub in
                        Button(hub.name) {
                            model.selectLocation(hub.locationID)
                        }
                    }
                }
                .disabled(model.isLoadingDirectory)
            }
            GridRow {
                Text("Marktstandort")
                Picker(
                    "Marktstandort",
                    selection: Binding(
                        get: { model.selectedLocationID },
                        set: { model.selectLocation($0) }
                    )
                ) {
                    Text(
                        model.selectedRegion.map {
                            "Gesamte Region „\($0.name)“"
                        } ?? "Gesamte Region"
                    )
                    .tag(Optional<Int64>.none)
                    ForEach(model.locationsForSelectedRegion) { location in
                        Text(
                            "\(location.name) · \(kindText(location.kind))"
                        )
                        .tag(Optional(location.locationID))
                        .disabled(
                            location.kind == .accessibleStructure
                        )
                    }
                }
                .labelsHidden()
                .disabled(
                    model.selectedRegionID == nil
                        || model.isLoadingDirectory
                )
            }
            if model.isLoadingDirectory {
                GridRow {
                    Color.clear.frame(width: 100, height: 1)
                    ProgressView("Regionen und bekannte Standorte laden …")
                }
            }
            ForEach(model.directoryWarnings, id: \.self) { warning in
                GridRow {
                    Color.clear.frame(width: 100, height: 1)
                    Label(warning, systemImage: "exclamationmark.triangle")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            }
            GridRow {
                Color.clear.frame(width: 100, height: 1)
                HStack {
                    Text(
                        "„Gesamte Region“ verwendet alle öffentlichen Verkaufsorders. Die fünf NPC-Trade-Hubs sind Schnellwahlen. Lokal bekannte Stationen sowie Spielerstrukturen erscheinen nach einem aktuellen persönlichen ESI-/Strukturnamenabruf. Nicht öffentliche Strukturmärkte bleiben sichtbar, aber bis zu einer gesonderten privaten Marktfreigabe nicht auswählbar."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Spacer()
                    Button("Vorschau abrufen") {
                        run(.marketPriceInspect) {
                            try await model.createPreview()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!model.canPreview)
                }
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if model.isWorking {
            ProgressView("Marktorders werden geprüft …")
                .frame(maxWidth: .infinity, minHeight: 140)
        } else if let preview = model.preview {
            previewContent(preview)
        } else if let report = model.report {
            ContentUnavailableView {
                Label(
                    "Materialpreise gespeichert",
                    systemImage: "checkmark.circle.fill"
                )
            } description: {
                Text(
                    "\(NexusNumberFormat.quantity(report.lines.filter { [.inserted, .replaced].contains($0.result) }.count)) Preis(e) wurden bestätigt übernommen."
                )
            } actions: {
                Button("Schließen") { dismiss() }
            }
        } else {
            ContentUnavailableView {
                Label(
                    "Noch keine Marktvorschau",
                    systemImage: "chart.line.uptrend.xyaxis"
                )
            } description: {
                Text(
                    "\(NexusNumberFormat.quantity(model.requirements.count)) Materialposition(en) werden nach Type-ID abgefragt."
                )
            }
            .frame(maxWidth: .infinity, minHeight: 180)
        }
    }

    private func previewContent(
        _ preview: MarketPriceImportPreview
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Vorschau").font(.headline)
                Spacer()
                Text(
                    preview.profile == nil
                        ? "\(NexusNumberFormat.quantity(preview.lines.count)) geprüft · nur Vorschau"
                        : "\(NexusNumberFormat.quantity(preview.changedLines.count)) Änderung(en) · \(NexusNumberFormat.quantity(preview.lines.count)) geprüft"
                )
                .foregroundStyle(.secondary)
            }
            Table(preview.lines) {
                TableColumn("Material") { line in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(line.itemName)
                        Text("Type-ID \(line.typeID)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                TableColumn("Menge") { line in
                    Text(
                        "\(NexusNumberFormat.quantity(line.requestedQuantity)) / \(NexusNumberFormat.quantity(line.availableQuantity))"
                    )
                    .monospacedDigit()
                }
                .width(110)
                TableColumn("Preis") { line in
                    Text(
                        line.quote.map {
                            NexusNumberFormat.isk(
                                hundredths: $0.unitPrice.hundredths
                            )
                        } ?? "—"
                    )
                    .monospacedDigit()
                }
                .width(140)
                TableColumn("Status") { line in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(
                            preview.profile == nil && line.quote != nil
                                ? "Marktpreis verfügbar"
                                : stateText(line.state)
                        )
                        Text(detailText(line))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
            }
            HStack {
                Label {
                    Text(
                        preview.profile == nil
                            ? "Nur Vorschau – kein Ziel-Preissatz ausgewählt"
                            : "Keine Preisänderung ohne Bestätigung"
                    )
                } icon: {
                    Image(
                        systemName: preview.profile == nil
                            ? "eye"
                            : "checkmark.shield"
                    )
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                Spacer()
                Button("Geprüfte Preise übernehmen") {
                    showingConfirmation = true
                }
                .buttonStyle(.borderedProminent)
                .disabled(!model.canApply)
            }
        }
    }

    private func run(
        _ operation: NexusOperation,
        action: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                reportError(error, operation)
            }
        }
    }

    private func detailText(_ line: MarketPricePreviewLine) -> String {
        if let message = line.message {
            return message
        }
        guard let quote = line.quote else { return "Kein Preis" }
        return
            "\(NexusNumberFormat.quantity(quote.orderCount)) Order(s) · \(sourceText(quote.source)) · \(quote.ordersFetchedAt.formatted(date: .abbreviated, time: .shortened))"
    }

    private func stateText(_ state: MarketPricePreviewState) -> String {
        switch state {
        case .insert: "Neu"
        case .replacementRequired: "Ersetzen"
        case .unchanged: "Unverändert"
        case .noOrders: "Keine Orders"
        case .insufficientVolume: "Menge nicht gedeckt"
        case .failed: "Prüfung fehlgeschlagen"
        }
    }

    private func sourceText(_ source: MarketPriceQuoteSource) -> String {
        switch source {
        case .freshCache: "frischer Cache"
        case .network: "ESI"
        case .notModified: "ESI 304"
        case .offlineCache: "Offline-Cache"
        case .limitedCache: "Limit-Cache"
        case .serverFallback: "Server-Fallback"
        }
    }

    private func kindText(_ kind: MarketLocationKind) -> String {
        switch kind {
        case .tradeHub: "Trade Hub"
        case .npcStation: "bekannte Station"
        case .publicStructure: "öffentliche Struktur"
        case .accessibleStructure: "privater Markt – noch nicht aktiviert"
        }
    }
}
