import Foundation

enum EVEPublicConfiguration {
    static let clientID = "40aaba007d504673bffc14291a8a088c"
    static let redirectURI = "http://localhost:52721/callback"

    private static let previousDefaultClientID =
        "d8c11eb33bf5483fb8907df5a3b0eaeb"
    private static let previousRedirectURI = "newedennexus://callback"

    static func applyDefaults(to defaults: UserDefaults = .standard) {
        let storedClientID = defaults.string(forKey: "eve.clientID")
        if storedClientID?.isEmpty != false ||
            storedClientID == previousDefaultClientID {
            defaults.set(clientID, forKey: "eve.clientID")
        }

        let storedRedirectURI = defaults.string(forKey: "eve.redirectURI")
        if storedRedirectURI?.isEmpty != false ||
            storedRedirectURI == previousRedirectURI {
            defaults.set(redirectURI, forKey: "eve.redirectURI")
        }
    }
}
