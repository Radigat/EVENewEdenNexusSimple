import AppKit
import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct ProductionWorkspaceView: View {
    let project: ProductionProjectSnapshot
    let graph: ProductionGraphSnapshot
    let section: ProductionWorkspaceSection
    @ObservedObject var model: BuildOrBuyWorkspaceViewModel
    @ObservedObject var conflictModel: ReservationConflictViewModel
    let refresh: @MainActor () -> Void
    let reportError: @MainActor (any Error) -> Void
    @EnvironmentObject private var runtime: NexusAppRuntime

    @State private var showingApplyConfirmation = false
    @State private var showingBudgetConfirmation = false
    @State private var showingShoppingConfirmation = false
    @State private var marketPriceModel: MarketPriceImportViewModel?
    @State private var task: Task<Void, Never>?
    @State private var selectedDecisionCategory: BuildOrBuyStageCategory?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusHeader
            if let message = model.lastErrorMessage {
                errorState(message)
            }
            if model.isLoading && validPreview == nil {
                ProgressView("Produktionsplanung wird geladen …")
                    .frame(maxWidth: .infinity, minHeight: 140)
            } else if let preview = validPreview {
                plan(preview)
            } else if model.lastErrorMessage == nil {
                emptyState
            }
        }
        .confirmationDialog(
            "Build-or-Buy-Entscheidungen übernehmen?",
            isPresented: $showingApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button("Entscheidungen speichern") {
                run {
                    try await model.applyConfirmedPreview()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Gespeichert werden nur die projektbezogenen Kaufentscheidungen. Lagerbestände und Reservierungen bleiben unverändert."
            )
        }
        .confirmationDialog(
            "Projektbudget speichern?",
            isPresented: $showingBudgetConfirmation,
            titleVisibility: .visible
        ) {
            Button("Budgetbasis speichern") {
                run {
                    try await model.applyConfirmedBudget()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Gespeichert werden nur der projektbezogene Preissatz sowie Logistik- und Produktionskosten. Preise, Lager, Einkaufsmengen und Build-or-Buy-Entscheidungen bleiben unverändert."
            )
        }
        .confirmationDialog(
            "Einkaufsmengen speichern?",
            isPresented: $showingShoppingConfirmation,
            titleVisibility: .visible
        ) {
            Button("Einkaufsmengen speichern") {
                run {
                    try await model.applyConfirmedShopping()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Gespeichert werden nur Abweichungen von den aktuell berechneten Fehlmengen. Lager, Reservierungen und Build-or-Buy-Entscheidungen bleiben unverändert."
            )
        }
        .sheet(item: $marketPriceModel) { marketModel in
            MarketPriceImportSheet(
                model: marketModel,
                applied: { profileID in
                    try await model.refreshAfterMarketPriceImport(
                        profileID: profileID
                    )
                },
                reportError: { error, operation in
                    runtime.report(error, operation: operation)
                }
            )
        }
        .onDisappear {
            task?.cancel()
        }
    }

    private var statusHeader: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline) {
                workspaceHeading
                Spacer()
                conflictStatus
                refreshButton
            }
            VStack(alignment: .leading, spacing: 10) {
                workspaceHeading
                HStack {
                    conflictStatus
                    Spacer()
                    refreshButton
                }
            }
        }
    }

    private var workspaceHeading: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("Produktionsplanung · \(section.title)")
                .font(.title3.bold())
                .accessibilityAddTraits(.isHeader)
            Text(
                "Lager, Sicherheitsbestände und fremde Reservierungen sind bereits verrechnet."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var refreshButton: some View {
        Button {
            refresh()
        } label: {
            Label("Plan aktualisieren", systemImage: "arrow.clockwise")
        }
        .keyboardShortcut("p", modifiers: [.command, .shift])
        .disabled(model.isLoading || model.isPreviewing || model.isSaving)
        .accessibilityLabel(
            "Produktionsplan, Lager und Reservierungskonflikte aktualisieren"
        )
    }

    @ViewBuilder
    private var conflictStatus: some View {
        if conflictModel.isLoading {
            ProgressView()
                .controlSize(.small)
                .accessibilityLabel("Reservierungskonflikte werden geprüft")
        } else if let conflict = conflictModel.preview,
            conflict.projectID == project.id,
            conflict.graphID == graph.id
        {
            if conflict.analysisBefore.hasConflicts {
                Label(
                    "\(NexusNumberFormat.quantity(conflict.analysisBefore.conflicts.count)) Konflikt(e)",
                    systemImage: "exclamationmark.triangle.fill"
                )
                .foregroundStyle(.orange)
                .accessibilityLabel(
                    "\(NexusNumberFormat.quantity(conflict.analysisBefore.conflicts.count)) Reservierungskonflikte erkannt"
                )
            } else {
                Label(
                    "Keine Konflikte",
                    systemImage: "checkmark.circle.fill"
                )
                .foregroundStyle(NexusTheme.teal)
                .accessibilityLabel(
                    "Keine Reservierungskonflikte erkannt"
                )
            }
        }
    }

    private var validPreview: BuildOrBuyPlanPreview? {
        guard let preview = model.preview,
            preview.projectID == project.id,
            preview.sourceVersion.graphID == graph.id
        else {
            return nil
        }
        return preview
    }

    @ViewBuilder
    private func plan(_ preview: BuildOrBuyPlanPreview) -> some View {
        switch section {
        case .overview:
            VStack(alignment: .leading, spacing: 16) {
                overviewSection(preview)
                jobSection(preview)
            }
        case .decisions:
            decisionSection(preview)
        case .inventory:
            requirementSection(preview)
        case .economics:
            budgetSection
        case .materials, .stages:
            EmptyView()
        }
    }

    private func overviewSection(
        _ preview: BuildOrBuyPlanPreview
    ) -> some View {
        GroupBox("Planübersicht") {
            Grid(
                alignment: .leading,
                horizontalSpacing: 32,
                verticalSpacing: 12
            ) {
                GridRow {
                    overviewMetric(
                        "Produktionsjobs",
                        NexusNumberFormat.quantity(
                            preview.plan.productionJobs.count
                        )
                    )
                    overviewMetric(
                        "Inventionsjobs",
                        NexusNumberFormat.quantity(
                            preview.plan.inventionJobs.count
                        )
                    )
                    overviewMetric(
                        "Materialpositionen",
                        NexusNumberFormat.quantity(
                            preview.plan.requirements.count
                        )
                    )
                    overviewMetric(
                        "Kaufpositionen",
                        NexusNumberFormat.quantity(
                            preview.plan.requirements
                                .filter { $0.missingQuantity > 0 }
                                .count
                        )
                    )
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 4)
        }
    }

    private func overviewMetric(
        _ title: String,
        _ value: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title3.weight(.semibold))
                .monospacedDigit()
        }
        .accessibilityElement(children: .combine)
    }

    private var budgetSection: some View {
        GroupBox("Benötigtes Projektbudget") {
            VStack(alignment: .leading, spacing: 12) {
                Text(
                    "Das Materialbudget folgt der wirksamen Einkaufsliste. Im Bereich „Bauen / Kaufen“ legst du je Produktionsart oder einzelner Zwischenstufe fest, ob Rohstoffe beziehungsweise Komponenten oder das Zwischenprodukt gekauft werden."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        budgetInputs
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        budgetInputs
                    }
                }
                if !model.isBudgetPreviewCurrent {
                    Label(
                        "Preissatz oder Kosten geändert – Budget neu berechnen.",
                        systemImage: "arrow.triangle.2.circlepath"
                    )
                    .font(.caption)
                    .foregroundStyle(.orange)
                }
                if let budget = model.budgetPreview {
                    if !budget.missingPrices.isEmpty {
                        VStack(alignment: .leading, spacing: 4) {
                            Label(
                                "Das Materialbudget ist wegen fehlender Einkaufspreise noch unvollständig.",
                                systemImage: "exclamationmark.triangle.fill"
                            )
                            .foregroundStyle(.orange)
                            ForEach(
                                budget.missingPrices,
                                id: \.typeID
                            ) { missing in
                                Text(missing.name)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    } else if let calculation = budget.calculation {
                        budgetSummary(calculation)
                    } else {
                        Text(
                            "Wähle einen Preissatz, um das benötigte Budget zu berechnen."
                        )
                        .foregroundStyle(.secondary)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 4)
        }
    }

    @ViewBuilder
    private var budgetInputs: some View {
        Group {
            Picker(
                "Preissatz",
                selection: Binding(
                    get: {
                        model.selectedBudgetProfileID
                    },
                    set: {
                        model.setBudgetProfile($0)
                    }
                )
            ) {
                Text("Kein Preissatz").tag(Optional<UUID>.none)
                ForEach(model.economicsProfiles) { profile in
                    Text(profile.name).tag(Optional(profile.id))
                }
            }
            .frame(maxWidth: 300)
            .accessibilityLabel(
                "Preissatz für das Materialbudget"
            )
            HStack(spacing: 6) {
                Text("Logistikkosten")
                TextField(
                    "Betrag",
                    text: Binding(
                        get: { model.logisticsCostText },
                        set: { model.setLogisticsCostText($0) }
                    )
                )
                .frame(width: 145)
                .multilineTextAlignment(.trailing)
                .accessibilityLabel("Logistikkosten in ISK")
                Text("ISK")
                    .foregroundStyle(.secondary)
            }
            HStack(spacing: 6) {
                Text("Produktionskosten")
                TextField(
                    "Betrag",
                    text: Binding(
                        get: { model.productionCostText },
                        set: { model.setProductionCostText($0) }
                    )
                )
                .frame(width: 155)
                .multilineTextAlignment(.trailing)
                .accessibilityLabel("Produktionskosten in ISK")
                Text("ISK")
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button("Budget berechnen") {
                run {
                    try await model.calculateBudgetPreview()
                }
            }
            .disabled(
                model.isLoading
                    || model.isPreviewing
                    || model.isSaving
            )
            Button("ESI-Materialpreise") {
                marketPriceModel =
                    model.makeMarketPriceImportViewModel()
            }
            .disabled(!model.canStartMarketPriceImport)
            Button("Budgetbasis speichern") {
                showingBudgetConfirmation = true
            }
            .buttonStyle(.borderedProminent)
            .disabled(!model.canApplyBudget)
        }
    }

    private func budgetSummary(
        _ calculation: ProjectBudgetCalculation
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Grid(alignment: .leading, horizontalSpacing: 28) {
                GridRow {
                    metric(
                        "Materialeinkauf",
                        calculation.materialPurchaseCost
                    )
                    metric(
                        "Logistik",
                        ISKValue(
                            hundredths:
                                calculation.logisticsCost.hundredths
                        )
                    )
                    metric(
                        "Produktion",
                        ISKValue(
                            hundredths:
                                calculation.productionCost.hundredths
                        )
                    )
                    metric(
                        "Benötigtes Budget",
                        calculation.requiredBudget,
                        color: NexusTheme.teal
                    )
                }
            }
            Divider()
            if calculation.materialLines.isEmpty {
                Text(
                    "Für den aktuellen Plan sind keine Materialien einzukaufen."
                )
                .foregroundStyle(.secondary)
            } else {
                ForEach(
                    calculation.materialLines,
                    id: \.typeID
                ) { line in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(line.name)
                            Text(purchaseKindLabel(line))
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(
                            "\(NexusNumberFormat.quantity(line.purchaseQuantity)) × \(NexusNumberFormat.isk(hundredths: line.unitPrice.hundredths))"
                        )
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                        Text(
                            NexusNumberFormat.isk(
                                hundredths: line.cost.hundredths
                            )
                        )
                        .frame(
                            minWidth: 140,
                            alignment: .trailing
                        )
                        .monospacedDigit()
                    }
                    .font(.caption)
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel(
                        "\(line.name), \(purchaseKindLabel(line)), Einkaufsmenge \(NexusNumberFormat.quantity(line.purchaseQuantity)), Einheitspreis \(NexusNumberFormat.isk(hundredths: line.unitPrice.hundredths)), Kosten \(NexusNumberFormat.isk(hundredths: line.cost.hundredths))"
                    )
                }
            }
        }
    }

    private func purchaseKindLabel(
        _ line: ProjectBudgetMaterialLine
    ) -> String {
        let kinds = Set(line.sources.map(\.kind))
        if kinds.contains(.boughtIntermediate) {
            return "Direkt gekauftes Zwischenprodukt"
        }
        if kinds.contains(.inventionMaterial) {
            return "Invention-Material"
        }
        return "Rohstoff oder Komponente"
    }

    private func metric(
        _ title: String,
        _ value: ISKValue,
        color: Color = .primary
    ) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(
                NexusNumberFormat.isk(
                    hundredths: value.hundredths
                )
            )
            .fontWeight(.semibold)
            .foregroundStyle(color)
            .monospacedDigit()
        }
        .accessibilityElement(children: .combine)
    }

    private func decisionSection(
        _ preview: BuildOrBuyPlanPreview
    ) -> some View {
        GroupBox("Bauen oder Kaufen nach Produktionsart") {
            VStack(alignment: .leading, spacing: 10) {
                if model.stages.isEmpty {
                    Text(
                        "Dieses Projekt besitzt keine umschaltbare Zwischenstufe."
                    )
                    .foregroundStyle(.secondary)
                } else {
                    Text(
                        "Filtere nach Produktionsart, wähle eine ganze Gruppe oder setze alle Stufen gemeinsam. Einzelne Abweichungen bleiben möglich."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)

                    decisionControls

                    ForEach(filteredStageGroups) { group in
                        decisionGroup(group)
                    }
                }
                if !model.isPreviewCurrent {
                    Label(
                        "Entscheidungen geändert – Vorschau neu berechnen.",
                        systemImage: "arrow.triangle.2.circlepath"
                    )
                    .font(.caption)
                    .foregroundStyle(.orange)
                }
                if !preview.staleDecisionTypeIDs.isEmpty {
                    Label(
                        "Veraltete Entscheidungen: \(preview.staleDecisionTypeIDs.map(String.init).joined(separator: ", "))",
                        systemImage: "exclamationmark.triangle"
                    )
                    .font(.caption)
                    .foregroundStyle(.red)
                }
                HStack {
                    Spacer()
                    Button("Vorschau berechnen") {
                        run {
                            try await model.calculatePreview()
                        }
                    }
                    .keyboardShortcut("v", modifiers: [.command, .shift])
                    .disabled(
                        model.isLoading
                            || model.isPreviewing
                            || model.isSaving
                    )
                    .accessibilityLabel(
                        "Build-or-Buy-Vorschau neu berechnen"
                    )
                    Button("Entscheidungen übernehmen") {
                        showingApplyConfirmation = true
                    }
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)
                    .disabled(!model.canApply)
                    .accessibilityLabel(
                        "Geprüfte Build-or-Buy-Entscheidungen speichern"
                    )
                }
            }
            .padding(.vertical, 4)
        }
    }

    private func jobSection(
        _ preview: BuildOrBuyPlanPreview
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            GroupBox("Produktionsjobs") {
                VStack(alignment: .leading, spacing: 8) {
                    if preview.plan.productionJobs.isEmpty {
                        Text("Keine Produktionsjobs erforderlich.")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(
                        preview.plan.productionJobs,
                        id: \.nodeID
                    ) { job in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(job.name)
                                .fontWeight(.medium)
                            Text(
                                "\(NexusNumberFormat.quantity(job.requiredRuns)) Runs · \(NexusNumberFormat.quantity(job.producedQuantity)) Ausgabe · \(NexusNumberFormat.quantity(job.inventoryQuantity)) aus Lager"
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .monospacedDigit()
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 4)
            }
            if !preview.plan.inventionJobs.isEmpty {
                GroupBox("Inventionsjobs") {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(
                            preview.plan.inventionJobs,
                            id: \.nodeID
                        ) { job in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(
                                    "Blueprint \(job.inventedBlueprintTypeID)"
                                )
                                .fontWeight(.medium)
                                Text(
                                    "\(NexusNumberFormat.quantity(job.requiredSuccessfulCopies)) erfolgreiche Kopie(n) · \(NexusNumberFormat.quantity(job.licensedRunsPerCopy)) lizenzierte Runs je Kopie · Basiswahrscheinlichkeit \(NexusNumberFormat.quantity(job.baseProbabilityMillionths)) ppm"
                                )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .monospacedDigit()
                            }
                            .accessibilityElement(children: .combine)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 4)
                }
            }
        }
    }

    private func decisionGroup(
        _ group: BuildOrBuyStageGroup
    ) -> some View {
        GroupBox {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Label(
                        group.category.title,
                        systemImage: group.category.systemImage
                    )
                    .fontWeight(.semibold)
                    Text(
                        group.stages.count == 1
                            ? "1 Stufe"
                            : "\(NexusNumberFormat.quantity(group.stages.count)) Stufen"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Spacer()
                    Text(groupChoiceLabel(group.category))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(group.category.explanation)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                HStack {
                    Button("Alle bauen") {
                        model.setChoice(
                            .build,
                            for: group.category
                        )
                    }
                    .disabled(
                        model.uniformChoice(in: group.category)
                            == .build
                    )
                    .accessibilityLabel(
                        "Alle Stufen in \(group.category.title) bauen"
                    )

                    Button("Alle kaufen") {
                        model.setChoice(
                            .buy,
                            for: group.category
                        )
                    }
                    .disabled(
                        model.uniformChoice(in: group.category)
                            == .buy
                    )
                    .accessibilityLabel(
                        "Alle Stufen in \(group.category.title) kaufen"
                    )
                    Spacer()
                }

                DisclosureGroup(
                    "Einzelentscheidungen"
                ) {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text("Item")
                            Spacer()
                            Text("Bauen oder Kaufen")
                                .frame(width: 190)
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)

                        Divider()

                        ForEach(group.stages) { stage in
                            decisionRow(stage)
                        }
                    }
                    .padding(.top, 6)
                }
                .accessibilityLabel(
                    "Einzelentscheidungen für \(group.category.title)"
                )
            }
        }
    }

    private func decisionRow(
        _ stage: BuildOrBuyStage
    ) -> some View {
        HStack {
            Text(stage.name)
                .fontWeight(.medium)
            Spacer()
            Picker(
                "Bauen oder Kaufen für \(stage.name)",
                selection: Binding(
                    get: {
                        model.choice(typeID: stage.typeID)
                    },
                    set: {
                        model.setChoice(
                            $0,
                            typeID: stage.typeID
                        )
                    }
                )
            ) {
                Text("Bauen").tag(BuildOrBuyChoice.build)
                Text("Kaufen").tag(BuildOrBuyChoice.buy)
            }
            .pickerStyle(.segmented)
            .labelsHidden()
            .frame(width: 190)
            .accessibilityLabel(
                "Zwischenstufe \(stage.name) bauen oder kaufen"
            )
        }
    }

    private var decisionControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center, spacing: 10) {
                Text("Produktionsart")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                ScrollView(.horizontal, showsIndicators: false) {
                    Picker(
                        "Produktionsart filtern",
                        selection: $selectedDecisionCategory
                    ) {
                        Text("Alle")
                            .tag(
                                Optional<BuildOrBuyStageCategory>.none
                            )
                        ForEach(model.stageGroups) { group in
                            Text(group.category.title)
                                .tag(
                                    Optional(group.category)
                                )
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                    .fixedSize(horizontal: true, vertical: false)
                }
            }

            HStack(spacing: 8) {
                Button {
                    model.setChoiceForAllStages(.build)
                } label: {
                    Label("Alles bauen", systemImage: "hammer.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(
                    model.uniformChoiceForAllStages == .build
                )
                .accessibilityLabel(
                    "Alle Produktionsstufen bauen"
                )

                Button {
                    model.setChoiceForAllStages(.buy)
                } label: {
                    Label("Alles kaufen", systemImage: "cart.fill")
                }
                .disabled(
                    model.uniformChoiceForAllStages == .buy
                )
                .accessibilityLabel(
                    "Alle Produktionsstufen kaufen"
                )

                Text(
                    "Wirkt zunächst nur auf den Entwurf."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                Spacer()
            }
        }
        .padding(10)
        .background(
            Color.secondary.opacity(0.08),
            in: RoundedRectangle(cornerRadius: 8)
        )
    }

    private var filteredStageGroups: [BuildOrBuyStageGroup] {
        guard let selectedDecisionCategory else {
            return model.stageGroups
        }
        let matches = model.stageGroups.filter {
            $0.category == selectedDecisionCategory
        }
        return matches.isEmpty ? model.stageGroups : matches
    }

    private func groupChoiceLabel(
        _ category: BuildOrBuyStageCategory
    ) -> String {
        switch model.uniformChoice(in: category) {
        case .build:
            "Alle bauen"
        case .buy:
            "Alle kaufen"
        case nil:
            "Gemischte Auswahl"
        }
    }

    private func requirementSection(
        _ preview: BuildOrBuyPlanPreview
    ) -> some View {
        GroupBox("Lager und Fehlmengen") {
            VStack(alignment: .leading, spacing: 8) {
                if preview.plan.requirements.isEmpty {
                    Text("Keine Materialanforderungen.")
                        .foregroundStyle(.secondary)
                }
                ForEach(
                    preview.plan.requirements,
                    id: \.typeID
                ) { line in
                    HStack(alignment: .firstTextBaseline) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(line.name)
                                .fontWeight(.medium)
                            Text("Type-ID \(line.typeID)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(
                                "Bedarf \(NexusNumberFormat.quantity(line.requiredQuantity)) · Lager \(NexusNumberFormat.quantity(line.inventoryQuantity))"
                            )
                            .font(.caption)
                            .monospacedDigit()
                            Text(
                                "Fehlt \(NexusNumberFormat.quantity(line.missingQuantity))"
                            )
                            .fontWeight(
                                line.missingQuantity > 0
                                    ? .semibold
                                    : .regular
                            )
                            .foregroundStyle(
                                line.missingQuantity > 0
                                    ? .orange
                                    : NexusTheme.teal
                            )
                            .monospacedDigit()
                        }
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel(
                        "\(line.name), Bedarf \(NexusNumberFormat.quantity(line.requiredQuantity)), aus Lager \(NexusNumberFormat.quantity(line.inventoryQuantity)), fehlt \(NexusNumberFormat.quantity(line.missingQuantity))"
                    )
                }
                Divider()
                if let shopping = model.shoppingPreview {
                    shoppingEditor(shopping)
                } else {
                    HStack {
                        Text(
                            "\(NexusNumberFormat.quantity(model.missingRequirements.count)) Kaufposition(en)"
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        Spacer()
                        copyShoppingButton
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 4)
        }
    }

    private func shoppingEditor(
        _ preview: ShoppingListPreview
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Einkaufsmengen")
                    .fontWeight(.semibold)
                Spacer()
                Text(
                    "\(NexusNumberFormat.quantity(preview.aggregation.effectivePositionCount)) Position(en) · \(NexusNumberFormat.quantity(preview.aggregation.totalPurchaseQuantity)) Einheit(en)"
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                .monospacedDigit()
            }
            if !preview.staleStoredOverrideTypeIDs.isEmpty {
                Label(
                    "Veraltete gespeicherte Overrides: \(preview.staleStoredOverrideTypeIDs.map(String.init).joined(separator: ", ")). Beim Speichern werden sie entfernt.",
                    systemImage: "exclamationmark.triangle.fill"
                )
                .font(.caption)
                .foregroundStyle(.orange)
            }
            if model.shoppingPositions.isEmpty {
                Text("Keine Materialien müssen eingekauft werden.")
                    .foregroundStyle(.secondary)
            }
            ForEach(model.shoppingPositions, id: \.typeID) { position in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 5) {
                            Text(position.name)
                                .fontWeight(.medium)
                            if position.isOverridden {
                                Text("Manuell")
                                    .font(.caption2)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 2)
                                    .background(
                                        Color.orange.opacity(0.16),
                                        in: Capsule()
                                    )
                            }
                        }
                        Text(
                            "Type-ID \(position.typeID) · berechnet \(NexusNumberFormat.quantity(position.calculatedQuantity))"
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }
                    Spacer()
                    TextField(
                        "Zielkaufmenge",
                        text: Binding(
                            get: {
                                model.shoppingQuantityTexts[
                                    position.typeID
                                ] ?? ""
                            },
                            set: {
                                model.setShoppingQuantityText(
                                    $0,
                                    typeID: position.typeID
                                )
                            }
                        )
                    )
                    .frame(width: 110)
                    .multilineTextAlignment(.trailing)
                    .monospacedDigit()
                    .accessibilityLabel(
                        "Zielkaufmenge für \(position.name)"
                    )
                    Button("Zurücksetzen") {
                        model.resetShoppingQuantity(
                            typeID: position.typeID
                        )
                    }
                    .buttonStyle(.link)
                    .disabled(
                        model.shoppingQuantityTexts[position.typeID]
                            == String(position.calculatedQuantity)
                    )
                    .accessibilityLabel(
                        "Kaufmenge für \(position.name) auf \(NexusNumberFormat.quantity(position.calculatedQuantity)) zurücksetzen"
                    )
                }
            }
            if !model.isShoppingPreviewCurrent {
                Label(
                    "Plan oder Menge geändert – Einkaufsliste neu berechnen.",
                    systemImage: "arrow.triangle.2.circlepath"
                )
                .font(.caption)
                .foregroundStyle(.orange)
            }
            HStack {
                Button("Einkaufsliste berechnen") {
                    run {
                        try await model.calculateShoppingPreview()
                    }
                }
                .disabled(
                    !model.isPreviewCurrent
                        || model.isLoading
                        || model.isPreviewing
                        || model.isSaving
                )
                Button("Overrides speichern") {
                    showingShoppingConfirmation = true
                }
                .buttonStyle(.borderedProminent)
                .disabled(!model.canApplyShopping)
                Spacer()
                copyShoppingButton
            }
        }
    }

    private var copyShoppingButton: some View {
        HStack {
            if model.copiedShoppingList {
                Label(
                    "Kopiert",
                    systemImage: "checkmark.circle.fill"
                )
                .font(.caption)
                .foregroundStyle(NexusTheme.teal)
            }
            Button("Einkaufsliste kopieren") {
                copyShoppingList()
            }
            .keyboardShortcut("c", modifiers: [.command, .shift])
            .disabled(model.shoppingListText.isEmpty)
            .accessibilityLabel(
                "Wirksame Einkaufsmengen als Textliste kopieren"
            )
        }
    }

    private func errorState(_ message: String) -> some View {
        HStack {
            Label(message, systemImage: "exclamationmark.triangle")
                .foregroundStyle(.red)
            Spacer()
            Button("Erneut versuchen") {
                refresh()
            }
        }
        .accessibilityElement(children: .contain)
    }

    private var emptyState: some View {
        ContentUnavailableView {
            Label(
                "Produktionsplan nicht verfügbar",
                systemImage: "hammer"
            )
        } description: {
            Text(
                "Aktualisiere den Graphen und lade die lokale Planung erneut."
            )
        } actions: {
            Button("Plan erneut laden") {
                refresh()
            }
        }
    }

    private func copyShoppingList() {
        let text = model.shoppingListText
        guard !text.isEmpty else { return }
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        guard pasteboard.setString(text, forType: .string) else {
            reportError(
                BuildOrBuyWorkspaceClipboardError.writeFailed
            )
            return
        }
        model.markShoppingListCopied()
    }

    private func run(
        _ operation: @escaping @MainActor () async throws -> Void
    ) {
        task?.cancel()
        task = Task {
            do {
                try await operation()
            } catch is CancellationError {
                return
            } catch {
                reportError(error)
            }
        }
    }
}

private enum BuildOrBuyWorkspaceClipboardError: Error {
    case writeFailed
}
