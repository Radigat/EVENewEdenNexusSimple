import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum ReservationConflictViewModelError: Error, Equatable {
    case operationAlreadyRunning
    case invalidQuantity(reservationID: UUID)
    case previewRequired
}

enum ReservationConflictEditMode:
    String,
    CaseIterable,
    Identifiable
{
    case keep = "Beibehalten"
    case reduce = "Reduzieren"
    case release = "Freigeben"

    var id: String { rawValue }
}

struct ReservationConflictFieldState: Equatable {
    var mode: ReservationConflictEditMode = .keep
    var quantity = ""
}

@MainActor
final class ReservationConflictViewModel: ObservableObject {
    @Published private(set) var preview: ReservationConflictPreview?
    @Published private(set) var isLoading = false
    @Published private(set) var isPreviewing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreviewCurrent = false
    @Published private(set) var fields:
        [UUID: ReservationConflictFieldState] = [:]

    private let service: any ReservationConflictManaging
    private var projectID: UUID?

    init(service: any ReservationConflictManaging) {
        self.service = service
    }

    var canApply: Bool {
        guard let preview else { return false }
        return !preview.resolutions.isEmpty
            && !preview.analysisAfter.hasConflicts
            && isPreviewCurrent
            && !isSaving
    }

    func load(projectID: UUID) async throws {
        guard !isBusy else {
            throw ReservationConflictViewModelError
                .operationAlreadyRunning
        }
        self.projectID = projectID
        isLoading = true
        defer { isLoading = false }
        let loaded = try await service.preview(
            projectID: projectID,
            resolutions: nil
        )
        try Task.checkCancellation()
        preview = loaded
        applyToFields(loaded)
        isPreviewCurrent = true
    }

    func state(
        reservationID: UUID
    ) -> ReservationConflictFieldState {
        fields[reservationID] ?? ReservationConflictFieldState()
    }

    func setState(
        _ state: ReservationConflictFieldState,
        reservationID: UUID
    ) {
        fields[reservationID] = state
        isPreviewCurrent = false
    }

    func applySuggestions() {
        guard let preview else { return }
        var proposed = fields
        for participant in preview.analysisBefore.conflicts
            .flatMap(\.participants) {
            let current = participant.reservation.remainingQuantity
            let suggested = participant.suggestedRemainingQuantity
            guard suggested < current else { continue }
            proposed[participant.id] = ReservationConflictFieldState(
                mode: suggested == 0 ? .release : .reduce,
                quantity: suggested == 0 ? "" : String(suggested)
            )
        }
        fields = proposed
        isPreviewCurrent = false
    }

    func calculatePreview() async throws {
        guard !isBusy else {
            throw ReservationConflictViewModelError
                .operationAlreadyRunning
        }
        guard let projectID, let preview else {
            throw ReservationConflictViewModelError.previewRequired
        }
        let resolutions = try makeResolutions(from: preview)
        isPreviewing = true
        defer { isPreviewing = false }
        let calculated = try await service.preview(
            projectID: projectID,
            resolutions: resolutions
        )
        try Task.checkCancellation()
        self.preview = calculated
        isPreviewCurrent = true
    }

    func applyConfirmedPreview() async throws {
        guard !isBusy else {
            throw ReservationConflictViewModelError
                .operationAlreadyRunning
        }
        guard let preview, canApply else {
            throw ReservationConflictViewModelError.previewRequired
        }
        isSaving = true
        defer { isSaving = false }
        let saved = try await service.apply(
            preview,
            confirmed: true
        )
        self.preview = saved
        applyToFields(saved)
        isPreviewCurrent = true
    }

    private var isBusy: Bool {
        isLoading || isPreviewing || isSaving
    }

    private func makeResolutions(
        from preview: ReservationConflictPreview
    ) throws -> [ReservationConflictResolution] {
        var resolutions: [ReservationConflictResolution] = []
        var visited: Set<UUID> = []
        for participant in preview.analysisBefore.conflicts
            .flatMap(\.participants) {
            guard visited.insert(participant.id).inserted else {
                continue
            }
            let state = state(reservationID: participant.id)
            switch state.mode {
            case .keep:
                continue
            case .reduce:
                let text = state.quantity.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                guard let quantity = Int64(text),
                      quantity > 0,
                      quantity
                        < participant.reservation.remainingQuantity else {
                    throw ReservationConflictViewModelError
                        .invalidQuantity(
                            reservationID: participant.id
                        )
                }
                resolutions.append(
                    .reduce(
                        reservationID: participant.id,
                        remainingQuantity: quantity
                    )
                )
            case .release:
                resolutions.append(
                    .release(reservationID: participant.id)
                )
            }
        }
        return resolutions
    }

    private func applyToFields(
        _ preview: ReservationConflictPreview
    ) {
        fields = Dictionary(
            uniqueKeysWithValues:
                preview.analysisBefore.conflicts
                    .flatMap(\.participants)
                    .map {
                        (
                            $0.id,
                            ReservationConflictFieldState(
                                mode: .keep,
                                quantity: String(
                                    $0.reservation.remainingQuantity
                                )
                            )
                        )
                    }
        )
    }
}
