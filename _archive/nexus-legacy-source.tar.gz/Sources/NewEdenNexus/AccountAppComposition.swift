import Foundation
import NewEdenNexusApplication
import NewEdenNexusInfrastructure
import NewEdenNexusPersistence
import SwiftData

@MainActor
enum AccountAppComposition {
    static let esiCompatibilityDate = "2026-07-26"

    static func makeViewModel(
        container: ModelContainer,
        defaults: UserDefaults = .standard
    ) throws -> AccountsViewModel {
        let profileCache = try FileESICharacterProfileCache(
            fileURL: try FileESICharacterProfileCache.defaultFileURL()
        )
        let personalDataStore = try FileESIPersonalDataStore(
            directoryURL: try FileESIPersonalDataStore
                .defaultDirectoryURL()
        )
        let walletDataStore = try FileESIWalletStore(
            directoryURL: try FileESIWalletStore.defaultDirectoryURL()
        )
        let locationNameStore = try FileESILocationNameStore(
            directoryURL: try FileESILocationNameStore
                .defaultDirectoryURL()
        )
        let walletAssignmentStore =
            SwiftDataWalletProjectAssignmentRepository(
                modelContainer: container
            )
        let inventoryStore =
            SwiftDataInventoryAvailabilityRepository(
                modelContainer: container
            )
        let projectStore = SwiftDataProductionProjectRepository(
            modelContainer: container
        )
        let catalog = SwiftDataItemBlueprintCatalog(
            modelContainer: container
        )
        let assetAvailabilityStore =
            SwiftDataESIAssetAvailabilitySelectionRepository(
                modelContainer: container
            )
        let assetAvailability = ESIAssetAvailabilityService(
            personalData: personalDataStore,
            inventory: inventoryStore,
            projects: projectStore,
            repository: assetAvailabilityStore
        )
        let authorization = EVESSOAuthorizationFlow()
        let vault = KeychainRefreshTokenVault()
        let service = EVEAccountConnectionService(
            authorization: authorization,
            vault: vault,
            repository: SwiftDataCharacterAccountRepository(
                modelContainer: container
            ),
            profileCache: profileCache,
            personalDataStore: personalDataStore,
            walletDataStore: walletDataStore,
            walletAssignmentStore: walletAssignmentStore,
            assetAvailabilityStore: assetAvailabilityStore,
            locationNameStore: locationNameStore
        )
        let remotes: (
            character: any ESICharacterRemoteFetching,
            personal: any ESIPersonalDataRemoteFetching,
            wallet: any ESIWalletRemoteFetching,
            locations: (any ESILocationNameRemoteFetching)?,
            structures: (any ESIStructureNameRemoteFetching)?
        )
        do {
            if let contact = try KeychainStore.readSecurely(
                account: SDEAppConfiguration.ownerContactKeychainAccount
            )?
            .trimmingCharacters(in: .whitespacesAndNewlines),
            !contact.isEmpty {
                let userAgent = try SDEUserAgentConfiguration(
                    applicationName: SDEAppConfiguration.applicationName,
                    applicationVersion:
                        SDEAppConfiguration.applicationVersion,
                    contact: contact,
                    purpose: "ESI integration"
                )
                let locationClient =
                    URLSessionESILocationNameClient(
                        configuration:
                            try ESIPersonalDataClientConfiguration(
                                compatibilityDate: esiCompatibilityDate,
                                userAgent: userAgent
                            )
                    )
                remotes = (
                    character: URLSessionESICharacterClient(
                        configuration: try ESICharacterClientConfiguration(
                            compatibilityDate: esiCompatibilityDate,
                            userAgent: userAgent
                        )
                    ),
                    personal: URLSessionESIPersonalDataClient(
                        configuration:
                            try ESIPersonalDataClientConfiguration(
                                compatibilityDate: esiCompatibilityDate,
                                userAgent: userAgent
                            )
                    ),
                    wallet: URLSessionESIWalletClient(
                        configuration: try ESIWalletClientConfiguration(
                            compatibilityDate: esiCompatibilityDate,
                            userAgent: userAgent
                        )
                    ),
                    locations: locationClient,
                    structures: locationClient
                )
            } else {
                remotes = (
                    character: MissingOwnerContactESIRemote(),
                    personal: MissingOwnerContactESIPersonalRemote(),
                    wallet: MissingOwnerContactESIWalletRemote(),
                    locations: nil,
                    structures: nil
                )
            }
        } catch {
            remotes = (
                character: UnreadableOwnerContactESIRemote(),
                personal: UnreadableOwnerContactESIPersonalRemote(),
                wallet: UnreadableOwnerContactESIWalletRemote(),
                locations: nil,
                structures: nil
            )
        }
        let synchronization = ESICharacterSynchronizationService(
            remote: remotes.character,
            cache: profileCache
        )
        let personalSynchronization =
            ESIPersonalDataSynchronizationService(
                tokenProvider: EVERefreshAccessTokenService(
                    authorization: authorization,
                    vault: vault
                ),
                remote: remotes.personal,
                repository: personalDataStore
            )
        let walletSynchronization = ESIWalletSynchronizationService(
            tokenProvider: EVERefreshAccessTokenService(
                authorization: authorization,
                vault: vault
            ),
            remote: remotes.wallet,
            repository: walletDataStore
        )
        let priceRepository = SwiftDataPriceProfileRepository(
            modelContainer: container
        )
        let planning = try ProjectAppComposition.makePlanning(
            container: container,
            catalog: catalog,
            personalDataStore: personalDataStore
        )
        return AccountsViewModel(
            service: service,
            synchronization: synchronization,
            personalSynchronization: personalSynchronization,
            walletSynchronization: walletSynchronization,
            walletAssignments: WalletProjectAssignmentService(
                wallets: walletDataStore,
                repository: walletAssignmentStore
            ),
            assetAvailability: assetAvailability,
            locationNames: remotes.locations.map {
                ESILocationNameResolutionService(
                    remote: $0,
                    structureRemote: remotes.structures,
                    tokenProvider: EVERefreshAccessTokenService(
                        authorization: authorization,
                        vault: vault
                    ),
                    store: locationNameStore
                )
            },
            catalog: catalog,
            projects: ProductionProjectLifecycleService(
                repository: projectStore
            ),
            financeComparison: ProjectFinanceComparisonService(
                planning: planning,
                economics: ProjectEconomicsService(
                    repository: SwiftDataProjectEconomicsRepository(
                        modelContainer: container
                    ),
                    prices: PriceProfileManagementService(
                        repository: priceRepository,
                        catalog: catalog
                    )
                ),
                assignments: walletAssignmentStore,
                wallets: walletDataStore
            ),
            configuration: { purpose in
                let clientID =
                    defaults.string(forKey: "eve.clientID")
                    ?? EVEPublicConfiguration.clientID
                let redirectValue =
                    defaults.string(forKey: "eve.redirectURI")
                    ?? EVEPublicConfiguration.redirectURI
                guard let redirectURI = URL(string: redirectValue) else {
                    throw EVEAuthenticationError.invalidConfiguration
                }
                return EVEAuthenticationConfiguration(
                    clientID: clientID,
                    redirectURI: redirectURI,
                    scopes: purpose.scopes
                )
            }
        )
    }
}

private struct MissingOwnerContactESIRemote:
    ESICharacterRemoteFetching
{
    func fetch(
        characterID: Int64,
        validators: ESICacheValidators?
    ) async throws -> ESICharacterRemoteResult {
        throw ESICharacterSyncError.ownerContactMissing
    }
}

private struct MissingOwnerContactESIPersonalRemote:
    ESIPersonalDataRemoteFetching
{
    func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> ESIPersonalDataSnapshot {
        throw ESICharacterSyncError.ownerContactMissing
    }
}

private struct MissingOwnerContactESIWalletRemote:
    ESIWalletRemoteFetching
{
    func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> ESIWalletSnapshot {
        throw ESICharacterSyncError.ownerContactMissing
    }
}

private struct UnreadableOwnerContactESIRemote:
    ESICharacterRemoteFetching
{
    func fetch(
        characterID: Int64,
        validators: ESICacheValidators?
    ) async throws -> ESICharacterRemoteResult {
        throw ESICharacterSyncError.ownerContactAccessFailed
    }
}

private struct UnreadableOwnerContactESIPersonalRemote:
    ESIPersonalDataRemoteFetching
{
    func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> ESIPersonalDataSnapshot {
        throw ESICharacterSyncError.ownerContactAccessFailed
    }
}

private struct UnreadableOwnerContactESIWalletRemote:
    ESIWalletRemoteFetching
{
    func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> ESIWalletSnapshot {
        throw ESICharacterSyncError.ownerContactAccessFailed
    }
}
