import Combine
import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum AccountAccessRefreshFeedback: Equatable {
    case running
    case succeeded
    case failed
}

enum WalletPreviewActionFeedback: Equatable {
    case applied
    case discardedKeepingSnapshot
    case discardedWithoutSnapshot
    case failed
}

@MainActor
final class AccountsViewModel: ObservableObject {
    @Published private(set) var accounts: [EVECharacterAccount] = []
    @Published private(set) var isLoading = false
    @Published private(set) var activeOperationCharacterID: Int64?
    @Published private(set) var isConnecting = false
    @Published private(set) var loadErrorDescription: String?
    @Published private(set) var profileSnapshots:
        [Int64: ESICharacterProfileSnapshot] = [:]
    @Published private(set) var profileSources:
        [Int64: ESICharacterSyncSource] = [:]
    @Published private(set) var personalSnapshots:
        [Int64: ESIPersonalDataSnapshot] = [:]
    @Published private(set) var personalPreview:
        ESIPersonalDataPreview?
    @Published private(set) var walletSnapshots:
        [Int64: ESIWalletSnapshot] = [:]
    @Published private(set) var walletPreview: ESIWalletPreview?
    @Published private(set) var walletAssignmentPreview:
        WalletAssignmentPreview?
    @Published private(set) var projects:
        [ProductionProjectSnapshot] = []
    @Published private(set) var walletAssignments:
        [WalletProjectAssignmentSnapshot] = []
    @Published private(set) var walletProjectActuals:
        [UUID: WalletProjectActuals] = [:]
    @Published private(set) var walletFinanceComparisons:
        [UUID: ProjectFinanceComparisonSnapshot] = [:]
    @Published private(set) var financeComparisonErrorDescription: String?
    @Published private(set) var assetAvailabilityPreview:
        ESIAssetAvailabilityPreview?
    @Published private(set) var assetAvailabilityRemovalPreview:
        ESIAssetAvailabilityRemovalPreview?
    @Published private(set) var assetSelections:
        [UUID: ESIAssetAvailabilitySelectionSnapshot] = [:]
    @Published private(set) var personalTypeNames: [Int64: String] = [:]
    @Published private(set) var personalMissingTypeIDs: Set<Int64> = []
    @Published private(set) var personalLocationNames:
        [Int64: String] = [:]
    @Published private(set) var personalDetailLoadingCharacterID: Int64?
    @Published private(set) var personalDetailErrorDescription: String?
    @Published private(set) var accessRefreshFeedback:
        [Int64: AccountAccessRefreshFeedback] = [:]
    @Published private(set) var walletPreviewActionFeedback:
        [Int64: WalletPreviewActionFeedback] = [:]

    private let service: any EVEAccountConnectionManaging
    private let synchronization: any ESICharacterSynchronizing
    private let personalSynchronization:
        (any ESIPersonalDataSynchronizing)?
    private let walletSynchronization: (any ESIWalletSynchronizing)?
    private let walletAssignmentService:
        (any WalletProjectAssignmentManaging)?
    private let projectLifecycle:
        (any ProductionProjectLifecycleManaging)?
    private let financeComparison:
        (any ProjectFinanceComparisonProviding)?
    private let assetAvailability:
        (any ESIAssetAvailabilityManaging)?
    private let locationNames: (any ESILocationNameResolving)?
    private let catalog: (any ItemBlueprintCatalogReading)?
    private let configuration:
        @MainActor (EVEAuthorizationPurpose) throws
            -> EVEAuthenticationConfiguration

    init(
        service: any EVEAccountConnectionManaging,
        synchronization: any ESICharacterSynchronizing,
        personalSynchronization:
            (any ESIPersonalDataSynchronizing)? = nil,
        walletSynchronization:
            (any ESIWalletSynchronizing)? = nil,
        walletAssignments:
            (any WalletProjectAssignmentManaging)? = nil,
        assetAvailability:
            (any ESIAssetAvailabilityManaging)? = nil,
        locationNames: (any ESILocationNameResolving)? = nil,
        catalog: (any ItemBlueprintCatalogReading)? = nil,
        projects:
            (any ProductionProjectLifecycleManaging)? = nil,
        financeComparison:
            (any ProjectFinanceComparisonProviding)? = nil,
        configuration:
            @escaping @MainActor (EVEAuthorizationPurpose) throws
                -> EVEAuthenticationConfiguration
    ) {
        self.service = service
        self.synchronization = synchronization
        self.personalSynchronization = personalSynchronization
        self.walletSynchronization = walletSynchronization
        self.walletAssignmentService = walletAssignments
        self.assetAvailability = assetAvailability
        self.locationNames = locationNames
        self.catalog = catalog
        self.projectLifecycle = projects
        self.financeComparison = financeComparison
        self.configuration = configuration
    }

    func load() async {
        isLoading = true
        loadErrorDescription = nil
        financeComparisonErrorDescription = nil
        defer { isLoading = false }
        do {
            accounts = try await service.accounts()
            var loaded: [Int64: ESICharacterProfileSnapshot] = [:]
            var loadedPersonal: [Int64: ESIPersonalDataSnapshot] = [:]
            var loadedWallets: [Int64: ESIWalletSnapshot] = [:]
            for account in accounts {
                try Task.checkCancellation()
                if let snapshot = try await synchronization.cachedProfile(
                    characterID: account.characterID
                ) {
                    loaded[account.characterID] = snapshot
                }
                if let snapshot = try await personalSynchronization?.current(
                    characterID: account.characterID
                ) {
                    loadedPersonal[account.characterID] = snapshot
                }
                if let snapshot = try await walletSynchronization?.current(
                    characterID: account.characterID
                ) {
                    loadedWallets[account.characterID] = snapshot
                }
            }
            profileSnapshots = loaded
            personalSnapshots = loadedPersonal
            walletSnapshots = loadedWallets
            projects = try await projectLifecycle?.projects(
                scope: .all
            ) ?? []
            var loadedSelections:
                [UUID: ESIAssetAvailabilitySelectionSnapshot] = [:]
            for project in projects {
                if let selection = try await assetAvailability?.selection(
                    projectID: project.id
                ) {
                    loadedSelections[project.id] = selection
                }
            }
            assetSelections = loadedSelections
            let loadedAssignments =
                try await walletAssignmentService?.assignments(
                    projectID: nil
                ) ?? []
            walletAssignments = loadedAssignments
            walletProjectActuals = try Self.actuals(
                projects: projects,
                assignments: loadedAssignments
            )
            walletFinanceComparisons =
                try await loadFinanceComparisons(projects: projects)
        } catch is CancellationError {
            return
        } catch {
            loadErrorDescription =
                "Die lokalen Charakterkonten konnten nicht geladen werden."
        }
    }

    func connect() async throws {
        guard !isConnecting else {
            return
        }
        isConnecting = true
        defer { isConnecting = false }
        let account = try await service.connect(
            configuration: try configuration(.personalIndustry)
        )
        replace(account)
    }

    func refresh(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil else {
            return
        }
        activeOperationCharacterID = characterID
        accessRefreshFeedback[characterID] = .running
        defer { activeOperationCharacterID = nil }
        do {
            let account = try await service.refresh(
                characterID: characterID,
                configuration: try configuration(
                    authorizationPurpose(characterID: characterID)
                )
            )
            replace(account)
            accessRefreshFeedback[characterID] = .succeeded
        } catch {
            accessRefreshFeedback[characterID] = .failed
            throw error
        }
    }

    func authorizeWallet(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil else {
            return
        }
        activeOperationCharacterID = characterID
        defer { activeOperationCharacterID = nil }
        let account = try await service.reauthorize(
            characterID: characterID,
            configuration: try configuration(
                hasStructureAuthorization(characterID: characterID)
                    ? .walletAndStructures
                    : .wallet
            )
        )
        replace(account)
    }

    func authorizeStructureNames(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil else {
            return
        }
        activeOperationCharacterID = characterID
        defer { activeOperationCharacterID = nil }
        let account = try await service.reauthorize(
            characterID: characterID,
            configuration: try configuration(
                hasWalletAuthorization(characterID: characterID)
                    ? .walletAndStructures
                    : .structures
            )
        )
        replace(account)
        await loadPersonalLocationNames(characterID: characterID)
    }

    func hasWalletAuthorization(characterID: Int64) -> Bool {
        accounts.first {
            $0.characterID == characterID
        }?.authorizes(EVEAuthorizationScope.wallet) == true
    }

    func hasStructureAuthorization(characterID: Int64) -> Bool {
        accounts.first {
            $0.characterID == characterID
        }?.authorizes(EVEAuthorizationScope.structures) == true
    }

    func hasPrivateStructureLocations(characterID: Int64) -> Bool {
        guard let snapshot = personalSnapshots[characterID] else {
            return false
        }
        return !ESILocationNameResolutionService
            .privateStructureLocationIDs(snapshot: snapshot)
            .isEmpty
    }

    func synchronize(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil else {
            return
        }
        activeOperationCharacterID = characterID
        defer { activeOperationCharacterID = nil }
        let result = try await synchronization.synchronize(
            characterID: characterID
        )
        profileSnapshots[characterID] = result.snapshot
        profileSources[characterID] = result.source
    }

    func inspectPersonalData(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil,
              let personalSynchronization else {
            return
        }
        activeOperationCharacterID = characterID
        defer { activeOperationCharacterID = nil }
        let preview = try await personalSynchronization.inspect(
            characterID: characterID,
            configuration: try configuration(.personalIndustry)
        )
        personalPreview = preview
        await loadPersonalTypeNames(
            typeIDs: preview.changes.compactMap(\.typeID)
        )
    }

    func applyPersonalDataPreview() async throws {
        guard activeOperationCharacterID == nil,
              let preview = personalPreview,
              let personalSynchronization else {
            return
        }
        activeOperationCharacterID = preview.characterID
        defer { activeOperationCharacterID = nil }
        let snapshot = try await personalSynchronization.apply(
            previewID: preview.id
        )
        personalSnapshots[preview.characterID] = snapshot
        personalPreview = nil
    }

    func discardPersonalDataPreview() async {
        guard let preview = personalPreview,
              let personalSynchronization else {
            personalPreview = nil
            return
        }
        await personalSynchronization.discard(previewID: preview.id)
        personalPreview = nil
    }

    func inspectWallet(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil,
              let walletSynchronization else {
            return
        }
        guard hasWalletAuthorization(characterID: characterID) else {
            throw EVEAuthenticationError.missingScopes(
                [EVEAuthorizationScope.wallet]
            )
        }
        walletPreviewActionFeedback[characterID] = nil
        activeOperationCharacterID = characterID
        defer { activeOperationCharacterID = nil }
        walletPreview = try await walletSynchronization.inspect(
            characterID: characterID,
            configuration: try configuration(.wallet)
        )
    }

    func applyWalletPreview() async throws {
        guard activeOperationCharacterID == nil,
              let preview = walletPreview,
              let walletSynchronization else {
            return
        }
        walletPreviewActionFeedback[preview.characterID] = nil
        activeOperationCharacterID = preview.characterID
        defer { activeOperationCharacterID = nil }
        do {
            let snapshot = try await walletSynchronization.apply(
                previewID: preview.id
            )
            walletSnapshots[preview.characterID] = snapshot
            walletPreview = nil
            walletPreviewActionFeedback[preview.characterID] = .applied
            await refreshFinanceComparisonsAfterCommittedChange(
                projects: projects
            )
        } catch {
            walletPreviewActionFeedback[preview.characterID] = .failed
            throw error
        }
    }

    func discardWalletPreview() async {
        guard let preview = walletPreview else {
            return
        }
        let keepsStoredSnapshot =
            walletSnapshots[preview.characterID] != nil
        if let walletSynchronization {
            await walletSynchronization.discard(previewID: preview.id)
        }
        walletPreview = nil
        walletPreviewActionFeedback[preview.characterID] =
            keepsStoredSnapshot
                ? .discardedKeepingSnapshot
                : .discardedWithoutSnapshot
    }

    func previewTransactionAssignment(
        projectID: UUID,
        characterID: Int64,
        transactionID: Int64,
        quantity: Int64
    ) async throws {
        try requireWritableProject(projectID)
        walletAssignmentPreview =
            try await walletAssignmentService?.previewTransaction(
                projectID: projectID,
                characterID: characterID,
                transactionID: transactionID,
                quantity: quantity
            )
    }

    func previewJournalAssignment(
        projectID: UUID,
        characterID: Int64,
        journalID: Int64,
        amountHundredths: Int64
    ) async throws {
        try requireWritableProject(projectID)
        walletAssignmentPreview =
            try await walletAssignmentService?.previewJournal(
                projectID: projectID,
                characterID: characterID,
                journalID: journalID,
                amountHundredths: amountHundredths
            )
    }

    func applyWalletAssignmentPreview() async throws {
        guard let preview = walletAssignmentPreview,
              let walletAssignmentService else {
            return
        }
        let assignment = try await walletAssignmentService.apply(
            previewID: preview.id,
            confirmed: true
        )
        walletAssignments.append(assignment)
        walletProjectActuals = try Self.actuals(
            projects: projects,
            assignments: walletAssignments
        )
        walletAssignmentPreview = nil
        if let project = projects.first(where: {
            $0.id == assignment.projectID
        }) {
            await refreshFinanceComparisonsAfterCommittedChange(
                projects: [project]
            )
        }
    }

    func discardWalletAssignmentPreview() async {
        guard let preview = walletAssignmentPreview,
              let walletAssignmentService else {
            walletAssignmentPreview = nil
            return
        }
        await walletAssignmentService.discard(previewID: preview.id)
        walletAssignmentPreview = nil
    }

    func loadPersonalTypeNames(characterID: Int64) async {
        guard let snapshot = personalSnapshots[characterID] else {
            return
        }
        personalDetailLoadingCharacterID = characterID
        personalDetailErrorDescription = nil
        defer { personalDetailLoadingCharacterID = nil }
        let typeIDs = Array(Set(
            snapshot.assets.map(\.typeID)
                + snapshot.blueprints.map(\.typeID)
                + snapshot.industryJobs
                    .flatMap {
                        [$0.blueprintTypeID, $0.productTypeID]
                            .compactMap { $0 }
                    }
        )).sorted()
        await loadPersonalTypeNames(typeIDs: typeIDs)
    }

    func loadPersonalLocationNames(characterID: Int64) async {
        guard let snapshot = personalSnapshots[characterID],
              let locationNames else {
            return
        }
        personalDetailLoadingCharacterID = characterID
        defer { personalDetailLoadingCharacterID = nil }
        do {
            personalLocationNames = try await locationNames.names(
                characterID: characterID,
                snapshot: snapshot,
                structureConfiguration:
                    hasStructureAuthorization(characterID: characterID)
                        ? try configuration(
                            authorizationPurpose(
                                characterID: characterID
                            )
                        )
                        : nil
            )
        } catch is CancellationError {
            return
        } catch {
            personalDetailErrorDescription =
                "Einige Ortsnamen konnten nicht geladen werden. Der lokale Datenstand bleibt nutzbar."
        }
    }

    func previewAssetAvailability(
        projectID: UUID,
        characterID: Int64,
        locationIDs: [Int64]
    ) async throws {
        assetAvailabilityPreview = try await assetAvailability?.preview(
            projectID: projectID,
            characterID: characterID,
            locationIDs: locationIDs
        )
    }

    func applyAssetAvailabilityPreview() async throws {
        guard let preview = assetAvailabilityPreview,
              let assetAvailability else {
            return
        }
        let selection = try await assetAvailability.apply(
            previewID: preview.id,
            confirmed: true
        )
        assetSelections[selection.projectID] = selection
        assetAvailabilityPreview = nil
    }

    func discardAssetAvailabilityPreview() async {
        guard let preview = assetAvailabilityPreview,
              let assetAvailability else {
            assetAvailabilityPreview = nil
            return
        }
        await assetAvailability.discard(previewID: preview.id)
        assetAvailabilityPreview = nil
    }

    func previewAssetAvailabilityRemoval(projectID: UUID) async throws {
        assetAvailabilityRemovalPreview =
            try await assetAvailability?.previewRemoval(
                projectID: projectID
            )
    }

    func applyAssetAvailabilityRemoval() async throws {
        guard let preview = assetAvailabilityRemovalPreview,
              let assetAvailability else {
            return
        }
        let removed = try await assetAvailability.applyRemoval(
            previewID: preview.id,
            confirmed: true
        )
        assetSelections[removed.projectID] = nil
        assetAvailabilityRemovalPreview = nil
    }

    func discardAssetAvailabilityRemoval() async {
        guard let preview = assetAvailabilityRemovalPreview,
              let assetAvailability else {
            assetAvailabilityRemovalPreview = nil
            return
        }
        await assetAvailability.discardRemoval(previewID: preview.id)
        assetAvailabilityRemovalPreview = nil
    }

    func disconnect(characterID: Int64) async throws {
        guard activeOperationCharacterID == nil else {
            return
        }
        activeOperationCharacterID = characterID
        defer { activeOperationCharacterID = nil }
        try await service.disconnect(
            characterID: characterID,
            confirmation: .confirmed
        )
        accounts.removeAll { $0.characterID == characterID }
        profileSnapshots[characterID] = nil
        profileSources[characterID] = nil
        personalSnapshots[characterID] = nil
        walletSnapshots[characterID] = nil
        walletPreviewActionFeedback[characterID] = nil
        walletAssignments.removeAll {
            $0.characterID == characterID
        }
        walletProjectActuals = try Self.actuals(
            projects: projects,
            assignments: walletAssignments
        )
        await refreshFinanceComparisonsAfterCommittedChange(
            projects: projects
        )
        if personalPreview?.characterID == characterID {
            personalPreview = nil
        }
        if walletPreview?.characterID == characterID {
            walletPreview = nil
        }
        if walletAssignmentPreview?.assignment.characterID
            == characterID {
            walletAssignmentPreview = nil
        }
        assetSelections = assetSelections.filter {
            $0.value.characterID != characterID
        }
        if assetAvailabilityPreview?.characterID == characterID {
            assetAvailabilityPreview = nil
        }
        if assetAvailabilityRemovalPreview?.characterID == characterID {
            assetAvailabilityRemovalPreview = nil
        }
        personalLocationNames = [:]
    }

    private func replace(_ account: EVECharacterAccount) {
        accounts.removeAll { $0.characterID == account.characterID }
        accounts.append(account)
        accounts.sort {
            let comparison = $0.name.localizedCaseInsensitiveCompare($1.name)
            if comparison == .orderedSame {
                return $0.characterID < $1.characterID
            }
            return comparison == .orderedAscending
        }
    }

    private func loadPersonalTypeNames(typeIDs: [Int64]) async {
        guard let catalog else { return }
        let requested = Set(typeIDs.filter { $0 > 0 })
        guard !requested.isEmpty else { return }
        do {
            let unresolved = requested.filter {
                personalTypeNames[$0] == nil
            }
            let loaded = try await catalog.itemNames(
                typeIDs: unresolved.sorted()
            )
            var names = personalTypeNames
            names.merge(loaded) { current, _ in current }
            personalTypeNames = names
            personalMissingTypeIDs.subtract(loaded.keys)
            personalMissingTypeIDs.formUnion(
                requested.filter { names[$0] == nil }
            )
        } catch is CancellationError {
            return
        } catch {
            personalDetailErrorDescription =
                "Einige Gegenstandsnamen konnten nicht aus dem lokalen SDE-Katalog geladen werden."
        }
    }

    private func authorizationPurpose(
        characterID: Int64
    ) -> EVEAuthorizationPurpose {
        let wallet = hasWalletAuthorization(
            characterID: characterID
        )
        let structures = hasStructureAuthorization(
            characterID: characterID
        )
        return switch (wallet, structures) {
        case (true, true): .walletAndStructures
        case (true, false): .wallet
        case (false, true): .structures
        case (false, false): .personalIndustry
        }
    }

    private func requireWritableProject(_ projectID: UUID) throws {
        guard let project = projects.first(where: {
            $0.id == projectID
        }) else {
            throw ProductionProjectLifecycleError.projectNotFound(
                projectID
            )
        }
        guard project.status != .archived else {
            throw ProductionProjectLifecycleError
                .archivedProjectIsReadOnly(projectID)
        }
    }

    private func loadFinanceComparisons(
        projects: [ProductionProjectSnapshot]
    ) async throws -> [UUID: ProjectFinanceComparisonSnapshot] {
        guard let financeComparison else {
            return [:]
        }
        var result: [UUID: ProjectFinanceComparisonSnapshot] = [:]
        for project in projects {
            try Task.checkCancellation()
            result[project.id] = try await financeComparison.comparison(
                project: project,
                at: Date()
            )
        }
        return result
    }

    private func refreshFinanceComparisonsAfterCommittedChange(
        projects: [ProductionProjectSnapshot]
    ) async {
        guard let financeComparison else {
            return
        }
        do {
            for project in projects {
                try Task.checkCancellation()
                walletFinanceComparisons[project.id] =
                    try await financeComparison.comparison(
                        project: project,
                        at: Date()
                    )
            }
            financeComparisonErrorDescription = nil
        } catch is CancellationError {
            return
        } catch {
            financeComparisonErrorDescription =
                "Der Plan-/Istvergleich konnte nach der gespeicherten Änderung nicht neu geladen werden. Die Fachdaten wurden nicht zurückgesetzt."
        }
    }

    private static func actuals(
        projects: [ProductionProjectSnapshot],
        assignments: [WalletProjectAssignmentSnapshot]
    ) throws -> [UUID: WalletProjectActuals] {
        var result: [UUID: WalletProjectActuals] = [:]
        let calculator = WalletProjectActualsCalculator()
        for project in projects {
            result[project.id] = try calculator.calculate(
                projectID: project.id,
                assignments: assignments
            )
        }
        return result
    }
}
