import SwiftUI

struct SDELegalNoticesView: View {
    @ObservedObject var model: SDEManagementViewModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Label(
                    "Unabhängige Drittanbieteranwendung",
                    systemImage: "checkmark.shield"
                )
                .font(.title2.bold())

                Text(
                    "New Eden Nexus ist eine unabhängige Drittanbieteranwendung. Sie ist weder ein offizielles Produkt von CCP noch mit CCP verbunden, von CCP unterstützt oder von CCP gebilligt."
                )

                GroupBox("Eigentums- und Markenhinweis") {
                    Text(
                        "© 2014 CCP hf. All rights reserved. \"EVE\", \"EVE Online\", \"CCP\", and all related logos and images are trademarks or registered trademarks of CCP hf."
                    )
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
                }

                GroupBox("Verwendeter Datenstand") {
                    VStack(alignment: .leading, spacing: 6) {
                        LabeledContent(
                            "Aktiver SDE-Build",
                            value: model.activeVersion?.buildNumber
                                .formatted() ?? "Keiner"
                        )
                        LabeledContent("Format", value: "JSON Lines")
                        Text(
                            "Die App nutzt offizielle statische CCP-Daten. SDE und spätere ESI-Livedaten sind technisch und fachlich getrennte Datenquellen."
                        )
                        .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }

                GroupBox("Offizielle Bedingungen und Dokumentation") {
                    VStack(alignment: .leading, spacing: 10) {
                        Link(
                            "CCP Developer License Agreement",
                            destination:
                                SDEAppConfiguration.developerLicenseURL
                        )
                        Link(
                            "Offizielle SDE-Dokumentation",
                            destination: SDEAppConfiguration.staticDataURL
                        )
                        Link(
                            "EVE Online EULA",
                            destination: SDEAppConfiguration.eulaURL
                        )
                        Link(
                            "EVE Online Terms of Service",
                            destination: SDEAppConfiguration.termsURL
                        )
                        Link(
                            "Third Party Policies",
                            destination:
                                SDEAppConfiguration.thirdPartyPoliciesURL
                        )
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }

                Text(
                    "Prüfstand der eingebundenen Hinweise: 23. Juli 2026. Bedingungen können sich ändern und werden vor einer öffentlichen Veröffentlichung erneut geprüft. Diese Ansicht ist keine Rechtsberatung und behauptet keine Genehmigung durch CCP."
                )
                .font(.caption)
                .foregroundStyle(.secondary)

                Text(
                    "Es werden keine CCP-Logos oder Bilder eingebunden. Eine spätere Nutzung solcher Medien erfordert eine gesonderte Prüfung ihrer offiziellen Bedingungen."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            .padding(24)
            .frame(maxWidth: 760, alignment: .leading)
        }
        .navigationTitle("Rechtliche Hinweise")
    }
}
