import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

private struct PriceProfileEditorContext: Identifiable {
    let id = UUID()
    let profile: PriceProfileSnapshot?
}

private struct ManualPriceEditorContext: Identifiable {
    let id = UUID()
    let price: ManualPriceSnapshot?
}

struct PriceProfileView: View {
    @ObservedObject var model: PriceProfileViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @State private var profileEditor: PriceProfileEditorContext?
    @State private var priceEditor: ManualPriceEditorContext?
    @State private var csvImportModel: PriceCSVImportViewModel?
    @State private var deletingProfile = false
    @State private var deletingPrice = false
    @State private var operationTask: Task<Void, Never>?

    var body: some View {
        HSplitView {
            profilePane
                .frame(minWidth: 250, idealWidth: 310)
            pricePane
                .frame(minWidth: 520)
        }
        .navigationTitle("Preise & Preissätze")
        .toolbar { toolbar }
        .task { await load() }
        .onDisappear { operationTask?.cancel() }
        .sheet(item: $profileEditor) { context in
            PriceProfileEditorSheet(
                profile: context.profile,
                save: { name in
                    if context.profile == nil {
                        try await model.createProfile(name: name)
                    } else {
                        try await model.renameSelectedProfile(name: name)
                    }
                },
                reportError: {
                    runtime.report($0, operation: .priceProfileSave)
                }
            )
        }
        .sheet(item: $priceEditor) { context in
            ManualPriceEditorSheet(
                model: model,
                price: context.price,
                reportError: {
                    runtime.report($0, operation: .priceProfileSave)
                }
            )
        }
        .sheet(item: $csvImportModel) { importModel in
            if let profile = model.selectedProfile {
                PriceCSVImportSheet(
                    model: importModel,
                    profile: profile,
                    reloadPrices: {
                        try await model.selectProfile(profile.id)
                    },
                    reportError: { error, operation in
                        runtime.report(error, operation: operation)
                    }
                )
            }
        }
        .confirmationDialog(
            "Preissatz löschen?",
            isPresented: $deletingProfile,
            titleVisibility: .visible
        ) {
            Button("Preissatz und Preise löschen", role: .destructive) {
                run(.priceProfileSave) {
                    try await model.deleteSelectedProfile()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Alle manuellen Preise dieses Profils werden lokal gelöscht. Andere Profile und Produktionsdaten bleiben unverändert."
            )
        }
        .confirmationDialog(
            "Manuellen Preis löschen?",
            isPresented: $deletingPrice,
            titleVisibility: .visible
        ) {
            Button("Preis löschen", role: .destructive) {
                run(.priceProfileSave) {
                    try await model.deleteSelectedPrice()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text("Nur der ausgewählte Preis wird aus diesem Profil entfernt.")
        }
    }

    private var profilePane: some View {
        VStack(spacing: 0) {
            if model.isLoading && model.profiles.isEmpty {
                ProgressView("Preissätze werden geladen …")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if model.profiles.isEmpty {
                ContentUnavailableView {
                    Label("Noch kein Preissatz", systemImage: "tag")
                } description: {
                    Text(
                        "Lege einen getrennten ISK-Preisstand an, zum Beispiel „Jita Einkauf“ oder „manuell konservativ“."
                    )
                } actions: {
                    Button("Preissatz anlegen") {
                        profileEditor = .init(profile: nil)
                    }
                }
            } else {
                List(
                    model.profiles,
                    selection: Binding(
                        get: { model.selectedProfileID },
                        set: { id in
                            run(.priceProfileLoad) {
                                try await model.selectProfile(id)
                            }
                        }
                    )
                ) { profile in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(profile.name)
                                .fontWeight(
                                    profile.isActive ? .semibold : .regular
                                )
                            Text(
                                profile.isActive
                                    ? "Aktiver ISK-Preisstand"
                                    : "ISK-Preisstand"
                            )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if profile.isActive {
                            Label("Aktiv", systemImage: "checkmark.circle.fill")
                                .labelStyle(.iconOnly)
                                .foregroundStyle(NexusTheme.teal)
                                .accessibilityLabel("Aktiver Preissatz")
                        }
                    }
                    .tag(profile.id)
                }
                .accessibilityLabel("Lokale Preissätze")
            }
        }
    }

    @ViewBuilder
    private var pricePane: some View {
        if let profile = model.selectedProfile {
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(profile.name)
                            .font(.title2.bold())
                        Text(
                            profile.isActive
                                ? "Aktiver Preissatz · lokale ISK-Preise"
                                : "Inaktiver Preissatz · Aktivierung nur auf ausdrückliche Auswahl"
                        )
                        .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if !profile.isActive {
                        Button("Als aktiv verwenden") {
                            run(.priceProfileSave) {
                                try await model.activateSelectedProfile()
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(model.isMutating)
                    }
                }
                .padding()

                Divider()

                if model.prices.isEmpty {
                    ContentUnavailableView {
                        Label(
                            "Keine Preise",
                            systemImage: "banknote"
                        )
                    } description: {
                        Text(
                            "Fehlende Preise bleiben explizit unbekannt und werden nicht als null ISK angenommen."
                        )
                    } actions: {
                        Button("Preis erfassen") {
                            priceEditor = .init(price: nil)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    Table(model.prices, selection: $model.selectedPriceID) {
                        TableColumn("Item") { price in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(price.itemName)
                                Text("Type-ID \(price.typeID)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        TableColumn("Einheitspreis") { price in
                            Text(
                                NexusNumberFormat.isk(
                                    hundredths: price.amount.hundredths
                                )
                            )
                                .monospacedDigit()
                        }
                        .width(min: 130, ideal: 160)
                        TableColumn("Quelle") { price in
                            if let provenance = model.marketProvenance(
                                priceID: price.id
                            ) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("ESI-Markt")
                                    Text(
                                        marketProvenanceText(provenance)
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                            } else {
                                Text(priceSourceText(price.source))
                            }
                        }
                        .width(min: 170, ideal: 230)
                        TableColumn("Gültigkeit") { price in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(
                                    price.validFrom.formatted(
                                        date: .abbreviated,
                                        time: .omitted
                                    )
                                )
                                if let until = price.validUntil {
                                    Text(
                                        "bis \(until.formatted(date: .abbreviated, time: .omitted))"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                } else {
                                    Text("unbegrenzt")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .width(min: 130, ideal: 160)
                    }
                    .contextMenu(forSelectionType: UUID.self) { selection in
                        if selection.count == 1 {
                            Button("Preis bearbeiten") {
                                priceEditor = .init(
                                    price: model.selectedPrice
                                )
                            }
                            Button("Preis löschen", role: .destructive) {
                                deletingPrice = true
                            }
                        }
                    } primaryAction: { _ in
                        priceEditor = .init(price: model.selectedPrice)
                    }
                    .accessibilityLabel(
                        "Preise im ausgewählten Profil"
                    )
                }
            }
        } else {
            ContentUnavailableView {
                Label("Kein Preissatz ausgewählt", systemImage: "tag")
            } description: {
                Text("Wähle links ein Profil oder lege ein neues an.")
            }
        }
    }

    @ToolbarContentBuilder
    private var toolbar: some ToolbarContent {
        ToolbarItemGroup {
            Button {
                run(.priceProfileLoad) { try await model.load() }
            } label: {
                Label("Aktualisieren", systemImage: "arrow.clockwise")
            }
            .keyboardShortcut("r", modifiers: .command)
            .disabled(model.isLoading || model.isMutating)

            Button {
                profileEditor = .init(profile: nil)
            } label: {
                Label("Profil anlegen", systemImage: "plus.rectangle")
            }
            .disabled(model.isMutating)

            Button {
                profileEditor = .init(profile: model.selectedProfile)
            } label: {
                Label("Preissatz umbenennen", systemImage: "pencil")
            }
            .disabled(model.selectedProfile == nil || model.isMutating)

            Button {
                deletingProfile = true
            } label: {
                Label("Profil löschen", systemImage: "trash")
            }
            .disabled(model.selectedProfile == nil || model.isMutating)

            Divider()

            Button {
                priceEditor = .init(price: nil)
            } label: {
                Label("Preis erfassen", systemImage: "plus")
            }
            .disabled(model.selectedProfile == nil || model.isMutating)

            Button {
                csvImportModel = model.makeCSVImportViewModel()
            } label: {
                Label(
                    "CSV-Preise importieren",
                    systemImage: "tablecells.badge.ellipsis"
                )
            }
            .keyboardShortcut("i", modifiers: [.command, .shift])
            .disabled(model.selectedProfile == nil || model.isMutating)

            Button {
                priceEditor = .init(price: model.selectedPrice)
            } label: {
                Label("Preis bearbeiten", systemImage: "square.and.pencil")
            }
            .disabled(model.selectedPrice == nil || model.isMutating)

            Button {
                deletingPrice = true
            } label: {
                Label("Preis löschen", systemImage: "minus")
            }
            .disabled(model.selectedPrice == nil || model.isMutating)
        }
    }

    private func load() async {
        do {
            try await model.load()
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .priceProfileLoad,
                retry: { Task { await load() } }
            )
        }
    }

    private func run(
        _ operation: NexusOperation,
        action: @escaping @MainActor () async throws -> Void
    ) {
        operationTask?.cancel()
        operationTask = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: operation)
            }
        }
    }

    private func priceSourceText(_ source: PriceSource) -> String {
        switch source {
        case .manual:
            "Manuell"
        case .csv:
            "CSV"
        case .esiMarket:
            "ESI-Markt"
        }
    }

    private func marketProvenanceText(
        _ value: MarketPriceProvenanceSnapshot
    ) -> String {
        let location = value.locationLabel
            ?? value.locationID.map { "Location \($0)" }
            ?? "Region \(value.regionID)"
        let cache = value.cacheExpiresAt.map {
            "Cache bis \($0.formatted(date: .omitted, time: .shortened))"
        } ?? "Cachealter unbekannt"
        return "\(location) · Menge \(NexusNumberFormat.quantity(value.requestedQuantity)) · Abruf \(value.ordersFetchedAt.formatted(date: .abbreviated, time: .shortened)) · \(cache)"
    }
}

private struct PriceProfileEditorSheet: View {
    let profile: PriceProfileSnapshot?
    let save: (String) async throws -> Void
    let reportError: (any Error) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var isSaving = false
    @State private var task: Task<Void, Never>?

    init(
        profile: PriceProfileSnapshot?,
        save: @escaping (String) async throws -> Void,
        reportError: @escaping (any Error) -> Void
    ) {
        self.profile = profile
        self.save = save
        self.reportError = reportError
        _name = State(initialValue: profile?.name ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                TextField("Profilname", text: $name)
                Text(
                    "Alle Preise werden in ISK geführt. Der Name beschreibt den Preisstand oder das Szenario und muss eindeutig sein."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                NexusValidationSummary(issues: validationIssues)
            }
            .formStyle(.grouped)
            .navigationTitle(
                profile == nil ? "Preissatz anlegen" : "Preissatz umbenennen"
            )
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern") {
                        isSaving = true
                        task?.cancel()
                        task = Task {
                            do {
                                try await save(name)
                                dismiss()
                            } catch is CancellationError {
                                isSaving = false
                            } catch {
                                isSaving = false
                                reportError(error)
                            }
                        }
                    }
                    .disabled(!validationIssues.isEmpty || isSaving)
                }
            }
        }
        .frame(minWidth: 440, minHeight: 240)
        .onDisappear { task?.cancel() }
    }

    private var validationIssues: [NexusValidationIssue] {
        guard name.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty else {
            return []
        }
        return [.requiredText(field: "Profilname")]
    }
}

private struct ManualPriceEditorSheet: View {
    @ObservedObject var model: PriceProfileViewModel
    let price: ManualPriceSnapshot?
    let reportError: (any Error) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var results: [CatalogItemSummary] = []
    @State private var selectedTypeID: Int64?
    @State private var amountText: String
    @State private var validFrom: Date
    @State private var hasExpiration: Bool
    @State private var validUntil: Date
    @State private var isSearching = false
    @State private var isSaving = false
    @State private var task: Task<Void, Never>?

    init(
        model: PriceProfileViewModel,
        price: ManualPriceSnapshot?,
        reportError: @escaping (any Error) -> Void
    ) {
        self.model = model
        self.price = price
        self.reportError = reportError
        _selectedTypeID = State(initialValue: price?.typeID)
        _amountText = State(
            initialValue: price?.amount.displayText ?? ""
        )
        _validFrom = State(initialValue: price?.validFrom ?? .now)
        _hasExpiration = State(initialValue: price?.validUntil != nil)
        _validUntil = State(
            initialValue: price?.validUntil
                ?? Calendar.current.date(byAdding: .month, value: 1, to: .now)
                ?? .now
        )
    }

    var body: some View {
        NavigationStack {
            Form {
                if let price {
                    Section("Item") {
                        LabeledContent("Name", value: price.itemName)
                        LabeledContent("Type-ID", value: "\(price.typeID)")
                    }
                } else {
                    Section("Item auswählen") {
                        HStack {
                            TextField("Itemname", text: $query)
                                .onSubmit { search() }
                            Button("Suchen") { search() }
                                .disabled(
                                    query.trimmingCharacters(
                                        in: .whitespacesAndNewlines
                                    ).isEmpty || isSearching
                                )
                        }
                        if isSearching {
                            ProgressView("Katalog wird durchsucht …")
                        } else if results.isEmpty {
                            Text(
                                "Suche nach einem veröffentlichten Item im lokalen EVE-Katalog."
                            )
                            .foregroundStyle(.secondary)
                        } else {
                            List(
                                results,
                                id: \.typeID,
                                selection: $selectedTypeID
                            ) { item in
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.name)
                                    Text(
                                        "\(item.groupName) · Type-ID \(item.typeID)"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                                .tag(item.typeID)
                            }
                            .frame(minHeight: 170)
                        }
                    }
                }

                Section("Einheitspreis") {
                    TextField("ISK, höchstens zwei Nachkommastellen", text: $amountText)
                        .monospacedDigit()
                    Text(
                        "Punkt oder Komma ist als Dezimaltrennzeichen zulässig; Tausendertrennzeichen sind nicht erlaubt."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                Section("Gültigkeit") {
                    DatePicker(
                        "Gültig ab",
                        selection: $validFrom,
                        displayedComponents: [.date, .hourAndMinute]
                    )
                    Toggle("Ablaufdatum verwenden", isOn: $hasExpiration)
                    if hasExpiration {
                        DatePicker(
                            "Gültig bis",
                            selection: $validUntil,
                            displayedComponents: [.date, .hourAndMinute]
                        )
                    }
                    LabeledContent("Quelle", value: "Manuell")
                }
                NexusValidationSummary(issues: validationIssues)
            }
            .formStyle(.grouped)
            .navigationTitle(
                price == nil ? "Preis erfassen" : "Preis bearbeiten"
            )
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern") { savePrice() }
                        .disabled(!validationIssues.isEmpty || isSaving)
                }
            }
        }
        .frame(minWidth: 560, minHeight: 620)
        .onDisappear { task?.cancel() }
    }

    private var validationIssues: [NexusValidationIssue] {
        var issues: [NexusValidationIssue] = []
        if (price?.typeID ?? selectedTypeID) == nil {
            issues.append(.requiredSelection(field: "Item"))
        }
        if !hasValidAmount {
            issues.append(.moneyAmount(field: "Einheitspreis"))
        }
        if hasExpiration && validUntil <= validFrom {
            issues.append(.dateRange(field: "Gültigkeit"))
        }
        return issues
    }

    private var hasValidAmount: Bool {
        do {
            _ = try ISKAmount.parse(amountText)
            return true
        } catch {
            return false
        }
    }

    private func search() {
        task?.cancel()
        isSearching = true
        task = Task {
            do {
                let page = try await model.searchItems(query: query)
                results = page.items
                isSearching = false
            } catch is CancellationError {
                isSearching = false
            } catch {
                isSearching = false
                reportError(error)
            }
        }
    }

    private func savePrice() {
        guard let typeID = price?.typeID ?? selectedTypeID else { return }
        isSaving = true
        task?.cancel()
        task = Task {
            do {
                try await model.savePrice(
                    typeID: typeID,
                    amountText: amountText,
                    validFrom: validFrom,
                    validUntil: hasExpiration ? validUntil : nil
                )
                dismiss()
            } catch is CancellationError {
                isSaving = false
            } catch {
                isSaving = false
                reportError(error)
            }
        }
    }
}
