import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct InventoryView: View {
    @ObservedObject var model: InventoryViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @State private var locationEditor: LocationEditorContext?
    @State private var stockEditor: StockEditorContext?
    @State private var csvImportModel: InventoryCSVImportViewModel?
    @State private var showingArchiveConfirmation = false
    @State private var showingDeleteStockConfirmation = false
    @State private var operationTask: Task<Void, Never>?

    var body: some View {
        HSplitView {
            locationPane
                .frame(minWidth: 250, idealWidth: 310)
            stockPane
                .frame(minWidth: 420)
        }
        .navigationTitle("Lager & Bestände")
        .toolbar { inventoryToolbar }
        .task(id: model.scope) {
            await loadInventory()
        }
        .onDisappear {
            operationTask?.cancel()
        }
        .sheet(item: $locationEditor) { context in
            StorageLocationEditorSheet(
                location: context.location,
                save: { draft in
                    if let location = context.location {
                        try await model.updateLocation(
                            id: location.id,
                            draft: draft
                        )
                    } else {
                        try await model.createLocation(draft: draft)
                    }
                },
                reportError: {
                    runtime.report($0, operation: .inventorySave)
                }
            )
        }
        .sheet(item: $stockEditor) { context in
            ManualStockEditorSheet(
                model: model,
                stock: context.stock,
                reportError: {
                    runtime.report($0, operation: .inventorySave)
                }
            )
        }
        .sheet(item: $csvImportModel) { importModel in
            if let location = model.selectedLocation {
                InventoryCSVImportSheet(
                    model: importModel,
                    location: location,
                    reloadInventory: {
                        try await model.load()
                    },
                    reportError: { error, operation in
                        runtime.report(error, operation: operation)
                    }
                )
            }
        }
        .confirmationDialog(
            "Lager archivieren?",
            isPresented: $showingArchiveConfirmation,
            titleVisibility: .visible
        ) {
            Button("Archivieren", role: .destructive) {
                runMutation {
                    try await model.archiveSelectedLocation()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Das Lager und alle Bestandspositionen bleiben lokal erhalten."
            )
        }
        .confirmationDialog(
            "Bestandsposition löschen?",
            isPresented: $showingDeleteStockConfirmation,
            titleVisibility: .visible
        ) {
            Button("Position löschen", role: .destructive) {
                runMutation {
                    try await model.deleteSelectedStock()
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text("Nur die ausgewählte manuelle Position wird gelöscht.")
        }
    }

    private var locationPane: some View {
        VStack(spacing: 0) {
            Picker("Lagerfilter", selection: $model.scope) {
                Text("Aktiv").tag(StorageLocationListScope.active)
                Text("Archiv").tag(StorageLocationListScope.archived)
                Text("Alle").tag(StorageLocationListScope.all)
            }
            .pickerStyle(.segmented)
            .padding()
            .accessibilityLabel("Lagerorte filtern")

            if model.isLoading && model.locations.isEmpty {
                ProgressView("Lager werden geladen …")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if model.locations.isEmpty {
                ContentUnavailableView {
                    Label(
                        model.scope == .archived
                            ? "Kein Lager im Archiv"
                            : "Noch kein Lager",
                        systemImage: "archivebox"
                    )
                } description: {
                    Text(
                        model.scope == .archived
                            ? "Archivierte Lager erscheinen hier."
                            : "Lege ein lokales Lager für manuelle Bestände an."
                    )
                } actions: {
                    if model.scope != .archived {
                        Button("Lager anlegen") {
                            locationEditor = .init(location: nil)
                        }
                    }
                }
            } else {
                List(
                    model.locations,
                    selection: Binding(
                        get: { model.selectedLocationID },
                        set: { newValue in
                            operationTask?.cancel()
                            operationTask = Task {
                                do {
                                    try await model.selectLocation(newValue)
                                } catch is CancellationError {
                                    return
                                } catch {
                                    runtime.report(
                                        error,
                                        operation: .inventoryLoad
                                    )
                                }
                            }
                        }
                    )
                ) { location in
                    VStack(alignment: .leading, spacing: 3) {
                        Label(
                            location.name,
                            systemImage: location.isArchived
                                ? "archivebox"
                                : "shippingbox"
                        )
                        Text(location.kind.localizedName)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .tag(location.id)
                }
                .accessibilityLabel("Lokale Lagerorte")
            }
        }
    }

    @ViewBuilder
    private var stockPane: some View {
        if let location = model.selectedLocation {
            VStack(alignment: .leading, spacing: 0) {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(location.name)
                            .font(.title2.bold())
                        if location.isArchived {
                            Text("Archiviert")
                                .font(.caption)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 3)
                                .background(.secondary.opacity(0.15))
                                .clipShape(Capsule())
                        }
                    }
                    Text(location.kind.localizedName)
                        .foregroundStyle(.secondary)
                    if !location.notes.isEmpty {
                        Text(location.notes)
                            .font(.callout)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding()

                Divider()

                if model.stocks.isEmpty {
                    ContentUnavailableView {
                        Label(
                            "Keine manuellen Bestände",
                            systemImage: "shippingbox.and.arrow.backward"
                        )
                    } description: {
                        Text(
                            location.isArchived
                                ? "Die Bestände dieses archivierten Lagers bleiben erhalten."
                                : "Füge ein Item aus dem lokalen EVE-Katalog hinzu."
                        )
                    } actions: {
                        if !location.isArchived {
                            Button("Bestand erfassen") {
                                stockEditor = .init(stock: nil)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    Table(model.stocks, selection: $model.selectedStockID) {
                        TableColumn("Item") { stock in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(stock.itemName)
                                Text("Type-ID \(stock.typeID)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        TableColumn("Menge") { stock in
                            Text(NexusNumberFormat.quantity(stock.quantity))
                                .monospacedDigit()
                        }
                        .width(min: 100, ideal: 140)
                        TableColumn("SDE-Build") { stock in
                            Text(stock.catalogBuildNumber.formatted())
                                .monospacedDigit()
                        }
                        .width(min: 90, ideal: 110)
                    }
                    .contextMenu(forSelectionType: UUID.self) { selection in
                        if selection.count == 1 {
                            Button("Menge bearbeiten") {
                                openStockEditor()
                            }
                            .disabled(!model.canEditStock)
                            Button("Position löschen", role: .destructive) {
                                showingDeleteStockConfirmation = true
                            }
                            .disabled(!model.canEditStock)
                        }
                    } primaryAction: { _ in
                        openStockEditor()
                    }
                    .accessibilityLabel(
                        "Manuelle Bestände im ausgewählten Lager"
                    )
                }
            }
        } else {
            ContentUnavailableView {
                Label("Kein Lager ausgewählt", systemImage: "archivebox")
            } description: {
                Text("Wähle links ein Lager oder lege ein neues an.")
            }
        }
    }

    @ToolbarContentBuilder
    private var inventoryToolbar: some ToolbarContent {
        ToolbarItemGroup {
            Button {
                runLoad()
            } label: {
                Label("Aktualisieren", systemImage: "arrow.clockwise")
            }
            .keyboardShortcut("r", modifiers: .command)
            .disabled(model.isLoading || model.isMutating)

            Button {
                locationEditor = .init(location: nil)
            } label: {
                Label("Lager anlegen", systemImage: "plus")
            }
            .keyboardShortcut("n", modifiers: [.command, .shift])
            .disabled(model.scope == .archived || model.isMutating)

            Button {
                guard let location = model.selectedLocation else { return }
                locationEditor = .init(location: location)
            } label: {
                Label("Lager bearbeiten", systemImage: "pencil")
            }
            .disabled(!model.canEditLocation || model.isMutating)

            if model.canRestoreLocation {
                Button {
                    runMutation {
                        try await model.restoreSelectedLocation()
                    }
                } label: {
                    Label(
                        "Lager wiederherstellen",
                        systemImage: "arrow.uturn.backward"
                    )
                }
                .disabled(model.isMutating)
            } else {
                Button {
                    showingArchiveConfirmation = true
                } label: {
                    Label("Lager archivieren", systemImage: "archivebox")
                }
                .disabled(!model.canArchiveLocation || model.isMutating)
            }

            Button {
                stockEditor = .init(stock: nil)
            } label: {
                Label("Bestand erfassen", systemImage: "shippingbox.fill")
            }
            .keyboardShortcut("n", modifiers: .command)
            .disabled(!model.canEditLocation || model.isMutating)

            Button {
                csvImportModel = model.makeCSVImportViewModel()
            } label: {
                Label("CSV importieren", systemImage: "tablecells.badge.ellipsis")
            }
            .keyboardShortcut("i", modifiers: [.command, .shift])
            .disabled(!model.canEditLocation || model.isMutating)

            Button {
                openStockEditor()
            } label: {
                Label("Menge bearbeiten", systemImage: "number")
            }
            .disabled(!model.canEditStock || model.isMutating)

            Button(role: .destructive) {
                showingDeleteStockConfirmation = true
            } label: {
                Label("Position löschen", systemImage: "trash")
            }
            .disabled(!model.canEditStock || model.isMutating)
        }
    }

    private func openStockEditor() {
        guard model.canEditStock, let stock = model.selectedStock else { return }
        stockEditor = .init(stock: stock)
    }

    private func runLoad() {
        operationTask?.cancel()
        operationTask = Task { await loadInventory() }
    }

    private func loadInventory() async {
        do {
            try await model.load()
        } catch is CancellationError {
            return
        } catch {
            runtime.report(
                error,
                operation: .inventoryLoad,
                retry: { runLoad() }
            )
        }
    }

    private func runMutation(
        _ action: @escaping @MainActor () async throws -> Void
    ) {
        operationTask?.cancel()
        operationTask = Task {
            do {
                try await action()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: .inventorySave)
            }
        }
    }
}
