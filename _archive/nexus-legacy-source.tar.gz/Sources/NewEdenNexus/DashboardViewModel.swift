import Combine
import NewEdenNexusApplication
import NewEdenNexusDomain

@MainActor
final class DashboardViewModel: ObservableObject {
    @Published private(set) var projects: [ProductionProjectSnapshot] = []
    @Published private(set) var isLoading = false

    private let lifecycle: any ProductionProjectLifecycleManaging

    init(lifecycle: any ProductionProjectLifecycleManaging) {
        self.lifecycle = lifecycle
    }

    var activeProjectCount: Int {
        projects.filter {
            $0.status != .completed && $0.status != .archived
        }.count
    }

    var plannedProductQuantity: Int {
        projects.filter { $0.status != .archived }.reduce(0) {
            $0 + $1.targetQuantity
        }
    }

    func load() async throws {
        isLoading = true
        defer { isLoading = false }
        let loaded = try await lifecycle.projects(scope: .all)
        try Task.checkCancellation()
        projects = loaded
    }
}
