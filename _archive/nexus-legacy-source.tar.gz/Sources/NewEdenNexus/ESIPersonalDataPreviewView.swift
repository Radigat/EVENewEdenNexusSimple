import NewEdenNexusApplication
import SwiftUI

struct ESIPersonalDataPreviewView: View {
    let preview: ESIPersonalDataPreview
    let typeNames: [Int64: String]
    let missingTypeIDs: Set<Int64>
    let isApplying: Bool
    let apply: () -> Void
    let cancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Persönliche ESI-Daten prüfen")
                .font(.title2.bold())
            Text(
                "Noch wurde kein persönlicher Fachdatenstand geschrieben. "
                    + "Übernehmen ersetzt ausschließlich den bisherigen "
                    + "ESI-Snapshot dieses Charakters."
            )
            .foregroundStyle(.secondary)

            HStack(spacing: 12) {
                countCard("Assets", preview.assetCounts)
                countCard("Blueprints", preview.blueprintCounts)
                countCard("Jobs", preview.jobCounts)
            }

            if preview.totalChangeCount == 0 {
                ContentUnavailableView(
                    "Keine Änderungen",
                    systemImage: "checkmark.circle",
                    description: Text(
                        "Der lokale ESI-Snapshot entspricht dem geprüften Stand."
                    )
                )
            } else {
                List(preview.changes) { change in
                    HStack {
                        Text(dataSetName(change.dataSet))
                        Spacer()
                        Text(changeSubject(change))
                            .foregroundStyle(.secondary)
                        Text(changeName(change.kind))
                            .foregroundStyle(changeColor(change.kind))
                    }
                    .accessibilityElement(children: .combine)
                }
                if preview.isChangeListTruncated {
                    Text(
                        "Angezeigt werden die ersten 500 von "
                            + "\(NexusNumberFormat.quantity(preview.totalChangeCount)) Änderungen."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
            }

            HStack {
                Button("Abbrechen", role: .cancel, action: cancel)
                    .keyboardShortcut(.cancelAction)
                Spacer()
                Button("Geprüften Stand übernehmen", action: apply)
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)
                    .disabled(isApplying)
            }
        }
        .padding(24)
        .frame(minWidth: 760, minHeight: 520)
    }

    private func countCard(
        _ title: String,
        _ counts: ESIPersonalDataChangeCounts
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.headline)
            Text(
                "+\(NexusNumberFormat.quantity(counts.added)) · "
                    + "~\(NexusNumberFormat.quantity(counts.changed)) · "
                    + "−\(NexusNumberFormat.quantity(counts.removed))"
            )
            .font(.body.monospacedDigit())
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.quaternary, in: RoundedRectangle(cornerRadius: 8))
    }

    private func dataSetName(_ dataSet: ESIPersonalDataSet) -> String {
        switch dataSet {
        case .assets: "Asset"
        case .blueprints: "Blueprint"
        case .industryJobs: "Industry Job"
        }
    }

    private func changeSubject(
        _ change: ESIPersonalDataChange
    ) -> String {
        guard let typeID = change.typeID else {
            return switch change.dataSet {
            case .assets: "Gegenstand ohne Typreferenz"
            case .blueprints: "Blueprint ohne Typreferenz"
            case .industryJobs: "Industry Job ohne Typreferenz"
            }
        }
        if let name = typeNames[typeID] {
            return name
        }
        return missingTypeIDs.contains(typeID)
            ? "Typ im lokalen SDE nicht enthalten"
            : "Gegenstandsname noch nicht geladen"
    }

    private func changeName(
        _ kind: ESIPersonalDataChangeKind
    ) -> String {
        switch kind {
        case .added: "Neu"
        case .changed: "Geändert"
        case .removed: "Entfernt"
        }
    }

    private func changeColor(
        _ kind: ESIPersonalDataChangeKind
    ) -> Color {
        switch kind {
        case .added: .green
        case .changed: .orange
        case .removed: .red
        }
    }
}
