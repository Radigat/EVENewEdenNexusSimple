import NewEdenNexusApplication
import NewEdenNexusPersistence
import SwiftUI
import UniformTypeIdentifiers

struct LocalRecoveryView: View {
    @EnvironmentObject private var runtime: NexusAppRuntime
    @State private var showingImporter = false
    @State private var showingRestoreConfirmation = false
    @State private var previewWasConfirmed = false
    @State private var operationTask: Task<Void, Never>?

    var body: some View {
        Form {
            backupSection
            restoreSelectionSection
            if let preview = runtime.recoveryPreview {
                restorePreviewSection(preview)
            }
            if let result = runtime.lastRestore {
                restoreResultSection(result)
            }
        }
        .formStyle(.grouped)
        .padding()
        .fileImporter(
            isPresented: $showingImporter,
            allowedContentTypes: [.folder],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let packageURL = urls.first else { return }
                previewWasConfirmed = false
                runWithSecurityScope(packageURL) {
                    await runtime.inspectBackupForRestore(packageURL)
                }
            case .failure(let error):
                runtime.report(error, operation: .backupInspect)
            }
        }
        .confirmationDialog(
            "Lokale Daten wirklich ersetzen?",
            isPresented: $showingRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(
                "Geprüftes Backup wiederherstellen",
                role: .destructive
            ) {
                guard let packageURL =
                    runtime.recoveryPreview?.backup.packageURL else {
                    return
                }
                runWithSecurityScope(packageURL) {
                    await runtime.restoreInspectedBackup()
                    previewWasConfirmed = false
                }
            }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text(
                "Der geöffnete Store wird geschlossen und vorher automatisch als beforeRestore gesichert. Danach wird nur das unveränderte geprüfte Backup eingespielt und der Store erneut geöffnet."
            )
        }
        .onDisappear { operationTask?.cancel() }
    }

    private var backupSection: some View {
        Section("Lokale Sicherung") {
            Text(
                "Backups enthalten den lokalen Fachdaten-Store, aber keine Schlüsselbund-Tokens. Vor einer erkannten Schemamigration erzeugt die App automatisch eine Sicherung."
            )
            .foregroundStyle(.secondary)
            Button("Backup jetzt erstellen") {
                operationTask?.cancel()
                operationTask = Task {
                    await runtime.createManualBackup()
                }
            }
            .disabled(runtime.isRecoveryOperationRunning)
            .accessibilityIdentifier("recovery.manualBackup")

            if let backup = runtime.lastBackup {
                LabeledContent(
                    "Letzte Sicherung",
                    value: backup.packageURL.lastPathComponent
                )
                LabeledContent(
                    "Art",
                    value: localizedKind(backup.manifest.kind)
                )
                LabeledContent(
                    "Schema",
                    value: backup.manifest.schemaVersion
                )
            }
        }
    }

    private var restoreSelectionSection: some View {
        Section("Wiederherstellung") {
            Text(
                "Die Auswahl startet nur eine Integritäts- und Kompatibilitätsprüfung. Ohne sichtbare Vorschau und deine Bestätigung wird nichts geschrieben."
            )
            .foregroundStyle(.secondary)
            HStack {
                Button("Backup-Paket prüfen …") {
                    showingImporter = true
                }
                .disabled(runtime.isRecoveryOperationRunning)
                .accessibilityIdentifier("recovery.selectBackup")
                if runtime.isRecoveryOperationRunning {
                    ProgressView()
                        .controlSize(.small)
                }
            }
        }
    }

    private func restorePreviewSection(
        _ preview: LocalBackupRestorePreview
    ) -> some View {
        Section("Geprüfte Vorschau") {
            LabeledContent(
                "Paket",
                value: preview.backup.packageURL.lastPathComponent
            )
            LabeledContent(
                "Erstellt",
                value: preview.backup.manifest.createdAt.formatted(
                    date: .abbreviated,
                    time: .shortened
                )
            )
            LabeledContent(
                "Backup-Art",
                value: localizedKind(preview.backup.manifest.kind)
            )
            LabeledContent(
                "Schemaversion",
                value: preview.backup.manifest.schemaVersion
            )
            LabeledContent(
                "Datenmenge",
                value: ByteCountFormatter.string(
                    fromByteCount:
                        preview.backup.manifest.databaseByteCount,
                    countStyle: .file
                )
            )
            LabeledContent(
                "Prüfsumme",
                value: String(
                    preview.backup.manifest.databaseSHA256.prefix(16)
                ) + "…"
            )
            LabeledContent(
                "Wirkung",
                value: preview.willReplaceExistingStore
                    ? "Aktuellen lokalen Store ersetzen"
                    : "Neuen lokalen Store anlegen"
            )
            if preview.backup.manifest.schemaVersion
                != SQLiteLocalBackupService.schemaVersion {
                Label(
                    "Das ältere Backup wird nach der Wiederherstellung kontrolliert auf Schema \(SQLiteLocalBackupService.schemaVersion) migriert. Ein Downgrade auf eine ältere App-Version wird nicht unterstützt.",
                    systemImage: "arrow.up.doc"
                )
                .foregroundStyle(.orange)
            }
            Toggle(
                "Ich habe Paket, Schemaversion und Ersetzungswirkung geprüft.",
                isOn: $previewWasConfirmed
            )
            .accessibilityIdentifier("recovery.previewConfirmed")
            HStack {
                Button("Vorschau verwerfen") {
                    previewWasConfirmed = false
                    runtime.discardRecoveryPreview()
                }
                Button(
                    "Wiederherstellung bestätigen …",
                    role: .destructive
                ) {
                    showingRestoreConfirmation = true
                }
                .disabled(
                    !previewWasConfirmed
                        || runtime.isRecoveryOperationRunning
                )
                .accessibilityIdentifier("recovery.confirmRestore")
            }
        }
    }

    private func restoreResultSection(
        _ result: LocalBackupRestoreResult
    ) -> some View {
        Section("Letzte Wiederherstellung") {
            Label(
                "Backup wurde eingespielt und der lokale Store erneut geöffnet.",
                systemImage: "checkmark.circle.fill"
            )
            .foregroundStyle(.green)
            if let safetyBackup = result.safetyBackup {
                LabeledContent(
                    "Sicherheitsbackup",
                    value: safetyBackup.packageURL.lastPathComponent
                )
            }
        }
    }

    private func runWithSecurityScope(
        _ url: URL,
        operation: @escaping @MainActor () async -> Void
    ) {
        operationTask?.cancel()
        operationTask = Task {
            let hasScope = url.startAccessingSecurityScopedResource()
            defer {
                if hasScope {
                    url.stopAccessingSecurityScopedResource()
                }
            }
            await operation()
        }
    }

    private func localizedKind(_ kind: LocalBackupKind) -> String {
        switch kind {
        case .manual:
            "Manuell"
        case .beforeMigration:
            "Vor Migration"
        case .beforeRestore:
            "Vor Wiederherstellung"
        case .beforeSDEUpdate:
            "Vor SDE-Aktualisierung"
        }
    }
}
