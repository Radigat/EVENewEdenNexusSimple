import Foundation

enum AppExecutionEnvironment {
    static let isolatedStoreArgument =
        "--new-eden-nexus-isolated-store"

    static var isolatedStoreURL: URL? {
        isolatedStoreURL(arguments: ProcessInfo.processInfo.arguments)
    }

    static var isRunningTests: Bool {
        isRunningTests(
            environment: ProcessInfo.processInfo.environment,
            arguments: ProcessInfo.processInfo.arguments
        )
    }

    static func isRunningTests(
        environment: [String: String],
        arguments: [String]
    ) -> Bool {
        environment["XCTestConfigurationFilePath"] != nil
            || environment["XCTestBundlePath"] != nil
            || environment["XCInjectBundleInto"] != nil
            || isolatedStoreURL(arguments: arguments) != nil
    }

    static func isolatedStoreURL(arguments: [String]) -> URL? {
        guard let argumentIndex = arguments.firstIndex(
            of: isolatedStoreArgument
        ) else {
            return nil
        }
        let pathIndex = arguments.index(after: argumentIndex)
        guard arguments.indices.contains(pathIndex) else {
            return nil
        }

        let path = arguments[pathIndex]
        guard path.hasPrefix("/") else {
            return nil
        }
        return URL(fileURLWithPath: path).standardizedFileURL
    }
}
