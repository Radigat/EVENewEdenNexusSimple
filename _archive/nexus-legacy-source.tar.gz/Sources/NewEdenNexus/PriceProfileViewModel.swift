import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

enum PriceProfileViewModelError: Error, Equatable {
    case operationAlreadyRunning
}

@MainActor
final class PriceProfileViewModel: ObservableObject {
    @Published var selectedProfileID: UUID?
    @Published var selectedPriceID: UUID?
    @Published private(set) var profiles: [PriceProfileSnapshot] = []
    @Published private(set) var prices: [ManualPriceSnapshot] = []
    @Published private(set) var marketProvenanceByPriceID:
        [UUID: MarketPriceProvenanceSnapshot] = [:]
    @Published private(set) var isLoading = false
    @Published private(set) var isMutating = false

    private let service: any PriceProfileManaging
    private let csvImporter: any PriceCSVImporting
    private let csvFileReader: any InventoryCSVFileReading
    private let marketRepository:
        (any MarketPriceImportRepository)?

    init(
        service: any PriceProfileManaging,
        csvImporter: any PriceCSVImporting,
        csvFileReader: any InventoryCSVFileReading,
        marketRepository:
            (any MarketPriceImportRepository)? = nil
    ) {
        self.service = service
        self.csvImporter = csvImporter
        self.csvFileReader = csvFileReader
        self.marketRepository = marketRepository
    }

    var selectedProfile: PriceProfileSnapshot? {
        profiles.first { $0.id == selectedProfileID }
    }

    var selectedPrice: ManualPriceSnapshot? {
        prices.first { $0.id == selectedPriceID }
    }

    func marketProvenance(
        priceID: UUID
    ) -> MarketPriceProvenanceSnapshot? {
        marketProvenanceByPriceID[priceID]
    }

    func makeCSVImportViewModel() -> PriceCSVImportViewModel {
        PriceCSVImportViewModel(
            importer: csvImporter,
            fileReader: csvFileReader
        )
    }

    func load() async throws {
        isLoading = true
        defer { isLoading = false }
        profiles = try await service.profiles()
        if !profiles.contains(where: { $0.id == selectedProfileID }) {
            selectedProfileID =
                profiles.first(where: \.isActive)?.id ?? profiles.first?.id
        }
        try await loadPrices()
    }

    func selectProfile(_ id: UUID?) async throws {
        selectedProfileID = id
        selectedPriceID = nil
        try await loadPrices()
    }

    func createProfile(name: String) async throws {
        try await mutate {
            try await service.createProfile(
                draft: PriceProfileDraft(name: name)
            )
        }
    }

    func renameSelectedProfile(name: String) async throws {
        guard let selectedProfileID else { return }
        try await mutate {
            try await service.renameProfile(
                id: selectedProfileID,
                draft: PriceProfileDraft(name: name)
            )
        }
    }

    func activateSelectedProfile() async throws {
        guard let selectedProfileID else { return }
        try await mutateProfile {
            try await service.activateProfile(id: selectedProfileID)
        }
    }

    func deleteSelectedProfile() async throws {
        guard let selectedProfileID else { return }
        try await mutateProfile {
            try await service.deleteProfile(
                id: selectedProfileID,
                confirmed: true
            )
        }
    }

    func searchItems(query: String) async throws -> CatalogSearchPage {
        try await service.searchItems(query: query)
    }

    func savePrice(
        typeID: Int64,
        amountText: String,
        validFrom: Date,
        validUntil: Date?
    ) async throws {
        guard let selectedProfileID else { return }
        let amount = try ISKAmount.parse(amountText)
        try await mutatePrice {
            try await service.savePrice(
                draft: ManualPriceDraft(
                    profileID: selectedProfileID,
                    typeID: typeID,
                    amount: amount,
                    validFrom: validFrom,
                    validUntil: validUntil
                )
            )
        }
    }

    func deleteSelectedPrice() async throws {
        guard let selectedPriceID else { return }
        try await mutatePrice {
            try await service.deletePrice(
                id: selectedPriceID,
                confirmed: true
            )
            return nil
        }
    }

    private func loadPrices() async throws {
        guard let selectedProfileID else {
            prices = []
            marketProvenanceByPriceID = [:]
            selectedPriceID = nil
            return
        }
        prices = try await service.prices(profileID: selectedProfileID)
        if let marketRepository {
            marketProvenanceByPriceID = Dictionary(
                uniqueKeysWithValues:
                    try await marketRepository
                        .marketPriceProvenances(
                            profileID: selectedProfileID
                        )
                        .map { ($0.priceID, $0) }
            )
        } else {
            marketProvenanceByPriceID = [:]
        }
        if !prices.contains(where: { $0.id == selectedPriceID }) {
            selectedPriceID = nil
        }
    }

    private func mutate(
        _ operation: () async throws -> PriceProfileSnapshot
    ) async throws {
        try requireIdle()
        isMutating = true
        defer { isMutating = false }
        let result = try await operation()
        profiles = try await service.profiles()
        selectedProfileID = result.id
        selectedPriceID = nil
        try await loadPrices()
    }

    private func mutateProfile(
        _ operation: () async throws -> Void
    ) async throws {
        try requireIdle()
        isMutating = true
        defer { isMutating = false }
        try await operation()
        profiles = try await service.profiles()
        if !profiles.contains(where: { $0.id == selectedProfileID }) {
            selectedProfileID =
                profiles.first(where: \.isActive)?.id ?? profiles.first?.id
        }
        selectedPriceID = nil
        try await loadPrices()
    }

    private func mutatePrice(
        _ operation: () async throws -> ManualPriceSnapshot?
    ) async throws {
        try requireIdle()
        isMutating = true
        defer { isMutating = false }
        let result = try await operation()
        try await loadPrices()
        selectedPriceID = result?.id
    }

    private func requireIdle() throws {
        guard !isMutating else {
            throw PriceProfileViewModelError.operationAlreadyRunning
        }
    }
}
