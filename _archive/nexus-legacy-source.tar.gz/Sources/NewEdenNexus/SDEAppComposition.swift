import Foundation
import NewEdenNexusApplication
import NewEdenNexusInfrastructure
import NewEdenNexusPersistence
import SwiftData

@MainActor
enum SDEAppComposition {
    static func makeViewModel(
        container: ModelContainer,
        logger: any DiagnosticLogging,
        defaults: UserDefaults = .standard
    ) throws -> SDEManagementViewModel {
        SDEManagementViewModel(
            dependencies: try makeDependencies(
                container: container,
                logger: logger
            ),
            defaults: defaults
        )
    }

    private static func makeDependencies(
        container: ModelContainer,
        logger: any DiagnosticLogging
    ) throws -> SDEManagementViewModel.Dependencies {
        let directories = try SDEAppDirectories()
        let stateRepository = SwiftDataSDEUpdateStateRepository(
            modelContainer: container
        )
        let catalogRepository = SwiftDataStaticDataCatalogRepository(
            modelContainer: container
        )
        let retentionRepository =
            SwiftDataSDECatalogRetentionRepository(
                modelContainer: container
            )
        let logStore = FileSDEInstallationLogStore(
            directoryURL: directories.logs
        )

        func configuredContact() -> String? {
            KeychainStore.read(
                account: SDEAppConfiguration.ownerContactKeychainAccount
            )?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .nilIfEmpty
        }

        func makeUserAgent(
            requireContact: Bool
        ) throws -> SDEUserAgentConfiguration {
            let contact = configuredContact()
            if requireContact, contact == nil {
                throw SDEInstallationError.missingOwnerContact
            }
            return try SDEUserAgentConfiguration(
                applicationName: SDEAppConfiguration.applicationName,
                applicationVersion: SDEAppConfiguration.applicationVersion,
                contact: contact
            )
        }

        func makeCachedDownloader()
            throws -> CachedSDEArchiveDownloader {
            let base = try CCPSDEArchiveDownloader(
                transport: URLSessionSDEArchiveHTTPTransport(),
                configuration: CCPSDEArchiveDownloaderConfiguration(
                    workingDirectoryURL: directories.downloads,
                    userAgent: try makeUserAgent(requireContact: true)
                )
            )
            return CachedSDEArchiveDownloader(
                base: base,
                cacheDirectoryURL: directories.cache
            )
        }

        func makeInstallationService(
            downloader: any SDEArchiveDownloading
        ) -> SDEInstallationService {
            SDEInstallationService(
                downloader: downloader,
                archivePreparer: SecureSDEArchivePreparer(),
                importer: JSONLinesSDEImportService(),
                mapper: JSONLinesSDECatalogMapper(),
                stagingStore: SwiftDataSDEStagingService(
                    rootDirectoryURL: directories.staging
                ),
                backup: SQLiteSDEPromotionSafetyBackup(
                    sourceStoreURL:
                        NexusModelContainerFactory.defaultStoreURL,
                    backupDirectoryURL: directories.backups
                ),
                catalogStore: catalogRepository,
                rollbackStore: catalogRepository,
                activeVersionReader: stateRepository,
                logStore: logStore
            )
        }

        return SDEManagementViewModel.Dependencies(
            check: { force in
                let metadataClient = try CCPSDEMetadataClient(
                    transport: URLSessionSDEHTTPTransport(),
                    configuration: CCPSDEMetadataClientConfiguration(
                        userAgent: try makeUserAgent(
                            requireContact: false
                        )
                    )
                )
                let service = SDEUpdateService(
                    checker: metadataClient,
                    stateStore: stateRepository,
                    activeVersionReader: stateRepository,
                    policy: try SDEUpdateCheckPolicy(
                        schemaUnderstoodThroughBuildNumber:
                            SDEAppConfiguration
                                .schemaUnderstoodThroughBuildNumber
                    ),
                    logger: logger
                )
                return try await service.check(force: force)
            },
            loadState: {
                try await stateRepository.loadState()
            },
            activeVersion: {
                try await stateRepository.activeSDEVersion()
            },
            readLogs: {
                try await logStore.allLogs()
            },
            prefetch: { buildNumber in
                try await makeCachedDownloader().prefetch(
                    buildNumber: buildNumber
                )
            },
            prefetched: { buildNumber in
                guard configuredContact() != nil else {
                    return nil
                }
                return try await makeCachedDownloader().prefetchedArchive(
                    buildNumber: buildNumber
                )
            },
            install: { buildNumber, complianceConfirmed, progress in
                let checkedState = try await stateRepository.loadState()
                guard checkedState.lastKnownOfficialBuildNumber
                        == buildNumber,
                      let schemaChangelogHighestAfterBuildNumber =
                        checkedState.schemaHighestAfterBuildNumber else {
                    throw SDEInstallationError.schemaGateRejected
                }
                let downloader = try makeCachedDownloader()
                let service = makeInstallationService(
                    downloader: downloader
                )
                let result = try await service.install(
                    SDEInstallationRequest(
                        buildNumber: buildNumber,
                        schemaChangelogHighestAfterBuildNumber:
                            schemaChangelogHighestAfterBuildNumber,
                        schemaUnderstoodThroughBuildNumber:
                            SDEAppConfiguration
                                .schemaUnderstoodThroughBuildNumber,
                        ownerComplianceConfirmed: complianceConfirmed,
                        packageDestinationDirectoryURL:
                            directories.packages
                    ),
                    progress: progress
                )
                try await downloader.removePrefetchedArchive(
                    buildNumber: buildNumber
                )
                return result
            },
            recover: {
                let recoveryBoundary = SDEArchiveRecoveryBoundary(
                    downloadDirectoryURL: directories.downloads,
                    cacheDirectoryURL: directories.cache
                )
                return try await makeInstallationService(
                    downloader: recoveryBoundary
                )
                .recoverInterruptedInstallations()
            },
            retentionPreview: { keepCount in
                try await retentionRepository.previewRetention(
                    keepingRollbackVersions: keepCount
                )
            },
            applyRetention: { preview, confirmation in
                try await retentionRepository.applyRetention(
                    preview: preview,
                    confirmation: confirmation
                )
            },
            storeByteCount: {
                try localStoreByteCount(
                    storeURL: NexusModelContainerFactory.defaultStoreURL
                )
            },
            hasOwnerContact: {
                configuredContact() != nil
            },
            saveOwnerContact: { contact in
                if contact.isEmpty {
                    try KeychainStore.delete(
                        account:
                            SDEAppConfiguration.ownerContactKeychainAccount
                    )
                    guard try KeychainStore.readSecurely(
                        account:
                            SDEAppConfiguration.ownerContactKeychainAccount
                    ) == nil else {
                        throw KeychainStoreError.verificationFailed
                    }
                } else {
                    _ = try SDEUserAgentConfiguration(
                        applicationName:
                            SDEAppConfiguration.applicationName,
                        applicationVersion:
                            SDEAppConfiguration.applicationVersion,
                        contact: contact
                    )
                    try KeychainStore.save(
                        contact,
                        account:
                            SDEAppConfiguration.ownerContactKeychainAccount
                    )
                    guard try KeychainStore.readSecurely(
                        account:
                            SDEAppConfiguration.ownerContactKeychainAccount
                    ) == contact else {
                        throw KeychainStoreError.verificationFailed
                    }
                }
            },
            loadOwnerContact: {
                configuredContact() ?? ""
            },
            now: Date.init
        )
    }

    private static func localStoreByteCount(
        storeURL: URL,
        fileManager: FileManager = .default
    ) throws -> Int64 {
        let urls = [
            storeURL,
            URL(fileURLWithPath: storeURL.path + "-wal"),
            URL(fileURLWithPath: storeURL.path + "-shm")
        ]
        return try urls.reduce(Int64(0)) { total, url in
            guard fileManager.fileExists(atPath: url.path) else {
                return total
            }
            let values = try url.resourceValues(
                forKeys: [.fileSizeKey, .isRegularFileKey]
            )
            guard values.isRegularFile == true else {
                return total
            }
            let (sum, overflow) = total.addingReportingOverflow(
                Int64(values.fileSize ?? 0)
            )
            guard !overflow else {
                throw SDEInstallationError.insufficientDiskSpace
            }
            return sum
        }
    }
}

private extension String {
    var nilIfEmpty: String? {
        isEmpty ? nil : self
    }
}
