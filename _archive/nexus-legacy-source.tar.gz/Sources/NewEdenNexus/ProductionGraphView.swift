import NewEdenNexusDomain
import SwiftUI

enum ProductionWorkspaceSection: String, CaseIterable, Identifiable {
    case overview
    case decisions
    case inventory
    case economics
    case materials
    case stages

    var id: Self { self }

    var title: String {
        switch self {
        case .overview:
            "Übersicht"
        case .decisions:
            "Bauen / Kaufen"
        case .inventory:
            "Lager & Einkauf"
        case .economics:
            "Budget"
        case .materials:
            "Materialsumme"
        case .stages:
            "Produktionsstufen"
        }
    }
}

struct ProductionGraphView: View {
    let project: ProductionProjectSnapshot
    @ObservedObject var model: ProductionGraphViewModel
    @ObservedObject var buildOrBuyModel:
        BuildOrBuyWorkspaceViewModel
    @ObservedObject var availabilityModel: InventoryAvailabilityViewModel
    @ObservedObject var safetyStockModel: SafetyStockViewModel
    @ObservedObject var reservationModel:
        ProjectReservationViewModel
    @ObservedObject var conflictModel:
        ReservationConflictViewModel
    @EnvironmentObject private var runtime: NexusAppRuntime
    @Environment(\.dismiss) private var dismiss
    @State private var task: Task<Void, Never>?
    @State private var showingInventoryAvailability = false
    @State private var showingSafetyStock = false
    @State private var showingReservations = false
    @State private var showingReservationConflicts = false
    @State private var selectedSection: ProductionWorkspaceSection = .overview
    @State private var visibleGraphNodeLimit =
        ProductionGraphDisplayBudget.initialVisibleNodeCount

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header
            Divider()
            content
            Divider()
            footer
        }
        .padding(24)
        .frame(
            minWidth: 1_080,
            idealWidth: 1_360,
            minHeight: 700,
            idealHeight: 840
        )
        .task {
            await load()
        }
        .onDisappear {
            task?.cancel()
        }
        .sheet(
            isPresented: $showingInventoryAvailability,
            onDismiss: refreshDerivedPlanning
        ) {
            InventoryAvailabilitySheet(
                project: project,
                model: availabilityModel
            )
        }
        .sheet(
            isPresented: $showingSafetyStock,
            onDismiss: refreshDerivedPlanning
        ) {
            SafetyStockSheet(
                project: project,
                model: safetyStockModel
            )
        }
        .sheet(
            isPresented: $showingReservations,
            onDismiss: refreshDerivedPlanning
        ) {
            ProjectReservationSheet(
                project: project,
                model: reservationModel
            )
        }
        .sheet(
            isPresented: $showingReservationConflicts,
            onDismiss: refreshDerivedPlanning
        ) {
            ReservationConflictSheet(
                project: project,
                model: conflictModel
            )
        }
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Produktionsworkspace")
                    .font(.title2.bold())
                Text(project.name)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if model.isStale(for: project) {
                Label("Veraltet", systemImage: "exclamationmark.triangle")
                    .foregroundStyle(.orange)
                    .accessibilityLabel(
                        "Der gespeicherte Produktionsgraph ist veraltet"
                    )
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if model.isLoading && model.graph == nil {
            ProgressView("Produktionsgraph wird geladen …")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if let graph = model.graph {
            VStack(alignment: .leading, spacing: 12) {
                graphMetadata(graph)
                sectionNavigation
                Divider()
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 16) {
                        selectedSectionContent(graph)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        } else {
            ContentUnavailableView {
                Label(
                    "Noch kein Produktionsgraph",
                    systemImage: "point.3.connected.trianglepath.dotted"
                )
            } description: {
                Text(
                    "Erzeuge den ersten, kataloggebundenen Rezeptschritt für dieses Projekt."
                )
            } actions: {
                Button("Graph erzeugen") {
                    generate()
                }
                .buttonStyle(.borderedProminent)
                .disabled(!canGenerate)
            }
        }
    }

    private var sectionNavigation: some View {
        Picker("Arbeitsbereich", selection: $selectedSection) {
            ForEach(ProductionWorkspaceSection.allCases) { section in
                Text(section.title).tag(section)
            }
        }
        .pickerStyle(.segmented)
        .labelsHidden()
        .accessibilityLabel("Bereich des Produktionsworkspace")
        .help("Wechselt zwischen den Bereichen des Produktionsworkspace")
    }

    @ViewBuilder
    private func selectedSectionContent(
        _ graph: ProductionGraphSnapshot
    ) -> some View {
        switch selectedSection {
        case .overview, .decisions, .inventory, .economics:
            if model.isStale(for: project) {
                Label(
                    "Der Produktionsplan bleibt verborgen, bis der veraltete Graph neu erzeugt wurde.",
                    systemImage: "exclamationmark.triangle"
                )
                .foregroundStyle(.orange)
                .accessibilityLabel(
                    "Produktionsplanung nicht verfügbar. Produktionsgraph neu erzeugen."
                )
            } else {
                ProductionWorkspaceView(
                    project: project,
                    graph: graph,
                    section: selectedSection,
                    model: buildOrBuyModel,
                    conflictModel: conflictModel,
                    refresh: refreshDerivedPlanning,
                    reportError: {
                        runtime.report(
                            $0,
                            operation: .productionPlanning
                        )
                    }
                )
            }
        case .materials:
            materialAggregation(graph)
        case .stages:
            VStack(alignment: .leading, spacing: 12) {
                Text("Produktionsstufen")
                    .font(.headline)
                graphStages(graph)
            }
        }
    }

    private func graphMetadata(
        _ graph: ProductionGraphSnapshot
    ) -> some View {
        let root = graph.nodes.first(where: {
            $0.id == graph.rootNodeID
        })
        let calculation = root?.runCalculation
        let isReaction = root?.recipe?.activity == .reaction
        return Grid(alignment: .leading, horizontalSpacing: 24) {
            GridRow {
                Text("Zielmenge")
                Text(NexusNumberFormat.quantity(graph.projectTargetQuantity))
                    .monospacedDigit()
                Text("SDE-Build")
                Text(graph.catalogBuildNumber.formatted())
                    .monospacedDigit()
            }
            GridRow {
                Text(isReaction ? "Reaktionsformel" : "Blueprint")
                Text(graph.targetBlueprintTypeID.formatted())
                    .monospacedDigit()
                Text("Graphformat")
                Text(graph.formatVersion.formatted())
                    .monospacedDigit()
            }
            if let calculation {
                GridRow {
                    Text("Benötigte Runs")
                    Text(NexusNumberFormat.quantity(calculation.requiredRuns))
                        .monospacedDigit()
                    Text("Output je Run")
                    Text(
                        NexusNumberFormat.quantity(
                            calculation.outputQuantityPerRun
                        )
                    )
                        .monospacedDigit()
                }
                GridRow {
                    Text("Tatsächliche Ausgabe")
                    Text(
                        NexusNumberFormat.quantity(
                            calculation.producedOutputQuantity
                        )
                    )
                        .monospacedDigit()
                    Text("Überschuss")
                    Text(
                        NexusNumberFormat.quantity(
                            calculation.surplusOutputQuantity
                        )
                    )
                        .monospacedDigit()
                }
                GridRow {
                    Text("Formelversion")
                    Text(calculation.formulaVersion.formatted())
                        .monospacedDigit()
                    Text(isReaction ? "Blueprint-ME/TE" : "Blueprint-ME")
                    Text(
                        isReaction
                            ? "Nicht anwendbar"
                            : graph.blueprintMaterialEfficiency.map {
                            "\($0) %"
                        } ?? "Nicht vorhanden"
                    )
                    .monospacedDigit()
                }
                GridRow {
                    Text("Materialformel")
                    Text(
                        graph.edges.first?
                            .reactionMaterialCalculation?
                            .formulaVersion.formatted()
                            ?? graph.edges.first?.materialCalculation?
                                .formulaVersion.formatted()
                            ?? "Keine Materialposition"
                    )
                    .monospacedDigit()
                    Text("")
                    Text("")
                }
                GridRow {
                    Text("Expansionsregel")
                    Text(
                        graph.expansionPolicyVersion.map {
                            "Manufacturing/Reaktion v\($0)"
                        } ?? "Nicht vorhanden"
                    )
                    Text("Graphknoten")
                    Text(NexusNumberFormat.quantity(graph.nodes.count))
                        .monospacedDigit()
                }
                GridRow {
                    Text("Aggregationsformel")
                    Text(
                        graph.materialAggregation?.formulaVersion
                            .formatted()
                            ?? "Nicht vorhanden"
                    )
                    .monospacedDigit()
                    Text("Materialtypen")
                    Text(
                        graph.materialAggregation.map {
                            NexusNumberFormat.quantity(
                                $0.materialTypeCount
                            )
                        }
                            ?? "—"
                    )
                    .monospacedDigit()
                }
            } else {
                GridRow {
                    Text("Runberechnung")
                    Text("Nicht vorhanden – Graph neu erzeugen")
                    Text("")
                    Text("")
                }
            }
        }
        .font(.caption)
        .foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
    }

    @ViewBuilder
    private func materialAggregation(
        _ graph: ProductionGraphSnapshot
    ) -> some View {
        if let aggregation = graph.materialAggregation {
            let namesByID = Dictionary(
                uniqueKeysWithValues: graph.nodes.map {
                    ($0.id, $0.name)
                }
            )
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .firstTextBaseline) {
                    Text("Zusammengeführte Endmaterialien")
                        .font(.headline)
                    Spacer()
                    Button("Bestand abgleichen") {
                        showingInventoryAvailability = true
                    }
                    .keyboardShortcut("b", modifiers: [.command, .shift])
                    .accessibilityLabel(
                        "Verfügbarkeit und Ausschlüsse für dieses Projekt"
                    )
                    Button("Sicherheitsbestände") {
                        showingSafetyStock = true
                    }
                    .keyboardShortcut("s", modifiers: [.command, .option])
                    .accessibilityLabel(
                        "Sicherheitsbestände und Warnschwellen für dieses Projekt"
                    )
                    Button("Projektreservierungen") {
                        showingReservations = true
                    }
                    .keyboardShortcut(
                        "r",
                        modifiers: [.command, .option]
                    )
                    .accessibilityLabel(
                        "Materialreservierungen für dieses Projekt"
                    )
                    Button("Reservierungskonflikte") {
                        showingReservationConflicts = true
                    }
                    .keyboardShortcut(
                        "k",
                        modifiers: [.command, .option]
                    )
                    .accessibilityLabel(
                        "Reservierungskonflikte für dieses Projekt prüfen"
                    )
                    Text(
                        "\(NexusNumberFormat.quantity(aggregation.materialTypeCount)) Typen · \(NexusNumberFormat.quantity(aggregation.occurrenceCount)) Vorkommen"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
                }
                if aggregation.lines.isEmpty {
                    Text("Dieser Graph enthält keine Endmaterialien.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(
                        aggregation.lines,
                        id: \.typeID
                        ) { line in
                            DisclosureGroup {
                                LazyVStack(alignment: .leading, spacing: 8) {
                                    ForEach(
                                        line.occurrences,
                                        id: \.leafNodeID
                                    ) { occurrence in
                                        materialOccurrence(
                                            occurrence,
                                            namesByID: namesByID
                                        )
                                    }
                            }
                            .padding(.leading, 20)
                            .padding(.vertical, 4)
                        } label: {
                            HStack(alignment: .firstTextBaseline) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(line.name)
                                        .fontWeight(.semibold)
                                    Text(
                                        "Type-ID \(line.typeID) · \(NexusNumberFormat.quantity(line.occurrences.count)) Vorkommen"
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(
                                    NexusNumberFormat.quantity(
                                        line.totalQuantity
                                    )
                                )
                                    .fontWeight(.semibold)
                                    .monospacedDigit()
                            }
                            .accessibilityElement(children: .combine)
                            .accessibilityLabel(
                                "\(line.name), Type-ID \(line.typeID), Gesamtmenge \(NexusNumberFormat.quantity(line.totalQuantity)), \(NexusNumberFormat.quantity(line.occurrences.count)) Vorkommen"
                            )
                        }
                    }
                }
            }
        } else {
            Label(
                "Keine gespeicherte Materialaggregation – Graph neu erzeugen",
                systemImage: "arrow.triangle.2.circlepath"
            )
            .foregroundStyle(.secondary)
            .accessibilityLabel(
                "Dieser ältere Produktionsgraph enthält keine Materialaggregation. Er muss neu erzeugt werden."
            )
        }
    }

    private func materialOccurrence(
        _ occurrence: ProductionGraphMaterialOccurrence,
        namesByID: [ProductionGraphNodeID: String]
    ) -> some View {
        let path = occurrence.path.map {
            namesByID[$0] ?? "Unbekannter Knoten"
        }.joined(separator: " → ")
        return VStack(alignment: .leading, spacing: 2) {
            Text(
                "\(NexusNumberFormat.quantity(occurrence.quantity)) aus \(path)"
            )
            .monospacedDigit()
            Text(leafReasonName(occurrence.leafReason))
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(
            "Vorkommensmenge \(NexusNumberFormat.quantity(occurrence.quantity)). Pfad \(path). \(leafReasonName(occurrence.leafReason))"
        )
    }

    @ViewBuilder
    private func graphStages(
        _ graph: ProductionGraphSnapshot
    ) -> some View {
        if graph.nodes.count
            <= ProductionGraphDisplayBudget.outlineNodeLimit,
           let tree = GraphDisplayNode(graph: graph) {
            OutlineGroup(
                [tree],
                children: \.children
            ) { item in
                GraphNodeRow(item: item)
            }
        } else if let projection = ProductionGraphDisplayProjection(
            graph: graph,
            visibleNodeLimit: visibleGraphNodeLimit
        ) {
            Text(
                "Großer Graph: \(NexusNumberFormat.quantity(projection.rows.count)) von \(NexusNumberFormat.quantity(projection.totalNodeCount)) Stufen werden gestaffelt dargestellt."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityLabel(
                "\(NexusNumberFormat.quantity(projection.rows.count)) von \(NexusNumberFormat.quantity(projection.totalNodeCount)) Produktionsstufen sichtbar"
            )
            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(projection.rows) { row in
                    GraphNodeRow(row: row)
                        .padding(
                            .leading,
                            min(CGFloat(row.node.depth) * 16, 240)
                        )
                }
            }
            if projection.omittedNodeCount > 0 {
                Button(
                    "Weitere \(NexusNumberFormat.quantity(min(ProductionGraphDisplayBudget.visibleNodeIncrement, projection.omittedNodeCount))) Stufen anzeigen"
                ) {
                    visibleGraphNodeLimit = min(
                        graph.nodes.count,
                        visibleGraphNodeLimit
                            + ProductionGraphDisplayBudget
                                .visibleNodeIncrement
                    )
                }
                .accessibilityHint(
                    "Erweitert die gestaffelte Graphdarstellung, ohne den Produktionsplan neu zu berechnen."
                )
            }
        } else {
            Label(
                "Der Graph kann nicht dargestellt werden.",
                systemImage: "exclamationmark.triangle"
            )
            .foregroundStyle(.orange)
        }
    }

    private var footer: some View {
        HStack {
            Text(
                "T1-, T2- und Reaktionsstufen werden rekursiv aufgelöst; gleiche Endmaterialien sind nach Type-ID zusammengeführt."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            Spacer()
            Button("Schließen") {
                dismiss()
            }
            .keyboardShortcut(.cancelAction)
            Button(
                model.graph == nil ? "Graph erzeugen" : "Neu erzeugen"
            ) {
                generate()
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut("g", modifiers: [.command, .shift])
            .disabled(!canGenerate)
        }
    }

    private var canGenerate: Bool {
        project.status != .archived
            && project.target != nil
            && !model.isLoading
            && !model.isGenerating
    }

    private func load() async {
        do {
            try await model.load(for: project)
            try await loadDerivedPlanning()
        } catch is CancellationError {
            return
        } catch {
            runtime.report(error, operation: .productionGraph)
        }
    }

    private func generate() {
        task?.cancel()
        task = Task {
            do {
                try await model.generate(for: project)
                try await loadDerivedPlanning()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(error, operation: .productionGraph)
            }
        }
    }

    private func refreshDerivedPlanning() {
        task?.cancel()
        task = Task {
            do {
                try await loadDerivedPlanning()
            } catch is CancellationError {
                return
            } catch {
                runtime.report(
                    error,
                    operation: .productionPlanning
                )
            }
        }
    }

    private func loadDerivedPlanning() async throws {
        guard let graph = model.graph,
              !model.isStale(for: project) else {
            return
        }
        try await buildOrBuyModel.load(
            projectID: project.id,
            graph: graph
        )
        try await conflictModel.load(projectID: project.id)
    }

    private func leafReasonName(
        _ reason: ProductionGraphLeafReason
    ) -> String {
        switch reason {
        case .noManufacturingRecipe:
            "Endmaterial: kein Herstellungsrezept"
        case .noProductionRecipe:
            "Endmaterial: kein Fertigungs- oder Reaktionsrezept"
        case .reactionDeferred:
            "Legacy-Endmaterial: Reaktion war zurückgestellt"
        }
    }
}

private struct GraphDisplayNode: Identifiable {
    let node: ProductionGraphNode
    let incomingQuantity: Int64?
    let incomingCalculation: ProductionMaterialCalculation?
    let incomingReactionCalculation: ReactionMaterialCalculation?
    let children: [GraphDisplayNode]?

    var id: ProductionGraphNodeID {
        node.id
    }

    init?(graph: ProductionGraphSnapshot) {
        let nodes = Dictionary(
            uniqueKeysWithValues: graph.nodes.map { ($0.id, $0) }
        )
        let groupedEdges = Dictionary(
            grouping: graph.edges,
            by: \.parentID
        )
        guard let root = Self.make(
            nodeID: graph.rootNodeID,
            incomingQuantity: nil,
            incomingCalculation: nil,
            incomingReactionCalculation: nil,
            nodes: nodes,
            groupedEdges: groupedEdges
        ) else {
            return nil
        }
        self = root
    }

    private init(
        node: ProductionGraphNode,
        incomingQuantity: Int64?,
        incomingCalculation: ProductionMaterialCalculation?,
        incomingReactionCalculation: ReactionMaterialCalculation?,
        children: [GraphDisplayNode]?
    ) {
        self.node = node
        self.incomingQuantity = incomingQuantity
        self.incomingCalculation = incomingCalculation
        self.incomingReactionCalculation = incomingReactionCalculation
        self.children = children
    }

    private static func make(
        nodeID: ProductionGraphNodeID,
        incomingQuantity: Int64?,
        incomingCalculation: ProductionMaterialCalculation?,
        incomingReactionCalculation: ReactionMaterialCalculation?,
        nodes: [ProductionGraphNodeID: ProductionGraphNode],
        groupedEdges: [
            ProductionGraphNodeID: [ProductionGraphEdge]
        ]
    ) -> GraphDisplayNode? {
        guard let node = nodes[nodeID] else {
            return nil
        }
        let childNodes = (groupedEdges[nodeID] ?? [])
            .sorted {
                if $0.sortOrder != $1.sortOrder {
                    return $0.sortOrder < $1.sortOrder
                }
                return $0.childID.rawValue < $1.childID.rawValue
            }
            .compactMap { edge in
                make(
                    nodeID: edge.childID,
                    incomingQuantity: edge.baseQuantityPerRun,
                    incomingCalculation: edge.materialCalculation,
                    incomingReactionCalculation:
                        edge.reactionMaterialCalculation,
                    nodes: nodes,
                    groupedEdges: groupedEdges
                )
            }
        return GraphDisplayNode(
            node: node,
            incomingQuantity: incomingQuantity,
            incomingCalculation: incomingCalculation,
            incomingReactionCalculation: incomingReactionCalculation,
            children: childNodes.isEmpty ? nil : childNodes
        )
    }
}

private struct GraphNodeRow: View {
    let node: ProductionGraphNode
    let incomingQuantity: Int64?
    let incomingCalculation: ProductionMaterialCalculation?
    let incomingReactionCalculation: ReactionMaterialCalculation?

    init(item: GraphDisplayNode) {
        node = item.node
        incomingQuantity = item.incomingQuantity
        incomingCalculation = item.incomingCalculation
        incomingReactionCalculation =
            item.incomingReactionCalculation
    }

    init(row: ProductionGraphDisplayRow) {
        node = row.node
        incomingQuantity = row.incomingQuantity
        incomingCalculation = row.incomingCalculation
        incomingReactionCalculation =
            row.incomingReactionCalculation
    }

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Image(systemName: symbol)
                .foregroundStyle(color)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(node.name)
                    .fontWeight(
                        node.kind == .target ? .semibold : .regular
                    )
                HStack(spacing: 10) {
                    Text("Type-ID \(node.typeID)")
                    Text(role)
                    Text("Tiefe \(node.depth)")
                    if let quantity = incomingQuantity {
                        Text(
                            "\(NexusNumberFormat.quantity(quantity)) je Run"
                        )
                    }
                    if let calculation =
                        incomingReactionCalculation {
                        Text(
                            "\(NexusNumberFormat.quantity(calculation.rawQuantity)) roh → \(NexusNumberFormat.quantity(calculation.effectiveQuantity)) effektiv mit Reaktionsfaktor \(basisPointPercent(calculation.materialFactorBasisPoints)), Ersparnis \(NexusNumberFormat.quantity(calculation.savedQuantity))"
                        )
                    } else if let calculation = incomingCalculation {
                        Text(
                            "\(NexusNumberFormat.quantity(calculation.rawQuantity)) roh → \(NexusNumberFormat.quantity(calculation.effectiveQuantity)) effektiv bei ME \(calculation.materialEfficiency) %, Ersparnis \(NexusNumberFormat.quantity(calculation.savedQuantity))"
                        )
                    }
                    if let recipe = node.recipe {
                        Text(
                            "\(recipe.activity == .reaction ? "Formel" : "Blueprint") \(recipe.blueprintTypeID), \(activityName(recipe.activity)), Ausgabe \(NexusNumberFormat.quantity(recipe.outputQuantityPerRun)), Basiszeit \(NexusNumberFormat.quantity(recipe.timeSeconds)) s"
                        )
                        if let efficiency = recipe.materialEfficiency {
                            Text(
                                "Stufen-ME \(efficiency) % (\(efficiencySourceName(recipe.materialEfficiencySource)))"
                            )
                        }
                        if let techLevel = recipe.techLevel,
                           let quality =
                            recipe.blueprintPlanningQuality {
                            Text(
                                "\(techLevelName(techLevel)), \(blueprintOriginName(quality.origin)), TE \(quality.timeEfficiency.map(String.init) ?? "—"), Runs/Kopie \(quality.licensedRunsPerCopy.map { NexusNumberFormat.quantity($0) } ?? "unbegrenzt/unspezifiziert")"
                            )
                        }
                        if let invention = recipe.invention {
                            Text(
                                "Invention aus Blueprint \(invention.sourceBlueprintTypeID), Basis \(NexusNumberFormat.quantity(invention.baseLicensedRuns)) Runs bei \(NexusNumberFormat.quantity(invention.baseProbabilityMillionths)) ppm; \(NexusNumberFormat.quantity(invention.requiredSuccessfulCopies)) erfolgreiche Kopie(n) geplant"
                            )
                        }
                        if let kind = recipe.reactionKind,
                           let reactorTypeID =
                            recipe.requiredReactorTypeID,
                           let context = recipe.reactionContext,
                           let time = recipe.reactionTimeCalculation {
                            Text(
                                "\(reactionKindName(kind)), Reactor \(reactorTypeID), Kontext \(reactionContextName(context)), Skill \(context.reactionsSkillLevel), effektive Zeit \(NexusNumberFormat.quantity(time.effectiveDurationSeconds)) s"
                            )
                            Text(
                                "Zeitfaktoren Skill \(basisPointPercent(time.skillFactorBasisPoints)), Facility \(basisPointPercent(time.facilityFactorBasisPoints)), Rig \(basisPointPercent(time.rigFactorBasisPoints)); Regel v\(context.ruleVersion), SDE \(context.catalogBuildNumber)"
                            )
                        }
                        if let decryptor = recipe
                            .blueprintPlanningQuality?.decryptor,
                           let decryptorTypeID = recipe
                            .blueprintPlanningQuality?.decryptorTypeID {
                            Text(
                                "Decryptor \(decryptorName(decryptor)), Type-ID \(decryptorTypeID)"
                            )
                        }
                    }
                    if let calculation = node.runCalculation {
                        Text(
                            "\(NexusNumberFormat.quantity(calculation.requiredRuns)) Runs → \(NexusNumberFormat.quantity(calculation.producedOutputQuantity)) Ausgabe, \(NexusNumberFormat.quantity(calculation.surplusOutputQuantity)) Überschuss"
                        )
                    }
                    if let reason = node.leafReason {
                        Text(leafReasonName(reason))
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }

    private var role: String {
        switch node.kind {
        case .target:
            "Zielprodukt"
        case .intermediate:
            "Zwischenprodukt"
        case .material:
            "Material"
        }
    }

    private var symbol: String {
        switch node.kind {
        case .target:
            "scope"
        case .intermediate:
            "gearshape.2"
        case .material:
            "cube"
        }
    }

    private var color: Color {
        node.kind == .target ? NexusTheme.accent : .secondary
    }

    private func activityName(
        _ activity: ProductionTargetActivity
    ) -> String {
        switch activity {
        case .manufacturing:
            "Fertigung"
        case .reaction:
            "Reaktion"
        }
    }

    private func efficiencySourceName(
        _ source: ProductionGraphMaterialEfficiencySource?
    ) -> String {
        switch source {
        case .projectBlueprint:
            "Projekt-Blueprint"
        case .neutralIntermediate:
            "neutraler Zwischenproduktwert"
        case .regularT2Invention:
            "reguläre T2-Invention ohne Decryptor"
        case .t2StageOverride:
            "T2-Stufenüberschreibung"
        case .reactionFormula:
            "Reaktionsformel – ME/TE nicht anwendbar"
        case nil:
            "älteres Graphformat"
        }
    }

    private func techLevelName(_ level: IndustryTechLevel) -> String {
        switch level {
        case .techI:
            "Tech I"
        case .techII:
            "Tech II"
        }
    }

    private func blueprintOriginName(
        _ origin: BlueprintPlanningOrigin
    ) -> String {
        switch origin {
        case .researchedBPO:
            "erforschte BPO"
        case .copiedFromBPO:
            "BPC aus BPO"
        case .inventedBPC:
            "erfundene BPC"
        case .legacyT2BPO:
            "historische T2-BPO"
        case .manualPlanningAssumption:
            "manuelle Planungsannahme"
        }
    }

    private func decryptorName(
        _ decryptor: InventionDecryptor
    ) -> String {
        switch decryptor {
        case .accelerant:
            "Accelerant"
        case .attainment:
            "Attainment"
        case .augmentation:
            "Augmentation"
        case .parity:
            "Parity"
        case .process:
            "Process"
        case .symmetry:
            "Symmetry"
        case .optimizedAttainment:
            "Optimized Attainment"
        case .optimizedAugmentation:
            "Optimized Augmentation"
        }
    }

    private func leafReasonName(
        _ reason: ProductionGraphLeafReason
    ) -> String {
        switch reason {
        case .noManufacturingRecipe:
            "Endmaterial: kein Herstellungsrezept"
        case .noProductionRecipe:
            "Endmaterial: kein Fertigungs- oder Reaktionsrezept"
        case .reactionDeferred:
            "Legacy-Endmaterial: Reaktion war zurückgestellt; Graph neu erzeugen"
        }
    }

    private func reactionKindName(_ kind: ReactionKind) -> String {
        switch kind {
        case .composite:
            "Composite-Reaktion"
        case .hybrid:
            "Hybrid-Reaktion"
        case .biochemical:
            "Biochemical-Reaktion"
        }
    }

    private func reactionContextName(
        _ context: ReactionPlanningContext
    ) -> String {
        switch context.mode {
        case .neutralBase:
            return "neutrales Basisszenario"
        case .modified:
            let security = context.securityBand == .lowSecurity
                ? "Lowsec"
                : "Nullsec/Wurmloch"
            return "modifiziert (\(security))"
        }
    }

    private func basisPointPercent(_ value: Int64) -> String {
        let percent = Double(value) / 100
        return percent.formatted(
            .number.precision(.fractionLength(0...2))
        ) + " %"
    }
}
