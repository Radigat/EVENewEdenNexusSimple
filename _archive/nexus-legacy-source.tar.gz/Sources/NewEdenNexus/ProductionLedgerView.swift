import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct ProductionLedgerView: View {
    @ObservedObject var model: ProductionLedgerViewModel
    @State private var showingEditor = false
    @State private var showingConfirmation = false
    @State private var showingCostEditor = false
    @State private var showingCostConfirmation = false
    @State private var showingSaleEditor = false
    @State private var showingSaleConfirmation = false

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            filters
            Divider()
            if model.batches.isEmpty {
                ContentUnavailableView {
                    Label(
                        "Noch keine Produktionschargen",
                        systemImage: "list.number"
                    )
                } description: {
                    Text(
                        "Erfasse eine tatsächlich geplante oder produzierte Charge aus einem bestehenden Projekt."
                    )
                } actions: {
                    Button("Charge erfassen") {
                        showingEditor = true
                    }
                }
            } else {
                HSplitView {
                    batchTable
                        .frame(minWidth: 600)
                    detail
                        .frame(minWidth: 320, idealWidth: 390)
                }
            }
        }
        .task { await model.load() }
        .sheet(isPresented: $showingEditor) {
            editor
                .frame(minWidth: 720, minHeight: 680)
        }
        .sheet(isPresented: $showingCostEditor) {
            costEditor
                .frame(minWidth: 900, minHeight: 760)
        }
        .sheet(isPresented: $showingSaleEditor) {
            saleEditor
                .frame(minWidth: 900, minHeight: 760)
        }
        .alert(
            "Produktionsbuch",
            isPresented: Binding(
                get: {
                    model.errorMessage != nil
                        || model.successMessage != nil
                },
                set: { visible in
                    if !visible {
                        model.clearMessages()
                    }
                }
            )
        ) {
            Button("OK") { model.clearMessages() }
        } message: {
            Text(model.errorMessage ?? model.successMessage ?? "")
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Produktionsbuch")
                    .font(.largeTitle.bold())
                Text(
                    "Tatsächliche Produktionschargen – getrennt von veränderbaren Planwerten."
                )
                .foregroundStyle(.secondary)
            }
            Spacer()
            if model.isWorking {
                ProgressView()
                    .controlSize(.small)
            }
            Button {
                showingEditor = true
            } label: {
                Label("Charge erfassen", systemImage: "plus")
            }
            .keyboardShortcut("n", modifiers: [.command, .shift])
            .accessibilityIdentifier(
                "productionLedger.createBatch"
            )
        }
        .padding()
    }

    private var filters: some View {
        VStack(spacing: 8) {
            HStack {
                Picker("Jahr", selection: $model.yearFilter) {
                    Text("Alle Jahre").tag(Int?.none)
                    ForEach(model.availableYears, id: \.self) {
                        Text(String($0)).tag(Int?.some($0))
                    }
                }
                .frame(width: 150)
                Picker("Status", selection: $model.statusFilter) {
                    Text("Alle Status").tag(ProductionBatchStatus?.none)
                    ForEach(ProductionBatchStatus.allCases, id: \.self) {
                        Text($0.localizedName)
                            .tag(ProductionBatchStatus?.some($0))
                    }
                }
                .frame(width: 180)
                Picker("Projekt", selection: $model.projectFilter) {
                    Text("Alle Projekte").tag(UUID?.none)
                    ForEach(model.projects) {
                        Text($0.name).tag(UUID?.some($0.id))
                    }
                }
                .frame(minWidth: 220)
                Picker("Charakter", selection: $model.characterFilter) {
                    Text("Alle Charaktere").tag(Int64?.none)
                    ForEach(model.availableCharacters, id: \.id) {
                        Text($0.name).tag(Int64?.some($0.id))
                    }
                }
                .frame(minWidth: 220)
            }
            HStack {
                TextField("Produkt suchen", text: $model.productFilter)
                TextField("Ort suchen", text: $model.locationFilter)
                Button("Filtern") {
                    Task { await model.reloadForFilters() }
                }
                .accessibilityHint(
                    "Wendet Jahr, Status, Projekt, Charakter, Produkt und Ort auf das Produktionsbuch an."
                )
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
    }

    private var batchTable: some View {
        Table(
            model.batches,
            selection: Binding(
                get: { model.selectedBatchID },
                set: { value in
                    Task { await model.selectBatch(value) }
                }
            )
        ) {
            TableColumn("Nummer") {
                Text($0.displayNumber)
                    .monospacedDigit()
            }
            TableColumn("Datum") {
                Text($0.productionDate, format: .dateTime.day().month().year())
            }
            TableColumn("Produkt") {
                Text($0.productName)
            }
            TableColumn("Einheiten") {
                Text($0.outputUnits, format: .number.grouping(.automatic))
                    .monospacedDigit()
            }
            TableColumn("Status") {
                Text($0.status.localizedName)
            }
            TableColumn("System") {
                Text(
                    optionalLocationName(
                        name: $0.solarSystemName,
                        id: $0.solarSystemID
                    )
                )
                    .foregroundStyle(
                        $0.solarSystemName == nil
                            ? .secondary
                            : .primary
                    )
            }
        }
        .accessibilityLabel("Gespeicherte Produktionschargen")
    }

    @ViewBuilder
    private var detail: some View {
        if let batch = model.selectedBatch {
            Form {
                Section("Charge") {
                    LabeledContent("Nummer", value: batch.displayNumber)
                    LabeledContent("Projekt", value: batch.projectName)
                    LabeledContent("Produkt", value: batch.productName)
                    LabeledContent(
                        "Aktivität",
                        value: batch.activity.localizedName
                    )
                    LabeledContent(
                        "Status",
                        value: batch.status.localizedName
                    )
                }
                Section("Produktion") {
                    LabeledContent(
                        "Runs",
                        value: batch.runs.formatted(
                            .number.grouping(.automatic)
                        )
                    )
                    LabeledContent(
                        "ME / TE",
                        value:
                            "\(batch.materialEfficiency) / \(batch.timeEfficiency)"
                    )
                    LabeledContent(
                        "Ausgabemenge",
                        value: batch.outputUnits.formatted(
                            .number.grouping(.automatic)
                        )
                    )
                }
                Section("Ort") {
                    LabeledContent(
                        "Sonnensystem",
                        value: optionalLocationName(
                            name: batch.solarSystemName,
                            id: batch.solarSystemID
                        )
                    )
                    LabeledContent(
                        "Station oder Struktur",
                        value: optionalLocationName(
                            name: batch.locationName,
                            id: batch.locationID
                        )
                    )
                    LabeledContent(
                        "Anlage",
                        value: optionalLocationName(
                            name: batch.facilityName,
                            id: batch.facilityID
                        )
                    )
                }
                Section("Nachweis") {
                    LabeledContent(
                        "SDE-Build",
                        value: batch.catalogBuildNumber.formatted(
                            .number.grouping(.automatic)
                        )
                    )
                    LabeledContent(
                        "Graphformat",
                        value: String(batch.graphFormatVersion)
                    )
                    if let jobID = batch.esiIndustryJobID {
                        LabeledContent(
                            "ESI-Industry-Job",
                            value: jobID.formatted(
                                .number.grouping(.automatic)
                            )
                        )
                    }
                }
                Section("Kosten und Preisvorschläge") {
                    if let cost = model.latestCostSnapshot {
                        LabeledContent(
                            "Kostenbasis",
                            value: cost.createdAt.formatted(
                                date: .abbreviated,
                                time: .shortened
                            )
                        )
                        LabeledContent(
                            "Gesamtkosten",
                            value: isk(
                                cost.calculation.totalCost
                            )
                        )
                        LabeledContent(
                            "Kosten je Unit",
                            value: isk(
                                cost.calculation.unitCost
                            )
                        )
                        LabeledContent(
                            "Vorschlag +5 %",
                            value: isk(
                                cost.calculation
                                    .suggestionFivePercent
                            )
                        )
                        LabeledContent(
                            "Vorschlag +10 %",
                            value: isk(
                                cost.calculation
                                    .suggestionTenPercent
                            )
                        )
                    } else {
                        Text("Noch keine bestätigte Kostenbasis")
                            .foregroundStyle(.secondary)
                    }
                    Button("Kostenbasis und Marktpreise prüfen") {
                        showingCostEditor = true
                        Task { await model.prepareCostEditor() }
                    }
                    .accessibilityIdentifier(
                        "productionLedger.openCostEditor"
                    )
                }
                Section("Verkäufe und Realgewinn") {
                    if let summary = model.saleWorkspace?.summary,
                        summary.allocationCount > 0
                    {
                        LabeledContent(
                            "Verkauft / offen",
                            value:
                                "\(NexusNumberFormat.quantity(summary.soldUnits)) / \(NexusNumberFormat.quantity(summary.openUnits)) Units"
                        )
                        LabeledContent(
                            "Realer Bruttoerlös",
                            value: isk(summary.grossRevenue)
                        )
                        LabeledContent(
                            "Verkaufsgebühren",
                            value: isk(summary.sellingFees)
                        )
                        LabeledContent(
                            "Realisierte Kosten",
                            value: isk(summary.realizedCost)
                        )
                        LabeledContent(
                            "Realgewinn",
                            value: isk(summary.realizedProfit)
                        )
                        LabeledContent(
                            "Ø Verkaufspreis je Unit",
                            value: isk(summary.averageSaleUnitPrice)
                        )
                        LabeledContent(
                            "Reale Marge / ROI",
                            value:
                                "\(percentage(summary.margin)) / \(percentage(summary.roi))"
                        )
                    } else {
                        Text(
                            "Noch keine bestätigte Verkaufs- oder Gebührenzuordnung"
                        )
                        .foregroundStyle(.secondary)
                    }
                    Button("Verkäufe und Realgewinn prüfen") {
                        showingSaleEditor = true
                        Task { await model.prepareSaleEditor() }
                    }
                    .disabled(model.latestCostSnapshot == nil)
                    .accessibilityIdentifier(
                        "productionLedger.openSaleEditor"
                    )
                }
            }
            .formStyle(.grouped)
        } else {
            ContentUnavailableView(
                "Keine Charge ausgewählt",
                systemImage: "sidebar.right"
            )
        }
    }

    private var editor: some View {
        NavigationStack {
            Form {
                Section("Grundlage") {
                    Picker(
                        "Produktionsprojekt",
                        selection: Binding(
                            get: { model.form.projectID },
                            set: { model.selectProject($0) }
                        )
                    ) {
                        Text("Projekt wählen").tag(UUID?.none)
                        ForEach(model.projects) {
                            Text("\($0.name) · \($0.productName)")
                                .tag(UUID?.some($0.id))
                        }
                    }
                    Text(
                        "ME und Ausgabemenge werden aus dem Projekt vorbelegt. Prüfe nur, was für diese Charge abweicht."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    if !model.jobs.isEmpty {
                        DisclosureGroup(
                            "Optional: ESI-Industry-Job übernehmen"
                        ) {
                            Picker(
                                "Vorhandener ESI-Job",
                                selection: $model.selectedJobID
                            ) {
                                Text("Kein ESI-Job").tag(Int64?.none)
                                ForEach(model.jobs) {
                                    Text($0.label)
                                        .tag(Int64?.some($0.id))
                                }
                            }
                            Button("ESI-Werte übernehmen") {
                                Task { await model.preloadSelectedJob() }
                            }
                            .disabled(
                                model.selectedJobID == nil
                                    || model.form.projectID == nil
                            )
                        }
                    }
                }
                Section("Charge") {
                    DatePicker(
                        "Produktionsdatum",
                        selection: $model.form.productionDate
                    )
                    Picker("Status", selection: $model.form.status) {
                        ForEach(
                            ProductionBatchStatus.allCases,
                            id: \.self
                        ) {
                            Text($0.localizedName).tag($0)
                        }
                    }
                    LabeledContent("Runs") {
                        TextField("Runs", text: $model.form.runs)
                            .frame(maxWidth: 220)
                    }
                    LabeledContent("Materialeffizienz (ME)") {
                        TextField(
                            "ME",
                            text: $model.form.materialEfficiency
                        )
                        .frame(maxWidth: 220)
                    }
                    LabeledContent("Zeiteffizienz (TE)") {
                        TextField(
                            "TE",
                            text: $model.form.timeEfficiency
                        )
                        .frame(maxWidth: 220)
                    }
                    LabeledContent("Ausgabemenge") {
                        TextField(
                            "Ausgabemenge",
                            text: $model.form.outputUnits
                        )
                        .frame(maxWidth: 220)
                    }
                }
                Section("Optionaler Produktionsort") {
                    Text(
                        "Für die Planung nicht erforderlich. Trage Namen nur ein, wenn du den tatsächlichen Produktionsort festhalten möchtest."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    TextField(
                        "Sonnensystem",
                        text: $model.form.solarSystemName
                    )
                    TextField(
                        "Station oder Struktur",
                        text: $model.form.locationName
                    )
                    TextField(
                        "Anlage",
                        text: $model.form.facilityName
                    )
                }
                Section {
                    DisclosureGroup("Erweiterte technische Zuordnung") {
                        Text(
                            "Diese Angaben sind optional und vor allem für ESI-Nachweise oder eine spätere technische Zuordnung gedacht."
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        TextField(
                            "Sonnensystem-ID",
                            text: $model.form.solarSystemID
                        )
                        TextField(
                            "Stations-/Struktur-ID",
                            text: $model.form.locationID
                        )
                        TextField(
                            "Anlagen-ID",
                            text: $model.form.facilityID
                        )
                        TextField(
                            "Charaktername",
                            text: $model.form.characterName
                        )
                        TextField(
                            "Charakter-ID",
                            text: $model.form.characterID
                        )
                        TextField(
                            "Blueprint-Instanz-ID",
                            text: $model.form.blueprintInstanceID
                        )
                    }
                }
                if let preview = model.preview {
                    Section("Zusammenfassung") {
                        LabeledContent(
                            "Projekt",
                            value: preview.request.projectName
                        )
                        LabeledContent(
                            "Produkt",
                            value: preview.request.productName
                        )
                        LabeledContent(
                            "Runs",
                            value: preview.request.runs.formatted(
                                .number.grouping(.automatic)
                            )
                        )
                        LabeledContent(
                            "Ausgabemenge",
                            value: preview.request.outputUnits.formatted(
                                .number.grouping(.automatic)
                            )
                        )
                        if !preview.missingFields.isEmpty {
                            Label(
                                missingText(preview),
                                systemImage: "info.circle"
                            )
                            .foregroundStyle(.secondary)
                        }
                        HStack {
                            Button("Vorschau verwerfen") {
                                model.discardPreview()
                            }
                            Spacer()
                            Button("Verbindlich übernehmen") {
                                showingConfirmation = true
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Produktionscharge erfassen")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        model.discardPreview()
                        showingEditor = false
                    }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button("Vorschau erzeugen") {
                        Task { await model.createPreview() }
                    }
                    .disabled(!model.canCreatePreview || model.isWorking)
                    .accessibilityIdentifier(
                        "productionLedger.createPreview"
                    )
                }
            }
            .confirmationDialog(
                "Produktionscharge verbindlich speichern?",
                isPresented: $showingConfirmation
            ) {
                Button("Charge speichern") {
                    Task {
                        await model.applyPreview()
                        if model.errorMessage == nil {
                            showingEditor = false
                        }
                    }
                }
                .accessibilityIdentifier(
                    "productionLedger.confirmBatch"
                )
                Button("Abbrechen", role: .cancel) {}
            } message: {
                Text(
                    "Projekt-, Graph-, Regel- und SDE-Stand werden unveränderlich an diese Charge gebunden. Nicht angegebene Orts- und Zuordnungsdaten bleiben leer."
                )
            }
        }
    }

    private var costEditor: some View {
        NavigationStack {
            Form {
                Section("Charge") {
                    if let batch = model.selectedBatch {
                        LabeledContent(
                            "Charge",
                            value:
                                "\(batch.displayNumber) · \(batch.productName)"
                        )
                        LabeledContent(
                            "Ausgabemenge",
                            value: batch.outputUnits.formatted(
                                .number.grouping(.automatic)
                            )
                        )
                    }
                }
                Section("Kostenbasis") {
                    Picker(
                        "Preissatz für Material und Fallback",
                        selection: $model.costForm.priceProfileID
                    ) {
                        Text("Kein Preissatz")
                            .tag(Optional<UUID>.none)
                        ForEach(model.priceProfiles) {
                            Text($0.name).tag(Optional($0.id))
                        }
                    }
                    TextField(
                        "Facility, SCC und Produktionssteuer in ISK",
                        text: $model.costForm.facilityAndTaxCost
                    )
                    TextField(
                        "BPO/BPC, Kopie, Invention und Decryptor in ISK",
                        text:
                            $model.costForm.blueprintAndInventionCost
                    )
                    TextField(
                        "Broker- und Transaktionsgebühren in ISK",
                        text: $model.costForm.marketFees
                    )
                    TextField(
                        "Sonstige Kosten in ISK",
                        text: $model.costForm.manualOtherCost
                    )
                    Text(
                        "Leere Felder bleiben unbekannt und blockieren die Speicherung. Trage 0 nur ein, wenn die Kostenart ausdrücklich nicht anfällt. Material, Logistik und Produktionskosten stammen aus dem gespeicherten Projektbudget."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                Section("Marktvergleich") {
                    LabeledContent(
                        "Standardmarkt",
                        value:
                            "Jita IV - Moon 4 - Caldari Navy Assembly Plant"
                    )
                    Picker(
                        "Alternative Region",
                        selection: Binding(
                            get: {
                                model.costForm.alternativeRegionID
                            },
                            set: {
                                model.selectAlternativeRegion($0)
                            }
                        )
                    ) {
                        Text("Keine Alternative")
                            .tag(Optional<Int64>.none)
                        ForEach(model.marketRegions) {
                            Text($0.name).tag(Optional($0.regionID))
                        }
                    }
                    Picker(
                        "Alternativer Marktstandort",
                        selection: Binding(
                            get: {
                                model.costForm.alternativeLocationID
                            },
                            set: {
                                model.selectAlternativeLocation($0)
                            }
                        )
                    ) {
                        Text("Gesamte Region")
                            .tag(Optional<Int64>.none)
                        ForEach(model.alternativeLocations) {
                            Text($0.name).tag(Optional($0.locationID))
                        }
                    }
                    Picker(
                        "Verkaufspreis für Prognose",
                        selection: $model.costForm.selectedSaleQuote
                    ) {
                        ForEach(
                            ProductionBatchSaleQuoteSelection.allCases,
                            id: \.self
                        ) {
                            Text($0.localizedName).tag($0)
                        }
                    }
                    Toggle(
                        "Gewählten Preissatz ausdrücklich als Fallback erlauben",
                        isOn:
                            $model.costForm
                            .allowManualPriceSetFallback
                    )
                }
                if let preview = model.costPreview {
                    Section("Schreibfreie Vorschau") {
                        ForEach(preview.snapshot.costLines) { line in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(line.label)
                                    if let warning = line.warnings.first {
                                        Text(warning)
                                            .font(.caption)
                                            .foregroundStyle(.orange)
                                    }
                                }
                                Spacer()
                                Text(
                                    line.amount.map {
                                        NexusNumberFormat.isk(
                                            hundredths: $0.hundredths
                                        )
                                    } ?? "unbekannt"
                                )
                                .monospacedDigit()
                            }
                        }
                        quoteRow(
                            "Jita Sell-Quote",
                            preview.snapshot.jitaQuote
                        )
                        quoteRow(
                            "Alternativmarkt Sell-Quote",
                            preview.snapshot.alternativeQuote
                        )
                        Divider()
                        metricRow(
                            "Gesamtkosten",
                            preview.snapshot.calculation.totalCost
                        )
                        metricRow(
                            "Kosten je Unit / Break-even",
                            preview.snapshot.calculation.unitCost
                        )
                        metricRow(
                            "Preisvorschlag +5 %",
                            preview.snapshot.calculation
                                .suggestionFivePercent
                        )
                        metricRow(
                            "Preisvorschlag +10 %",
                            preview.snapshot.calculation
                                .suggestionTenPercent
                        )
                        metricRow(
                            "Prognoseerlös",
                            preview.snapshot.calculation.forecastRevenue
                        )
                        metricRow(
                            "Prognosegewinn",
                            preview.snapshot.calculation.forecastProfit
                        )
                        percentageRow(
                            "Marge",
                            preview.snapshot.calculation.margin
                        )
                        percentageRow(
                            "ROI",
                            preview.snapshot.calculation.roi
                        )
                        if !preview.warnings.isEmpty {
                            ForEach(preview.warnings, id: \.self) {
                                Label(
                                    $0,
                                    systemImage:
                                        "exclamationmark.triangle"
                                )
                                .foregroundStyle(.orange)
                            }
                        }
                        HStack {
                            Button("Vorschau verwerfen") {
                                model.discardCostPreview()
                            }
                            Spacer()
                            Button("Kostenbasis speichern") {
                                showingCostConfirmation = true
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(!preview.isComplete)
                            .accessibilityIdentifier(
                                "productionLedger.confirmCostBasis"
                            )
                        }
                    }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Produktionskosten und Preisvorschläge")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        model.discardCostPreview()
                        showingCostEditor = false
                    }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button("Vorschau berechnen") {
                        Task { await model.createCostPreview() }
                    }
                    .disabled(model.isWorking)
                    .accessibilityIdentifier(
                        "productionLedger.createCostPreview"
                    )
                }
            }
            .confirmationDialog(
                "Kostenbasis verbindlich speichern?",
                isPresented: $showingCostConfirmation,
                titleVisibility: .visible
            ) {
                Button("Kostenbasis speichern") {
                    Task {
                        await model.applyCostPreview()
                        if model.errorMessage == nil {
                            showingCostEditor = false
                        }
                    }
                }
                Button("Abbrechen", role: .cancel) {}
            } message: {
                Text(
                    "Die bestätigte Kostenbasis und ihre Marktquotes bleiben als historischer Snapshot unverändert."
                )
            }
        }
    }

    private var saleEditor: some View {
        NavigationStack {
            Form {
                Section("Charge und Kostenbindung") {
                    if let workspace = model.saleWorkspace {
                        LabeledContent(
                            "Charge",
                            value:
                                "\(workspace.batch.displayNumber) · \(workspace.batch.productName)"
                        )
                        LabeledContent(
                            "Ausgabemenge",
                            value:
                                "\(NexusNumberFormat.quantity(workspace.batch.outputUnits)) Units"
                        )
                        LabeledContent(
                            "Unveränderliche Kostenbasis",
                            value: workspace.costSnapshot.map {
                                $0.createdAt.formatted(
                                    date: .abbreviated,
                                    time: .shortened
                                )
                            } ?? "nicht verfügbar"
                        )
                    } else {
                        ProgressView("Nachweise werden geladen")
                    }
                }

                if let workspace = model.saleWorkspace {
                    Section("Neuen Nachweis zuordnen") {
                        Picker(
                            "Nachweisart",
                            selection: Binding(
                                get: { model.saleForm.source },
                                set: { model.selectSaleSource($0) }
                            )
                        ) {
                            ForEach(
                                ProductionSaleSourceChoice.allCases,
                                id: \.self
                            ) {
                                Text($0.localizedName).tag($0)
                            }
                        }
                        .pickerStyle(.segmented)

                        switch model.saleForm.source {
                        case .walletTransaction:
                            if workspace.transactions.isEmpty {
                                walletEmptyState(
                                    "Keine bestätigte, noch verfügbare Wallet-Verkaufszuordnung für dieses Produkt."
                                )
                            } else {
                                Picker(
                                    "Wallet-Verkauf",
                                    selection:
                                        $model.saleForm
                                        .transactionAssignmentID
                                ) {
                                    Text("Nachweis wählen")
                                        .tag(Optional<UUID>.none)
                                    ForEach(workspace.transactions) {
                                        Text(transactionLabel($0))
                                            .tag(Optional($0.id))
                                    }
                                }
                                TextField(
                                    "Zuzuordnende Verkaufsmenge",
                                    text: $model.saleForm.quantity
                                )
                            }
                        case .walletJournal:
                            if workspace.journals.isEmpty {
                                walletEmptyState(
                                    "Keine bestätigte, noch verfügbare Wallet-Gebührenzuordnung für dieses Projekt."
                                )
                            } else {
                                Picker(
                                    "Wallet-Gebühr",
                                    selection:
                                        $model.saleForm
                                        .journalAssignmentID
                                ) {
                                    Text("Nachweis wählen")
                                        .tag(Optional<UUID>.none)
                                    ForEach(workspace.journals) {
                                        Text(journalLabel($0))
                                            .tag(Optional($0.id))
                                    }
                                }
                                TextField(
                                    "Zuzuordnender Gebührenbetrag in ISK",
                                    text: $model.saleForm.amount
                                )
                            }
                        case .manualSale:
                            TextField(
                                "Verkaufsmenge",
                                text: $model.saleForm.quantity
                            )
                            TextField(
                                "Gesamter Verkaufserlös in ISK",
                                text: $model.saleForm.amount
                            )
                            manualEvidenceFields
                        case .manualFee:
                            TextField(
                                "Gesamte Verkaufsgebühr in ISK",
                                text: $model.saleForm.amount
                            )
                            manualEvidenceFields
                        }

                        Text(
                            "Manuelle Angaben sind nur für nachvollziehbare Alt- oder Fremdnachweise vorgesehen. Aktuelle Marktquotes und offene eigene Marktorders gelten nicht als realisierter Erlös."
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }

                    if !workspace.allocations.isEmpty {
                        Section("Gespeicherte Zuordnungen") {
                            ForEach(workspace.allocations) {
                                allocationRow($0)
                            }
                        }
                    }

                    if let summary = workspace.summary,
                        summary.allocationCount > 0
                    {
                        Section("Bisher realisiert") {
                            realizedSummary(summary)
                        }
                    }
                }

                if let preview = model.salePreview {
                    Section("Schreibfreie Vorschau") {
                        LabeledContent(
                            "Nachweis",
                            value:
                                "\(preview.allocation.source.localizedName) · \(preview.allocation.kind.localizedName)"
                        )
                        LabeledContent(
                            "Menge",
                            value:
                                "\(NexusNumberFormat.quantity(preview.allocation.quantity)) Units"
                        )
                        LabeledContent(
                            "Betrag",
                            value: NexusNumberFormat.isk(
                                hundredths:
                                    preview.allocation.amountHundredths
                            )
                        )
                        realizedSummary(preview.summaryAfter)
                        if let remaining =
                            preview.sourceRemainingQuantity
                        {
                            LabeledContent(
                                "Danach im Nachweis verfügbar",
                                value:
                                    "\(NexusNumberFormat.quantity(remaining)) Units"
                            )
                        }
                        if let remaining =
                            preview.sourceRemainingAmountHundredths
                        {
                            LabeledContent(
                                "Danach im Nachweis verfügbar",
                                value: NexusNumberFormat.isk(
                                    hundredths: remaining
                                )
                            )
                        }
                        HStack {
                            Button("Vorschau verwerfen") {
                                Task {
                                    await model.discardSalePreview()
                                }
                            }
                            Spacer()
                            Button("Zuordnung speichern") {
                                showingSaleConfirmation = true
                            }
                            .buttonStyle(.borderedProminent)
                            .accessibilityIdentifier(
                                "productionLedger.confirmSaleAllocation"
                            )
                        }
                    }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Verkäufe und Realgewinn")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        Task {
                            await model.discardSalePreview()
                            showingSaleEditor = false
                        }
                    }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button("Vorschau erzeugen") {
                        Task { await model.createSalePreview() }
                    }
                    .disabled(model.isWorking)
                    .accessibilityIdentifier(
                        "productionLedger.createSalePreview"
                    )
                }
            }
            .confirmationDialog(
                "Zuordnung verbindlich speichern?",
                isPresented: $showingSaleConfirmation,
                titleVisibility: .visible
            ) {
                Button("Zuordnung speichern") {
                    Task {
                        await model.applySalePreview()
                        if model.errorMessage == nil {
                            showingSaleEditor = false
                        }
                    }
                }
                Button("Abbrechen", role: .cancel) {}
            } message: {
                Text(
                    "Der Nachweis wird einmalig an diese Charge und ihre unveränderliche Kostenbasis gebunden. Eine spätere Marktquote verändert den Realgewinn nicht."
                )
            }
        }
    }

    @ViewBuilder
    private var manualEvidenceFields: some View {
        DatePicker(
            "Nachweisdatum",
            selection: $model.saleForm.date,
            in: ...Date()
        )
        TextField(
            "Begründung oder Belegreferenz",
            text: $model.saleForm.reason
        )
    }

    private func walletEmptyState(_ message: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Label(message, systemImage: "wallet.pass")
                .foregroundStyle(.secondary)
            Text(
                "Ordne den Wallet-Umsatz zuerst schreibgeschützt einem Projekt zu und bestätige diese Zuordnung. Ein erneuter ESI-Abruf ist hier nicht erforderlich."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private func transactionLabel(
        _ option: ProductionBatchTransactionEvidence
    ) -> String {
        let amount = option.transaction.unitPriceHundredths
            .multipliedReportingOverflow(
                by: option.remainingQuantity
            )
        let availableAmount = amount.overflow
            ? option.remainingAmountHundredths
            : min(
                amount.partialValue,
                option.remainingAmountHundredths
            )
        return
            "\(option.transaction.date.formatted(date: .abbreviated, time: .shortened)) · \(NexusNumberFormat.quantity(option.remainingQuantity)) Units · \(NexusNumberFormat.isk(hundredths: availableAmount))"
    }

    private func journalLabel(
        _ option: ProductionBatchJournalEvidence
    ) -> String {
        "\(option.entry.date.formatted(date: .abbreviated, time: .shortened)) · \(option.entry.refType.localizedWalletFeeName) · \(NexusNumberFormat.isk(hundredths: option.remainingAmountHundredths))"
    }

    private func allocationRow(
        _ allocation: ProductionBatchSaleAllocationSnapshot
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(
                    "\(allocation.kind.localizedName) · \(allocation.source.localizedName)"
                )
                Spacer()
                Text(
                    NexusNumberFormat.isk(
                        hundredths: allocation.amountHundredths
                    )
                )
                .monospacedDigit()
            }
            Text(
                "\(allocation.sourceObservedAt.formatted(date: .abbreviated, time: .shortened))"
                    + (allocation.kind == .sale
                        ? " · \(NexusNumberFormat.quantity(allocation.quantity)) Units"
                        : "")
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            if let reason = allocation.reason {
                Text(reason)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func realizedSummary(
        _ summary: ProductionBatchRealizedSummary
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            LabeledContent(
                "Verkauft / offen",
                value:
                    "\(NexusNumberFormat.quantity(summary.soldUnits)) / \(NexusNumberFormat.quantity(summary.openUnits)) Units"
            )
            LabeledContent(
                "Bruttoerlös",
                value: isk(summary.grossRevenue)
            )
            LabeledContent(
                "Gebühren",
                value: isk(summary.sellingFees)
            )
            LabeledContent(
                "Realisierte Kosten",
                value: isk(summary.realizedCost)
            )
            LabeledContent(
                "Realgewinn",
                value: isk(summary.realizedProfit)
            )
            LabeledContent(
                "Ø Verkaufspreis je Unit",
                value: isk(summary.averageSaleUnitPrice)
            )
            LabeledContent(
                "Marge / ROI",
                value:
                    "\(percentage(summary.margin)) / \(percentage(summary.roi))"
            )
        }
    }

    private func quoteRow(
        _ label: String,
        _ quote: PriceQuoteBinding?
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(label)
                Spacer()
                Text(
                    quote?.unitPrice.map {
                        NexusNumberFormat.isk(
                            hundredths: $0.hundredths
                        )
                    } ?? "nicht verfügbar"
                )
                .monospacedDigit()
            }
            if let quote {
                Text(
                    "\(quote.locationName ?? quote.regionName ?? "Markt nicht benannt") · \(quote.fallback.localizedName)"
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                Text(
                    "Beobachtet \(quote.observedAt.formatted(date: .abbreviated, time: .shortened)) · \(NexusNumberFormat.quantity(quote.fulfilledQuantity))/\(NexusNumberFormat.quantity(quote.quantity)) Units · \(NexusNumberFormat.quantity(quote.orderCount)) Orders · Preisregel \(quote.policyVersion)"
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                if let expiresAt = quote.expiresAt {
                    Text(
                        "Cache gültig bis \(expiresAt.formatted(date: .abbreviated, time: .shortened))"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                ForEach(quote.warnings, id: \.self) {
                    Text($0)
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            }
        }
    }

    private func metricRow(
        _ label: String,
        _ value: ISKValue?
    ) -> some View {
        HStack {
            Text(label)
            Spacer()
            Text(isk(value))
                .monospacedDigit()
        }
    }

    private func percentageRow(
        _ label: String,
        _ value: ISKPercentage?
    ) -> some View {
        HStack {
            Text(label)
            Spacer()
            Text(
                value.map {
                    NexusNumberFormat.decimal(
                        Decimal($0.basisPoints) / 100
                    ) + " %"
                } ?? "—"
            )
            .monospacedDigit()
        }
    }

    private func percentage(_ value: ISKPercentage?) -> String {
        value.map {
            NexusNumberFormat.decimal(
                Decimal($0.basisPoints) / 100
            ) + " %"
        } ?? "—"
    }

    private func isk(_ value: ISKValue?) -> String {
        value.map {
            NexusNumberFormat.isk(hundredths: $0.hundredths)
        } ?? "—"
    }

    private func missingText(
        _ preview: ProductionBatchPreview
    ) -> String {
        "Optionale Angaben nicht gesetzt: "
            + preview.missingFields.map(\.localizedName)
            .joined(separator: ", ")
    }

    private func optionalLocationName(
        name: String?,
        id: Int64?
    ) -> String {
        if let name,
           !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return name
        }
        return id == nil ? "Nicht angegeben" : "Name nicht aufgelöst"
    }
}

extension ProductionBatchStatus {
    fileprivate var localizedName: String {
        switch self {
        case .planned: "Geplant"
        case .produced: "Produziert"
        case .forSale: "Zum Verkauf"
        case .completed: "Abgeschlossen"
        case .archived: "Archiviert"
        }
    }
}

extension ProductionTargetActivity {
    fileprivate var localizedName: String {
        switch self {
        case .manufacturing: "Produktion"
        case .reaction: "Reaktion"
        }
    }
}

extension ProductionBatchMissingField {
    fileprivate var localizedName: String {
        switch self {
        case .solarSystem: "Sonnensystem"
        case .solarSystemName: "Sonnensystemname"
        case .locationName: "Stations-/Strukturname"
        case .characterName: "Charaktername"
        }
    }
}

extension ProductionBatchSaleQuoteSelection {
    fileprivate var localizedName: String {
        switch self {
        case .none: "Keinen Marktpreis verwenden"
        case .jita: "Jita Sell-Quote"
        case .alternative: "Alternativmarkt Sell-Quote"
        }
    }
}

extension ProductionPriceQuoteFallback {
    fileprivate var localizedName: String {
        switch self {
        case .none: "Live ESI"
        case .freshCache: "gültiger ESI-Cache"
        case .staleCache: "veralteter ESI-Cache"
        case .manualPriceSet: "ausgewählter manueller/CSV-Preissatz"
        case .unavailable: "nicht verfügbar"
        }
    }
}

extension ProductionSaleSourceChoice {
    fileprivate var localizedName: String {
        switch self {
        case .walletTransaction: "Wallet-Verkauf"
        case .walletJournal: "Wallet-Gebühr"
        case .manualSale: "Manueller Verkauf"
        case .manualFee: "Manuelle Gebühr"
        }
    }
}

extension ProductionBatchSaleEvidenceSource {
    fileprivate var localizedName: String {
        switch self {
        case .walletTransaction: "Wallet-Verkauf"
        case .walletJournal: "Wallet-Journal"
        case .manual: "manueller Nachweis"
        }
    }
}

extension ProductionBatchSaleAllocationKind {
    fileprivate var localizedName: String {
        switch self {
        case .sale: "Verkauf"
        case .fee: "Verkaufsgebühr"
        }
    }
}

extension String {
    fileprivate var localizedWalletFeeName: String {
        switch self {
        case "brokers_fee": "Brokergebühr"
        case "transaction_tax": "Transaktionssteuer"
        default: "Verkaufsgebühr"
        }
    }
}
