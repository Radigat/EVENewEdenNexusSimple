import Foundation
import SwiftUI

enum NexusNumberFormat {
    private static let locale = Locale(identifier: "de_DE")

    static func quantity<T: BinaryInteger>(_ value: T) -> String {
        guard let decimal = Decimal(
            string: String(value),
            locale: Locale(identifier: "en_US_POSIX")
        ) else {
            return String(value)
        }
        return decimal.formatted(
            .number
                .locale(locale)
                .grouping(.automatic)
                .precision(.fractionLength(0))
        )
    }

    static func decimal(_ value: Decimal) -> String {
        value.formatted(
            .number
                .locale(locale)
                .grouping(.automatic)
                .precision(.fractionLength(2))
        )
    }

    static func isk(hundredths: Int64) -> String {
        decimal(Decimal(hundredths) / 100) + " ISK"
    }
}

enum NexusTheme {
    static let accent = Color(nsColor: .controlAccentColor)
    static let teal = Color(nsColor: .systemTeal)
    static let warning = Color(nsColor: .systemOrange)
    static let panel = Color(nsColor: .controlBackgroundColor)
}

struct MetricCard: View {
    let title: String
    let value: String
    let detail: String
    let symbol: String
    var tint: Color = NexusTheme.accent

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: symbol)
                    .foregroundStyle(tint)
                    .accessibilityHidden(true)
                Spacer()
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Text(value).font(.system(size: 28, weight: .semibold, design: .rounded))
            Text(title).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(NexusTheme.panel, in: RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(.separator.opacity(0.45)))
        .accessibilityRepresentation {
            Text("\(title): \(value). \(detail)")
        }
    }
}

struct EmptyModuleView: View {
    let title: String
    let symbol: String
    let explanation: String

    var body: some View {
        ContentUnavailableView(title, systemImage: symbol, description: Text(explanation))
            .navigationTitle(title)
    }
}
