import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftUI

struct ProjectEditorContext: Identifiable {
    let id = UUID()
    let project: ProductionProjectSnapshot?
}

struct ProjectEditorSheet: View {
    private enum FocusField: Hashable {
        case name
        case targetSearch
        case targetQuantity
    }

    @Environment(\.dismiss) private var dismiss
    @ObservedObject var model: ProjectLifecycleViewModel
    @State private var name: String
    @State private var target: ProductionTargetSelection?
    @State private var targetQuantityText: String
    @State private var materialEfficiency: Int
    @State private var priority: Int
    @State private var usesTargetDate: Bool
    @State private var targetDate: Date
    @State private var notes: String
    @State private var isSaving = false
    @State private var saveTask: Task<Void, Never>?
    @State private var searchText = ""
    @State private var activityFilter: ProductionTargetActivity?
    @State private var categoryFilter: Int64?
    @State private var groupFilter: Int64?
    @State private var searchPage: ProductionTargetSearchPage?
    @State private var isSearching = false
    @State private var selectionError: String?
    @State private var pendingOptions: ProductionTargetOptions?
    @State private var selectedBlueprintTypeID: Int64?
    @State private var selectedOutputQuantity: Int64?
    @State private var targetIsValidated = false
    @State private var isRevalidatingTarget = false
    @FocusState private var focusedField: FocusField?

    private let project: ProductionProjectSnapshot?
    private let save: @MainActor (ProductionProjectDraft) async throws -> Void
    private let reportError: @MainActor (any Error) -> Void

    init(
        model: ProjectLifecycleViewModel,
        project: ProductionProjectSnapshot?,
        save: @escaping @MainActor (
            ProductionProjectDraft
        ) async throws -> Void,
        reportError: @escaping @MainActor (any Error) -> Void
    ) {
        self.model = model
        self.project = project
        self.save = save
        self.reportError = reportError
        _name = State(initialValue: project?.name ?? "")
        _target = State(initialValue: project?.target)
        _targetQuantityText = State(
            initialValue: String(project?.targetQuantity ?? 1)
        )
        _materialEfficiency = State(
            initialValue: project?.materialEfficiency ?? 0
        )
        _priority = State(initialValue: project?.priority ?? 2)
        _usesTargetDate = State(
            initialValue: project?.targetDate != nil
        )
        _targetDate = State(
            initialValue: project?.targetDate ?? Date()
        )
        _notes = State(initialValue: project?.notes ?? "")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(project == nil ? "Produktionsprojekt anlegen" : "Produktionsprojekt bearbeiten")
                .font(.title2.bold())

            Form {
                TextField("Projektname", text: $name)
                    .accessibilityLabel("Projektname")
                    .focused($focusedField, equals: .name)
                    .submitLabel(.next)
                    .onSubmit {
                        focusedField =
                            target == nil ? .targetSearch : .targetQuantity
                    }

                Section("Zielprodukt") {
                    if let target {
                        selectedTargetView(target)
                        Button("Ziel erneut auswählen") {
                            self.target = nil
                            targetIsValidated = false
                            pendingOptions = nil
                            selectedBlueprintTypeID = nil
                            selectedOutputQuantity = nil
                            Task { @MainActor in
                                await Task.yield()
                                focusedField = .targetSearch
                            }
                        }
                        .accessibilityLabel(
                            "Zielprodukt erneut aus dem EVE-Katalog auswählen"
                        )
                    } else {
                        if project != nil {
                            Label(
                                "Bestandsprojekt: Ziel erneut auswählen",
                                systemImage: "exclamationmark.triangle"
                            )
                            .foregroundStyle(.orange)
                        }
                        targetSearch
                    }
                }

                TextField("Zielmenge", text: $targetQuantityText)
                    .accessibilityLabel(
                        "Positive ganze Zielmenge"
                    )
                    .help("Ganze Zahl größer als null")
                    .focused($focusedField, equals: .targetQuantity)
                    .submitLabel(.done)
                Section("Blueprint-Materialeffizienz") {
                    if target?.activity == .reaction {
                        LabeledContent(
                            "Material Efficiency",
                            value: "Für Reaktionen nicht anwendbar"
                        )
                        Text(
                            "Reaktionsformeln erhalten in P15 keine Blueprint-ME."
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    } else {
                        Stepper(
                            "Material Efficiency: \(materialEfficiency) %",
                            value: $materialEfficiency,
                            in: 0...10
                        )
                        .accessibilityLabel(
                            "Blueprint Material Efficiency"
                        )
                        .accessibilityValue(
                            "\(materialEfficiency) Prozent"
                        )
                        Text(
                            "Lokaler Projektwert der verwendeten Blueprint-ME, ganzzahlig von 0 bis 10 Prozent."
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }
                }
                Picker("Priorität", selection: $priority) {
                    Text("Hoch").tag(1)
                    Text("Normal").tag(2)
                    Text("Niedrig").tag(3)
                }
                Toggle("Zieltermin verwenden", isOn: $usesTargetDate)
                if usesTargetDate {
                    DatePicker(
                        "Zieltermin",
                        selection: $targetDate,
                        displayedComponents: [.date, .hourAndMinute]
                    )
                }
                TextField("Notizen", text: $notes, axis: .vertical)
                    .lineLimit(3...8)
                if let project {
                    LabeledContent("Status", value: project.status.rawValue)
                }
            }
            .formStyle(.grouped)

            NexusValidationSummary(issues: validationIssues)

            HStack {
                Spacer()
                Button("Abbrechen") {
                    dismiss()
                }
                .keyboardShortcut(.cancelAction)
                Button(project == nil ? "Anlegen" : "Speichern") {
                    saveProject()
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
                .disabled(!canSave || isSaving)
                .accessibilityLabel(
                    project == nil
                        ? "Produktionsprojekt anlegen"
                        : "Änderungen am Produktionsprojekt speichern"
                )
            }
        }
        .padding(24)
        .frame(minWidth: 520, idealWidth: 580)
        .overlay {
            if isSaving {
                ProgressView("Projekt wird gespeichert …")
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10))
            }
        }
        .onDisappear {
            saveTask?.cancel()
        }
        .task(id: searchIdentity) {
            guard target == nil else {
                return
            }
            await runSearch()
        }
        .task {
            await revalidateStoredTarget()
        }
        .onAppear {
            focusedField = .name
        }
    }

    private var canSave: Bool {
        validationIssues.isEmpty
            && (1...3).contains(priority)
            && (0...10).contains(materialEfficiency)
            && (
                target?.activity != .reaction
                    || materialEfficiency == 0
            )
    }

    private var parsedTargetQuantity: Int? {
        model.targetQuantity(from: targetQuantityText)
    }

    private var validationIssues: [NexusValidationIssue] {
        var issues: [NexusValidationIssue] = []
        if name.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty {
            issues.append(.requiredText(field: "Projektname"))
        }
        if target == nil {
            issues.append(.requiredSelection(field: "Zielprodukt"))
        } else if !targetIsValidated {
            issues.append(.staleInput(field: "Zielprodukt"))
        }
        if parsedTargetQuantity == nil {
            issues.append(.positiveInteger(field: "Zielmenge"))
        }
        return issues
    }

    private func saveProject() {
        guard let target, let targetQuantity = parsedTargetQuantity else {
            return
        }
        let draft = ProductionProjectDraft(
            name: name,
            target: target,
            targetQuantity: targetQuantity,
            priority: priority,
            targetDate: usesTargetDate ? targetDate : nil,
            notes: notes,
            materialEfficiency: materialEfficiency
        )
        isSaving = true
        saveTask = Task {
            defer { isSaving = false }
            do {
                try await save(draft)
                dismiss()
            } catch is CancellationError {
                return
            } catch {
                reportError(error)
            }
        }
    }

    @ViewBuilder
    private func selectedTargetView(
        _ selection: ProductionTargetSelection
    ) -> some View {
        LabeledContent("Produkt", value: selection.productName)
        LabeledContent(
            "Type-ID",
            value: selection.productTypeID.formatted()
        )
        LabeledContent(
            "Aktivität",
            value: activityLabel(selection.activity)
        )
        LabeledContent(
            "Blueprint-ID",
            value: selection.blueprintTypeID.formatted()
        )
        LabeledContent(
            "SDE-Build",
            value: selection.catalogBuildNumber.formatted()
        )
        if isRevalidatingTarget {
            ProgressView("Ziel wird gegen den aktiven SDE-Katalog geprüft …")
        } else if !targetIsValidated {
            Label(
                "Ziel ist für den aktiven SDE-Datenstand nicht bestätigt.",
                systemImage: "exclamationmark.triangle"
            )
            .foregroundStyle(.orange)
            if let selectionError {
                Text(selectionError)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        if let selectedOutputQuantity {
            LabeledContent(
                "Output je Lauf",
                value: NexusNumberFormat.quantity(selectedOutputQuantity)
            )
        }
    }

    @ViewBuilder
    private var targetSearch: some View {
        TextField("Zielprodukt auswählen", text: $searchText)
            .accessibilityLabel("EVE-Zielprodukt suchen")
            .focused($focusedField, equals: .targetSearch)
            .submitLabel(.search)

        Picker("Aktivität", selection: $activityFilter) {
            Text("Alle").tag(nil as ProductionTargetActivity?)
            Text("Fertigung")
                .tag(ProductionTargetActivity.manufacturing as ProductionTargetActivity?)
            Text("Reaktion")
                .tag(ProductionTargetActivity.reaction as ProductionTargetActivity?)
        }
        .accessibilityLabel("Produktionsaktivität filtern")

        if let page = searchPage {
            let categories = uniqueCategories(page.items)
            let groups = uniqueGroups(page.items)
            Picker("Kategorie", selection: $categoryFilter) {
                Text("Alle Kategorien").tag(nil as Int64?)
                ForEach(categories, id: \.id) { category in
                    Text(category.name).tag(category.id as Int64?)
                }
            }
            Picker("Gruppe", selection: $groupFilter) {
                Text("Alle Gruppen").tag(nil as Int64?)
                ForEach(groups, id: \.id) { group in
                    Text(group.name).tag(group.id as Int64?)
                }
            }
        }

        if isSearching {
            ProgressView("Katalog wird durchsucht …")
                .accessibilityLabel("Zielproduktsuche läuft")
        } else if let selectionError {
            Label(selectionError, systemImage: "exclamationmark.triangle")
                .foregroundStyle(.orange)
                .accessibilityLabel(
                    "Zielproduktauswahl fehlgeschlagen: \(selectionError)"
                )
        } else if let page = searchPage, page.items.isEmpty {
            ContentUnavailableView(
                "Keine produzierbaren Treffer",
                systemImage: "magnifyingglass"
            )
        } else if let page = searchPage {
            ForEach(page.items, id: \.typeID) { item in
                Button {
                    choose(item)
                } label: {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(item.name)
                            .fontWeight(.medium)
                        Text(
                            "Type \(item.typeID) · \(item.categoryName) · \(item.groupName)"
                        )
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        Text(
                            item.activities.map(activityLabel).joined(
                                separator: ", "
                            )
                        )
                        .font(.caption)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(
                    "\(item.name), Type \(item.typeID), \(item.categoryName), \(item.groupName)"
                )
            }
            if page.hasMore {
                Text("Weitere Treffer vorhanden – Suche verfeinern.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }

        if let options = pendingOptions,
           options.availableRecipes.count > 1 {
            Picker(
                "Blueprint",
                selection: $selectedBlueprintTypeID
            ) {
                Text("Blueprint auswählen").tag(nil as Int64?)
                ForEach(
                    options.availableRecipes,
                    id: \.blueprintTypeID
                ) { option in
                    Text(
                        "\(option.blueprintName) · Output \(NexusNumberFormat.quantity(option.outputQuantityPerRun))"
                    )
                    .tag(option.blueprintTypeID as Int64?)
                }
            }
            .accessibilityLabel("Blueprint für Zielprodukt auswählen")
            Button("Blueprint übernehmen") {
                confirmPendingRecipe()
            }
            .disabled(selectedBlueprintTypeID == nil)
        }
    }

    private var searchIdentity: String {
        [
            searchText,
            activityFilter?.rawValue ?? "all",
            categoryFilter.map(String.init) ?? "all",
            groupFilter.map(String.init) ?? "all"
        ].joined(separator: "|")
    }

    private func choose(_ item: ProductionTargetSearchItem) {
        let activity: ProductionTargetActivity
        if let activityFilter {
            guard item.activities.contains(activityFilter) else {
                selectionError =
                    "Das Produkt unterstützt den gewählten Aktivitätsfilter nicht."
                return
            }
            activity = activityFilter
        } else if item.activities.count == 1,
                  let onlyActivity = item.activities.first {
            activity = onlyActivity
        } else {
            selectionError =
                "Bitte vor der Auswahl Fertigung oder Reaktion festlegen."
            return
        }
        guard item.activities.contains(activity) else {
            selectionError = "Keine unterstützte Aktivität verfügbar."
            return
        }
        saveTask?.cancel()
        isSearching = true
        selectionError = nil
        saveTask = Task {
            defer { isSearching = false }
            do {
                let options = try await model.targetOptions(
                    productTypeID: item.typeID,
                    activity: activity
                )
                pendingOptions = options
                if options.availableRecipes.count == 1,
                   let recipe = options.availableRecipes.first {
                    selectedBlueprintTypeID = recipe.blueprintTypeID
                    try await applySelection(
                        productTypeID: item.typeID,
                        activity: activity,
                        blueprintTypeID: recipe.blueprintTypeID,
                        outputQuantity: recipe.outputQuantityPerRun
                    )
                }
            } catch is CancellationError {
                return
            } catch {
                selectionError = safeSelectionMessage(error)
            }
        }
    }

    private func confirmPendingRecipe() {
        guard let options = pendingOptions,
              let blueprintTypeID = selectedBlueprintTypeID,
              let recipe = options.availableRecipes.first(where: {
                  $0.blueprintTypeID == blueprintTypeID
              }) else {
            return
        }
        saveTask?.cancel()
        saveTask = Task {
            do {
                try await applySelection(
                    productTypeID: options.item.typeID,
                    activity: options.activity,
                    blueprintTypeID: blueprintTypeID,
                    outputQuantity: recipe.outputQuantityPerRun
                )
            } catch is CancellationError {
                return
            } catch {
                selectionError = safeSelectionMessage(error)
            }
        }
    }

    private func applySelection(
        productTypeID: Int64,
        activity: ProductionTargetActivity,
        blueprintTypeID: Int64,
        outputQuantity: Int64
    ) async throws {
        target = try await model.selectTarget(
            productTypeID: productTypeID,
            activity: activity,
            blueprintTypeID: blueprintTypeID
        )
        if activity == .reaction {
            materialEfficiency = 0
        }
        targetIsValidated = true
        selectedOutputQuantity = outputQuantity
        pendingOptions = nil
        selectionError = nil
        focusedField = .targetQuantity
    }

    private func runSearch() async {
        do {
            try await Task.sleep(for: .milliseconds(250))
            isSearching = true
            defer { isSearching = false }
            searchPage = try await model.searchTargets(
                query: searchText,
                activity: activityFilter,
                categoryID: categoryFilter,
                groupID: groupFilter
            )
            selectionError = nil
        } catch is CancellationError {
            return
        } catch {
            searchPage = nil
            selectionError = safeSelectionMessage(error)
        }
    }

    private func revalidateStoredTarget() async {
        guard let storedTarget = project?.target else {
            return
        }
        isRevalidatingTarget = true
        defer { isRevalidatingTarget = false }
        do {
            let validated = try await model.revalidateTarget(storedTarget)
            guard target == storedTarget else {
                return
            }
            target = validated
            targetIsValidated = true
            selectionError = nil
        } catch is CancellationError {
            return
        } catch {
            guard target == storedTarget else {
                return
            }
            targetIsValidated = false
            selectionError = safeSelectionMessage(error)
        }
    }

    private func activityLabel(
        _ activity: ProductionTargetActivity
    ) -> String {
        switch activity {
        case .manufacturing:
            "Fertigung"
        case .reaction:
            "Reaktion"
        }
    }

    private func safeSelectionMessage(_ error: any Error) -> String {
        switch error as? ProductionTargetSelectionError {
        case .itemNotFound:
            "Das Item ist im aktiven SDE nicht mehr vorhanden."
        case .itemNotPublished:
            "Das Item ist nicht veröffentlicht."
        case .noCompleteRecipe:
            "Für diese Aktivität existiert kein vollständiges Rezept."
        case .blueprintSelectionRequired:
            "Bitte einen Blueprint auswählen."
        case .blueprintMismatch:
            "Der Blueprint gehört nicht zu dieser Auswahl."
        case .catalogVersionChanged:
            "Der SDE-Datenstand hat sich geändert. Bitte erneut auswählen."
        case .unsupportedActivity:
            "Diese Produktionsaktivität wird nicht unterstützt."
        case .catalog(.noActiveDataVersion):
            "Kein aktiver lokaler SDE-Katalog vorhanden."
        case .catalog(.multipleActiveDataVersions):
            "Mehrere aktive SDE-Kataloge erkannt."
        case .catalog, .none:
            "Der lokale EVE-Katalog konnte nicht gelesen werden."
        }
    }

    private func uniqueCategories(
        _ items: [ProductionTargetSearchItem]
    ) -> [(id: Int64, name: String)] {
        Dictionary(
            items.map { ($0.categoryID, $0.categoryName) },
            uniquingKeysWith: { first, _ in first }
        )
        .map { (id: $0.key, name: $0.value) }
        .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    private func uniqueGroups(
        _ items: [ProductionTargetSearchItem]
    ) -> [(id: Int64, name: String)] {
        Dictionary(
            items.map { ($0.groupID, $0.groupName) },
            uniquingKeysWith: { first, _ in first }
        )
        .map { (id: $0.key, name: $0.value) }
        .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
}
