import Foundation
import NewEdenNexusDomain

public struct PriceCSVImportService: PriceCSVImporting, Sendable {
    private let parser: any InventoryCSVParsing
    private let repository: any PriceProfileRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        parser: any InventoryCSVParsing,
        repository: any PriceProfileRepository,
        catalog: any ItemBlueprintCatalogReading,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.parser = parser
        self.repository = repository
        self.catalog = catalog
        self.now = now
        self.makeID = makeID
    }

    public func inspect(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions
    ) async throws -> PriceCSVInspection {
        try validateSource(source)
        let parser = self.parser
        let document = try await Task.detached {
            try parser.parse(source: source, options: options)
        }.value
        return PriceCSVInspection(
            sourceName: source.displayName,
            sourceSHA256: source.sha256,
            headers: document.headers,
            dataRowCount: document.rows.count,
            encoding: document.encoding,
            delimiter: document.delimiter
        )
    }

    public func preview(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions,
        mapping: PriceCSVColumnMapping,
        decimalFormat: PriceCSVDecimalFormat,
        profileID: UUID,
        validFrom: Date,
        validUntil: Date?
    ) async throws -> PriceCSVImportPreview {
        try validateSource(source)
        guard validUntil.map({ validFrom < $0 }) ?? true else {
            throw PriceCSVImportError.invalidValidityRange
        }
        let parser = self.parser
        let document = try await Task.detached {
            try parser.parse(source: source, options: options)
        }.value
        try validate(mapping: mapping, headerCount: document.headers.count)
        guard let profile = try await repository.profile(id: profileID) else {
            throw PriceCSVImportError.profileNotFound(profileID)
        }

        let preliminaries = document.rows.map {
            preliminary(
                row: $0,
                headerCount: document.headers.count,
                mapping: mapping,
                decimalFormat: decimalFormat
            )
        }
        let duplicateIDs = Set(
            Dictionary(
                grouping: preliminaries.compactMap(\.typeID),
                by: { $0 }
            ).filter { $0.value.count > 1 }.keys
        )
        var lines: [PriceCSVPreviewLine] = []
        for preliminary in preliminaries {
            try Task.checkCancellation()
            if let typeID = preliminary.typeID,
               duplicateIDs.contains(typeID) {
                lines.append(
                    invalidLine(
                        preliminary,
                        adding: .init(
                            code: .duplicateTypeID,
                            message: "Type-ID \(typeID) kommt mehrfach in der Datei vor."
                        )
                    )
                )
                continue
            }
            guard preliminary.issues.isEmpty,
                  let typeID = preliminary.typeID,
                  let amount = preliminary.amount else {
                lines.append(invalidLine(preliminary))
                continue
            }
            let details: CatalogItemDetails
            switch try await catalog.item(typeID: typeID) {
            case .notFound:
                lines.append(
                    invalidLine(
                        preliminary,
                        adding: .init(
                            code: .itemNotFound,
                            message: "Type-ID \(typeID) existiert nicht im aktiven Katalog."
                        )
                    )
                )
                continue
            case .found(let found):
                guard found.summary.published else {
                    lines.append(
                        invalidLine(
                            preliminary,
                            adding: .init(
                                code: .unpublishedItem,
                                message: "Type-ID \(typeID) ist nicht veröffentlicht."
                            )
                        )
                    )
                    continue
                }
                details = found
            }
            if let suppliedName = preliminary.suppliedItemName,
               !suppliedName.isEmpty,
               CatalogSearchText.normalize(suppliedName)
                != CatalogSearchText.normalize(details.summary.name) {
                lines.append(
                    invalidLine(
                        preliminary,
                        itemName: details.summary.name,
                        adding: .init(
                            code: .itemNameMismatch,
                            message: "Der CSV-Itemname stimmt nicht mit dem aktiven Katalog überein."
                        )
                    )
                )
                continue
            }
            let existing = try await repository.price(
                profileID: profileID,
                typeID: typeID
            )
            let state: PriceCSVPreviewState
            if let existing {
                state = existing.amount == amount
                    && existing.validFrom == validFrom
                    && existing.validUntil == validUntil
                    ? .unchanged
                    : .replacementRequired
            } else {
                state = .insert
            }
            lines.append(
                PriceCSVPreviewLine(
                    rowNumber: preliminary.rowNumber,
                    typeID: typeID,
                    itemName: details.summary.name,
                    amount: amount,
                    existingPrice: existing,
                    catalogVersion: details.version,
                    state: state,
                    issues: []
                )
            )
        }
        return PriceCSVImportPreview(
            sourceName: source.displayName,
            sourceSHA256: source.sha256,
            profile: profile,
            encoding: document.encoding,
            delimiter: document.delimiter,
            mapping: mapping,
            decimalFormat: decimalFormat,
            validFrom: validFrom,
            validUntil: validUntil,
            lines: lines.sorted { $0.rowNumber < $1.rowNumber }
        )
    }

    public func apply(
        preview: PriceCSVImportPreview,
        decisions: [Int: PriceCSVImportDecision],
        confirmed: Bool
    ) async throws -> PriceImportReport {
        guard confirmed else {
            throw PriceCSVImportError.confirmationRequired
        }
        guard try await repository.profile(id: preview.profile.id)
                == preview.profile else {
            throw PriceCSVImportError.stalePreview
        }
        let timestamp = now()
        var mutations: [PriceImportMutation] = []
        var reportLines: [PriceImportReportLine] = []
        for line in preview.lines {
            try Task.checkCancellation()
            switch line.state {
            case .invalid:
                reportLines.append(reportLine(line, result: .invalid))
            case .unchanged:
                guard try await currentPrice(for: line, profileID:
                    preview.profile.id) == line.existingPrice else {
                    throw PriceCSVImportError.stalePreview
                }
                reportLines.append(reportLine(line, result: .unchanged))
            case .replacementRequired:
                guard let decision = decisions[line.rowNumber] else {
                    throw PriceCSVImportError.missingConflictDecision(
                        row: line.rowNumber
                    )
                }
                guard let current = try await currentPrice(
                    for: line,
                    profileID: preview.profile.id
                ), current == line.existingPrice else {
                    throw PriceCSVImportError.stalePreview
                }
                if decision == .skip {
                    reportLines.append(reportLine(line, result: .skipped))
                    continue
                }
                try await validateCatalog(line)
                mutations.append(
                    PriceImportMutation(
                        expectation: .existing(current),
                        price: try makePrice(
                            line,
                            profileID: preview.profile.id,
                            existing: current,
                            validFrom: preview.validFrom,
                            validUntil: preview.validUntil,
                            timestamp: timestamp
                        )
                    )
                )
                reportLines.append(reportLine(line, result: .replaced))
            case .insert:
                guard try await currentPrice(
                    for: line,
                    profileID: preview.profile.id
                ) == nil else {
                    throw PriceCSVImportError.stalePreview
                }
                try await validateCatalog(line)
                guard let typeID = line.typeID else {
                    throw PriceCSVImportError.stalePreview
                }
                mutations.append(
                    PriceImportMutation(
                        expectation: .missing(
                            profileID: preview.profile.id,
                            typeID: typeID
                        ),
                        price: try makePrice(
                            line,
                            profileID: preview.profile.id,
                            existing: nil,
                            validFrom: preview.validFrom,
                            validUntil: preview.validUntil,
                            timestamp: timestamp
                        )
                    )
                )
                reportLines.append(reportLine(line, result: .inserted))
            }
        }
        guard !mutations.isEmpty else {
            throw PriceCSVImportError.noChangesSelected
        }
        let report = PriceImportReport(
            id: makeID(),
            importedAt: timestamp,
            profileID: preview.profile.id,
            profileName: preview.profile.name,
            sourceName: preview.sourceName,
            sourceSHA256: preview.sourceSHA256,
            encoding: preview.encoding,
            delimiter: preview.delimiter,
            decimalFormat: preview.decimalFormat,
            validFrom: preview.validFrom,
            validUntil: preview.validUntil,
            lines: reportLines
        )
        try Task.checkCancellation()
        try await repository.applyPriceImport(
            PriceImportCommit(
                profile: preview.profile,
                mutations: mutations,
                report: report
            )
        )
        return report
    }

    private func validateSource(_ source: InventoryCSVImportSource) throws {
        guard !source.displayName.isEmpty,
              !source.displayName.contains("/"),
              !source.displayName.contains("\\") else {
            throw PriceCSVImportError.invalidSourceName
        }
        guard source.sha256.count == 64,
              source.sha256.allSatisfy(\.isHexDigit) else {
            throw PriceCSVImportError.invalidSourceHash
        }
    }

    private func validate(
        mapping: PriceCSVColumnMapping,
        headerCount: Int
    ) throws {
        let required = [mapping.typeIDColumn, mapping.priceColumn]
        guard required.allSatisfy({ (0..<headerCount).contains($0) }),
              Set(required).count == required.count else {
            throw PriceCSVImportError.invalidColumnMapping
        }
        if let itemNameColumn = mapping.itemNameColumn {
            guard (0..<headerCount).contains(itemNameColumn),
                  !required.contains(itemNameColumn) else {
                throw PriceCSVImportError.invalidColumnMapping
            }
        }
    }

    private func preliminary(
        row: InventoryCSVParsedRow,
        headerCount: Int,
        mapping: PriceCSVColumnMapping,
        decimalFormat: PriceCSVDecimalFormat
    ) -> Preliminary {
        guard row.fields.count == headerCount else {
            return Preliminary(
                rowNumber: row.rowNumber,
                typeID: nil,
                amount: nil,
                suppliedItemName: nil,
                issues: [.init(
                    code: .wrongColumnCount,
                    message: "Die Spaltenzahl stimmt nicht mit der Kopfzeile überein."
                )]
            )
        }
        let typeText = row.fields[mapping.typeIDColumn]
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let typeID = Int64(typeText).flatMap { $0 > 0 ? $0 : nil }
        let priceText = row.fields[mapping.priceColumn]
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let amount: ISKAmount?
        switch decimalFormat {
        case .decimalPoint where priceText.contains(","):
            amount = nil
        case .decimalComma where priceText.contains("."):
            amount = nil
        default:
            do {
                amount = try ISKAmount.parse(priceText)
            } catch {
                amount = nil
            }
        }
        var issues: [PriceCSVRowIssue] = []
        if typeID == nil {
            issues.append(.init(
                code: .invalidTypeID,
                message: "Die Type-ID muss eine positive ganze Zahl sein."
            ))
        }
        if amount == nil {
            issues.append(.init(
                code: .invalidPrice,
                message: "Der Preis muss positiv sein und zum gewählten Dezimalformat passen."
            ))
        }
        return Preliminary(
            rowNumber: row.rowNumber,
            typeID: typeID,
            amount: amount,
            suppliedItemName: mapping.itemNameColumn.map {
                row.fields[$0].trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
            },
            issues: issues
        )
    }

    private func invalidLine(
        _ preliminary: Preliminary,
        itemName: String? = nil,
        adding issue: PriceCSVRowIssue? = nil
    ) -> PriceCSVPreviewLine {
        PriceCSVPreviewLine(
            rowNumber: preliminary.rowNumber,
            typeID: preliminary.typeID,
            itemName: itemName ?? preliminary.suppliedItemName,
            amount: preliminary.amount,
            existingPrice: nil,
            catalogVersion: nil,
            state: .invalid,
            issues: preliminary.issues + (issue.map { [$0] } ?? [])
        )
    }

    private func currentPrice(
        for line: PriceCSVPreviewLine,
        profileID: UUID
    ) async throws -> ManualPriceSnapshot? {
        guard let typeID = line.typeID else {
            throw PriceCSVImportError.stalePreview
        }
        return try await repository.price(
            profileID: profileID,
            typeID: typeID
        )
    }

    private func validateCatalog(_ line: PriceCSVPreviewLine) async throws {
        guard let typeID = line.typeID,
              let expectedVersion = line.catalogVersion,
              let itemName = line.itemName else {
            throw PriceCSVImportError.stalePreview
        }
        switch try await catalog.item(typeID: typeID) {
        case .found(let details):
            guard details.summary.published,
                  details.summary.name == itemName,
                  details.version == expectedVersion else {
                throw PriceCSVImportError.stalePreview
            }
        case .notFound:
            throw PriceCSVImportError.stalePreview
        }
    }

    private func makePrice(
        _ line: PriceCSVPreviewLine,
        profileID: UUID,
        existing: ManualPriceSnapshot?,
        validFrom: Date,
        validUntil: Date?,
        timestamp: Date
    ) throws -> ManualPriceSnapshot {
        guard let typeID = line.typeID,
              let itemName = line.itemName,
              let amount = line.amount,
              let version = line.catalogVersion else {
            throw PriceCSVImportError.stalePreview
        }
        return try ManualPriceSnapshot(
            id: existing?.id ?? makeID(),
            profileID: profileID,
            typeID: typeID,
            itemName: itemName,
            amount: amount,
            source: .csv,
            validFrom: validFrom,
            validUntil: validUntil,
            catalogBuildNumber: version.buildNumber,
            catalogContentSHA256: version.contentSHA256,
            createdAt: existing?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
    }

    private func reportLine(
        _ line: PriceCSVPreviewLine,
        result: PriceImportResult
    ) -> PriceImportReportLine {
        PriceImportReportLine(
            rowNumber: line.rowNumber,
            typeID: line.typeID,
            itemName: line.itemName,
            previousAmountHundredths:
                line.existingPrice?.amount.hundredths,
            importedAmountHundredths: line.amount?.hundredths,
            result: result,
            issues: line.issues
        )
    }

    private struct Preliminary {
        let rowNumber: Int
        let typeID: Int64?
        let amount: ISKAmount?
        let suppliedItemName: String?
        let issues: [PriceCSVRowIssue]
    }
}

