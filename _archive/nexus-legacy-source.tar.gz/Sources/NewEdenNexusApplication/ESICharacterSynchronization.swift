import Foundation

public struct ESICacheValidators: Codable, Equatable, Sendable {
    public let etag: String?
    public let lastModified: String?

    public init(etag: String? = nil, lastModified: String? = nil) {
        self.etag = etag
        self.lastModified = lastModified
    }
}

public struct ESIRateLimitSnapshot: Codable, Equatable, Sendable {
    public let group: String?
    public let limit: String?
    public let remaining: Int?
    public let used: Int?
    public let errorLimitRemaining: Int?
    public let errorLimitResetSeconds: Int?

    public init(
        group: String? = nil,
        limit: String? = nil,
        remaining: Int? = nil,
        used: Int? = nil,
        errorLimitRemaining: Int? = nil,
        errorLimitResetSeconds: Int? = nil
    ) {
        self.group = group
        self.limit = limit
        self.remaining = remaining
        self.used = used
        self.errorLimitRemaining = errorLimitRemaining
        self.errorLimitResetSeconds = errorLimitResetSeconds
    }
}

public struct ESIResponseMetadata: Codable, Equatable, Sendable {
    public let checkedAt: Date
    public let expiresAt: Date?
    public let validators: ESICacheValidators
    public let compatibilityDate: String
    public let rateLimit: ESIRateLimitSnapshot

    public init(
        checkedAt: Date,
        expiresAt: Date?,
        validators: ESICacheValidators,
        compatibilityDate: String,
        rateLimit: ESIRateLimitSnapshot = ESIRateLimitSnapshot()
    ) {
        self.checkedAt = checkedAt
        self.expiresAt = expiresAt
        self.validators = validators
        self.compatibilityDate = compatibilityDate
        self.rateLimit = rateLimit
    }
}

public struct ESICharacterProfile: Codable, Equatable, Sendable {
    public let characterID: Int64
    public let name: String
    public let corporationID: Int64
    public let allianceID: Int64?
    public let factionID: Int64?
    public let birthday: Date
    public let gender: String
    public let raceID: Int64
    public let bloodlineID: Int64
    public let securityStatus: Double?
    public let achievementScore: Int64?
    public let characterTitleID: Int64?
    public let corporationTitleID: Int64?

    public init(
        characterID: Int64,
        name: String,
        corporationID: Int64,
        allianceID: Int64? = nil,
        factionID: Int64? = nil,
        birthday: Date,
        gender: String,
        raceID: Int64,
        bloodlineID: Int64,
        securityStatus: Double? = nil,
        achievementScore: Int64? = nil,
        characterTitleID: Int64? = nil,
        corporationTitleID: Int64? = nil
    ) throws {
        let normalizedName = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard characterID > 0,
              corporationID > 0,
              raceID > 0,
              bloodlineID > 0,
              !normalizedName.isEmpty,
              ["female", "male"].contains(gender),
              allianceID.map({ $0 > 0 }) ?? true,
              factionID.map({ $0 > 0 }) ?? true,
              securityStatus.map({ (-10...10).contains($0) }) ?? true,
              achievementScore.map({ $0 >= 0 }) ?? true,
              characterTitleID.map({ $0 > 0 }) ?? true,
              corporationTitleID.map({ $0 > 0 }) ?? true else {
            throw ESICharacterSyncError.invalidResponse
        }
        self.characterID = characterID
        self.name = normalizedName
        self.corporationID = corporationID
        self.allianceID = allianceID
        self.factionID = factionID
        self.birthday = birthday
        self.gender = gender
        self.raceID = raceID
        self.bloodlineID = bloodlineID
        self.securityStatus = securityStatus
        self.achievementScore = achievementScore
        self.characterTitleID = characterTitleID
        self.corporationTitleID = corporationTitleID
    }
}

public struct ESICharacterProfileSnapshot:
    Codable,
    Equatable,
    Sendable
{
    public let profile: ESICharacterProfile
    public let metadata: ESIResponseMetadata

    public init(
        profile: ESICharacterProfile,
        metadata: ESIResponseMetadata
    ) {
        self.profile = profile
        self.metadata = metadata
    }

    public func isFresh(at date: Date) -> Bool {
        metadata.expiresAt.map { $0 > date } ?? false
    }
}

public enum ESICharacterRemoteResult: Equatable, Sendable {
    case modified(ESICharacterProfile, ESIResponseMetadata)
    case notModified(ESIResponseMetadata)
}

public enum ESICharacterSyncSource: String, Equatable, Sendable {
    case freshCache = "fresh_cache"
    case network
    case notModified = "not_modified"
    case offlineCache = "offline_cache"
    case limitedCache = "limited_cache"
    case serverFallback = "server_fallback"
}

public struct ESICharacterSyncResult: Equatable, Sendable {
    public let snapshot: ESICharacterProfileSnapshot
    public let source: ESICharacterSyncSource

    public init(
        snapshot: ESICharacterProfileSnapshot,
        source: ESICharacterSyncSource
    ) {
        self.snapshot = snapshot
        self.source = source
    }

    public var isStale: Bool {
        [.offlineCache, .limitedCache, .serverFallback].contains(source)
    }
}

public enum ESICharacterSyncError: Error, Equatable, Sendable {
    case invalidConfiguration
    case ownerContactMissing
    case ownerContactAccessFailed
    case invalidCharacterID
    case invalidResponse
    case responseTooLarge
    case notFound
    case unauthorized
    case rateLimited(until: Date)
    case errorLimited(until: Date)
    case serverUnavailable
    case offline
    case transport
    case cacheCorrupted
    case cacheWriteFailed
    case notModifiedWithoutCache
}

extension ESICharacterSyncError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .invalidConfiguration:
            "Die ESI-Konfiguration ist ungültig."
        case .ownerContactMissing:
            "Für ESI muss zuerst der User-Agent-Kontakt gespeichert werden."
        case .ownerContactAccessFailed:
            "Die User-Agent-Kontaktangabe konnte nicht sicher aus dem Schlüsselbund gelesen werden."
        case .invalidCharacterID:
            "Die Charakter-ID ist ungültig."
        case .invalidResponse:
            "ESI hat ungültige Charakterdaten geliefert."
        case .responseTooLarge:
            "Die ESI-Antwort überschreitet die zulässige Größe."
        case .notFound:
            "Der Charakter wurde bei ESI nicht gefunden."
        case .unauthorized:
            "Die ESI-Anfrage wurde nicht autorisiert."
        case .rateLimited:
            "ESI begrenzt weitere Anfragen vorübergehend."
        case .errorLimited:
            "Das ESI-Fehlerlimit ist vorübergehend erreicht."
        case .serverUnavailable:
            "ESI ist vorübergehend nicht verfügbar."
        case .offline:
            "ESI ist offline nicht erreichbar."
        case .transport:
            "Die ESI-Anfrage konnte nicht abgeschlossen werden."
        case .cacheCorrupted:
            "Der lokale ESI-Charaktercache ist beschädigt."
        case .cacheWriteFailed:
            "Der lokale ESI-Charaktercache konnte nicht gespeichert werden."
        case .notModifiedWithoutCache:
            "ESI meldete unveränderte Daten, aber lokal fehlt der Cache."
        }
    }
}

public extension ESICharacterSyncError {
    var diagnosticReason: String {
        switch self {
        case .invalidConfiguration:
            "invalid_configuration"
        case .ownerContactMissing:
            "owner_contact_missing"
        case .ownerContactAccessFailed:
            "owner_contact_keychain_access_failed"
        case .invalidCharacterID:
            "invalid_character_id"
        case .invalidResponse:
            "invalid_response"
        case .responseTooLarge:
            "response_too_large"
        case .notFound:
            "not_found"
        case .unauthorized:
            "unauthorized"
        case .rateLimited:
            "rate_limited"
        case .errorLimited:
            "error_limited"
        case .serverUnavailable:
            "server_unavailable"
        case .offline:
            "offline"
        case .transport:
            "transport"
        case .cacheCorrupted:
            "cache_corrupted"
        case .cacheWriteFailed:
            "cache_write_failed"
        case .notModifiedWithoutCache:
            "not_modified_without_cache"
        }
    }
}

public protocol ESICharacterRemoteFetching: Sendable {
    func fetch(
        characterID: Int64,
        validators: ESICacheValidators?
    ) async throws -> ESICharacterRemoteResult
}

public protocol ESICharacterProfileCaching: Sendable {
    func snapshot(
        characterID: Int64
    ) async throws -> ESICharacterProfileSnapshot?

    func save(_ snapshot: ESICharacterProfileSnapshot) async throws
    func delete(characterID: Int64) async throws
}

public protocol ESICharacterSynchronizing: Sendable {
    func cachedProfile(
        characterID: Int64
    ) async throws -> ESICharacterProfileSnapshot?

    func synchronize(
        characterID: Int64
    ) async throws -> ESICharacterSyncResult
}

public actor ESICharacterSynchronizationService:
    ESICharacterSynchronizing
{
    private let remote: any ESICharacterRemoteFetching
    private let cache: any ESICharacterProfileCaching
    private let now: @Sendable () -> Date

    public init(
        remote: any ESICharacterRemoteFetching,
        cache: any ESICharacterProfileCaching,
        now: @escaping @Sendable () -> Date = Date.init
    ) {
        self.remote = remote
        self.cache = cache
        self.now = now
    }

    public func cachedProfile(
        characterID: Int64
    ) async throws -> ESICharacterProfileSnapshot? {
        guard characterID > 0 else {
            throw ESICharacterSyncError.invalidCharacterID
        }
        return try await cache.snapshot(characterID: characterID)
    }

    public func synchronize(
        characterID: Int64
    ) async throws -> ESICharacterSyncResult {
        guard characterID > 0 else {
            throw ESICharacterSyncError.invalidCharacterID
        }
        try Task.checkCancellation()
        let cached = try await cache.snapshot(characterID: characterID)
        if let cached, cached.isFresh(at: now()) {
            return ESICharacterSyncResult(
                snapshot: cached,
                source: .freshCache
            )
        }

        do {
            let result = try await remote.fetch(
                characterID: characterID,
                validators: cached?.metadata.validators
            )
            try Task.checkCancellation()
            switch result {
            case .modified(let profile, let metadata):
                guard profile.characterID == characterID else {
                    throw ESICharacterSyncError.invalidResponse
                }
                let snapshot = ESICharacterProfileSnapshot(
                    profile: profile,
                    metadata: metadata
                )
                try await cache.save(snapshot)
                return ESICharacterSyncResult(
                    snapshot: snapshot,
                    source: .network
                )
            case .notModified(let metadata):
                guard let cached else {
                    throw ESICharacterSyncError.notModifiedWithoutCache
                }
                let merged = ESIResponseMetadata(
                    checkedAt: metadata.checkedAt,
                    expiresAt: metadata.expiresAt
                        ?? cached.metadata.expiresAt,
                    validators: ESICacheValidators(
                        etag: metadata.validators.etag
                            ?? cached.metadata.validators.etag,
                        lastModified:
                            metadata.validators.lastModified
                            ?? cached.metadata.validators.lastModified
                    ),
                    compatibilityDate: metadata.compatibilityDate,
                    rateLimit: metadata.rateLimit
                )
                let snapshot = ESICharacterProfileSnapshot(
                    profile: cached.profile,
                    metadata: merged
                )
                try await cache.save(snapshot)
                return ESICharacterSyncResult(
                    snapshot: snapshot,
                    source: .notModified
                )
            }
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as ESICharacterSyncError {
            guard let cached else {
                throw error
            }
            let source: ESICharacterSyncSource
            switch error {
            case .offline, .transport:
                source = .offlineCache
            case .rateLimited, .errorLimited:
                source = .limitedCache
            case .serverUnavailable:
                source = .serverFallback
            default:
                throw error
            }
            return ESICharacterSyncResult(
                snapshot: cached,
                source: source
            )
        }
    }
}
