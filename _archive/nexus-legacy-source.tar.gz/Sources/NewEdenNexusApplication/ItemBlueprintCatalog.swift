import Foundation

public struct CatalogDataVersion: Equatable, Sendable {
    public let buildNumber: Int
    public let contentSHA256: String

    public init(buildNumber: Int, contentSHA256: String) {
        self.buildNumber = buildNumber
        self.contentSHA256 = contentSHA256
    }
}

public enum CatalogPublicationFilter: String, Equatable, Sendable {
    case publishedOnly
    case unpublishedOnly
    case all
}

public enum CatalogSearchScope: String, Equatable, Sendable {
    case allItems
    case producibleItems
}

public struct CatalogSearchFilter: Equatable, Sendable {
    public let scope: CatalogSearchScope
    public let publication: CatalogPublicationFilter
    public let categoryID: Int64?
    public let groupID: Int64?
    public let activity: StaticIndustryActivity?

    public init(
        scope: CatalogSearchScope = .allItems,
        publication: CatalogPublicationFilter = .publishedOnly,
        categoryID: Int64? = nil,
        groupID: Int64? = nil,
        activity: StaticIndustryActivity? = nil
    ) {
        self.scope = scope
        self.publication = publication
        self.categoryID = categoryID
        self.groupID = groupID
        self.activity = activity
    }

    public var hasExplicitConstraint: Bool {
        scope == .producibleItems
            || publication != .publishedOnly
            || categoryID != nil
            || groupID != nil
            || activity != nil
    }
}

public enum CatalogQueryError: Error, Equatable, Sendable {
    case invalidLimit(Int)
    case invalidExternalID(Int64)
    case emptyUnfilteredQuery
    case noActiveDataVersion
    case multipleActiveDataVersions
    case inconsistentStoredCatalog
    case persistenceFailure
}

public struct CatalogSearchRequest: Equatable, Sendable {
    public static let defaultLimit = 50
    public static let maximumLimit = 100

    public let normalizedQuery: String?
    public let filter: CatalogSearchFilter
    public let limit: Int

    public init(
        query: String? = nil,
        filter: CatalogSearchFilter = CatalogSearchFilter(),
        limit: Int = CatalogSearchRequest.defaultLimit
    ) throws {
        guard (1...Self.maximumLimit).contains(limit) else {
            throw CatalogQueryError.invalidLimit(limit)
        }
        if let categoryID = filter.categoryID, categoryID < 0 {
            throw CatalogQueryError.invalidExternalID(categoryID)
        }
        if let groupID = filter.groupID, groupID < 0 {
            throw CatalogQueryError.invalidExternalID(groupID)
        }

        let normalized = query.map(CatalogSearchText.normalize)
        let normalizedQuery = normalized?.isEmpty == false ? normalized : nil
        guard normalizedQuery != nil || filter.hasExplicitConstraint else {
            throw CatalogQueryError.emptyUnfilteredQuery
        }

        self.normalizedQuery = normalizedQuery
        self.filter = filter
        self.limit = limit
    }
}

public enum CatalogSearchText {
    public static func normalize(_ value: String) -> String {
        let folded = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(
                options: [
                    .caseInsensitive,
                    .diacriticInsensitive,
                    .widthInsensitive
                ],
                locale: Locale(identifier: "en_US_POSIX")
            )

        return folded
            .split(whereSeparator: \.isWhitespace)
            .joined(separator: " ")
    }
}

public struct CatalogProductionLink: Equatable, Sendable {
    public let blueprintTypeID: Int64
    public let productTypeID: Int64
    public let activity: StaticIndustryActivity
    public let outputQuantity: Int64
    public let probability: Double?
    public let timeSeconds: Int64
    public let hasUnresolvedReferences: Bool

    public init(
        blueprintTypeID: Int64,
        productTypeID: Int64,
        activity: StaticIndustryActivity,
        outputQuantity: Int64,
        probability: Double?,
        timeSeconds: Int64,
        hasUnresolvedReferences: Bool
    ) {
        self.blueprintTypeID = blueprintTypeID
        self.productTypeID = productTypeID
        self.activity = activity
        self.outputQuantity = outputQuantity
        self.probability = probability
        self.timeSeconds = timeSeconds
        self.hasUnresolvedReferences = hasUnresolvedReferences
    }
}

public struct CatalogItemSummary: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let groupID: Int64
    public let groupName: String
    public let categoryID: Int64
    public let categoryName: String
    public let marketGroupID: Int64?
    public let published: Bool
    public let productionActivities: [StaticIndustryActivity]
    public let hasUnresolvedProductionReferences: Bool

    public init(
        typeID: Int64,
        name: String,
        groupID: Int64,
        groupName: String,
        categoryID: Int64,
        categoryName: String,
        marketGroupID: Int64?,
        published: Bool,
        productionActivities: [StaticIndustryActivity],
        hasUnresolvedProductionReferences: Bool
    ) {
        self.typeID = typeID
        self.name = name
        self.groupID = groupID
        self.groupName = groupName
        self.categoryID = categoryID
        self.categoryName = categoryName
        self.marketGroupID = marketGroupID
        self.published = published
        self.productionActivities = productionActivities
        self.hasUnresolvedProductionReferences =
            hasUnresolvedProductionReferences
    }
}

public struct CatalogItemDetails: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let summary: CatalogItemSummary
    public let itemDescription: String?
    public let volume: Double?
    public let packagedVolume: Double?
    public let basePrice: Double?
    public let portionSize: Int64
    public let iconID: Int64?
    public let productionLinks: [CatalogProductionLink]

    public init(
        version: CatalogDataVersion,
        summary: CatalogItemSummary,
        itemDescription: String?,
        volume: Double?,
        packagedVolume: Double?,
        basePrice: Double?,
        portionSize: Int64,
        iconID: Int64?,
        productionLinks: [CatalogProductionLink]
    ) {
        self.version = version
        self.summary = summary
        self.itemDescription = itemDescription
        self.volume = volume
        self.packagedVolume = packagedVolume
        self.basePrice = basePrice
        self.portionSize = portionSize
        self.iconID = iconID
        self.productionLinks = productionLinks
    }
}

public struct CatalogBlueprintSummary: Equatable, Sendable {
    public let blueprintTypeID: Int64
    public let name: String
    public let published: Bool
    public let maxProductionLimit: Int64?
    public let activities: [StaticIndustryActivity]

    public init(
        blueprintTypeID: Int64,
        name: String,
        published: Bool,
        maxProductionLimit: Int64?,
        activities: [StaticIndustryActivity]
    ) {
        self.blueprintTypeID = blueprintTypeID
        self.name = name
        self.published = published
        self.maxProductionLimit = maxProductionLimit
        self.activities = activities
    }
}

public struct CatalogBlueprintDetails: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let summary: CatalogBlueprintSummary
    public let products: [CatalogProductionLink]

    public init(
        version: CatalogDataVersion,
        summary: CatalogBlueprintSummary,
        products: [CatalogProductionLink]
    ) {
        self.version = version
        self.summary = summary
        self.products = products
    }
}

public struct CatalogSearchPage: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let items: [CatalogItemSummary]
    public let hasMore: Bool

    public init(
        version: CatalogDataVersion,
        items: [CatalogItemSummary],
        hasMore: Bool
    ) {
        self.version = version
        self.items = items
        self.hasMore = hasMore
    }
}

public enum CatalogLookupResult<Value: Sendable>: Sendable {
    case found(Value)
    case notFound(CatalogDataVersion)
}

extension CatalogLookupResult: Equatable where Value: Equatable {}

public protocol ItemBlueprintCatalogReading: Sendable {
    func search(_ request: CatalogSearchRequest) async throws
        -> CatalogSearchPage

    func item(typeID: Int64) async throws
        -> CatalogLookupResult<CatalogItemDetails>

    func blueprint(typeID: Int64) async throws
        -> CatalogLookupResult<CatalogBlueprintDetails>

    func itemNames(typeIDs: [Int64]) async throws -> [Int64: String]
}

public extension ItemBlueprintCatalogReading {
    func itemNames(typeIDs: [Int64]) async throws -> [Int64: String] {
        let unique = Array(Set(typeIDs)).sorted()
        guard unique.allSatisfy({ $0 >= 0 }) else {
            throw CatalogQueryError.invalidExternalID(
                unique.first(where: { $0 < 0 }) ?? -1
            )
        }
        var result: [Int64: String] = [:]
        for typeID in unique {
            try Task.checkCancellation()
            if case let .found(item) = try await item(typeID: typeID) {
                result[typeID] = item.summary.name
            }
        }
        return result
    }
}

public struct SearchItemBlueprintCatalogUseCase: Sendable {
    private let catalog: any ItemBlueprintCatalogReading

    public init(catalog: any ItemBlueprintCatalogReading) {
        self.catalog = catalog
    }

    public func callAsFunction(
        _ request: CatalogSearchRequest
    ) async throws -> CatalogSearchPage {
        try await catalog.search(request)
    }
}

public struct LoadCatalogItemUseCase: Sendable {
    private let catalog: any ItemBlueprintCatalogReading

    public init(catalog: any ItemBlueprintCatalogReading) {
        self.catalog = catalog
    }

    public func callAsFunction(
        typeID: Int64
    ) async throws -> CatalogLookupResult<CatalogItemDetails> {
        guard typeID >= 0 else {
            throw CatalogQueryError.invalidExternalID(typeID)
        }
        return try await catalog.item(typeID: typeID)
    }
}

public struct LoadCatalogBlueprintUseCase: Sendable {
    private let catalog: any ItemBlueprintCatalogReading

    public init(catalog: any ItemBlueprintCatalogReading) {
        self.catalog = catalog
    }

    public func callAsFunction(
        typeID: Int64
    ) async throws -> CatalogLookupResult<CatalogBlueprintDetails> {
        guard typeID >= 0 else {
            throw CatalogQueryError.invalidExternalID(typeID)
        }
        return try await catalog.blueprint(typeID: typeID)
    }
}
