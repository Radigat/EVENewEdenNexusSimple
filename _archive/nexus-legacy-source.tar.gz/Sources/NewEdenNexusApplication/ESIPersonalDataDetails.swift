import Foundation

public enum ESIPersonalDataDetailSort:
    String,
    CaseIterable,
    Sendable
{
    case name
    case typeID
    case quantity
    case location
    case date
}

public struct ESIPersonalDataDetailPage<Value: Sendable>: Sendable {
    public let items: [Value]
    public let totalMatchCount: Int
    public let isTruncated: Bool

    public init(items: [Value], totalMatchCount: Int, isTruncated: Bool) {
        self.items = items
        self.totalMatchCount = totalMatchCount
        self.isTruncated = isTruncated
    }
}

public struct ESIPersonalDataLocationGroup<Value: Sendable>:
    Identifiable,
    Sendable
{
    public let id: String
    public let name: String
    public let locationIDs: [Int64]
    public let items: [Value]

    public init(
        id: String,
        name: String,
        locationIDs: [Int64],
        items: [Value]
    ) {
        self.id = id
        self.name = name
        self.locationIDs = locationIDs
        self.items = items
    }
}

public struct ESIPersonalDataGroupedPage<Value: Sendable>: Sendable {
    public let groups: [ESIPersonalDataLocationGroup<Value>]
    public let totalMatchCount: Int

    public init(
        groups: [ESIPersonalDataLocationGroup<Value>],
        totalMatchCount: Int
    ) {
        self.groups = groups
        self.totalMatchCount = totalMatchCount
    }
}

private struct ESIPersonalDataGroupBucket<Value> {
    var name: String
    var locationIDs: Set<Int64>
    var items: [Value]
}

public struct ESIPersonalDataDetailProjector: Sendable {
    public static let defaultLimit = 2_000

    public init() {}

    public func assets(
        _ values: [ESICharacterAsset],
        names: [Int64: String],
        locationNames: [Int64: String] = [:],
        query: String,
        locationID: Int64?,
        sort: ESIPersonalDataDetailSort,
        limit: Int = Self.defaultLimit
    ) -> ESIPersonalDataDetailPage<ESICharacterAsset> {
        page(
            values.filter {
                (locationID == nil || $0.locationID == locationID)
                    && matches(
                        query,
                        texts: [
                            names[$0.typeID],
                            locationNames[$0.locationID],
                            $0.locationFlag
                        ]
                    )
            }.sorted {
                switch sort {
                case .name:
                    nameOrder(
                        $0.typeID,
                        $1.typeID,
                        names: names
                    )
                case .typeID:
                    ($0.typeID, $0.itemID) < ($1.typeID, $1.itemID)
                case .quantity:
                    ($0.quantity, $0.itemID) > ($1.quantity, $1.itemID)
                case .location:
                    textOrder(
                        locationNames[$0.locationID],
                        locationNames[$1.locationID],
                        fallback: ($0.locationID, $1.locationID)
                    )
                        || (
                            locationNames[$0.locationID]
                                == locationNames[$1.locationID]
                                && $0.itemID < $1.itemID
                        )
                case .date:
                    $0.itemID < $1.itemID
                }
            },
            limit: limit
        )
    }

    public func blueprints(
        _ values: [ESICharacterBlueprint],
        names: [Int64: String],
        locationNames: [Int64: String] = [:],
        query: String,
        sort: ESIPersonalDataDetailSort,
        limit: Int = Self.defaultLimit
    ) -> ESIPersonalDataDetailPage<ESICharacterBlueprint> {
        page(
            values.filter {
                matches(
                    query,
                    texts: [
                        names[$0.typeID],
                        locationNames[$0.locationID],
                        $0.locationFlag
                    ]
                )
            }.sorted {
                switch sort {
                case .name:
                    nameOrder(
                        $0.typeID,
                        $1.typeID,
                        names: names
                    )
                case .typeID:
                    ($0.typeID, $0.itemID) < ($1.typeID, $1.itemID)
                case .quantity:
                    ($0.runs, $0.itemID) > ($1.runs, $1.itemID)
                case .location:
                    textOrder(
                        locationNames[$0.locationID],
                        locationNames[$1.locationID],
                        fallback: ($0.locationID, $1.locationID)
                    )
                        || (
                            locationNames[$0.locationID]
                                == locationNames[$1.locationID]
                                && $0.itemID < $1.itemID
                        )
                case .date:
                    $0.itemID < $1.itemID
                }
            },
            limit: limit
        )
    }

    public func jobs(
        _ values: [ESICharacterIndustryJob],
        names: [Int64: String],
        locationNames: [Int64: String] = [:],
        activityNames: [Int64: String] = [:],
        query: String,
        sort: ESIPersonalDataDetailSort,
        limit: Int = Self.defaultLimit
    ) -> ESIPersonalDataDetailPage<ESICharacterIndustryJob> {
        page(
            values.filter {
                matches(
                    query,
                    texts: [
                        names[$0.blueprintTypeID],
                        $0.productTypeID.flatMap { names[$0] },
                        locationNames[$0.facilityID],
                        locationNames[$0.stationID],
                        locationNames[$0.outputLocationID],
                        activityNames[$0.activityID],
                        $0.status
                    ]
                )
            }.sorted {
                switch sort {
                case .name:
                    nameOrder(
                        $0.blueprintTypeID,
                        $1.blueprintTypeID,
                        names: names
                    )
                case .typeID:
                    ($0.blueprintTypeID, $0.jobID)
                        < ($1.blueprintTypeID, $1.jobID)
                case .quantity:
                    ($0.runs, $0.jobID) > ($1.runs, $1.jobID)
                case .location:
                    textOrder(
                        locationNames[$0.facilityID]
                            ?? locationNames[$0.stationID],
                        locationNames[$1.facilityID]
                            ?? locationNames[$1.stationID],
                        fallback: ($0.facilityID, $1.facilityID)
                    )
                        || (
                            locationNames[$0.facilityID]
                                == locationNames[$1.facilityID]
                                && $0.jobID < $1.jobID
                        )
                case .date:
                    ($0.startDate, $0.jobID)
                        > ($1.startDate, $1.jobID)
                }
            },
            limit: limit
        )
    }

    public func groupedAssets(
        _ values: [ESICharacterAsset],
        names: [Int64: String],
        locationNames: [Int64: String] = [:],
        query: String,
        sort: ESIPersonalDataDetailSort
    ) -> ESIPersonalDataGroupedPage<ESICharacterAsset> {
        let matches = values.filter {
            self.matches(
                query,
                texts: [
                    names[$0.typeID],
                    locationNames[$0.locationID],
                    $0.locationFlag
                ]
            )
        }.sorted {
            assetOrder(
                $0,
                $1,
                names: names,
                locationNames: locationNames,
                sort: sort
            )
        }
        return grouped(
            matches,
            locationID: \.locationID,
            locationName: {
                locationNames[$0.locationID]
            }
        )
    }

    public func groupedBlueprints(
        _ values: [ESICharacterBlueprint],
        names: [Int64: String],
        locationNames: [Int64: String] = [:],
        query: String,
        sort: ESIPersonalDataDetailSort
    ) -> ESIPersonalDataGroupedPage<ESICharacterBlueprint> {
        let matches = values.filter {
            self.matches(
                query,
                texts: [
                    names[$0.typeID],
                    locationNames[$0.locationID],
                    $0.locationFlag
                ]
            )
        }.sorted {
            blueprintOrder(
                $0,
                $1,
                names: names,
                locationNames: locationNames,
                sort: sort
            )
        }
        return grouped(
            matches,
            locationID: \.locationID,
            locationName: {
                locationNames[$0.locationID]
            }
        )
    }

    public func groupedActiveJobs(
        _ values: [ESICharacterIndustryJob],
        names: [Int64: String],
        locationNames: [Int64: String] = [:],
        activityNames: [Int64: String] = [:],
        query: String,
        sort: ESIPersonalDataDetailSort
    ) -> ESIPersonalDataGroupedPage<ESICharacterIndustryJob> {
        let matches = values.filter {
            normalized($0.status) == "active"
                && self.matches(
                    query,
                    texts: [
                        names[$0.blueprintTypeID],
                        $0.productTypeID.flatMap { names[$0] },
                        locationNames[$0.facilityID],
                        locationNames[$0.stationID],
                        locationNames[$0.outputLocationID],
                        activityNames[$0.activityID],
                        $0.status
                    ]
                )
        }.sorted {
            jobOrder(
                $0,
                $1,
                names: names,
                locationNames: locationNames,
                sort: sort
            )
        }
        return grouped(
            matches,
            locationID: {
                preferredJobLocationID(
                    $0,
                    locationNames: locationNames
                )
            },
            locationName: {
                let id = preferredJobLocationID(
                    $0,
                    locationNames: locationNames
                )
                return locationNames[id]
            }
        )
    }

    private func grouped<Value: Sendable>(
        _ values: [Value],
        locationID: (Value) -> Int64,
        locationName: (Value) -> String?
    ) -> ESIPersonalDataGroupedPage<Value> {
        var buckets: [String: ESIPersonalDataGroupBucket<Value>] = [:]
        for value in values {
            let id = locationID(value)
            let name = resolvedLocationName(locationName(value))
            let key = normalized(name)
            if buckets[key] == nil {
                buckets[key] = ESIPersonalDataGroupBucket(
                    name: name,
                    locationIDs: [],
                    items: []
                )
            }
            buckets[key]?.locationIDs.insert(id)
            buckets[key]?.items.append(value)
        }

        let groups = buckets.values.map { bucket in
            let ids = bucket.locationIDs.sorted()
            return ESIPersonalDataLocationGroup(
                id: normalized(bucket.name)
                    + "|"
                    + ids.map(String.init).joined(separator: ","),
                name: bucket.name,
                locationIDs: ids,
                items: bucket.items
            )
        }.sorted {
            let lhs = normalized($0.name)
            let rhs = normalized($1.name)
            if lhs != rhs {
                return lhs < rhs
            }
            return $0.locationIDs.lexicographicallyPrecedes(
                $1.locationIDs
            )
        }

        return ESIPersonalDataGroupedPage(
            groups: groups,
            totalMatchCount: values.count
        )
    }

    private func resolvedLocationName(_ name: String?) -> String {
        let value = name?.trimmingCharacters(
            in: .whitespacesAndNewlines
        ) ?? ""
        return value.isEmpty ? "Unbekannter Lagerort" : value
    }

    private func preferredJobLocationID(
        _ job: ESICharacterIndustryJob,
        locationNames: [Int64: String]
    ) -> Int64 {
        if let station = locationNames[job.stationID],
           isResolvedLocationName(station) {
            return job.stationID
        }
        if let facility = locationNames[job.facilityID],
           isResolvedLocationName(facility) {
            return job.facilityID
        }
        if locationNames[job.stationID] != nil {
            return job.stationID
        }
        return job.facilityID
    }

    private func isResolvedLocationName(_ name: String) -> Bool {
        name != "Unbekannter Lagerort"
            && !name.contains("– Name ")
    }

    private func assetOrder(
        _ lhs: ESICharacterAsset,
        _ rhs: ESICharacterAsset,
        names: [Int64: String],
        locationNames: [Int64: String],
        sort: ESIPersonalDataDetailSort
    ) -> Bool {
        switch sort {
        case .name:
            nameOrder(lhs.typeID, rhs.typeID, names: names)
        case .typeID:
            (lhs.typeID, lhs.itemID) < (rhs.typeID, rhs.itemID)
        case .quantity:
            (lhs.quantity, lhs.itemID) > (rhs.quantity, rhs.itemID)
        case .location:
            textOrder(
                locationNames[lhs.locationID],
                locationNames[rhs.locationID],
                fallback: (lhs.locationID, rhs.locationID)
            )
        case .date:
            lhs.itemID < rhs.itemID
        }
    }

    private func blueprintOrder(
        _ lhs: ESICharacterBlueprint,
        _ rhs: ESICharacterBlueprint,
        names: [Int64: String],
        locationNames: [Int64: String],
        sort: ESIPersonalDataDetailSort
    ) -> Bool {
        switch sort {
        case .name:
            nameOrder(lhs.typeID, rhs.typeID, names: names)
        case .typeID:
            (lhs.typeID, lhs.itemID) < (rhs.typeID, rhs.itemID)
        case .quantity:
            (lhs.runs, lhs.itemID) > (rhs.runs, rhs.itemID)
        case .location:
            textOrder(
                locationNames[lhs.locationID],
                locationNames[rhs.locationID],
                fallback: (lhs.locationID, rhs.locationID)
            )
        case .date:
            lhs.itemID < rhs.itemID
        }
    }

    private func jobOrder(
        _ lhs: ESICharacterIndustryJob,
        _ rhs: ESICharacterIndustryJob,
        names: [Int64: String],
        locationNames: [Int64: String],
        sort: ESIPersonalDataDetailSort
    ) -> Bool {
        switch sort {
        case .name:
            nameOrder(
                lhs.blueprintTypeID,
                rhs.blueprintTypeID,
                names: names
            )
        case .typeID:
            (lhs.blueprintTypeID, lhs.jobID)
                < (rhs.blueprintTypeID, rhs.jobID)
        case .quantity:
            (lhs.runs, lhs.jobID) > (rhs.runs, rhs.jobID)
        case .location:
            textOrder(
                locationNames[lhs.stationID]
                    ?? locationNames[lhs.facilityID],
                locationNames[rhs.stationID]
                    ?? locationNames[rhs.facilityID],
                fallback: (lhs.facilityID, rhs.facilityID)
            )
        case .date:
            (lhs.startDate, lhs.jobID)
                > (rhs.startDate, rhs.jobID)
        }
    }

    private func page<Value: Sendable>(
        _ values: [Value],
        limit: Int
    ) -> ESIPersonalDataDetailPage<Value> {
        let safeLimit = max(1, min(limit, Self.defaultLimit))
        return ESIPersonalDataDetailPage(
            items: Array(values.prefix(safeLimit)),
            totalMatchCount: values.count,
            isTruncated: values.count > safeLimit
        )
    }

    private func matches(
        _ query: String,
        texts: [String?]
    ) -> Bool {
        let needle = normalized(query)
        guard !needle.isEmpty else { return true }
        return texts.compactMap { $0 }.contains {
            normalized($0).contains(needle)
        }
    }

    private func nameOrder(
        _ left: Int64,
        _ right: Int64,
        names: [Int64: String]
    ) -> Bool {
        let lhs = normalized(names[left] ?? "")
        let rhs = normalized(names[right] ?? "")
        return lhs == rhs ? left < right : lhs < rhs
    }

    private func normalized(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(
                options: [
                    .caseInsensitive,
                    .diacriticInsensitive,
                    .widthInsensitive
                ],
                locale: Locale(identifier: "en_US_POSIX")
            )
    }

    private func textOrder(
        _ left: String?,
        _ right: String?,
        fallback: (Int64, Int64)
    ) -> Bool {
        let lhs = normalized(left ?? "")
        let rhs = normalized(right ?? "")
        return lhs == rhs ? fallback.0 < fallback.1 : lhs < rhs
    }
}
