import Foundation
import NewEdenNexusDomain

public protocol ProductionProjectRepository: Sendable {
    func save(_ project: ProductionProjectSnapshot) async throws
    func project(id: UUID) async throws -> ProductionProjectSnapshot?
    func projects() async throws -> [ProductionProjectSnapshot]
}
