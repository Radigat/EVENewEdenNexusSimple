import Foundation

public struct ESILocationNameCache: Codable, Equatable, Sendable {
    public static let payloadVersion = 1

    public let version: Int
    public let characterID: Int64
    public let names: [Int64: String]
    public let structureEntries:
        [Int64: ESIStructureNameCacheEntry]?
    public let updatedAt: Date

    public init(
        characterID: Int64,
        names: [Int64: String],
        structureEntries:
            [Int64: ESIStructureNameCacheEntry] = [:],
        updatedAt: Date
    ) throws {
        guard characterID > 0,
              updatedAt.timeIntervalSinceReferenceDate.isFinite,
              names.keys.allSatisfy({ $0 > 0 }),
              names.values.allSatisfy(Self.isSafeName),
              structureEntries.keys.allSatisfy({ $0 >= 1_000_000_000_000 }),
              structureEntries.values.allSatisfy({
                  Self.isSafeName($0.name)
                      && ($0.solarSystemID.map { $0 > 0 } ?? true)
              }) else {
            throw ESIPersonalDataError.invalidResponse
        }
        version = Self.payloadVersion
        self.characterID = characterID
        self.names = names
        self.structureEntries = structureEntries
        self.updatedAt = updatedAt
    }

    private static func isSafeName(_ value: String) -> Bool {
        let trimmed = value.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        return !trimmed.isEmpty
            && trimmed.utf8.count <= 512
            && value.rangeOfCharacter(from: .newlines) == nil
    }
}

public struct ESIStructureNameCacheEntry:
    Codable,
    Equatable,
    Sendable
{
    public let name: String
    public let solarSystemID: Int64?
    public let metadata: ESIResponseMetadata

    public init(
        name: String,
        solarSystemID: Int64? = nil,
        metadata: ESIResponseMetadata
    ) {
        self.name = name
        self.solarSystemID = solarSystemID
        self.metadata = metadata
    }
}

public protocol ESILocationNameRemoteFetching: Sendable {
    func names(for ids: [Int64]) async throws -> [Int64: String]
}

public enum ESIStructureNameRemoteResult:
    Equatable,
    Sendable
{
    case modified(
        name: String,
        solarSystemID: Int64,
        metadata: ESIResponseMetadata
    )
    case notModified(metadata: ESIResponseMetadata)
    case inaccessible
}

public protocol ESIStructureNameRemoteFetching: Sendable {
    func name(
        structureID: Int64,
        accessToken: String,
        validators: ESICacheValidators?
    ) async throws -> ESIStructureNameRemoteResult
}

public protocol ESILocationNamePersisting: Sendable {
    func cache(characterID: Int64) async throws -> ESILocationNameCache?
    func save(_ cache: ESILocationNameCache) async throws
    func delete(characterID: Int64) async throws
}

public protocol ESILocationNameResolving: Sendable {
    func names(
        characterID: Int64,
        snapshot: ESIPersonalDataSnapshot
    ) async throws -> [Int64: String]

    func names(
        characterID: Int64,
        snapshot: ESIPersonalDataSnapshot,
        structureConfiguration: EVEAuthenticationConfiguration?
    ) async throws -> [Int64: String]
}

public extension ESILocationNameResolving {
    func names(
        characterID: Int64,
        snapshot: ESIPersonalDataSnapshot,
        structureConfiguration: EVEAuthenticationConfiguration?
    ) async throws -> [Int64: String] {
        try await names(characterID: characterID, snapshot: snapshot)
    }
}

public actor ESILocationNameResolutionService:
    ESILocationNameResolving
{
    private let remote: any ESILocationNameRemoteFetching
    private let structureRemote:
        (any ESIStructureNameRemoteFetching)?
    private let tokenProvider: (any EVEAccessTokenProviding)?
    private let store: any ESILocationNamePersisting
    private let now: @Sendable () -> Date

    public init(
        remote: any ESILocationNameRemoteFetching,
        structureRemote:
            (any ESIStructureNameRemoteFetching)? = nil,
        tokenProvider: (any EVEAccessTokenProviding)? = nil,
        store: any ESILocationNamePersisting,
        now: @escaping @Sendable () -> Date = Date.init
    ) {
        self.remote = remote
        self.structureRemote = structureRemote
        self.tokenProvider = tokenProvider
        self.store = store
        self.now = now
    }

    public func names(
        characterID: Int64,
        snapshot: ESIPersonalDataSnapshot
    ) async throws -> [Int64: String] {
        try await names(
            characterID: characterID,
            snapshot: snapshot,
            structureConfiguration: nil
        )
    }

    public func names(
        characterID: Int64,
        snapshot: ESIPersonalDataSnapshot,
        structureConfiguration: EVEAuthenticationConfiguration?
    ) async throws -> [Int64: String] {
        guard characterID > 0,
              snapshot.characterID == characterID else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        var cached = try await store.cache(characterID: characterID)
        var names = cached?.names ?? [:]
        var structureEntries = cached?.structureEntries ?? [:]
        let candidates = Self.resolvableLocationIDs(snapshot: snapshot)
        let missing = candidates.filter { names[$0] == nil }
        if !missing.isEmpty {
            do {
                let resolved = try await remote.names(for: missing)
                for (id, name) in resolved {
                    names[id] = name
                }
                let replacement = try ESILocationNameCache(
                    characterID: characterID,
                    names: names,
                    structureEntries: structureEntries,
                    updatedAt: now()
                )
                try await store.save(replacement)
                cached = replacement
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                if cached == nil {
                    throw error
                }
            }
        }

        let structureIDs = Self.privateStructureLocationIDs(
            snapshot: snapshot
        )
        guard let structureConfiguration,
              structureConfiguration.scopes.contains(
                  EVEAuthorizationScope.structures
              ),
              let structureRemote,
              let tokenProvider else {
            for id in structureIDs {
                names[id] = nil
            }
            return names
        }
        guard structureIDs.count <= 500 else {
            throw ESIPersonalDataError.responseTooLarge
        }
        guard !structureIDs.isEmpty else {
            return names
        }
        do {
            let token = try await tokenProvider.accessToken(
                characterID: characterID,
                configuration: structureConfiguration
            )
            for id in structureIDs {
                try Task.checkCancellation()
                let previous = structureEntries[id]
                if let expiry = previous?.metadata.expiresAt,
                   expiry > now() {
                    names[id] = previous?.name
                    continue
                }
                switch try await structureRemote.name(
                    structureID: id,
                    accessToken: token.value,
                    validators: previous?.metadata.validators
                ) {
                case .modified(
                    let name,
                    let solarSystemID,
                    let metadata
                ):
                    names[id] = name
                    structureEntries[id] = ESIStructureNameCacheEntry(
                        name: name,
                        solarSystemID: solarSystemID,
                        metadata: metadata
                    )
                case .notModified(let metadata):
                    guard let previous else {
                        throw ESIPersonalDataError.invalidResponse
                    }
                    names[id] = previous.name
                    structureEntries[id] = ESIStructureNameCacheEntry(
                        name: previous.name,
                        solarSystemID: previous.solarSystemID,
                        metadata: metadata
                    )
                case .inaccessible:
                    names[id] = nil
                    structureEntries[id] = nil
                }
            }
            let replacement = try ESILocationNameCache(
                characterID: characterID,
                names: names,
                structureEntries: structureEntries,
                updatedAt: now()
            )
            try await store.save(replacement)
            return names
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            for (id, entry) in structureEntries {
                names[id] = entry.name
            }
            if structureEntries.isEmpty {
                throw error
            }
            return names
        }
    }

    static func resolvableLocationIDs(
        snapshot: ESIPersonalDataSnapshot
    ) -> [Int64] {
        var ids = Set<Int64>()
        for asset in snapshot.assets
        where asset.locationType == "station"
            || asset.locationType == "solar_system" {
            ids.insert(asset.locationID)
        }
        for blueprint in snapshot.blueprints
        where isPublicUniverseLocation(blueprint.locationID) {
            ids.insert(blueprint.locationID)
        }
        for job in snapshot.industryJobs {
            if isPublicUniverseLocation(job.stationID) {
                ids.insert(job.stationID)
            }
            if isPublicUniverseLocation(job.facilityID) {
                ids.insert(job.facilityID)
            }
            if isPublicUniverseLocation(job.outputLocationID) {
                ids.insert(job.outputLocationID)
            }
        }
        return ids.sorted()
    }

    public static func privateStructureLocationIDs(
        snapshot: ESIPersonalDataSnapshot
    ) -> [Int64] {
        let assetsByItem = Dictionary(
            uniqueKeysWithValues: snapshot.assets.map {
                ($0.itemID, $0)
            }
        )
        var ids = Set<Int64>()
        let candidates = snapshot.assets.map(\.locationID)
            + snapshot.blueprints.map(\.locationID)
            + snapshot.industryJobs.flatMap {
                [$0.stationID, $0.facilityID, $0.outputLocationID]
                    .compactMap { $0 }
            }
        for candidate in candidates {
            var current = candidate
            var visited = Set<Int64>()
            while let parent = assetsByItem[current],
                  visited.insert(current).inserted {
                current = parent.locationID
            }
            if current >= 1_000_000_000_000 {
                ids.insert(current)
            }
        }
        return ids.sorted()
    }

    private static func isPublicUniverseLocation(_ id: Int64) -> Bool {
        (30_000_000...39_999_999).contains(id)
            || (60_000_000...69_999_999).contains(id)
    }
}

public struct ESIPersonalDataLocationIndex: Sendable {
    public let namesByLocationID: [Int64: String]
    public let assetLabelsByLocationID: [Int64: String]
    public let assetLocationIDs: [Int64]

    public init(
        namesByLocationID: [Int64: String] = [:],
        assetLabelsByLocationID: [Int64: String] = [:],
        assetLocationIDs: [Int64] = []
    ) {
        self.namesByLocationID = namesByLocationID
        self.assetLabelsByLocationID = assetLabelsByLocationID
        self.assetLocationIDs = assetLocationIDs
    }
}

public struct ESIPersonalDataPresentation: Sendable {
    public init() {}

    public func locationIndex(
        snapshot: ESIPersonalDataSnapshot,
        names: [Int64: String]
    ) -> ESIPersonalDataLocationIndex {
        let assetsByItem = Dictionary(
            uniqueKeysWithValues: snapshot.assets.map {
                ($0.itemID, $0)
            }
        )
        let referencedIDs = Set(
            snapshot.assets.map(\.locationID)
                + snapshot.blueprints.map(\.locationID)
                + snapshot.industryJobs.flatMap {
                    [
                        $0.facilityID,
                        $0.stationID,
                        $0.outputLocationID
                    ]
                }
        )
        var cache: [Int64: String] = [:]

        func resolve(_ locationID: Int64) -> String {
            if let cached = cache[locationID] {
                return cached
            }
            var current = locationID
            var path: [Int64] = []
            var visited = Set<Int64>()
            var result: String?
            while current > 0, visited.insert(current).inserted {
                path.append(current)
                if let cached = cache[current] {
                    result = cached
                    break
                }
                if let name = names[current] {
                    result = name
                    break
                }
                guard let parent = assetsByItem[current] else {
                    break
                }
                current = parent.locationID
            }
            let resolved = result ?? fallbackLocationName(current)
            cache[locationID] = resolved
            for id in path {
                cache[id] = resolved
            }
            return resolved
        }

        for id in referencedIDs {
            _ = resolve(id)
        }

        let assetLocationIDs = Array(
            Set(snapshot.assets.map(\.locationID))
        ).sorted {
            let lhs = cache[$0] ?? resolve($0)
            let rhs = cache[$1] ?? resolve($1)
            let order = lhs.localizedStandardCompare(rhs)
            return order == .orderedSame ? $0 < $1 : order == .orderedAscending
        }
        let flagsByLocation = Dictionary(
            grouping: snapshot.assets,
            by: \.locationID
        ).mapValues { assets in
            Set(assets.map {
                locationFlagName($0.locationFlag)
            }).sorted()
        }
        let labels = Dictionary(
            uniqueKeysWithValues: assetLocationIDs.map { id in
                let location = cache[id] ?? resolve(id)
                let flags = flagsByLocation[id] ?? []
                return (
                    id,
                    flags.isEmpty
                        ? location
                        : location + " · " + flags.joined(separator: ", ")
                )
            }
        )
        return ESIPersonalDataLocationIndex(
            namesByLocationID: cache,
            assetLabelsByLocationID: labels,
            assetLocationIDs: assetLocationIDs
        )
    }

    public func locationName(
        _ locationID: Int64,
        snapshot: ESIPersonalDataSnapshot,
        names: [Int64: String]
    ) -> String {
        let assetsByItem = Dictionary(
            uniqueKeysWithValues: snapshot.assets.map {
                ($0.itemID, $0)
            }
        )
        var current = locationID
        var visited = Set<Int64>()
        while current > 0, visited.insert(current).inserted {
            if let name = names[current] {
                return name
            }
            guard let parent = assetsByItem[current] else {
                break
            }
            current = parent.locationID
        }
        if current >= 1_000_000_000_000 {
            return "Spielerstruktur – Name nicht verfügbar"
        }
        if (30_000_000...39_999_999).contains(current) {
            return "Sonnensystem – Name noch nicht geladen"
        }
        if (60_000_000...69_999_999).contains(current) {
            return "NPC-Station – Name noch nicht geladen"
        }
        return "Unbekannter Lagerort"
    }

    private func fallbackLocationName(_ locationID: Int64) -> String {
        if locationID >= 1_000_000_000_000 {
            return "Spielerstruktur – Name nicht verfügbar"
        }
        if (30_000_000...39_999_999).contains(locationID) {
            return "Sonnensystem – Name noch nicht geladen"
        }
        if (60_000_000...69_999_999).contains(locationID) {
            return "NPC-Station – Name noch nicht geladen"
        }
        return "Unbekannter Lagerort"
    }

    public func locationFlagName(_ flag: String) -> String {
        switch flag {
        case "Hangar", "HangarAll": "Item-Hangar"
        case "ShipHangar": "Schiffshangar"
        case "Cargo": "Frachtraum"
        case "FleetHangar": "Flottenhangar"
        case "DroneBay": "Drohnenbucht"
        case "FighterBay": "Jägerbucht"
        case "Deliveries", "CapsuleerDeliveries": "Lieferungen"
        case "AssetSafety": "Asset Safety"
        case "Locked": "Gesperrter Container"
        case "Unlocked": "Container"
        case "SpecializedAmmoHold": "Munitionslager"
        case "SpecializedFuelBay": "Treibstofflager"
        case "SpecializedGasHold": "Gaslager"
        case "SpecializedIceHold": "Eislager"
        case "SpecializedMineralHold": "Mineralienlager"
        case "SpecializedOreHold": "Erzlager"
        case "SpecializedPlanetaryCommoditiesHold": "PI-Lager"
        case "SpecializedMaterialBay": "Materiallager"
        default:
            flag
                .replacingOccurrences(
                    of: "([a-z])([A-Z])",
                    with: "$1 $2",
                    options: .regularExpression
                )
        }
    }

    public func activityName(_ activityID: Int64) -> String {
        switch activityID {
        case 1: "Produktion"
        case 3: "Zeiteffizienz-Forschung"
        case 4: "Materialeffizienz-Forschung"
        case 5: "Blueprint-Kopie"
        case 7: "Reverse Engineering"
        case 8: "Invention"
        case 9: "Reaktion"
        default: "Andere Industrieaktivität"
        }
    }

    public func jobStatusName(_ status: String) -> String {
        switch status {
        case "active": "Aktiv"
        case "cancelled": "Abgebrochen"
        case "delivered": "Ausgeliefert"
        case "paused": "Pausiert"
        case "ready": "Abholbereit"
        case "reverted": "Zurückgesetzt"
        default: status.capitalized
        }
    }
}
