import Foundation

public enum LocalBackupKind: String, Codable, Equatable, Sendable {
    case manual
    case beforeMigration
    case beforeRestore
    case beforeSDEUpdate
}

public enum LocalBackupEncryption: String, Codable, Equatable, Sendable {
    case none
}

public struct LocalBackupManifest: Codable, Equatable, Sendable {
    public let formatIdentifier: String
    public let formatVersion: Int
    public let backupID: UUID
    public let createdAt: Date
    public let kind: LocalBackupKind
    public let schemaVersion: String
    public let databaseFileName: String
    public let databaseByteCount: Int64
    public let databaseSHA256: String
    public let encryption: LocalBackupEncryption

    public init(
        formatIdentifier: String,
        formatVersion: Int,
        backupID: UUID,
        createdAt: Date,
        kind: LocalBackupKind,
        schemaVersion: String,
        databaseFileName: String,
        databaseByteCount: Int64,
        databaseSHA256: String,
        encryption: LocalBackupEncryption
    ) {
        self.formatIdentifier = formatIdentifier
        self.formatVersion = formatVersion
        self.backupID = backupID
        self.createdAt = createdAt
        self.kind = kind
        self.schemaVersion = schemaVersion
        self.databaseFileName = databaseFileName
        self.databaseByteCount = databaseByteCount
        self.databaseSHA256 = databaseSHA256
        self.encryption = encryption
    }
}

public struct LocalBackupDescriptor: Equatable, Sendable {
    public let packageURL: URL
    public let manifest: LocalBackupManifest

    public init(packageURL: URL, manifest: LocalBackupManifest) {
        self.packageURL = packageURL
        self.manifest = manifest
    }
}

public struct LocalBackupRestorePreview: Equatable, Sendable {
    public let backup: LocalBackupDescriptor
    public let targetStoreURL: URL
    public let willReplaceExistingStore: Bool
    public let targetStoreFingerprint: String?

    public init(
        backup: LocalBackupDescriptor,
        targetStoreURL: URL,
        willReplaceExistingStore: Bool,
        targetStoreFingerprint: String?
    ) {
        self.backup = backup
        self.targetStoreURL = targetStoreURL
        self.willReplaceExistingStore = willReplaceExistingStore
        self.targetStoreFingerprint = targetStoreFingerprint
    }
}

public enum LocalBackupRestoreConfirmation: Equatable, Sendable {
    case notConfirmed
    case confirmed
}

public enum LocalBackupTargetStoreState: Equatable, Sendable {
    case open
    case closed
}

public struct LocalBackupRestoreResult: Equatable, Sendable {
    public let restoredStoreURL: URL
    public let safetyBackup: LocalBackupDescriptor?

    public init(
        restoredStoreURL: URL,
        safetyBackup: LocalBackupDescriptor?
    ) {
        self.restoredStoreURL = restoredStoreURL
        self.safetyBackup = safetyBackup
    }
}

public protocol LocalBackupManaging: Sendable {
    func createBackup(
        sourceStoreURL: URL,
        destinationDirectoryURL: URL,
        kind: LocalBackupKind
    ) async throws -> LocalBackupDescriptor

    func previewRestore(
        packageURL: URL,
        targetStoreURL: URL
    ) async throws -> LocalBackupRestorePreview

    func restore(
        preview: LocalBackupRestorePreview,
        confirmation: LocalBackupRestoreConfirmation,
        targetStoreState: LocalBackupTargetStoreState,
        safetyBackupDirectoryURL: URL
    ) async throws -> LocalBackupRestoreResult
}

public enum LocalBackupFileOperation: String, Equatable, Sendable {
    case validateSource
    case createDestination
    case createStaging
    case writeManifest
    case publishPackage
    case readPackage
    case calculateChecksum
    case stageRestore
    case replaceStore
    case manageSidecars
    case cleanup
}

public enum LocalBackupDatabaseOperation: String, Equatable, Sendable {
    case openSource
    case openDestination
    case initializeSnapshot
    case copySnapshot
    case finishSnapshot
    case integrityCheck
    case closeDatabase
}

public enum LocalBackupError: Error, Equatable, Sendable {
    case sourceStoreMissing
    case unsafeSymbolicLink
    case unrecognizedStoreSchema
    case packageAlreadyExists
    case malformedPackage
    case unsupportedFormat(expected: Int, actual: Int)
    case incompatibleSchema(expected: String, actual: String)
    case checksumMismatch
    case databaseIntegrityCheckFailed
    case confirmationRequired
    case targetStoreMustBeClosed
    case backupChangedSincePreview
    case targetChangedSincePreview
    case fileOperationFailed(LocalBackupFileOperation)
    case databaseOperationFailed(LocalBackupDatabaseOperation, code: Int32)
}
