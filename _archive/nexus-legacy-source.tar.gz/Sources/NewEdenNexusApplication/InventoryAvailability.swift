import Foundation
import NewEdenNexusDomain

public struct InventoryAvailabilityConfigurationDraft:
    Equatable,
    Sendable
{
    public let mode: InventoryAvailabilityMode
    public let includedLocationIDs: [UUID]
    public let excludedTypeIDs: [Int64]
    public let caps: [InventoryAvailabilityCap]

    public init(
        mode: InventoryAvailabilityMode,
        includedLocationIDs: [UUID] = [],
        excludedTypeIDs: [Int64] = [],
        caps: [InventoryAvailabilityCap] = []
    ) {
        self.mode = mode
        self.includedLocationIDs = includedLocationIDs
        self.excludedTypeIDs = excludedTypeIDs
        self.caps = caps
    }

    public init(_ configuration: InventoryAvailabilityConfigurationSnapshot) {
        self.init(
            mode: configuration.mode,
            includedLocationIDs: configuration.includedLocationIDs,
            excludedTypeIDs: configuration.excludedTypeIDs,
            caps: configuration.caps
        )
    }
}

public struct InventoryAvailabilityState: Equatable, Sendable {
    public let locations: [StorageLocationSnapshot]
    public let stocks: [ManualStockSnapshot]

    public init(
        locations: [StorageLocationSnapshot],
        stocks: [ManualStockSnapshot]
    ) {
        self.locations = locations
        self.stocks = stocks
    }
}

public struct InventoryAvailabilitySourceVersion:
    Equatable,
    Sendable
{
    public struct Location: Equatable, Sendable {
        public let id: UUID
        public let updatedAt: Date
        public let isArchived: Bool
    }

    public struct Stock: Equatable, Sendable {
        public let id: UUID
        public let locationID: UUID
        public let typeID: Int64
        public let quantity: Int64
        public let updatedAt: Date
    }

    public let projectUpdatedAt: Date
    public let graphID: UUID
    public let graphUpdatedAt: Date
    public let locations: [Location]
    public let stocks: [Stock]
    public let storedConfigurationUpdatedAt: Date?
}

public struct InventoryAvailabilityPreview: Equatable, Sendable {
    public let projectID: UUID
    public let graphID: UUID
    public let calculatedAt: Date
    public let sourceVersion: InventoryAvailabilitySourceVersion
    public let storedConfiguration:
        InventoryAvailabilityConfigurationSnapshot?
    public let proposedConfiguration:
        InventoryAvailabilityConfigurationSnapshot
    public let locations: [StorageLocationSnapshot]
    public let calculation: InventoryAvailabilityCalculation
    public let unusedLocationRuleIDs: [UUID]
    public let unusedMaterialRuleTypeIDs: [Int64]
}

public enum InventoryAvailabilityServiceError:
    Error,
    Equatable,
    Sendable
{
    case projectNotFound(UUID)
    case archivedProject(UUID)
    case graphRequired(UUID)
    case staleGraph(UUID)
    case aggregationRequired(UUID)
    case invalidAggregationFormula(Int)
    case unknownLocation(UUID)
    case unknownMaterial(Int64)
    case confirmationRequired
    case stalePreview
    case persistenceFailure
}

public protocol InventoryAvailabilityRepository: Sendable {
    func availabilityConfiguration(projectID: UUID) async throws
        -> InventoryAvailabilityConfigurationSnapshot?
    func availabilityState() async throws -> InventoryAvailabilityState
    func saveAvailabilityConfiguration(
        _ configuration: InventoryAvailabilityConfigurationSnapshot,
        expectedStoredUpdatedAt: Date?
    ) async throws
}

public protocol InventoryAvailabilityManaging: Sendable {
    func preview(
        projectID: UUID,
        draft: InventoryAvailabilityConfigurationDraft?
    ) async throws -> InventoryAvailabilityPreview

    func apply(
        _ preview: InventoryAvailabilityPreview,
        confirmed: Bool
    ) async throws -> InventoryAvailabilityPreview
}

public struct InventoryAvailabilityService:
    InventoryAvailabilityManaging,
    Sendable
{
    private let repository: any InventoryAvailabilityRepository
    private let projectRepository: any ProductionProjectRepository
    private let graphRepository: any ProductionGraphRepository
    private let calculator: InventoryAvailabilityCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any InventoryAvailabilityRepository,
        projectRepository: any ProductionProjectRepository,
        graphRepository: any ProductionGraphRepository,
        calculator: InventoryAvailabilityCalculator = .init(),
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.repository = repository
        self.projectRepository = projectRepository
        self.graphRepository = graphRepository
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func preview(
        projectID: UUID,
        draft: InventoryAvailabilityConfigurationDraft? = nil
    ) async throws -> InventoryAvailabilityPreview {
        try Task.checkCancellation()
        let inputs = try await readInputs(projectID: projectID)
        let timestamp = now()
        let proposed = try makeConfiguration(
            projectID: projectID,
            stored: inputs.storedConfiguration,
            draft: draft,
            timestamp: timestamp
        )
        try validateReferences(
            configuration: proposed,
            state: inputs.state,
            requirements: inputs.aggregation.lines,
            storedConfiguration: inputs.storedConfiguration
        )
        try Task.checkCancellation()
        let calculation = try calculator.calculate(
            requirements: inputs.aggregation.lines,
            locations: inputs.state.locations,
            stocks: inputs.state.stocks,
            configuration: proposed
        )
        return InventoryAvailabilityPreview(
            projectID: projectID,
            graphID: inputs.graph.id,
            calculatedAt: timestamp,
            sourceVersion: inputs.sourceVersion,
            storedConfiguration: inputs.storedConfiguration,
            proposedConfiguration: proposed,
            locations: inputs.state.locations,
            calculation: calculation,
            unusedLocationRuleIDs: unusedLocationRuleIDs(
                configuration: proposed,
                state: inputs.state
            ),
            unusedMaterialRuleTypeIDs: unusedMaterialRuleTypeIDs(
                configuration: proposed,
                requirements: inputs.aggregation.lines
            )
        )
    }

    public func apply(
        _ preview: InventoryAvailabilityPreview,
        confirmed: Bool
    ) async throws -> InventoryAvailabilityPreview {
        guard confirmed else {
            throw InventoryAvailabilityServiceError.confirmationRequired
        }
        try Task.checkCancellation()
        let inputs = try await readInputs(projectID: preview.projectID)
        guard inputs.sourceVersion == preview.sourceVersion,
              inputs.graph.id == preview.graphID else {
            throw InventoryAvailabilityServiceError.stalePreview
        }
        try validateReferences(
            configuration: preview.proposedConfiguration,
            state: inputs.state,
            requirements: inputs.aggregation.lines,
            storedConfiguration: inputs.storedConfiguration
        )
        let calculation = try calculator.calculate(
            requirements: inputs.aggregation.lines,
            locations: inputs.state.locations,
            stocks: inputs.state.stocks,
            configuration: preview.proposedConfiguration
        )
        try Task.checkCancellation()
        do {
            try await repository.saveAvailabilityConfiguration(
                preview.proposedConfiguration,
                expectedStoredUpdatedAt:
                    preview.storedConfiguration?.updatedAt
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw InventoryAvailabilityServiceError.persistenceFailure
        }
        let committedSourceVersion = InventoryAvailabilitySourceVersion(
            projectUpdatedAt: inputs.sourceVersion.projectUpdatedAt,
            graphID: inputs.sourceVersion.graphID,
            graphUpdatedAt: inputs.sourceVersion.graphUpdatedAt,
            locations: inputs.sourceVersion.locations,
            stocks: inputs.sourceVersion.stocks,
            storedConfigurationUpdatedAt:
                preview.proposedConfiguration.updatedAt
        )
        return InventoryAvailabilityPreview(
            projectID: preview.projectID,
            graphID: preview.graphID,
            calculatedAt: now(),
            sourceVersion: committedSourceVersion,
            storedConfiguration: preview.proposedConfiguration,
            proposedConfiguration: preview.proposedConfiguration,
            locations: inputs.state.locations,
            calculation: calculation,
            unusedLocationRuleIDs: unusedLocationRuleIDs(
                configuration: preview.proposedConfiguration,
                state: inputs.state
            ),
            unusedMaterialRuleTypeIDs: unusedMaterialRuleTypeIDs(
                configuration: preview.proposedConfiguration,
                requirements: inputs.aggregation.lines
            )
        )
    }

    private struct Inputs {
        let project: ProductionProjectSnapshot
        let graph: ProductionGraphSnapshot
        let aggregation: ProductionGraphMaterialAggregation
        let storedConfiguration:
            InventoryAvailabilityConfigurationSnapshot?
        let state: InventoryAvailabilityState
        let sourceVersion: InventoryAvailabilitySourceVersion
    }

    private func readInputs(projectID: UUID) async throws -> Inputs {
        guard let project = try await projectRepository.project(id: projectID)
        else {
            throw InventoryAvailabilityServiceError.projectNotFound(projectID)
        }
        guard project.status != .archived else {
            throw InventoryAvailabilityServiceError.archivedProject(projectID)
        }
        try Task.checkCancellation()
        guard let graph = try await graphRepository.graph(projectID: projectID)
        else {
            throw InventoryAvailabilityServiceError.graphRequired(projectID)
        }
        guard !ProductionGraphFreshness.isStale(graph, for: project) else {
            throw InventoryAvailabilityServiceError.staleGraph(projectID)
        }
        guard let aggregation = graph.materialAggregation else {
            throw InventoryAvailabilityServiceError
                .aggregationRequired(projectID)
        }
        guard aggregation.formulaVersion
                == ProductionGraphMaterialAggregation.currentFormulaVersion
        else {
            throw InventoryAvailabilityServiceError
                .invalidAggregationFormula(aggregation.formulaVersion)
        }
        async let stored = repository.availabilityConfiguration(
            projectID: projectID
        )
        async let state = repository.availabilityState()
        let (storedConfiguration, inventoryState) = try await (stored, state)
        try Task.checkCancellation()
        let sourceVersion = InventoryAvailabilitySourceVersion(
            projectUpdatedAt: project.updatedAt,
            graphID: graph.id,
            graphUpdatedAt: graph.updatedAt,
            locations: inventoryState.locations.map {
                .init(
                    id: $0.id,
                    updatedAt: $0.updatedAt,
                    isArchived: $0.isArchived
                )
            }.sorted { $0.id.uuidString < $1.id.uuidString },
            stocks: inventoryState.stocks.map {
                .init(
                    id: $0.id,
                    locationID: $0.locationID,
                    typeID: $0.typeID,
                    quantity: $0.quantity,
                    updatedAt: $0.updatedAt
                )
            }.sorted { $0.id.uuidString < $1.id.uuidString },
            storedConfigurationUpdatedAt: storedConfiguration?.updatedAt
        )
        return Inputs(
            project: project,
            graph: graph,
            aggregation: aggregation,
            storedConfiguration: storedConfiguration,
            state: inventoryState,
            sourceVersion: sourceVersion
        )
    }

    private func makeConfiguration(
        projectID: UUID,
        stored: InventoryAvailabilityConfigurationSnapshot?,
        draft: InventoryAvailabilityConfigurationDraft?,
        timestamp: Date
    ) throws -> InventoryAvailabilityConfigurationSnapshot {
        if draft == nil, let stored {
            return stored
        }
        let selectedDraft = draft ?? stored.map {
            InventoryAvailabilityConfigurationDraft($0)
        } ?? InventoryAvailabilityConfigurationDraft(
            mode: .allActiveLocations
        )
        return try InventoryAvailabilityConfigurationSnapshot(
            id: stored?.id ?? makeID(),
            projectID: projectID,
            mode: selectedDraft.mode,
            includedLocationIDs: selectedDraft.includedLocationIDs,
            excludedTypeIDs: selectedDraft.excludedTypeIDs,
            caps: selectedDraft.caps,
            createdAt: stored?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
    }

    private func validateReferences(
        configuration: InventoryAvailabilityConfigurationSnapshot,
        state: InventoryAvailabilityState,
        requirements: [ProductionGraphMaterialLine],
        storedConfiguration:
            InventoryAvailabilityConfigurationSnapshot?
    ) throws {
        let knownLocations = Set(state.locations.map(\.id))
        for locationID in configuration.includedLocationIDs
        where !knownLocations.contains(locationID) {
            throw InventoryAvailabilityServiceError
                .unknownLocation(locationID)
        }
        let requirementIDs = Set(requirements.map(\.typeID))
        let storedRuleIDs = Set(
            (storedConfiguration?.excludedTypeIDs ?? [])
                + (storedConfiguration?.caps.map(\.typeID) ?? [])
        )
        for typeID in configuration.excludedTypeIDs
        where !requirementIDs.contains(typeID)
            && !storedRuleIDs.contains(typeID) {
            throw InventoryAvailabilityServiceError.unknownMaterial(typeID)
        }
        for cap in configuration.caps
        where !requirementIDs.contains(cap.typeID)
            && !storedRuleIDs.contains(cap.typeID) {
            throw InventoryAvailabilityServiceError
                .unknownMaterial(cap.typeID)
        }
    }

    private func unusedLocationRuleIDs(
        configuration: InventoryAvailabilityConfigurationSnapshot,
        state: InventoryAvailabilityState
    ) -> [UUID] {
        let activeIDs = Set(
            state.locations.filter { !$0.isArchived }.map(\.id)
        )
        return configuration.includedLocationIDs.filter {
            !activeIDs.contains($0)
        }
    }

    private func unusedMaterialRuleTypeIDs(
        configuration: InventoryAvailabilityConfigurationSnapshot,
        requirements: [ProductionGraphMaterialLine]
    ) -> [Int64] {
        let requirementIDs = Set(requirements.map(\.typeID))
        return (
            configuration.excludedTypeIDs
                + configuration.caps.map(\.typeID)
        ).filter { !requirementIDs.contains($0) }.sorted()
    }
}
