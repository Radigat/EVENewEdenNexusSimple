import Foundation
import NewEdenNexusDomain

public struct ShoppingQuantityOverrideSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let typeID: Int64
    public let quantity: Int64
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        typeID: Int64,
        quantity: Int64,
        createdAt: Date,
        updatedAt: Date
    ) {
        self.id = id
        self.projectID = projectID
        self.typeID = typeID
        self.quantity = quantity
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct ShoppingQuantityDraft: Equatable, Sendable {
    public let typeID: Int64
    public let quantity: Int64

    public init(typeID: Int64, quantity: Int64) {
        self.typeID = typeID
        self.quantity = quantity
    }
}

public struct ShoppingQuantityOverrideVersion: Equatable, Sendable {
    public let id: UUID
    public let updatedAt: Date

    public init(id: UUID, updatedAt: Date) {
        self.id = id
        self.updatedAt = updatedAt
    }
}

public struct ShoppingListSourceVersion: Equatable, Sendable {
    public let plan: BuildOrBuyPlanSourceVersion
    public let overrides: [ShoppingQuantityOverrideVersion]
}

public struct ShoppingListPreview: Equatable, Sendable {
    public let projectID: UUID
    public let graphID: UUID
    public let calculatedAt: Date
    public let planPreview: BuildOrBuyPlanPreview
    public let sourceVersion: ShoppingListSourceVersion
    public let storedOverrides: [ShoppingQuantityOverrideSnapshot]
    public let proposedOverrides: [ShoppingQuantityOverrideSnapshot]
    public let staleStoredOverrideTypeIDs: [Int64]
    public let aggregation: ShoppingListAggregation
}

public enum ShoppingListManagementError:
    Error,
    Equatable,
    Sendable
{
    case confirmationRequired
    case duplicateDraftTypeID(Int64)
    case invalidDraft(typeID: Int64, quantity: Int64)
    case unknownDraftTypeID(Int64)
    case missingDraftTypeIDs([Int64])
    case stalePreview
    case invalidStoredOverride(Int64)
    case calculationFailed
    case persistenceFailure
}

public enum ShoppingQuantityOverrideRepositoryError:
    Error,
    Equatable,
    Sendable
{
    case staleState
}

public protocol ShoppingQuantityOverrideRepository: Sendable {
    func overrides(projectID: UUID) async throws
        -> [ShoppingQuantityOverrideSnapshot]

    func replaceOverrides(
        _ overrides: [ShoppingQuantityOverrideSnapshot],
        projectID: UUID,
        expectedVersions: [ShoppingQuantityOverrideVersion]
    ) async throws
}

public protocol ShoppingListManaging: Sendable {
    func load(
        planPreview: BuildOrBuyPlanPreview
    ) async throws -> ShoppingListPreview

    func preview(
        planPreview: BuildOrBuyPlanPreview,
        quantities: [ShoppingQuantityDraft]
    ) async throws -> ShoppingListPreview

    func apply(
        _ preview: ShoppingListPreview,
        confirmed: Bool
    ) async throws -> ShoppingListPreview
}

public struct ShoppingListManagementService:
    ShoppingListManaging,
    Sendable
{
    private let repository: any ShoppingQuantityOverrideRepository
    private let planning: any BuildOrBuyPlanning
    private let aggregator: ShoppingListAggregator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any ShoppingQuantityOverrideRepository,
        planning: any BuildOrBuyPlanning,
        aggregator: ShoppingListAggregator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.repository = repository
        self.planning = planning
        self.aggregator = aggregator
        self.now = now
        self.makeID = makeID
    }

    public func load(
        planPreview: BuildOrBuyPlanPreview
    ) async throws -> ShoppingListPreview {
        try await makePreview(
            planPreview: planPreview,
            drafts: nil
        )
    }

    public func preview(
        planPreview: BuildOrBuyPlanPreview,
        quantities: [ShoppingQuantityDraft]
    ) async throws -> ShoppingListPreview {
        try await makePreview(
            planPreview: planPreview,
            drafts: quantities
        )
    }

    public func apply(
        _ preview: ShoppingListPreview,
        confirmed: Bool
    ) async throws -> ShoppingListPreview {
        guard confirmed else {
            throw ShoppingListManagementError.confirmationRequired
        }
        try Task.checkCancellation()
        let currentPlan = try await planning.preview(
            projectID: preview.projectID,
            decisions: nil
        )
        guard currentPlan.sourceVersion
                == preview.planPreview.sourceVersion,
              currentPlan.plan == preview.planPreview.plan else {
            throw ShoppingListManagementError.stalePreview
        }
        let drafts = preview.aggregation.positions.map {
            ShoppingQuantityDraft(
                typeID: $0.typeID,
                quantity: $0.purchaseQuantity
            )
        }
        let fresh = try await makePreview(
            planPreview: currentPlan,
            drafts: drafts
        )
        guard fresh.sourceVersion == preview.sourceVersion,
              fresh.aggregation == preview.aggregation else {
            throw ShoppingListManagementError.stalePreview
        }
        try Task.checkCancellation()
        do {
            try await repository.replaceOverrides(
                fresh.proposedOverrides,
                projectID: preview.projectID,
                expectedVersions: preview.sourceVersion.overrides
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch ShoppingQuantityOverrideRepositoryError.staleState {
            throw ShoppingListManagementError.stalePreview
        } catch {
            throw ShoppingListManagementError.persistenceFailure
        }
        return ShoppingListPreview(
            projectID: fresh.projectID,
            graphID: fresh.graphID,
            calculatedAt: fresh.calculatedAt,
            planPreview: fresh.planPreview,
            sourceVersion: ShoppingListSourceVersion(
                plan: fresh.sourceVersion.plan,
                overrides: fresh.proposedOverrides.map {
                    ShoppingQuantityOverrideVersion(
                        id: $0.id,
                        updatedAt: $0.updatedAt
                    )
                }.sorted { $0.id.uuidString < $1.id.uuidString }
            ),
            storedOverrides: fresh.proposedOverrides,
            proposedOverrides: fresh.proposedOverrides,
            staleStoredOverrideTypeIDs: [],
            aggregation: fresh.aggregation
        )
    }

    private func makePreview(
        planPreview: BuildOrBuyPlanPreview,
        drafts: [ShoppingQuantityDraft]?
    ) async throws -> ShoppingListPreview {
        try Task.checkCancellation()
        let stored: [ShoppingQuantityOverrideSnapshot]
        do {
            stored = try await repository.overrides(
                projectID: planPreview.projectID
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ShoppingListManagementError.persistenceFailure
        }
        let base: ShoppingListAggregation
        do {
            base = try aggregator.aggregate(
                requirements: planPreview.plan.requirements,
                overrides: []
            )
        } catch {
            throw ShoppingListManagementError.calculationFailed
        }
        let baseByTypeID = Dictionary(
            uniqueKeysWithValues: base.positions.map {
                ($0.typeID, $0)
            }
        )
        let stale = stored.filter {
            baseByTypeID[$0.typeID] == nil
        }.map(\.typeID).sorted()
        let proposal = try proposedOverrides(
            projectID: planPreview.projectID,
            baseByTypeID: baseByTypeID,
            stored: stored,
            drafts: drafts
        )
        let aggregation: ShoppingListAggregation
        do {
            aggregation = try aggregator.aggregate(
                requirements: planPreview.plan.requirements,
                overrides: proposal.map {
                    ShoppingQuantityOverride(
                        typeID: $0.typeID,
                        quantity: $0.quantity
                    )
                }
            )
        } catch {
            throw ShoppingListManagementError.calculationFailed
        }
        return ShoppingListPreview(
            projectID: planPreview.projectID,
            graphID: planPreview.plan.graphID,
            calculatedAt: now(),
            planPreview: planPreview,
            sourceVersion: ShoppingListSourceVersion(
                plan: planPreview.sourceVersion,
                overrides: stored.map {
                    ShoppingQuantityOverrideVersion(
                        id: $0.id,
                        updatedAt: $0.updatedAt
                    )
                }.sorted { $0.id.uuidString < $1.id.uuidString }
            ),
            storedOverrides: stored.sorted { $0.typeID < $1.typeID },
            proposedOverrides: proposal.sorted { $0.typeID < $1.typeID },
            staleStoredOverrideTypeIDs: stale,
            aggregation: aggregation
        )
    }

    private func proposedOverrides(
        projectID: UUID,
        baseByTypeID: [Int64: ShoppingListPosition],
        stored: [ShoppingQuantityOverrideSnapshot],
        drafts: [ShoppingQuantityDraft]?
    ) throws -> [ShoppingQuantityOverrideSnapshot] {
        var storedByTypeID: [Int64: ShoppingQuantityOverrideSnapshot] = [:]
        for item in stored {
            guard item.projectID == projectID,
                  item.typeID > 0,
                  item.quantity >= 0,
                  storedByTypeID[item.typeID] == nil else {
                throw ShoppingListManagementError
                    .invalidStoredOverride(item.typeID)
            }
            storedByTypeID[item.typeID] = item
        }
        guard let drafts else {
            return stored.filter { baseByTypeID[$0.typeID] != nil }
        }

        var draftByTypeID: [Int64: Int64] = [:]
        for draft in drafts {
            guard draft.typeID > 0, draft.quantity >= 0 else {
                throw ShoppingListManagementError.invalidDraft(
                    typeID: draft.typeID,
                    quantity: draft.quantity
                )
            }
            guard baseByTypeID[draft.typeID] != nil else {
                throw ShoppingListManagementError
                    .unknownDraftTypeID(draft.typeID)
            }
            guard draftByTypeID[draft.typeID] == nil else {
                throw ShoppingListManagementError
                    .duplicateDraftTypeID(draft.typeID)
            }
            draftByTypeID[draft.typeID] = draft.quantity
        }
        let missing = Set(baseByTypeID.keys)
            .subtracting(draftByTypeID.keys)
            .sorted()
        guard missing.isEmpty else {
            throw ShoppingListManagementError.missingDraftTypeIDs(
                missing
            )
        }

        let timestamp = now()
        return baseByTypeID.values.compactMap { base in
            guard let quantity = draftByTypeID[base.typeID],
                  quantity != base.calculatedQuantity else {
                return nil
            }
            let current = storedByTypeID[base.typeID]
            return ShoppingQuantityOverrideSnapshot(
                id: current?.id ?? makeID(),
                projectID: projectID,
                typeID: base.typeID,
                quantity: quantity,
                createdAt: current?.createdAt ?? timestamp,
                updatedAt: timestamp
            )
        }
    }
}
