import Foundation
import NewEdenNexusDomain

public protocol ProductionBatchSaleRepository: Sendable {
    func allocations(
        batchID: UUID?
    ) async throws -> [ProductionBatchSaleAllocationSnapshot]
    func save(
        _ allocation: ProductionBatchSaleAllocationSnapshot,
        expectedBatchAllocations: [ProductionBatchSaleAllocationSnapshot]
    ) async throws
}

public enum ProductionBatchSaleDraftSource:
    Equatable,
    Sendable
{
    case walletTransaction(
        projectAssignmentID: UUID,
        quantity: Int64
    )
    case walletJournal(
        projectAssignmentID: UUID,
        amountHundredths: Int64
    )
    case manualSale(
        quantity: Int64,
        amountHundredths: Int64,
        date: Date,
        reason: String
    )
    case manualFee(
        amountHundredths: Int64,
        date: Date,
        reason: String
    )
}

public struct ProductionBatchSaleDraft: Equatable, Sendable {
    public let batchID: UUID
    public let source: ProductionBatchSaleDraftSource

    public init(
        batchID: UUID,
        source: ProductionBatchSaleDraftSource
    ) {
        self.batchID = batchID
        self.source = source
    }
}

public struct ProductionBatchTransactionEvidence:
    Identifiable,
    Equatable,
    Sendable
{
    public var id: UUID { projectAssignment.id }
    public let projectAssignment: WalletProjectAssignmentSnapshot
    public let transaction: ESIWalletTransaction
    public let walletRevision: UUID
    public let remainingQuantity: Int64
    public let remainingAmountHundredths: Int64
}

public struct ProductionBatchJournalEvidence:
    Identifiable,
    Equatable,
    Sendable
{
    public var id: UUID { projectAssignment.id }
    public let projectAssignment: WalletProjectAssignmentSnapshot
    public let entry: ESIWalletJournalEntry
    public let walletRevision: UUID
    public let remainingAmountHundredths: Int64
}

public struct ProductionBatchSaleWorkspace:
    Equatable,
    Sendable
{
    public let batch: ProductionBatchSnapshot
    public let costSnapshot: ProductionBatchCostSnapshot?
    public let allocations: [ProductionBatchSaleAllocationSnapshot]
    public let summary: ProductionBatchRealizedSummary?
    public let transactions: [ProductionBatchTransactionEvidence]
    public let journals: [ProductionBatchJournalEvidence]
    public let unavailableWalletSourceCount: Int
}

public struct ProductionBatchSalePreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let allocation: ProductionBatchSaleAllocationSnapshot
    public let summaryAfter: ProductionBatchRealizedSummary
    public let sourceRemainingQuantity: Int64?
    public let sourceRemainingAmountHundredths: Int64?
}

public enum ProductionBatchSaleManagementError:
    Error,
    Equatable,
    Sendable
{
    case batchNotFound(UUID)
    case costBasisMissing
    case projectAssignmentNotFound(UUID)
    case sourceNotFound
    case sourceNotEligible
    case sourceCapacityExceeded
    case stalePreview
    case previewNotFound
    case confirmationRequired
    case persistenceFailure
}

public protocol ProductionBatchSaleManaging: Sendable {
    func workspace(
        batchID: UUID
    ) async throws -> ProductionBatchSaleWorkspace
    func preview(
        _ draft: ProductionBatchSaleDraft
    ) async throws -> ProductionBatchSalePreview
    func apply(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> ProductionBatchSaleAllocationSnapshot
    func discard(previewID: UUID) async
}

public actor ProductionBatchSaleManagementService:
    ProductionBatchSaleManaging
{
    private struct Pending {
        let preview: ProductionBatchSalePreview
        let batchUpdatedAt: Date
        let existing: [ProductionBatchSaleAllocationSnapshot]
        let projectAssignment: WalletProjectAssignmentSnapshot?
        let walletRevision: UUID?
    }

    private let batches: any ProductionBatchRepository
    private let costs: any ProductionBatchCostRepository
    private let wallets: any ESIWalletPersisting
    private let projectAssignments: any WalletProjectAssignmentRepository
    private let sales: any ProductionBatchSaleRepository
    private let calculator: ProductionBatchRealizedCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var pending: [UUID: Pending] = [:]

    public init(
        batches: any ProductionBatchRepository,
        costs: any ProductionBatchCostRepository,
        wallets: any ESIWalletPersisting,
        projectAssignments: any WalletProjectAssignmentRepository,
        sales: any ProductionBatchSaleRepository,
        calculator: ProductionBatchRealizedCalculator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.batches = batches
        self.costs = costs
        self.wallets = wallets
        self.projectAssignments = projectAssignments
        self.sales = sales
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func workspace(
        batchID: UUID
    ) async throws -> ProductionBatchSaleWorkspace {
        guard let batch = try await batches.batch(id: batchID) else {
            throw ProductionBatchSaleManagementError.batchNotFound(
                batchID
            )
        }
        let allocations = try await sales.allocations(batchID: batchID)
        let costSnapshots = try await costs.snapshots(batchID: batchID)
        let costSnapshot = lockedCost(
            allocations: allocations,
            costs: costSnapshots
        )
        let summary: ProductionBatchRealizedSummary?
        if let costSnapshot,
           let totalCost = costSnapshot.calculation.totalCost {
            summary = try calculator.calculate(
                batchID: batch.id,
                costSnapshotID: costSnapshot.id,
                outputUnits: batch.outputUnits,
                totalCostHundredths: totalCost.hundredths,
                allocations: allocations
            )
        } else {
            summary = nil
        }

        let assignments = try await projectAssignments.assignments(
            projectID: batch.projectID
        )
        var walletCache: [Int64: ESIWalletSnapshot?] = [:]
        var transactionOptions: [ProductionBatchTransactionEvidence] = []
        var journalOptions: [ProductionBatchJournalEvidence] = []
        var unavailable = 0
        for assignment in assignments {
            let wallet: ESIWalletSnapshot?
            if let cached = walletCache[assignment.characterID] {
                wallet = cached
            } else {
                wallet = try await wallets.snapshot(
                    characterID: assignment.characterID
                )
                walletCache[assignment.characterID] = wallet
            }
            guard let wallet else {
                unavailable += 1
                continue
            }
            let consumed = allocations.filter {
                $0.projectAssignmentID == assignment.id
            }
            let usedQuantity = try sum(consumed.map(\.quantity))
            let usedAmount = try sum(
                consumed.map(\.amountHundredths)
            )
            let remainingQuantity =
                assignment.assignedQuantity - usedQuantity
            let remainingAmount =
                assignment.assignedAmountHundredths - usedAmount
            guard remainingQuantity >= 0, remainingAmount >= 0 else {
                throw ProductionBatchSaleManagementError
                    .sourceCapacityExceeded
            }
            if assignment.sourceKind == .transaction,
               assignment.direction == .revenue,
               remainingQuantity > 0,
               remainingAmount > 0,
               let transaction = wallet.transactions.first(where: {
                   $0.transactionID == assignment.sourceID
               }),
               !transaction.isBuy,
               transaction.typeID == batch.productTypeID {
                transactionOptions.append(
                    ProductionBatchTransactionEvidence(
                        projectAssignment: assignment,
                        transaction: transaction,
                        walletRevision: wallet.revision,
                        remainingQuantity: remainingQuantity,
                        remainingAmountHundredths: remainingAmount
                    )
                )
            } else if assignment.sourceKind == .journal,
                      assignment.direction == .cost,
                      remainingAmount > 0,
                      let entry = wallet.journal.first(where: {
                          $0.id == assignment.sourceID
                      }),
                      Self.isSaleFee(entry) {
                journalOptions.append(
                    ProductionBatchJournalEvidence(
                        projectAssignment: assignment,
                        entry: entry,
                        walletRevision: wallet.revision,
                        remainingAmountHundredths: remainingAmount
                    )
                )
            }
        }
        return ProductionBatchSaleWorkspace(
            batch: batch,
            costSnapshot: costSnapshot,
            allocations: allocations,
            summary: summary,
            transactions: transactionOptions.sorted {
                $0.transaction.date > $1.transaction.date
            },
            journals: journalOptions.sorted {
                $0.entry.date > $1.entry.date
            },
            unavailableWalletSourceCount: unavailable
        )
    }

    public func preview(
        _ draft: ProductionBatchSaleDraft
    ) async throws -> ProductionBatchSalePreview {
        let workspace = try await workspace(batchID: draft.batchID)
        guard let cost = workspace.costSnapshot,
              let totalCost = cost.calculation.totalCost else {
            throw ProductionBatchSaleManagementError.costBasisMissing
        }
        let timestamp = now()
        let allocation: ProductionBatchSaleAllocationSnapshot
        let projectAssignment: WalletProjectAssignmentSnapshot?
        let walletRevision: UUID?
        let remainingQuantity: Int64?
        let remainingAmount: Int64?

        switch draft.source {
        case .walletTransaction(let assignmentID, let quantity):
            guard let option = workspace.transactions.first(where: {
                $0.id == assignmentID
            }) else {
                throw ProductionBatchSaleManagementError
                    .projectAssignmentNotFound(assignmentID)
            }
            guard quantity > 0,
                  quantity <= option.remainingQuantity else {
                throw ProductionBatchSaleManagementError
                    .sourceCapacityExceeded
            }
            let amount = try option.transaction.amountHundredths(
                quantity: quantity
            )
            guard amount <= option.remainingAmountHundredths else {
                throw ProductionBatchSaleManagementError
                    .sourceCapacityExceeded
            }
            allocation = try ProductionBatchSaleAllocationSnapshot(
                id: makeID(),
                batchID: workspace.batch.id,
                projectID: workspace.batch.projectID,
                costSnapshotID: cost.id,
                kind: .sale,
                source: .walletTransaction,
                projectAssignmentID: option.projectAssignment.id,
                characterID: option.projectAssignment.characterID,
                sourceID: option.transaction.transactionID,
                sourceRevision: option.walletRevision,
                sourceObservedAt: option.transaction.date,
                quantity: quantity,
                amountHundredths: amount,
                reason: nil,
                createdAt: timestamp
            )
            projectAssignment = option.projectAssignment
            walletRevision = option.walletRevision
            remainingQuantity = option.remainingQuantity - quantity
            remainingAmount =
                option.remainingAmountHundredths - amount

        case .walletJournal(let assignmentID, let amount):
            guard let option = workspace.journals.first(where: {
                $0.id == assignmentID
            }) else {
                throw ProductionBatchSaleManagementError
                    .projectAssignmentNotFound(assignmentID)
            }
            guard amount > 0,
                  amount <= option.remainingAmountHundredths else {
                throw ProductionBatchSaleManagementError
                    .sourceCapacityExceeded
            }
            allocation = try ProductionBatchSaleAllocationSnapshot(
                id: makeID(),
                batchID: workspace.batch.id,
                projectID: workspace.batch.projectID,
                costSnapshotID: cost.id,
                kind: .fee,
                source: .walletJournal,
                projectAssignmentID: option.projectAssignment.id,
                characterID: option.projectAssignment.characterID,
                sourceID: option.entry.id,
                sourceRevision: option.walletRevision,
                sourceObservedAt: option.entry.date,
                quantity: 0,
                amountHundredths: amount,
                reason: nil,
                createdAt: timestamp
            )
            projectAssignment = option.projectAssignment
            walletRevision = option.walletRevision
            remainingQuantity = nil
            remainingAmount =
                option.remainingAmountHundredths - amount

        case .manualSale(
            let quantity,
            let amount,
            let date,
            let reason
        ):
            allocation = try ProductionBatchSaleAllocationSnapshot(
                id: makeID(),
                batchID: workspace.batch.id,
                projectID: workspace.batch.projectID,
                costSnapshotID: cost.id,
                kind: .sale,
                source: .manual,
                projectAssignmentID: nil,
                characterID: nil,
                sourceID: nil,
                sourceRevision: nil,
                sourceObservedAt: date,
                quantity: quantity,
                amountHundredths: amount,
                reason: reason,
                createdAt: timestamp
            )
            projectAssignment = nil
            walletRevision = nil
            remainingQuantity = nil
            remainingAmount = nil

        case .manualFee(let amount, let date, let reason):
            allocation = try ProductionBatchSaleAllocationSnapshot(
                id: makeID(),
                batchID: workspace.batch.id,
                projectID: workspace.batch.projectID,
                costSnapshotID: cost.id,
                kind: .fee,
                source: .manual,
                projectAssignmentID: nil,
                characterID: nil,
                sourceID: nil,
                sourceRevision: nil,
                sourceObservedAt: date,
                quantity: 0,
                amountHundredths: amount,
                reason: reason,
                createdAt: timestamp
            )
            projectAssignment = nil
            walletRevision = nil
            remainingQuantity = nil
            remainingAmount = nil
        }

        let summary = try calculator.calculate(
            batchID: workspace.batch.id,
            costSnapshotID: cost.id,
            outputUnits: workspace.batch.outputUnits,
            totalCostHundredths: totalCost.hundredths,
            allocations: workspace.allocations + [allocation]
        )
        let preview = ProductionBatchSalePreview(
            id: makeID(),
            allocation: allocation,
            summaryAfter: summary,
            sourceRemainingQuantity: remainingQuantity,
            sourceRemainingAmountHundredths: remainingAmount
        )
        pending.removeAll()
        pending[preview.id] = Pending(
            preview: preview,
            batchUpdatedAt: workspace.batch.updatedAt,
            existing: workspace.allocations,
            projectAssignment: projectAssignment,
            walletRevision: walletRevision
        )
        return preview
    }

    public func apply(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> ProductionBatchSaleAllocationSnapshot {
        guard confirmed else {
            throw ProductionBatchSaleManagementError.confirmationRequired
        }
        guard let pending = pending[previewID] else {
            throw ProductionBatchSaleManagementError.previewNotFound
        }
        try Task.checkCancellation()
        guard let batch = try await batches.batch(
            id: pending.preview.allocation.batchID
        ), batch.updatedAt == pending.batchUpdatedAt else {
            throw ProductionBatchSaleManagementError.stalePreview
        }
        let currentAllocations = try await sales.allocations(
            batchID: batch.id
        )
        guard currentAllocations == pending.existing else {
            throw ProductionBatchSaleManagementError.stalePreview
        }
        let costIDs = Set(
            try await costs.snapshots(batchID: batch.id).map(\.id)
        )
        guard costIDs.contains(
            pending.preview.allocation.costSnapshotID
        ) else {
            throw ProductionBatchSaleManagementError.stalePreview
        }
        if let expected = pending.projectAssignment {
            let assignments = try await projectAssignments.assignments(
                projectID: batch.projectID
            )
            guard assignments.first(where: { $0.id == expected.id })
                    == expected,
                  let revision = pending.walletRevision,
                  let wallet = try await wallets.snapshot(
                      characterID: expected.characterID
                  ),
                  wallet.revision == revision else {
                throw ProductionBatchSaleManagementError.stalePreview
            }
        }
        do {
            try await sales.save(
                pending.preview.allocation,
                expectedBatchAllocations: pending.existing
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ProductionBatchSaleManagementError.persistenceFailure
        }
        self.pending[previewID] = nil
        return pending.preview.allocation
    }

    public func discard(previewID: UUID) async {
        pending[previewID] = nil
    }

    private func lockedCost(
        allocations: [ProductionBatchSaleAllocationSnapshot],
        costs: [ProductionBatchCostSnapshot]
    ) -> ProductionBatchCostSnapshot? {
        if let lockedID = allocations.first?.costSnapshotID {
            return costs.first { $0.id == lockedID }
        }
        return costs.first {
            $0.calculation.totalCost != nil
                && $0.calculation.unitCost != nil
        }
    }

    private func sum(_ values: [Int64]) throws -> Int64 {
        try values.reduce(Int64.zero) { partial, value in
            let result = partial.addingReportingOverflow(value)
            guard !result.overflow else {
                throw ProductionBatchSaleError.arithmeticOverflow
            }
            return result.partialValue
        }
    }

    private static func isSaleFee(
        _ entry: ESIWalletJournalEntry
    ) -> Bool {
        guard let amount = entry.amountHundredths, amount < 0 else {
            return false
        }
        return entry.refType == "brokers_fee"
            || entry.refType == "transaction_tax"
    }
}
