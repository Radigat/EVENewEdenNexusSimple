import Foundation

public enum SDEManagementPhase: String, CaseIterable, Sendable {
    case idle
    case checking
    case updateAvailable
    case current
    case downloading
    case inspectingArchive
    case extractingArchive
    case validatingSource
    case importing
    case activating
    case completed
    case offline
    case schemaReviewRequired
    case failed
    case cancelled
}

public struct SDEAutomationSettings: Codable, Equatable, Sendable {
    public static let minimumCheckIntervalHours = 24

    public var automaticCheckEnabled: Bool
    public var automaticDownloadEnabled: Bool
    public var automaticInstallationEnabled: Bool
    public var checkIntervalHours: Int
    public var rollbackVersionsToKeep: Int
    public var proposeOldVersionDeletion: Bool
    public var ownerComplianceReviewed: Bool

    public init(
        automaticCheckEnabled: Bool = true,
        automaticDownloadEnabled: Bool = false,
        automaticInstallationEnabled: Bool = false,
        checkIntervalHours: Int = Self.minimumCheckIntervalHours,
        rollbackVersionsToKeep: Int = 1,
        proposeOldVersionDeletion: Bool = false,
        ownerComplianceReviewed: Bool = false
    ) {
        self.automaticCheckEnabled = automaticCheckEnabled
        self.automaticDownloadEnabled = automaticDownloadEnabled
        self.automaticInstallationEnabled =
            automaticInstallationEnabled && automaticDownloadEnabled
        self.checkIntervalHours = max(
            Self.minimumCheckIntervalHours,
            checkIntervalHours
        )
        self.rollbackVersionsToKeep = max(1, rollbackVersionsToKeep)
        self.proposeOldVersionDeletion = proposeOldVersionDeletion
        self.ownerComplianceReviewed = ownerComplianceReviewed
    }

    public mutating func normalize() {
        checkIntervalHours = max(
            Self.minimumCheckIntervalHours,
            checkIntervalHours
        )
        rollbackVersionsToKeep = max(1, rollbackVersionsToKeep)
        if !automaticDownloadEnabled {
            automaticInstallationEnabled = false
        }
    }
}

public enum SDEAutomationAction: Equatable, Sendable {
    case none
    case prefetch(buildNumber: Int)
    case install(buildNumber: Int)
}

public enum SDEAutomationPolicy {
    public static func action(
        for report: SDEUpdateCheckReport,
        settings: SDEAutomationSettings,
        hasOwnerContact: Bool
    ) -> SDEAutomationAction {
        guard report.status == .updateAvailable,
              let buildNumber = report.officialBuildNumber,
              settings.automaticDownloadEnabled,
              hasOwnerContact else {
            return .none
        }
        if settings.automaticInstallationEnabled,
           settings.ownerComplianceReviewed {
            return .install(buildNumber: buildNumber)
        }
        return .prefetch(buildNumber: buildNumber)
    }
}

public struct SDEPrefetchedArchive: Codable, Equatable, Sendable {
    public let buildNumber: Int
    public let byteCount: Int64
    public let downloadedAt: Date

    public init(
        buildNumber: Int,
        byteCount: Int64,
        downloadedAt: Date
    ) {
        self.buildNumber = buildNumber
        self.byteCount = byteCount
        self.downloadedAt = downloadedAt
    }
}

public protocol SDEArchivePrefetching: Sendable {
    func prefetch(buildNumber: Int) async throws -> SDEPrefetchedArchive
    func prefetchedArchive(buildNumber: Int) async throws
        -> SDEPrefetchedArchive?
    func removePrefetchedArchive(buildNumber: Int) async throws
}

public protocol SDEInstallationLogReading: Sendable {
    func allLogs() async throws -> [SDEInstallationLog]
}

public struct SDECatalogVersionSummary: Codable, Equatable, Sendable {
    public let buildNumber: Int
    public let contentSHA256: String
    public let importedAt: Date
    public let isActive: Bool

    public init(
        buildNumber: Int,
        contentSHA256: String,
        importedAt: Date,
        isActive: Bool
    ) {
        self.buildNumber = buildNumber
        self.contentSHA256 = contentSHA256
        self.importedAt = importedAt
        self.isActive = isActive
    }
}

public struct SDECatalogRetentionPreview: Equatable, Sendable {
    public let keepingRollbackVersions: Int
    public let retainedVersions: [SDECatalogVersionSummary]
    public let deletionCandidates: [SDECatalogVersionSummary]
    public let confirmationID: String

    public init(
        keepingRollbackVersions: Int,
        retainedVersions: [SDECatalogVersionSummary],
        deletionCandidates: [SDECatalogVersionSummary],
        confirmationID: String
    ) {
        self.keepingRollbackVersions = keepingRollbackVersions
        self.retainedVersions = retainedVersions
        self.deletionCandidates = deletionCandidates
        self.confirmationID = confirmationID
    }
}

public struct SDECatalogRetentionConfirmation: Equatable, Sendable {
    public let confirmationID: String
    public let confirmedBuildNumbers: [Int]

    public init(
        confirmationID: String,
        confirmedBuildNumbers: [Int]
    ) {
        self.confirmationID = confirmationID
        self.confirmedBuildNumbers = confirmedBuildNumbers.sorted()
    }
}

public struct SDECatalogRetentionResult: Equatable, Sendable {
    public let deletedBuildNumbers: [Int]

    public init(deletedBuildNumbers: [Int]) {
        self.deletedBuildNumbers = deletedBuildNumbers.sorted()
    }
}

public enum SDECatalogRetentionError: Error, Equatable, Sendable {
    case confirmationRequired
    case previewChanged
    case activeVersionProtected
    case rollbackVersionProtected
    case saveFailed
}

public protocol SDECatalogRetentionManaging: Sendable {
    func previewRetention(keepingRollbackVersions: Int) async throws
        -> SDECatalogRetentionPreview
    func applyRetention(
        preview: SDECatalogRetentionPreview,
        confirmation: SDECatalogRetentionConfirmation
    ) async throws -> SDECatalogRetentionResult
}

public struct SDEDiagnosticExport: Codable, Equatable, Sendable {
    public let formatIdentifier: String
    public let formatVersion: Int
    public let generatedAt: Date
    public let attempts: [Attempt]

    public struct Attempt: Codable, Equatable, Sendable {
        public let requestedBuildNumber: Int
        public let activatedBuildNumber: Int?
        public let httpStatus: Int?
        public let cacheDecision: String?
        public let downloadByteCount: Int64?
        public let counts: StaticDataCatalogCounts?
        public let backupCreated: Bool
        public let cleanupSucceeded: Bool?
        public let rollbackSucceeded: Bool?
        public let events: [Event]
    }

    public struct Event: Codable, Equatable, Sendable {
        public let phase: String
        public let occurredAt: Date
        public let safeCode: String?
    }
}

public enum SDEDiagnosticExporter {
    public static let formatIdentifier =
        "com.newedennexus.sde-diagnostics"

    public static func makeExport(
        logs: [SDEInstallationLog],
        generatedAt: Date = Date()
    ) -> SDEDiagnosticExport {
        SDEDiagnosticExport(
            formatIdentifier: formatIdentifier,
            formatVersion: 1,
            generatedAt: generatedAt,
            attempts: logs.map { log in
                SDEDiagnosticExport.Attempt(
                    requestedBuildNumber: log.requestedBuildNumber,
                    activatedBuildNumber: log.activatedBuildNumber,
                    httpStatus: log.httpStatus,
                    cacheDecision: log.cacheDecision?.rawValue,
                    downloadByteCount: log.downloadByteCount,
                    counts: log.counts,
                    backupCreated: log.backupCreated,
                    cleanupSucceeded: log.cleanupSucceeded,
                    rollbackSucceeded: log.rollbackSucceeded,
                    events: log.events.map {
                        SDEDiagnosticExport.Event(
                            phase: $0.phase.rawValue,
                            occurredAt: $0.occurredAt,
                            safeCode: $0.safeCode
                        )
                    }
                )
            }
        )
    }

    public static func encoded(
        _ export: SDEDiagnosticExport
    ) throws -> Data {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try encoder.encode(export)
    }
}
