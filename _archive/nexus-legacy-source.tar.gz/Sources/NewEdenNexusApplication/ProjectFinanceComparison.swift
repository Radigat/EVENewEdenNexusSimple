import Foundation
import NewEdenNexusDomain

public enum ProjectFinancePlanState: Equatable, Sendable {
    case available
    case archived
    case missingTarget
    case missingGraph
    case staleGraph
    case incompletePrices
    case unavailable
}

public enum ProjectFinanceActualState: Equatable, Sendable {
    case current
    case noAssignments
    case outdatedSource
    case unavailable
}

public struct ProjectFinanceComparisonSnapshot: Equatable, Sendable {
    public let projectID: UUID
    public let projectStatus: ProjectStatus
    public let planState: ProjectFinancePlanState
    public let plan: ProjectEconomicsCalculation?
    public let planCalculatedAt: Date?
    public let actualState: ProjectFinanceActualState
    public let actuals: WalletProjectActuals?
    public let actualsUpdatedAt: Date?

    public init(
        projectID: UUID,
        projectStatus: ProjectStatus,
        planState: ProjectFinancePlanState,
        plan: ProjectEconomicsCalculation?,
        planCalculatedAt: Date?,
        actualState: ProjectFinanceActualState,
        actuals: WalletProjectActuals?,
        actualsUpdatedAt: Date?
    ) {
        self.projectID = projectID
        self.projectStatus = projectStatus
        self.planState = planState
        self.plan = plan
        self.planCalculatedAt = planCalculatedAt
        self.actualState = actualState
        self.actuals = actuals
        self.actualsUpdatedAt = actualsUpdatedAt
    }
}

public protocol ProjectFinanceComparisonProviding: Sendable {
    func comparison(
        project: ProductionProjectSnapshot,
        at date: Date
    ) async throws -> ProjectFinanceComparisonSnapshot
}

public struct ProjectFinanceComparisonService:
    ProjectFinanceComparisonProviding,
    Sendable
{
    private struct PlanResult {
        let state: ProjectFinancePlanState
        let calculation: ProjectEconomicsCalculation?
        let calculatedAt: Date?
    }

    private struct ActualResult {
        let state: ProjectFinanceActualState
        let actuals: WalletProjectActuals?
        let updatedAt: Date?
    }

    private let planning: any BuildOrBuyPlanning
    private let economics: any ProjectEconomicsManaging
    private let assignments: any WalletProjectAssignmentRepository
    private let wallets: any ESIWalletPersisting
    private let calculator: WalletProjectActualsCalculator

    public init(
        planning: any BuildOrBuyPlanning,
        economics: any ProjectEconomicsManaging,
        assignments: any WalletProjectAssignmentRepository,
        wallets: any ESIWalletPersisting,
        calculator: WalletProjectActualsCalculator = .init()
    ) {
        self.planning = planning
        self.economics = economics
        self.assignments = assignments
        self.wallets = wallets
        self.calculator = calculator
    }

    public func comparison(
        project: ProductionProjectSnapshot,
        at date: Date
    ) async throws -> ProjectFinanceComparisonSnapshot {
        async let planTask = planResult(project: project, at: date)
        async let actualTask = actualResult(projectID: project.id)
        let (plan, actual) = try await (planTask, actualTask)
        return ProjectFinanceComparisonSnapshot(
            projectID: project.id,
            projectStatus: project.status,
            planState: plan.state,
            plan: plan.calculation,
            planCalculatedAt: plan.calculatedAt,
            actualState: actual.state,
            actuals: actual.actuals,
            actualsUpdatedAt: actual.updatedAt
        )
    }

    private func planResult(
        project: ProductionProjectSnapshot,
        at date: Date
    ) async throws -> PlanResult {
        guard project.status != .archived else {
            return PlanResult(
                state: .archived,
                calculation: nil,
                calculatedAt: nil
            )
        }
        guard let target = project.target else {
            return PlanResult(
                state: .missingTarget,
                calculation: nil,
                calculatedAt: nil
            )
        }
        do {
            let preview = try await planning.preview(
                projectID: project.id,
                decisions: nil
            )
            let economicsPreview = try await economics.load(
                projectID: project.id,
                graphID: preview.sourceVersion.graphID,
                targetTypeID: target.productTypeID,
                targetName: target.productName,
                targetQuantity: Int64(project.targetQuantity),
                plan: preview.plan,
                at: date
            )
            guard let calculation = economicsPreview.calculation else {
                return PlanResult(
                    state: .incompletePrices,
                    calculation: nil,
                    calculatedAt: preview.calculatedAt
                )
            }
            return PlanResult(
                state: .available,
                calculation: calculation,
                calculatedAt: preview.calculatedAt
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch BuildOrBuyPlanningError.graphRequired {
            return PlanResult(
                state: .missingGraph,
                calculation: nil,
                calculatedAt: nil
            )
        } catch BuildOrBuyPlanningError.staleGraph {
            return PlanResult(
                state: .staleGraph,
                calculation: nil,
                calculatedAt: nil
            )
        } catch {
            return PlanResult(
                state: .unavailable,
                calculation: nil,
                calculatedAt: nil
            )
        }
    }

    private func actualResult(
        projectID: UUID
    ) async throws -> ActualResult {
        do {
            let stored = try await assignments.assignments(
                projectID: projectID
            )
            let actuals = try calculator.calculate(
                projectID: projectID,
                assignments: stored
            )
            guard !stored.isEmpty else {
                return ActualResult(
                    state: .noAssignments,
                    actuals: actuals,
                    updatedAt: nil
                )
            }
            var isOutdated = false
            for characterID in Set(stored.map(\.characterID)) {
                try Task.checkCancellation()
                guard let wallet = try await wallets.snapshot(
                    characterID: characterID
                ) else {
                    isOutdated = true
                    continue
                }
                if stored.contains(where: {
                    $0.characterID == characterID
                        && $0.sourceRevision != wallet.revision
                }) {
                    isOutdated = true
                }
            }
            return ActualResult(
                state: isOutdated ? .outdatedSource : .current,
                actuals: actuals,
                updatedAt: stored.map(\.updatedAt).max()
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            return ActualResult(
                state: .unavailable,
                actuals: nil,
                updatedAt: nil
            )
        }
    }
}
