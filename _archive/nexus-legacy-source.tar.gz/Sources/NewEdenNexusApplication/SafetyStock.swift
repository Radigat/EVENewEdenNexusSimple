import Foundation
import NewEdenNexusDomain

public struct SafetyStockPolicyDraft: Equatable, Sendable {
    public let typeID: Int64
    public let safetyStockQuantity: Int64
    public let minimumQuantity: Int64?
    public let warningQuantity: Int64?
    public let targetQuantity: Int64?

    public init(
        typeID: Int64,
        safetyStockQuantity: Int64,
        minimumQuantity: Int64?,
        warningQuantity: Int64?,
        targetQuantity: Int64?
    ) {
        self.typeID = typeID
        self.safetyStockQuantity = safetyStockQuantity
        self.minimumQuantity = minimumQuantity
        self.warningQuantity = warningQuantity
        self.targetQuantity = targetQuantity
    }

    public init(_ policy: SafetyStockPolicySnapshot) {
        self.init(
            typeID: policy.typeID,
            safetyStockQuantity: policy.safetyStockQuantity,
            minimumQuantity: policy.minimumQuantity,
            warningQuantity: policy.warningQuantity,
            targetQuantity: policy.targetQuantity
        )
    }

    public var isEmpty: Bool {
        safetyStockQuantity == 0
            && minimumQuantity == nil
            && warningQuantity == nil
            && targetQuantity == nil
    }
}

public struct SafetyStockPolicyVersion: Equatable, Sendable {
    public let typeID: Int64
    public let updatedAt: Date?

    public init(typeID: Int64, updatedAt: Date?) {
        self.typeID = typeID
        self.updatedAt = updatedAt
    }
}

public struct SafetyStockSourceVersion: Equatable, Sendable {
    public let availability: InventoryAvailabilitySourceVersion
    public let policies: [SafetyStockPolicyVersion]

    public init(
        availability: InventoryAvailabilitySourceVersion,
        policies: [SafetyStockPolicyVersion]
    ) {
        self.availability = availability
        self.policies = policies.sorted { $0.typeID < $1.typeID }
    }
}

public struct SafetyStockPreview: Equatable, Sendable {
    public let projectID: UUID
    public let graphID: UUID
    public let calculatedAt: Date
    public let sourceVersion: SafetyStockSourceVersion
    public let availabilityPreview: InventoryAvailabilityPreview
    public let storedPolicies: [SafetyStockPolicySnapshot]
    public let proposedPolicies: [SafetyStockPolicySnapshot]
    public let calculation: SafetyStockCalculation
}

public enum SafetyStockServiceError:
    Error,
    Equatable,
    Sendable
{
    case duplicateDraftTypeID(Int64)
    case unknownMaterial(Int64)
    case confirmationRequired
    case stalePreview
    case persistenceFailure
}

public enum SafetyStockPolicyRepositoryError:
    Error,
    Equatable,
    Sendable
{
    case staleState
}

public protocol SafetyStockPolicyRepository: Sendable {
    func policies(typeIDs: [Int64]) async throws
        -> [SafetyStockPolicySnapshot]

    func replacePolicies(
        _ policies: [SafetyStockPolicySnapshot],
        managedTypeIDs: [Int64],
        expectedVersions: [SafetyStockPolicyVersion]
    ) async throws
}

public protocol SafetyStockManaging: Sendable {
    func preview(
        projectID: UUID,
        drafts: [SafetyStockPolicyDraft]?
    ) async throws -> SafetyStockPreview

    func apply(
        _ preview: SafetyStockPreview,
        confirmed: Bool
    ) async throws -> SafetyStockPreview
}

public struct SafetyStockService: SafetyStockManaging, Sendable {
    private let availability: any InventoryAvailabilityManaging
    private let repository: any SafetyStockPolicyRepository
    private let calculator: SafetyStockCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        availability: any InventoryAvailabilityManaging,
        repository: any SafetyStockPolicyRepository,
        calculator: SafetyStockCalculator = .init(),
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.availability = availability
        self.repository = repository
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func preview(
        projectID: UUID,
        drafts: [SafetyStockPolicyDraft]? = nil
    ) async throws -> SafetyStockPreview {
        try Task.checkCancellation()
        let availabilityPreview = try await availability.preview(
            projectID: projectID,
            draft: nil
        )
        let typeIDs = availabilityPreview.calculation.lines
            .map(\.typeID)
            .sorted()
        let stored = try await repository.policies(typeIDs: typeIDs)
            .sorted { $0.typeID < $1.typeID }
        try Task.checkCancellation()
        let timestamp = now()
        let proposed = try proposedPolicies(
            drafts: drafts,
            stored: stored,
            allowedTypeIDs: Set(typeIDs),
            timestamp: timestamp
        )
        let calculation = try calculator.calculate(
            availability: availabilityPreview.calculation,
            policies: proposed
        )
        return SafetyStockPreview(
            projectID: projectID,
            graphID: availabilityPreview.graphID,
            calculatedAt: timestamp,
            sourceVersion: sourceVersion(
                availability: availabilityPreview,
                typeIDs: typeIDs,
                policies: stored
            ),
            availabilityPreview: availabilityPreview,
            storedPolicies: stored,
            proposedPolicies: proposed,
            calculation: calculation
        )
    }

    public func apply(
        _ preview: SafetyStockPreview,
        confirmed: Bool
    ) async throws -> SafetyStockPreview {
        guard confirmed else {
            throw SafetyStockServiceError.confirmationRequired
        }
        try Task.checkCancellation()
        let currentAvailability = try await availability.preview(
            projectID: preview.projectID,
            draft: nil
        )
        let typeIDs = currentAvailability.calculation.lines
            .map(\.typeID)
            .sorted()
        let currentPolicies = try await repository.policies(typeIDs: typeIDs)
            .sorted { $0.typeID < $1.typeID }
        let currentSource = sourceVersion(
            availability: currentAvailability,
            typeIDs: typeIDs,
            policies: currentPolicies
        )
        guard currentSource == preview.sourceVersion,
              currentAvailability.graphID == preview.graphID else {
            throw SafetyStockServiceError.stalePreview
        }
        let allowedTypeIDs = Set(typeIDs)
        for policy in preview.proposedPolicies {
            guard allowedTypeIDs.contains(policy.typeID) else {
                throw SafetyStockServiceError
                    .unknownMaterial(policy.typeID)
            }
        }
        let calculation = try calculator.calculate(
            availability: currentAvailability.calculation,
            policies: preview.proposedPolicies
        )
        try Task.checkCancellation()
        do {
            try await repository.replacePolicies(
                preview.proposedPolicies,
                managedTypeIDs: typeIDs,
                expectedVersions: preview.sourceVersion.policies
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch SafetyStockPolicyRepositoryError.staleState {
            throw SafetyStockServiceError.stalePreview
        } catch {
            throw SafetyStockServiceError.persistenceFailure
        }

        let committedSource = SafetyStockSourceVersion(
            availability: currentAvailability.sourceVersion,
            policies: typeIDs.map { typeID in
                SafetyStockPolicyVersion(
                    typeID: typeID,
                    updatedAt: preview.proposedPolicies.first {
                        $0.typeID == typeID
                    }?.updatedAt
                )
            }
        )
        return SafetyStockPreview(
            projectID: preview.projectID,
            graphID: currentAvailability.graphID,
            calculatedAt: now(),
            sourceVersion: committedSource,
            availabilityPreview: currentAvailability,
            storedPolicies: preview.proposedPolicies,
            proposedPolicies: preview.proposedPolicies,
            calculation: calculation
        )
    }

    private func proposedPolicies(
        drafts: [SafetyStockPolicyDraft]?,
        stored: [SafetyStockPolicySnapshot],
        allowedTypeIDs: Set<Int64>,
        timestamp: Date
    ) throws -> [SafetyStockPolicySnapshot] {
        guard let drafts else { return stored }
        var draftsByTypeID: [Int64: SafetyStockPolicyDraft] = [:]
        for draft in drafts {
            guard allowedTypeIDs.contains(draft.typeID) else {
                throw SafetyStockServiceError.unknownMaterial(draft.typeID)
            }
            guard draftsByTypeID[draft.typeID] == nil else {
                throw SafetyStockServiceError
                    .duplicateDraftTypeID(draft.typeID)
            }
            draftsByTypeID[draft.typeID] = draft
        }
        let storedByTypeID = Dictionary(
            uniqueKeysWithValues: stored.map { ($0.typeID, $0) }
        )
        return try draftsByTypeID.values.compactMap { draft in
            guard !draft.isEmpty else { return nil }
            let existing = storedByTypeID[draft.typeID]
            return try SafetyStockPolicySnapshot(
                id: existing?.id ?? makeID(),
                typeID: draft.typeID,
                safetyStockQuantity: draft.safetyStockQuantity,
                minimumQuantity: draft.minimumQuantity,
                warningQuantity: draft.warningQuantity,
                targetQuantity: draft.targetQuantity,
                createdAt: existing?.createdAt ?? timestamp,
                updatedAt: timestamp
            )
        }.sorted { $0.typeID < $1.typeID }
    }

    private func sourceVersion(
        availability: InventoryAvailabilityPreview,
        typeIDs: [Int64],
        policies: [SafetyStockPolicySnapshot]
    ) -> SafetyStockSourceVersion {
        let byTypeID = Dictionary(
            uniqueKeysWithValues: policies.map { ($0.typeID, $0) }
        )
        return SafetyStockSourceVersion(
            availability: availability.sourceVersion,
            policies: typeIDs.map { typeID in
                SafetyStockPolicyVersion(
                    typeID: typeID,
                    updatedAt: byTypeID[typeID]?.updatedAt
                )
            }
        )
    }
}
