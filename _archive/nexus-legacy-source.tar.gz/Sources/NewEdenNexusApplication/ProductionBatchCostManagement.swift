import Foundation
import NewEdenNexusDomain

public protocol ProductionBatchCostRepository: Sendable {
    func save(
        _ snapshot: ProductionBatchCostSnapshot
    ) async throws
    func snapshots(
        batchID: UUID
    ) async throws -> [ProductionBatchCostSnapshot]
}

public enum ProductionBatchSaleQuoteSelection:
    String,
    CaseIterable,
    Sendable
{
    case none
    case jita
    case alternative
}

public struct ProductionBatchCostDraft: Equatable, Sendable {
    public let batchID: UUID
    public let priceProfileID: UUID?
    public let alternativeMarket: MarketPriceConfiguration?
    public let alternativeMarketName: String?
    public let selectedSaleQuote: ProductionBatchSaleQuoteSelection
    public let allowManualPriceSetFallback: Bool
    public let facilityAndTaxCost: NonNegativeISKAmount?
    public let blueprintAndInventionCost: NonNegativeISKAmount?
    public let marketFees: NonNegativeISKAmount?
    public let manualOtherCost: NonNegativeISKAmount?

    public init(
        batchID: UUID,
        priceProfileID: UUID?,
        alternativeMarket: MarketPriceConfiguration?,
        alternativeMarketName: String?,
        selectedSaleQuote: ProductionBatchSaleQuoteSelection,
        allowManualPriceSetFallback: Bool,
        facilityAndTaxCost: NonNegativeISKAmount?,
        blueprintAndInventionCost: NonNegativeISKAmount?,
        marketFees: NonNegativeISKAmount?,
        manualOtherCost: NonNegativeISKAmount?
    ) {
        self.batchID = batchID
        self.priceProfileID = priceProfileID
        self.alternativeMarket = alternativeMarket
        self.alternativeMarketName = alternativeMarketName
        self.selectedSaleQuote = selectedSaleQuote
        self.allowManualPriceSetFallback =
            allowManualPriceSetFallback
        self.facilityAndTaxCost = facilityAndTaxCost
        self.blueprintAndInventionCost =
            blueprintAndInventionCost
        self.marketFees = marketFees
        self.manualOtherCost = manualOtherCost
    }
}

public struct ProductionBatchCostPreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let draft: ProductionBatchCostDraft
    public let batch: ProductionBatchSnapshot
    public let snapshot: ProductionBatchCostSnapshot
    public let warnings: [String]

    public var isComplete: Bool {
        snapshot.calculation.totalCost != nil
    }
}

public enum ProductionBatchCostManagementError:
    Error,
    Equatable,
    Sendable
{
    case batchNotFound(UUID)
    case profileNotFound(UUID)
    case stalePlanningBasis
    case staleBatch
    case confirmationRequired
    case incompleteCostBasis
    case persistenceFailure
}

public protocol ProductionBatchCostManaging: Sendable {
    func priceProfiles() async throws -> [PriceProfileSnapshot]
    func snapshots(
        batchID: UUID
    ) async throws -> [ProductionBatchCostSnapshot]
    func preview(
        _ draft: ProductionBatchCostDraft
    ) async throws -> ProductionBatchCostPreview
    func apply(
        _ preview: ProductionBatchCostPreview,
        confirmed: Bool
    ) async throws -> ProductionBatchCostSnapshot
}

public struct ProductionBatchCostManagementService:
    ProductionBatchCostManaging,
    Sendable
{
    private static let jita = MarketPriceConfiguration(
        regionID: 10_000_002,
        locationID: 60_003_760,
        locationLabel:
            "Jita IV - Moon 4 - Caldari Navy Assembly Plant"
    )

    private let batches: any ProductionBatchRepository
    private let costs: any ProductionBatchCostRepository
    private let planning: any BuildOrBuyPlanning
    private let shopping: any ShoppingListManaging
    private let budget: any ProjectBudgetManaging
    private let prices: any PriceProfileManaging
    private let market: any MarketPriceImporting
    private let calculator: ProductionBatchCostCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        batches: any ProductionBatchRepository,
        costs: any ProductionBatchCostRepository,
        planning: any BuildOrBuyPlanning,
        shopping: any ShoppingListManaging,
        budget: any ProjectBudgetManaging,
        prices: any PriceProfileManaging,
        market: any MarketPriceImporting,
        calculator: ProductionBatchCostCalculator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.batches = batches
        self.costs = costs
        self.planning = planning
        self.shopping = shopping
        self.budget = budget
        self.prices = prices
        self.market = market
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func priceProfiles() async throws -> [PriceProfileSnapshot] {
        try await prices.profiles()
    }

    public func snapshots(
        batchID: UUID
    ) async throws -> [ProductionBatchCostSnapshot] {
        do {
            return try await costs.snapshots(batchID: batchID)
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ProductionBatchCostManagementError.persistenceFailure
        }
    }

    public func preview(
        _ draft: ProductionBatchCostDraft
    ) async throws -> ProductionBatchCostPreview {
        guard let batch = try await batches.batch(id: draft.batchID)
        else {
            throw ProductionBatchCostManagementError.batchNotFound(
                draft.batchID
            )
        }
        let timestamp = now()
        let profiles = try await prices.profiles()
        let profile: PriceProfileSnapshot?
        if let profileID = draft.priceProfileID {
            guard
                let value = profiles.first(where: {
                    $0.id == profileID
                })
            else {
                throw
                    ProductionBatchCostManagementError
                    .profileNotFound(profileID)
            }
            profile = value
        } else {
            profile = nil
        }

        let plan = try await planning.preview(
            projectID: batch.projectID,
            decisions: nil
        )
        guard
            plan.sourceVersion.projectUpdatedAt
                == batch.sourceProjectUpdatedAt,
            plan.sourceVersion.graphID == batch.graphID,
            plan.sourceVersion.graphUpdatedAt == batch.graphUpdatedAt
        else {
            throw ProductionBatchCostManagementError
                .stalePlanningBasis
        }
        let shoppingPreview = try await shopping.load(planPreview: plan)
        let budgetPreview = try await budget.load(
            projectID: batch.projectID,
            graphID: plan.plan.graphID,
            purchases: shoppingPreview.aggregation.effectivePositions,
            at: timestamp
        )

        let lines = try makeCostLines(
            draft: draft,
            budget: budgetPreview,
            at: timestamp
        )
        async let jitaResult = quote(
            batch: batch,
            configuration: Self.jita,
            marketName:
                "Jita IV - Moon 4 - Caldari Navy Assembly Plant",
            profile: profile,
            allowFallback: draft.allowManualPriceSetFallback,
            at: timestamp
        )
        let alternativeResult: PriceQuoteBinding?
        if let alternative = draft.alternativeMarket,
            alternative != Self.jita
        {
            alternativeResult = try await quote(
                batch: batch,
                configuration: alternative,
                marketName: draft.alternativeMarketName
                    ?? alternative.locationLabel
                    ?? "Alternativmarkt",
                profile: profile,
                allowFallback: draft.allowManualPriceSetFallback,
                at: timestamp
            )
        } else {
            alternativeResult = nil
        }
        let jita = try await jitaResult
        let selectedQuote: PriceQuoteBinding?
        switch draft.selectedSaleQuote {
        case .none:
            selectedQuote = nil
        case .jita:
            selectedQuote = jita
        case .alternative:
            selectedQuote = alternativeResult
        }
        let calculation = try calculator.calculate(
            outputUnits: batch.outputUnits,
            costLines: lines,
            selectedSaleUnitPrice: selectedQuote?.unitPrice
        )
        let snapshot = try ProductionBatchCostSnapshot(
            id: makeID(),
            batchID: batch.id,
            batchUpdatedAt: batch.updatedAt,
            priceProfileID: profile?.id,
            priceProfileName: profile?.name,
            costLines: lines,
            jitaQuote: jita,
            alternativeQuote: alternativeResult,
            selectedSaleQuoteID: selectedQuote?.id,
            calculation: calculation,
            createdAt: timestamp
        )
        var warnings = lines.flatMap(\.warnings)
        warnings.append(
            contentsOf: jita?.warnings ?? [
                "Für Jita ist keine belastbare Sell-Quote verfügbar."
            ])
        if draft.alternativeMarket != nil, alternativeResult == nil {
            warnings.append(
                "Für den Alternativmarkt ist keine belastbare Sell-Quote verfügbar."
            )
        }
        return ProductionBatchCostPreview(
            id: makeID(),
            draft: draft,
            batch: batch,
            snapshot: snapshot,
            warnings: Array(Set(warnings)).sorted()
        )
    }

    public func apply(
        _ preview: ProductionBatchCostPreview,
        confirmed: Bool
    ) async throws -> ProductionBatchCostSnapshot {
        guard confirmed else {
            throw ProductionBatchCostManagementError
                .confirmationRequired
        }
        guard preview.isComplete else {
            throw ProductionBatchCostManagementError
                .incompleteCostBasis
        }
        guard
            let current = try await batches.batch(
                id: preview.batch.id
            ), current.updatedAt == preview.batch.updatedAt
        else {
            throw ProductionBatchCostManagementError.staleBatch
        }
        do {
            try await costs.save(preview.snapshot)
            return preview.snapshot
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ProductionBatchCostManagementError.persistenceFailure
        }
    }

    private func makeCostLines(
        draft: ProductionBatchCostDraft,
        budget: ProjectBudgetPreview,
        at date: Date
    ) throws -> [ProductionBatchCostLine] {
        let calculation = budget.calculation
        let materialWarnings =
            calculation == nil
            ? [
                "Materialpreise sind unvollständig. Fehlende Werte werden nicht als 0 ISK gerechnet."
            ]
            : []
        return try [
            ProductionBatchCostLine(
                id: makeID(),
                kind: .material,
                label: "Materialeinkauf",
                amount: try calculation.map {
                    try NonNegativeISKAmount(
                        hundredths:
                            $0.materialPurchaseCost.hundredths
                    )
                },
                source: .projectBudget,
                assignment: .calculated,
                sourceObservedAt: date,
                warnings: materialWarnings
            ),
            ProductionBatchCostLine(
                id: makeID(),
                kind: .industryJob,
                label: "System-Cost-Index und Industry-Job",
                amount: calculation?.productionCost,
                source: .projectBudget,
                assignment: .calculated,
                sourceObservedAt: date,
                warnings: calculation == nil
                    ? ["Produktionskostenbasis ist nicht vollständig."]
                    : []
            ),
            ProductionBatchCostLine(
                id: makeID(),
                kind: .facilityAndTax,
                label: "Facility-, SCC-Abgabe und Produktionssteuer",
                amount: draft.facilityAndTaxCost,
                source: .manual,
                assignment: .manual,
                sourceObservedAt: date,
                warnings: unresolvedWarning(
                    draft.facilityAndTaxCost
                )
            ),
            ProductionBatchCostLine(
                id: makeID(),
                kind: .blueprintAndInvention,
                label: "BPO/BPC, Kopie, Invention und Decryptor",
                amount: draft.blueprintAndInventionCost,
                source: .manual,
                assignment: .manual,
                sourceObservedAt: date,
                warnings: unresolvedWarning(
                    draft.blueprintAndInventionCost
                )
            ),
            ProductionBatchCostLine(
                id: makeID(),
                kind: .logistics,
                label: "Logistik",
                amount: calculation?.logisticsCost,
                source: .projectBudget,
                assignment: .calculated,
                sourceObservedAt: date,
                warnings: calculation == nil
                    ? ["Logistikkostenbasis ist nicht vollständig."]
                    : []
            ),
            ProductionBatchCostLine(
                id: makeID(),
                kind: .marketFees,
                label: "Broker- und Transaktionsgebühren",
                amount: draft.marketFees,
                source: .manual,
                assignment: .manual,
                sourceObservedAt: date,
                warnings: unresolvedWarning(draft.marketFees)
            ),
            ProductionBatchCostLine(
                id: makeID(),
                kind: .manualOther,
                label: "Sonstige manuelle Kosten",
                amount: draft.manualOtherCost,
                source: .manual,
                assignment: .manual,
                sourceObservedAt: date,
                warnings: unresolvedWarning(draft.manualOtherCost)
            ),
        ]
    }

    private func unresolvedWarning(
        _ amount: NonNegativeISKAmount?
    ) -> [String] {
        amount == nil
            ? [
                "Wert unbekannt. Trage 0 ISK nur ein, wenn die Kostenart ausdrücklich nicht anfällt."
            ]
            : []
    }

    private func quote(
        batch: ProductionBatchSnapshot,
        configuration: MarketPriceConfiguration,
        marketName: String,
        profile: PriceProfileSnapshot?,
        allowFallback: Bool,
        at date: Date
    ) async throws -> PriceQuoteBinding? {
        do {
            let preview = try await market.preview(
                profileID: nil,
                configuration: configuration,
                requirements: [
                    MarketPriceRequestLine(
                        typeID: batch.productTypeID,
                        itemName: batch.productName,
                        quantity: batch.outputUnits
                    )
                ]
            )
            if let quote = preview.lines.first?.quote {
                return try PriceQuoteBinding(
                    id: makeID(),
                    typeID: batch.productTypeID,
                    itemName: batch.productName,
                    regionID: configuration.regionID,
                    regionName: nil,
                    locationID: configuration.locationID,
                    locationName: marketName,
                    quantity: quote.requestedQuantity,
                    fulfilledQuantity: quote.fulfilledQuantity,
                    orderCount: quote.orderCount,
                    unitPrice: quote.unitPrice,
                    observedAt: quote.ordersFetchedAt,
                    expiresAt: quote.cacheExpiresAt,
                    sourceSnapshotID: makeID(),
                    policyVersion:
                        ProductionBatchCostSnapshot
                        .currentQuotePolicyVersion,
                    fallback: quote.source.fallback,
                    warnings: quote.source.isStaleFallback
                        ? [
                            "Die Quote stammt aus einem sichtbar veralteten Cache."
                        ]
                        : []
                )
            }
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            // A selected price set may be used only through the explicit
            // fallback below. Network and cache errors do not become zero.
        }
        guard allowFallback, let profile else {
            return nil
        }
        let resolution = try await prices.resolve(
            typeIDs: [batch.productTypeID],
            profileID: profile.id,
            at: date
        )
        guard
            let amount = resolution.pricesByTypeID[
                batch.productTypeID
            ]
        else {
            return nil
        }
        return try PriceQuoteBinding(
            id: makeID(),
            typeID: batch.productTypeID,
            itemName: batch.productName,
            regionID: nil,
            regionName: nil,
            locationID: nil,
            locationName: profile.name,
            quantity: batch.outputUnits,
            fulfilledQuantity: batch.outputUnits,
            orderCount: 0,
            unitPrice: amount,
            observedAt: profile.updatedAt,
            expiresAt: nil,
            sourceSnapshotID: profile.id,
            policyVersion:
                ProductionBatchCostSnapshot.currentQuotePolicyVersion,
            fallback: .manualPriceSet,
            warnings: [
                "Expliziter Preissatz-Fallback; kein aktuelles ESI-Orderbuch."
            ]
        )
    }
}

extension MarketPriceQuoteSource {
    fileprivate var fallback: ProductionPriceQuoteFallback {
        switch self {
        case .network:
            .none
        case .freshCache, .notModified:
            .freshCache
        case .offlineCache, .limitedCache, .serverFallback:
            .staleCache
        }
    }
}
