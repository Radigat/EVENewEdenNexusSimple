import Foundation

public enum ESIPersonalDataSet: String, Codable, CaseIterable, Sendable {
    case assets
    case blueprints
    case industryJobs = "industry_jobs"
}

public struct ESICharacterAsset: Codable, Equatable, Sendable {
    public let itemID: Int64
    public let typeID: Int64
    public let quantity: Int64
    public let locationID: Int64
    public let locationType: String
    public let locationFlag: String
    public let isSingleton: Bool
    public let isBlueprintCopy: Bool?
    public let sourcePage: Int

    public init(
        itemID: Int64,
        typeID: Int64,
        quantity: Int64,
        locationID: Int64,
        locationType: String,
        locationFlag: String,
        isSingleton: Bool,
        isBlueprintCopy: Bool?,
        sourcePage: Int
    ) throws {
        guard itemID > 0, typeID > 0, quantity >= 0, locationID > 0,
              Self.isSafeLabel(locationType),
              Self.isSafeLabel(locationFlag),
              sourcePage > 0 else {
            throw ESIPersonalDataError.invalidResponse
        }
        self.itemID = itemID
        self.typeID = typeID
        self.quantity = quantity
        self.locationID = locationID
        self.locationType = locationType
        self.locationFlag = locationFlag
        self.isSingleton = isSingleton
        self.isBlueprintCopy = isBlueprintCopy
        self.sourcePage = sourcePage
    }

    private static func isSafeLabel(_ value: String) -> Bool {
        !value.isEmpty && value.utf8.count <= 128
            && value.rangeOfCharacter(from: .newlines) == nil
    }
}

public struct ESICharacterBlueprint: Codable, Equatable, Sendable {
    public let itemID: Int64
    public let typeID: Int64
    public let locationID: Int64
    public let locationFlag: String
    public let quantity: Int64
    public let timeEfficiency: Int64
    public let materialEfficiency: Int64
    public let runs: Int64
    public let sourcePage: Int

    public init(
        itemID: Int64,
        typeID: Int64,
        locationID: Int64,
        locationFlag: String,
        quantity: Int64,
        timeEfficiency: Int64,
        materialEfficiency: Int64,
        runs: Int64,
        sourcePage: Int
    ) throws {
        guard itemID > 0, typeID > 0, locationID > 0,
              !locationFlag.isEmpty, locationFlag.utf8.count <= 128,
              locationFlag.rangeOfCharacter(from: .newlines) == nil,
              quantity >= -2, runs >= -1, sourcePage > 0 else {
            throw ESIPersonalDataError.invalidResponse
        }
        self.itemID = itemID
        self.typeID = typeID
        self.locationID = locationID
        self.locationFlag = locationFlag
        self.quantity = quantity
        self.timeEfficiency = timeEfficiency
        self.materialEfficiency = materialEfficiency
        self.runs = runs
        self.sourcePage = sourcePage
    }
}

public struct ESICharacterIndustryJob: Codable, Equatable, Sendable {
    public let jobID: Int64
    public let installerID: Int64
    public let facilityID: Int64
    public let stationID: Int64
    public let activityID: Int64
    public let blueprintID: Int64
    public let blueprintTypeID: Int64
    public let blueprintLocationID: Int64
    public let outputLocationID: Int64
    public let runs: Int64
    public let status: String
    public let duration: Int64
    public let startDate: Date
    public let endDate: Date
    public let completedDate: Date?
    public let completedCharacterID: Int64?
    public let cost: Double?
    public let licensedRuns: Int64?
    public let pauseDate: Date?
    public let probability: Double?
    public let productTypeID: Int64?
    public let successfulRuns: Int64?

    public init(
        jobID: Int64,
        installerID: Int64,
        facilityID: Int64,
        stationID: Int64,
        activityID: Int64,
        blueprintID: Int64,
        blueprintTypeID: Int64,
        blueprintLocationID: Int64,
        outputLocationID: Int64,
        runs: Int64,
        status: String,
        duration: Int64,
        startDate: Date,
        endDate: Date,
        completedDate: Date? = nil,
        completedCharacterID: Int64? = nil,
        cost: Double? = nil,
        licensedRuns: Int64? = nil,
        pauseDate: Date? = nil,
        probability: Double? = nil,
        productTypeID: Int64? = nil,
        successfulRuns: Int64? = nil
    ) throws {
        guard jobID > 0, installerID > 0, facilityID > 0, stationID > 0,
              activityID > 0, blueprintID > 0, blueprintTypeID > 0,
              blueprintLocationID > 0, outputLocationID > 0, runs > 0,
              !status.isEmpty, status.utf8.count <= 64,
              status.rangeOfCharacter(from: .newlines) == nil,
              duration >= 0, endDate >= startDate,
              completedCharacterID.map({ $0 > 0 }) ?? true,
              cost.map({ $0.isFinite && $0 >= 0 }) ?? true,
              licensedRuns.map({ $0 >= 0 }) ?? true,
              probability.map({ $0.isFinite && (0...1).contains($0) }) ?? true,
              productTypeID.map({ $0 > 0 }) ?? true,
              successfulRuns.map({ $0 >= 0 }) ?? true else {
            throw ESIPersonalDataError.invalidResponse
        }
        self.jobID = jobID
        self.installerID = installerID
        self.facilityID = facilityID
        self.stationID = stationID
        self.activityID = activityID
        self.blueprintID = blueprintID
        self.blueprintTypeID = blueprintTypeID
        self.blueprintLocationID = blueprintLocationID
        self.outputLocationID = outputLocationID
        self.runs = runs
        self.status = status
        self.duration = duration
        self.startDate = startDate
        self.endDate = endDate
        self.completedDate = completedDate
        self.completedCharacterID = completedCharacterID
        self.cost = cost
        self.licensedRuns = licensedRuns
        self.pauseDate = pauseDate
        self.probability = probability
        self.productTypeID = productTypeID
        self.successfulRuns = successfulRuns
    }
}

public struct ESIPersonalEndpointMetadata: Codable, Equatable, Sendable {
    public let checkedAt: Date
    public let expiresAt: Date?
    public let compatibilityDate: String
    public let pageCount: Int
    public let validatorsByPage: [Int: ESICacheValidators]
    public let rateLimit: ESIRateLimitSnapshot

    public init(
        checkedAt: Date,
        expiresAt: Date?,
        compatibilityDate: String,
        pageCount: Int,
        validatorsByPage: [Int: ESICacheValidators],
        rateLimit: ESIRateLimitSnapshot = ESIRateLimitSnapshot()
    ) throws {
        guard checkedAt.timeIntervalSinceReferenceDate.isFinite,
              expiresAt?.timeIntervalSinceReferenceDate.isFinite ?? true,
              Self.isISODate(compatibilityDate),
              pageCount > 0, pageCount <= 100,
              validatorsByPage.keys.allSatisfy({
                  $0 > 0 && $0 <= pageCount
              }),
              validatorsByPage.values.allSatisfy(Self.isSafe),
              Self.isSafe(rateLimit.group),
              Self.isSafe(rateLimit.limit),
              Self.isNonNegative(rateLimit.remaining),
              Self.isNonNegative(rateLimit.used),
              Self.isNonNegative(rateLimit.errorLimitRemaining),
              Self.isNonNegative(rateLimit.errorLimitResetSeconds) else {
            throw ESIPersonalDataError.invalidResponse
        }
        self.checkedAt = checkedAt
        self.expiresAt = expiresAt
        self.compatibilityDate = compatibilityDate
        self.pageCount = pageCount
        self.validatorsByPage = validatorsByPage
        self.rateLimit = rateLimit
    }

    public func isFresh(at date: Date) -> Bool {
        expiresAt.map { $0 > date } ?? false
    }

    private static func isSafe(_ validators: ESICacheValidators) -> Bool {
        isSafe(validators.etag) && isSafe(validators.lastModified)
    }

    private static func isSafe(_ value: String?) -> Bool {
        guard let value else {
            return true
        }
        return !value.isEmpty && value.utf8.count <= 1_024
            && value.rangeOfCharacter(from: .newlines) == nil
    }

    private static func isNonNegative(_ value: Int?) -> Bool {
        value.map { $0 >= 0 } ?? true
    }

    private static func isISODate(_ value: String) -> Bool {
        let parts = value.split(
            separator: "-",
            omittingEmptySubsequences: false
        )
        guard value.count == 10,
              parts.count == 3,
              parts[0].count == 4,
              parts[1].count == 2,
              parts[2].count == 2,
              parts.allSatisfy({ $0.allSatisfy(\.isNumber) }),
              let year = Int(parts[0]),
              let month = Int(parts[1]),
              let day = Int(parts[2]),
              let utc = TimeZone(secondsFromGMT: 0) else {
            return false
        }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = utc
        guard let date = calendar.date(
            from: DateComponents(
                timeZone: utc,
                year: year,
                month: month,
                day: day
            )
        ) else {
            return false
        }
        let resolved = calendar.dateComponents(
            [.year, .month, .day],
            from: date
        )
        return resolved.year == year
            && resolved.month == month
            && resolved.day == day
    }
}

public struct ESIPersonalDataSnapshot: Codable, Equatable, Sendable {
    public static let payloadVersion = 1

    public let version: Int
    public let revision: UUID
    public let characterID: Int64
    public let synchronizedAt: Date
    public let assets: [ESICharacterAsset]
    public let blueprints: [ESICharacterBlueprint]
    public let industryJobs: [ESICharacterIndustryJob]
    public let assetMetadata: ESIPersonalEndpointMetadata
    public let blueprintMetadata: ESIPersonalEndpointMetadata
    public let jobMetadata: ESIPersonalEndpointMetadata

    public init(
        revision: UUID,
        characterID: Int64,
        synchronizedAt: Date,
        assets: [ESICharacterAsset],
        blueprints: [ESICharacterBlueprint],
        industryJobs: [ESICharacterIndustryJob],
        assetMetadata: ESIPersonalEndpointMetadata,
        blueprintMetadata: ESIPersonalEndpointMetadata,
        jobMetadata: ESIPersonalEndpointMetadata
    ) throws {
        guard characterID > 0,
              synchronizedAt.timeIntervalSinceReferenceDate.isFinite,
              Set(assets.map(\.itemID)).count == assets.count,
              Set(blueprints.map(\.itemID)).count == blueprints.count,
              Set(industryJobs.map(\.jobID)).count == industryJobs.count else {
            throw ESIPersonalDataError.invalidResponse
        }
        version = Self.payloadVersion
        self.revision = revision
        self.characterID = characterID
        self.synchronizedAt = synchronizedAt
        self.assets = assets.sorted { $0.itemID < $1.itemID }
        self.blueprints = blueprints.sorted { $0.itemID < $1.itemID }
        self.industryJobs = industryJobs.sorted { $0.jobID < $1.jobID }
        self.assetMetadata = assetMetadata
        self.blueprintMetadata = blueprintMetadata
        self.jobMetadata = jobMetadata
    }
}

public enum ESIPersonalDataError: Error, Equatable, Sendable {
    case invalidConfiguration
    case invalidCharacterID
    case authorizationRequired
    case permissionDenied
    case invalidResponse
    case responseTooLarge
    case pageLimitExceeded
    case recordLimitExceeded
    case inconsistentPagination
    case rateLimited(until: Date)
    case errorLimited(until: Date)
    case serverUnavailable
    case offline
    case transport
    case cacheCorrupted
    case cacheWriteFailed
    case stalePreview
    case previewNotFound
}

extension ESIPersonalDataError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .invalidConfiguration:
            "Die persönliche ESI-Konfiguration ist ungültig."
        case .invalidCharacterID:
            "Die Charakter-ID ist ungültig."
        case .authorizationRequired:
            "Der EVE-Zugang muss für die persönlichen Daten erneuert werden."
        case .permissionDenied:
            "Die erforderlichen ESI-Leseberechtigungen wurden nicht erteilt."
        case .invalidResponse:
            "ESI hat ungültige persönliche Daten geliefert."
        case .responseTooLarge:
            "Eine ESI-Antwort überschreitet die sichere Größenbegrenzung."
        case .pageLimitExceeded:
            "Die ESI-Seitenzahl überschreitet die sichere Begrenzung."
        case .recordLimitExceeded:
            "Die ESI-Datensatzmenge überschreitet die sichere Begrenzung."
        case .inconsistentPagination:
            "Die ESI-Seiten stammen nicht aus einem konsistenten Datenstand."
        case .rateLimited, .errorLimited:
            "ESI begrenzt weitere Anfragen vorübergehend."
        case .serverUnavailable:
            "ESI ist vorübergehend nicht verfügbar."
        case .offline:
            "ESI ist offline nicht erreichbar."
        case .transport:
            "Die persönliche ESI-Abfrage konnte nicht abgeschlossen werden."
        case .cacheCorrupted:
            "Der lokale persönliche ESI-Snapshot ist beschädigt."
        case .cacheWriteFailed:
            "Der persönliche ESI-Snapshot konnte nicht gespeichert werden."
        case .stalePreview:
            "Die ESI-Vorschau basiert nicht mehr auf dem aktuellen Stand."
        case .previewNotFound:
            "Die ESI-Vorschau ist nicht mehr verfügbar."
        }
    }
}

public extension ESIPersonalDataError {
    var diagnosticReason: String {
        switch self {
        case .invalidConfiguration: "invalid_configuration"
        case .invalidCharacterID: "invalid_character_id"
        case .authorizationRequired: "authorization_required"
        case .permissionDenied: "permission_denied"
        case .invalidResponse: "invalid_response"
        case .responseTooLarge: "response_too_large"
        case .pageLimitExceeded: "page_limit_exceeded"
        case .recordLimitExceeded: "record_limit_exceeded"
        case .inconsistentPagination: "inconsistent_pagination"
        case .rateLimited: "rate_limited"
        case .errorLimited: "error_limited"
        case .serverUnavailable: "server_unavailable"
        case .offline: "offline"
        case .transport: "transport"
        case .cacheCorrupted: "cache_corrupted"
        case .cacheWriteFailed: "cache_write_failed"
        case .stalePreview: "stale_preview"
        case .previewNotFound: "preview_not_found"
        }
    }
}

public struct EVETransientAccessToken: Sendable {
    public let value: String
    public let expiresAt: Date

    public init(value: String, expiresAt: Date) throws {
        guard !value.isEmpty, value.utf8.count <= 16_384,
              value.rangeOfCharacter(from: .newlines) == nil else {
            throw EVEAuthenticationError.invalidTokenResponse
        }
        self.value = value
        self.expiresAt = expiresAt
    }
}

public protocol EVEAccessTokenProviding: Sendable {
    func accessToken(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVETransientAccessToken
}

public struct EVERefreshAccessTokenService:
    EVEAccessTokenProviding,
    Sendable
{
    private let authorization: any EVEAuthorizationFlow
    private let vault: any EVERefreshTokenVault

    public init(
        authorization: any EVEAuthorizationFlow,
        vault: any EVERefreshTokenVault
    ) {
        self.authorization = authorization
        self.vault = vault
    }

    public func accessToken(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVETransientAccessToken {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        let previous: String
        do {
            guard let stored = try await vault.token(
                characterID: characterID
            ) else {
                throw EVEAuthenticationError.refreshTokenUnavailable
            }
            previous = stored
        } catch let error as EVEAuthenticationError {
            throw error
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw EVEAuthenticationError.localCredentialAccessFailed
        }
        let grant = try await authorization.refresh(
            refreshToken: previous,
            configuration: configuration
        )
        guard grant.identity.characterID == characterID else {
            throw EVEAuthenticationError.identityChanged
        }
        if grant.refreshToken != previous {
            do {
                try await vault.save(
                    grant.refreshToken,
                    characterID: characterID
                )
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                throw EVEAuthenticationError.localCredentialAccessFailed
            }
        }
        return try EVETransientAccessToken(
            value: grant.accessToken,
            expiresAt: grant.identity.expiresAt
        )
    }
}

public protocol ESIPersonalDataRemoteFetching: Sendable {
    func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> ESIPersonalDataSnapshot
}

public protocol ESIPersonalDataPersisting: Sendable {
    func snapshot(characterID: Int64) async throws -> ESIPersonalDataSnapshot?
    func save(
        _ snapshot: ESIPersonalDataSnapshot,
        expectedRevision: UUID?
    ) async throws
    func delete(characterID: Int64) async throws
}

public enum ESIPersonalDataChangeKind: String, Sendable {
    case added
    case changed
    case removed
}

public struct ESIPersonalDataChange: Identifiable, Equatable, Sendable {
    public var id: String {
        "\(dataSet.rawValue):\(identity):\(kind.rawValue)"
    }

    public let dataSet: ESIPersonalDataSet
    public let identity: Int64
    public let typeID: Int64?
    public let kind: ESIPersonalDataChangeKind
}

public struct ESIPersonalDataChangeCounts: Equatable, Sendable {
    public let added: Int
    public let changed: Int
    public let removed: Int
}

public struct ESIPersonalDataPreview: Identifiable, Equatable, Sendable {
    public let id: UUID
    public let characterID: Int64
    public let generatedAt: Date
    public let baseRevision: UUID?
    public let assetCounts: ESIPersonalDataChangeCounts
    public let blueprintCounts: ESIPersonalDataChangeCounts
    public let jobCounts: ESIPersonalDataChangeCounts
    public let changes: [ESIPersonalDataChange]
    public let totalChangeCount: Int
    public let isChangeListTruncated: Bool
}

public protocol ESIPersonalDataSynchronizing: Sendable {
    func current(
        characterID: Int64
    ) async throws -> ESIPersonalDataSnapshot?

    func inspect(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> ESIPersonalDataPreview

    func apply(previewID: UUID) async throws -> ESIPersonalDataSnapshot
    func discard(previewID: UUID) async
}

public actor ESIPersonalDataSynchronizationService:
    ESIPersonalDataSynchronizing
{
    private struct Pending {
        let preview: ESIPersonalDataPreview
        let proposed: ESIPersonalDataSnapshot
    }

    private let tokenProvider: any EVEAccessTokenProviding
    private let remote: any ESIPersonalDataRemoteFetching
    private let repository: any ESIPersonalDataPersisting
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var pending: [UUID: Pending] = [:]

    public init(
        tokenProvider: any EVEAccessTokenProviding,
        remote: any ESIPersonalDataRemoteFetching,
        repository: any ESIPersonalDataPersisting,
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.tokenProvider = tokenProvider
        self.remote = remote
        self.repository = repository
        self.now = now
        self.makeID = makeID
    }

    public func current(
        characterID: Int64
    ) async throws -> ESIPersonalDataSnapshot? {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        return try await repository.snapshot(characterID: characterID)
    }

    public func inspect(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> ESIPersonalDataPreview {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        try Task.checkCancellation()
        let existing = try await repository.snapshot(
            characterID: characterID
        )
        let token = try await tokenProvider.accessToken(
            characterID: characterID,
            configuration: configuration
        )
        let proposed = try await remote.fetch(
            characterID: characterID,
            accessToken: token.value,
            existing: existing
        )
        try Task.checkCancellation()
        guard proposed.characterID == characterID else {
            throw ESIPersonalDataError.invalidResponse
        }
        let allChanges = Self.changes(from: existing, to: proposed)
        let previewID = makeID()
        let preview = ESIPersonalDataPreview(
            id: previewID,
            characterID: characterID,
            generatedAt: now(),
            baseRevision: existing?.revision,
            assetCounts: Self.counts(
                allChanges.filter { $0.dataSet == .assets }
            ),
            blueprintCounts: Self.counts(
                allChanges.filter { $0.dataSet == .blueprints }
            ),
            jobCounts: Self.counts(
                allChanges.filter { $0.dataSet == .industryJobs }
            ),
            changes: Array(allChanges.prefix(500)),
            totalChangeCount: allChanges.count,
            isChangeListTruncated: allChanges.count > 500
        )
        pending.removeAll()
        pending[previewID] = Pending(
            preview: preview,
            proposed: proposed
        )
        return preview
    }

    public func apply(
        previewID: UUID
    ) async throws -> ESIPersonalDataSnapshot {
        guard let pending = pending[previewID] else {
            throw ESIPersonalDataError.previewNotFound
        }
        try Task.checkCancellation()
        try await repository.save(
            pending.proposed,
            expectedRevision: pending.preview.baseRevision
        )
        self.pending[previewID] = nil
        return pending.proposed
    }

    public func discard(previewID: UUID) async {
        pending[previewID] = nil
    }

    private static func counts(
        _ changes: [ESIPersonalDataChange]
    ) -> ESIPersonalDataChangeCounts {
        ESIPersonalDataChangeCounts(
            added: changes.count { $0.kind == .added },
            changed: changes.count { $0.kind == .changed },
            removed: changes.count { $0.kind == .removed }
        )
    }

    private static func changes(
        from old: ESIPersonalDataSnapshot?,
        to new: ESIPersonalDataSnapshot
    ) -> [ESIPersonalDataChange] {
        var result: [ESIPersonalDataChange] = []
        result += diff(
            old: old?.assets ?? [],
            new: new.assets,
            id: \.itemID,
            typeID: \.typeID,
            dataSet: .assets
        )
        result += diff(
            old: old?.blueprints ?? [],
            new: new.blueprints,
            id: \.itemID,
            typeID: \.typeID,
            dataSet: .blueprints
        )
        result += diff(
            old: old?.industryJobs ?? [],
            new: new.industryJobs,
            id: \.jobID,
            typeID: \.blueprintTypeID,
            dataSet: .industryJobs
        )
        return result.sorted {
            if $0.dataSet.rawValue != $1.dataSet.rawValue {
                return $0.dataSet.rawValue < $1.dataSet.rawValue
            }
            if $0.identity != $1.identity {
                return $0.identity < $1.identity
            }
            return $0.kind.rawValue < $1.kind.rawValue
        }
    }

    private static func diff<Value: Equatable>(
        old: [Value],
        new: [Value],
        id: KeyPath<Value, Int64>,
        typeID: KeyPath<Value, Int64>,
        dataSet: ESIPersonalDataSet
    ) -> [ESIPersonalDataChange] {
        let oldByID = Dictionary(uniqueKeysWithValues: old.map {
            ($0[keyPath: id], $0)
        })
        let newByID = Dictionary(uniqueKeysWithValues: new.map {
            ($0[keyPath: id], $0)
        })
        let identities = Set(oldByID.keys).union(newByID.keys)
        return identities.compactMap { identity in
            switch (oldByID[identity], newByID[identity]) {
            case (nil, let value?):
                ESIPersonalDataChange(
                    dataSet: dataSet,
                    identity: identity,
                    typeID: value[keyPath: typeID],
                    kind: .added
                )
            case (let value?, nil):
                ESIPersonalDataChange(
                    dataSet: dataSet,
                    identity: identity,
                    typeID: value[keyPath: typeID],
                    kind: .removed
                )
            case (let old?, let new?) where old != new:
                ESIPersonalDataChange(
                    dataSet: dataSet,
                    identity: identity,
                    typeID: new[keyPath: typeID],
                    kind: .changed
                )
            default:
                nil
            }
        }
    }
}
