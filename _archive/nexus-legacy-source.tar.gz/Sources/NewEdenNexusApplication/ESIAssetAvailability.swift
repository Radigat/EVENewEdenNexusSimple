import Foundation
import NewEdenNexusDomain

public enum ESIAssetAvailabilityAugmentationError:
    Error,
    Equatable,
    Sendable
{
    case quantityOverflow(Int64)
}

public struct ESIAssetAvailabilityAugmenter: Sendable {
    public init() {}

    public func adding(
        _ selection: ESIAssetAvailabilitySelectionSnapshot?,
        to calculation: InventoryAvailabilityCalculation
    ) throws -> InventoryAvailabilityCalculation {
        guard let selection else { return calculation }
        var quantities: [Int64: Int64] = [:]
        for line in selection.lines {
            let addition = (quantities[line.typeID] ?? 0)
                .addingReportingOverflow(line.quantity)
            guard !addition.overflow else {
                throw ESIAssetAvailabilityAugmentationError
                    .quantityOverflow(line.typeID)
            }
            quantities[line.typeID] = addition.partialValue
        }
        let lines = try calculation.lines.map { line in
            let external = quantities[line.typeID] ?? 0
            let active = line.activePhysicalQuantity
                .addingReportingOverflow(external)
            let eligible = line.eligiblePhysicalQuantity
                .addingReportingOverflow(external)
            guard !active.overflow, !eligible.overflow else {
                throw ESIAssetAvailabilityAugmentationError
                    .quantityOverflow(line.typeID)
            }
            let usable = min(line.requiredQuantity, eligible.partialValue)
            return InventoryAvailabilityLine(
                typeID: line.typeID,
                name: line.name,
                requiredQuantity: line.requiredQuantity,
                storedPhysicalQuantity: line.storedPhysicalQuantity,
                externalPhysicalQuantity: external,
                activePhysicalQuantity: active.partialValue,
                archivedExcludedQuantity: line.archivedExcludedQuantity,
                selectionExcludedQuantity: line.selectionExcludedQuantity,
                materialExcludedQuantity: line.materialExcludedQuantity,
                capExcludedQuantity: line.capExcludedQuantity,
                eligiblePhysicalQuantity: eligible.partialValue,
                usableQuantity: usable,
                uncoveredQuantity: line.requiredQuantity - usable,
                unusedEligibleQuantity: eligible.partialValue - usable
            )
        }
        return InventoryAvailabilityCalculation(
            formulaVersion: calculation.formulaVersion,
            lines: lines
        )
    }
}

public struct ESIAssetAvailabilityLine:
    Codable,
    Equatable,
    Sendable
{
    public let typeID: Int64
    public let locationID: Int64
    public let quantity: Int64

    public init(typeID: Int64, locationID: Int64, quantity: Int64) throws {
        guard typeID > 0, locationID > 0, quantity > 0 else {
            throw ESIAssetAvailabilityError.invalidSelection
        }
        self.typeID = typeID
        self.locationID = locationID
        self.quantity = quantity
    }
}

public struct ESIAssetAvailabilitySelectionSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public static let recordVersion = 1

    public let id: UUID
    public let projectID: UUID
    public let characterID: Int64
    public let sourceRevision: UUID
    public let lines: [ESIAssetAvailabilityLine]
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        characterID: Int64,
        sourceRevision: UUID,
        lines: [ESIAssetAvailabilityLine],
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard characterID > 0, !lines.isEmpty, createdAt <= updatedAt else {
            throw ESIAssetAvailabilityError.invalidSelection
        }
        let identities = Set(lines.map { "\($0.typeID):\($0.locationID)" })
        guard identities.count == lines.count else {
            throw ESIAssetAvailabilityError.invalidSelection
        }
        var totals: [Int64: Int64] = [:]
        for line in lines {
            let total = (totals[line.typeID] ?? 0)
                .addingReportingOverflow(line.quantity)
            guard !total.overflow else {
                throw ESIAssetAvailabilityError.invalidSelection
            }
            totals[line.typeID] = total.partialValue
        }
        self.id = id
        self.projectID = projectID
        self.characterID = characterID
        self.sourceRevision = sourceRevision
        self.lines = lines.sorted {
            ($0.typeID, $0.locationID) < ($1.typeID, $1.locationID)
        }
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    public var quantityByTypeID: [Int64: Int64] {
        Dictionary(grouping: lines, by: \.typeID).mapValues {
            $0.reduce(0) { $0 + $1.quantity }
        }
    }

    public var locationIDs: [Int64] {
        Array(Set(lines.map(\.locationID))).sorted()
    }
}

public struct ESIAssetAvailabilityPreviewLine:
    Identifiable,
    Equatable,
    Sendable
{
    public var id: String { "\(typeID):\(locationID)" }
    public let typeID: Int64
    public let locationID: Int64
    public let quantity: Int64
    public let manualStockQuantity: Int64

    public var hasPossibleDoubleCount: Bool {
        manualStockQuantity > 0
    }
}

public struct ESIAssetAvailabilityPreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let characterID: Int64
    public let sourceRevision: UUID
    public let generatedAt: Date
    public let selectedLocationIDs: [Int64]
    public let lines: [ESIAssetAvailabilityPreviewLine]
    public let replacedSelection:
        ESIAssetAvailabilitySelectionSnapshot?
    public let blockingTypeIDs: [Int64]

    public var canApply: Bool {
        !lines.isEmpty && blockingTypeIDs.isEmpty
    }
}

public struct ESIAssetAvailabilityRemovalPreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let selection: ESIAssetAvailabilitySelectionSnapshot
    public let generatedAt: Date

    public var projectID: UUID { selection.projectID }
    public var characterID: Int64 { selection.characterID }
    public var lineCount: Int { selection.lines.count }
    public var locationIDs: [Int64] { selection.locationIDs }
}

public enum ESIAssetAvailabilityError:
    Error,
    Equatable,
    Sendable
{
    case projectNotFound(UUID)
    case snapshotNotFound(Int64)
    case invalidLocationID(Int64)
    case unknownLocationID(Int64)
    case emptySelection
    case invalidSelection
    case possibleDoubleCount([Int64])
    case confirmationRequired
    case previewNotFound
    case selectionNotFound
    case stalePreview
    case persistenceFailure
}

extension ESIAssetAvailabilityError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .projectNotFound:
            "Das Produktionsprojekt wurde nicht gefunden."
        case .snapshotNotFound:
            "Für den Charakter ist kein lokaler Asset-Snapshot vorhanden."
        case .invalidLocationID, .unknownLocationID:
            "Mindestens ein ausgewählter EVE-Lagerort ist ungültig."
        case .emptySelection:
            "Die Auswahl enthält keine verwendbaren Assets."
        case .invalidSelection:
            "Die ESI-Asset-Auswahl ist ungültig."
        case .possibleDoubleCount:
            "Die Auswahl überschneidet sich mit manuellen oder importierten Beständen."
        case .confirmationRequired:
            "Die ESI-Asset-Auswahl muss ausdrücklich bestätigt werden."
        case .previewNotFound:
            "Die ESI-Asset-Vorschau ist nicht mehr verfügbar."
        case .selectionNotFound:
            "Für das Projekt ist keine ESI-Asset-Auswahl gespeichert."
        case .stalePreview:
            "Assets oder Bestände haben sich seit der Vorschau geändert."
        case .persistenceFailure:
            "Die bestätigte ESI-Asset-Auswahl konnte nicht gespeichert werden."
        }
    }
}

public protocol ESIAssetAvailabilitySelectionRepository: Sendable {
    func selection(projectID: UUID) async throws
        -> ESIAssetAvailabilitySelectionSnapshot?
    func selections(characterID: Int64) async throws
        -> [ESIAssetAvailabilitySelectionSnapshot]
    func save(
        _ selection: ESIAssetAvailabilitySelectionSnapshot,
        expectedUpdatedAt: Date?
    ) async throws
    func delete(projectID: UUID, expectedUpdatedAt: Date) async throws
    func delete(characterID: Int64) async throws
    func restore(
        _ selections: [ESIAssetAvailabilitySelectionSnapshot]
    ) async throws
}

public protocol ESIAssetAvailabilityManaging: Sendable {
    func selection(projectID: UUID) async throws
        -> ESIAssetAvailabilitySelectionSnapshot?
    func activeSelection(projectID: UUID) async throws
        -> ESIAssetAvailabilitySelectionSnapshot?
    func preview(
        projectID: UUID,
        characterID: Int64,
        locationIDs: [Int64]
    ) async throws -> ESIAssetAvailabilityPreview
    func apply(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> ESIAssetAvailabilitySelectionSnapshot
    func discard(previewID: UUID) async
    func previewRemoval(projectID: UUID) async throws
        -> ESIAssetAvailabilityRemovalPreview
    func applyRemoval(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> ESIAssetAvailabilitySelectionSnapshot
    func discardRemoval(previewID: UUID) async
}

public actor ESIAssetAvailabilityService:
    ESIAssetAvailabilityManaging
{
    private struct StockVersion: Equatable, Sendable {
        let id: UUID
        let typeID: Int64
        let quantity: Int64
        let updatedAt: Date
    }

    private struct Pending: Sendable {
        let preview: ESIAssetAvailabilityPreview
        let stockVersions: [StockVersion]
    }

    private let personalData: any ESIPersonalDataPersisting
    private let inventory: any InventoryAvailabilityRepository
    private let projects: any ProductionProjectRepository
    private let repository: any ESIAssetAvailabilitySelectionRepository
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var pending: [UUID: Pending] = [:]
    private var pendingRemovals:
        [UUID: ESIAssetAvailabilityRemovalPreview] = [:]

    public init(
        personalData: any ESIPersonalDataPersisting,
        inventory: any InventoryAvailabilityRepository,
        projects: any ProductionProjectRepository,
        repository: any ESIAssetAvailabilitySelectionRepository,
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.personalData = personalData
        self.inventory = inventory
        self.projects = projects
        self.repository = repository
        self.now = now
        self.makeID = makeID
    }

    public func selection(projectID: UUID) async throws
        -> ESIAssetAvailabilitySelectionSnapshot?
    {
        try await repository.selection(projectID: projectID)
    }

    public func activeSelection(projectID: UUID) async throws
        -> ESIAssetAvailabilitySelectionSnapshot?
    {
        guard let selection = try await repository.selection(
            projectID: projectID
        ), let snapshot = try await personalData.snapshot(
            characterID: selection.characterID
        ), snapshot.revision == selection.sourceRevision else {
            return nil
        }
        let selectedTypes = Set(selection.lines.map(\.typeID))
        let inventoryState = try await inventory.availabilityState()
        guard !inventoryState.stocks.contains(where: {
            $0.quantity > 0 && selectedTypes.contains($0.typeID)
        }) else {
            return nil
        }
        return selection
    }

    public func preview(
        projectID: UUID,
        characterID: Int64,
        locationIDs: [Int64]
    ) async throws -> ESIAssetAvailabilityPreview {
        try Task.checkCancellation()
        guard try await projects.project(id: projectID) != nil else {
            throw ESIAssetAvailabilityError.projectNotFound(projectID)
        }
        guard let snapshot = try await personalData.snapshot(
            characterID: characterID
        ) else {
            throw ESIAssetAvailabilityError.snapshotNotFound(characterID)
        }
        let selectedLocations = Array(Set(locationIDs)).sorted()
        guard !selectedLocations.isEmpty else {
            throw ESIAssetAvailabilityError.emptySelection
        }
        guard selectedLocations.allSatisfy({ $0 > 0 }) else {
            throw ESIAssetAvailabilityError.invalidLocationID(
                selectedLocations.first(where: { $0 <= 0 }) ?? 0
            )
        }
        let knownLocations = Set(snapshot.assets.map(\.locationID))
        guard let unknown = selectedLocations.first(where: {
            !knownLocations.contains($0)
        }) else {
            return try await makePreview(
                projectID: projectID,
                snapshot: snapshot,
                locationIDs: selectedLocations
            )
        }
        throw ESIAssetAvailabilityError.unknownLocationID(unknown)
    }

    public func apply(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> ESIAssetAvailabilitySelectionSnapshot {
        guard confirmed else {
            throw ESIAssetAvailabilityError.confirmationRequired
        }
        guard let pending = pending[previewID] else {
            throw ESIAssetAvailabilityError.previewNotFound
        }
        guard pending.preview.canApply else {
            throw ESIAssetAvailabilityError.possibleDoubleCount(
                pending.preview.blockingTypeIDs
            )
        }
        try Task.checkCancellation()
        guard let currentSnapshot = try await personalData.snapshot(
            characterID: pending.preview.characterID
        ), currentSnapshot.revision == pending.preview.sourceRevision else {
            throw ESIAssetAvailabilityError.stalePreview
        }
        let currentStockVersions = try await stockVersions()
        guard currentStockVersions == pending.stockVersions,
              try await repository.selection(
                projectID: pending.preview.projectID
              ) == pending.preview.replacedSelection else {
            throw ESIAssetAvailabilityError.stalePreview
        }
        let timestamp = now()
        let selection = try ESIAssetAvailabilitySelectionSnapshot(
            id: pending.preview.replacedSelection?.id ?? makeID(),
            projectID: pending.preview.projectID,
            characterID: pending.preview.characterID,
            sourceRevision: pending.preview.sourceRevision,
            lines: pending.preview.lines.map {
                try ESIAssetAvailabilityLine(
                    typeID: $0.typeID,
                    locationID: $0.locationID,
                    quantity: $0.quantity
                )
            },
            createdAt: pending.preview.replacedSelection?.createdAt
                ?? timestamp,
            updatedAt: timestamp
        )
        do {
            try await repository.save(
                selection,
                expectedUpdatedAt:
                    pending.preview.replacedSelection?.updatedAt
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ESIAssetAvailabilityError.persistenceFailure
        }
        self.pending[previewID] = nil
        return selection
    }

    public func discard(previewID: UUID) async {
        pending[previewID] = nil
    }

    public func previewRemoval(projectID: UUID) async throws
        -> ESIAssetAvailabilityRemovalPreview
    {
        try Task.checkCancellation()
        guard try await projects.project(id: projectID) != nil else {
            throw ESIAssetAvailabilityError.projectNotFound(projectID)
        }
        guard let selection = try await repository.selection(
            projectID: projectID
        ) else {
            throw ESIAssetAvailabilityError.selectionNotFound
        }
        let preview = ESIAssetAvailabilityRemovalPreview(
            id: makeID(),
            selection: selection,
            generatedAt: now()
        )
        pendingRemovals = pendingRemovals.filter {
            $0.value.projectID != projectID
        }
        pendingRemovals[preview.id] = preview
        return preview
    }

    public func applyRemoval(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> ESIAssetAvailabilitySelectionSnapshot {
        guard confirmed else {
            throw ESIAssetAvailabilityError.confirmationRequired
        }
        guard let preview = pendingRemovals[previewID] else {
            throw ESIAssetAvailabilityError.previewNotFound
        }
        try Task.checkCancellation()
        guard try await repository.selection(
            projectID: preview.projectID
        ) == preview.selection else {
            throw ESIAssetAvailabilityError.stalePreview
        }
        do {
            try await repository.delete(
                projectID: preview.projectID,
                expectedUpdatedAt: preview.selection.updatedAt
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ESIAssetAvailabilityError.persistenceFailure
        }
        pendingRemovals[previewID] = nil
        return preview.selection
    }

    public func discardRemoval(previewID: UUID) async {
        pendingRemovals[previewID] = nil
    }

    private func makePreview(
        projectID: UUID,
        snapshot: ESIPersonalDataSnapshot,
        locationIDs: [Int64]
    ) async throws -> ESIAssetAvailabilityPreview {
        let state = try await inventory.availabilityState()
        var manualByType: [Int64: Int64] = [:]
        for stock in state.stocks where stock.quantity > 0 {
            let total = (manualByType[stock.typeID] ?? 0)
                .addingReportingOverflow(stock.quantity)
            guard !total.overflow else {
                throw ESIAssetAvailabilityError.invalidSelection
            }
            manualByType[stock.typeID] = total.partialValue
        }
        let selected = Set(locationIDs)
        let grouped = Dictionary(
            grouping: snapshot.assets.filter {
                selected.contains($0.locationID) && $0.quantity > 0
            },
            by: { "\($0.typeID):\($0.locationID)" }
        )
        let lines = try grouped.values.compactMap { assets
            -> ESIAssetAvailabilityPreviewLine? in
            guard let first = assets.first else { return nil }
            var quantity: Int64 = 0
            for asset in assets {
                let total = quantity.addingReportingOverflow(asset.quantity)
                guard !total.overflow else {
                    throw ESIAssetAvailabilityError.invalidSelection
                }
                quantity = total.partialValue
            }
            return ESIAssetAvailabilityPreviewLine(
                typeID: first.typeID,
                locationID: first.locationID,
                quantity: quantity,
                manualStockQuantity: manualByType[first.typeID] ?? 0
            )
        }.sorted {
            ($0.typeID, $0.locationID) < ($1.typeID, $1.locationID)
        }
        guard !lines.isEmpty else {
            throw ESIAssetAvailabilityError.emptySelection
        }
        let current = try await repository.selection(projectID: projectID)
        let blockers = Array(Set(
            lines.filter(\.hasPossibleDoubleCount).map(\.typeID)
        )).sorted()
        let preview = ESIAssetAvailabilityPreview(
            id: makeID(),
            projectID: projectID,
            characterID: snapshot.characterID,
            sourceRevision: snapshot.revision,
            generatedAt: now(),
            selectedLocationIDs: locationIDs,
            lines: lines,
            replacedSelection: current,
            blockingTypeIDs: blockers
        )
        pending = pending.filter {
            $0.value.preview.projectID != projectID
        }
        pending[preview.id] = Pending(
            preview: preview,
            stockVersions: stockVersions(from: state)
        )
        return preview
    }

    private func stockVersions() async throws -> [StockVersion] {
        let state = try await inventory.availabilityState()
        return stockVersions(from: state)
    }

    private func stockVersions(
        from state: InventoryAvailabilityState
    ) -> [StockVersion] {
        return state.stocks.map {
            StockVersion(
                id: $0.id,
                typeID: $0.typeID,
                quantity: $0.quantity,
                updatedAt: $0.updatedAt
            )
        }.sorted { $0.id.uuidString < $1.id.uuidString }
    }
}
