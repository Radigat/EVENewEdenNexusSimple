import Foundation
import NewEdenNexusDomain

public struct MarketPriceRequestLine: Equatable, Sendable {
    public let typeID: Int64
    public let itemName: String
    public let quantity: Int64

    public init(typeID: Int64, itemName: String, quantity: Int64) {
        self.typeID = typeID
        self.itemName = itemName
        self.quantity = quantity
    }
}

public struct MarketPriceConfiguration: Equatable, Sendable {
    public let regionID: Int64
    public let locationID: Int64?
    public let locationLabel: String?

    public init(
        regionID: Int64,
        locationID: Int64?,
        locationLabel: String?
    ) {
        self.regionID = regionID
        self.locationID = locationID
        self.locationLabel = locationLabel?
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

public struct MarketRegionOption:
    Identifiable,
    Codable,
    Equatable,
    Sendable
{
    public var id: Int64 { regionID }

    public let regionID: Int64
    public let name: String

    public init(regionID: Int64, name: String) throws {
        let normalized = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard regionID > 0, Self.isSafeName(normalized) else {
            throw MarketPriceImportError.invalidRegionID
        }
        self.regionID = regionID
        self.name = normalized
    }

    private static func isSafeName(_ value: String) -> Bool {
        !value.isEmpty
            && value.utf8.count <= 512
            && value.rangeOfCharacter(from: .newlines) == nil
    }
}

public enum MarketLocationKind:
    String,
    Codable,
    Equatable,
    Sendable
{
    case tradeHub = "trade_hub"
    case npcStation = "npc_station"
    case publicStructure = "public_structure"
    case accessibleStructure = "accessible_structure"
}

public struct MarketLocationOption:
    Identifiable,
    Codable,
    Equatable,
    Sendable
{
    public var id: Int64 { locationID }

    public let locationID: Int64
    public let regionID: Int64
    public let name: String
    public let kind: MarketLocationKind

    public init(
        locationID: Int64,
        regionID: Int64,
        name: String,
        kind: MarketLocationKind
    ) throws {
        let normalized = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard locationID > 0, regionID > 0,
              !normalized.isEmpty,
              normalized.utf8.count <= 512,
              normalized.rangeOfCharacter(from: .newlines) == nil else {
            throw MarketPriceImportError.invalidLocationID
        }
        self.locationID = locationID
        self.regionID = regionID
        self.name = normalized
        self.kind = kind
    }
}

public struct MarketLocationDirectorySnapshot:
    Equatable,
    Sendable
{
    public let regions: [MarketRegionOption]
    public let locations: [MarketLocationOption]
    public let warnings: [String]

    public init(
        regions: [MarketRegionOption],
        locations: [MarketLocationOption],
        warnings: [String] = []
    ) {
        self.regions = regions
        self.locations = locations
        self.warnings = warnings
    }
}

public protocol MarketUniverseDirectoryRemoteFetching: Sendable {
    func regions() async throws -> [MarketRegionOption]
    func publicMarketStructureIDs() async throws -> Set<Int64>
    func solarSystemID(stationID: Int64) async throws -> Int64
    func regionID(solarSystemID: Int64) async throws -> Int64
}

public protocol MarketLocationDirectoryLoading: Sendable {
    func load() async throws -> MarketLocationDirectorySnapshot
}

public enum MarketTradeHubPreset {
    public static let all: [MarketLocationOption] = {
        [
            try? MarketLocationOption(
                locationID: 60_003_760,
                regionID: 10_000_002,
                name:
                    "Jita IV - Moon 4 - Caldari Navy Assembly Plant",
                kind: .tradeHub
            ),
            try? MarketLocationOption(
                locationID: 60_008_494,
                regionID: 10_000_043,
                name: "Amarr VIII (Oris) - Emperor Family Academy",
                kind: .tradeHub
            ),
            try? MarketLocationOption(
                locationID: 60_011_866,
                regionID: 10_000_032,
                name:
                    "Dodixie IX - Moon 20 - Federation Navy Assembly Plant",
                kind: .tradeHub
            ),
            try? MarketLocationOption(
                locationID: 60_004_588,
                regionID: 10_000_030,
                name: "Rens VI - Moon 8 - Brutor Tribe Treasury",
                kind: .tradeHub
            ),
            try? MarketLocationOption(
                locationID: 60_005_686,
                regionID: 10_000_042,
                name: "Hek VIII - Moon 12 - Boundless Creation Factory",
                kind: .tradeHub
            )
        ].compactMap { $0 }
    }()
}

public actor MarketLocationDirectoryService:
    MarketLocationDirectoryLoading
{
    private let remote: any MarketUniverseDirectoryRemoteFetching
    private let accounts: any EVECharacterAccountRepository
    private let personalData: any ESIPersonalDataPersisting
    private let locationNames: any ESILocationNamePersisting

    public init(
        remote: any MarketUniverseDirectoryRemoteFetching,
        accounts: any EVECharacterAccountRepository,
        personalData: any ESIPersonalDataPersisting,
        locationNames: any ESILocationNamePersisting
    ) {
        self.remote = remote
        self.accounts = accounts
        self.personalData = personalData
        self.locationNames = locationNames
    }

    public func load() async throws -> MarketLocationDirectorySnapshot {
        try Task.checkCancellation()
        var warnings: [String] = []
        let regions: [MarketRegionOption]
        do {
            regions = try await remote.regions().sorted {
                $0.name.localizedCaseInsensitiveCompare($1.name)
                    == .orderedAscending
            }
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            regions = Self.tradeHubRegions
            warnings.append(
                "Das vollständige Regionsverzeichnis ist offline nicht verfügbar; die bekannten Trade-Hub-Regionen bleiben auswählbar."
            )
        }

        let publicStructures: Set<Int64>
        do {
            publicStructures =
                try await remote.publicMarketStructureIDs()
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            publicStructures = []
            warnings.append(
                "Öffentliche Marktstrukturen konnten nicht neu klassifiziert werden."
            )
        }

        var values = Dictionary(
            uniqueKeysWithValues: MarketTradeHubPreset.all.map {
                ($0.locationID, $0)
            }
        )
        do {
            for account in try await accounts.accounts() {
                try Task.checkCancellation()
                guard let snapshot = try await personalData.snapshot(
                    characterID: account.characterID
                ), let cache = try await locationNames.cache(
                    characterID: account.characterID
                ) else {
                    continue
                }
                for stationID in Self.stationIDs(snapshot) {
                    guard let name = cache.names[stationID] else {
                        continue
                    }
                    do {
                        let systemID = try await remote.solarSystemID(
                            stationID: stationID
                        )
                        let regionID = try await remote.regionID(
                            solarSystemID: systemID
                        )
                        let option = try MarketLocationOption(
                            locationID: stationID,
                            regionID: regionID,
                            name: name,
                            kind: .npcStation
                        )
                        values[stationID] = values[stationID] ?? option
                    } catch is CancellationError {
                        throw CancellationError()
                    } catch {
                        continue
                    }
                }
                for structureID in
                    ESILocationNameResolutionService
                        .privateStructureLocationIDs(snapshot: snapshot) {
                    guard let entry =
                            cache.structureEntries?[structureID],
                          let systemID = entry.solarSystemID else {
                        continue
                    }
                    do {
                        let regionID = try await remote.regionID(
                            solarSystemID: systemID
                        )
                        values[structureID] = try MarketLocationOption(
                            locationID: structureID,
                            regionID: regionID,
                            name: entry.name,
                            kind: publicStructures.contains(structureID)
                                ? .publicStructure
                                : .accessibleStructure
                        )
                    } catch is CancellationError {
                        throw CancellationError()
                    } catch {
                        continue
                    }
                }
            }
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            warnings.append(
                "Lokal bekannte EVE-Standorte konnten nicht vollständig geladen werden."
            )
        }

        return MarketLocationDirectorySnapshot(
            regions: regions,
            locations: values.values.sorted {
                if $0.kind == .tradeHub, $1.kind != .tradeHub {
                    return true
                }
                if $0.kind != .tradeHub, $1.kind == .tradeHub {
                    return false
                }
                return $0.name.localizedCaseInsensitiveCompare($1.name)
                    == .orderedAscending
            },
            warnings: warnings
        )
    }

    private static var tradeHubRegions: [MarketRegionOption] {
        let names: [Int64: String] = [
            10_000_002: "The Forge",
            10_000_030: "Heimatar",
            10_000_032: "Sinq Laison",
            10_000_042: "Metropolis",
            10_000_043: "Domain"
        ]
        return names.compactMap {
            try? MarketRegionOption(regionID: $0.key, name: $0.value)
        }.sorted {
            $0.name.localizedCaseInsensitiveCompare($1.name)
                == .orderedAscending
        }
    }

    private static func stationIDs(
        _ snapshot: ESIPersonalDataSnapshot
    ) -> [Int64] {
        var ids = Set<Int64>()
        for asset in snapshot.assets
        where asset.locationType == "station"
            && (60_000_000...69_999_999).contains(asset.locationID) {
            ids.insert(asset.locationID)
        }
        for blueprint in snapshot.blueprints
        where (60_000_000...69_999_999).contains(
            blueprint.locationID
        ) {
            ids.insert(blueprint.locationID)
        }
        for job in snapshot.industryJobs {
            for id in [
                job.stationID,
                job.facilityID,
                job.outputLocationID
            ] where (60_000_000...69_999_999).contains(id) {
                ids.insert(id)
            }
        }
        return ids.sorted()
    }
}

public struct ESIMarketSellOrder: Codable, Equatable, Sendable {
    public let orderID: Int64
    public let typeID: Int64
    public let locationID: Int64
    public let unitPrice: ISKAmount
    public let remainingVolume: Int64

    public init(
        orderID: Int64,
        typeID: Int64,
        locationID: Int64,
        unitPrice: ISKAmount,
        remainingVolume: Int64
    ) {
        self.orderID = orderID
        self.typeID = typeID
        self.locationID = locationID
        self.unitPrice = unitPrice
        self.remainingVolume = remainingVolume
    }
}

public struct ESIMarketOrderPageSnapshot:
    Codable,
    Equatable,
    Sendable
{
    public let regionID: Int64
    public let typeID: Int64
    public let page: Int
    public let pageCount: Int
    public let orders: [ESIMarketSellOrder]
    public let ordersFetchedAt: Date
    public let metadata: ESIResponseMetadata

    public init(
        regionID: Int64,
        typeID: Int64,
        page: Int,
        pageCount: Int,
        orders: [ESIMarketSellOrder],
        ordersFetchedAt: Date,
        metadata: ESIResponseMetadata
    ) {
        self.regionID = regionID
        self.typeID = typeID
        self.page = page
        self.pageCount = pageCount
        self.orders = orders
        self.ordersFetchedAt = ordersFetchedAt
        self.metadata = metadata
    }

    public func isFresh(at date: Date) -> Bool {
        metadata.expiresAt.map { $0 > date } ?? false
    }
}

public enum ESIMarketOrderPageRemoteResult: Equatable, Sendable {
    case modified(
        orders: [ESIMarketSellOrder],
        pageCount: Int,
        metadata: ESIResponseMetadata
    )
    case notModified(metadata: ESIResponseMetadata)
}

public protocol ESIMarketOrderPageFetching: Sendable {
    func fetchSellOrders(
        regionID: Int64,
        typeID: Int64,
        page: Int,
        validators: ESICacheValidators?
    ) async throws -> ESIMarketOrderPageRemoteResult
}

public protocol ESIMarketOrderPageCaching: Sendable {
    func load(
        regionID: Int64,
        typeID: Int64,
        page: Int
    ) async throws -> ESIMarketOrderPageSnapshot?
    func save(_ snapshot: ESIMarketOrderPageSnapshot) async throws
}

public enum MarketPriceQuoteSource: String, Codable, Sendable {
    case freshCache = "fresh_cache"
    case network
    case notModified = "not_modified"
    case offlineCache = "offline_cache"
    case limitedCache = "limited_cache"
    case serverFallback = "server_fallback"

    public var isStaleFallback: Bool {
        switch self {
        case .offlineCache, .limitedCache, .serverFallback:
            true
        case .freshCache, .network, .notModified:
            false
        }
    }
}

public struct MarketPriceQuote: Equatable, Sendable {
    public let unitPrice: ISKAmount
    public let totalCostHundredths: Int64
    public let requestedQuantity: Int64
    public let fulfilledQuantity: Int64
    public let orderCount: Int
    public let ordersFetchedAt: Date
    public let checkedAt: Date
    public let cacheExpiresAt: Date?
    public let source: MarketPriceQuoteSource
}

public enum MarketPricePreviewState: String, Sendable {
    case insert
    case replacementRequired
    case unchanged
    case noOrders
    case insufficientVolume
    case failed
}

public struct MarketPricePreviewLine: Identifiable, Equatable, Sendable {
    public var id: Int64 { typeID }

    public let typeID: Int64
    public let itemName: String
    public let requestedQuantity: Int64
    public let availableQuantity: Int64
    public let quote: MarketPriceQuote?
    public let existingPrice: ManualPriceSnapshot?
    public let catalogVersion: CatalogDataVersion?
    public let state: MarketPricePreviewState
    public let message: String?
}

public struct MarketPriceImportPreview: Equatable, Sendable {
    public let profile: PriceProfileSnapshot?
    public let configuration: MarketPriceConfiguration
    public let lines: [MarketPricePreviewLine]
    public let createdAt: Date

    public var changedLines: [MarketPricePreviewLine] {
        lines.filter {
            $0.state == .insert || $0.state == .replacementRequired
        }
    }
}

public enum MarketPriceImportResult: String, Codable, Sendable {
    case inserted
    case replaced
    case unchanged
    case unavailable
}

public struct MarketPriceImportReportLine:
    Equatable,
    Codable,
    Sendable
{
    public let typeID: Int64
    public let itemName: String
    public let result: MarketPriceImportResult
    public let amountHundredths: Int64?
}

public struct MarketPriceImportReport:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public let id: UUID
    public let importedAt: Date
    public let profileID: UUID
    public let regionID: Int64
    public let locationID: Int64?
    public let lines: [MarketPriceImportReportLine]
}

public struct MarketPriceProvenanceSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let priceID: UUID
    public let profileID: UUID
    public let typeID: Int64
    public let regionID: Int64
    public let locationID: Int64?
    public let locationLabel: String?
    public let requestedQuantity: Int64
    public let fulfilledQuantity: Int64
    public let orderCount: Int
    public let totalCostHundredths: Int64
    public let ordersFetchedAt: Date
    public let checkedAt: Date
    public let cacheExpiresAt: Date?
    public let source: MarketPriceQuoteSource
    public let createdAt: Date

    public init(
        id: UUID,
        priceID: UUID,
        profileID: UUID,
        typeID: Int64,
        regionID: Int64,
        locationID: Int64?,
        locationLabel: String?,
        requestedQuantity: Int64,
        fulfilledQuantity: Int64,
        orderCount: Int,
        totalCostHundredths: Int64,
        ordersFetchedAt: Date,
        checkedAt: Date,
        cacheExpiresAt: Date?,
        source: MarketPriceQuoteSource,
        createdAt: Date
    ) {
        self.id = id
        self.priceID = priceID
        self.profileID = profileID
        self.typeID = typeID
        self.regionID = regionID
        self.locationID = locationID
        self.locationLabel = locationLabel
        self.requestedQuantity = requestedQuantity
        self.fulfilledQuantity = fulfilledQuantity
        self.orderCount = orderCount
        self.totalCostHundredths = totalCostHundredths
        self.ordersFetchedAt = ordersFetchedAt
        self.checkedAt = checkedAt
        self.cacheExpiresAt = cacheExpiresAt
        self.source = source
        self.createdAt = createdAt
    }
}

public struct MarketPriceImportMutation: Equatable, Sendable {
    public let expectation: PriceImportExpectation
    public let price: ManualPriceSnapshot
    public let provenance: MarketPriceProvenanceSnapshot

    public init(
        expectation: PriceImportExpectation,
        price: ManualPriceSnapshot,
        provenance: MarketPriceProvenanceSnapshot
    ) {
        self.expectation = expectation
        self.price = price
        self.provenance = provenance
    }
}

public struct MarketPriceImportCommit: Equatable, Sendable {
    public let profile: PriceProfileSnapshot
    public let mutations: [MarketPriceImportMutation]

    public init(
        profile: PriceProfileSnapshot,
        mutations: [MarketPriceImportMutation]
    ) {
        self.profile = profile
        self.mutations = mutations
    }
}

public protocol MarketPriceImportRepository: Sendable {
    func profile(id: UUID) async throws -> PriceProfileSnapshot?
    func price(
        profileID: UUID,
        typeID: Int64
    ) async throws -> ManualPriceSnapshot?
    func applyMarketPriceImport(
        _ commit: MarketPriceImportCommit
    ) async throws
    func marketPriceProvenances(
        profileID: UUID
    ) async throws -> [MarketPriceProvenanceSnapshot]
}

public enum ESIMarketPriceError: Error, Equatable, Sendable {
    case invalidConfiguration
    case invalidRequest
    case invalidResponse
    case responseTooLarge
    case notFound
    case rateLimited(until: Date)
    case errorLimited(until: Date)
    case serverUnavailable
    case offline
    case transport
    case cacheCorrupted
    case cacheWriteFailed
}

public enum MarketPriceImportError: Error, Equatable, Sendable {
    case invalidRegionID
    case invalidLocationID
    case emptyRequest
    case tooManyTypes(maximum: Int)
    case invalidRequestLine(typeID: Int64)
    case profileNotFound(UUID)
    case targetPriceSetRequired
    case itemNotFound(Int64)
    case unpublishedItem(Int64)
    case tooManyPages(typeID: Int64, maximum: Int)
    case arithmeticOverflow(Int64)
    case confirmationRequired
    case noChangesSelected
    case stalePreview
    case persistenceFailure
}

public protocol MarketPriceImporting: Sendable {
    func preview(
        profileID: UUID?,
        configuration: MarketPriceConfiguration,
        requirements: [MarketPriceRequestLine]
    ) async throws -> MarketPriceImportPreview
    func apply(
        preview: MarketPriceImportPreview,
        confirmed: Bool
    ) async throws -> MarketPriceImportReport
}

public struct MarketPriceImportService: MarketPriceImporting, Sendable {
    private let remote: any ESIMarketOrderPageFetching
    private let cache: any ESIMarketOrderPageCaching
    private let repository: any MarketPriceImportRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private let maximumTypes: Int
    private let maximumPagesPerType: Int
    private let previewLifetime: TimeInterval

    public init(
        remote: any ESIMarketOrderPageFetching,
        cache: any ESIMarketOrderPageCaching,
        repository: any MarketPriceImportRepository,
        catalog: any ItemBlueprintCatalogReading,
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init,
        maximumTypes: Int = 250,
        maximumPagesPerType: Int = 20,
        previewLifetime: TimeInterval = 15 * 60
    ) {
        self.remote = remote
        self.cache = cache
        self.repository = repository
        self.catalog = catalog
        self.now = now
        self.makeID = makeID
        self.maximumTypes = maximumTypes
        self.maximumPagesPerType = maximumPagesPerType
        self.previewLifetime = previewLifetime
    }

    public func preview(
        profileID: UUID?,
        configuration: MarketPriceConfiguration,
        requirements: [MarketPriceRequestLine]
    ) async throws -> MarketPriceImportPreview {
        try validate(configuration)
        let normalized = try normalizedRequirements(requirements)
        guard normalized.count <= maximumTypes else {
            throw MarketPriceImportError.tooManyTypes(
                maximum: maximumTypes
            )
        }
        let profile: PriceProfileSnapshot?
        if let profileID {
            guard let stored = try await repository.profile(id: profileID)
            else {
                throw MarketPriceImportError.profileNotFound(profileID)
            }
            profile = stored
        } else {
            profile = nil
        }
        var lines: [MarketPricePreviewLine] = []
        for requirement in normalized {
            try Task.checkCancellation()
            lines.append(
                try await previewLine(
                    requirement,
                    profileID: profile?.id,
                    configuration: configuration
                )
            )
        }
        return MarketPriceImportPreview(
            profile: profile,
            configuration: configuration,
            lines: lines,
            createdAt: now()
        )
    }

    public func apply(
        preview: MarketPriceImportPreview,
        confirmed: Bool
    ) async throws -> MarketPriceImportReport {
        guard confirmed else {
            throw MarketPriceImportError.confirmationRequired
        }
        guard preview.createdAt.addingTimeInterval(previewLifetime) > now()
        else {
            throw MarketPriceImportError.stalePreview
        }
        guard !preview.changedLines.isEmpty else {
            throw MarketPriceImportError.noChangesSelected
        }
        guard let profile = preview.profile else {
            throw MarketPriceImportError.targetPriceSetRequired
        }
        guard try await repository.profile(id: profile.id) == profile else {
            throw MarketPriceImportError.stalePreview
        }
        let timestamp = now()
        let mutations = try preview.changedLines.map { line in
            guard let quote = line.quote,
                  let version = line.catalogVersion else {
                throw MarketPriceImportError.stalePreview
            }
            let priceID = line.existingPrice?.id ?? makeID()
            let price = try ManualPriceSnapshot(
                id: priceID,
                profileID: profile.id,
                typeID: line.typeID,
                itemName: line.itemName,
                amount: quote.unitPrice,
                source: .esiMarket,
                validFrom: quote.ordersFetchedAt,
                validUntil: nil,
                catalogBuildNumber: version.buildNumber,
                catalogContentSHA256: version.contentSHA256,
                createdAt: line.existingPrice?.createdAt ?? timestamp,
                updatedAt: timestamp
            )
            let provenance = MarketPriceProvenanceSnapshot(
                id: makeID(),
                priceID: priceID,
                profileID: profile.id,
                typeID: line.typeID,
                regionID: preview.configuration.regionID,
                locationID: preview.configuration.locationID,
                locationLabel: preview.configuration.locationLabel,
                requestedQuantity: quote.requestedQuantity,
                fulfilledQuantity: quote.fulfilledQuantity,
                orderCount: quote.orderCount,
                totalCostHundredths: quote.totalCostHundredths,
                ordersFetchedAt: quote.ordersFetchedAt,
                checkedAt: quote.checkedAt,
                cacheExpiresAt: quote.cacheExpiresAt,
                source: quote.source,
                createdAt: timestamp
            )
            return MarketPriceImportMutation(
                expectation: line.existingPrice.map {
                    .existing($0)
                } ?? .missing(
                    profileID: profile.id,
                    typeID: line.typeID
                ),
                price: price,
                provenance: provenance
            )
        }
        do {
            try Task.checkCancellation()
            try await repository.applyMarketPriceImport(
                MarketPriceImportCommit(
                    profile: profile,
                    mutations: mutations
                )
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch PriceProfileRepositoryError.staleState {
            throw MarketPriceImportError.stalePreview
        } catch {
            throw MarketPriceImportError.persistenceFailure
        }
        return MarketPriceImportReport(
            id: makeID(),
            importedAt: timestamp,
            profileID: profile.id,
            regionID: preview.configuration.regionID,
            locationID: preview.configuration.locationID,
            lines: preview.lines.map { line in
                MarketPriceImportReportLine(
                    typeID: line.typeID,
                    itemName: line.itemName,
                    result: importResult(for: line.state),
                    amountHundredths: line.quote?
                        .unitPrice.hundredths
                )
            }
        )
    }

    private func previewLine(
        _ requirement: MarketPriceRequestLine,
        profileID: UUID?,
        configuration: MarketPriceConfiguration
    ) async throws -> MarketPricePreviewLine {
        let details: CatalogItemDetails
        switch try await catalog.item(typeID: requirement.typeID) {
        case .found(let value):
            guard value.summary.published else {
                throw MarketPriceImportError.unpublishedItem(
                    requirement.typeID
                )
            }
            details = value
        case .notFound:
            throw MarketPriceImportError.itemNotFound(
                requirement.typeID
            )
        }
        let existing: ManualPriceSnapshot?
        if let profileID {
            existing = try await repository.price(
                profileID: profileID,
                typeID: requirement.typeID
            )
        } else {
            existing = nil
        }
        do {
            let loaded = try await loadOrders(
                regionID: configuration.regionID,
                typeID: requirement.typeID
            )
            let filtered: [ESIMarketSellOrder]
            if let locationID = configuration.locationID {
                filtered = loaded.orders.filter {
                    $0.locationID == locationID
                }
            } else {
                filtered = loaded.orders
            }
            let available = try filtered.reduce(Int64.zero) {
                let (sum, overflow) = $0.addingReportingOverflow(
                    $1.remainingVolume
                )
                guard !overflow else {
                    throw MarketPriceImportError.arithmeticOverflow(
                        requirement.typeID
                    )
                }
                return sum
            }
            guard !filtered.isEmpty else {
                return unavailableLine(
                    requirement,
                    existing: existing,
                    version: details.version,
                    state: .noOrders,
                    available: 0,
                    message: "Keine passende Verkaufsorder gefunden."
                )
            }
            guard available >= requirement.quantity else {
                return unavailableLine(
                    requirement,
                    existing: existing,
                    version: details.version,
                    state: .insufficientVolume,
                    available: available,
                    message:
                        "Verfügbar \(available), benötigt \(requirement.quantity)."
                )
            }
            let quote = try quote(
                orders: filtered,
                quantity: requirement.quantity,
                typeID: requirement.typeID,
                loaded: loaded
            )
            return MarketPricePreviewLine(
                typeID: requirement.typeID,
                itemName: details.summary.name,
                requestedQuantity: requirement.quantity,
                availableQuantity: available,
                quote: quote,
                existingPrice: existing,
                catalogVersion: details.version,
                state: existing.map {
                    $0.amount == quote.unitPrice
                        ? .unchanged
                        : .replacementRequired
                } ?? .insert,
                message: quote.source.isStaleFallback
                    ? "Offline-/Fallback-Snapshot; Alter sichtbar prüfen."
                    : nil
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            return unavailableLine(
                requirement,
                existing: existing,
                version: details.version,
                state: .failed,
                available: 0,
                message: safeFailureMessage(error)
            )
        }
    }

    private struct LoadedOrders {
        let orders: [ESIMarketSellOrder]
        let source: MarketPriceQuoteSource
        let ordersFetchedAt: Date
        let checkedAt: Date
        let expiresAt: Date?
    }

    private struct LoadedPage {
        let snapshot: ESIMarketOrderPageSnapshot
        let source: MarketPriceQuoteSource
    }

    private func loadOrders(
        regionID: Int64,
        typeID: Int64
    ) async throws -> LoadedOrders {
        let first = try await loadPage(
            regionID: regionID,
            typeID: typeID,
            page: 1
        )
        guard first.snapshot.pageCount <= maximumPagesPerType else {
            throw MarketPriceImportError.tooManyPages(
                typeID: typeID,
                maximum: maximumPagesPerType
            )
        }
        var pages = [first]
        if first.snapshot.pageCount > 1 {
            for page in 2...first.snapshot.pageCount {
                try Task.checkCancellation()
                let loaded = try await loadPage(
                    regionID: regionID,
                    typeID: typeID,
                    page: page
                )
                guard loaded.snapshot.pageCount
                        == first.snapshot.pageCount else {
                    throw ESIMarketPriceError.invalidResponse
                }
                pages.append(loaded)
            }
        }
        let orders = pages.flatMap(\.snapshot.orders)
        guard Set(orders.map(\.orderID)).count == orders.count else {
            throw ESIMarketPriceError.invalidResponse
        }
        return LoadedOrders(
            orders: orders,
            source: combinedSource(pages.map(\.source)),
            ordersFetchedAt:
                pages.map(\.snapshot.ordersFetchedAt).min() ?? now(),
            checkedAt:
                pages.map(\.snapshot.metadata.checkedAt).max() ?? now(),
            expiresAt:
                pages.compactMap(\.snapshot.metadata.expiresAt).min()
        )
    }

    private func loadPage(
        regionID: Int64,
        typeID: Int64,
        page: Int
    ) async throws -> LoadedPage {
        let cached = try await cache.load(
            regionID: regionID,
            typeID: typeID,
            page: page
        )
        if let cached, cached.isFresh(at: now()) {
            return LoadedPage(snapshot: cached, source: .freshCache)
        }
        do {
            let result = try await remote.fetchSellOrders(
                regionID: regionID,
                typeID: typeID,
                page: page,
                validators: cached?.metadata.validators
            )
            let snapshot: ESIMarketOrderPageSnapshot
            let source: MarketPriceQuoteSource
            switch result {
            case .modified(let orders, let pageCount, let metadata):
                snapshot = ESIMarketOrderPageSnapshot(
                    regionID: regionID,
                    typeID: typeID,
                    page: page,
                    pageCount: pageCount,
                    orders: orders,
                    ordersFetchedAt: metadata.checkedAt,
                    metadata: metadata
                )
                source = .network
            case .notModified(let metadata):
                guard let cached else {
                    throw ESIMarketPriceError.cacheCorrupted
                }
                snapshot = ESIMarketOrderPageSnapshot(
                    regionID: regionID,
                    typeID: typeID,
                    page: page,
                    pageCount: cached.pageCount,
                    orders: cached.orders,
                    ordersFetchedAt: cached.ordersFetchedAt,
                    metadata: metadata
                )
                source = .notModified
            }
            try await cache.save(snapshot)
            return LoadedPage(snapshot: snapshot, source: source)
        } catch let error as ESIMarketPriceError {
            guard let cached else { throw error }
            let source: MarketPriceQuoteSource
            switch error {
            case .offline, .transport:
                source = .offlineCache
            case .rateLimited, .errorLimited:
                source = .limitedCache
            case .serverUnavailable:
                source = .serverFallback
            default:
                throw error
            }
            return LoadedPage(snapshot: cached, source: source)
        }
    }

    private func quote(
        orders: [ESIMarketSellOrder],
        quantity: Int64,
        typeID: Int64,
        loaded: LoadedOrders
    ) throws -> MarketPriceQuote {
        let sorted = orders.sorted {
            $0.unitPrice == $1.unitPrice
                ? $0.orderID < $1.orderID
                : $0.unitPrice < $1.unitPrice
        }
        var remaining = quantity
        var total: Int64 = 0
        var used = 0
        for order in sorted where remaining > 0 {
            let fill = min(remaining, order.remainingVolume)
            let (cost, multiplyOverflow) =
                order.unitPrice.hundredths.multipliedReportingOverflow(
                    by: fill
                )
            let (sum, addOverflow) = total.addingReportingOverflow(cost)
            guard !multiplyOverflow, !addOverflow else {
                throw MarketPriceImportError.arithmeticOverflow(typeID)
            }
            total = sum
            remaining -= fill
            used += 1
        }
        guard remaining == 0 else {
            throw ESIMarketPriceError.invalidResponse
        }
        let quotient = total / quantity
        let unitHundredths = total % quantity == 0
            ? quotient
            : quotient + 1
        return MarketPriceQuote(
            unitPrice: try ISKAmount(hundredths: unitHundredths),
            totalCostHundredths: total,
            requestedQuantity: quantity,
            fulfilledQuantity: quantity,
            orderCount: used,
            ordersFetchedAt: loaded.ordersFetchedAt,
            checkedAt: loaded.checkedAt,
            cacheExpiresAt: loaded.expiresAt,
            source: loaded.source
        )
    }

    private func unavailableLine(
        _ requirement: MarketPriceRequestLine,
        existing: ManualPriceSnapshot?,
        version: CatalogDataVersion,
        state: MarketPricePreviewState,
        available: Int64,
        message: String
    ) -> MarketPricePreviewLine {
        MarketPricePreviewLine(
            typeID: requirement.typeID,
            itemName: requirement.itemName,
            requestedQuantity: requirement.quantity,
            availableQuantity: available,
            quote: nil,
            existingPrice: existing,
            catalogVersion: version,
            state: state,
            message: message
        )
    }

    private func normalizedRequirements(
        _ requirements: [MarketPriceRequestLine]
    ) throws -> [MarketPriceRequestLine] {
        guard !requirements.isEmpty else {
            throw MarketPriceImportError.emptyRequest
        }
        var combined: [Int64: MarketPriceRequestLine] = [:]
        for line in requirements {
            let name = line.itemName.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            guard line.typeID > 0, line.quantity > 0, !name.isEmpty else {
                throw MarketPriceImportError.invalidRequestLine(
                    typeID: line.typeID
                )
            }
            if let existing = combined[line.typeID] {
                let (quantity, overflow) =
                    existing.quantity.addingReportingOverflow(line.quantity)
                guard !overflow else {
                    throw MarketPriceImportError.arithmeticOverflow(
                        line.typeID
                    )
                }
                combined[line.typeID] = MarketPriceRequestLine(
                    typeID: line.typeID,
                    itemName: existing.itemName,
                    quantity: quantity
                )
            } else {
                combined[line.typeID] = MarketPriceRequestLine(
                    typeID: line.typeID,
                    itemName: name,
                    quantity: line.quantity
                )
            }
        }
        return combined.values.sorted { $0.typeID < $1.typeID }
    }

    private func validate(_ configuration: MarketPriceConfiguration)
        throws {
        guard configuration.regionID > 0 else {
            throw MarketPriceImportError.invalidRegionID
        }
        guard configuration.locationID.map({ $0 > 0 }) ?? true else {
            throw MarketPriceImportError.invalidLocationID
        }
    }

    private func combinedSource(
        _ sources: [MarketPriceQuoteSource]
    ) -> MarketPriceQuoteSource {
        let priority: [MarketPriceQuoteSource] = [
            .offlineCache,
            .limitedCache,
            .serverFallback,
            .network,
            .notModified,
            .freshCache
        ]
        return priority.first(where: { sources.contains($0) })
            ?? .freshCache
    }

    private func importResult(
        for state: MarketPricePreviewState
    ) -> MarketPriceImportResult {
        switch state {
        case .insert:
            .inserted
        case .replacementRequired:
            .replaced
        case .unchanged:
            .unchanged
        case .noOrders, .insufficientVolume, .failed:
            .unavailable
        }
    }

    private func safeFailureMessage(_ error: Error) -> String {
        switch error {
        case ESIMarketPriceError.offline:
            "Keine Verbindung; es ist kein verwendbarer Cache vorhanden."
        case ESIMarketPriceError.rateLimited,
             ESIMarketPriceError.errorLimited:
            "CCP begrenzt Marktanfragen vorübergehend."
        case ESIMarketPriceError.serverUnavailable:
            "Die öffentlichen ESI-Marktdaten sind vorübergehend nicht verfügbar."
        case ESIMarketPriceError.notFound:
            "Für den gewählten Marktfilter wurden keine Daten gefunden."
        case ESIMarketPriceError.cacheCorrupted:
            "Der lokale Marktcache ist ungültig und wurde nicht verwendet."
        case MarketPriceImportError.tooManyPages:
            "Die Antwort überschreitet die sichere Seitengrenze."
        case MarketPriceImportError.itemNotFound,
             MarketPriceImportError.unpublishedItem:
            "Der Gegenstand ist im aktiven Katalog nicht verwendbar."
        default:
            "Die Marktpreisvorschau konnte für diesen Gegenstand nicht erstellt werden."
        }
    }
}
