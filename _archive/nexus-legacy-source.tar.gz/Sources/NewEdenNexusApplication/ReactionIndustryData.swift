import Foundation
import NewEdenNexusDomain

public struct ReactionFormulaMetadata: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let formulaTypeID: Int64
    public let formulaGroupID: Int64
    public let kind: ReactionKind
    public let reactorTypeID: Int64
    public let profile: ReactionRuleProfile

    public init(
        version: CatalogDataVersion,
        formulaTypeID: Int64,
        formulaGroupID: Int64,
        kind: ReactionKind,
        reactorTypeID: Int64,
        profile: ReactionRuleProfile
    ) {
        self.version = version
        self.formulaTypeID = formulaTypeID
        self.formulaGroupID = formulaGroupID
        self.kind = kind
        self.reactorTypeID = reactorTypeID
        self.profile = profile
    }
}

public enum ReactionIndustryDataError: Error, Equatable, Sendable {
    case noActiveDataVersion
    case catalogVersionChanged
    case missingRuleProfile
    case invalidRuleProfile(IndustryPreflightResult)
    case formulaNotFound(Int64)
    case formulaUnpublished(Int64)
    case formulaHasUnsupportedActivities(Int64)
    case unknownFormulaGroup(Int64)
    case missingReactor(ReactionKind)
    case persistenceFailure
}

public protocol ReactionIndustryDataReading: Sendable {
    func formulaMetadata(
        formulaTypeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> ReactionFormulaMetadata
}

public struct NoReactionIndustryData:
    ReactionIndustryDataReading,
    Sendable
{
    public init() {}

    public func formulaMetadata(
        formulaTypeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> ReactionFormulaMetadata {
        throw ReactionIndustryDataError.missingRuleProfile
    }
}

public struct ReactionStagePlanningPolicy: Equatable, Sendable {
    public let defaultContext: ReactionPlanningContext?
    public let contextByFormulaTypeID: [Int64: ReactionPlanningContext]

    public init(
        defaultContext: ReactionPlanningContext? = nil,
        contextByFormulaTypeID: [Int64: ReactionPlanningContext] = [:]
    ) {
        self.defaultContext = defaultContext
        self.contextByFormulaTypeID = contextByFormulaTypeID
    }

    public static let catalogNeutral = ReactionStagePlanningPolicy()

    public func context(
        formulaTypeID: Int64,
        profile: ReactionRuleProfile
    ) -> ReactionPlanningContext {
        contextByFormulaTypeID[formulaTypeID]
            ?? defaultContext
            ?? .neutral(profile: profile)
    }
}
