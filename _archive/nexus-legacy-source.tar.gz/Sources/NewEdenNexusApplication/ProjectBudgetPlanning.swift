import Foundation
import NewEdenNexusDomain

public protocol ProjectBudgetRepository: Sendable {
    func configuration(
        projectID: UUID
    ) async throws -> ProjectBudgetConfigurationSnapshot?
    func save(
        configuration: ProjectBudgetConfigurationSnapshot,
        expectedUpdatedAt: Date?
    ) async throws
}

public struct ProjectBudgetDraft: Equatable, Sendable {
    public let projectID: UUID
    public let graphID: UUID
    public let priceProfileID: UUID?
    public let logisticsCost: NonNegativeISKAmount
    public let productionCost: NonNegativeISKAmount
    public let purchases: [ShoppingListPosition]

    public init(
        projectID: UUID,
        graphID: UUID,
        priceProfileID: UUID?,
        logisticsCost: NonNegativeISKAmount,
        productionCost: NonNegativeISKAmount,
        purchases: [ShoppingListPosition]
    ) {
        self.projectID = projectID
        self.graphID = graphID
        self.priceProfileID = priceProfileID
        self.logisticsCost = logisticsCost
        self.productionCost = productionCost
        self.purchases = purchases
    }
}

public struct ProjectBudgetMissingPrice: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
}

public struct ProjectBudgetPricingVersion: Equatable, Sendable {
    public let profileID: UUID
    public let profileUpdatedAt: Date
    public let prices: [ProjectEconomicsPriceVersion]
}

public struct ProjectBudgetPreview: Equatable, Sendable {
    public let draft: ProjectBudgetDraft
    public let profiles: [PriceProfileSnapshot]
    public let storedConfiguration:
        ProjectBudgetConfigurationSnapshot?
    public let selectedProfile: PriceProfileSnapshot?
    public let pricingVersion: ProjectBudgetPricingVersion?
    public let missingPrices: [ProjectBudgetMissingPrice]
    public let calculation: ProjectBudgetCalculation?

    public var isComplete: Bool {
        calculation != nil && missingPrices.isEmpty
    }
}

public enum ProjectBudgetServiceError: Error, Equatable, Sendable {
    case confirmationRequired
    case profileRequired
    case profileNotFound(UUID)
    case staleConfiguration
    case stalePricing
    case persistenceFailure
}

public protocol ProjectBudgetManaging: Sendable {
    func load(
        projectID: UUID,
        graphID: UUID,
        purchases: [ShoppingListPosition],
        at date: Date
    ) async throws -> ProjectBudgetPreview
    func preview(
        draft: ProjectBudgetDraft,
        storedConfiguration: ProjectBudgetConfigurationSnapshot?,
        at date: Date
    ) async throws -> ProjectBudgetPreview
    func apply(
        _ preview: ProjectBudgetPreview,
        confirmed: Bool,
        at date: Date
    ) async throws -> ProjectBudgetPreview
}

public struct ProjectBudgetService: ProjectBudgetManaging, Sendable {
    private let repository: any ProjectBudgetRepository
    private let prices: any PriceProfileManaging
    private let calculator: ProjectBudgetCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any ProjectBudgetRepository,
        prices: any PriceProfileManaging,
        calculator: ProjectBudgetCalculator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.repository = repository
        self.prices = prices
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func load(
        projectID: UUID,
        graphID: UUID,
        purchases: [ShoppingListPosition],
        at date: Date
    ) async throws -> ProjectBudgetPreview {
        try Task.checkCancellation()
        let stored = try await loadConfiguration(projectID: projectID)
        let profiles = try await prices.profiles()
        let selectedID = stored?.priceProfileID
            ?? profiles.first(where: \.isActive)?.id
            ?? profiles.first?.id
        return try await evaluate(
            draft: ProjectBudgetDraft(
                projectID: projectID,
                graphID: graphID,
                priceProfileID: selectedID,
                logisticsCost: stored?.logisticsCost ?? .zero,
                productionCost: stored?.productionCost ?? .zero,
                purchases: purchases
            ),
            storedConfiguration: stored,
            profiles: profiles,
            at: date
        )
    }

    public func preview(
        draft: ProjectBudgetDraft,
        storedConfiguration: ProjectBudgetConfigurationSnapshot?,
        at date: Date
    ) async throws -> ProjectBudgetPreview {
        try Task.checkCancellation()
        return try await evaluate(
            draft: draft,
            storedConfiguration: storedConfiguration,
            profiles: try await prices.profiles(),
            at: date
        )
    }

    public func apply(
        _ preview: ProjectBudgetPreview,
        confirmed: Bool,
        at date: Date
    ) async throws -> ProjectBudgetPreview {
        guard confirmed else {
            throw ProjectBudgetServiceError.confirmationRequired
        }
        guard let profileID = preview.draft.priceProfileID else {
            throw ProjectBudgetServiceError.profileRequired
        }
        let fresh = try await self.preview(
            draft: preview.draft,
            storedConfiguration: preview.storedConfiguration,
            at: date
        )
        guard fresh.pricingVersion == preview.pricingVersion,
              fresh.missingPrices == preview.missingPrices else {
            throw ProjectBudgetServiceError.stalePricing
        }
        guard fresh.profiles.contains(where: { $0.id == profileID }) else {
            throw ProjectBudgetServiceError.profileNotFound(profileID)
        }
        let timestamp = now()
        let stored = preview.storedConfiguration
        let configuration = try ProjectBudgetConfigurationSnapshot(
            id: stored?.id ?? makeID(),
            projectID: preview.draft.projectID,
            priceProfileID: profileID,
            logisticsCost: preview.draft.logisticsCost,
            productionCost: preview.draft.productionCost,
            createdAt: stored?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
        do {
            try await repository.save(
                configuration: configuration,
                expectedUpdatedAt: stored?.updatedAt
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch ProjectBudgetServiceError.staleConfiguration {
            throw ProjectBudgetServiceError.staleConfiguration
        } catch {
            throw ProjectBudgetServiceError.persistenceFailure
        }
        return ProjectBudgetPreview(
            draft: fresh.draft,
            profiles: fresh.profiles,
            storedConfiguration: configuration,
            selectedProfile: fresh.selectedProfile,
            pricingVersion: fresh.pricingVersion,
            missingPrices: fresh.missingPrices,
            calculation: fresh.calculation
        )
    }

    private func loadConfiguration(
        projectID: UUID
    ) async throws -> ProjectBudgetConfigurationSnapshot? {
        do {
            return try await repository.configuration(
                projectID: projectID
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ProjectBudgetServiceError.persistenceFailure
        }
    }

    private func evaluate(
        draft: ProjectBudgetDraft,
        storedConfiguration: ProjectBudgetConfigurationSnapshot?,
        profiles: [PriceProfileSnapshot],
        at date: Date
    ) async throws -> ProjectBudgetPreview {
        let references = requiredPriceReferences(draft.purchases)
        guard let profileID = draft.priceProfileID,
              let profile = profiles.first(where: {
                  $0.id == profileID
              }) else {
            return ProjectBudgetPreview(
                draft: draft,
                profiles: profiles,
                storedConfiguration: storedConfiguration,
                selectedProfile: nil,
                pricingVersion: nil,
                missingPrices: references,
                calculation: nil
            )
        }
        let resolution = try await prices.resolve(
            typeIDs: references.map(\.typeID),
            profileID: profileID,
            at: date
        )
        let missingSet = Set(resolution.missingTypeIDs)
        let missing = references.filter {
            missingSet.contains($0.typeID)
        }
        let version = ProjectBudgetPricingVersion(
            profileID: profile.id,
            profileUpdatedAt: profile.updatedAt,
            prices: resolution.pricesByTypeID.map {
                ProjectEconomicsPriceVersion(
                    typeID: $0.key,
                    amount: $0.value
                )
            }.sorted { $0.typeID < $1.typeID }
        )
        return ProjectBudgetPreview(
            draft: draft,
            profiles: profiles,
            storedConfiguration: storedConfiguration,
            selectedProfile: profile,
            pricingVersion: version,
            missingPrices: missing,
            calculation: missing.isEmpty
                ? try calculator.calculate(
                    purchases: draft.purchases,
                    pricesByTypeID: resolution.pricesByTypeID,
                    logisticsCost: draft.logisticsCost,
                    productionCost: draft.productionCost
                )
                : nil
        )
    }

    private func requiredPriceReferences(
        _ purchases: [ShoppingListPosition]
    ) -> [ProjectBudgetMissingPrice] {
        var result: [Int64: ProjectBudgetMissingPrice] = [:]
        for purchase in purchases where purchase.purchaseQuantity > 0 {
            if result[purchase.typeID] == nil {
                result[purchase.typeID] = ProjectBudgetMissingPrice(
                    typeID: purchase.typeID,
                    name: purchase.name
                )
            }
        }
        return result.values.sorted { $0.typeID < $1.typeID }
    }
}
