import Foundation
import NewEdenNexusDomain

public struct T2InventionMetadata: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let sourceBlueprintTypeID: Int64
    public let inventedBlueprintTypeID: Int64
    public let baseLicensedRuns: Int64
    public let baseProbabilityMillionths: Int
    public let materialTypeIDs: [Int64]

    public init(
        version: CatalogDataVersion,
        sourceBlueprintTypeID: Int64,
        inventedBlueprintTypeID: Int64,
        baseLicensedRuns: Int64,
        baseProbabilityMillionths: Int,
        materialTypeIDs: [Int64]
    ) {
        self.version = version
        self.sourceBlueprintTypeID = sourceBlueprintTypeID
        self.inventedBlueprintTypeID = inventedBlueprintTypeID
        self.baseLicensedRuns = baseLicensedRuns
        self.baseProbabilityMillionths = baseProbabilityMillionths
        self.materialTypeIDs = materialTypeIDs.sorted()
    }
}

public enum T2IndustryDataError: Error, Equatable, Sendable {
    case catalog(CatalogQueryError)
    case catalogVersionChanged
    case ambiguousInventionSource(
        inventedBlueprintTypeID: Int64,
        sourceBlueprintTypeIDs: [Int64]
    )
    case unresolvedInventionReferences(
        sourceBlueprintTypeID: Int64,
        typeIDs: [Int64]
    )
    case unsupportedInventionSourceBlueprint(Int64)
    case missingInventionProbability(
        sourceBlueprintTypeID: Int64,
        inventedBlueprintTypeID: Int64
    )
    case invalidInventionProbability(Double)
    case invalidInventionBaseRuns(Int64)
}

public protocol T2IndustryDataReading: Sendable {
    func inventionMetadata(
        inventedBlueprintTypeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> T2InventionMetadata?
}

public struct NoT2IndustryData: T2IndustryDataReading, Sendable {
    public init() {}

    public func inventionMetadata(
        inventedBlueprintTypeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> T2InventionMetadata? {
        nil
    }
}

public struct RecipeBackedT2IndustryData:
    T2IndustryDataReading,
    Sendable
{
    private let source: any RecipeCandidateReading
    private let blueprintCatalog: any ItemBlueprintCatalogReading

    public init(
        source: any RecipeCandidateReading,
        blueprintCatalog: any ItemBlueprintCatalogReading
    ) {
        self.source = source
        self.blueprintCatalog = blueprintCatalog
    }

    public func inventionMetadata(
        inventedBlueprintTypeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> T2InventionMetadata? {
        try Task.checkCancellation()
        let page: RecipeCandidatePage
        do {
            page = try await source.recipeCandidates(
                productTypeID: inventedBlueprintTypeID,
                activity: .invention,
                blueprintTypeID: nil
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as CatalogQueryError {
            throw T2IndustryDataError.catalog(error)
        } catch {
            throw T2IndustryDataError.catalog(.persistenceFailure)
        }
        guard page.version == expectedVersion else {
            throw T2IndustryDataError.catalogVersionChanged
        }
        guard !page.candidates.isEmpty else {
            return nil
        }
        let candidates = page.candidates.sorted {
            $0.blueprintTypeID < $1.blueprintTypeID
        }
        guard candidates.count == 1, let candidate = candidates.first else {
            throw T2IndustryDataError.ambiguousInventionSource(
                inventedBlueprintTypeID: inventedBlueprintTypeID,
                sourceBlueprintTypeIDs:
                    candidates.map(\.blueprintTypeID)
            )
        }
        let sourceBlueprint: CatalogLookupResult<CatalogBlueprintDetails>
        do {
            sourceBlueprint = try await blueprintCatalog.blueprint(
                typeID: candidate.blueprintTypeID
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as CatalogQueryError {
            throw T2IndustryDataError.catalog(error)
        } catch {
            throw T2IndustryDataError.catalog(.persistenceFailure)
        }
        let sourceDetails: CatalogBlueprintDetails
        switch sourceBlueprint {
        case let .found(details):
            guard details.version == expectedVersion else {
                throw T2IndustryDataError.catalogVersionChanged
            }
            sourceDetails = details
        case let .notFound(version):
            guard version == expectedVersion else {
                throw T2IndustryDataError.catalogVersionChanged
            }
            throw T2IndustryDataError.catalog(
                .inconsistentStoredCatalog
            )
        }
        guard sourceDetails.summary.activities.contains(.manufacturing) else {
            throw T2IndustryDataError.unsupportedInventionSourceBlueprint(
                candidate.blueprintTypeID
            )
        }
        let unresolved = (
            candidate.materials.filter { !$0.typeIsResolved }.map(\.typeID)
            + candidate.products.filter { !$0.typeIsResolved }.map(\.typeID)
        ).sorted()
        guard unresolved.isEmpty else {
            throw T2IndustryDataError.unresolvedInventionReferences(
                sourceBlueprintTypeID: candidate.blueprintTypeID,
                typeIDs: unresolved
            )
        }
        guard let product = candidate.products.first(where: {
            $0.typeID == inventedBlueprintTypeID
        }) else {
            throw T2IndustryDataError.catalog(.inconsistentStoredCatalog)
        }
        guard product.quantity > 0 else {
            throw T2IndustryDataError.invalidInventionBaseRuns(
                product.quantity
            )
        }
        guard let probability = product.probability else {
            throw T2IndustryDataError.missingInventionProbability(
                sourceBlueprintTypeID: candidate.blueprintTypeID,
                inventedBlueprintTypeID: inventedBlueprintTypeID
            )
        }
        guard probability > 0, probability <= 1,
              probability.isFinite else {
            throw T2IndustryDataError
                .invalidInventionProbability(probability)
        }
        let probabilityMillionths = Int(
            (probability * 1_000_000).rounded()
        )
        guard probabilityMillionths > 0,
              probabilityMillionths <= 1_000_000 else {
            throw T2IndustryDataError
                .invalidInventionProbability(probability)
        }
        return T2InventionMetadata(
            version: page.version,
            sourceBlueprintTypeID: candidate.blueprintTypeID,
            inventedBlueprintTypeID: inventedBlueprintTypeID,
            baseLicensedRuns: product.quantity,
            baseProbabilityMillionths: probabilityMillionths,
            materialTypeIDs: candidate.materials.map(\.typeID)
        )
    }
}

public struct T2StagePlanningPolicy: Equatable, Sendable {
    public let decryptorByBlueprintTypeID:
        [Int64: InventionDecryptor]
    public let qualityOverrideByBlueprintTypeID:
        [Int64: BlueprintPlanningQuality]

    public init(
        decryptorByBlueprintTypeID:
            [Int64: InventionDecryptor] = [:],
        qualityOverrideByBlueprintTypeID:
            [Int64: BlueprintPlanningQuality] = [:]
    ) {
        self.decryptorByBlueprintTypeID =
            decryptorByBlueprintTypeID
        self.qualityOverrideByBlueprintTypeID =
            qualityOverrideByBlueprintTypeID
    }

    public static let regularInventionWithoutDecryptor =
        T2StagePlanningPolicy()
}
