import Foundation
import NewEdenNexusDomain

public struct ESIWalletTransaction:
    Codable,
    Equatable,
    Identifiable,
    Sendable
{
    public var id: Int64 { transactionID }

    public let transactionID: Int64
    public let journalRefID: Int64
    public let date: Date
    public let locationID: Int64
    public let typeID: Int64
    public let unitPriceHundredths: Int64
    public let quantity: Int64
    public let clientID: Int64
    public let isBuy: Bool
    public let isPersonal: Bool
    public let sourcePage: Int

    public init(
        transactionID: Int64,
        journalRefID: Int64,
        date: Date,
        locationID: Int64,
        typeID: Int64,
        unitPriceHundredths: Int64,
        quantity: Int64,
        clientID: Int64,
        isBuy: Bool,
        isPersonal: Bool,
        sourcePage: Int
    ) throws {
        guard transactionID > 0, journalRefID > 0,
              locationID > 0, typeID > 0,
              unitPriceHundredths >= 0, quantity > 0,
              clientID > 0, sourcePage > 0 else {
            throw ESIWalletError.invalidResponse
        }
        self.transactionID = transactionID
        self.journalRefID = journalRefID
        self.date = date
        self.locationID = locationID
        self.typeID = typeID
        self.unitPriceHundredths = unitPriceHundredths
        self.quantity = quantity
        self.clientID = clientID
        self.isBuy = isBuy
        self.isPersonal = isPersonal
        self.sourcePage = sourcePage
    }

    public func amountHundredths(quantity: Int64) throws -> Int64 {
        guard quantity > 0, quantity <= self.quantity else {
            throw WalletFinanceError.allocationExceeded
        }
        return try WalletMoneyNormalizer.multiplied(
            unitHundredths: unitPriceHundredths,
            quantity: quantity
        )
    }
}

public struct ESIWalletJournalEntry:
    Codable,
    Equatable,
    Identifiable,
    Sendable
{
    public let id: Int64
    public let date: Date
    public let refType: String
    public let amountHundredths: Int64?
    public let balanceHundredths: Int64?
    public let contextID: Int64?
    public let contextIDType: String?
    public let sourcePage: Int

    public init(
        id: Int64,
        date: Date,
        refType: String,
        amountHundredths: Int64?,
        balanceHundredths: Int64?,
        contextID: Int64?,
        contextIDType: String?,
        sourcePage: Int
    ) throws {
        guard id > 0, sourcePage > 0,
              Self.isSafe(refType, maximum: 128),
              contextID.map({ $0 > 0 }) ?? true,
              contextIDType.map({
                  Self.isSafe($0, maximum: 64)
              }) ?? true else {
            throw ESIWalletError.invalidResponse
        }
        self.id = id
        self.date = date
        self.refType = refType
        self.amountHundredths = amountHundredths
        self.balanceHundredths = balanceHundredths
        self.contextID = contextID
        self.contextIDType = contextIDType
        self.sourcePage = sourcePage
    }

    public var isAssignable: Bool {
        guard amountHundredths != nil else {
            return false
        }
        return contextIDType == "industry_job_id"
            || Self.assignableFeeTypes.contains(refType)
    }

    private static let assignableFeeTypes: Set<String> = [
        "brokers_fee",
        "industry_job_tax",
        "industry_security_tax",
        "manufacturing",
        "reaction",
        "copying",
        "researching_material_productivity",
        "researching_time_productivity",
        "transaction_tax"
    ]

    private static func isSafe(
        _ value: String,
        maximum: Int
    ) -> Bool {
        !value.isEmpty
            && value.utf8.count <= maximum
            && value.rangeOfCharacter(from: .newlines) == nil
    }
}

public struct ESIWalletEndpointMetadata:
    Codable,
    Equatable,
    Sendable
{
    public let checkedAt: Date
    public let expiresAt: Date?
    public let compatibilityDate: String
    public let pageCount: Int
    public let validatorsByPage: [Int: ESICacheValidators]
    public let rateLimit: ESIRateLimitSnapshot

    public init(
        checkedAt: Date,
        expiresAt: Date?,
        compatibilityDate: String,
        pageCount: Int,
        validatorsByPage: [Int: ESICacheValidators],
        rateLimit: ESIRateLimitSnapshot = .init()
    ) throws {
        guard pageCount > 0, pageCount <= 100,
              validatorsByPage.keys.allSatisfy({
                  $0 > 0 && $0 <= pageCount
              }),
              compatibilityDate.count == 10 else {
            throw ESIWalletError.invalidResponse
        }
        self.checkedAt = checkedAt
        self.expiresAt = expiresAt
        self.compatibilityDate = compatibilityDate
        self.pageCount = pageCount
        self.validatorsByPage = validatorsByPage
        self.rateLimit = rateLimit
    }

    public func isFresh(at date: Date) -> Bool {
        expiresAt.map { $0 > date } ?? false
    }
}

public struct ESIWalletSnapshot:
    Codable,
    Equatable,
    Sendable
{
    public static let payloadVersion = 1

    public let version: Int
    public let revision: UUID
    public let characterID: Int64
    public let synchronizedAt: Date
    public let balanceHundredths: Int64
    public let journal: [ESIWalletJournalEntry]
    public let transactions: [ESIWalletTransaction]
    public let balanceMetadata: ESIWalletEndpointMetadata
    public let journalMetadata: ESIWalletEndpointMetadata
    public let transactionMetadata: ESIWalletEndpointMetadata

    public init(
        version: Int = payloadVersion,
        revision: UUID,
        characterID: Int64,
        synchronizedAt: Date,
        balanceHundredths: Int64,
        journal: [ESIWalletJournalEntry],
        transactions: [ESIWalletTransaction],
        balanceMetadata: ESIWalletEndpointMetadata,
        journalMetadata: ESIWalletEndpointMetadata,
        transactionMetadata: ESIWalletEndpointMetadata
    ) throws {
        guard version == Self.payloadVersion,
              characterID > 0,
              Set(journal.map(\.id)).count == journal.count,
              Set(transactions.map(\.transactionID)).count
                == transactions.count else {
            throw ESIWalletError.invalidResponse
        }
        self.version = version
        self.revision = revision
        self.characterID = characterID
        self.synchronizedAt = synchronizedAt
        self.balanceHundredths = balanceHundredths
        self.journal = journal.sorted { $0.id > $1.id }
        self.transactions = transactions.sorted {
            $0.transactionID > $1.transactionID
        }
        self.balanceMetadata = balanceMetadata
        self.journalMetadata = journalMetadata
        self.transactionMetadata = transactionMetadata
    }

    public func isVerifiablyAssignable(
        _ entry: ESIWalletJournalEntry
    ) -> Bool {
        guard entry.isAssignable else {
            return false
        }
        if entry.contextIDType == "industry_job_id" {
            return true
        }
        return transactions.contains {
            $0.journalRefID == entry.id
                || (
                    entry.contextIDType == "market_transaction_id"
                        && entry.contextID == $0.transactionID
                )
        }
    }
}

public enum ESIWalletPaginationIssue: String, Equatable, Sendable {
    case pageCountChanged = "page_count_changed"
    case lastModifiedMissing = "last_modified_missing"
    case lastModifiedChanged = "last_modified_changed"
    case duplicateJournalEntry = "duplicate_journal_entry"
    case conflictingTransaction = "conflicting_transaction"
    case transactionCursorStalled = "transaction_cursor_stalled"
}

public enum ESIWalletError: Error, Equatable, Sendable {
    case invalidConfiguration
    case invalidCharacterID
    case authorizationRequired
    case permissionDenied
    case invalidResponse
    case responseTooLarge
    case pageLimitExceeded
    case recordLimitExceeded
    case inconsistentPagination(ESIWalletPaginationIssue)
    case offline
    case transport
    case rateLimited(until: Date)
    case errorLimited(until: Date)
    case serverUnavailable
    case cacheCorrupted
    case cacheWriteFailed
    case stalePreview
    case previewNotFound
}

public protocol ESIWalletRemoteFetching: Sendable {
    func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> ESIWalletSnapshot
}

public protocol ESIWalletPersisting: Sendable {
    func snapshot(characterID: Int64) async throws -> ESIWalletSnapshot?
    func save(
        _ snapshot: ESIWalletSnapshot,
        expectedRevision: UUID?
    ) async throws
    func delete(characterID: Int64) async throws
}

public struct ESIWalletPreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let characterID: Int64
    public let generatedAt: Date
    public let baseRevision: UUID?
    public let balanceBeforeHundredths: Int64?
    public let balanceAfterHundredths: Int64
    public let addedJournalCount: Int
    public let removedJournalCount: Int
    public let addedTransactionCount: Int
    public let removedTransactionCount: Int
}

public protocol ESIWalletSynchronizing: Sendable {
    func current(characterID: Int64) async throws -> ESIWalletSnapshot?
    func inspect(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> ESIWalletPreview
    func apply(previewID: UUID) async throws -> ESIWalletSnapshot
    func discard(previewID: UUID) async
}

public actor ESIWalletSynchronizationService: ESIWalletSynchronizing {
    private struct Pending {
        let preview: ESIWalletPreview
        let proposed: ESIWalletSnapshot
    }

    private let tokenProvider: any EVEAccessTokenProviding
    private let remote: any ESIWalletRemoteFetching
    private let repository: any ESIWalletPersisting
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var pending: [UUID: Pending] = [:]

    public init(
        tokenProvider: any EVEAccessTokenProviding,
        remote: any ESIWalletRemoteFetching,
        repository: any ESIWalletPersisting,
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.tokenProvider = tokenProvider
        self.remote = remote
        self.repository = repository
        self.now = now
        self.makeID = makeID
    }

    public func current(
        characterID: Int64
    ) async throws -> ESIWalletSnapshot? {
        guard characterID > 0 else {
            throw ESIWalletError.invalidCharacterID
        }
        return try await repository.snapshot(characterID: characterID)
    }

    public func inspect(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> ESIWalletPreview {
        guard characterID > 0 else {
            throw ESIWalletError.invalidCharacterID
        }
        try Task.checkCancellation()
        let existing = try await repository.snapshot(
            characterID: characterID
        )
        let token = try await tokenProvider.accessToken(
            characterID: characterID,
            configuration: configuration
        )
        let proposed = try await remote.fetch(
            characterID: characterID,
            accessToken: token.value,
            existing: existing
        )
        guard proposed.characterID == characterID else {
            throw ESIWalletError.invalidResponse
        }
        let preview = ESIWalletPreview(
            id: makeID(),
            characterID: characterID,
            generatedAt: now(),
            baseRevision: existing?.revision,
            balanceBeforeHundredths: existing?.balanceHundredths,
            balanceAfterHundredths: proposed.balanceHundredths,
            addedJournalCount: Self.added(
                old: existing?.journal.map(\.id) ?? [],
                new: proposed.journal.map(\.id)
            ),
            removedJournalCount: Self.added(
                old: proposed.journal.map(\.id),
                new: existing?.journal.map(\.id) ?? []
            ),
            addedTransactionCount: Self.added(
                old: existing?.transactions.map(\.transactionID) ?? [],
                new: proposed.transactions.map(\.transactionID)
            ),
            removedTransactionCount: Self.added(
                old: proposed.transactions.map(\.transactionID),
                new: existing?.transactions.map(\.transactionID) ?? []
            )
        )
        pending.removeAll()
        pending[preview.id] = Pending(
            preview: preview,
            proposed: proposed
        )
        return preview
    }

    public func apply(previewID: UUID) async throws -> ESIWalletSnapshot {
        guard let pending = pending[previewID] else {
            throw ESIWalletError.previewNotFound
        }
        try Task.checkCancellation()
        try await repository.save(
            pending.proposed,
            expectedRevision: pending.preview.baseRevision
        )
        self.pending[previewID] = nil
        return pending.proposed
    }

    public func discard(previewID: UUID) async {
        pending[previewID] = nil
    }

    private static func added(old: [Int64], new: [Int64]) -> Int {
        Set(new).subtracting(old).count
    }
}

public protocol WalletProjectAssignmentRepository: Sendable {
    func assignments(
        projectID: UUID?
    ) async throws -> [WalletProjectAssignmentSnapshot]
    func assignments(
        characterID: Int64
    ) async throws -> [WalletProjectAssignmentSnapshot]
    func save(
        _ assignment: WalletProjectAssignmentSnapshot,
        expectedUpdatedAt: Date?,
        sourceMaximumQuantity: Int64,
        sourceMaximumAmountHundredths: Int64
    ) async throws
    func delete(characterID: Int64) async throws
    func restore(
        _ assignments: [WalletProjectAssignmentSnapshot]
    ) async throws
}

public struct WalletAssignmentPreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let assignment: WalletProjectAssignmentSnapshot
    public let sourceMaximumQuantity: Int64
    public let sourceMaximumAmountHundredths: Int64
    public let alreadyAssignedQuantity: Int64
    public let alreadyAssignedAmountHundredths: Int64
    public let existingAssignments: [WalletProjectAssignmentSnapshot]
}

public enum WalletAssignmentSourceCapacity: Equatable, Sendable {
    case available(
        remainingQuantity: Int64,
        remainingAmountHundredths: Int64
    )
    case exhausted
    case inconsistent
}

public enum WalletAssignmentSourceCapacityCalculator {
    public static func transaction(
        _ transaction: ESIWalletTransaction,
        characterID: Int64,
        assignments: [WalletProjectAssignmentSnapshot]
    ) -> WalletAssignmentSourceCapacity {
        guard transaction.unitPriceHundredths > 0 else {
            return .inconsistent
        }
        let matching = assignments.filter {
            $0.characterID == characterID
                && $0.sourceKind == .transaction
                && $0.sourceID == transaction.transactionID
        }
        guard
            let assignedQuantity = sum(
                matching.map(\.assignedQuantity)
            ),
            let assignedAmount = sum(
                matching.map(\.assignedAmountHundredths)
            )
        else {
            return .inconsistent
        }
        let maximumAmount: Int64
        do {
            maximumAmount = try transaction.amountHundredths(
                quantity: transaction.quantity
            )
        } catch {
            return .inconsistent
        }
        guard assignedQuantity <= transaction.quantity,
              assignedAmount <= maximumAmount else {
            return .inconsistent
        }
        let remainingQuantity = transaction.quantity - assignedQuantity
        let remainingAmount = maximumAmount - assignedAmount
        let quantityCoveredByAmount =
            remainingAmount / transaction.unitPriceHundredths
        let safeQuantity = min(
            remainingQuantity,
            quantityCoveredByAmount
        )
        guard safeQuantity > 0 else {
            return .exhausted
        }
        return .available(
            remainingQuantity: safeQuantity,
            remainingAmountHundredths: remainingAmount
        )
    }

    public static func journal(
        _ entry: ESIWalletJournalEntry,
        characterID: Int64,
        assignments: [WalletProjectAssignmentSnapshot]
    ) -> WalletAssignmentSourceCapacity {
        guard let amount = entry.amountHundredths,
              amount != 0, amount != Int64.min else {
            return .inconsistent
        }
        let matching = assignments.filter {
            $0.characterID == characterID
                && $0.sourceKind == .journal
                && $0.sourceID == entry.id
        }
        guard let assignedAmount = sum(
            matching.map(\.assignedAmountHundredths)
        ) else {
            return .inconsistent
        }
        let maximumAmount = abs(amount)
        guard assignedAmount <= maximumAmount else {
            return .inconsistent
        }
        let remainingAmount = maximumAmount - assignedAmount
        guard remainingAmount > 0 else {
            return .exhausted
        }
        return .available(
            remainingQuantity: 0,
            remainingAmountHundredths: remainingAmount
        )
    }

    private static func sum(_ values: [Int64]) -> Int64? {
        var total: Int64 = 0
        for value in values {
            guard value >= 0 else {
                return nil
            }
            let result = total.addingReportingOverflow(value)
            guard !result.overflow else {
                return nil
            }
            total = result.partialValue
        }
        return total
    }
}

public protocol WalletProjectAssignmentManaging: Sendable {
    func assignments(
        projectID: UUID?
    ) async throws -> [WalletProjectAssignmentSnapshot]
    func previewTransaction(
        projectID: UUID,
        characterID: Int64,
        transactionID: Int64,
        quantity: Int64
    ) async throws -> WalletAssignmentPreview
    func previewJournal(
        projectID: UUID,
        characterID: Int64,
        journalID: Int64,
        amountHundredths: Int64
    ) async throws -> WalletAssignmentPreview
    func apply(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> WalletProjectAssignmentSnapshot
    func discard(previewID: UUID) async
    func actuals(projectID: UUID) async throws -> WalletProjectActuals
}

public enum WalletAssignmentServiceError:
    Error,
    Equatable,
    Sendable
{
    case sourceNotFound
    case sourceNotAssignable
    case confirmationRequired
    case stalePreview
    case previewNotFound
    case persistenceFailure
}

public actor WalletProjectAssignmentService:
    WalletProjectAssignmentManaging
{
    private struct Pending {
        let preview: WalletAssignmentPreview
        let sourceRevision: UUID
    }

    private let wallets: any ESIWalletPersisting
    private let repository: any WalletProjectAssignmentRepository
    private let calculator: WalletProjectActualsCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var pending: [UUID: Pending] = [:]

    public init(
        wallets: any ESIWalletPersisting,
        repository: any WalletProjectAssignmentRepository,
        calculator: WalletProjectActualsCalculator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.wallets = wallets
        self.repository = repository
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func assignments(
        projectID: UUID?
    ) async throws -> [WalletProjectAssignmentSnapshot] {
        try await repository.assignments(projectID: projectID)
    }

    public func previewTransaction(
        projectID: UUID,
        characterID: Int64,
        transactionID: Int64,
        quantity: Int64
    ) async throws -> WalletAssignmentPreview {
        guard let snapshot = try await wallets.snapshot(
            characterID: characterID
        ), let transaction = snapshot.transactions.first(where: {
            $0.transactionID == transactionID
        }) else {
            throw WalletAssignmentServiceError.sourceNotFound
        }
        let amount = try transaction.amountHundredths(quantity: quantity)
        return try await makePreview(
            projectID: projectID,
            characterID: characterID,
            sourceKind: .transaction,
            sourceID: transactionID,
            direction: transaction.isBuy ? .cost : .revenue,
            quantity: quantity,
            amountHundredths: amount,
            maximumQuantity: transaction.quantity,
            maximumAmountHundredths: try transaction.amountHundredths(
                quantity: transaction.quantity
            ),
            sourceRevision: snapshot.revision
        )
    }

    public func previewJournal(
        projectID: UUID,
        characterID: Int64,
        journalID: Int64,
        amountHundredths: Int64
    ) async throws -> WalletAssignmentPreview {
        guard let snapshot = try await wallets.snapshot(
            characterID: characterID
        ), let entry = snapshot.journal.first(where: {
            $0.id == journalID
        }) else {
            throw WalletAssignmentServiceError.sourceNotFound
        }
        guard snapshot.isVerifiablyAssignable(entry),
              let sourceAmount = entry.amountHundredths,
              sourceAmount != Int64.min else {
            throw WalletAssignmentServiceError.sourceNotAssignable
        }
        let maximum = abs(sourceAmount)
        guard amountHundredths > 0, amountHundredths <= maximum else {
            throw WalletFinanceError.allocationExceeded
        }
        return try await makePreview(
            projectID: projectID,
            characterID: characterID,
            sourceKind: .journal,
            sourceID: journalID,
            direction: sourceAmount < 0 ? .cost : .revenue,
            quantity: 0,
            amountHundredths: amountHundredths,
            maximumQuantity: 0,
            maximumAmountHundredths: maximum,
            sourceRevision: snapshot.revision
        )
    }

    public func apply(
        previewID: UUID,
        confirmed: Bool
    ) async throws -> WalletProjectAssignmentSnapshot {
        guard confirmed else {
            throw WalletAssignmentServiceError.confirmationRequired
        }
        guard let pending = pending[previewID] else {
            throw WalletAssignmentServiceError.previewNotFound
        }
        guard let current = try await wallets.snapshot(
            characterID: pending.preview.assignment.characterID
        ), current.revision == pending.sourceRevision else {
            throw WalletAssignmentServiceError.stalePreview
        }
        let currentAssignments = try await repository.assignments(
            projectID: nil
        ).filter {
            $0.characterID == pending.preview.assignment.characterID
                && $0.sourceKind
                    == pending.preview.assignment.sourceKind
                && $0.sourceID == pending.preview.assignment.sourceID
        }
        guard currentAssignments == pending.preview.existingAssignments else {
            throw WalletAssignmentServiceError.stalePreview
        }
        do {
            try await repository.save(
                pending.preview.assignment,
                expectedUpdatedAt: nil,
                sourceMaximumQuantity:
                    pending.preview.sourceMaximumQuantity,
                sourceMaximumAmountHundredths:
                    pending.preview.sourceMaximumAmountHundredths
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw WalletAssignmentServiceError.persistenceFailure
        }
        self.pending[previewID] = nil
        return pending.preview.assignment
    }

    public func discard(previewID: UUID) async {
        pending[previewID] = nil
    }

    public func actuals(
        projectID: UUID
    ) async throws -> WalletProjectActuals {
        try calculator.calculate(
            projectID: projectID,
            assignments: try await repository.assignments(
                projectID: projectID
            )
        )
    }

    private func makePreview(
        projectID: UUID,
        characterID: Int64,
        sourceKind: WalletAssignmentSourceKind,
        sourceID: Int64,
        direction: WalletAssignmentDirection,
        quantity: Int64,
        amountHundredths: Int64,
        maximumQuantity: Int64,
        maximumAmountHundredths: Int64,
        sourceRevision: UUID
    ) async throws -> WalletAssignmentPreview {
        let all = try await repository.assignments(projectID: nil)
        let existing = all.filter {
            $0.characterID == characterID
                && $0.sourceKind == sourceKind
                && $0.sourceID == sourceID
        }
        let quantities = try Self.sum(existing.map(\.assignedQuantity))
        let amounts = try Self.sum(
            existing.map(\.assignedAmountHundredths)
        )
        let nextQuantity = quantities.addingReportingOverflow(quantity)
        let nextAmount = amounts.addingReportingOverflow(amountHundredths)
        guard !nextQuantity.overflow, !nextAmount.overflow,
              nextQuantity.partialValue <= maximumQuantity,
              nextAmount.partialValue <= maximumAmountHundredths else {
            throw WalletFinanceError.allocationExceeded
        }
        let timestamp = now()
        let assignment = try WalletProjectAssignmentSnapshot(
            id: makeID(),
            projectID: projectID,
            characterID: characterID,
            sourceKind: sourceKind,
            sourceID: sourceID,
            direction: direction,
            assignedQuantity: quantity,
            assignedAmountHundredths: amountHundredths,
            sourceRevision: sourceRevision,
            createdAt: timestamp,
            updatedAt: timestamp
        )
        let preview = WalletAssignmentPreview(
            id: makeID(),
            assignment: assignment,
            sourceMaximumQuantity: maximumQuantity,
            sourceMaximumAmountHundredths: maximumAmountHundredths,
            alreadyAssignedQuantity: quantities,
            alreadyAssignedAmountHundredths: amounts,
            existingAssignments: existing
        )
        pending.removeAll()
        pending[preview.id] = Pending(
            preview: preview,
            sourceRevision: sourceRevision
        )
        return preview
    }

    private static func sum(_ values: [Int64]) throws -> Int64 {
        var total: Int64 = 0
        for value in values {
            let result = total.addingReportingOverflow(value)
            guard !result.overflow else {
                throw WalletFinanceError.moneyOverflow
            }
            total = result.partialValue
        }
        return total
    }
}
