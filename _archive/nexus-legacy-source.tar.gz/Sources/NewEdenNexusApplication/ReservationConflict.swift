import Foundation
import NewEdenNexusDomain

public enum ReservationConflictResolution:
    Equatable,
    Sendable
{
    case reduce(reservationID: UUID, remainingQuantity: Int64)
    case release(reservationID: UUID)

    public var reservationID: UUID {
        switch self {
        case .reduce(let reservationID, _),
             .release(let reservationID):
            reservationID
        }
    }
}

public struct ReservationConflictProjectVersion:
    Equatable,
    Sendable
{
    public let id: UUID
    public let updatedAt: Date

    public init(id: UUID, updatedAt: Date) {
        self.id = id
        self.updatedAt = updatedAt
    }
}

public struct ReservationConflictSourceVersion:
    Equatable,
    Sendable
{
    public let safetyStock: SafetyStockSourceVersion
    public let reservations: [StockReservationVersion]
    public let projects: [ReservationConflictProjectVersion]

    public init(
        safetyStock: SafetyStockSourceVersion,
        reservations: [StockReservationVersion],
        projects: [ReservationConflictProjectVersion]
    ) {
        self.safetyStock = safetyStock
        self.reservations = reservations.sorted {
            $0.id.uuidString < $1.id.uuidString
        }
        self.projects = projects.sorted {
            $0.id.uuidString < $1.id.uuidString
        }
    }
}

public struct ReservationConflictPreview:
    Equatable,
    Sendable
{
    public let projectID: UUID
    public let graphID: UUID
    public let evaluatedAt: Date
    public let relevantTypeIDs: [Int64]
    public let sourceVersion: ReservationConflictSourceVersion
    public let safetyStockPreview: SafetyStockPreview
    public let projects: [ReservationConflictProjectSnapshot]
    public let materialNames: [Int64: String]
    public let storedReservations: [StockReservationSnapshot]
    public let proposedReservations: [StockReservationSnapshot]
    public let changedReservations: [StockReservationSnapshot]
    public let resolutions: [ReservationConflictResolution]
    public let analysisBefore: ReservationConflictAnalysis
    public let analysisAfter: ReservationConflictAnalysis
}

public enum ReservationConflictServiceError:
    Error,
    Equatable,
    Sendable
{
    case projectNotFound(UUID)
    case archivedProject(UUID)
    case duplicateResolution(UUID)
    case unknownReservation(UUID)
    case reservationNotConflicting(UUID)
    case activeReservationRequired(UUID)
    case invalidReduction(UUID)
    case confirmationRequired
    case resolutionRequired
    case unresolvedConflicts
    case stalePreview
    case persistenceFailure
}

public protocol ReservationConflictManaging: Sendable {
    func preview(
        projectID: UUID,
        resolutions: [ReservationConflictResolution]?
    ) async throws -> ReservationConflictPreview

    func apply(
        _ preview: ReservationConflictPreview,
        confirmed: Bool
    ) async throws -> ReservationConflictPreview
}

public struct ReservationConflictService:
    ReservationConflictManaging,
    Sendable
{
    private let safetyStock: any SafetyStockManaging
    private let reservations: any ProjectReservationRepository
    private let projects: any ProductionProjectRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let calculator: ReservationConflictCalculator
    private let now: @Sendable () -> Date

    public init(
        safetyStock: any SafetyStockManaging,
        reservations: any ProjectReservationRepository,
        projects: any ProductionProjectRepository,
        catalog: any ItemBlueprintCatalogReading,
        calculator: ReservationConflictCalculator = .init(),
        now: @escaping @Sendable () -> Date = { Date() }
    ) {
        self.safetyStock = safetyStock
        self.reservations = reservations
        self.projects = projects
        self.catalog = catalog
        self.calculator = calculator
        self.now = now
    }

    public func preview(
        projectID: UUID,
        resolutions: [ReservationConflictResolution]? = nil
    ) async throws -> ReservationConflictPreview {
        let state = try await loadState(projectID: projectID)
        let timestamp = now()
        let before = try analyze(state: state, at: timestamp)
        let selected = resolutions ?? []
        let proposal = try makeProposal(
            stored: state.reservations,
            conflicts: before,
            resolutions: selected,
            timestamp: timestamp
        )
        let after = try calculator.analyze(
            currentProjectID: projectID,
            safetyStock: state.safety.calculation,
            reservations: proposal.all,
            projects: state.projects,
            materialNames: state.materialNames,
            at: timestamp
        )
        return makePreview(
            state: state,
            evaluatedAt: timestamp,
            proposed: proposal.all,
            changed: proposal.changed,
            resolutions: selected,
            before: before,
            after: after
        )
    }

    public func apply(
        _ preview: ReservationConflictPreview,
        confirmed: Bool
    ) async throws -> ReservationConflictPreview {
        guard confirmed else {
            throw ReservationConflictServiceError.confirmationRequired
        }
        guard !preview.resolutions.isEmpty else {
            throw ReservationConflictServiceError.resolutionRequired
        }
        guard !preview.analysisAfter.hasConflicts else {
            throw ReservationConflictServiceError.unresolvedConflicts
        }
        try Task.checkCancellation()
        let current = try await loadState(projectID: preview.projectID)
        guard sourceVersion(current) == preview.sourceVersion,
              current.safety.graphID == preview.graphID else {
            throw ReservationConflictServiceError.stalePreview
        }
        let currentBefore = try analyze(
            state: current,
            at: preview.evaluatedAt
        )
        let proposal = try makeProposal(
            stored: current.reservations,
            conflicts: currentBefore,
            resolutions: preview.resolutions,
            timestamp: preview.evaluatedAt
        )
        guard proposal.changed == preview.changedReservations,
              proposal.all == preview.proposedReservations else {
            throw ReservationConflictServiceError.stalePreview
        }
        let currentAfter = try calculator.analyze(
            currentProjectID: preview.projectID,
            safetyStock: current.safety.calculation,
            reservations: proposal.all,
            projects: current.projects,
            materialNames: current.materialNames,
            at: preview.evaluatedAt
        )
        guard !currentAfter.hasConflicts else {
            throw ReservationConflictServiceError.unresolvedConflicts
        }
        try Task.checkCancellation()
        do {
            try await reservations.applyReservations(
                proposal.changed,
                relevantTypeIDs: current.relevantTypeIDs,
                expectedVersions:
                    preview.sourceVersion.reservations
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch ProjectReservationRepositoryError.staleState {
            throw ReservationConflictServiceError.stalePreview
        } catch {
            throw ReservationConflictServiceError.persistenceFailure
        }

        let updatedState = LoadedState(
            projectID: current.projectID,
            safety: current.safety,
            relevantTypeIDs: current.relevantTypeIDs,
            reservations: proposal.all,
            projects: current.projects,
            materialNames: current.materialNames
        )
        return makePreview(
            state: updatedState,
            evaluatedAt: now(),
            proposed: proposal.all,
            changed: [],
            resolutions: [],
            before: currentAfter,
            after: currentAfter
        )
    }

    private struct LoadedState {
        let projectID: UUID
        let safety: SafetyStockPreview
        let relevantTypeIDs: [Int64]
        let reservations: [StockReservationSnapshot]
        let projects: [ReservationConflictProjectSnapshot]
        let materialNames: [Int64: String]
    }

    private struct Proposal {
        let all: [StockReservationSnapshot]
        let changed: [StockReservationSnapshot]
    }

    private func loadState(
        projectID: UUID
    ) async throws -> LoadedState {
        try Task.checkCancellation()
        guard let currentProject = try await projects.project(id: projectID)
        else {
            throw ReservationConflictServiceError
                .projectNotFound(projectID)
        }
        guard currentProject.status != .archived else {
            throw ReservationConflictServiceError
                .archivedProject(projectID)
        }
        let safety = try await safetyStock.preview(
            projectID: projectID,
            drafts: nil
        )
        let projectReservations = try await reservations.reservations(
            projectID: projectID
        )
        let activeProjectTypeIDs = projectReservations
            .filter { $0.status.isBinding }
            .map(\.typeID)
        let relevantTypeIDs = Array(
            Set(
                safety.calculation.lines.map {
                    $0.availability.typeID
                } + activeProjectTypeIDs
            )
        ).sorted()
        let storedReservations = try await reservations.reservations(
            typeIDs: relevantTypeIDs
        ).sorted(by: reservationOrder)
        let relevantProjectIDs = Set(
            storedReservations.map(\.projectID) + [projectID]
        )
        let storedProjects = try await projects.projects()
            .filter { relevantProjectIDs.contains($0.id) }
        let conflictProjects = try storedProjects.map {
            try ReservationConflictProjectSnapshot(
                id: $0.id,
                name: $0.name,
                priority: $0.priority,
                updatedAt: $0.updatedAt
            )
        }.sorted {
            $0.id.uuidString < $1.id.uuidString
        }
        var materialNames = Dictionary(
            uniqueKeysWithValues: safety.calculation.lines.map {
                (
                    $0.availability.typeID,
                    $0.availability.name
                )
            }
        )
        for typeID in relevantTypeIDs
        where materialNames[typeID] == nil {
            switch try await catalog.item(typeID: typeID) {
            case .found(let item):
                materialNames[typeID] = item.summary.name
            case .notFound:
                materialNames[typeID] = "Type-ID \(typeID)"
            }
        }
        try Task.checkCancellation()
        return LoadedState(
            projectID: projectID,
            safety: safety,
            relevantTypeIDs: relevantTypeIDs,
            reservations: storedReservations,
            projects: conflictProjects,
            materialNames: materialNames
        )
    }

    private func analyze(
        state: LoadedState,
        at date: Date
    ) throws -> ReservationConflictAnalysis {
        try calculator.analyze(
            currentProjectID: state.projectID,
            safetyStock: state.safety.calculation,
            reservations: state.reservations,
            projects: state.projects,
            materialNames: state.materialNames,
            at: date
        )
    }

    private func makeProposal(
        stored: [StockReservationSnapshot],
        conflicts: ReservationConflictAnalysis,
        resolutions: [ReservationConflictResolution],
        timestamp: Date
    ) throws -> Proposal {
        let allowedIDs = Set(
            conflicts.conflicts.flatMap {
                $0.participants.map(\.id)
            }
        )
        let storedByID = Dictionary(
            uniqueKeysWithValues: stored.map { ($0.id, $0) }
        )
        var byID: [UUID: ReservationConflictResolution] = [:]
        for resolution in resolutions {
            guard byID[resolution.reservationID] == nil else {
                throw ReservationConflictServiceError
                    .duplicateResolution(resolution.reservationID)
            }
            guard allowedIDs.contains(resolution.reservationID) else {
                if storedByID[resolution.reservationID] == nil {
                    throw ReservationConflictServiceError
                        .unknownReservation(resolution.reservationID)
                }
                throw ReservationConflictServiceError
                    .reservationNotConflicting(
                        resolution.reservationID
                    )
            }
            byID[resolution.reservationID] = resolution
        }

        var changed: [StockReservationSnapshot] = []
        for resolution in byID.values {
            guard let existing = storedByID[resolution.reservationID]
            else {
                throw ReservationConflictServiceError
                    .unknownReservation(resolution.reservationID)
            }
            guard existing.status.isBinding else {
                throw ReservationConflictServiceError
                    .activeReservationRequired(existing.id)
            }
            changed.append(
                try changedReservation(
                    existing,
                    resolution: resolution,
                    timestamp: timestamp
                )
            )
        }
        let changedIDs = Set(changed.map(\.id))
        var proposed = stored.filter {
            !changedIDs.contains($0.id)
        }
        proposed.append(contentsOf: changed)
        return Proposal(
            all: proposed.sorted(by: reservationOrder),
            changed: changed.sorted(by: reservationOrder)
        )
    }

    private func changedReservation(
        _ existing: StockReservationSnapshot,
        resolution: ReservationConflictResolution,
        timestamp: Date
    ) throws -> StockReservationSnapshot {
        switch resolution {
        case .reduce(_, let remainingQuantity):
            guard remainingQuantity > 0,
                  remainingQuantity
                    < existing.remainingQuantity else {
                throw ReservationConflictServiceError
                    .invalidReduction(existing.id)
            }
            let total = existing.consumedQuantity
                .addingReportingOverflow(remainingQuantity)
            guard !total.overflow else {
                throw ReservationConflictServiceError
                    .invalidReduction(existing.id)
            }
            return try StockReservationSnapshot(
                id: existing.id,
                projectID: existing.projectID,
                typeID: existing.typeID,
                reservedQuantity: total.partialValue,
                consumedQuantity: existing.consumedQuantity,
                priority: existing.priority,
                expiresAt: existing.expiresAt,
                status: existing.consumedQuantity == 0
                    ? .reserved
                    : .partiallyConsumed,
                createdAt: existing.createdAt,
                updatedAt: timestamp,
                releasedAt: nil,
                consumedAt: nil
            )
        case .release:
            return try StockReservationSnapshot(
                id: existing.id,
                projectID: existing.projectID,
                typeID: existing.typeID,
                reservedQuantity: existing.reservedQuantity,
                consumedQuantity: existing.consumedQuantity,
                priority: existing.priority,
                expiresAt: existing.expiresAt,
                status: .released,
                createdAt: existing.createdAt,
                updatedAt: timestamp,
                releasedAt: timestamp,
                consumedAt: nil
            )
        }
    }

    private func sourceVersion(
        _ state: LoadedState
    ) -> ReservationConflictSourceVersion {
        ReservationConflictSourceVersion(
            safetyStock: state.safety.sourceVersion,
            reservations: state.reservations.map {
                StockReservationVersion(
                    id: $0.id,
                    updatedAt: $0.updatedAt
                )
            },
            projects: state.projects.map {
                ReservationConflictProjectVersion(
                    id: $0.id,
                    updatedAt: $0.updatedAt
                )
            }
        )
    }

    private func makePreview(
        state: LoadedState,
        evaluatedAt: Date,
        proposed: [StockReservationSnapshot],
        changed: [StockReservationSnapshot],
        resolutions: [ReservationConflictResolution],
        before: ReservationConflictAnalysis,
        after: ReservationConflictAnalysis
    ) -> ReservationConflictPreview {
        ReservationConflictPreview(
            projectID: state.projectID,
            graphID: state.safety.graphID,
            evaluatedAt: evaluatedAt,
            relevantTypeIDs: state.relevantTypeIDs,
            sourceVersion: sourceVersion(state),
            safetyStockPreview: state.safety,
            projects: state.projects,
            materialNames: state.materialNames,
            storedReservations: state.reservations,
            proposedReservations: proposed,
            changedReservations: changed,
            resolutions: resolutions.sorted {
                $0.reservationID.uuidString
                    < $1.reservationID.uuidString
            },
            analysisBefore: before,
            analysisAfter: after
        )
    }

    private func reservationOrder(
        _ left: StockReservationSnapshot,
        _ right: StockReservationSnapshot
    ) -> Bool {
        if left.typeID != right.typeID {
            return left.typeID < right.typeID
        }
        if left.projectID != right.projectID {
            return left.projectID.uuidString
                < right.projectID.uuidString
        }
        return left.id.uuidString < right.id.uuidString
    }
}
