import Foundation
import NewEdenNexusDomain

public protocol ProjectEconomicsRepository: Sendable {
    func configuration(
        projectID: UUID
    ) async throws -> ProjectEconomicsConfigurationSnapshot?
    func save(
        configuration: ProjectEconomicsConfigurationSnapshot,
        expectedUpdatedAt: Date?
    ) async throws
}

public struct ProjectEconomicsDraft: Equatable, Sendable {
    public let projectID: UUID
    public let graphID: UUID
    public let targetTypeID: Int64
    public let targetName: String
    public let targetQuantity: Int64
    public let priceProfileID: UUID?
    public let manualJobCost: NonNegativeISKAmount
    public let plan: BuildOrBuyPlan

    public init(
        projectID: UUID,
        graphID: UUID,
        targetTypeID: Int64,
        targetName: String,
        targetQuantity: Int64,
        priceProfileID: UUID?,
        manualJobCost: NonNegativeISKAmount,
        plan: BuildOrBuyPlan
    ) {
        self.projectID = projectID
        self.graphID = graphID
        self.targetTypeID = targetTypeID
        self.targetName = targetName
        self.targetQuantity = targetQuantity
        self.priceProfileID = priceProfileID
        self.manualJobCost = manualJobCost
        self.plan = plan
    }
}

public struct ProjectEconomicsMissingPrice: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let isTargetProduct: Bool
}

public struct ProjectEconomicsPriceVersion: Equatable, Sendable {
    public let typeID: Int64
    public let amount: ISKAmount
}

public struct ProjectEconomicsPricingVersion: Equatable, Sendable {
    public let profileID: UUID
    public let profileUpdatedAt: Date
    public let prices: [ProjectEconomicsPriceVersion]
}

public struct ProjectEconomicsPreview: Equatable, Sendable {
    public let draft: ProjectEconomicsDraft
    public let profiles: [PriceProfileSnapshot]
    public let storedConfiguration:
        ProjectEconomicsConfigurationSnapshot?
    public let selectedProfile: PriceProfileSnapshot?
    public let pricingVersion: ProjectEconomicsPricingVersion?
    public let missingPrices: [ProjectEconomicsMissingPrice]
    public let calculation: ProjectEconomicsCalculation?

    public var isComplete: Bool {
        calculation != nil && missingPrices.isEmpty
    }
}

public enum ProjectEconomicsServiceError: Error, Equatable, Sendable {
    case confirmationRequired
    case profileRequired
    case profileNotFound(UUID)
    case staleConfiguration
    case stalePricing
    case persistenceFailure
}

public protocol ProjectEconomicsManaging: Sendable {
    func load(
        projectID: UUID,
        graphID: UUID,
        targetTypeID: Int64,
        targetName: String,
        targetQuantity: Int64,
        plan: BuildOrBuyPlan,
        at date: Date
    ) async throws -> ProjectEconomicsPreview
    func preview(
        draft: ProjectEconomicsDraft,
        storedConfiguration:
            ProjectEconomicsConfigurationSnapshot?,
        at date: Date
    ) async throws -> ProjectEconomicsPreview
    func apply(
        _ preview: ProjectEconomicsPreview,
        confirmed: Bool,
        at date: Date
    ) async throws -> ProjectEconomicsPreview
}

public struct ProjectEconomicsService:
    ProjectEconomicsManaging,
    Sendable
{
    private let repository: any ProjectEconomicsRepository
    private let prices: any PriceProfileManaging
    private let calculator: ProjectEconomicsCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any ProjectEconomicsRepository,
        prices: any PriceProfileManaging,
        calculator: ProjectEconomicsCalculator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.repository = repository
        self.prices = prices
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func load(
        projectID: UUID,
        graphID: UUID,
        targetTypeID: Int64,
        targetName: String,
        targetQuantity: Int64,
        plan: BuildOrBuyPlan,
        at date: Date
    ) async throws -> ProjectEconomicsPreview {
        try Task.checkCancellation()
        let stored = try await loadConfiguration(projectID: projectID)
        let profiles = try await prices.profiles()
        let selectedID = stored?.priceProfileID
            ?? profiles.first(where: \.isActive)?.id
            ?? profiles.first?.id
        let draft = ProjectEconomicsDraft(
            projectID: projectID,
            graphID: graphID,
            targetTypeID: targetTypeID,
            targetName: targetName,
            targetQuantity: targetQuantity,
            priceProfileID: selectedID,
            manualJobCost: stored?.manualJobCost ?? .zero,
            plan: plan
        )
        return try await evaluate(
            draft: draft,
            storedConfiguration: stored,
            profiles: profiles,
            at: date
        )
    }

    public func preview(
        draft: ProjectEconomicsDraft,
        storedConfiguration:
            ProjectEconomicsConfigurationSnapshot?,
        at date: Date
    ) async throws -> ProjectEconomicsPreview {
        try Task.checkCancellation()
        let profiles = try await prices.profiles()
        return try await evaluate(
            draft: draft,
            storedConfiguration: storedConfiguration,
            profiles: profiles,
            at: date
        )
    }

    public func apply(
        _ preview: ProjectEconomicsPreview,
        confirmed: Bool,
        at date: Date
    ) async throws -> ProjectEconomicsPreview {
        guard confirmed else {
            throw ProjectEconomicsServiceError.confirmationRequired
        }
        guard let profileID = preview.draft.priceProfileID else {
            throw ProjectEconomicsServiceError.profileRequired
        }
        try Task.checkCancellation()
        let fresh = try await self.preview(
            draft: preview.draft,
            storedConfiguration: preview.storedConfiguration,
            at: date
        )
        guard fresh.pricingVersion == preview.pricingVersion,
              fresh.missingPrices == preview.missingPrices else {
            throw ProjectEconomicsServiceError.stalePricing
        }
        guard fresh.profiles.contains(where: { $0.id == profileID }) else {
            throw ProjectEconomicsServiceError.profileNotFound(profileID)
        }
        let timestamp = now()
        let stored = preview.storedConfiguration
        let configuration = try ProjectEconomicsConfigurationSnapshot(
            id: stored?.id ?? makeID(),
            projectID: preview.draft.projectID,
            priceProfileID: profileID,
            manualJobCost: preview.draft.manualJobCost,
            createdAt: stored?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
        try Task.checkCancellation()
        do {
            try await repository.save(
                configuration: configuration,
                expectedUpdatedAt: stored?.updatedAt
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch ProjectEconomicsServiceError.staleConfiguration {
            throw ProjectEconomicsServiceError.staleConfiguration
        } catch {
            throw ProjectEconomicsServiceError.persistenceFailure
        }
        return ProjectEconomicsPreview(
            draft: fresh.draft,
            profiles: fresh.profiles,
            storedConfiguration: configuration,
            selectedProfile: fresh.selectedProfile,
            pricingVersion: fresh.pricingVersion,
            missingPrices: fresh.missingPrices,
            calculation: fresh.calculation
        )
    }

    private func loadConfiguration(
        projectID: UUID
    ) async throws -> ProjectEconomicsConfigurationSnapshot? {
        do {
            return try await repository.configuration(
                projectID: projectID
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ProjectEconomicsServiceError.persistenceFailure
        }
    }

    private func evaluate(
        draft: ProjectEconomicsDraft,
        storedConfiguration:
            ProjectEconomicsConfigurationSnapshot?,
        profiles: [PriceProfileSnapshot],
        at date: Date
    ) async throws -> ProjectEconomicsPreview {
        guard let profileID = draft.priceProfileID else {
            return ProjectEconomicsPreview(
                draft: draft,
                profiles: profiles,
                storedConfiguration: storedConfiguration,
                selectedProfile: nil,
                pricingVersion: nil,
                missingPrices: requiredPriceReferences(draft: draft),
                calculation: nil
            )
        }
        guard let profile = profiles.first(where: {
            $0.id == profileID
        }) else {
            return ProjectEconomicsPreview(
                draft: draft,
                profiles: profiles,
                storedConfiguration: storedConfiguration,
                selectedProfile: nil,
                pricingVersion: nil,
                missingPrices: requiredPriceReferences(draft: draft),
                calculation: nil
            )
        }
        let references = requiredPriceReferences(draft: draft)
        let resolution = try await prices.resolve(
            typeIDs: references.map(\.typeID),
            profileID: profileID,
            at: date
        )
        let missingSet = Set(resolution.missingTypeIDs)
        let missing = references.filter {
            missingSet.contains($0.typeID)
        }
        let version = ProjectEconomicsPricingVersion(
            profileID: profile.id,
            profileUpdatedAt: profile.updatedAt,
            prices: resolution.pricesByTypeID.map {
                ProjectEconomicsPriceVersion(
                    typeID: $0.key,
                    amount: $0.value
                )
            }.sorted { $0.typeID < $1.typeID }
        )
        let calculation: ProjectEconomicsCalculation?
        if missing.isEmpty {
            calculation = try calculator.calculate(
                targetTypeID: draft.targetTypeID,
                targetName: draft.targetName,
                targetQuantity: draft.targetQuantity,
                requirements: draft.plan.requirements,
                pricesByTypeID: resolution.pricesByTypeID,
                manualJobCost: draft.manualJobCost
            )
        } else {
            calculation = nil
        }
        return ProjectEconomicsPreview(
            draft: draft,
            profiles: profiles,
            storedConfiguration: storedConfiguration,
            selectedProfile: profile,
            pricingVersion: version,
            missingPrices: missing,
            calculation: calculation
        )
    }

    private func requiredPriceReferences(
        draft: ProjectEconomicsDraft
    ) -> [ProjectEconomicsMissingPrice] {
        var references: [Int64: ProjectEconomicsMissingPrice] = [
            draft.targetTypeID: ProjectEconomicsMissingPrice(
                typeID: draft.targetTypeID,
                name: draft.targetName,
                isTargetProduct: true
            )
        ]
        for requirement in draft.plan.requirements
        where requirement.requiredQuantity > 0 {
            if references[requirement.typeID] == nil {
                references[requirement.typeID] =
                    ProjectEconomicsMissingPrice(
                        typeID: requirement.typeID,
                        name: requirement.name,
                        isTargetProduct: false
                    )
            }
        }
        return references.values.sorted { lhs, rhs in
            if lhs.isTargetProduct != rhs.isTargetProduct {
                return lhs.isTargetProduct
            }
            return lhs.typeID < rhs.typeID
        }
    }
}
