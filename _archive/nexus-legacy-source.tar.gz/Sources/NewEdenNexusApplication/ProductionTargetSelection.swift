import Foundation
import NewEdenNexusDomain

public enum ProductionTargetQuantityError: Error, Equatable, Sendable {
    case empty
    case notAnInteger
    case notPositive
    case outOfRange
}

public enum ProductionTargetQuantityParser {
    public static func parse(
        _ text: String,
        locale: Locale = .current
    ) throws -> Int {
        var normalized = text.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !normalized.isEmpty else {
            throw ProductionTargetQuantityError.empty
        }
        let formatter = NumberFormatter()
        formatter.locale = locale
        formatter.numberStyle = .decimal
        if let decimalSeparator = formatter.decimalSeparator,
           normalized.contains(decimalSeparator) {
            throw ProductionTargetQuantityError.notAnInteger
        }
        for separator in [
            formatter.groupingSeparator,
            "\u{00A0}",
            "\u{202F}",
            " "
        ].compactMap({ $0 }) {
            normalized = normalized.replacingOccurrences(
                of: separator,
                with: ""
            )
        }
        guard let value = Int(normalized) else {
            if normalized.allSatisfy({
                $0.isNumber || $0 == "+" || $0 == "-"
            }) {
                throw ProductionTargetQuantityError.outOfRange
            }
            throw ProductionTargetQuantityError.notAnInteger
        }
        guard value > 0 else {
            throw ProductionTargetQuantityError.notPositive
        }
        return value
    }
}

public struct ProductionTargetSearchItem: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let groupID: Int64
    public let groupName: String
    public let categoryID: Int64
    public let categoryName: String
    public let activities: [ProductionTargetActivity]
    public let hasUnresolvedProductionReferences: Bool

    public init(
        typeID: Int64,
        name: String,
        groupID: Int64,
        groupName: String,
        categoryID: Int64,
        categoryName: String,
        activities: [ProductionTargetActivity],
        hasUnresolvedProductionReferences: Bool
    ) {
        self.typeID = typeID
        self.name = name
        self.groupID = groupID
        self.groupName = groupName
        self.categoryID = categoryID
        self.categoryName = categoryName
        self.activities = activities
        self.hasUnresolvedProductionReferences =
            hasUnresolvedProductionReferences
    }
}

public struct ProductionTargetSearchPage: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let items: [ProductionTargetSearchItem]
    public let hasMore: Bool

    public init(
        version: CatalogDataVersion,
        items: [ProductionTargetSearchItem],
        hasMore: Bool
    ) {
        self.version = version
        self.items = items
        self.hasMore = hasMore
    }
}

public struct ProductionTargetRecipeOption: Equatable, Sendable {
    public let blueprintTypeID: Int64
    public let blueprintName: String
    public let outputQuantityPerRun: Int64

    public init(
        blueprintTypeID: Int64,
        blueprintName: String,
        outputQuantityPerRun: Int64
    ) {
        self.blueprintTypeID = blueprintTypeID
        self.blueprintName = blueprintName
        self.outputQuantityPerRun = outputQuantityPerRun
    }
}

public struct BlockedProductionTargetRecipe: Equatable, Sendable {
    public let blueprintTypeID: Int64
    public let diagnosticCode: String

    public init(blueprintTypeID: Int64, diagnosticCode: String) {
        self.blueprintTypeID = blueprintTypeID
        self.diagnosticCode = diagnosticCode
    }
}

public struct ProductionTargetOptions: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let item: ProductionTargetSearchItem
    public let activity: ProductionTargetActivity
    public let availableRecipes: [ProductionTargetRecipeOption]
    public let blockedRecipes: [BlockedProductionTargetRecipe]

    public init(
        version: CatalogDataVersion,
        item: ProductionTargetSearchItem,
        activity: ProductionTargetActivity,
        availableRecipes: [ProductionTargetRecipeOption],
        blockedRecipes: [BlockedProductionTargetRecipe]
    ) {
        self.version = version
        self.item = item
        self.activity = activity
        self.availableRecipes = availableRecipes
        self.blockedRecipes = blockedRecipes
    }
}

public enum ProductionTargetSelectionError: Error, Equatable, Sendable {
    case itemNotFound(Int64)
    case itemNotPublished(Int64)
    case unsupportedActivity
    case noCompleteRecipe(
        productTypeID: Int64,
        activity: ProductionTargetActivity
    )
    case blueprintSelectionRequired([Int64])
    case blueprintMismatch(Int64)
    case catalogVersionChanged
    case catalog(CatalogQueryError)
}

public protocol ProductionTargetSelectionManaging: Sendable {
    func search(
        query: String?,
        activity: ProductionTargetActivity?,
        categoryID: Int64?,
        groupID: Int64?
    ) async throws -> ProductionTargetSearchPage

    func options(
        productTypeID: Int64,
        activity: ProductionTargetActivity
    ) async throws -> ProductionTargetOptions

    func select(
        productTypeID: Int64,
        activity: ProductionTargetActivity,
        blueprintTypeID: Int64?
    ) async throws -> ProductionTargetSelection

    func revalidate(
        _ selection: ProductionTargetSelection
    ) async throws -> ProductionTargetSelection
}

public struct ProductionTargetSelectionService:
    ProductionTargetSelectionManaging,
    Sendable
{
    private let catalog: any ItemBlueprintCatalogReading
    private let resolver: ResolveRecipeUseCase

    public init(
        catalog: any ItemBlueprintCatalogReading,
        resolver: ResolveRecipeUseCase
    ) {
        self.catalog = catalog
        self.resolver = resolver
    }

    public func search(
        query: String? = nil,
        activity: ProductionTargetActivity? = nil,
        categoryID: Int64? = nil,
        groupID: Int64? = nil
    ) async throws -> ProductionTargetSearchPage {
        try Task.checkCancellation()
        let request = try CatalogSearchRequest(
            query: query,
            filter: CatalogSearchFilter(
                scope: .producibleItems,
                publication: .publishedOnly,
                categoryID: categoryID,
                groupID: groupID,
                activity: activity.map(Self.catalogActivity)
            ),
            limit: 50
        )
        do {
            let page = try await catalog.search(request)
            try Task.checkCancellation()
            return ProductionTargetSearchPage(
                version: page.version,
                items: page.items.map(Self.searchItem),
                hasMore: page.hasMore
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as CatalogQueryError {
            throw ProductionTargetSelectionError.catalog(error)
        } catch {
            throw ProductionTargetSelectionError.catalog(.persistenceFailure)
        }
    }

    public func options(
        productTypeID: Int64,
        activity: ProductionTargetActivity
    ) async throws -> ProductionTargetOptions {
        try Task.checkCancellation()
        let details: CatalogItemDetails
        do {
            switch try await catalog.item(typeID: productTypeID) {
            case let .found(value):
                details = value
            case .notFound:
                throw ProductionTargetSelectionError
                    .itemNotFound(productTypeID)
            }
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as ProductionTargetSelectionError {
            throw error
        } catch let error as CatalogQueryError {
            throw ProductionTargetSelectionError.catalog(error)
        } catch {
            throw ProductionTargetSelectionError.catalog(.persistenceFailure)
        }

        guard details.summary.published else {
            throw ProductionTargetSelectionError
                .itemNotPublished(productTypeID)
        }
        let catalogActivity = Self.catalogActivity(activity)
        let candidateIDs = Set(
            details.productionLinks
                .filter {
                    $0.productTypeID == productTypeID
                        && $0.activity == catalogActivity
                }
                .map(\.blueprintTypeID)
        ).sorted()
        guard !candidateIDs.isEmpty else {
            throw ProductionTargetSelectionError.noCompleteRecipe(
                productTypeID: productTypeID,
                activity: activity
            )
        }

        var available: [ProductionTargetRecipeOption] = []
        var blocked: [BlockedProductionTargetRecipe] = []
        for blueprintTypeID in candidateIDs {
            try Task.checkCancellation()
            do {
                let recipe = try await resolver(
                    productTypeID: productTypeID,
                    activity: catalogActivity,
                    blueprintTypeID: blueprintTypeID
                )
                guard recipe.version == details.version else {
                    throw ProductionTargetSelectionError
                        .catalogVersionChanged
                }
                let blueprintName = try await loadBlueprintName(
                    typeID: blueprintTypeID,
                    expectedVersion: details.version
                )
                available.append(
                    ProductionTargetRecipeOption(
                        blueprintTypeID: blueprintTypeID,
                        blueprintName: blueprintName,
                        outputQuantityPerRun: recipe.outputQuantityPerRun
                    )
                )
            } catch is CancellationError {
                throw CancellationError()
            } catch let error as ProductionTargetSelectionError {
                throw error
            } catch let error as RecipeResolutionError {
                blocked.append(
                    BlockedProductionTargetRecipe(
                        blueprintTypeID: blueprintTypeID,
                        diagnosticCode: Self.diagnosticCode(for: error)
                    )
                )
            }
        }
        guard !available.isEmpty else {
            throw ProductionTargetSelectionError.noCompleteRecipe(
                productTypeID: productTypeID,
                activity: activity
            )
        }
        return ProductionTargetOptions(
            version: details.version,
            item: Self.searchItem(details.summary),
            activity: activity,
            availableRecipes: available.sorted {
                $0.blueprintTypeID < $1.blueprintTypeID
            },
            blockedRecipes: blocked.sorted {
                $0.blueprintTypeID < $1.blueprintTypeID
            }
        )
    }

    public func select(
        productTypeID: Int64,
        activity: ProductionTargetActivity,
        blueprintTypeID: Int64? = nil
    ) async throws -> ProductionTargetSelection {
        let options = try await options(
            productTypeID: productTypeID,
            activity: activity
        )
        let selected: ProductionTargetRecipeOption
        if let blueprintTypeID {
            guard let match = options.availableRecipes.first(where: {
                $0.blueprintTypeID == blueprintTypeID
            }) else {
                throw ProductionTargetSelectionError
                    .blueprintMismatch(blueprintTypeID)
            }
            selected = match
        } else {
            guard options.availableRecipes.count == 1,
                  let only = options.availableRecipes.first else {
                throw ProductionTargetSelectionError
                    .blueprintSelectionRequired(
                        options.availableRecipes.map(\.blueprintTypeID)
                    )
            }
            selected = only
        }
        return try ProductionTargetSelection(
            productTypeID: options.item.typeID,
            productName: options.item.name,
            activity: activity,
            blueprintTypeID: selected.blueprintTypeID,
            catalogBuildNumber: options.version.buildNumber,
            catalogContentSHA256: options.version.contentSHA256
        )
    }

    public func revalidate(
        _ selection: ProductionTargetSelection
    ) async throws -> ProductionTargetSelection {
        try await select(
            productTypeID: selection.productTypeID,
            activity: selection.activity,
            blueprintTypeID: selection.blueprintTypeID
        )
    }

    private func loadBlueprintName(
        typeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> String {
        let result = try await catalog.blueprint(typeID: typeID)
        switch result {
        case let .found(details):
            guard details.version == expectedVersion else {
                throw ProductionTargetSelectionError.catalogVersionChanged
            }
            return details.summary.name
        case .notFound:
            throw ProductionTargetSelectionError.blueprintMismatch(typeID)
        }
    }

    private static func catalogActivity(
        _ activity: ProductionTargetActivity
    ) -> StaticIndustryActivity {
        switch activity {
        case .manufacturing:
            .manufacturing
        case .reaction:
            .reaction
        }
    }

    private static func targetActivity(
        _ activity: StaticIndustryActivity
    ) -> ProductionTargetActivity? {
        switch activity {
        case .manufacturing:
            .manufacturing
        case .reaction:
            .reaction
        default:
            nil
        }
    }

    private static func searchItem(
        _ summary: CatalogItemSummary
    ) -> ProductionTargetSearchItem {
        ProductionTargetSearchItem(
            typeID: summary.typeID,
            name: summary.name,
            groupID: summary.groupID,
            groupName: summary.groupName,
            categoryID: summary.categoryID,
            categoryName: summary.categoryName,
            activities: summary.productionActivities
                .compactMap(targetActivity)
                .sorted { $0.rawValue < $1.rawValue },
            hasUnresolvedProductionReferences:
                summary.hasUnresolvedProductionReferences
        )
    }

    private static func diagnosticCode(
        for error: RecipeResolutionError
    ) -> String {
        switch error {
        case let .unresolvedReferences(diagnostics):
            diagnostics.first?.code.rawValue
                ?? RecipeDiagnosticCode.unresolvedReference.rawValue
        case let .invalidRecipe(diagnostic):
            diagnostic.code.rawValue
        case .recipeNotFound:
            "NEN-TARGET-001"
        case .explicitBlueprintMismatch:
            "NEN-TARGET-002"
        case .ambiguousRecipe:
            "NEN-TARGET-003"
        case .invalidExternalID, .unsupportedActivity, .catalog:
            "NEN-TARGET-004"
        }
    }
}
