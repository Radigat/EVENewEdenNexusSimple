import Foundation
import NewEdenNexusDomain

public struct PurchaseAllocationKey:
    Hashable,
    Comparable,
    Sendable
{
    public let projectID: UUID
    public let typeID: Int64

    public init(projectID: UUID, typeID: Int64) {
        self.projectID = projectID
        self.typeID = typeID
    }

    public static func < (
        lhs: PurchaseAllocationKey,
        rhs: PurchaseAllocationKey
    ) -> Bool {
        lhs.projectID == rhs.projectID
            ? lhs.typeID < rhs.typeID
            : lhs.projectID.uuidString < rhs.projectID.uuidString
    }
}

public struct PurchaseProgressSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let typeID: Int64
    public let purchasedQuantity: Int64
    public let createdAt: Date
    public let updatedAt: Date

    public var key: PurchaseAllocationKey {
        PurchaseAllocationKey(projectID: projectID, typeID: typeID)
    }

    public init(
        id: UUID,
        projectID: UUID,
        typeID: Int64,
        purchasedQuantity: Int64,
        createdAt: Date,
        updatedAt: Date
    ) {
        self.id = id
        self.projectID = projectID
        self.typeID = typeID
        self.purchasedQuantity = purchasedQuantity
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct PurchaseProgressVersion: Equatable, Sendable {
    public let id: UUID
    public let updatedAt: Date

    public init(id: UUID, updatedAt: Date) {
        self.id = id
        self.updatedAt = updatedAt
    }
}

public struct PurchaseProgressDraft: Equatable, Sendable {
    public let projectID: UUID
    public let typeID: Int64
    public let purchasedQuantity: Int64

    public var key: PurchaseAllocationKey {
        PurchaseAllocationKey(projectID: projectID, typeID: typeID)
    }

    public init(
        projectID: UUID,
        typeID: Int64,
        purchasedQuantity: Int64
    ) {
        self.projectID = projectID
        self.typeID = typeID
        self.purchasedQuantity = purchasedQuantity
    }
}

public struct PurchasingProjectSourceVersion:
    Equatable,
    Sendable
{
    public let projectID: UUID
    public let projectUpdatedAt: Date
    public let shopping: ShoppingListSourceVersion?
}

public struct PurchasingWorkflowSourceVersion:
    Equatable,
    Sendable
{
    public let projects: [PurchasingProjectSourceVersion]
    public let progress: [PurchaseProgressVersion]
}

public enum PurchasingProjectIssueKind:
    String,
    Equatable,
    Sendable
{
    case planUnavailable
}

public struct PurchasingProjectIssue:
    Identifiable,
    Equatable,
    Sendable
{
    public var id: UUID { projectID }
    public let projectID: UUID
    public let projectName: String
    public let kind: PurchasingProjectIssueKind
}

public struct PurchasingWorkflowPreview:
    Equatable,
    Sendable
{
    public let calculatedAt: Date
    public let sourceVersion: PurchasingWorkflowSourceVersion
    public let scopedProjectIDs: Set<UUID>
    public let issues: [PurchasingProjectIssue]
    public let storedProgress: [PurchaseProgressSnapshot]
    public let proposedProgress: [PurchaseProgressSnapshot]
    public let staleProgressKeys: [PurchaseAllocationKey]
    public let aggregation: PurchasingWorkflowAggregation

    public var hasChanges: Bool {
        progressValues(storedProgress) != progressValues(proposedProgress)
    }

    private func progressValues(
        _ progress: [PurchaseProgressSnapshot]
    ) -> [PurchaseAllocationKey: Int64] {
        Dictionary(
            uniqueKeysWithValues: progress.map {
                ($0.key, $0.purchasedQuantity)
            }
        )
    }
}

public enum PurchasingWorkflowManagementError:
    Error,
    Equatable,
    Sendable
{
    case confirmationRequired
    case duplicateDraft(PurchaseAllocationKey)
    case invalidDraft(PurchaseAllocationKey, quantity: Int64)
    case unknownDraft(PurchaseAllocationKey)
    case missingDrafts([PurchaseAllocationKey])
    case invalidStoredProgress(PurchaseAllocationKey)
    case stalePreview
    case calculationFailed
    case persistenceFailure
}

public enum PurchaseProgressRepositoryError:
    Error,
    Equatable,
    Sendable
{
    case staleState
}

public protocol PurchaseProgressRepository: Sendable {
    func progress(
        projectIDs: Set<UUID>
    ) async throws -> [PurchaseProgressSnapshot]

    func replaceProgress(
        _ progress: [PurchaseProgressSnapshot],
        scopedProjectIDs: Set<UUID>,
        expectedVersions: [PurchaseProgressVersion]
    ) async throws
}

public protocol PurchasingWorkflowManaging: Sendable {
    func load() async throws -> PurchasingWorkflowPreview

    func preview(
        progress: [PurchaseProgressDraft]
    ) async throws -> PurchasingWorkflowPreview

    func apply(
        _ preview: PurchasingWorkflowPreview,
        confirmed: Bool
    ) async throws -> PurchasingWorkflowPreview
}

public struct PurchasingWorkflowManagementService:
    PurchasingWorkflowManaging,
    Sendable
{
    private let projects: any ProductionProjectLifecycleManaging
    private let planning: any BuildOrBuyPlanning
    private let shopping: any ShoppingListManaging
    private let progress: any PurchaseProgressRepository
    private let aggregator: PurchasingWorkflowAggregator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        projects: any ProductionProjectLifecycleManaging,
        planning: any BuildOrBuyPlanning,
        shopping: any ShoppingListManaging,
        progress: any PurchaseProgressRepository,
        aggregator: PurchasingWorkflowAggregator = .init(),
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.projects = projects
        self.planning = planning
        self.shopping = shopping
        self.progress = progress
        self.aggregator = aggregator
        self.now = now
        self.makeID = makeID
    }

    public func load() async throws -> PurchasingWorkflowPreview {
        try await makePreview(drafts: nil)
    }

    public func preview(
        progress drafts: [PurchaseProgressDraft]
    ) async throws -> PurchasingWorkflowPreview {
        try await makePreview(drafts: drafts)
    }

    public func apply(
        _ preview: PurchasingWorkflowPreview,
        confirmed: Bool
    ) async throws -> PurchasingWorkflowPreview {
        guard confirmed else {
            throw PurchasingWorkflowManagementError.confirmationRequired
        }
        try Task.checkCancellation()
        let current = try await makePreview(drafts: nil)
        guard current.sourceVersion == preview.sourceVersion,
              current.scopedProjectIDs == preview.scopedProjectIDs,
              targetSignature(current.aggregation)
                == targetSignature(preview.aggregation) else {
            throw PurchasingWorkflowManagementError.stalePreview
        }
        try Task.checkCancellation()
        do {
            try await progress.replaceProgress(
                preview.proposedProgress,
                scopedProjectIDs: preview.scopedProjectIDs,
                expectedVersions: preview.sourceVersion.progress
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch PurchaseProgressRepositoryError.staleState {
            throw PurchasingWorkflowManagementError.stalePreview
        } catch {
            throw PurchasingWorkflowManagementError.persistenceFailure
        }

        let timestamp = now()
        return PurchasingWorkflowPreview(
            calculatedAt: timestamp,
            sourceVersion: PurchasingWorkflowSourceVersion(
                projects: preview.sourceVersion.projects,
                progress: versions(preview.proposedProgress)
            ),
            scopedProjectIDs: preview.scopedProjectIDs,
            issues: preview.issues,
            storedProgress: preview.proposedProgress,
            proposedProgress: preview.proposedProgress,
            staleProgressKeys: preview.staleProgressKeys,
            aggregation: preview.aggregation
        )
    }

    private func makePreview(
        drafts: [PurchaseProgressDraft]?
    ) async throws -> PurchasingWorkflowPreview {
        try Task.checkCancellation()
        let currentProjects: [ProductionProjectSnapshot]
        do {
            currentProjects = try await projects.projects(scope: .current)
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw PurchasingWorkflowManagementError.persistenceFailure
        }

        var allocations: [BaseAllocation] = []
        var issues: [PurchasingProjectIssue] = []
        var projectVersions: [PurchasingProjectSourceVersion] = []
        var scopedProjectIDs: Set<UUID> = []

        for project in currentProjects.sorted(by: projectOrder) {
            try Task.checkCancellation()
            do {
                let plan = try await planning.preview(
                    projectID: project.id,
                    decisions: nil
                )
                let list = try await shopping.load(planPreview: plan)
                scopedProjectIDs.insert(project.id)
                projectVersions.append(
                    PurchasingProjectSourceVersion(
                        projectID: project.id,
                        projectUpdatedAt: project.updatedAt,
                        shopping: list.sourceVersion
                    )
                )
                allocations.append(
                    contentsOf: list.aggregation.effectivePositions.map {
                        BaseAllocation(
                            projectID: project.id,
                            projectName: project.name,
                            typeID: $0.typeID,
                            itemName: $0.name,
                            targetQuantity: $0.purchaseQuantity
                        )
                    }
                )
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                projectVersions.append(
                    PurchasingProjectSourceVersion(
                        projectID: project.id,
                        projectUpdatedAt: project.updatedAt,
                        shopping: nil
                    )
                )
                issues.append(
                    PurchasingProjectIssue(
                        projectID: project.id,
                        projectName: project.name,
                        kind: .planUnavailable
                    )
                )
            }
        }

        let stored: [PurchaseProgressSnapshot]
        do {
            stored = try await progress.progress(
                projectIDs: scopedProjectIDs
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw PurchasingWorkflowManagementError.persistenceFailure
        }
        let storedByKey = try validatedStored(
            stored,
            scopedProjectIDs: scopedProjectIDs
        )
        let allocationKeys = Set(allocations.map(\.key))
        let staleKeys = Set(storedByKey.keys)
            .subtracting(allocationKeys)
            .sorted()
        let proposal = try proposedProgress(
            allocations: allocations,
            storedByKey: storedByKey,
            drafts: drafts
        )
        let proposalByKey = Dictionary(
            uniqueKeysWithValues: proposal.map { ($0.key, $0) }
        )
        let domainAllocations = allocations.map { allocation in
            ProjectPurchaseAllocation(
                projectID: allocation.projectID,
                projectName: allocation.projectName,
                typeID: allocation.typeID,
                itemName: allocation.itemName,
                targetQuantity: allocation.targetQuantity,
                recordedPurchasedQuantity:
                    proposalByKey[allocation.key]?.purchasedQuantity ?? 0
            )
        }
        let aggregation: PurchasingWorkflowAggregation
        do {
            aggregation = try aggregator.aggregate(domainAllocations)
        } catch {
            throw PurchasingWorkflowManagementError.calculationFailed
        }

        return PurchasingWorkflowPreview(
            calculatedAt: now(),
            sourceVersion: PurchasingWorkflowSourceVersion(
                projects: projectVersions.sorted {
                    $0.projectID.uuidString < $1.projectID.uuidString
                },
                progress: versions(stored)
            ),
            scopedProjectIDs: scopedProjectIDs,
            issues: issues.sorted(by: issueOrder),
            storedProgress: stored.sorted { $0.key < $1.key },
            proposedProgress: proposal.sorted { $0.key < $1.key },
            staleProgressKeys: staleKeys,
            aggregation: aggregation
        )
    }

    private func validatedStored(
        _ stored: [PurchaseProgressSnapshot],
        scopedProjectIDs: Set<UUID>
    ) throws -> [PurchaseAllocationKey: PurchaseProgressSnapshot] {
        var result: [PurchaseAllocationKey: PurchaseProgressSnapshot] = [:]
        for item in stored {
            guard scopedProjectIDs.contains(item.projectID),
                  item.typeID > 0,
                  item.purchasedQuantity > 0,
                  result[item.key] == nil else {
                throw PurchasingWorkflowManagementError
                    .invalidStoredProgress(item.key)
            }
            result[item.key] = item
        }
        return result
    }

    private func proposedProgress(
        allocations: [BaseAllocation],
        storedByKey: [PurchaseAllocationKey: PurchaseProgressSnapshot],
        drafts: [PurchaseProgressDraft]?
    ) throws -> [PurchaseProgressSnapshot] {
        guard let drafts else {
            return Array(storedByKey.values)
        }
        let allocationByKey = Dictionary(
            uniqueKeysWithValues: allocations.map { ($0.key, $0) }
        )
        var draftByKey: [PurchaseAllocationKey: Int64] = [:]
        for draft in drafts {
            guard let allocation = allocationByKey[draft.key] else {
                throw PurchasingWorkflowManagementError
                    .unknownDraft(draft.key)
            }
            guard draft.purchasedQuantity >= 0,
                  draft.purchasedQuantity <= allocation.targetQuantity else {
                throw PurchasingWorkflowManagementError.invalidDraft(
                    draft.key,
                    quantity: draft.purchasedQuantity
                )
            }
            guard draftByKey[draft.key] == nil else {
                throw PurchasingWorkflowManagementError
                    .duplicateDraft(draft.key)
            }
            draftByKey[draft.key] = draft.purchasedQuantity
        }
        let missing = Set(allocationByKey.keys)
            .subtracting(draftByKey.keys)
            .sorted()
        guard missing.isEmpty else {
            throw PurchasingWorkflowManagementError
                .missingDrafts(missing)
        }

        var result = storedByKey.filter {
            allocationByKey[$0.key] == nil
        }
        let timestamp = now()
        for allocation in allocations {
            guard let quantity = draftByKey[allocation.key],
                  quantity > 0 else {
                result.removeValue(forKey: allocation.key)
                continue
            }
            if let current = storedByKey[allocation.key],
               current.purchasedQuantity == quantity {
                result[allocation.key] = current
            } else {
                let current = storedByKey[allocation.key]
                result[allocation.key] = PurchaseProgressSnapshot(
                    id: current?.id ?? makeID(),
                    projectID: allocation.projectID,
                    typeID: allocation.typeID,
                    purchasedQuantity: quantity,
                    createdAt: current?.createdAt ?? timestamp,
                    updatedAt: timestamp
                )
            }
        }
        return Array(result.values)
    }

    private func versions(
        _ values: [PurchaseProgressSnapshot]
    ) -> [PurchaseProgressVersion] {
        values.map {
            PurchaseProgressVersion(id: $0.id, updatedAt: $0.updatedAt)
        }.sorted { $0.id.uuidString < $1.id.uuidString }
    }

    private func targetSignature(
        _ aggregation: PurchasingWorkflowAggregation
    ) -> [TargetSignature] {
        aggregation.positions.flatMap { position in
            position.sources.map {
                TargetSignature(
                    projectID: $0.projectID,
                    typeID: position.typeID,
                    targetQuantity: $0.targetQuantity
                )
            }
        }.sorted()
    }

    private func projectOrder(
        _ lhs: ProductionProjectSnapshot,
        _ rhs: ProductionProjectSnapshot
    ) -> Bool {
        lhs.name == rhs.name
            ? lhs.id.uuidString < rhs.id.uuidString
            : lhs.name < rhs.name
    }

    private func issueOrder(
        _ lhs: PurchasingProjectIssue,
        _ rhs: PurchasingProjectIssue
    ) -> Bool {
        lhs.projectName == rhs.projectName
            ? lhs.projectID.uuidString < rhs.projectID.uuidString
            : lhs.projectName < rhs.projectName
    }
}

private extension PurchasingWorkflowManagementService {
    struct BaseAllocation {
        let projectID: UUID
        let projectName: String
        let typeID: Int64
        let itemName: String
        let targetQuantity: Int64

        var key: PurchaseAllocationKey {
            PurchaseAllocationKey(projectID: projectID, typeID: typeID)
        }
    }

    struct TargetSignature: Equatable, Comparable {
        let projectID: UUID
        let typeID: Int64
        let targetQuantity: Int64

        static func < (
            lhs: TargetSignature,
            rhs: TargetSignature
        ) -> Bool {
            if lhs.projectID != rhs.projectID {
                return lhs.projectID.uuidString < rhs.projectID.uuidString
            }
            if lhs.typeID != rhs.typeID {
                return lhs.typeID < rhs.typeID
            }
            return lhs.targetQuantity < rhs.targetQuantity
        }
    }
}
