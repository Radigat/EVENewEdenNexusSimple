import Foundation
import NewEdenNexusDomain

public enum ProjectReservationChange: Equatable, Sendable {
    case reserve(
        typeID: Int64,
        remainingQuantity: Int64,
        priority: Int,
        expiresAt: Date?
    )
    case consume(typeID: Int64, quantity: Int64)
    case release(typeID: Int64)

    public var typeID: Int64 {
        switch self {
        case .reserve(let typeID, _, _, _),
             .consume(let typeID, _),
             .release(let typeID):
            typeID
        }
    }
}

public struct StockReservationVersion: Equatable, Sendable {
    public let id: UUID
    public let updatedAt: Date

    public init(id: UUID, updatedAt: Date) {
        self.id = id
        self.updatedAt = updatedAt
    }
}

public struct ProjectReservationSourceVersion:
    Equatable,
    Sendable
{
    public let safetyStock: SafetyStockSourceVersion
    public let reservations: [StockReservationVersion]

    public init(
        safetyStock: SafetyStockSourceVersion,
        reservations: [StockReservationVersion]
    ) {
        self.safetyStock = safetyStock
        self.reservations = reservations.sorted {
            $0.id.uuidString < $1.id.uuidString
        }
    }
}

public struct ProjectReservationPreview: Equatable, Sendable {
    public let projectID: UUID
    public let graphID: UUID
    public let calculatedAt: Date
    public let sourceVersion: ProjectReservationSourceVersion
    public let safetyStockPreview: SafetyStockPreview
    public let storedReservations: [StockReservationSnapshot]
    public let proposedReservations: [StockReservationSnapshot]
    public let changedReservations: [StockReservationSnapshot]
    public let changes: [ProjectReservationChange]
    public let calculation: ProjectReservationCalculation
}

public enum ProjectReservationServiceError:
    Error,
    Equatable,
    Sendable
{
    case duplicateChangeTypeID(Int64)
    case unknownMaterial(Int64)
    case activeReservationRequired(Int64)
    case invalidQuantity(Int64)
    case quantityOverflow(Int64)
    case insufficientAvailability(
        typeID: Int64,
        requested: Int64,
        maximum: Int64
    )
    case confirmationRequired
    case stalePreview
    case persistenceFailure
}

public enum ProjectReservationRepositoryError:
    Error,
    Equatable,
    Sendable
{
    case staleState
}

public protocol ProjectReservationRepository: Sendable {
    func reservations(typeIDs: [Int64]) async throws
        -> [StockReservationSnapshot]

    func reservations(projectID: UUID) async throws
        -> [StockReservationSnapshot]

    func applyReservations(
        _ changes: [StockReservationSnapshot],
        relevantTypeIDs: [Int64],
        expectedVersions: [StockReservationVersion]
    ) async throws
}

public protocol ProjectReservationManaging: Sendable {
    func preview(
        projectID: UUID,
        changes: [ProjectReservationChange]?
    ) async throws -> ProjectReservationPreview

    func apply(
        _ preview: ProjectReservationPreview,
        confirmed: Bool
    ) async throws -> ProjectReservationPreview
}

public struct ProjectReservationService:
    ProjectReservationManaging,
    Sendable
{
    private let safetyStock: any SafetyStockManaging
    private let repository: any ProjectReservationRepository
    private let calculator: ProjectReservationCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        safetyStock: any SafetyStockManaging,
        repository: any ProjectReservationRepository,
        calculator: ProjectReservationCalculator = .init(),
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.safetyStock = safetyStock
        self.repository = repository
        self.calculator = calculator
        self.now = now
        self.makeID = makeID
    }

    public func preview(
        projectID: UUID,
        changes: [ProjectReservationChange]? = nil
    ) async throws -> ProjectReservationPreview {
        try Task.checkCancellation()
        let safetyPreview = try await safetyStock.preview(
            projectID: projectID,
            drafts: nil
        )
        let typeIDs = safetyPreview.calculation.lines
            .map(\.availability.typeID)
            .sorted()
        let stored = try await repository.reservations(
            typeIDs: typeIDs
        ).sorted(by: reservationOrder)
        try Task.checkCancellation()
        let timestamp = now()
        let selectedChanges = changes ?? []
        let proposal = try makeProposal(
            projectID: projectID,
            typeIDs: typeIDs,
            stored: stored,
            changes: selectedChanges,
            timestamp: timestamp
        )
        let calculation = try calculator.calculate(
            projectID: projectID,
            safetyStock: safetyPreview.calculation,
            reservations: proposal.all,
            at: timestamp
        )
        try validateAvailability(
            changes: selectedChanges,
            calculation: calculation
        )
        return ProjectReservationPreview(
            projectID: projectID,
            graphID: safetyPreview.graphID,
            calculatedAt: timestamp,
            sourceVersion: sourceVersion(
                safetyStock: safetyPreview,
                reservations: stored
            ),
            safetyStockPreview: safetyPreview,
            storedReservations: stored,
            proposedReservations: proposal.all,
            changedReservations: proposal.changed,
            changes: selectedChanges.sorted {
                $0.typeID < $1.typeID
            },
            calculation: calculation
        )
    }

    public func apply(
        _ preview: ProjectReservationPreview,
        confirmed: Bool
    ) async throws -> ProjectReservationPreview {
        guard confirmed else {
            throw ProjectReservationServiceError.confirmationRequired
        }
        try Task.checkCancellation()
        let currentSafety = try await safetyStock.preview(
            projectID: preview.projectID,
            drafts: nil
        )
        let typeIDs = currentSafety.calculation.lines
            .map(\.availability.typeID)
            .sorted()
        let currentStored = try await repository.reservations(
            typeIDs: typeIDs
        ).sorted(by: reservationOrder)
        let currentSource = sourceVersion(
            safetyStock: currentSafety,
            reservations: currentStored
        )
        guard currentSource == preview.sourceVersion,
              currentSafety.graphID == preview.graphID else {
            throw ProjectReservationServiceError.stalePreview
        }
        let calculation = try calculator.calculate(
            projectID: preview.projectID,
            safetyStock: currentSafety.calculation,
            reservations: preview.proposedReservations,
            at: preview.calculatedAt
        )
        try validateAvailability(
            changes: preview.changes,
            calculation: calculation
        )
        try Task.checkCancellation()
        do {
            try await repository.applyReservations(
                preview.changedReservations,
                relevantTypeIDs: typeIDs,
                expectedVersions: preview.sourceVersion.reservations
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch ProjectReservationRepositoryError.staleState {
            throw ProjectReservationServiceError.stalePreview
        } catch {
            throw ProjectReservationServiceError.persistenceFailure
        }

        return ProjectReservationPreview(
            projectID: preview.projectID,
            graphID: currentSafety.graphID,
            calculatedAt: now(),
            sourceVersion: sourceVersion(
                safetyStock: currentSafety,
                reservations: preview.proposedReservations
            ),
            safetyStockPreview: currentSafety,
            storedReservations: preview.proposedReservations,
            proposedReservations: preview.proposedReservations,
            changedReservations: [],
            changes: [],
            calculation: calculation
        )
    }

    private struct Proposal {
        let all: [StockReservationSnapshot]
        let changed: [StockReservationSnapshot]
    }

    private func makeProposal(
        projectID: UUID,
        typeIDs: [Int64],
        stored: [StockReservationSnapshot],
        changes: [ProjectReservationChange],
        timestamp: Date
    ) throws -> Proposal {
        let allowed = Set(typeIDs)
        var changesByTypeID: [Int64: ProjectReservationChange] = [:]
        for change in changes {
            guard allowed.contains(change.typeID) else {
                throw ProjectReservationServiceError
                    .unknownMaterial(change.typeID)
            }
            guard changesByTypeID[change.typeID] == nil else {
                throw ProjectReservationServiceError
                    .duplicateChangeTypeID(change.typeID)
            }
            changesByTypeID[change.typeID] = change
        }

        let activeCurrent = Dictionary(
            uniqueKeysWithValues: try activeReservations(
                stored,
                projectID: projectID
            ).map { ($0.typeID, $0) }
        )
        var changed: [StockReservationSnapshot] = []
        for change in changesByTypeID.values {
            let existing = activeCurrent[change.typeID]
            changed.append(
                try changedReservation(
                    change,
                    projectID: projectID,
                    existing: existing,
                    timestamp: timestamp
                )
            )
        }

        let changedIDs = Set(changed.map(\.id))
        var all = stored.filter { !changedIDs.contains($0.id) }
        all.append(contentsOf: changed)
        return Proposal(
            all: all.sorted(by: reservationOrder),
            changed: changed.sorted(by: reservationOrder)
        )
    }

    private func activeReservations(
        _ reservations: [StockReservationSnapshot],
        projectID: UUID
    ) throws -> [StockReservationSnapshot] {
        var byTypeID: [Int64: StockReservationSnapshot] = [:]
        for reservation in reservations
        where reservation.projectID == projectID
                && reservation.status.isBinding {
            guard byTypeID[reservation.typeID] == nil else {
                throw ProjectReservationCalculationError
                    .duplicateActiveReservation(
                        projectID: projectID,
                        typeID: reservation.typeID
                    )
            }
            byTypeID[reservation.typeID] = reservation
        }
        return Array(byTypeID.values)
    }

    private func changedReservation(
        _ change: ProjectReservationChange,
        projectID: UUID,
        existing: StockReservationSnapshot?,
        timestamp: Date
    ) throws -> StockReservationSnapshot {
        switch change {
        case .reserve(
            let typeID,
            let remaining,
            let priority,
            let expiresAt
        ):
            guard remaining > 0 else {
                throw ProjectReservationServiceError
                    .invalidQuantity(remaining)
            }
            let consumed = existing?.consumedQuantity ?? 0
            let total = consumed.addingReportingOverflow(remaining)
            guard !total.overflow else {
                throw ProjectReservationServiceError
                    .quantityOverflow(typeID)
            }
            return try StockReservationSnapshot(
                id: existing?.id ?? makeID(),
                projectID: projectID,
                typeID: typeID,
                reservedQuantity: total.partialValue,
                consumedQuantity: consumed,
                priority: priority,
                expiresAt: expiresAt,
                status: consumed == 0
                    ? .reserved
                    : .partiallyConsumed,
                createdAt: existing?.createdAt ?? timestamp,
                updatedAt: timestamp,
                releasedAt: nil,
                consumedAt: nil
            )
        case .consume(let typeID, let quantity):
            guard quantity > 0 else {
                throw ProjectReservationServiceError
                    .invalidQuantity(quantity)
            }
            guard let existing else {
                throw ProjectReservationServiceError
                    .activeReservationRequired(typeID)
            }
            guard quantity <= existing.remainingQuantity else {
                throw ProjectReservationServiceError
                    .invalidQuantity(quantity)
            }
            let consumed = existing.consumedQuantity + quantity
            let isComplete = consumed == existing.reservedQuantity
            return try StockReservationSnapshot(
                id: existing.id,
                projectID: projectID,
                typeID: typeID,
                reservedQuantity: existing.reservedQuantity,
                consumedQuantity: consumed,
                priority: existing.priority,
                expiresAt: existing.expiresAt,
                status: isComplete ? .consumed : .partiallyConsumed,
                createdAt: existing.createdAt,
                updatedAt: timestamp,
                releasedAt: nil,
                consumedAt: isComplete ? timestamp : nil
            )
        case .release(let typeID):
            guard let existing else {
                throw ProjectReservationServiceError
                    .activeReservationRequired(typeID)
            }
            return try StockReservationSnapshot(
                id: existing.id,
                projectID: projectID,
                typeID: typeID,
                reservedQuantity: existing.reservedQuantity,
                consumedQuantity: existing.consumedQuantity,
                priority: existing.priority,
                expiresAt: existing.expiresAt,
                status: .released,
                createdAt: existing.createdAt,
                updatedAt: timestamp,
                releasedAt: timestamp,
                consumedAt: nil
            )
        }
    }

    private func validateAvailability(
        changes: [ProjectReservationChange],
        calculation: ProjectReservationCalculation
    ) throws {
        let lines = Dictionary(
            uniqueKeysWithValues: calculation.lines.map {
                ($0.safetyStock.availability.typeID, $0)
            }
        )
        for change in changes {
            guard case .reserve(
                let typeID,
                let requested,
                _,
                _
            ) = change else {
                continue
            }
            guard let line = lines[typeID] else {
                throw ProjectReservationServiceError
                    .unknownMaterial(typeID)
            }
            guard requested <= line.maximumReservableQuantity else {
                throw ProjectReservationServiceError
                    .insufficientAvailability(
                        typeID: typeID,
                        requested: requested,
                        maximum: line.maximumReservableQuantity
                    )
            }
        }
    }

    private func sourceVersion(
        safetyStock: SafetyStockPreview,
        reservations: [StockReservationSnapshot]
    ) -> ProjectReservationSourceVersion {
        ProjectReservationSourceVersion(
            safetyStock: safetyStock.sourceVersion,
            reservations: reservations.map {
                StockReservationVersion(
                    id: $0.id,
                    updatedAt: $0.updatedAt
                )
            }
        )
    }

    private func reservationOrder(
        _ left: StockReservationSnapshot,
        _ right: StockReservationSnapshot
    ) -> Bool {
        if left.typeID != right.typeID {
            return left.typeID < right.typeID
        }
        if left.projectID != right.projectID {
            return left.projectID.uuidString
                < right.projectID.uuidString
        }
        return left.id.uuidString < right.id.uuidString
    }
}
