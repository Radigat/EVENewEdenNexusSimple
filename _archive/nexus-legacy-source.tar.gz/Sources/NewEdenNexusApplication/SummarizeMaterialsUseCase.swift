import NewEdenNexusDomain

public protocol MaterialSummarizing: Sendable {
    func summarize(lines: [MaterialLine]) async throws -> MaterialSummary
}

public struct SummarizeMaterialsUseCase: Sendable {
    private let summarizer: any MaterialSummarizing

    public init(summarizer: any MaterialSummarizing) {
        self.summarizer = summarizer
    }

    public func callAsFunction(lines: [MaterialLine]) async throws -> MaterialSummary {
        try await summarizer.summarize(lines: lines)
    }
}
