import Foundation

public enum RecipeReferenceRole: String, Equatable, Sendable {
    case material
    case product
}

public enum RecipeDiagnosticCode: String, Equatable, Sendable {
    case unresolvedReference = "NEN-RECIPE-001"
    case emptyMaterialList = "NEN-RECIPE-002"
    case unpublishedRecipe = "NEN-RECIPE-003"
    case inconsistentCandidate = "NEN-RECIPE-004"
}

public struct RecipeReferenceDiagnostic: Equatable, Sendable {
    public let code: RecipeDiagnosticCode
    public let version: CatalogDataVersion
    public let blueprintTypeID: Int64
    public let activity: StaticIndustryActivity
    public let role: RecipeReferenceRole
    public let missingTypeID: Int64

    public init(
        version: CatalogDataVersion,
        blueprintTypeID: Int64,
        activity: StaticIndustryActivity,
        role: RecipeReferenceRole,
        missingTypeID: Int64
    ) {
        self.code = .unresolvedReference
        self.version = version
        self.blueprintTypeID = blueprintTypeID
        self.activity = activity
        self.role = role
        self.missingTypeID = missingTypeID
    }
}

public struct RecipeValidationDiagnostic: Equatable, Sendable {
    public let code: RecipeDiagnosticCode
    public let version: CatalogDataVersion
    public let blueprintTypeID: Int64
    public let activity: StaticIndustryActivity

    public init(
        code: RecipeDiagnosticCode,
        version: CatalogDataVersion,
        blueprintTypeID: Int64,
        activity: StaticIndustryActivity
    ) {
        self.code = code
        self.version = version
        self.blueprintTypeID = blueprintTypeID
        self.activity = activity
    }
}

public struct RecipeCandidateMaterial: Equatable, Sendable {
    public let typeID: Int64
    public let typeIsResolved: Bool
    public let quantity: Int64
    public let consumptionType: StaticDataConsumptionType
    public let sortOrder: Int

    public init(
        typeID: Int64,
        typeIsResolved: Bool,
        quantity: Int64,
        consumptionType: StaticDataConsumptionType,
        sortOrder: Int
    ) {
        self.typeID = typeID
        self.typeIsResolved = typeIsResolved
        self.quantity = quantity
        self.consumptionType = consumptionType
        self.sortOrder = sortOrder
    }
}

public struct RecipeCandidateProduct: Equatable, Sendable {
    public let typeID: Int64
    public let typeIsResolved: Bool
    public let quantity: Int64
    public let probability: Double?
    public let sortOrder: Int

    public init(
        typeID: Int64,
        typeIsResolved: Bool,
        quantity: Int64,
        probability: Double?,
        sortOrder: Int
    ) {
        self.typeID = typeID
        self.typeIsResolved = typeIsResolved
        self.quantity = quantity
        self.probability = probability
        self.sortOrder = sortOrder
    }
}

public struct RecipeCandidate: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let blueprintTypeID: Int64
    public let blueprintIsPublished: Bool
    public let requestedProductIsPublished: Bool
    public let activity: StaticIndustryActivity
    public let timeSeconds: Int64
    public let maxProductionLimit: Int64?
    public let materials: [RecipeCandidateMaterial]
    public let products: [RecipeCandidateProduct]

    public init(
        version: CatalogDataVersion,
        blueprintTypeID: Int64,
        blueprintIsPublished: Bool,
        requestedProductIsPublished: Bool,
        activity: StaticIndustryActivity,
        timeSeconds: Int64,
        maxProductionLimit: Int64?,
        materials: [RecipeCandidateMaterial],
        products: [RecipeCandidateProduct]
    ) {
        self.version = version
        self.blueprintTypeID = blueprintTypeID
        self.blueprintIsPublished = blueprintIsPublished
        self.requestedProductIsPublished = requestedProductIsPublished
        self.activity = activity
        self.timeSeconds = timeSeconds
        self.maxProductionLimit = maxProductionLimit
        self.materials = materials
        self.products = products
    }
}

public struct RecipeCandidatePage: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let candidates: [RecipeCandidate]

    public init(
        version: CatalogDataVersion,
        candidates: [RecipeCandidate]
    ) {
        self.version = version
        self.candidates = candidates
    }
}

public protocol RecipeCandidateReading: Sendable {
    func recipeCandidates(
        productTypeID: Int64,
        activity: StaticIndustryActivity,
        blueprintTypeID: Int64?
    ) async throws -> RecipeCandidatePage
}

public struct RecipeReferenceAuditEntry: Equatable, Sendable {
    public let diagnostic: RecipeReferenceDiagnostic
    public let probeProductTypeID: Int64

    public init(
        diagnostic: RecipeReferenceDiagnostic,
        probeProductTypeID: Int64
    ) {
        self.diagnostic = diagnostic
        self.probeProductTypeID = probeProductTypeID
    }
}

public struct RecipeReferenceAudit: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let entries: [RecipeReferenceAuditEntry]

    public init(
        version: CatalogDataVersion,
        entries: [RecipeReferenceAuditEntry]
    ) {
        self.version = version
        self.entries = entries
    }
}

public protocol RecipeReferenceAuditing: Sendable {
    func unresolvedRecipeReferenceAudit() async throws
        -> RecipeReferenceAudit
}

public struct ResolvedRecipeMaterial: Equatable, Sendable {
    public let typeID: Int64
    public let quantity: Int64
    public let consumptionType: StaticDataConsumptionType
    public let sortOrder: Int

    public init(
        typeID: Int64,
        quantity: Int64,
        consumptionType: StaticDataConsumptionType,
        sortOrder: Int
    ) {
        self.typeID = typeID
        self.quantity = quantity
        self.consumptionType = consumptionType
        self.sortOrder = sortOrder
    }
}

public struct ResolvedRecipe: Equatable, Sendable {
    public let version: CatalogDataVersion
    public let blueprintTypeID: Int64
    public let activity: StaticIndustryActivity
    public let productTypeID: Int64
    public let outputQuantityPerRun: Int64
    public let timeSeconds: Int64
    public let maxProductionLimit: Int64?
    public let materials: [ResolvedRecipeMaterial]

    public init(
        version: CatalogDataVersion,
        blueprintTypeID: Int64,
        activity: StaticIndustryActivity,
        productTypeID: Int64,
        outputQuantityPerRun: Int64,
        timeSeconds: Int64,
        maxProductionLimit: Int64?,
        materials: [ResolvedRecipeMaterial]
    ) {
        self.version = version
        self.blueprintTypeID = blueprintTypeID
        self.activity = activity
        self.productTypeID = productTypeID
        self.outputQuantityPerRun = outputQuantityPerRun
        self.timeSeconds = timeSeconds
        self.maxProductionLimit = maxProductionLimit
        self.materials = materials
    }
}

public enum RecipeResolutionError: Error, Equatable, Sendable {
    case invalidExternalID(Int64)
    case unsupportedActivity(StaticIndustryActivity)
    case recipeNotFound(
        version: CatalogDataVersion,
        productTypeID: Int64,
        activity: StaticIndustryActivity
    )
    case explicitBlueprintMismatch(
        version: CatalogDataVersion,
        productTypeID: Int64,
        activity: StaticIndustryActivity,
        blueprintTypeID: Int64
    )
    case ambiguousRecipe(
        version: CatalogDataVersion,
        productTypeID: Int64,
        activity: StaticIndustryActivity,
        candidateBlueprintTypeIDs: [Int64]
    )
    case unresolvedReferences([RecipeReferenceDiagnostic])
    case invalidRecipe(RecipeValidationDiagnostic)
    case catalog(CatalogQueryError)
}

public struct ResolveRecipeUseCase: Sendable {
    private let source: any RecipeCandidateReading

    public init(source: any RecipeCandidateReading) {
        self.source = source
    }

    public func callAsFunction(
        productTypeID: Int64,
        activity: StaticIndustryActivity,
        blueprintTypeID: Int64? = nil
    ) async throws -> ResolvedRecipe {
        try Task.checkCancellation()
        guard productTypeID >= 0 else {
            throw RecipeResolutionError.invalidExternalID(productTypeID)
        }
        if let blueprintTypeID, blueprintTypeID < 0 {
            throw RecipeResolutionError.invalidExternalID(blueprintTypeID)
        }
        guard activity == .manufacturing || activity == .reaction else {
            throw RecipeResolutionError.unsupportedActivity(activity)
        }

        let page: RecipeCandidatePage
        do {
            page = try await source.recipeCandidates(
                productTypeID: productTypeID,
                activity: activity,
                blueprintTypeID: blueprintTypeID
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as CatalogQueryError {
            throw RecipeResolutionError.catalog(error)
        } catch {
            throw RecipeResolutionError.catalog(.persistenceFailure)
        }
        try Task.checkCancellation()

        let candidates = page.candidates.sorted {
            $0.blueprintTypeID < $1.blueprintTypeID
        }
        guard !candidates.isEmpty else {
            if let blueprintTypeID {
                throw RecipeResolutionError.explicitBlueprintMismatch(
                    version: page.version,
                    productTypeID: productTypeID,
                    activity: activity,
                    blueprintTypeID: blueprintTypeID
                )
            }
            throw RecipeResolutionError.recipeNotFound(
                version: page.version,
                productTypeID: productTypeID,
                activity: activity
            )
        }
        let selectableCandidates: [RecipeCandidate]
        if let blueprintTypeID {
            // An explicit choice must never be replaced by another recipe,
            // even if the source returns a broader candidate page.
            let explicitCandidates = candidates.filter {
                $0.blueprintTypeID == blueprintTypeID
            }
            guard !explicitCandidates.isEmpty else {
                throw RecipeResolutionError.explicitBlueprintMismatch(
                    version: page.version,
                    productTypeID: productTypeID,
                    activity: activity,
                    blueprintTypeID: blueprintTypeID
                )
            }
            selectableCandidates = explicitCandidates
        } else {
            // The official SDE can retain unpublished test or legacy
            // blueprints beside the single published production formula.
            // They are not valid implicit production choices and must not
            // make an otherwise unique published recipe ambiguous.
            let publishedCandidates = candidates.filter(
                \.blueprintIsPublished
            )
            selectableCandidates = publishedCandidates.isEmpty
                ? candidates
                : publishedCandidates
        }
        guard selectableCandidates.count == 1,
              let selected = selectableCandidates.first else {
            throw RecipeResolutionError.ambiguousRecipe(
                version: page.version,
                productTypeID: productTypeID,
                activity: activity,
                candidateBlueprintTypeIDs:
                    selectableCandidates.map(\.blueprintTypeID)
            )
        }
        guard selected.version == page.version,
              selected.activity == activity else {
            throw RecipeResolutionError.invalidRecipe(
                validationDiagnostic(for: selected, code: .inconsistentCandidate)
            )
        }

        let diagnostics = unresolvedDiagnostics(for: selected)
        guard diagnostics.isEmpty else {
            throw RecipeResolutionError.unresolvedReferences(diagnostics)
        }
        guard selected.blueprintIsPublished,
              selected.requestedProductIsPublished else {
            throw RecipeResolutionError.invalidRecipe(
                validationDiagnostic(for: selected, code: .unpublishedRecipe)
            )
        }
        guard !selected.materials.isEmpty else {
            throw RecipeResolutionError.invalidRecipe(
                validationDiagnostic(for: selected, code: .emptyMaterialList)
            )
        }

        let matchingProducts = selected.products.filter {
            $0.typeID == productTypeID
        }
        guard matchingProducts.count == 1,
              let requestedProduct = matchingProducts.first,
              requestedProduct.quantity > 0,
              selected.timeSeconds >= 0,
              selected.maxProductionLimit.map({ $0 > 0 }) ?? true,
              selected.materials.allSatisfy({
                  $0.quantity > 0 && $0.typeID >= 0 && $0.sortOrder >= 0
              }),
              selected.products.allSatisfy({
                  $0.quantity > 0
                      && $0.typeID >= 0
                      && $0.sortOrder >= 0
                      && $0.probability == nil
              }) else {
            throw RecipeResolutionError.invalidRecipe(
                validationDiagnostic(for: selected, code: .inconsistentCandidate)
            )
        }

        let materials = selected.materials
            .sorted(by: Self.materialSort)
            .map {
                ResolvedRecipeMaterial(
                    typeID: $0.typeID,
                    quantity: $0.quantity,
                    consumptionType: $0.consumptionType,
                    sortOrder: $0.sortOrder
                )
            }
        return ResolvedRecipe(
            version: selected.version,
            blueprintTypeID: selected.blueprintTypeID,
            activity: selected.activity,
            productTypeID: requestedProduct.typeID,
            outputQuantityPerRun: requestedProduct.quantity,
            timeSeconds: selected.timeSeconds,
            maxProductionLimit: selected.maxProductionLimit,
            materials: materials
        )
    }

    private func unresolvedDiagnostics(
        for candidate: RecipeCandidate
    ) -> [RecipeReferenceDiagnostic] {
        let materialDiagnostics = candidate.materials
            .filter { !$0.typeIsResolved }
            .map {
                RecipeReferenceDiagnostic(
                    version: candidate.version,
                    blueprintTypeID: candidate.blueprintTypeID,
                    activity: candidate.activity,
                    role: .material,
                    missingTypeID: $0.typeID
                )
            }
        let productDiagnostics = candidate.products
            .filter { !$0.typeIsResolved }
            .map {
                RecipeReferenceDiagnostic(
                    version: candidate.version,
                    blueprintTypeID: candidate.blueprintTypeID,
                    activity: candidate.activity,
                    role: .product,
                    missingTypeID: $0.typeID
                )
            }
        return (materialDiagnostics + productDiagnostics)
            .sorted(by: Self.diagnosticSort)
    }

    private func validationDiagnostic(
        for candidate: RecipeCandidate,
        code: RecipeDiagnosticCode
    ) -> RecipeValidationDiagnostic {
        RecipeValidationDiagnostic(
            code: code,
            version: candidate.version,
            blueprintTypeID: candidate.blueprintTypeID,
            activity: candidate.activity
        )
    }

    private static func materialSort(
        _ lhs: RecipeCandidateMaterial,
        _ rhs: RecipeCandidateMaterial
    ) -> Bool {
        if lhs.sortOrder != rhs.sortOrder {
            return lhs.sortOrder < rhs.sortOrder
        }
        return lhs.typeID < rhs.typeID
    }

    private static func diagnosticSort(
        _ lhs: RecipeReferenceDiagnostic,
        _ rhs: RecipeReferenceDiagnostic
    ) -> Bool {
        if lhs.role != rhs.role {
            return lhs.role.rawValue < rhs.role.rawValue
        }
        return lhs.missingTypeID < rhs.missingTypeID
    }
}
