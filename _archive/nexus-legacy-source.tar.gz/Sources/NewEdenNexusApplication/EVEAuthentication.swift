import Foundation

public struct EVEAuthenticationConfiguration: Equatable, Sendable {
    public let clientID: String
    public let redirectURI: URL
    public let scopes: [String]
    public let callbackTimeout: Duration

    public init(
        clientID: String,
        redirectURI: URL,
        scopes: [String],
        callbackTimeout: Duration = .seconds(120)
    ) {
        self.clientID = clientID
        self.redirectURI = redirectURI
        self.scopes = Array(Set(scopes)).sorted()
        self.callbackTimeout = callbackTimeout
    }
}

public struct EVEAuthenticatedIdentity: Equatable, Sendable {
    public let characterID: Int64
    public let characterName: String
    public let grantedScopes: [String]
    public let expiresAt: Date

    public init(
        characterID: Int64,
        characterName: String,
        grantedScopes: [String],
        expiresAt: Date
    ) {
        self.characterID = characterID
        self.characterName = characterName
        self.grantedScopes = Array(Set(grantedScopes)).sorted()
        self.expiresAt = expiresAt
    }
}

public struct EVEAuthorizationGrant: Equatable, Sendable {
    public let accessToken: String
    public let refreshToken: String
    public let identity: EVEAuthenticatedIdentity

    public init(
        accessToken: String,
        refreshToken: String,
        identity: EVEAuthenticatedIdentity
    ) {
        self.accessToken = accessToken
        self.refreshToken = refreshToken
        self.identity = identity
    }
}

public struct EVECharacterAccount: Equatable, Identifiable, Sendable {
    public var id: Int64 { characterID }

    public let characterID: Int64
    public let name: String
    public let accountLabel: String
    public let syncState: String
    public let lastSync: Date?
    public let createdAt: Date
    public let authorizedScopes: [String]
    public let authorizationUpdatedAt: Date?

    public init(
        characterID: Int64,
        name: String,
        accountLabel: String = "EVE Online",
        syncState: String = "Veraltet",
        lastSync: Date? = nil,
        createdAt: Date = Date(),
        authorizedScopes: [String] = [],
        authorizationUpdatedAt: Date? = nil
    ) {
        self.characterID = characterID
        self.name = name
        self.accountLabel = accountLabel
        self.syncState = syncState
        self.lastSync = lastSync
        self.createdAt = createdAt
        self.authorizedScopes = Array(
            Set(
                authorizedScopes
                    .map {
                        $0.trimmingCharacters(
                            in: .whitespacesAndNewlines
                        )
                    }
                    .filter { !$0.isEmpty }
            )
        ).sorted()
        self.authorizationUpdatedAt = authorizationUpdatedAt
    }

    public func authorizes(_ scope: String) -> Bool {
        authorizedScopes.contains(scope)
    }
}

public enum EVEAccountDisconnectConfirmation: Sendable {
    case unconfirmed
    case confirmed
}

public enum EVEAuthenticationError: Error, Equatable, Sendable {
    case invalidConfiguration
    case browserLaunchFailed
    case callbackUnavailable
    case callbackTimeout
    case callbackRejected
    case authorizationDenied
    case stateMismatch
    case missingAuthorizationCode
    case invalidDiscovery
    case tokenExchangeFailed(
        status: Int,
        oauthError: EVEOAuthTokenError?
    )
    case invalidTokenResponse
    case unsupportedSigningAlgorithm
    case signingKeyUnavailable
    case invalidSignature
    case invalidIssuer
    case invalidAudience
    case expiredToken
    case invalidSubject
    case missingScopes([String])
    case refreshTokenUnavailable
    case localCredentialAccessFailed
    case identityChanged
    case disconnectConfirmationRequired
    case compensationFailed
}

public extension EVEAuthenticationError {
    var diagnosticReason: String {
        switch self {
        case .invalidConfiguration:
            "invalid_configuration"
        case .browserLaunchFailed:
            "browser_launch_failed"
        case .callbackUnavailable:
            "callback_unavailable"
        case .callbackTimeout:
            "callback_timeout"
        case .callbackRejected:
            "callback_rejected"
        case .authorizationDenied:
            "authorization_denied"
        case .stateMismatch:
            "state_mismatch"
        case .missingAuthorizationCode:
            "missing_authorization_code"
        case .invalidDiscovery:
            "invalid_discovery"
        case .tokenExchangeFailed(let status, let oauthError):
            if let oauthError {
                "token_exchange_\(oauthError.rawValue)"
            } else {
                "token_exchange_http_\(status)"
            }
        case .invalidTokenResponse:
            "invalid_token_response"
        case .unsupportedSigningAlgorithm:
            "unsupported_signing_algorithm"
        case .signingKeyUnavailable:
            "signing_key_unavailable"
        case .invalidSignature:
            "invalid_signature"
        case .invalidIssuer:
            "invalid_issuer"
        case .invalidAudience:
            "invalid_audience"
        case .expiredToken:
            "expired_token"
        case .invalidSubject:
            "invalid_subject"
        case .missingScopes:
            "missing_required_scopes"
        case .refreshTokenUnavailable:
            "refresh_token_unavailable"
        case .localCredentialAccessFailed:
            "local_credential_access_failed"
        case .identityChanged:
            "identity_changed"
        case .disconnectConfirmationRequired:
            "disconnect_confirmation_required"
        case .compensationFailed:
            "compensation_failed"
        }
    }
}

public enum EVEOAuthTokenError:
    String,
    Error,
    Equatable,
    Sendable
{
    case invalidRequest = "invalid_request"
    case invalidClient = "invalid_client"
    case invalidGrant = "invalid_grant"
    case unauthorizedClient = "unauthorized_client"
    case unsupportedGrantType = "unsupported_grant_type"
    case invalidScope = "invalid_scope"
}

extension EVEAuthenticationError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .invalidConfiguration:
            "Die EVE-SSO-Konfiguration ist ungültig."
        case .browserLaunchFailed:
            "Der Systembrowser konnte nicht für EVE SSO geöffnet werden."
        case .callbackUnavailable:
            "Der lokale SSO-Callback konnte nicht gestartet werden."
        case .callbackTimeout:
            "Die EVE-Anmeldung wurde nicht rechtzeitig abgeschlossen."
        case .callbackRejected:
            "Der lokale SSO-Callback wurde aus Sicherheitsgründen abgelehnt."
        case .authorizationDenied:
            "Die EVE-Anmeldung wurde abgebrochen oder nicht autorisiert."
        case .stateMismatch:
            "Die SSO-Antwort stimmt nicht mit der gestarteten Anmeldung überein."
        case .missingAuthorizationCode:
            "EVE SSO hat keinen Autorisierungscode geliefert."
        case .invalidDiscovery:
            "Die offiziellen EVE-SSO-Endpunkte konnten nicht sicher ermittelt werden."
        case .tokenExchangeFailed:
            "Der Tokenaustausch mit EVE SSO ist fehlgeschlagen."
        case .invalidTokenResponse:
            "EVE SSO hat eine ungültige Tokenantwort geliefert."
        case .unsupportedSigningAlgorithm:
            "Das Zugriffstoken verwendet einen nicht unterstützten Signaturalgorithmus."
        case .signingKeyUnavailable:
            "Für das Zugriffstoken wurde kein passender offizieller Signaturschlüssel gefunden."
        case .invalidSignature:
            "Die Signatur des EVE-Zugriffstokens ist ungültig."
        case .invalidIssuer:
            "Das Zugriffstoken stammt nicht vom erwarteten EVE-SSO-Aussteller."
        case .invalidAudience:
            "Das Zugriffstoken ist nicht für diese Anwendung bestimmt."
        case .expiredToken:
            "Das EVE-Zugriffstoken ist abgelaufen."
        case .invalidSubject:
            "Das Zugriffstoken enthält keine gültige EVE-Charakteridentität."
        case .missingScopes:
            "Das Zugriffstoken enthält nicht alle bestätigten Berechtigungen."
        case .refreshTokenUnavailable:
            "Für diesen Charakter ist kein erneuerbarer Zugang gespeichert."
        case .localCredentialAccessFailed:
            "Der lokale EVE-Zugang ist im macOS-Schlüsselbund nicht verfügbar."
        case .identityChanged:
            "Die erneuerte Anmeldung gehört zu einem anderen Charakter."
        case .disconnectConfirmationRequired:
            "Das Trennen des Charakters muss ausdrücklich bestätigt werden."
        case .compensationFailed:
            "Die lokale Kontoänderung konnte nach einem Teilfehler nicht vollständig zurückgesetzt werden."
        }
    }
}

public protocol EVEAuthorizationFlow: Sendable {
    func authorize(
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVEAuthorizationGrant

    func refresh(
        refreshToken: String,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVEAuthorizationGrant
}

public protocol EVEAuthorizationURLLaunching: Sendable {
    func openAuthorizationURL(_ url: URL) async throws
}

public protocol EVEOAuthCallbackSession: Sendable {
    func waitForAuthorizationCode(
        timeout: Duration
    ) async throws -> String

    func cancel()
}

public protocol EVEOAuthCallbackReceiving: Sendable {
    func prepare(
        redirectURI: URL,
        expectedState: String
    ) async throws -> any EVEOAuthCallbackSession
}

public protocol EVERefreshTokenVault: Sendable {
    func token(characterID: Int64) async throws -> String?
    func save(_ token: String, characterID: Int64) async throws
    func delete(characterID: Int64) async throws
}

public protocol EVECharacterAccountRepository: Sendable {
    func accounts() async throws -> [EVECharacterAccount]
    func account(characterID: Int64) async throws -> EVECharacterAccount?
    func save(_ account: EVECharacterAccount) async throws
    func delete(characterID: Int64) async throws
}

public protocol EVEAccountConnectionManaging: Sendable {
    func accounts() async throws -> [EVECharacterAccount]

    func connect(
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVECharacterAccount

    func refresh(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVECharacterAccount

    func reauthorize(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVECharacterAccount

    func disconnect(
        characterID: Int64,
        confirmation: EVEAccountDisconnectConfirmation
    ) async throws
}

public struct EVEAccountConnectionService:
    EVEAccountConnectionManaging,
    Sendable
{
    private let authorization: any EVEAuthorizationFlow
    private let vault: any EVERefreshTokenVault
    private let repository: any EVECharacterAccountRepository
    private let profileCache: (any ESICharacterProfileCaching)?
    private let personalDataStore: (any ESIPersonalDataPersisting)?
    private let walletDataStore: (any ESIWalletPersisting)?
    private let walletAssignmentStore:
        (any WalletProjectAssignmentRepository)?
    private let assetAvailabilityStore:
        (any ESIAssetAvailabilitySelectionRepository)?
    private let locationNameStore: (any ESILocationNamePersisting)?

    public init(
        authorization: any EVEAuthorizationFlow,
        vault: any EVERefreshTokenVault,
        repository: any EVECharacterAccountRepository,
        profileCache: (any ESICharacterProfileCaching)? = nil,
        personalDataStore: (any ESIPersonalDataPersisting)? = nil,
        walletDataStore: (any ESIWalletPersisting)? = nil,
        walletAssignmentStore:
            (any WalletProjectAssignmentRepository)? = nil,
        assetAvailabilityStore:
            (any ESIAssetAvailabilitySelectionRepository)? = nil,
        locationNameStore: (any ESILocationNamePersisting)? = nil
    ) {
        self.authorization = authorization
        self.vault = vault
        self.repository = repository
        self.profileCache = profileCache
        self.personalDataStore = personalDataStore
        self.walletDataStore = walletDataStore
        self.walletAssignmentStore = walletAssignmentStore
        self.assetAvailabilityStore = assetAvailabilityStore
        self.locationNameStore = locationNameStore
    }

    public func accounts() async throws -> [EVECharacterAccount] {
        try Task.checkCancellation()
        return try await repository.accounts()
    }

    public func connect(
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVECharacterAccount {
        try Task.checkCancellation()
        let grant = try await authorization.authorize(
            configuration: configuration
        )
        return try await persist(
            grant: grant,
            authorizedScopes: configuration.scopes,
            previousAccount: try await repository.account(
                characterID: grant.identity.characterID
            )
        )
    }

    public func refresh(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVECharacterAccount {
        try Task.checkCancellation()
        guard let previousToken = try await storedToken(
            characterID: characterID
        ) else {
            throw EVEAuthenticationError.refreshTokenUnavailable
        }
        let previousAccount = try await repository.account(
            characterID: characterID
        )
        let grant = try await authorization.refresh(
            refreshToken: previousToken,
            configuration: configuration
        )
        guard grant.identity.characterID == characterID else {
            throw EVEAuthenticationError.identityChanged
        }
        return try await persist(
            grant: grant,
            authorizedScopes: configuration.scopes,
            previousAccount: previousAccount
        )
    }

    public func reauthorize(
        characterID: Int64,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVECharacterAccount {
        try Task.checkCancellation()
        guard let previousAccount = try await repository.account(
            characterID: characterID
        ) else {
            throw EVEAuthenticationError.refreshTokenUnavailable
        }
        let grant = try await authorization.authorize(
            configuration: configuration
        )
        guard grant.identity.characterID == characterID else {
            throw EVEAuthenticationError.identityChanged
        }
        return try await persist(
            grant: grant,
            authorizedScopes: configuration.scopes,
            previousAccount: previousAccount
        )
    }

    public func disconnect(
        characterID: Int64,
        confirmation: EVEAccountDisconnectConfirmation
    ) async throws {
        guard case .confirmed = confirmation else {
            throw EVEAuthenticationError.disconnectConfirmationRequired
        }
        try Task.checkCancellation()
        let previousAccount = try await repository.account(
            characterID: characterID
        )
        let previousProfile = try await profileCache?.snapshot(
            characterID: characterID
        )
        let previousPersonalData = try await personalDataStore?.snapshot(
            characterID: characterID
        )
        let previousWallet = try await walletDataStore?.snapshot(
            characterID: characterID
        )
        let previousAssignments =
            try await walletAssignmentStore?.assignments(
                characterID: characterID
            ) ?? []
        let previousAssetSelections =
            try await assetAvailabilityStore?.selections(
                characterID: characterID
            ) ?? []
        let previousLocationNames = try await locationNameStore?.cache(
            characterID: characterID
        )
        try await repository.delete(characterID: characterID)
        var personalDataWasDeleted = false
        var walletWasDeleted = false
        var assignmentsWereDeleted = false
        var assetSelectionsWereDeleted = false
        var locationNamesWereDeleted = false
        do {
            try await profileCache?.delete(characterID: characterID)
            try await personalDataStore?.delete(characterID: characterID)
            personalDataWasDeleted = personalDataStore != nil
            try await walletDataStore?.delete(characterID: characterID)
            walletWasDeleted = walletDataStore != nil
            try await walletAssignmentStore?.delete(
                characterID: characterID
            )
            assignmentsWereDeleted = walletAssignmentStore != nil
            try await assetAvailabilityStore?.delete(
                characterID: characterID
            )
            assetSelectionsWereDeleted = assetAvailabilityStore != nil
            try await locationNameStore?.delete(
                characterID: characterID
            )
            locationNamesWereDeleted = locationNameStore != nil
            try await deleteStoredToken(characterID: characterID)
        } catch {
            do {
                if let previousAccount {
                    try await repository.save(previousAccount)
                }
                if let previousProfile {
                    try await profileCache?.save(previousProfile)
                }
                if personalDataWasDeleted, let previousPersonalData {
                    try await personalDataStore?.save(
                        previousPersonalData,
                        expectedRevision: nil
                    )
                }
                if walletWasDeleted, let previousWallet {
                    try await walletDataStore?.save(
                        previousWallet,
                        expectedRevision: nil
                    )
                }
                if assignmentsWereDeleted {
                    try await walletAssignmentStore?.restore(
                        previousAssignments
                    )
                }
                if assetSelectionsWereDeleted {
                    try await assetAvailabilityStore?.restore(
                        previousAssetSelections
                    )
                }
                if locationNamesWereDeleted,
                   let previousLocationNames {
                    try await locationNameStore?.save(
                        previousLocationNames
                    )
                }
            } catch {
                throw EVEAuthenticationError.compensationFailed
            }
            throw error
        }
    }

    private func persist(
        grant: EVEAuthorizationGrant,
        authorizedScopes: [String],
        previousAccount: EVECharacterAccount?
    ) async throws -> EVECharacterAccount {
        let identity = grant.identity
        let account = EVECharacterAccount(
            characterID: identity.characterID,
            name: identity.characterName,
            accountLabel: previousAccount?.accountLabel ?? "EVE Online",
            syncState: "Veraltet",
            lastSync: previousAccount?.lastSync,
            createdAt: previousAccount?.createdAt ?? Date(),
            authorizedScopes: authorizedScopes,
            authorizationUpdatedAt: Date()
        )

        try await repository.save(account)
        do {
            try await saveStoredToken(
                grant.refreshToken,
                characterID: identity.characterID
            )
            return account
        } catch {
            do {
                if let previousAccount {
                    try await repository.save(previousAccount)
                } else {
                    try await repository.delete(
                        characterID: identity.characterID
                    )
                }
            } catch {
                throw EVEAuthenticationError.compensationFailed
            }
            throw error
        }
    }

    private func storedToken(
        characterID: Int64
    ) async throws -> String? {
        do {
            return try await vault.token(characterID: characterID)
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw EVEAuthenticationError.localCredentialAccessFailed
        }
    }

    private func saveStoredToken(
        _ token: String,
        characterID: Int64
    ) async throws {
        do {
            try await vault.save(token, characterID: characterID)
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw EVEAuthenticationError.localCredentialAccessFailed
        }
    }

    private func deleteStoredToken(
        characterID: Int64
    ) async throws {
        do {
            try await vault.delete(characterID: characterID)
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw EVEAuthenticationError.localCredentialAccessFailed
        }
    }
}
