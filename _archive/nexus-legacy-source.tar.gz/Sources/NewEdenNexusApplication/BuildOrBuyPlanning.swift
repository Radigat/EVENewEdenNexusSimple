import Foundation
import NewEdenNexusDomain

public struct BuildOrBuyDecisionDraft: Equatable, Sendable {
    public let typeID: Int64
    public let choice: BuildOrBuyChoice

    public init(typeID: Int64, choice: BuildOrBuyChoice) {
        self.typeID = typeID
        self.choice = choice
    }
}

public struct BuildOrBuyDecisionVersion: Equatable, Sendable {
    public let id: UUID
    public let updatedAt: Date

    public init(id: UUID, updatedAt: Date) {
        self.id = id
        self.updatedAt = updatedAt
    }
}

public struct ESIAssetAvailabilitySelectionVersion:
    Equatable,
    Sendable
{
    public let id: UUID
    public let sourceRevision: UUID
    public let updatedAt: Date

    public init(id: UUID, sourceRevision: UUID, updatedAt: Date) {
        self.id = id
        self.sourceRevision = sourceRevision
        self.updatedAt = updatedAt
    }
}

public struct BuildOrBuyPlanSourceVersion: Equatable, Sendable {
    public let projectUpdatedAt: Date
    public let graphID: UUID
    public let graphUpdatedAt: Date
    public let inventory: InventoryAvailabilitySourceVersion
    public let safetyPolicies: [SafetyStockPolicyVersion]
    public let reservations: [StockReservationVersion]
    public let decisions: [BuildOrBuyDecisionVersion]
    public let esiAssetSelection: ESIAssetAvailabilitySelectionVersion?

    public init(
        projectUpdatedAt: Date,
        graphID: UUID,
        graphUpdatedAt: Date,
        inventory: InventoryAvailabilitySourceVersion,
        safetyPolicies: [SafetyStockPolicyVersion],
        reservations: [StockReservationVersion],
        decisions: [BuildOrBuyDecisionVersion],
        esiAssetSelection: ESIAssetAvailabilitySelectionVersion? = nil
    ) {
        self.projectUpdatedAt = projectUpdatedAt
        self.graphID = graphID
        self.graphUpdatedAt = graphUpdatedAt
        self.inventory = inventory
        self.safetyPolicies = safetyPolicies
        self.reservations = reservations
        self.decisions = decisions
        self.esiAssetSelection = esiAssetSelection
    }
}

public struct BuildOrBuyPlanPreview: Equatable, Sendable {
    public let projectID: UUID
    public let calculatedAt: Date
    public let sourceVersion: BuildOrBuyPlanSourceVersion
    public let storedDecisions: [BuildOrBuyDecisionSnapshot]
    public let proposedDecisions: [BuildOrBuyDecisionSnapshot]
    public let staleDecisionTypeIDs: [Int64]
    public let plan: BuildOrBuyPlan
}

public enum BuildOrBuyPlanningError: Error, Equatable, Sendable {
    case projectNotFound(UUID)
    case archivedProject(UUID)
    case graphRequired(UUID)
    case staleGraph(UUID)
    case duplicateDecisionTypeID(Int64)
    case invalidDecisionTypeID(Int64)
    case missingInventionRecipe(ProductionGraphNodeID)
    case ambiguousInventionRecipe(ProductionGraphNodeID)
    case unresolvedInventionMaterial(
        nodeID: ProductionGraphNodeID,
        typeID: Int64
    )
    case inconsistentInventionMaterials(ProductionGraphNodeID)
    case catalogVersionChanged
    case catalogItemMissing(Int64)
    case unknownInventoryLocation(UUID)
    case confirmationRequired
    case staleDecisions([Int64])
    case stalePreview
    case calculationFailed
    case persistenceFailure
}

public enum BuildOrBuyDecisionRepositoryError:
    Error,
    Equatable,
    Sendable
{
    case staleState
}

public protocol BuildOrBuyDecisionRepository: Sendable {
    func decisions(projectID: UUID) async throws
        -> [BuildOrBuyDecisionSnapshot]

    func replaceDecisions(
        _ decisions: [BuildOrBuyDecisionSnapshot],
        projectID: UUID,
        expectedVersions: [BuildOrBuyDecisionVersion]
    ) async throws
}

public protocol BuildOrBuyPlanning: Sendable {
    func preview(
        projectID: UUID,
        decisions: [BuildOrBuyDecisionDraft]?
    ) async throws -> BuildOrBuyPlanPreview

    func apply(
        _ preview: BuildOrBuyPlanPreview,
        confirmed: Bool
    ) async throws -> BuildOrBuyPlanPreview
}

public struct BuildOrBuyPlanningService:
    BuildOrBuyPlanning,
    Sendable
{
    private let projects: any ProductionProjectRepository
    private let graphs: any ProductionGraphRepository
    private let decisions: any BuildOrBuyDecisionRepository
    private let inventory: any InventoryAvailabilityRepository
    private let policies: any SafetyStockPolicyRepository
    private let reservations: any ProjectReservationRepository
    private let recipes: any RecipeCandidateReading
    private let catalog: any ItemBlueprintCatalogReading
    private let esiAssets: (any ESIAssetAvailabilityManaging)?
    private let availabilityCalculator: InventoryAvailabilityCalculator
    private let safetyCalculator: SafetyStockCalculator
    private let reservationCalculator: ProjectReservationCalculator
    private let planCalculator: BuildOrBuyPlanCalculator
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        projects: any ProductionProjectRepository,
        graphs: any ProductionGraphRepository,
        decisions: any BuildOrBuyDecisionRepository,
        inventory: any InventoryAvailabilityRepository,
        policies: any SafetyStockPolicyRepository,
        reservations: any ProjectReservationRepository,
        recipes: any RecipeCandidateReading,
        catalog: any ItemBlueprintCatalogReading,
        esiAssets: (any ESIAssetAvailabilityManaging)? = nil,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.projects = projects
        self.graphs = graphs
        self.decisions = decisions
        self.inventory = inventory
        self.policies = policies
        self.reservations = reservations
        self.recipes = recipes
        self.catalog = catalog
        self.esiAssets = esiAssets
        self.availabilityCalculator = .init()
        self.safetyCalculator = .init()
        self.reservationCalculator = .init()
        self.planCalculator = .init()
        self.now = now
        self.makeID = makeID
    }

    public func preview(
        projectID: UUID,
        decisions drafts: [BuildOrBuyDecisionDraft]? = nil
    ) async throws -> BuildOrBuyPlanPreview {
        try await makePreview(projectID: projectID, drafts: drafts)
    }

    public func apply(
        _ preview: BuildOrBuyPlanPreview,
        confirmed: Bool
    ) async throws -> BuildOrBuyPlanPreview {
        guard confirmed else {
            throw BuildOrBuyPlanningError.confirmationRequired
        }
        guard preview.staleDecisionTypeIDs.isEmpty else {
            throw BuildOrBuyPlanningError.staleDecisions(
                preview.staleDecisionTypeIDs
            )
        }
        try Task.checkCancellation()
        let drafts = preview.proposedDecisions.map {
            BuildOrBuyDecisionDraft(typeID: $0.typeID, choice: $0.choice)
        }
        let current = try await makePreview(
            projectID: preview.projectID,
            drafts: drafts
        )
        guard current.sourceVersion == preview.sourceVersion else {
            throw BuildOrBuyPlanningError.stalePreview
        }
        do {
            try await decisions.replaceDecisions(
                preview.proposedDecisions,
                projectID: preview.projectID,
                expectedVersions: preview.sourceVersion.decisions
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch BuildOrBuyDecisionRepositoryError.staleState {
            throw BuildOrBuyPlanningError.stalePreview
        } catch {
            throw BuildOrBuyPlanningError.persistenceFailure
        }
        return try await makePreview(
            projectID: preview.projectID,
            drafts: nil
        )
    }

    private func makePreview(
        projectID: UUID,
        drafts: [BuildOrBuyDecisionDraft]?
    ) async throws -> BuildOrBuyPlanPreview {
        try Task.checkCancellation()
        guard let project = try await projects.project(id: projectID) else {
            throw BuildOrBuyPlanningError.projectNotFound(projectID)
        }
        guard project.status != .archived else {
            throw BuildOrBuyPlanningError.archivedProject(projectID)
        }
        guard let graph = try await graphs.graph(projectID: projectID) else {
            throw BuildOrBuyPlanningError.graphRequired(projectID)
        }
        guard !ProductionGraphFreshness.isStale(graph, for: project) else {
            throw BuildOrBuyPlanningError.staleGraph(projectID)
        }

        async let storedDecisionTask = decisions.decisions(
            projectID: projectID
        )
        async let inventoryConfigurationTask =
            inventory.availabilityConfiguration(projectID: projectID)
        async let inventoryStateTask = inventory.availabilityState()
        async let esiSelectionTask = esiAssets?.activeSelection(
            projectID: projectID
        )
        let inventionMaterials = try await loadInventionMaterials(
            graph: graph
        )
        let (
            storedDecisions,
            storedConfiguration,
            inventoryState,
            esiSelection
        ) = try await (
            storedDecisionTask,
            inventoryConfigurationTask,
            inventoryStateTask,
            esiSelectionTask
        )
        let buildableTypeIDs = Set(
            graph.nodes.filter {
                $0.kind == .intermediate && $0.recipe != nil
            }.map(\.typeID)
        )
        let proposal = try proposedDecisions(
            projectID: projectID,
            stored: storedDecisions,
            drafts: drafts,
            buildableTypeIDs: buildableTypeIDs
        )
        let stale = proposal.filter {
            !buildableTypeIDs.contains($0.typeID)
        }.map(\.typeID).sorted()
        let validBuyTypeIDs = Set(
            proposal.filter {
                $0.choice == .buy
                    && buildableTypeIDs.contains($0.typeID)
            }.map(\.typeID)
        )
        let typeNames = try await potentialTypeNames(
            graph: graph,
            inventionMaterials: inventionMaterials
        )
        let typeIDs = typeNames.keys.sorted()
        let configuration = try makeConfiguration(
            projectID: projectID,
            stored: storedConfiguration
        )
        try validateLocations(
            configuration: configuration,
            state: inventoryState
        )
        let probes = typeIDs.map {
            ProductionGraphMaterialLine(
                typeID: $0,
                name: typeNames[$0] ?? String($0),
                totalQuantity: Int64.max,
                occurrences: []
            )
        }
        let manualAvailability: InventoryAvailabilityCalculation
        do {
            manualAvailability = try availabilityCalculator.calculate(
                requirements: probes,
                locations: inventoryState.locations,
                stocks: inventoryState.stocks,
                configuration: configuration
            )
        } catch {
            throw BuildOrBuyPlanningError.calculationFailed
        }
        let availability: InventoryAvailabilityCalculation
        do {
            availability = try ESIAssetAvailabilityAugmenter().adding(
                esiSelection,
                to: manualAvailability
            )
        } catch {
            throw BuildOrBuyPlanningError.calculationFailed
        }
        let storedPolicies = try await policies.policies(typeIDs: typeIDs)
        let safety: SafetyStockCalculation
        do {
            safety = try safetyCalculator.calculate(
                availability: availability,
                policies: storedPolicies
            )
        } catch {
            throw BuildOrBuyPlanningError.calculationFailed
        }
        let storedReservations = try await reservations.reservations(
            typeIDs: typeIDs
        )
        let reservation: ProjectReservationCalculation
        do {
            reservation = try reservationCalculator.calculate(
                projectID: projectID,
                safetyStock: safety,
                reservations: storedReservations,
                at: now()
            )
        } catch {
            throw BuildOrBuyPlanningError.calculationFailed
        }
        let availableByTypeID = Dictionary(
            uniqueKeysWithValues: reservation.lines.map {
                (
                    $0.safetyStock.availability.typeID,
                    $0.freeBeforeCurrentProjectQuantity
                )
            }
        )
        let plan: BuildOrBuyPlan
        do {
            plan = try planCalculator.calculate(
                graph: graph,
                buyTypeIDs: validBuyTypeIDs,
                availableQuantityByTypeID: availableByTypeID,
                inventionMaterialsByNodeID: inventionMaterials
            )
        } catch {
            throw BuildOrBuyPlanningError.calculationFailed
        }
        let timestamp = now()
        let inventorySource = InventoryAvailabilitySourceVersion(
            projectUpdatedAt: project.updatedAt,
            graphID: graph.id,
            graphUpdatedAt: graph.updatedAt,
            locations: inventoryState.locations.map {
                .init(
                    id: $0.id,
                    updatedAt: $0.updatedAt,
                    isArchived: $0.isArchived
                )
            }.sorted { $0.id.uuidString < $1.id.uuidString },
            stocks: inventoryState.stocks.map {
                .init(
                    id: $0.id,
                    locationID: $0.locationID,
                    typeID: $0.typeID,
                    quantity: $0.quantity,
                    updatedAt: $0.updatedAt
                )
            }.sorted { $0.id.uuidString < $1.id.uuidString },
            storedConfigurationUpdatedAt: storedConfiguration?.updatedAt
        )
        return BuildOrBuyPlanPreview(
            projectID: projectID,
            calculatedAt: timestamp,
            sourceVersion: .init(
                projectUpdatedAt: project.updatedAt,
                graphID: graph.id,
                graphUpdatedAt: graph.updatedAt,
                inventory: inventorySource,
                safetyPolicies: typeIDs.map { typeID in
                    SafetyStockPolicyVersion(
                        typeID: typeID,
                        updatedAt: storedPolicies.first {
                            $0.typeID == typeID
                        }?.updatedAt
                    )
                },
                reservations: storedReservations.map {
                    StockReservationVersion(
                        id: $0.id,
                        updatedAt: $0.updatedAt
                    )
                }.sorted { $0.id.uuidString < $1.id.uuidString },
                decisions: storedDecisions.map {
                    BuildOrBuyDecisionVersion(
                        id: $0.id,
                        updatedAt: $0.updatedAt
                    )
                }.sorted { $0.id.uuidString < $1.id.uuidString },
                esiAssetSelection: esiSelection.map {
                    ESIAssetAvailabilitySelectionVersion(
                        id: $0.id,
                        sourceRevision: $0.sourceRevision,
                        updatedAt: $0.updatedAt
                    )
                }
            ),
            storedDecisions: storedDecisions.sorted {
                $0.typeID < $1.typeID
            },
            proposedDecisions: proposal.sorted {
                $0.typeID < $1.typeID
            },
            staleDecisionTypeIDs: stale,
            plan: plan
        )
    }

    private func proposedDecisions(
        projectID: UUID,
        stored: [BuildOrBuyDecisionSnapshot],
        drafts: [BuildOrBuyDecisionDraft]?,
        buildableTypeIDs: Set<Int64>
    ) throws -> [BuildOrBuyDecisionSnapshot] {
        guard let drafts else { return stored }
        let storedByTypeID = Dictionary(
            uniqueKeysWithValues: stored.map { ($0.typeID, $0) }
        )
        var seen: Set<Int64> = []
        let timestamp = now()
        return try drafts.compactMap { draft in
            guard draft.typeID > 0,
                  buildableTypeIDs.contains(draft.typeID) else {
                throw BuildOrBuyPlanningError
                    .invalidDecisionTypeID(draft.typeID)
            }
            guard seen.insert(draft.typeID).inserted else {
                throw BuildOrBuyPlanningError
                    .duplicateDecisionTypeID(draft.typeID)
            }
            guard draft.choice == .buy else { return nil }
            let current = storedByTypeID[draft.typeID]
            return BuildOrBuyDecisionSnapshot(
                id: current?.id ?? makeID(),
                projectID: projectID,
                typeID: draft.typeID,
                choice: .buy,
                createdAt: current?.createdAt ?? timestamp,
                updatedAt: timestamp
            )
        }
    }

    private func loadInventionMaterials(
        graph: ProductionGraphSnapshot
    ) async throws
        -> [ProductionGraphNodeID: [BuildOrBuyInventionMaterial]]
    {
        let expected = CatalogDataVersion(
            buildNumber: graph.catalogBuildNumber,
            contentSHA256: graph.catalogContentSHA256
        )
        var result:
            [ProductionGraphNodeID: [BuildOrBuyInventionMaterial]] = [:]
        for node in graph.nodes.sorted(by: {
            $0.id.rawValue < $1.id.rawValue
        }) {
            guard let recipe = node.recipe,
                  let invention = recipe.invention else { continue }
            let page = try await recipes.recipeCandidates(
                productTypeID: recipe.blueprintTypeID,
                activity: .invention,
                blueprintTypeID: invention.sourceBlueprintTypeID
            )
            guard page.version == expected else {
                throw BuildOrBuyPlanningError.catalogVersionChanged
            }
            guard !page.candidates.isEmpty else {
                throw BuildOrBuyPlanningError
                    .missingInventionRecipe(node.id)
            }
            guard page.candidates.count == 1,
                  let candidate = page.candidates.first else {
                throw BuildOrBuyPlanningError
                    .ambiguousInventionRecipe(node.id)
            }
            let expectedIDs = invention.materialTypeIDs.sorted()
            guard candidate.materials.map(\.typeID).sorted()
                    == expectedIDs else {
                throw BuildOrBuyPlanningError
                    .inconsistentInventionMaterials(node.id)
            }
            var materials: [BuildOrBuyInventionMaterial] = []
            var seen: Set<Int64> = []
            for material in candidate.materials {
                guard material.typeIsResolved,
                      material.quantity > 0 else {
                    throw BuildOrBuyPlanningError
                        .unresolvedInventionMaterial(
                            nodeID: node.id,
                            typeID: material.typeID
                        )
                }
                guard seen.insert(material.typeID).inserted else {
                    throw BuildOrBuyPlanningError
                        .inconsistentInventionMaterials(node.id)
                }
                let item = try await catalog.item(typeID: material.typeID)
                guard case let .found(details) = item else {
                    throw BuildOrBuyPlanningError
                        .catalogItemMissing(material.typeID)
                }
                guard details.version == expected else {
                    throw BuildOrBuyPlanningError.catalogVersionChanged
                }
                materials.append(
                    .init(
                        typeID: material.typeID,
                        name: details.summary.name,
                        quantityPerSuccessfulCopy: material.quantity
                    )
                )
            }
            result[node.id] = materials.sorted { $0.typeID < $1.typeID }
        }
        return result
    }

    private func potentialTypeNames(
        graph: ProductionGraphSnapshot,
        inventionMaterials:
            [ProductionGraphNodeID: [BuildOrBuyInventionMaterial]]
    ) async throws -> [Int64: String] {
        var result: [Int64: String] = [:]
        for node in graph.nodes {
            if let existing = result[node.typeID],
               existing != node.name {
                throw BuildOrBuyPlanningError.calculationFailed
            }
            result[node.typeID] = node.name
        }
        for material in inventionMaterials.values.flatMap({ $0 }) {
            if let existing = result[material.typeID],
               existing != material.name {
                throw BuildOrBuyPlanningError.calculationFailed
            }
            result[material.typeID] = material.name
        }
        return result
    }

    private func makeConfiguration(
        projectID: UUID,
        stored: InventoryAvailabilityConfigurationSnapshot?
    ) throws -> InventoryAvailabilityConfigurationSnapshot {
        if let stored { return stored }
        let timestamp = now()
        return try InventoryAvailabilityConfigurationSnapshot(
            id: makeID(),
            projectID: projectID,
            mode: .allActiveLocations,
            includedLocationIDs: [],
            excludedTypeIDs: [],
            caps: [],
            createdAt: timestamp,
            updatedAt: timestamp
        )
    }

    private func validateLocations(
        configuration: InventoryAvailabilityConfigurationSnapshot,
        state: InventoryAvailabilityState
    ) throws {
        let known = Set(state.locations.map(\.id))
        for id in configuration.includedLocationIDs
        where !known.contains(id) {
            throw BuildOrBuyPlanningError.unknownInventoryLocation(id)
        }
    }
}
