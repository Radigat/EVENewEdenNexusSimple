import Foundation
import NewEdenNexusDomain

public enum ProductionProjectListScope: String, CaseIterable, Sendable {
    case current
    case archived
    case all
}

public struct ProductionProjectDraft: Equatable, Sendable {
    public let name: String
    public let target: ProductionTargetSelection?
    public let targetQuantity: Int
    public let priority: Int
    public let targetDate: Date?
    public let notes: String
    public let materialEfficiency: Int

    public init(
        name: String,
        target: ProductionTargetSelection?,
        targetQuantity: Int,
        priority: Int,
        targetDate: Date?,
        notes: String,
        materialEfficiency: Int = 0
    ) {
        self.name = name
        self.target = target
        self.targetQuantity = targetQuantity
        self.priority = priority
        self.targetDate = targetDate
        self.notes = notes
        self.materialEfficiency = materialEfficiency
    }

    public init(project: ProductionProjectSnapshot) {
        self.init(
            name: project.name,
            target: project.target,
            targetQuantity: project.targetQuantity,
            priority: project.priority,
            targetDate: project.targetDate,
            notes: project.notes,
            materialEfficiency: project.materialEfficiency
        )
    }
}

public enum ProductionProjectLifecycleError:
    Error,
    Equatable,
    Sendable
{
    case projectNotFound(UUID)
    case archivedProjectIsReadOnly(UUID)
    case invalidStatusTransition(
        projectID: UUID,
        from: ProjectStatus,
        to: ProjectStatus
    )
    case targetSelectionRequired
}

public enum ProductionProjectStatusPolicy {
    public static func allowedTransitions(
        from status: ProjectStatus
    ) -> [ProjectStatus] {
        switch status {
        case .planning:
            [.procurement, .ready, .archived]
        case .procurement:
            [.planning, .ready, .archived]
        case .ready:
            [.planning, .procurement, .active, .archived]
        case .active:
            [.ready, .completed, .archived]
        case .completed:
            [.active, .archived]
        case .archived:
            [.planning]
        }
    }

    public static func canTransition(
        from source: ProjectStatus,
        to destination: ProjectStatus
    ) -> Bool {
        source == destination
            || allowedTransitions(from: source).contains(destination)
    }
}

public protocol ProductionProjectLifecycleManaging: Sendable {
    func projects(
        scope: ProductionProjectListScope
    ) async throws -> [ProductionProjectSnapshot]

    func project(id: UUID) async throws -> ProductionProjectSnapshot

    func create(
        draft: ProductionProjectDraft
    ) async throws -> ProductionProjectSnapshot

    func update(
        id: UUID,
        draft: ProductionProjectDraft
    ) async throws -> ProductionProjectSnapshot

    func transition(
        id: UUID,
        to status: ProjectStatus
    ) async throws -> ProductionProjectSnapshot

    func duplicate(id: UUID) async throws -> ProductionProjectSnapshot

    func archive(id: UUID) async throws -> ProductionProjectSnapshot

    func restore(id: UUID) async throws -> ProductionProjectSnapshot
}

public struct ProductionProjectLifecycleService:
    ProductionProjectLifecycleManaging,
    Sendable
{
    private let repository: any ProductionProjectRepository
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any ProductionProjectRepository,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.repository = repository
        self.now = now
        self.makeID = makeID
    }

    public func projects(
        scope: ProductionProjectListScope
    ) async throws -> [ProductionProjectSnapshot] {
        try Task.checkCancellation()
        let stored = try await repository.projects()
        try Task.checkCancellation()
        switch scope {
        case .current:
            return stored.filter { $0.status != .archived }
        case .archived:
            return stored.filter { $0.status == .archived }
        case .all:
            return stored
        }
    }

    public func project(id: UUID) async throws -> ProductionProjectSnapshot {
        try Task.checkCancellation()
        guard let project = try await repository.project(id: id) else {
            throw ProductionProjectLifecycleError.projectNotFound(id)
        }
        try Task.checkCancellation()
        return project
    }

    public func create(
        draft: ProductionProjectDraft
    ) async throws -> ProductionProjectSnapshot {
        try Task.checkCancellation()
        guard let target = draft.target else {
            throw ProductionProjectLifecycleError.targetSelectionRequired
        }
        let timestamp = now()
        let project = try ProductionProjectSnapshot(
            id: makeID(),
            name: draft.name,
            productName: target.productName,
            targetQuantity: draft.targetQuantity,
            status: .planning,
            priority: draft.priority,
            targetDate: draft.targetDate,
            notes: draft.notes,
            createdAt: timestamp,
            updatedAt: timestamp,
            target: target,
            materialEfficiency: draft.materialEfficiency
        )
        try Task.checkCancellation()
        try await repository.save(project)
        return project
    }

    public func update(
        id: UUID,
        draft: ProductionProjectDraft
    ) async throws -> ProductionProjectSnapshot {
        let stored = try await project(id: id)
        guard stored.status != .archived else {
            throw ProductionProjectLifecycleError
                .archivedProjectIsReadOnly(id)
        }
        guard let target = draft.target else {
            throw ProductionProjectLifecycleError.targetSelectionRequired
        }
        let updated = try ProductionProjectSnapshot(
            id: stored.id,
            name: draft.name,
            productName: target.productName,
            targetQuantity: draft.targetQuantity,
            status: stored.status,
            priority: draft.priority,
            targetDate: draft.targetDate,
            notes: draft.notes,
            createdAt: stored.createdAt,
            updatedAt: now(),
            target: target,
            materialEfficiency: draft.materialEfficiency
        )
        try Task.checkCancellation()
        try await repository.save(updated)
        return updated
    }

    public func transition(
        id: UUID,
        to status: ProjectStatus
    ) async throws -> ProductionProjectSnapshot {
        let stored = try await project(id: id)
        guard stored.status != status else {
            return stored
        }
        guard ProductionProjectStatusPolicy.canTransition(
            from: stored.status,
            to: status
        ) else {
            throw ProductionProjectLifecycleError.invalidStatusTransition(
                projectID: id,
                from: stored.status,
                to: status
            )
        }
        let updated = try snapshot(
            copying: stored,
            status: status,
            updatedAt: now()
        )
        try Task.checkCancellation()
        try await repository.save(updated)
        return updated
    }

    public func duplicate(
        id: UUID
    ) async throws -> ProductionProjectSnapshot {
        let stored = try await project(id: id)
        let timestamp = now()
        let duplicate = try ProductionProjectSnapshot(
            id: makeID(),
            name: "\(stored.name) – Kopie",
            productName: stored.productName,
            targetQuantity: stored.targetQuantity,
            status: .planning,
            priority: stored.priority,
            targetDate: stored.targetDate,
            notes: stored.notes,
            createdAt: timestamp,
            updatedAt: timestamp,
            target: stored.target,
            materialEfficiency: stored.materialEfficiency
        )
        try Task.checkCancellation()
        try await repository.save(duplicate)
        return duplicate
    }

    public func archive(
        id: UUID
    ) async throws -> ProductionProjectSnapshot {
        try await transition(id: id, to: .archived)
    }

    public func restore(
        id: UUID
    ) async throws -> ProductionProjectSnapshot {
        let stored = try await project(id: id)
        guard stored.status == .archived else {
            throw ProductionProjectLifecycleError.invalidStatusTransition(
                projectID: id,
                from: stored.status,
                to: .planning
            )
        }
        return try await transition(id: id, to: .planning)
    }

    private func snapshot(
        copying project: ProductionProjectSnapshot,
        status: ProjectStatus,
        updatedAt: Date
    ) throws -> ProductionProjectSnapshot {
        try ProductionProjectSnapshot(
            id: project.id,
            name: project.name,
            productName: project.productName,
            targetQuantity: project.targetQuantity,
            status: status,
            priority: project.priority,
            targetDate: project.targetDate,
            notes: project.notes,
            createdAt: project.createdAt,
            updatedAt: updatedAt,
            target: project.target,
            materialEfficiency: project.materialEfficiency
        )
    }
}
