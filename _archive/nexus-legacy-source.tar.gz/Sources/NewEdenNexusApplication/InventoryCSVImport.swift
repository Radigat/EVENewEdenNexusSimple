import Foundation
import NewEdenNexusDomain

public enum InventoryCSVEncodingOption: String, CaseIterable, Sendable {
    case automatic
    case utf8
    case windows1252
    case isoLatin1
}

public enum InventoryCSVDetectedEncoding: String, Codable, Sendable {
    case utf8
    case utf16LittleEndian
    case utf16BigEndian
    case windows1252
    case isoLatin1
}

public enum InventoryCSVDelimiterOption: String, CaseIterable, Sendable {
    case automatic
    case comma
    case semicolon
    case tab
}

public enum InventoryCSVDetectedDelimiter: String, Codable, Sendable {
    case comma
    case semicolon
    case tab
}

public enum InventoryCSVQuantityFormat: String, CaseIterable, Sendable {
    case integer
    case decimalComma
    case decimalPoint
}

public struct InventoryCSVParserOptions: Equatable, Sendable {
    public let encoding: InventoryCSVEncodingOption
    public let delimiter: InventoryCSVDelimiterOption

    public init(
        encoding: InventoryCSVEncodingOption = .automatic,
        delimiter: InventoryCSVDelimiterOption = .automatic
    ) {
        self.encoding = encoding
        self.delimiter = delimiter
    }
}

public struct InventoryCSVImportSource: Equatable, Sendable {
    public let displayName: String
    public let data: Data
    public let sha256: String

    public init(displayName: String, data: Data, sha256: String) {
        self.displayName = displayName
            .trimmingCharacters(in: .whitespacesAndNewlines)
        self.data = data
        self.sha256 = sha256.lowercased()
    }
}

public struct InventoryCSVParsedRow: Equatable, Sendable {
    public let rowNumber: Int
    public let fields: [String]

    public init(rowNumber: Int, fields: [String]) {
        self.rowNumber = rowNumber
        self.fields = fields
    }
}

public struct InventoryCSVParsedDocument: Equatable, Sendable {
    public let headers: [String]
    public let rows: [InventoryCSVParsedRow]
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter

    public init(
        headers: [String],
        rows: [InventoryCSVParsedRow],
        encoding: InventoryCSVDetectedEncoding,
        delimiter: InventoryCSVDetectedDelimiter
    ) {
        self.headers = headers
        self.rows = rows
        self.encoding = encoding
        self.delimiter = delimiter
    }
}

public protocol InventoryCSVParsing: Sendable {
    func parse(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions
    ) throws -> InventoryCSVParsedDocument
}

public protocol InventoryCSVFileReading: Sendable {
    func read(url: URL) throws -> InventoryCSVImportSource
}

public struct InventoryCSVInspection: Equatable, Sendable {
    public let sourceName: String
    public let sourceSHA256: String
    public let headers: [String]
    public let dataRowCount: Int
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter

    public init(
        sourceName: String,
        sourceSHA256: String,
        headers: [String],
        dataRowCount: Int,
        encoding: InventoryCSVDetectedEncoding,
        delimiter: InventoryCSVDetectedDelimiter
    ) {
        self.sourceName = sourceName
        self.sourceSHA256 = sourceSHA256
        self.headers = headers
        self.dataRowCount = dataRowCount
        self.encoding = encoding
        self.delimiter = delimiter
    }
}

public struct InventoryCSVColumnMapping: Equatable, Sendable {
    public let typeIDColumn: Int
    public let quantityColumn: Int
    public let itemNameColumn: Int?

    public init(
        typeIDColumn: Int,
        quantityColumn: Int,
        itemNameColumn: Int? = nil
    ) {
        self.typeIDColumn = typeIDColumn
        self.quantityColumn = quantityColumn
        self.itemNameColumn = itemNameColumn
    }
}

public enum InventoryCSVRowIssueCode: String, Codable, Sendable {
    case wrongColumnCount
    case invalidTypeID
    case invalidQuantity
    case duplicateTypeID
    case itemNotFound
    case unpublishedItem
    case itemNameMismatch
}

public struct InventoryCSVRowIssue: Equatable, Codable, Sendable {
    public let code: InventoryCSVRowIssueCode
    public let message: String

    public init(code: InventoryCSVRowIssueCode, message: String) {
        self.code = code
        self.message = message
    }
}

public enum InventoryCSVPreviewState: String, Codable, Sendable {
    case insert
    case unchanged
    case replacementRequired
    case invalid
}

public struct InventoryCSVPreviewLine: Identifiable, Equatable, Sendable {
    public var id: Int { rowNumber }

    public let rowNumber: Int
    public let typeID: Int64?
    public let itemName: String?
    public let quantity: Int64?
    public let existingStock: ManualStockSnapshot?
    public let catalogVersion: CatalogDataVersion?
    public let state: InventoryCSVPreviewState
    public let issues: [InventoryCSVRowIssue]

    public init(
        rowNumber: Int,
        typeID: Int64?,
        itemName: String?,
        quantity: Int64?,
        existingStock: ManualStockSnapshot?,
        catalogVersion: CatalogDataVersion?,
        state: InventoryCSVPreviewState,
        issues: [InventoryCSVRowIssue]
    ) {
        self.rowNumber = rowNumber
        self.typeID = typeID
        self.itemName = itemName
        self.quantity = quantity
        self.existingStock = existingStock
        self.catalogVersion = catalogVersion
        self.state = state
        self.issues = issues
    }
}

public struct InventoryCSVImportPreview: Equatable, Sendable {
    public let sourceName: String
    public let sourceSHA256: String
    public let location: StorageLocationSnapshot
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter
    public let mapping: InventoryCSVColumnMapping
    public let quantityFormat: InventoryCSVQuantityFormat
    public let lines: [InventoryCSVPreviewLine]

    public init(
        sourceName: String,
        sourceSHA256: String,
        location: StorageLocationSnapshot,
        encoding: InventoryCSVDetectedEncoding,
        delimiter: InventoryCSVDetectedDelimiter,
        mapping: InventoryCSVColumnMapping,
        quantityFormat: InventoryCSVQuantityFormat,
        lines: [InventoryCSVPreviewLine]
    ) {
        self.sourceName = sourceName
        self.sourceSHA256 = sourceSHA256
        self.location = location
        self.encoding = encoding
        self.delimiter = delimiter
        self.mapping = mapping
        self.quantityFormat = quantityFormat
        self.lines = lines
    }

    public var requiresDecisions: [InventoryCSVPreviewLine] {
        lines.filter { $0.state == .replacementRequired }
    }

    public var insertCount: Int {
        lines.count { $0.state == .insert }
    }

    public var invalidCount: Int {
        lines.count { $0.state == .invalid }
    }
}

public enum InventoryCSVImportDecision: String, Codable, Sendable {
    case replace
    case skip
}

public enum InventoryImportResult: String, Codable, Sendable {
    case inserted
    case replaced
    case skipped
    case unchanged
    case invalid
}

public struct InventoryImportReportLine: Equatable, Codable, Sendable {
    public let rowNumber: Int
    public let typeID: Int64?
    public let itemName: String?
    public let previousQuantity: Int64?
    public let importedQuantity: Int64?
    public let result: InventoryImportResult
    public let issues: [InventoryCSVRowIssue]

    public init(
        rowNumber: Int,
        typeID: Int64?,
        itemName: String?,
        previousQuantity: Int64?,
        importedQuantity: Int64?,
        result: InventoryImportResult,
        issues: [InventoryCSVRowIssue]
    ) {
        self.rowNumber = rowNumber
        self.typeID = typeID
        self.itemName = itemName
        self.previousQuantity = previousQuantity
        self.importedQuantity = importedQuantity
        self.result = result
        self.issues = issues
    }
}

public struct InventoryImportReport: Identifiable, Equatable, Codable, Sendable {
    public static let payloadVersion = 1

    public let id: UUID
    public let importedAt: Date
    public let locationID: UUID
    public let locationName: String
    public let sourceName: String
    public let sourceSHA256: String
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter
    public let totalRows: Int
    public let insertedCount: Int
    public let replacedCount: Int
    public let skippedCount: Int
    public let unchangedCount: Int
    public let invalidCount: Int
    public let lines: [InventoryImportReportLine]
    public let version: Int

    public init(
        id: UUID,
        importedAt: Date,
        locationID: UUID,
        locationName: String,
        sourceName: String,
        sourceSHA256: String,
        encoding: InventoryCSVDetectedEncoding,
        delimiter: InventoryCSVDetectedDelimiter,
        lines: [InventoryImportReportLine]
    ) {
        self.id = id
        self.importedAt = importedAt
        self.locationID = locationID
        self.locationName = locationName
        self.sourceName = sourceName
        self.sourceSHA256 = sourceSHA256
        self.encoding = encoding
        self.delimiter = delimiter
        self.totalRows = lines.count
        self.insertedCount = lines.count { $0.result == .inserted }
        self.replacedCount = lines.count { $0.result == .replaced }
        self.skippedCount = lines.count { $0.result == .skipped }
        self.unchangedCount = lines.count { $0.result == .unchanged }
        self.invalidCount = lines.count { $0.result == .invalid }
        self.lines = lines.sorted { $0.rowNumber < $1.rowNumber }
        self.version = Self.payloadVersion
    }
}

public enum InventoryImportExpectation: Equatable, Sendable {
    case missing(locationID: UUID, typeID: Int64)
    case existing(ManualStockSnapshot)
}

public struct InventoryImportMutation: Equatable, Sendable {
    public let expectation: InventoryImportExpectation
    public let stock: ManualStockSnapshot

    public init(
        expectation: InventoryImportExpectation,
        stock: ManualStockSnapshot
    ) {
        self.expectation = expectation
        self.stock = stock
    }
}

public struct InventoryImportCommit: Equatable, Sendable {
    public let mutations: [InventoryImportMutation]
    public let report: InventoryImportReport

    public init(
        mutations: [InventoryImportMutation],
        report: InventoryImportReport
    ) {
        self.mutations = mutations
        self.report = report
    }
}

public enum InventoryCSVImportError: Error, Equatable, Sendable {
    case invalidSourceName
    case invalidSourceHash
    case emptyFile
    case fileTooLarge(maximumBytes: Int)
    case notRegularFile
    case unreadableEncoding
    case containsNullByte
    case ambiguousDelimiter
    case malformedQuotedField(line: Int)
    case missingHeader
    case emptyHeader(column: Int)
    case duplicateHeader(String)
    case tooManyColumns(maximum: Int)
    case tooManyRows(maximum: Int)
    case invalidColumnMapping
    case inactiveLocation(UUID)
    case missingConflictDecision(row: Int)
    case noChangesSelected
    case confirmationRequired
    case stalePreview
    case invalidStoredImportReport(UUID)
}

public protocol InventoryCSVImporting: Sendable {
    func inspect(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions
    ) async throws -> InventoryCSVInspection

    func preview(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions,
        mapping: InventoryCSVColumnMapping,
        quantityFormat: InventoryCSVQuantityFormat,
        locationID: UUID
    ) async throws -> InventoryCSVImportPreview

    func apply(
        preview: InventoryCSVImportPreview,
        decisions: [Int: InventoryCSVImportDecision],
        confirmed: Bool
    ) async throws -> InventoryImportReport
}

public struct InventoryCSVImportService: InventoryCSVImporting, Sendable {
    private let parser: any InventoryCSVParsing
    private let repository: any InventoryRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        parser: any InventoryCSVParsing,
        repository: any InventoryRepository,
        catalog: any ItemBlueprintCatalogReading,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.parser = parser
        self.repository = repository
        self.catalog = catalog
        self.now = now
        self.makeID = makeID
    }

    public func inspect(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions
    ) async throws -> InventoryCSVInspection {
        try validateSource(source)
        try Task.checkCancellation()
        let parser = self.parser
        let document = try await Task.detached {
            try parser.parse(source: source, options: options)
        }.value
        try Task.checkCancellation()
        return InventoryCSVInspection(
            sourceName: source.displayName,
            sourceSHA256: source.sha256,
            headers: document.headers,
            dataRowCount: document.rows.count,
            encoding: document.encoding,
            delimiter: document.delimiter
        )
    }

    public func preview(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions,
        mapping: InventoryCSVColumnMapping,
        quantityFormat: InventoryCSVQuantityFormat,
        locationID: UUID
    ) async throws -> InventoryCSVImportPreview {
        try validateSource(source)
        let parser = self.parser
        let document = try await Task.detached {
            try parser.parse(source: source, options: options)
        }.value
        try validate(mapping: mapping, headerCount: document.headers.count)
        guard let location = try await repository.location(id: locationID),
              !location.isArchived else {
            throw InventoryCSVImportError.inactiveLocation(locationID)
        }

        let preliminaries = document.rows.map {
            preliminaryLine(
                row: $0,
                headerCount: document.headers.count,
                mapping: mapping,
                quantityFormat: quantityFormat
            )
        }
        let duplicateIDs = Dictionary(grouping: preliminaries.compactMap {
            line -> (Int64, Int)? in
            guard let typeID = line.typeID else {
                return nil
            }
            return (typeID, line.rowNumber)
        }, by: \.0).filter { $0.value.count > 1 }.keys

        var lines: [InventoryCSVPreviewLine] = []
        for preliminary in preliminaries {
            try Task.checkCancellation()
            if let typeID = preliminary.typeID,
               duplicateIDs.contains(typeID) {
                lines.append(
                    invalidLine(
                        preliminary,
                        adding: InventoryCSVRowIssue(
                            code: .duplicateTypeID,
                            message: "Type-ID \(typeID) kommt mehrfach in der Datei vor."
                        )
                    )
                )
                continue
            }
            guard preliminary.issues.isEmpty,
                  let typeID = preliminary.typeID,
                  let quantity = preliminary.quantity else {
                lines.append(invalidLine(preliminary))
                continue
            }

            let details: CatalogItemDetails
            switch try await catalog.item(typeID: typeID) {
            case .notFound:
                lines.append(
                    invalidLine(
                        preliminary,
                        adding: .init(
                            code: .itemNotFound,
                            message: "Type-ID \(typeID) existiert nicht im aktiven Katalog."
                        )
                    )
                )
                continue
            case .found(let found):
                guard found.summary.published else {
                    lines.append(
                        invalidLine(
                            preliminary,
                            adding: .init(
                                code: .unpublishedItem,
                                message: "Type-ID \(typeID) ist nicht veröffentlicht."
                            )
                        )
                    )
                    continue
                }
                details = found
            }

            if let suppliedName = preliminary.suppliedItemName,
               !suppliedName.isEmpty,
               CatalogSearchText.normalize(suppliedName)
                != CatalogSearchText.normalize(details.summary.name) {
                lines.append(
                    invalidLine(
                        preliminary,
                        itemName: details.summary.name,
                        adding: .init(
                            code: .itemNameMismatch,
                            message: "Der CSV-Itemname stimmt nicht mit dem aktiven Katalog überein."
                        )
                    )
                )
                continue
            }

            let existing = try await repository.stock(
                locationID: locationID,
                typeID: typeID
            )
            let state: InventoryCSVPreviewState
            if let existing {
                state = existing.quantity == quantity
                    ? .unchanged
                    : .replacementRequired
            } else {
                state = .insert
            }
            lines.append(
                InventoryCSVPreviewLine(
                    rowNumber: preliminary.rowNumber,
                    typeID: typeID,
                    itemName: details.summary.name,
                    quantity: quantity,
                    existingStock: existing,
                    catalogVersion: details.version,
                    state: state,
                    issues: []
                )
            )
        }

        return InventoryCSVImportPreview(
            sourceName: source.displayName,
            sourceSHA256: source.sha256,
            location: location,
            encoding: document.encoding,
            delimiter: document.delimiter,
            mapping: mapping,
            quantityFormat: quantityFormat,
            lines: lines.sorted { $0.rowNumber < $1.rowNumber }
        )
    }

    public func apply(
        preview: InventoryCSVImportPreview,
        decisions: [Int: InventoryCSVImportDecision],
        confirmed: Bool
    ) async throws -> InventoryImportReport {
        guard confirmed else {
            throw InventoryCSVImportError.confirmationRequired
        }
        guard let location = try await repository.location(
            id: preview.location.id
        ), location == preview.location, !location.isArchived else {
            throw InventoryCSVImportError.stalePreview
        }

        var mutations: [InventoryImportMutation] = []
        var reportLines: [InventoryImportReportLine] = []
        let timestamp = now()

        for line in preview.lines {
            try Task.checkCancellation()
            switch line.state {
            case .invalid:
                reportLines.append(reportLine(line, result: .invalid))
            case .unchanged:
                guard try await currentStock(for: line, in: location.id)
                        == line.existingStock else {
                    throw InventoryCSVImportError.stalePreview
                }
                reportLines.append(reportLine(line, result: .unchanged))
            case .replacementRequired:
                guard let decision = decisions[line.rowNumber] else {
                    throw InventoryCSVImportError.missingConflictDecision(
                        row: line.rowNumber
                    )
                }
                guard let current = try await currentStock(
                    for: line,
                    in: location.id
                ), current == line.existingStock else {
                    throw InventoryCSVImportError.stalePreview
                }
                if decision == .skip {
                    reportLines.append(reportLine(line, result: .skipped))
                    continue
                }
                let stock = try makeStock(
                    line: line,
                    locationID: location.id,
                    existing: current,
                    timestamp: timestamp
                )
                try await validateCatalog(line)
                mutations.append(
                    InventoryImportMutation(
                        expectation: .existing(current),
                        stock: stock
                    )
                )
                reportLines.append(reportLine(line, result: .replaced))
            case .insert:
                guard try await currentStock(for: line, in: location.id)
                        == nil else {
                    throw InventoryCSVImportError.stalePreview
                }
                let stock = try makeStock(
                    line: line,
                    locationID: location.id,
                    existing: nil,
                    timestamp: timestamp
                )
                try await validateCatalog(line)
                mutations.append(
                    InventoryImportMutation(
                        expectation: .missing(
                            locationID: location.id,
                            typeID: stock.typeID
                        ),
                        stock: stock
                    )
                )
                reportLines.append(reportLine(line, result: .inserted))
            }
        }

        guard !mutations.isEmpty else {
            throw InventoryCSVImportError.noChangesSelected
        }
        let report = InventoryImportReport(
            id: makeID(),
            importedAt: timestamp,
            locationID: location.id,
            locationName: location.name,
            sourceName: preview.sourceName,
            sourceSHA256: preview.sourceSHA256,
            encoding: preview.encoding,
            delimiter: preview.delimiter,
            lines: reportLines
        )
        try Task.checkCancellation()
        try await repository.applyInventoryImport(
            InventoryImportCommit(mutations: mutations, report: report)
        )
        return report
    }

    private func validateSource(_ source: InventoryCSVImportSource) throws {
        guard !source.displayName.isEmpty,
              !source.displayName.contains("/"),
              !source.displayName.contains("\\") else {
            throw InventoryCSVImportError.invalidSourceName
        }
        guard source.sha256.count == 64,
              source.sha256.allSatisfy(\.isHexDigit) else {
            throw InventoryCSVImportError.invalidSourceHash
        }
    }

    private func validate(
        mapping: InventoryCSVColumnMapping,
        headerCount: Int
    ) throws {
        let required = [mapping.typeIDColumn, mapping.quantityColumn]
        guard required.allSatisfy({ (0..<headerCount).contains($0) }),
              Set(required).count == required.count else {
            throw InventoryCSVImportError.invalidColumnMapping
        }
        if let itemNameColumn = mapping.itemNameColumn {
            guard (0..<headerCount).contains(itemNameColumn),
                  !required.contains(itemNameColumn) else {
                throw InventoryCSVImportError.invalidColumnMapping
            }
        }
    }

    private func preliminaryLine(
        row: InventoryCSVParsedRow,
        headerCount: Int,
        mapping: InventoryCSVColumnMapping,
        quantityFormat: InventoryCSVQuantityFormat
    ) -> PreliminaryLine {
        guard row.fields.count == headerCount else {
            return PreliminaryLine(
                rowNumber: row.rowNumber,
                typeID: nil,
                quantity: nil,
                suppliedItemName: nil,
                issues: [
                    .init(
                        code: .wrongColumnCount,
                        message: "Die Zeile hat \(row.fields.count) statt \(headerCount) Spalten."
                    )
                ]
            )
        }
        let typeText = row.fields[mapping.typeIDColumn]
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let typeID = positiveInteger(typeText)
        let quantity = quantity(
            row.fields[mapping.quantityColumn],
            format: quantityFormat
        )
        var issues: [InventoryCSVRowIssue] = []
        if typeID == nil {
            issues.append(
                .init(
                    code: .invalidTypeID,
                    message: "Die Type-ID ist keine positive Int64-Ganzzahl."
                )
            )
        }
        if quantity == nil {
            issues.append(
                .init(
                    code: .invalidQuantity,
                    message: "Die Menge entspricht nicht dem gewählten positiven Ganzzahlformat."
                )
            )
        }
        return PreliminaryLine(
            rowNumber: row.rowNumber,
            typeID: typeID,
            quantity: quantity,
            suppliedItemName: mapping.itemNameColumn.map {
                row.fields[$0].trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
            },
            issues: issues
        )
    }

    private func positiveInteger(_ value: String) -> Int64? {
        guard !value.isEmpty, value.allSatisfy(\.isNumber),
              let result = Int64(value), result > 0 else {
            return nil
        }
        return result
    }

    private func quantity(
        _ value: String,
        format: InventoryCSVQuantityFormat
    ) -> Int64? {
        let normalized = value.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        switch format {
        case .integer:
            return positiveInteger(normalized)
        case .decimalComma:
            return exactIntegerDecimal(normalized, separator: ",")
        case .decimalPoint:
            return exactIntegerDecimal(normalized, separator: ".")
        }
    }

    private func exactIntegerDecimal(
        _ value: String,
        separator: Character
    ) -> Int64? {
        let parts = value.split(
            separator: separator,
            omittingEmptySubsequences: false
        )
        guard parts.count == 2,
              !parts[1].isEmpty,
              parts[1].allSatisfy({ $0 == "0" }) else {
            return nil
        }
        return positiveInteger(String(parts[0]))
    }

    private func invalidLine(
        _ preliminary: PreliminaryLine,
        itemName: String? = nil,
        adding issue: InventoryCSVRowIssue? = nil
    ) -> InventoryCSVPreviewLine {
        InventoryCSVPreviewLine(
            rowNumber: preliminary.rowNumber,
            typeID: preliminary.typeID,
            itemName: itemName ?? preliminary.suppliedItemName,
            quantity: preliminary.quantity,
            existingStock: nil,
            catalogVersion: nil,
            state: .invalid,
            issues: preliminary.issues + [issue].compactMap { $0 }
        )
    }

    private func currentStock(
        for line: InventoryCSVPreviewLine,
        in locationID: UUID
    ) async throws -> ManualStockSnapshot? {
        guard let typeID = line.typeID else {
            throw InventoryCSVImportError.stalePreview
        }
        return try await repository.stock(
            locationID: locationID,
            typeID: typeID
        )
    }

    private func validateCatalog(
        _ line: InventoryCSVPreviewLine
    ) async throws {
        guard let typeID = line.typeID,
              let expectedVersion = line.catalogVersion,
              let expectedName = line.itemName else {
            throw InventoryCSVImportError.stalePreview
        }
        switch try await catalog.item(typeID: typeID) {
        case .notFound:
            throw InventoryCSVImportError.stalePreview
        case .found(let current):
            guard current.summary.published,
                  current.summary.name == expectedName,
                  current.version == expectedVersion else {
                throw InventoryCSVImportError.stalePreview
            }
        }
    }

    private func makeStock(
        line: InventoryCSVPreviewLine,
        locationID: UUID,
        existing: ManualStockSnapshot?,
        timestamp: Date
    ) throws -> ManualStockSnapshot {
        guard let typeID = line.typeID,
              let itemName = line.itemName,
              let quantity = line.quantity,
              let version = line.catalogVersion else {
            throw InventoryCSVImportError.stalePreview
        }
        return try ManualStockSnapshot(
            id: existing?.id ?? makeID(),
            locationID: locationID,
            typeID: typeID,
            itemName: itemName,
            quantity: quantity,
            catalogBuildNumber: version.buildNumber,
            catalogContentSHA256: version.contentSHA256,
            createdAt: existing?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
    }

    private func reportLine(
        _ line: InventoryCSVPreviewLine,
        result: InventoryImportResult
    ) -> InventoryImportReportLine {
        InventoryImportReportLine(
            rowNumber: line.rowNumber,
            typeID: line.typeID,
            itemName: line.itemName,
            previousQuantity: line.existingStock?.quantity,
            importedQuantity: line.quantity,
            result: result,
            issues: line.issues
        )
    }
}

private struct PreliminaryLine {
    let rowNumber: Int
    let typeID: Int64?
    let quantity: Int64?
    let suppliedItemName: String?
    let issues: [InventoryCSVRowIssue]
}
