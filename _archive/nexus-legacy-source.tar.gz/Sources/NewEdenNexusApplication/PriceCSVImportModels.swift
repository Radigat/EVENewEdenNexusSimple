import Foundation
import NewEdenNexusDomain

public enum PriceCSVDecimalFormat: String, CaseIterable, Codable, Sendable {
    case decimalPoint
    case decimalComma
}

public struct PriceCSVColumnMapping: Equatable, Sendable {
    public let typeIDColumn: Int
    public let priceColumn: Int
    public let itemNameColumn: Int?

    public init(
        typeIDColumn: Int,
        priceColumn: Int,
        itemNameColumn: Int? = nil
    ) {
        self.typeIDColumn = typeIDColumn
        self.priceColumn = priceColumn
        self.itemNameColumn = itemNameColumn
    }
}

public struct PriceCSVInspection: Equatable, Sendable {
    public let sourceName: String
    public let sourceSHA256: String
    public let headers: [String]
    public let dataRowCount: Int
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter
}

public enum PriceCSVRowIssueCode: String, Codable, Sendable {
    case wrongColumnCount
    case invalidTypeID
    case invalidPrice
    case duplicateTypeID
    case itemNotFound
    case unpublishedItem
    case itemNameMismatch
}

public struct PriceCSVRowIssue: Equatable, Codable, Sendable {
    public let code: PriceCSVRowIssueCode
    public let message: String

    public init(code: PriceCSVRowIssueCode, message: String) {
        self.code = code
        self.message = message
    }
}

public enum PriceCSVPreviewState: String, Codable, Sendable {
    case insert
    case unchanged
    case replacementRequired
    case invalid
}

public struct PriceCSVPreviewLine: Identifiable, Equatable, Sendable {
    public var id: Int { rowNumber }

    public let rowNumber: Int
    public let typeID: Int64?
    public let itemName: String?
    public let amount: ISKAmount?
    public let existingPrice: ManualPriceSnapshot?
    public let catalogVersion: CatalogDataVersion?
    public let state: PriceCSVPreviewState
    public let issues: [PriceCSVRowIssue]
}

public struct PriceCSVImportPreview: Equatable, Sendable {
    public let sourceName: String
    public let sourceSHA256: String
    public let profile: PriceProfileSnapshot
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter
    public let mapping: PriceCSVColumnMapping
    public let decimalFormat: PriceCSVDecimalFormat
    public let validFrom: Date
    public let validUntil: Date?
    public let lines: [PriceCSVPreviewLine]

    public var requiresDecisions: [PriceCSVPreviewLine] {
        lines.filter { $0.state == .replacementRequired }
    }

    public var insertCount: Int {
        lines.count { $0.state == .insert }
    }

    public var invalidCount: Int {
        lines.count { $0.state == .invalid }
    }
}

public enum PriceCSVImportDecision: String, Codable, Sendable {
    case replace
    case skip
}

public enum PriceImportResult: String, Codable, Sendable {
    case inserted
    case replaced
    case skipped
    case unchanged
    case invalid
}

public struct PriceImportReportLine: Equatable, Codable, Sendable {
    public let rowNumber: Int
    public let typeID: Int64?
    public let itemName: String?
    public let previousAmountHundredths: Int64?
    public let importedAmountHundredths: Int64?
    public let result: PriceImportResult
    public let issues: [PriceCSVRowIssue]
}

public struct PriceImportReport:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public static let payloadVersion = 1

    public let id: UUID
    public let importedAt: Date
    public let profileID: UUID
    public let profileName: String
    public let sourceName: String
    public let sourceSHA256: String
    public let encoding: InventoryCSVDetectedEncoding
    public let delimiter: InventoryCSVDetectedDelimiter
    public let decimalFormat: PriceCSVDecimalFormat
    public let validFrom: Date
    public let validUntil: Date?
    public let totalRows: Int
    public let insertedCount: Int
    public let replacedCount: Int
    public let skippedCount: Int
    public let unchangedCount: Int
    public let invalidCount: Int
    public let lines: [PriceImportReportLine]
    public let version: Int

    public init(
        id: UUID,
        importedAt: Date,
        profileID: UUID,
        profileName: String,
        sourceName: String,
        sourceSHA256: String,
        encoding: InventoryCSVDetectedEncoding,
        delimiter: InventoryCSVDetectedDelimiter,
        decimalFormat: PriceCSVDecimalFormat,
        validFrom: Date,
        validUntil: Date?,
        lines: [PriceImportReportLine]
    ) {
        self.id = id
        self.importedAt = importedAt
        self.profileID = profileID
        self.profileName = profileName
        self.sourceName = sourceName
        self.sourceSHA256 = sourceSHA256
        self.encoding = encoding
        self.delimiter = delimiter
        self.decimalFormat = decimalFormat
        self.validFrom = validFrom
        self.validUntil = validUntil
        let sorted = lines.sorted { $0.rowNumber < $1.rowNumber }
        self.lines = sorted
        totalRows = sorted.count
        insertedCount = sorted.count { $0.result == .inserted }
        replacedCount = sorted.count { $0.result == .replaced }
        skippedCount = sorted.count { $0.result == .skipped }
        unchangedCount = sorted.count { $0.result == .unchanged }
        invalidCount = sorted.count { $0.result == .invalid }
        version = Self.payloadVersion
    }
}

public enum PriceImportExpectation: Equatable, Sendable {
    case missing(profileID: UUID, typeID: Int64)
    case existing(ManualPriceSnapshot)
}

public struct PriceImportMutation: Equatable, Sendable {
    public let expectation: PriceImportExpectation
    public let price: ManualPriceSnapshot
}

public struct PriceImportCommit: Equatable, Sendable {
    public let profile: PriceProfileSnapshot
    public let mutations: [PriceImportMutation]
    public let report: PriceImportReport
}

public enum PriceCSVImportError: Error, Equatable, Sendable {
    case invalidSourceName
    case invalidSourceHash
    case invalidColumnMapping
    case invalidValidityRange
    case profileNotFound(UUID)
    case missingConflictDecision(row: Int)
    case noChangesSelected
    case confirmationRequired
    case stalePreview
    case invalidStoredImportReport(UUID)
}

public protocol PriceCSVImporting: Sendable {
    func inspect(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions
    ) async throws -> PriceCSVInspection

    func preview(
        source: InventoryCSVImportSource,
        options: InventoryCSVParserOptions,
        mapping: PriceCSVColumnMapping,
        decimalFormat: PriceCSVDecimalFormat,
        profileID: UUID,
        validFrom: Date,
        validUntil: Date?
    ) async throws -> PriceCSVImportPreview

    func apply(
        preview: PriceCSVImportPreview,
        decisions: [Int: PriceCSVImportDecision],
        confirmed: Bool
    ) async throws -> PriceImportReport
}

