import Foundation
import NewEdenNexusDomain

public enum ProductionBatchMissingField:
    String,
    CaseIterable,
    Equatable,
    Sendable
{
    case solarSystem = "solarSystem"
    case solarSystemName = "solarSystemName"
    case locationName = "locationName"
    case characterName = "characterName"
}

public struct ProductionBatchDraft: Equatable, Sendable {
    public let projectID: UUID
    public var productionDate: Date
    public var completedAt: Date?
    public var status: ProductionBatchStatus
    public var runs: Int64
    public var materialEfficiency: Int
    public var timeEfficiency: Int
    public var outputUnits: Int64
    public var characterID: Int64?
    public var characterName: String?
    public var blueprintInstanceID: Int64?
    public var esiIndustryJobID: Int64?
    public var solarSystemID: Int64?
    public var solarSystemName: String?
    public var locationID: Int64?
    public var locationName: String?
    public var facilityID: Int64?
    public var facilityName: String?

    public init(
        projectID: UUID,
        productionDate: Date,
        completedAt: Date? = nil,
        status: ProductionBatchStatus,
        runs: Int64,
        materialEfficiency: Int,
        timeEfficiency: Int,
        outputUnits: Int64,
        characterID: Int64? = nil,
        characterName: String? = nil,
        blueprintInstanceID: Int64? = nil,
        esiIndustryJobID: Int64? = nil,
        solarSystemID: Int64? = nil,
        solarSystemName: String? = nil,
        locationID: Int64? = nil,
        locationName: String? = nil,
        facilityID: Int64? = nil,
        facilityName: String? = nil
    ) {
        self.projectID = projectID
        self.productionDate = productionDate
        self.completedAt = completedAt
        self.status = status
        self.runs = runs
        self.materialEfficiency = materialEfficiency
        self.timeEfficiency = timeEfficiency
        self.outputUnits = outputUnits
        self.characterID = characterID
        self.characterName = characterName
        self.blueprintInstanceID = blueprintInstanceID
        self.esiIndustryJobID = esiIndustryJobID
        self.solarSystemID = solarSystemID
        self.solarSystemName = solarSystemName
        self.locationID = locationID
        self.locationName = locationName
        self.facilityID = facilityID
        self.facilityName = facilityName
    }
}

public struct ProductionBatchSourceFingerprint:
    Equatable,
    Codable,
    Sendable
{
    public let projectUpdatedAt: Date
    public let graphID: UUID
    public let graphUpdatedAt: Date
    public let graphFormatVersion: Int
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String

    public init(
        projectUpdatedAt: Date,
        graphID: UUID,
        graphUpdatedAt: Date,
        graphFormatVersion: Int,
        catalogBuildNumber: Int,
        catalogContentSHA256: String
    ) {
        self.projectUpdatedAt = projectUpdatedAt
        self.graphID = graphID
        self.graphUpdatedAt = graphUpdatedAt
        self.graphFormatVersion = graphFormatVersion
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = catalogContentSHA256
    }
}

public struct ProductionBatchCreationRequest:
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let projectName: String
    public let source: ProductionBatchSourceFingerprint
    public let expansionPolicyVersion: Int
    public let runFormulaVersion: Int
    public let materialFormulaVersion: Int
    public let productionDate: Date
    public let completedAt: Date?
    public let status: ProductionBatchStatus
    public let productTypeID: Int64
    public let productName: String
    public let activity: ProductionTargetActivity
    public let runs: Int64
    public let materialEfficiency: Int
    public let timeEfficiency: Int
    public let outputUnits: Int64
    public let characterID: Int64?
    public let characterName: String?
    public let blueprintInstanceID: Int64?
    public let esiIndustryJobID: Int64?
    public let solarSystemID: Int64?
    public let solarSystemName: String?
    public let locationID: Int64?
    public let locationName: String?
    public let facilityID: Int64?
    public let facilityName: String?
    public let createdAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        projectName: String,
        source: ProductionBatchSourceFingerprint,
        expansionPolicyVersion: Int,
        runFormulaVersion: Int,
        materialFormulaVersion: Int,
        productionDate: Date,
        completedAt: Date?,
        status: ProductionBatchStatus,
        productTypeID: Int64,
        productName: String,
        activity: ProductionTargetActivity,
        runs: Int64,
        materialEfficiency: Int,
        timeEfficiency: Int,
        outputUnits: Int64,
        characterID: Int64?,
        characterName: String?,
        blueprintInstanceID: Int64?,
        esiIndustryJobID: Int64?,
        solarSystemID: Int64?,
        solarSystemName: String?,
        locationID: Int64?,
        locationName: String?,
        facilityID: Int64?,
        facilityName: String?,
        createdAt: Date
    ) {
        self.id = id
        self.projectID = projectID
        self.projectName = projectName
        self.source = source
        self.expansionPolicyVersion = expansionPolicyVersion
        self.runFormulaVersion = runFormulaVersion
        self.materialFormulaVersion = materialFormulaVersion
        self.productionDate = productionDate
        self.completedAt = completedAt
        self.status = status
        self.productTypeID = productTypeID
        self.productName = productName
        self.activity = activity
        self.runs = runs
        self.materialEfficiency = materialEfficiency
        self.timeEfficiency = timeEfficiency
        self.outputUnits = outputUnits
        self.characterID = characterID
        self.characterName = characterName
        self.blueprintInstanceID = blueprintInstanceID
        self.esiIndustryJobID = esiIndustryJobID
        self.solarSystemID = solarSystemID
        self.solarSystemName = solarSystemName
        self.locationID = locationID
        self.locationName = locationName
        self.facilityID = facilityID
        self.facilityName = facilityName
        self.createdAt = createdAt
    }
}

public struct ProductionBatchPreview:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let request: ProductionBatchCreationRequest
    public let industryJobFingerprint:
        ProductionBatchIndustryJobFingerprint?
    public let missingFields: [ProductionBatchMissingField]
    public let generatedAt: Date

    /// Zusätzliche Herkunftsangaben dürfen bei einer lokalen Planung fehlen.
    /// Die Vorschau benennt diese Lücken, erfindet aber keine Ersatzwerte.
    public var isReadyToApply: Bool {
        true
    }
}

public struct ProductionBatchIndustryJobFingerprint:
    Equatable,
    Sendable
{
    public let jobID: Int64
    public let characterID: Int64
    public let blueprintID: Int64
    public let blueprintTypeID: Int64
    public let facilityID: Int64
    public let stationID: Int64
    public let activityID: Int64
    public let runs: Int64
    public let status: String
    public let endDate: Date
    public let completedDate: Date?
    public let productTypeID: Int64?
    public let successfulRuns: Int64?

    public init(
        job: ESICharacterIndustryJob,
        characterID: Int64
    ) {
        jobID = job.jobID
        self.characterID = characterID
        blueprintID = job.blueprintID
        blueprintTypeID = job.blueprintTypeID
        facilityID = job.facilityID
        stationID = job.stationID
        activityID = job.activityID
        runs = job.runs
        status = job.status
        endDate = job.endDate
        completedDate = job.completedDate
        productTypeID = job.productTypeID
        successfulRuns = job.successfulRuns
    }
}

public protocol ProductionBatchIndustryJobReading: Sendable {
    func industryJob(
        jobID: Int64,
        characterID: Int64
    ) async throws -> ESICharacterIndustryJob?
}

public struct ESIPersonalDataIndustryJobSource:
    ProductionBatchIndustryJobReading,
    Sendable
{
    private let store: any ESIPersonalDataPersisting

    public init(store: any ESIPersonalDataPersisting) {
        self.store = store
    }

    public func industryJob(
        jobID: Int64,
        characterID: Int64
    ) async throws -> ESICharacterIndustryJob? {
        try await store.snapshot(characterID: characterID)?
            .industryJobs.first { $0.jobID == jobID }
    }
}

public struct ProductionBatchFilter: Equatable, Sendable {
    public var calendarYear: Int?
    public var productQuery: String?
    public var projectID: UUID?
    public var characterID: Int64?
    public var locationQuery: String?
    public var status: ProductionBatchStatus?

    public init(
        calendarYear: Int? = nil,
        productQuery: String? = nil,
        projectID: UUID? = nil,
        characterID: Int64? = nil,
        locationQuery: String? = nil,
        status: ProductionBatchStatus? = nil
    ) {
        self.calendarYear = calendarYear
        self.productQuery = productQuery
        self.projectID = projectID
        self.characterID = characterID
        self.locationQuery = locationQuery
        self.status = status
    }
}

public protocol ProductionBatchRepository: Sendable {
    func create(_ request: ProductionBatchCreationRequest) async throws
        -> ProductionBatchSnapshot
    func batch(id: UUID) async throws -> ProductionBatchSnapshot?
    func batches() async throws -> [ProductionBatchSnapshot]
}

public enum ProductionBatchManagementError:
    Error,
    Equatable,
    Sendable
{
    case projectNotFound(UUID)
    case projectTargetMissing(UUID)
    case productionGraphMissing(UUID)
    case staleProject
    case staleGraph
    case staleCatalog
    case staleIndustryJob
    case industryJobMismatch
    case invalidRootCalculation
    case outputOverflow
    case requiredFieldMissing(ProductionBatchMissingField)
    case confirmationRequired
}

public protocol ProductionBatchManaging: Sendable {
    func projects() async throws -> [ProductionProjectSnapshot]
    func batches(filter: ProductionBatchFilter) async throws
        -> [ProductionBatchSnapshot]
    func preview(_ draft: ProductionBatchDraft) async throws
        -> ProductionBatchPreview
    func preview(
        projectID: UUID,
        industryJob: ESICharacterIndustryJob
    ) async throws -> ProductionBatchPreview
    func apply(
        _ preview: ProductionBatchPreview,
        confirmed: Bool
    ) async throws -> ProductionBatchSnapshot
}

public struct ProductionBatchManagementService:
    ProductionBatchManaging,
    Sendable
{
    private let projectsRepository: any ProductionProjectRepository
    private let graphs: any ProductionGraphRepository
    private let batchesRepository: any ProductionBatchRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let industryJobs:
        (any ProductionBatchIndustryJobReading)?
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        projects: any ProductionProjectRepository,
        graphs: any ProductionGraphRepository,
        batches: any ProductionBatchRepository,
        catalog: any ItemBlueprintCatalogReading,
        industryJobs:
            (any ProductionBatchIndustryJobReading)? = nil,
        now: @escaping @Sendable () -> Date = Date.init,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        projectsRepository = projects
        self.graphs = graphs
        batchesRepository = batches
        self.catalog = catalog
        self.industryJobs = industryJobs
        self.now = now
        self.makeID = makeID
    }

    public func projects() async throws -> [ProductionProjectSnapshot] {
        try await projectsRepository.projects()
            .filter { $0.status != .archived && $0.target != nil }
    }

    public func batches(
        filter: ProductionBatchFilter
    ) async throws -> [ProductionBatchSnapshot] {
        try await batchesRepository.batches()
            .filter { batch in
                (filter.calendarYear == nil
                    || batch.calendarYear == filter.calendarYear)
                    && (filter.projectID == nil
                        || batch.projectID == filter.projectID)
                    && (filter.characterID == nil
                        || batch.characterID == filter.characterID)
                    && (filter.status == nil
                        || batch.status == filter.status)
                    && Self.matches(
                        filter.productQuery,
                        values: [batch.productName]
                    )
                    && Self.matches(
                        filter.locationQuery,
                        values: [
                            batch.solarSystemName,
                            batch.locationName,
                            batch.facilityName
                        ].compactMap { $0 }
                    )
            }
    }

    public func preview(
        _ draft: ProductionBatchDraft
    ) async throws -> ProductionBatchPreview {
        let resolved = try await resolve(projectID: draft.projectID)
        return try await makePreview(draft: draft, resolved: resolved)
    }

    public func preview(
        projectID: UUID,
        industryJob: ESICharacterIndustryJob
    ) async throws -> ProductionBatchPreview {
        let resolved = try await resolve(projectID: projectID)
        try Self.validate(
            industryJob: industryJob,
            against: resolved.project
        )
        let root = resolved.graph.nodes.first {
            $0.id == resolved.graph.rootNodeID
        }
        guard let outputPerRun = root?.recipe?.outputQuantityPerRun,
              outputPerRun > 0 else {
            throw ProductionBatchManagementError.invalidRootCalculation
        }
        let effectiveRuns = industryJob.successfulRuns
            ?? industryJob.runs
        let output = effectiveRuns.multipliedReportingOverflow(
            by: outputPerRun
        )
        guard !output.overflow, output.partialValue > 0 else {
            throw ProductionBatchManagementError.outputOverflow
        }
        let draft = ProductionBatchDraft(
            projectID: projectID,
            productionDate: industryJob.completedDate
                ?? industryJob.endDate,
            completedAt: industryJob.completedDate,
            status: industryJob.completedDate == nil
                ? .planned
                : .produced,
            runs: industryJob.runs,
            materialEfficiency:
                resolved.graph.blueprintMaterialEfficiency ?? 0,
            timeEfficiency: 0,
            outputUnits: output.partialValue,
            characterID: industryJob.installerID,
            blueprintInstanceID: industryJob.blueprintID,
            esiIndustryJobID: industryJob.jobID,
            locationID: industryJob.stationID,
            facilityID: industryJob.facilityID
        )
        return try await makePreview(draft: draft, resolved: resolved)
    }

    public func apply(
        _ preview: ProductionBatchPreview,
        confirmed: Bool
    ) async throws -> ProductionBatchSnapshot {
        guard confirmed else {
            throw ProductionBatchManagementError.confirmationRequired
        }
        let resolved = try await resolve(
            projectID: preview.request.projectID
        )
        guard preview.request.source
                == Self.fingerprint(resolved) else {
            if resolved.project.updatedAt
                != preview.request.source.projectUpdatedAt {
                throw ProductionBatchManagementError.staleProject
            }
            throw ProductionBatchManagementError.staleGraph
        }
        if let expected = preview.industryJobFingerprint {
            guard let current = try await industryJobs?.industryJob(
                jobID: expected.jobID,
                characterID: expected.characterID
            ) else {
                throw ProductionBatchManagementError.staleIndustryJob
            }
            try Self.validate(
                industryJob: current,
                against: resolved.project
            )
            guard ProductionBatchIndustryJobFingerprint(
                job: current,
                characterID: expected.characterID
            ) == expected else {
                throw ProductionBatchManagementError.staleIndustryJob
            }
        }
        try await validateCatalog(resolved)
        return try await batchesRepository.create(preview.request)
    }

    private func makePreview(
        draft: ProductionBatchDraft,
        resolved: ResolvedSource
    ) async throws -> ProductionBatchPreview {
        try await validateCatalog(resolved)
        guard let target = resolved.project.target else {
            throw ProductionBatchManagementError.projectTargetMissing(
                resolved.project.id
            )
        }
        guard let root = resolved.graph.nodes.first(where: {
            $0.id == resolved.graph.rootNodeID
        }), root.runCalculation != nil else {
            throw ProductionBatchManagementError.invalidRootCalculation
        }
        let createdAt = now()
        let industryJobFingerprint =
            try await resolveIndustryJobFingerprint(
                for: draft,
                project: resolved.project
            )
        let request = ProductionBatchCreationRequest(
            id: makeID(),
            projectID: resolved.project.id,
            projectName: resolved.project.name,
            source: Self.fingerprint(resolved),
            expansionPolicyVersion:
                resolved.graph.expansionPolicyVersion ?? 1,
            runFormulaVersion:
                ProductionRunCalculation.currentFormulaVersion,
            materialFormulaVersion:
                ProductionMaterialCalculation.currentFormulaVersion,
            productionDate: draft.productionDate,
            completedAt: draft.completedAt,
            status: draft.status,
            productTypeID: target.productTypeID,
            productName: target.productName,
            activity: target.activity,
            runs: draft.runs,
            materialEfficiency: draft.materialEfficiency,
            timeEfficiency: draft.timeEfficiency,
            outputUnits: draft.outputUnits,
            characterID: draft.characterID,
            characterName: draft.characterName,
            blueprintInstanceID: draft.blueprintInstanceID,
            esiIndustryJobID: draft.esiIndustryJobID,
            solarSystemID: draft.solarSystemID,
            solarSystemName: draft.solarSystemName,
            locationID: draft.locationID,
            locationName: draft.locationName,
            facilityID: draft.facilityID,
            facilityName: draft.facilityName,
            createdAt: createdAt
        )
        let missing = Self.missingFields(in: draft)
        _ = try ProductionBatchSnapshot(
            request: request,
            calendarYear: Self.calendarYear(for: draft.productionDate),
            sequenceNumber: 1
        )
        return ProductionBatchPreview(
            id: makeID(),
            request: request,
            industryJobFingerprint: industryJobFingerprint,
            missingFields: missing,
            generatedAt: createdAt
        )
    }

    private func resolve(projectID: UUID) async throws -> ResolvedSource {
        guard let project = try await projectsRepository.project(
            id: projectID
        ) else {
            throw ProductionBatchManagementError.projectNotFound(
                projectID
            )
        }
        guard project.target != nil else {
            throw ProductionBatchManagementError.projectTargetMissing(
                projectID
            )
        }
        guard let graph = try await graphs.graph(projectID: projectID) else {
            throw ProductionBatchManagementError.productionGraphMissing(
                projectID
            )
        }
        guard !ProductionGraphFreshness.isStale(graph, for: project) else {
            throw ProductionBatchManagementError.staleGraph
        }
        return ResolvedSource(project: project, graph: graph)
    }

    private func validateCatalog(_ source: ResolvedSource) async throws {
        guard let target = source.project.target else {
            throw ProductionBatchManagementError.projectTargetMissing(
                source.project.id
            )
        }
        let result = try await catalog.item(
            typeID: target.productTypeID
        )
        let version: CatalogDataVersion
        switch result {
        case let .found(details):
            version = details.version
        case let .notFound(activeVersion):
            version = activeVersion
        }
        guard version.buildNumber == target.catalogBuildNumber,
              version.contentSHA256
                == target.catalogContentSHA256 else {
            throw ProductionBatchManagementError.staleCatalog
        }
    }

    private func resolveIndustryJobFingerprint(
        for draft: ProductionBatchDraft,
        project: ProductionProjectSnapshot
    ) async throws -> ProductionBatchIndustryJobFingerprint? {
        guard let jobID = draft.esiIndustryJobID else {
            return nil
        }
        guard let characterID = draft.characterID,
              let industryJobs,
              let job = try await industryJobs.industryJob(
                  jobID: jobID,
                  characterID: characterID
              ) else {
            throw ProductionBatchManagementError.staleIndustryJob
        }
        try Self.validate(industryJob: job, against: project)
        return ProductionBatchIndustryJobFingerprint(
            job: job,
            characterID: characterID
        )
    }

    private static func validate(
        industryJob: ESICharacterIndustryJob,
        against project: ProductionProjectSnapshot
    ) throws {
        guard let target = project.target,
              industryJob.blueprintTypeID == target.blueprintTypeID,
              industryJob.productTypeID == nil
                || industryJob.productTypeID == target.productTypeID,
              (
                  target.activity == .manufacturing
                    && industryJob.activityID == 1
              ) || (
                  target.activity == .reaction
                    && industryJob.activityID == 11
              ) else {
            throw ProductionBatchManagementError.industryJobMismatch
        }
    }

    private static func fingerprint(
        _ source: ResolvedSource
    ) -> ProductionBatchSourceFingerprint {
        ProductionBatchSourceFingerprint(
            projectUpdatedAt: source.project.updatedAt,
            graphID: source.graph.graphID,
            graphUpdatedAt: source.graph.updatedAt,
            graphFormatVersion: source.graph.formatVersion,
            catalogBuildNumber: source.graph.catalogBuildNumber,
            catalogContentSHA256:
                source.graph.catalogContentSHA256
        )
    }

    private static func missingFields(
        in draft: ProductionBatchDraft
    ) -> [ProductionBatchMissingField] {
        var fields: [ProductionBatchMissingField] = []
        let solarSystemName =
            draft.solarSystemName.normalizedBatchText
        if draft.solarSystemID == nil, solarSystemName == nil {
            fields.append(.solarSystem)
        } else if draft.solarSystemID != nil, solarSystemName == nil {
            fields.append(.solarSystemName)
        }
        if draft.locationID != nil,
           draft.locationName.normalizedBatchText == nil {
            fields.append(.locationName)
        }
        if draft.characterID != nil,
           draft.characterName.normalizedBatchText == nil {
            fields.append(.characterName)
        }
        return fields
    }

    private static func matches(
        _ query: String?,
        values: [String]
    ) -> Bool {
        guard let query = query.normalizedBatchText else {
            return true
        }
        let normalized = CatalogSearchText.normalize(query)
        return values.contains {
            CatalogSearchText.normalize($0).contains(normalized)
        }
    }

    private static func calendarYear(for date: Date) -> Int {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        return calendar.component(.year, from: date)
    }

    private struct ResolvedSource: Sendable {
        let project: ProductionProjectSnapshot
        let graph: ProductionGraphSnapshot
    }
}

public extension ProductionBatchSnapshot {
    init(
        request: ProductionBatchCreationRequest,
        calendarYear: Int,
        sequenceNumber: Int
    ) throws {
        try self.init(
            id: request.id,
            calendarYear: calendarYear,
            sequenceNumber: sequenceNumber,
            projectID: request.projectID,
            projectName: request.projectName,
            sourceProjectUpdatedAt:
                request.source.projectUpdatedAt,
            graphID: request.source.graphID,
            graphUpdatedAt: request.source.graphUpdatedAt,
            graphFormatVersion:
                request.source.graphFormatVersion,
            expansionPolicyVersion:
                request.expansionPolicyVersion,
            runFormulaVersion: request.runFormulaVersion,
            materialFormulaVersion: request.materialFormulaVersion,
            catalogBuildNumber:
                request.source.catalogBuildNumber,
            catalogContentSHA256:
                request.source.catalogContentSHA256,
            productionDate: request.productionDate,
            completedAt: request.completedAt,
            status: request.status,
            productTypeID: request.productTypeID,
            productName: request.productName,
            activity: request.activity,
            runs: request.runs,
            materialEfficiency: request.materialEfficiency,
            timeEfficiency: request.timeEfficiency,
            outputUnits: request.outputUnits,
            characterID: request.characterID,
            characterName: request.characterName,
            blueprintInstanceID: request.blueprintInstanceID,
            esiIndustryJobID: request.esiIndustryJobID,
            solarSystemID: request.solarSystemID,
            solarSystemName: request.solarSystemName,
            locationID: request.locationID,
            locationName: request.locationName,
            facilityID: request.facilityID,
            facilityName: request.facilityName,
            createdAt: request.createdAt,
            updatedAt: request.createdAt
        )
    }
}

private extension Optional where Wrapped == String {
    var normalizedBatchText: String? {
        guard let value = self?.trimmingCharacters(
            in: .whitespacesAndNewlines
        ), !value.isEmpty else {
            return nil
        }
        return value
    }
}
