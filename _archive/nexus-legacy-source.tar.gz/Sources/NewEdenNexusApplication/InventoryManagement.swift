import Foundation
import NewEdenNexusDomain

public enum StorageLocationListScope: String, CaseIterable, Sendable {
    case active
    case archived
    case all
}

public struct StorageLocationDraft: Equatable, Sendable {
    public let name: String
    public let kind: StorageLocationKind
    public let notes: String

    public init(
        name: String,
        kind: StorageLocationKind,
        notes: String
    ) {
        self.name = name
        self.kind = kind
        self.notes = notes
    }
}

public struct ManualStockDraft: Equatable, Sendable {
    public let locationID: UUID
    public let typeID: Int64
    public let quantity: Int64

    public init(locationID: UUID, typeID: Int64, quantity: Int64) {
        self.locationID = locationID
        self.typeID = typeID
        self.quantity = quantity
    }
}

public enum InventoryManagementError: Error, Equatable, Sendable {
    case locationNotFound(UUID)
    case stockNotFound(UUID)
    case archivedLocationIsReadOnly(UUID)
    case duplicateLocationName(String)
    case itemNotFound(Int64)
    case unpublishedItem(Int64)
}

public protocol InventoryRepository: Sendable {
    func locations() async throws -> [StorageLocationSnapshot]
    func location(id: UUID) async throws -> StorageLocationSnapshot?
    func save(location: StorageLocationSnapshot) async throws
    func stocks(locationID: UUID) async throws -> [ManualStockSnapshot]
    func stock(id: UUID) async throws -> ManualStockSnapshot?
    func stock(locationID: UUID, typeID: Int64) async throws
        -> ManualStockSnapshot?
    func save(stock: ManualStockSnapshot) async throws
    func deleteStock(id: UUID) async throws
    func applyInventoryImport(_ commit: InventoryImportCommit) async throws
    func inventoryImportReports(locationID: UUID) async throws
        -> [InventoryImportReport]
}

public protocol InventoryManaging: Sendable {
    func locations(scope: StorageLocationListScope) async throws
        -> [StorageLocationSnapshot]
    func stocks(locationID: UUID) async throws -> [ManualStockSnapshot]
    func createLocation(draft: StorageLocationDraft) async throws
        -> StorageLocationSnapshot
    func updateLocation(id: UUID, draft: StorageLocationDraft) async throws
        -> StorageLocationSnapshot
    func archiveLocation(id: UUID) async throws -> StorageLocationSnapshot
    func restoreLocation(id: UUID) async throws -> StorageLocationSnapshot
    func searchItems(query: String) async throws -> CatalogSearchPage
    func saveManualStock(draft: ManualStockDraft) async throws
        -> ManualStockSnapshot
    func deleteManualStock(id: UUID) async throws
}

public struct InventoryManagementService: InventoryManaging, Sendable {
    private let repository: any InventoryRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any InventoryRepository,
        catalog: any ItemBlueprintCatalogReading,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.repository = repository
        self.catalog = catalog
        self.now = now
        self.makeID = makeID
    }

    public func locations(
        scope: StorageLocationListScope
    ) async throws -> [StorageLocationSnapshot] {
        try Task.checkCancellation()
        let stored = try await repository.locations()
        try Task.checkCancellation()
        switch scope {
        case .active:
            return stored.filter { !$0.isArchived }
        case .archived:
            return stored.filter(\.isArchived)
        case .all:
            return stored
        }
    }

    public func stocks(
        locationID: UUID
    ) async throws -> [ManualStockSnapshot] {
        _ = try await requiredLocation(id: locationID)
        try Task.checkCancellation()
        return try await repository.stocks(locationID: locationID)
    }

    public func createLocation(
        draft: StorageLocationDraft
    ) async throws -> StorageLocationSnapshot {
        let timestamp = now()
        let location = try StorageLocationSnapshot(
            id: makeID(),
            name: draft.name,
            kind: draft.kind,
            notes: draft.notes,
            isArchived: false,
            createdAt: timestamp,
            updatedAt: timestamp
        )
        try await requireUniqueName(location.name, except: nil)
        try Task.checkCancellation()
        try await repository.save(location: location)
        return location
    }

    public func updateLocation(
        id: UUID,
        draft: StorageLocationDraft
    ) async throws -> StorageLocationSnapshot {
        let stored = try await requiredLocation(id: id)
        guard !stored.isArchived else {
            throw InventoryManagementError.archivedLocationIsReadOnly(id)
        }
        let updated = try StorageLocationSnapshot(
            id: id,
            name: draft.name,
            kind: draft.kind,
            notes: draft.notes,
            isArchived: false,
            createdAt: stored.createdAt,
            updatedAt: now()
        )
        try await requireUniqueName(updated.name, except: id)
        try Task.checkCancellation()
        try await repository.save(location: updated)
        return updated
    }

    public func archiveLocation(
        id: UUID
    ) async throws -> StorageLocationSnapshot {
        let stored = try await requiredLocation(id: id)
        guard !stored.isArchived else {
            return stored
        }
        let archived = try StorageLocationSnapshot(
            id: stored.id,
            name: stored.name,
            kind: stored.kind,
            notes: stored.notes,
            isArchived: true,
            createdAt: stored.createdAt,
            updatedAt: now()
        )
        try Task.checkCancellation()
        try await repository.save(location: archived)
        return archived
    }

    public func restoreLocation(
        id: UUID
    ) async throws -> StorageLocationSnapshot {
        let stored = try await requiredLocation(id: id)
        guard stored.isArchived else {
            return stored
        }
        try await requireUniqueName(stored.name, except: id)
        let restored = try StorageLocationSnapshot(
            id: stored.id,
            name: stored.name,
            kind: stored.kind,
            notes: stored.notes,
            isArchived: false,
            createdAt: stored.createdAt,
            updatedAt: now()
        )
        try Task.checkCancellation()
        try await repository.save(location: restored)
        return restored
    }

    public func searchItems(query: String) async throws -> CatalogSearchPage {
        try await catalog.search(
            try CatalogSearchRequest(
                query: query,
                filter: CatalogSearchFilter(
                    scope: .allItems,
                    publication: .publishedOnly
                )
            )
        )
    }

    public func saveManualStock(
        draft: ManualStockDraft
    ) async throws -> ManualStockSnapshot {
        let location = try await requiredLocation(id: draft.locationID)
        guard !location.isArchived else {
            throw InventoryManagementError.archivedLocationIsReadOnly(
                location.id
            )
        }
        guard draft.quantity > 0 else {
            throw InventoryValidationError.invalidQuantity(draft.quantity)
        }
        guard draft.typeID > 0 else {
            throw InventoryValidationError.invalidTypeID(draft.typeID)
        }
        try Task.checkCancellation()
        let details: CatalogItemDetails
        switch try await catalog.item(typeID: draft.typeID) {
        case .found(let found):
            guard found.summary.published else {
                throw InventoryManagementError.unpublishedItem(draft.typeID)
            }
            details = found
        case .notFound:
            throw InventoryManagementError.itemNotFound(draft.typeID)
        }
        try Task.checkCancellation()
        let existing = try await repository.stock(
            locationID: draft.locationID,
            typeID: draft.typeID
        )
        let timestamp = now()
        let stock = try ManualStockSnapshot(
            id: existing?.id ?? makeID(),
            locationID: draft.locationID,
            typeID: draft.typeID,
            itemName: details.summary.name,
            quantity: draft.quantity,
            catalogBuildNumber: details.version.buildNumber,
            catalogContentSHA256: details.version.contentSHA256,
            createdAt: existing?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
        try Task.checkCancellation()
        try await repository.save(stock: stock)
        return stock
    }

    public func deleteManualStock(id: UUID) async throws {
        guard let stock = try await repository.stock(id: id) else {
            throw InventoryManagementError.stockNotFound(id)
        }
        let location = try await requiredLocation(id: stock.locationID)
        guard !location.isArchived else {
            throw InventoryManagementError.archivedLocationIsReadOnly(
                location.id
            )
        }
        try Task.checkCancellation()
        try await repository.deleteStock(id: id)
    }

    private func requiredLocation(
        id: UUID
    ) async throws -> StorageLocationSnapshot {
        try Task.checkCancellation()
        guard let location = try await repository.location(id: id) else {
            throw InventoryManagementError.locationNotFound(id)
        }
        return location
    }

    private func requireUniqueName(
        _ name: String,
        except excludedID: UUID?
    ) async throws {
        let normalized = CatalogSearchText.normalize(name)
        let duplicate = try await repository.locations().first {
            $0.id != excludedID
                && CatalogSearchText.normalize($0.name) == normalized
        }
        if duplicate != nil {
            throw InventoryManagementError.duplicateLocationName(name)
        }
    }
}
