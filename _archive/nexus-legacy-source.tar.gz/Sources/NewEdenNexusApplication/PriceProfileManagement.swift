import Foundation
import NewEdenNexusDomain

public struct PriceProfileDraft: Equatable, Sendable {
    public let name: String

    public init(name: String) {
        self.name = name
    }
}

public struct ManualPriceDraft: Equatable, Sendable {
    public let profileID: UUID
    public let typeID: Int64
    public let amount: ISKAmount
    public let validFrom: Date
    public let validUntil: Date?

    public init(
        profileID: UUID,
        typeID: Int64,
        amount: ISKAmount,
        validFrom: Date,
        validUntil: Date?
    ) {
        self.profileID = profileID
        self.typeID = typeID
        self.amount = amount
        self.validFrom = validFrom
        self.validUntil = validUntil
    }
}

public enum PriceProfileManagementError:
    Error,
    Equatable,
    Sendable
{
    case profileNotFound(UUID)
    case priceNotFound(UUID)
    case duplicateProfileName(String)
    case itemNotFound(Int64)
    case unpublishedItem(Int64)
    case confirmationRequired
    case staleState
    case persistenceFailure
}

public enum PriceProfileRepositoryError:
    Error,
    Equatable,
    Sendable
{
    case staleState
}

public protocol PriceProfileRepository: Sendable {
    func profiles() async throws -> [PriceProfileSnapshot]
    func profile(id: UUID) async throws -> PriceProfileSnapshot?
    func activeProfile() async throws -> PriceProfileSnapshot?
    func save(
        profile: PriceProfileSnapshot,
        expectedUpdatedAt: Date?
    ) async throws
    func activateProfile(
        id: UUID,
        expectedUpdatedAt: Date,
        at: Date
    ) async throws
    func deleteProfile(
        id: UUID,
        expectedUpdatedAt: Date,
        at: Date
    ) async throws
    func prices(profileID: UUID) async throws -> [ManualPriceSnapshot]
    func price(id: UUID) async throws -> ManualPriceSnapshot?
    func price(
        profileID: UUID,
        typeID: Int64
    ) async throws -> ManualPriceSnapshot?
    func save(
        price: ManualPriceSnapshot,
        expectedUpdatedAt: Date?
    ) async throws
    func deletePrice(
        id: UUID,
        expectedUpdatedAt: Date
    ) async throws
    func applyPriceImport(_ commit: PriceImportCommit) async throws
    func priceImportReports(
        profileID: UUID
    ) async throws -> [PriceImportReport]
}

public protocol PriceProfileManaging: Sendable {
    func profiles() async throws -> [PriceProfileSnapshot]
    func prices(profileID: UUID) async throws -> [ManualPriceSnapshot]
    func createProfile(draft: PriceProfileDraft) async throws
        -> PriceProfileSnapshot
    func renameProfile(
        id: UUID,
        draft: PriceProfileDraft
    ) async throws -> PriceProfileSnapshot
    func activateProfile(id: UUID) async throws
    func deleteProfile(id: UUID, confirmed: Bool) async throws
    func searchItems(query: String) async throws -> CatalogSearchPage
    func savePrice(draft: ManualPriceDraft) async throws
        -> ManualPriceSnapshot
    func deletePrice(id: UUID, confirmed: Bool) async throws
    func resolve(
        typeIDs: [Int64],
        profileID: UUID?,
        at: Date
    ) async throws -> PriceResolution
}

public struct PriceProfileManagementService:
    PriceProfileManaging,
    Sendable
{
    private let repository: any PriceProfileRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID

    public init(
        repository: any PriceProfileRepository,
        catalog: any ItemBlueprintCatalogReading,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() }
    ) {
        self.repository = repository
        self.catalog = catalog
        self.now = now
        self.makeID = makeID
    }

    public func profiles() async throws -> [PriceProfileSnapshot] {
        try Task.checkCancellation()
        return try await repository.profiles()
    }

    public func prices(
        profileID: UUID
    ) async throws -> [ManualPriceSnapshot] {
        _ = try await requiredProfile(id: profileID)
        try Task.checkCancellation()
        return try await repository.prices(profileID: profileID)
    }

    public func createProfile(
        draft: PriceProfileDraft
    ) async throws -> PriceProfileSnapshot {
        let stored = try await repository.profiles()
        try requireUniqueName(draft.name, profiles: stored, except: nil)
        let timestamp = now()
        let profile = try PriceProfileSnapshot(
            id: makeID(),
            name: draft.name,
            isActive: stored.isEmpty,
            createdAt: timestamp,
            updatedAt: timestamp
        )
        try Task.checkCancellation()
        try await persist {
            try await repository.save(
                profile: profile,
                expectedUpdatedAt: nil
            )
        }
        return profile
    }

    public func renameProfile(
        id: UUID,
        draft: PriceProfileDraft
    ) async throws -> PriceProfileSnapshot {
        let stored = try await requiredProfile(id: id)
        let all = try await repository.profiles()
        try requireUniqueName(draft.name, profiles: all, except: id)
        let updated = try PriceProfileSnapshot(
            id: stored.id,
            name: draft.name,
            currency: stored.currency,
            isActive: stored.isActive,
            createdAt: stored.createdAt,
            updatedAt: now()
        )
        try Task.checkCancellation()
        try await persist {
            try await repository.save(
                profile: updated,
                expectedUpdatedAt: stored.updatedAt
            )
        }
        return updated
    }

    public func activateProfile(id: UUID) async throws {
        let stored = try await requiredProfile(id: id)
        guard !stored.isActive else { return }
        try Task.checkCancellation()
        try await persist {
            try await repository.activateProfile(
                id: id,
                expectedUpdatedAt: stored.updatedAt,
                at: now()
            )
        }
    }

    public func deleteProfile(
        id: UUID,
        confirmed: Bool
    ) async throws {
        guard confirmed else {
            throw PriceProfileManagementError.confirmationRequired
        }
        let stored = try await requiredProfile(id: id)
        try Task.checkCancellation()
        try await persist {
            try await repository.deleteProfile(
                id: id,
                expectedUpdatedAt: stored.updatedAt,
                at: now()
            )
        }
    }

    public func searchItems(query: String) async throws -> CatalogSearchPage {
        try await catalog.search(
            try CatalogSearchRequest(
                query: query,
                filter: CatalogSearchFilter(
                    scope: .allItems,
                    publication: .publishedOnly
                )
            )
        )
    }

    public func savePrice(
        draft: ManualPriceDraft
    ) async throws -> ManualPriceSnapshot {
        _ = try await requiredProfile(id: draft.profileID)
        let details: CatalogItemDetails
        switch try await catalog.item(typeID: draft.typeID) {
        case .found(let value):
            guard value.summary.published else {
                throw PriceProfileManagementError.unpublishedItem(
                    draft.typeID
                )
            }
            details = value
        case .notFound:
            throw PriceProfileManagementError.itemNotFound(draft.typeID)
        }
        try Task.checkCancellation()
        let existing = try await repository.price(
            profileID: draft.profileID,
            typeID: draft.typeID
        )
        let timestamp = now()
        let price = try ManualPriceSnapshot(
            id: existing?.id ?? makeID(),
            profileID: draft.profileID,
            typeID: draft.typeID,
            itemName: details.summary.name,
            amount: draft.amount,
            validFrom: draft.validFrom,
            validUntil: draft.validUntil,
            catalogBuildNumber: details.version.buildNumber,
            catalogContentSHA256: details.version.contentSHA256,
            createdAt: existing?.createdAt ?? timestamp,
            updatedAt: timestamp
        )
        try Task.checkCancellation()
        try await persist {
            try await repository.save(
                price: price,
                expectedUpdatedAt: existing?.updatedAt
            )
        }
        return price
    }

    public func deletePrice(
        id: UUID,
        confirmed: Bool
    ) async throws {
        guard confirmed else {
            throw PriceProfileManagementError.confirmationRequired
        }
        guard let stored = try await repository.price(id: id) else {
            throw PriceProfileManagementError.priceNotFound(id)
        }
        try Task.checkCancellation()
        try await persist {
            try await repository.deletePrice(
                id: id,
                expectedUpdatedAt: stored.updatedAt
            )
        }
    }

    public func resolve(
        typeIDs: [Int64],
        profileID: UUID? = nil,
        at date: Date
    ) async throws -> PriceResolution {
        let requested = Array(Set(typeIDs)).sorted()
        if let invalid = requested.first(where: { $0 <= 0 }) {
            throw PriceProfileValidationError.invalidTypeID(invalid)
        }
        let profile: PriceProfileSnapshot?
        if let profileID {
            profile = try await requiredProfile(id: profileID)
        } else {
            profile = try await repository.activeProfile()
        }
        guard let profile else {
            return PriceResolution(
                profile: nil,
                pricesByTypeID: [:],
                missingTypeIDs: requested
            )
        }
        let stored = try await repository.prices(profileID: profile.id)
        let requestedSet = Set(requested)
        let valid = stored.filter {
            requestedSet.contains($0.typeID) && $0.isValid(at: date)
        }
        let prices = Dictionary(
            uniqueKeysWithValues: valid.map { ($0.typeID, $0.amount) }
        )
        return PriceResolution(
            profile: profile,
            pricesByTypeID: prices,
            missingTypeIDs: requested.filter { prices[$0] == nil }
        )
    }

    private func requiredProfile(
        id: UUID
    ) async throws -> PriceProfileSnapshot {
        try Task.checkCancellation()
        guard let profile = try await repository.profile(id: id) else {
            throw PriceProfileManagementError.profileNotFound(id)
        }
        return profile
    }

    private func requireUniqueName(
        _ name: String,
        profiles: [PriceProfileSnapshot],
        except excludedID: UUID?
    ) throws {
        let normalized = CatalogSearchText.normalize(name)
        if profiles.contains(where: {
            $0.id != excludedID
                && CatalogSearchText.normalize($0.name) == normalized
        }) {
            throw PriceProfileManagementError.duplicateProfileName(name)
        }
    }

    private func persist(
        _ operation: () async throws -> Void
    ) async throws {
        do {
            try await operation()
        } catch is CancellationError {
            throw CancellationError()
        } catch PriceProfileRepositoryError.staleState {
            throw PriceProfileManagementError.staleState
        } catch let error as PriceProfileManagementError {
            throw error
        } catch {
            throw PriceProfileManagementError.persistenceFailure
        }
    }
}
