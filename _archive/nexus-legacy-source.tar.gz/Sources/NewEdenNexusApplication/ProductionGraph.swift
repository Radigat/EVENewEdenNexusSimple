import Foundation
import NewEdenNexusDomain

public protocol ProductionGraphRepository: Sendable {
    func graph(projectID: UUID) async throws -> ProductionGraphSnapshot?
    func save(_ graph: ProductionGraphSnapshot) async throws
}

public enum ProductionGraphError: Error, Equatable, Sendable {
    case targetSelectionRequired(UUID)
    case archivedProjectIsReadOnly(UUID)
    case targetRecipeMismatch
    case catalogVersionChanged
    case materialItemNotFound(Int64)
    case materialItemUnpublished(Int64)
    case intermediateRecipeResolutionFailed(
        productTypeID: Int64,
        error: RecipeResolutionError
    )
    case ambiguousIntermediateActivities(Int64)
    case recursiveCycle([Int64])
    case maximumDepthExceeded(Int)
    case maximumNodeCountExceeded(Int)
    case runCalculationFailed(ProductionRunCalculationError)
    case materialCalculationFailed(
        ProductionMaterialCalculationError
    )
    case t2IndustryDataFailed(T2IndustryDataError)
    case reactionIndustryDataFailed(ReactionIndustryDataError)
    case reactionCalculationFailed(ReactionCalculationError)
    case materialAggregationFailed(
        ProductionGraphMaterialAggregationError
    )
    case industryRuleFailed(IndustryRuleValidationError)
    case industryPreflightFailed(IndustryPreflightResult)
    case persistenceFailure
}

public struct ProductionGraphExpansionLimits: Equatable, Sendable {
    public static let standard = ProductionGraphExpansionLimits(
        maximumDepth:
            ProductionGraphSnapshot.maximumValidatedDepth,
        maximumNodeCount:
            ProductionGraphSnapshot.maximumValidatedNodeCount
    )

    public let maximumDepth: Int
    public let maximumNodeCount: Int

    public init(maximumDepth: Int, maximumNodeCount: Int) {
        self.maximumDepth = maximumDepth
        self.maximumNodeCount = maximumNodeCount
    }
}

public protocol ProductionGraphManaging: Sendable {
    func graph(
        for project: ProductionProjectSnapshot
    ) async throws -> ProductionGraphSnapshot?

    func generate(
        for project: ProductionProjectSnapshot
    ) async throws -> ProductionGraphSnapshot
}

public enum ProductionGraphFreshness {
    public static func isStale(
        _ graph: ProductionGraphSnapshot,
        for project: ProductionProjectSnapshot
    ) -> Bool {
        guard let target = project.target else {
            return true
        }
        let rootCalculation = graph.nodes.first(where: {
            $0.id == graph.rootNodeID
        })?.runCalculation
        let rootTechLevel = graph.nodes.first(where: {
            $0.id == graph.rootNodeID
        })?.recipe?.techLevel
        return graph.formatVersion
                != ProductionGraphSnapshot.currentFormatVersion
            || rootCalculation == nil
            || graph.edges.contains(where: {
                $0.materialCalculation == nil
            })
            || graph.projectID != project.id
            || graph.projectTargetQuantity != project.targetQuantity
            || graph.targetProductTypeID != target.productTypeID
            || graph.targetActivity != target.activity
            || graph.targetBlueprintTypeID != target.blueprintTypeID
            || graph.catalogBuildNumber != target.catalogBuildNumber
            || graph.catalogContentSHA256
                != target.catalogContentSHA256
            || (
                rootTechLevel != .techII
                    && graph.blueprintMaterialEfficiency
                        != project.materialEfficiency
            )
    }
}

public struct ProductionGraphService:
    ProductionGraphManaging,
    Sendable
{
    private let repository: any ProductionGraphRepository
    private let catalog: any ItemBlueprintCatalogReading
    private let resolver: ResolveRecipeUseCase
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private let limits: ProductionGraphExpansionLimits
    private let t2IndustryData: any T2IndustryDataReading
    private let t2PlanningPolicy: T2StagePlanningPolicy
    private let reactionIndustryData: any ReactionIndustryDataReading
    private let reactionPlanningPolicy: ReactionStagePlanningPolicy

    public init(
        repository: any ProductionGraphRepository,
        catalog: any ItemBlueprintCatalogReading,
        resolver: ResolveRecipeUseCase,
        now: @escaping @Sendable () -> Date = { Date() },
        makeID: @escaping @Sendable () -> UUID = { UUID() },
        limits: ProductionGraphExpansionLimits = .standard,
        t2IndustryData: any T2IndustryDataReading = NoT2IndustryData(),
        t2PlanningPolicy: T2StagePlanningPolicy =
            .regularInventionWithoutDecryptor,
        reactionIndustryData: any ReactionIndustryDataReading =
            NoReactionIndustryData(),
        reactionPlanningPolicy: ReactionStagePlanningPolicy =
            .catalogNeutral
    ) {
        self.repository = repository
        self.catalog = catalog
        self.resolver = resolver
        self.now = now
        self.makeID = makeID
        self.limits = limits
        self.t2IndustryData = t2IndustryData
        self.t2PlanningPolicy = t2PlanningPolicy
        self.reactionIndustryData = reactionIndustryData
        self.reactionPlanningPolicy = reactionPlanningPolicy
    }

    public func graph(
        for project: ProductionProjectSnapshot
    ) async throws -> ProductionGraphSnapshot? {
        try Task.checkCancellation()
        do {
            let graph = try await repository.graph(projectID: project.id)
            try Task.checkCancellation()
            return graph
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as ProductionGraphValidationError {
            throw error
        } catch {
            throw ProductionGraphError.persistenceFailure
        }
    }

    public func generate(
        for project: ProductionProjectSnapshot
    ) async throws -> ProductionGraphSnapshot {
        try Task.checkCancellation()
        guard project.status != .archived else {
            throw ProductionGraphError
                .archivedProjectIsReadOnly(project.id)
        }
        guard let target = project.target else {
            throw ProductionGraphError
                .targetSelectionRequired(project.id)
        }
        guard limits.maximumDepth >= 0 else {
            throw ProductionGraphError
                .maximumDepthExceeded(limits.maximumDepth)
        }
        guard limits.maximumNodeCount >= 1 else {
            throw ProductionGraphError
                .maximumNodeCountExceeded(limits.maximumNodeCount)
        }

        let recipe = try await resolver(
            productTypeID: target.productTypeID,
            activity: Self.catalogActivity(target.activity),
            blueprintTypeID: target.blueprintTypeID
        )
        try Task.checkCancellation()
        guard recipe.productTypeID == target.productTypeID,
              recipe.blueprintTypeID == target.blueprintTypeID,
              recipe.activity == Self.catalogActivity(target.activity) else {
            throw ProductionGraphError.targetRecipeMismatch
        }
        guard recipe.version.buildNumber == target.catalogBuildNumber,
              recipe.version.contentSHA256
                == target.catalogContentSHA256 else {
            throw ProductionGraphError.catalogVersionChanged
        }
        let runCalculation: ProductionRunCalculation
        do {
            runCalculation = try ProductionRunCalculation(
                requestedOutputQuantity: Int64(project.targetQuantity),
                outputQuantityPerRun: recipe.outputQuantityPerRun
            )
        } catch let error as ProductionRunCalculationError {
            throw ProductionGraphError.runCalculationFailed(error)
        }
        let rootStage = try await stagePlan(
            activity: target.activity,
            recipe: recipe,
            requiredRuns: runCalculation.requiredRuns,
            fallbackMaterialEfficiency: project.materialEfficiency,
            expectedVersion: recipe.version,
            isRoot: true
        )

        let rootID = ProductionGraphNodeID(
            rawValue: "root:\(target.productTypeID)"
        )
        let root = ProductionGraphNode(
            id: rootID,
            typeID: target.productTypeID,
            name: target.productName,
            kind: .target,
            depth: 0,
            recipe: ProductionGraphRecipeReference(
                blueprintTypeID: recipe.blueprintTypeID,
                activity: target.activity,
                outputQuantityPerRun: recipe.outputQuantityPerRun,
                timeSeconds: recipe.timeSeconds,
                maxProductionLimit: recipe.maxProductionLimit,
                materialEfficiency:
                    rootStage.materialEfficiency,
                materialEfficiencySource:
                    rootStage.materialEfficiencySource,
                techLevel: rootStage.techLevel,
                blueprintPlanningQuality: rootStage.quality,
                invention: rootStage.invention,
                reactionKind: rootStage.reactionKind,
                requiredReactorTypeID:
                    rootStage.requiredReactorTypeID,
                reactionContext: rootStage.reactionContext,
                reactionTimeCalculation:
                    rootStage.reactionTimeCalculation
            ),
            runCalculation: runCalculation
        )

        let expanded = try await expandChildren(
            parentID: rootID,
            parentActivity: target.activity,
            parentRecipe: recipe,
            parentRunCalculation: runCalculation,
            parentMaterialEfficiency:
                rootStage.materialEfficiency,
            parentReactionContext: rootStage.reactionContext,
            parentReactionModifiers: rootStage.reactionModifiers,
            parentDepth: 0,
            ancestorTypeIDs: [target.productTypeID],
            expectedVersion: recipe.version,
            remainingNodeCapacity:
                limits.maximumNodeCount - 1
        )
        let nodes = [root] + expanded.nodes
        let edges = expanded.edges
        guard nodes.count <= limits.maximumNodeCount else {
            throw ProductionGraphError
                .maximumNodeCountExceeded(limits.maximumNodeCount)
        }
        let materialAggregation:
            ProductionGraphMaterialAggregation
        do {
            materialAggregation = try ProductionGraphMaterialAggregator()
                .aggregate(
                    rootNodeID: rootID,
                    nodes: nodes,
                    edges: edges
                )
        } catch let error as
            ProductionGraphMaterialAggregationError {
            throw ProductionGraphError
                .materialAggregationFailed(error)
        }

        let timestamp = max(now(), project.updatedAt)
        let graph = try ProductionGraphSnapshot(
            id: makeID(),
            projectID: project.id,
            projectTargetQuantity: project.targetQuantity,
            sourceProjectUpdatedAt: project.updatedAt,
            targetProductTypeID: target.productTypeID,
            targetActivity: target.activity,
            targetBlueprintTypeID: target.blueprintTypeID,
            catalogBuildNumber: target.catalogBuildNumber,
            catalogContentSHA256: target.catalogContentSHA256,
            blueprintMaterialEfficiency:
                rootStage.materialEfficiency,
            expansionPolicyVersion:
                ProductionGraphSnapshot.currentExpansionPolicyVersion,
            rootNodeID: rootID,
            nodes: nodes,
            edges: edges,
            materialAggregation: materialAggregation,
            createdAt: timestamp,
            updatedAt: timestamp
        )
        try Task.checkCancellation()
        do {
            try await repository.save(graph)
            return graph
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ProductionGraphError.persistenceFailure
        }
    }

    private struct GraphFragment {
        var nodes: [ProductionGraphNode] = []
        var edges: [ProductionGraphEdge] = []
    }

    private struct StagePlan {
        let materialEfficiency: Int
        let materialEfficiencySource:
            ProductionGraphMaterialEfficiencySource
        let techLevel: IndustryTechLevel?
        let quality: BlueprintPlanningQuality?
        let invention: InventionStageReference?
        let reactionKind: ReactionKind?
        let requiredReactorTypeID: Int64?
        let reactionContext: ReactionPlanningContext?
        let reactionModifiers: ReactionResolvedModifiers?
        let reactionTimeCalculation: ReactionTimeCalculation?
    }

    private func expandChildren(
        parentID: ProductionGraphNodeID,
        parentActivity: ProductionTargetActivity,
        parentRecipe: ResolvedRecipe,
        parentRunCalculation: ProductionRunCalculation,
        parentMaterialEfficiency: Int,
        parentReactionContext: ReactionPlanningContext?,
        parentReactionModifiers: ReactionResolvedModifiers?,
        parentDepth: Int,
        ancestorTypeIDs: [Int64],
        expectedVersion: CatalogDataVersion,
        remainingNodeCapacity: Int
    ) async throws -> GraphFragment {
        var fragment = GraphFragment()
        let materials = parentRecipe.materials.sorted {
            if $0.sortOrder != $1.sortOrder {
                return $0.sortOrder < $1.sortOrder
            }
            return $0.typeID < $1.typeID
        }

        for (index, material) in materials.enumerated() {
            try Task.checkCancellation()
            guard fragment.nodes.count < remainingNodeCapacity else {
                throw ProductionGraphError
                    .maximumNodeCountExceeded(
                        limits.maximumNodeCount
                    )
            }
            let details = try await materialDetails(
                typeID: material.typeID,
                expectedVersion: expectedVersion
            )
            try Task.checkCancellation()
            let childDepth = parentDepth + 1
            guard childDepth <= limits.maximumDepth else {
                throw ProductionGraphError
                    .maximumDepthExceeded(limits.maximumDepth)
            }
            let childID = ProductionGraphNodeID(
                rawValue: [
                    parentID.rawValue,
                    "m\(material.sortOrder)",
                    "t\(material.typeID)",
                    "o\(index)"
                ].joined(separator: "/")
            )
            let edge = try materialEdge(
                parentID: parentID,
                childID: childID,
                baseQuantityPerRun: material.quantity,
                sortOrder: material.sortOrder,
                activity: parentActivity,
                requiredRuns: parentRunCalculation.requiredRuns,
                materialEfficiency: parentMaterialEfficiency,
                reactionContext: parentReactionContext,
                reactionModifiers: parentReactionModifiers
            )

            let supportedActivities = details.summary
                .productionActivities.filter {
                    $0 == .manufacturing || $0 == .reaction
                }
            guard supportedActivities.count <= 1 else {
                throw ProductionGraphError
                    .ambiguousIntermediateActivities(material.typeID)
            }
            if let catalogActivity = supportedActivities.first {
                let childActivity: ProductionTargetActivity =
                    catalogActivity == .manufacturing
                    ? .manufacturing
                    : .reaction
                if ancestorTypeIDs.contains(material.typeID) {
                    throw ProductionGraphError.recursiveCycle(
                        ancestorTypeIDs + [material.typeID]
                    )
                }
                let intermediateRecipe: ResolvedRecipe
                do {
                    intermediateRecipe = try await resolver(
                        productTypeID: material.typeID,
                        activity: catalogActivity,
                        blueprintTypeID: nil
                    )
                } catch is CancellationError {
                    throw CancellationError()
                } catch let error as RecipeResolutionError {
                    throw ProductionGraphError
                        .intermediateRecipeResolutionFailed(
                            productTypeID: material.typeID,
                            error: error
                        )
                }
                try Task.checkCancellation()
                guard intermediateRecipe.version == expectedVersion else {
                    throw ProductionGraphError.catalogVersionChanged
                }
                let incomingQuantity = try requiredIncomingQuantity(
                    edge: edge
                )
                let intermediateRunCalculation:
                    ProductionRunCalculation
                do {
                    intermediateRunCalculation =
                        try ProductionRunCalculation(
                            requestedOutputQuantity: incomingQuantity,
                            outputQuantityPerRun:
                                intermediateRecipe.outputQuantityPerRun
                        )
                } catch let error as ProductionRunCalculationError {
                    throw ProductionGraphError
                        .runCalculationFailed(error)
                }
                let stage = try await stagePlan(
                    activity: childActivity,
                    recipe: intermediateRecipe,
                    requiredRuns:
                        intermediateRunCalculation.requiredRuns,
                    fallbackMaterialEfficiency: 0,
                    expectedVersion: expectedVersion,
                    isRoot: false
                )
                let intermediateNode = ProductionGraphNode(
                    id: childID,
                    typeID: material.typeID,
                    name: details.summary.name,
                    kind: .intermediate,
                    depth: childDepth,
                    recipe: ProductionGraphRecipeReference(
                        blueprintTypeID:
                            intermediateRecipe.blueprintTypeID,
                        activity: childActivity,
                        outputQuantityPerRun:
                            intermediateRecipe.outputQuantityPerRun,
                        timeSeconds: intermediateRecipe.timeSeconds,
                        maxProductionLimit:
                            intermediateRecipe.maxProductionLimit,
                        materialEfficiency:
                            stage.materialEfficiency,
                        materialEfficiencySource:
                            stage.materialEfficiencySource,
                        techLevel: stage.techLevel,
                        blueprintPlanningQuality: stage.quality,
                        invention: stage.invention,
                        reactionKind: stage.reactionKind,
                        requiredReactorTypeID:
                            stage.requiredReactorTypeID,
                        reactionContext: stage.reactionContext,
                        reactionTimeCalculation:
                            stage.reactionTimeCalculation
                    ),
                    runCalculation: intermediateRunCalculation
                )
                fragment.nodes.append(intermediateNode)
                fragment.edges.append(edge)
                let descendants = try await expandChildren(
                    parentID: childID,
                    parentActivity: childActivity,
                    parentRecipe: intermediateRecipe,
                    parentRunCalculation: intermediateRunCalculation,
                    parentMaterialEfficiency:
                        stage.materialEfficiency,
                    parentReactionContext: stage.reactionContext,
                    parentReactionModifiers:
                        stage.reactionModifiers,
                    parentDepth: childDepth,
                    ancestorTypeIDs:
                        ancestorTypeIDs + [material.typeID],
                    expectedVersion: expectedVersion,
                    remainingNodeCapacity:
                        remainingNodeCapacity
                            - fragment.nodes.count
                )
                fragment.nodes.append(contentsOf: descendants.nodes)
                fragment.edges.append(contentsOf: descendants.edges)
            } else {
                fragment.nodes.append(
                    ProductionGraphNode(
                        id: childID,
                        typeID: material.typeID,
                        name: details.summary.name,
                        kind: .material,
                        depth: childDepth,
                        recipe: nil,
                        leafReason: .noProductionRecipe
                    )
                )
                fragment.edges.append(edge)
            }
            guard fragment.nodes.count <= remainingNodeCapacity else {
                throw ProductionGraphError
                    .maximumNodeCountExceeded(
                        limits.maximumNodeCount
                    )
            }
        }
        return fragment
    }

    private func stagePlan(
        activity: ProductionTargetActivity,
        recipe: ResolvedRecipe,
        requiredRuns: Int64,
        fallbackMaterialEfficiency: Int,
        expectedVersion: CatalogDataVersion,
        isRoot: Bool
    ) async throws -> StagePlan {
        switch activity {
        case .manufacturing:
            return try await manufacturingStagePlan(
                blueprintTypeID: recipe.blueprintTypeID,
                requiredRuns: requiredRuns,
                fallbackMaterialEfficiency:
                    fallbackMaterialEfficiency,
                expectedVersion: expectedVersion,
                isRoot: isRoot
            )
        case .reaction:
            let metadata: ReactionFormulaMetadata
            do {
                metadata = try await reactionIndustryData
                    .formulaMetadata(
                        formulaTypeID: recipe.blueprintTypeID,
                        expectedVersion: expectedVersion
                    )
            } catch is CancellationError {
                throw CancellationError()
            } catch let error as ReactionIndustryDataError {
                throw ProductionGraphError
                    .reactionIndustryDataFailed(error)
            }
            guard metadata.version == expectedVersion else {
                throw ProductionGraphError.catalogVersionChanged
            }
            let context = reactionPlanningPolicy.context(
                formulaTypeID: recipe.blueprintTypeID,
                profile: metadata.profile
            )
            let modifiers: ReactionResolvedModifiers
            let time: ReactionTimeCalculation
            do {
                modifiers = try ReactionRuleValidator.resolve(
                    context: context,
                    kind: metadata.kind,
                    profile: metadata.profile
                )
                time = try ReactionTimeCalculation(
                    baseTimeSeconds: recipe.timeSeconds,
                    requiredRuns: requiredRuns,
                    context: context,
                    modifiers: modifiers
                )
            } catch let error as ReactionCalculationError {
                throw ProductionGraphError
                    .reactionCalculationFailed(error)
            }
            return StagePlan(
                materialEfficiency: 0,
                materialEfficiencySource: .reactionFormula,
                techLevel: nil,
                quality: nil,
                invention: nil,
                reactionKind: metadata.kind,
                requiredReactorTypeID: metadata.reactorTypeID,
                reactionContext: context,
                reactionModifiers: modifiers,
                reactionTimeCalculation: time
            )
        }
    }

    private func manufacturingStagePlan(
        blueprintTypeID: Int64,
        requiredRuns: Int64,
        fallbackMaterialEfficiency: Int,
        expectedVersion: CatalogDataVersion,
        isRoot: Bool
    ) async throws -> StagePlan {
        let ruleSet = IndustryRuleSet.verified(
            catalogBuildNumber: expectedVersion.buildNumber,
            catalogContentSHA256: expectedVersion.contentSHA256
        )
        let preflight = IndustryRuleValidator.preflight(
            ruleSet: ruleSet,
            catalogBuildNumber: expectedVersion.buildNumber,
            catalogContentSHA256: expectedVersion.contentSHA256
        )
        guard preflight == .pass else {
            throw ProductionGraphError
                .industryPreflightFailed(preflight)
        }
        let metadata: T2InventionMetadata?
        do {
            metadata = try await t2IndustryData.inventionMetadata(
                inventedBlueprintTypeID: blueprintTypeID,
                expectedVersion: expectedVersion
            )
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as T2IndustryDataError {
            throw ProductionGraphError.t2IndustryDataFailed(error)
        }
        guard let metadata else {
            return StagePlan(
                materialEfficiency: fallbackMaterialEfficiency,
                materialEfficiencySource:
                    isRoot ? .projectBlueprint : .neutralIntermediate,
                techLevel: .techI,
                quality: .manual(
                    blueprintTypeID: blueprintTypeID,
                    materialEfficiency:
                        fallbackMaterialEfficiency,
                    catalogBuildNumber:
                        expectedVersion.buildNumber,
                    catalogContentSHA256:
                        expectedVersion.contentSHA256
                ),
                invention: nil,
                reactionKind: nil,
                requiredReactorTypeID: nil,
                reactionContext: nil,
                reactionModifiers: nil,
                reactionTimeCalculation: nil
            )
        }
        guard metadata.version == expectedVersion else {
            throw ProductionGraphError.catalogVersionChanged
        }

        let quality: BlueprintPlanningQuality
        let source: ProductionGraphMaterialEfficiencySource
        if let override = t2PlanningPolicy
            .qualityOverrideByBlueprintTypeID[blueprintTypeID] {
            do {
                try IndustryRuleValidator.validate(
                    override,
                    ruleSet: ruleSet
                )
            } catch let error as IndustryRuleValidationError {
                throw ProductionGraphError.industryRuleFailed(error)
            }
            quality = override
            source = .t2StageOverride
        } else {
            do {
                quality = try IndustryRuleValidator.inventedQuality(
                    blueprintTypeID: blueprintTypeID,
                    baseLicensedRuns: metadata.baseLicensedRuns,
                    decryptor: t2PlanningPolicy
                        .decryptorByBlueprintTypeID[blueprintTypeID],
                    ruleSet: ruleSet
                )
            } catch let error as IndustryRuleValidationError {
                throw ProductionGraphError.industryRuleFailed(error)
            }
            source = t2PlanningPolicy
                    .decryptorByBlueprintTypeID[blueprintTypeID] == nil
                ? .regularT2Invention
                : .t2StageOverride
        }

        let invention: InventionStageReference?
        if quality.origin == .inventedBPC {
            guard let licensedRuns = quality.licensedRunsPerCopy else {
                throw ProductionGraphError.industryRuleFailed(
                    .invalidLicensedRuns(nil)
                )
            }
            do {
                invention = InventionStageReference(
                    sourceBlueprintTypeID:
                        metadata.sourceBlueprintTypeID,
                    baseProbabilityMillionths:
                        metadata.baseProbabilityMillionths,
                    baseLicensedRuns: metadata.baseLicensedRuns,
                    licensedRunsPerCopy: licensedRuns,
                    requiredSuccessfulCopies:
                        try IndustryRuleValidator
                            .requiredSuccessfulCopies(
                                requiredRuns: requiredRuns,
                                licensedRunsPerCopy: licensedRuns
                            ),
                    materialTypeIDs: metadata.materialTypeIDs
                )
            } catch let error as IndustryRuleValidationError {
                throw ProductionGraphError.industryRuleFailed(error)
            }
        } else {
            invention = nil
        }
        return StagePlan(
            materialEfficiency: quality.materialEfficiency,
            materialEfficiencySource: source,
            techLevel: .techII,
            quality: quality,
            invention: invention,
            reactionKind: nil,
            requiredReactorTypeID: nil,
            reactionContext: nil,
            reactionModifiers: nil,
            reactionTimeCalculation: nil
        )
    }

    private func requiredIncomingQuantity(
        edge: ProductionGraphEdge
    ) throws -> Int64 {
        guard let quantity =
                edge.reactionMaterialCalculation?.effectiveQuantity
                ?? edge.materialCalculation?.effectiveQuantity else {
            throw ProductionGraphError.persistenceFailure
        }
        return quantity
    }

    private func materialEdge(
        parentID: ProductionGraphNodeID,
        childID: ProductionGraphNodeID,
        baseQuantityPerRun: Int64,
        sortOrder: Int,
        activity: ProductionTargetActivity,
        requiredRuns: Int64,
        materialEfficiency: Int,
        reactionContext: ReactionPlanningContext?,
        reactionModifiers: ReactionResolvedModifiers?
    ) throws -> ProductionGraphEdge {
        let calculation: ProductionMaterialCalculation
        do {
            calculation = try ProductionMaterialCalculation(
                activity: activity,
                baseQuantityPerRun: baseQuantityPerRun,
                requiredRuns: requiredRuns,
                materialEfficiency: materialEfficiency
            )
        } catch let error as ProductionMaterialCalculationError {
            throw ProductionGraphError
                .materialCalculationFailed(error)
        }
        let reactionCalculation: ReactionMaterialCalculation?
        if activity == .reaction {
            guard let reactionContext, let reactionModifiers else {
                throw ProductionGraphError.reactionCalculationFailed(
                    .invalidNeutralContext
                )
            }
            do {
                reactionCalculation = try ReactionMaterialCalculation(
                    baseQuantityPerRun: baseQuantityPerRun,
                    requiredRuns: requiredRuns,
                    context: reactionContext,
                    modifiers: reactionModifiers
                )
            } catch let error as ReactionCalculationError {
                throw ProductionGraphError
                    .reactionCalculationFailed(error)
            }
        } else {
            reactionCalculation = nil
        }
        return ProductionGraphEdge(
            parentID: parentID,
            childID: childID,
            baseQuantityPerRun: baseQuantityPerRun,
            sortOrder: sortOrder,
            materialCalculation: calculation,
            reactionMaterialCalculation: reactionCalculation
        )
    }

    private func materialDetails(
        typeID: Int64,
        expectedVersion: CatalogDataVersion
    ) async throws -> CatalogItemDetails {
        let result: CatalogLookupResult<CatalogItemDetails>
        do {
            result = try await catalog.item(typeID: typeID)
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as CatalogQueryError {
            if error == .noActiveDataVersion
                || error == .multipleActiveDataVersions {
                throw ProductionGraphError.catalogVersionChanged
            }
            throw error
        }
        switch result {
        case let .found(details):
            guard details.version == expectedVersion else {
                throw ProductionGraphError.catalogVersionChanged
            }
            guard details.summary.published else {
                throw ProductionGraphError
                    .materialItemUnpublished(typeID)
            }
            return details
        case .notFound:
            throw ProductionGraphError.materialItemNotFound(typeID)
        }
    }

    private static func catalogActivity(
        _ activity: ProductionTargetActivity
    ) -> StaticIndustryActivity {
        switch activity {
        case .manufacturing:
            .manufacturing
        case .reaction:
            .reaction
        }
    }
}
