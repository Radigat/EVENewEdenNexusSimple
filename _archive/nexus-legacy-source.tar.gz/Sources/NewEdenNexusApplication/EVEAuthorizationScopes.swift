import Foundation

public enum EVEAuthorizationScope {
    public static let assets = "esi-assets.read_assets.v1"
    public static let blueprints =
        "esi-characters.read_blueprints.v1"
    public static let industryJobs =
        "esi-industry.read_character_jobs.v1"
    public static let wallet =
        "esi-wallet.read_character_wallet.v1"
    public static let structures =
        "esi-universe.read_structures.v1"

    public static let personalIndustry: [String] = [
        assets,
        blueprints,
        industryJobs
    ].sorted()

    public static let personalIndustryAndWallet: [String] =
        (personalIndustry + [wallet]).sorted()

    public static let personalIndustryAndStructures: [String] =
        (personalIndustry + [structures]).sorted()

    public static let personalIndustryWalletAndStructures: [String] =
        (personalIndustry + [wallet, structures]).sorted()
}

public enum EVEAuthorizationPurpose: Equatable, Sendable {
    case personalIndustry
    case wallet
    case structures
    case walletAndStructures

    public var scopes: [String] {
        switch self {
        case .personalIndustry:
            EVEAuthorizationScope.personalIndustry
        case .wallet:
            EVEAuthorizationScope.personalIndustryAndWallet
        case .structures:
            EVEAuthorizationScope.personalIndustryAndStructures
        case .walletAndStructures:
            EVEAuthorizationScope
                .personalIndustryWalletAndStructures
        }
    }
}
