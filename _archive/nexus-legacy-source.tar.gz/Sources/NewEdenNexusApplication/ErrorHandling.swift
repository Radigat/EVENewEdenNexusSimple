import Foundation

public enum NexusValidationCode: String, Sendable {
    case requiredText = "NEN-VAL-001"
    case requiredSelection = "NEN-VAL-002"
    case positiveInteger = "NEN-VAL-003"
    case moneyAmount = "NEN-VAL-004"
    case dateRange = "NEN-VAL-005"
    case staleInput = "NEN-VAL-006"
}

public struct NexusValidationIssue: Identifiable, Equatable, Sendable {
    public let code: NexusValidationCode
    public let field: String
    public let message: String
    public let recoverySuggestion: String
    private let identifier: String

    public var id: String {
        "\(code.rawValue):\(identifier)"
    }

    private init(
        code: NexusValidationCode,
        field: String,
        message: String,
        recoverySuggestion: String,
        identifier: String? = nil
    ) {
        self.code = code
        self.field = field
        self.message = message
        self.recoverySuggestion = recoverySuggestion
        self.identifier = identifier ?? field
    }

    public static func requiredText(field: String) -> Self {
        Self(
            code: .requiredText,
            field: field,
            message: "Dieses Pflichtfeld darf nicht leer sein.",
            recoverySuggestion: "Gib einen Wert ein."
        )
    }

    public static func requiredSelection(field: String) -> Self {
        Self(
            code: .requiredSelection,
            field: field,
            message: "Es wurde noch keine gültige Auswahl getroffen.",
            recoverySuggestion: "Wähle einen Eintrag aus."
        )
    }

    public static func positiveInteger(field: String) -> Self {
        Self(
            code: .positiveInteger,
            field: field,
            message: "Erforderlich ist eine ganze Zahl größer als null.",
            recoverySuggestion: "Korrigiere die Menge."
        )
    }

    public static func integerRange(
        field: String,
        minimum: Int64,
        maximum: Int64,
        identifier: String? = nil
    ) -> Self {
        Self(
            code: .positiveInteger,
            field: field,
            message: "Erforderlich ist eine ganze Zahl von \(minimum) bis \(maximum).",
            recoverySuggestion: "Korrigiere die Menge.",
            identifier: identifier
        )
    }

    public static func moneyAmount(field: String) -> Self {
        Self(
            code: .moneyAmount,
            field: field,
            message: "Erforderlich ist ein positiver ISK-Betrag mit höchstens zwei Nachkommastellen.",
            recoverySuggestion: "Verwende Ziffern sowie optional Punkt oder Komma."
        )
    }

    public static func dateRange(field: String) -> Self {
        Self(
            code: .dateRange,
            field: field,
            message: "Das Enddatum muss nach dem Startdatum liegen.",
            recoverySuggestion: "Korrigiere den Gültigkeitszeitraum."
        )
    }

    public static func staleInput(field: String) -> Self {
        Self(
            code: .staleInput,
            field: field,
            message: "Die Auswahl oder Vorschau ist nicht mehr aktuell.",
            recoverySuggestion: "Prüfe die Eingaben erneut und erzeuge eine neue Vorschau."
        )
    }
}

public enum NexusUserRetryPolicy: Sendable {
    case unavailable
    case idempotentRead
}

public enum NexusOperation: String, CaseIterable, Hashable, Sendable {
    case applicationStartup = "application_startup"
    case projectLoad = "project_load"
    case projectSave = "project_save"
    case characterSave = "character_save"
    case characterDelete = "character_delete"
    case synchronizationStateSave = "synchronization_state_save"
    case esiCharacterRead = "esi_character_read"
    case esiPersonalDataInspect = "esi_personal_data_inspect"
    case esiPersonalDataApply = "esi_personal_data_apply"
    case esiWalletInspect = "esi_wallet_inspect"
    case esiWalletApply = "esi_wallet_apply"
    case walletAssignmentSave = "wallet_assignment_save"
    case authentication = "authentication"
    case keychainAccess = "keychain_access"
    case keychainDelete = "keychain_delete"
    case backupCreate = "backup_create"
    case backupInspect = "backup_inspect"
    case backupRestore = "backup_restore"
    case sdeInspect = "sde_inspect"
    case sdeStage = "sde_stage"
    case sdeMap = "sde_map"
    case sdeActivate = "sde_activate"
    case catalogQuery = "catalog_query"
    case recipeResolution = "recipe_resolution"
    case productionTargetSelection = "production_target_selection"
    case productionGraph = "production_graph"
    case productionPlanning = "production_planning"
    case purchasingLoad = "purchasing_load"
    case purchasingSave = "purchasing_save"
    case purchasingExport = "purchasing_export"
    case inventoryLoad = "inventory_load"
    case inventorySave = "inventory_save"
    case inventoryImportInspect = "inventory_import_inspect"
    case inventoryImportApply = "inventory_import_apply"
    case priceProfileLoad = "price_profile_load"
    case priceProfileSave = "price_profile_save"
    case priceImportInspect = "price_import_inspect"
    case priceImportApply = "price_import_apply"
    case marketPriceInspect = "market_price_inspect"
    case marketPriceApply = "market_price_apply"
    case reservationLoad = "reservation_load"
    case reservationSave = "reservation_save"
    case reservationConflictLoad = "reservation_conflict_load"
    case reservationConflictSave = "reservation_conflict_save"
    case sdeMetadataCheck = "sde_metadata_check"
    case sdeInstallation = "sde_installation"
    case unexpected = "unexpected"

    public var userRetryPolicy: NexusUserRetryPolicy {
        switch self {
        case .projectLoad,
             .backupInspect,
             .sdeInspect,
             .catalogQuery,
             .recipeResolution,
             .productionTargetSelection,
             .purchasingLoad,
             .inventoryLoad,
             .inventoryImportInspect,
             .priceProfileLoad,
             .priceImportInspect,
             .marketPriceInspect,
             .reservationLoad,
             .reservationConflictLoad,
             .sdeMetadataCheck,
             .esiCharacterRead,
             .esiPersonalDataInspect,
             .esiWalletInspect:
            .idempotentRead
        case .applicationStartup,
             .projectSave,
             .characterSave,
             .characterDelete,
             .synchronizationStateSave,
             .authentication,
             .keychainAccess,
             .keychainDelete,
             .backupCreate,
             .backupRestore,
             .sdeStage,
             .sdeMap,
             .sdeActivate,
             .productionGraph,
             .productionPlanning,
             .purchasingSave,
             .purchasingExport,
             .inventorySave,
             .inventoryImportApply,
             .priceProfileSave,
             .priceImportApply,
             .marketPriceApply,
             .reservationSave,
             .reservationConflictSave,
             .sdeInstallation,
             .esiPersonalDataApply,
             .esiWalletApply,
             .walletAssignmentSave,
             .unexpected:
            .unavailable
        }
    }
}

public enum NexusFailureCode: String, Sendable {
    case localDatabaseUnavailable = "NEN-PER-001"
    case projectSaveFailed = "NEN-PER-002"
    case characterSaveFailed = "NEN-PER-003"
    case characterDeleteFailed = "NEN-PER-004"
    case synchronizationStateSaveFailed = "NEN-PER-005"
    case projectLoadFailed = "NEN-PER-006"
    case authenticationFailed = "NEN-AUTH-001"
    case keychainDeleteFailed = "NEN-AUTH-002"
    case keychainAccessFailed = "NEN-AUTH-003"
    case backupCreateFailed = "NEN-BACKUP-001"
    case backupInspectFailed = "NEN-BACKUP-002"
    case backupRestoreFailed = "NEN-BACKUP-003"
    case sdeInspectFailed = "NEN-SDE-001"
    case sdeStageFailed = "NEN-SDE-002"
    case sdeMapFailed = "NEN-SDE-003"
    case sdeActivateFailed = "NEN-SDE-004"
    case catalogQueryFailed = "NEN-SDE-005"
    case recipeResolutionFailed = "NEN-SDE-008"
    case productionTargetSelectionFailed = "NEN-PROJ-001"
    case productionGraphFailed = "NEN-GRAPH-001"
    case productionPlanningFailed = "NEN-PLAN-001"
    case purchasingLoadFailed = "NEN-BUY-001"
    case purchasingSaveFailed = "NEN-BUY-002"
    case purchasingExportFailed = "NEN-BUY-003"
    case inventoryLoadFailed = "NEN-INV-001"
    case inventorySaveFailed = "NEN-INV-002"
    case inventoryImportInspectFailed = "NEN-INV-003"
    case inventoryImportApplyFailed = "NEN-INV-004"
    case priceProfileLoadFailed = "NEN-PRICE-001"
    case priceProfileSaveFailed = "NEN-PRICE-002"
    case priceImportInspectFailed = "NEN-PRICE-003"
    case priceImportApplyFailed = "NEN-PRICE-004"
    case marketPriceInspectFailed = "NEN-MKT-001"
    case marketPriceApplyFailed = "NEN-MKT-002"
    case reservationLoadFailed = "NEN-RES-001"
    case reservationSaveFailed = "NEN-RES-002"
    case reservationConflictLoadFailed = "NEN-RES-003"
    case reservationConflictSaveFailed = "NEN-RES-004"
    case sdeMetadataCheckFailed = "NEN-SDE-006"
    case sdeInstallationFailed = "NEN-SDE-007"
    case esiCharacterReadFailed = "NEN-ESI-001"
    case esiPersonalDataInspectFailed = "NEN-ESI-002"
    case esiPersonalDataApplyFailed = "NEN-ESI-003"
    case esiWalletInspectFailed = "NEN-ESI-004"
    case esiWalletApplyFailed = "NEN-ESI-005"
    case walletAssignmentSaveFailed = "NEN-FIN-001"
    case unexpected = "NEN-GEN-001"
}

public enum NexusFailureCategory: String, Sendable {
    case lifecycle
    case persistence
    case projects
    case inventory
    case prices
    case reservations
    case authentication
    case backup
    case staticData
    case synchronization
    case general
}

public enum DiagnosticLevel: String, Sendable {
    case info
    case warning
    case error
}

public enum DiagnosticValue: Equatable, Sendable {
    case publicValue(String)
    case privateValue(String)

    fileprivate var redacted: String {
        switch self {
        case .publicValue(let value):
            value
                .replacingOccurrences(of: "\n", with: " ")
                .replacingOccurrences(of: "\r", with: " ")
        case .privateValue:
            "<redacted>"
        }
    }
}

public struct DiagnosticEvent: Equatable, Sendable {
    public let level: DiagnosticLevel
    public let category: NexusFailureCategory
    public let name: String
    public let code: String
    public let operation: NexusOperation
    public let correlationID: UUID
    public let metadata: [String: DiagnosticValue]

    public init(
        level: DiagnosticLevel,
        category: NexusFailureCategory,
        name: String,
        code: String,
        operation: NexusOperation,
        correlationID: UUID,
        metadata: [String: DiagnosticValue] = [:]
    ) {
        self.level = level
        self.category = category
        self.name = name
        self.code = code
        self.operation = operation
        self.correlationID = correlationID
        self.metadata = metadata
    }

    public var redactedDescription: String {
        let baseFields = [
            "category=\(category.rawValue)",
            "code=\(code)",
            "correlation_id=\(correlationID.uuidString)",
            "event=\(name)",
            "level=\(level.rawValue)",
            "operation=\(operation.rawValue)"
        ]
        let metadataFields = metadata.keys.sorted().map { key in
            "\(key)=\(metadata[key]?.redacted ?? "<redacted>")"
        }
        return (baseFields + metadataFields).joined(separator: " ")
    }
}

public protocol DiagnosticLogging: Sendable {
    func log(_ event: DiagnosticEvent)
}

public struct NexusFailure: Error, Identifiable, Equatable, Sendable {
    public let id: UUID
    public let code: NexusFailureCode
    public let category: NexusFailureCategory
    public let level: DiagnosticLevel
    public let operation: NexusOperation
    public let title: String
    public let message: String
    public let recoverySuggestion: String
    public let underlyingErrorType: String
    public let diagnosticReason: String?

    public init(
        id: UUID,
        code: NexusFailureCode,
        category: NexusFailureCategory,
        level: DiagnosticLevel,
        operation: NexusOperation,
        title: String,
        message: String,
        recoverySuggestion: String,
        underlyingErrorType: String,
        diagnosticReason: String? = nil
    ) {
        self.id = id
        self.code = code
        self.category = category
        self.level = level
        self.operation = operation
        self.title = title
        self.message = message
        self.recoverySuggestion = recoverySuggestion
        self.underlyingErrorType = underlyingErrorType
        self.diagnosticReason = diagnosticReason
    }

    public var diagnosticEvent: DiagnosticEvent {
        var metadata: [String: DiagnosticValue] = [
            "error_type": .publicValue(underlyingErrorType)
        ]
        if let diagnosticReason {
            metadata["error_reason"] = .publicValue(diagnosticReason)
        }
        return DiagnosticEvent(
            level: level,
            category: category,
            name: "operation_failed",
            code: code.rawValue,
            operation: operation,
            correlationID: id,
            metadata: metadata
        )
    }
}

public enum NexusFailureMapper {
    public static func map(
        _ error: any Error,
        operation: NexusOperation,
        correlationID: UUID = UUID()
    ) -> NexusFailure {
        let presentation = presentation(for: operation)
        return NexusFailure(
            id: correlationID,
            code: presentation.code,
            category: presentation.category,
            level: .error,
            operation: operation,
            title: presentation.title,
            message: presentation.message,
            recoverySuggestion: presentation.recoverySuggestion,
            underlyingErrorType: String(reflecting: type(of: error)),
            diagnosticReason:
                (error as? EVEAuthenticationError)?.diagnosticReason
                ?? (error as? ESICharacterSyncError)?.diagnosticReason
                ?? (error as? ESIPersonalDataError)?.diagnosticReason
                ?? (error as? ESIWalletError)?.diagnosticReason
                ?? (error as? WalletAssignmentServiceError)?
                    .diagnosticReason
        )
    }

    private static func presentation(
        for operation: NexusOperation
    ) -> (
        code: NexusFailureCode,
        category: NexusFailureCategory,
        title: String,
        message: String,
        recoverySuggestion: String
    ) {
        switch operation {
        case .applicationStartup:
            (
                .localDatabaseUnavailable,
                .lifecycle,
                "Lokale Datenbank nicht verfügbar",
                "New Eden Nexus konnte die lokale Datenbank nicht öffnen.",
                "Versuche es erneut. Die Datenbank wird nicht automatisch gelöscht oder ersetzt."
            )
        case .projectLoad:
            (
                .projectLoadFailed,
                .projects,
                "Projekte nicht geladen",
                "Die lokalen Produktionsprojekte konnten nicht vollständig gelesen werden.",
                "Versuche die Ansicht erneut zu laden."
            )
        case .projectSave:
            (
                .projectSaveFailed,
                .projects,
                "Projekt nicht gespeichert",
                "Das Produktionsprojekt konnte nicht sicher gespeichert werden.",
                "Prüfe deine Eingaben und versuche das Speichern erneut."
            )
        case .characterSave:
            (
                .characterSaveFailed,
                .persistence,
                "Charakter nicht gespeichert",
                "Die lokale Charakteränderung konnte nicht sicher gespeichert werden.",
                "Versuche den Vorgang erneut. Bereits gespeicherte Daten bleiben erhalten."
            )
        case .characterDelete:
            (
                .characterDeleteFailed,
                .persistence,
                "Charakter nicht entfernt",
                "Der Charakter konnte nicht vollständig entfernt werden.",
                "Versuche den Vorgang erneut und prüfe anschließend die Charakterliste."
            )
        case .synchronizationStateSave:
            (
                .synchronizationStateSaveFailed,
                .synchronization,
                "Status nicht gespeichert",
                "Der lokale Synchronisationsstatus konnte nicht gespeichert werden.",
                "Versuche die Statusänderung erneut."
            )
        case .esiCharacterRead:
            (
                .esiCharacterReadFailed,
                .synchronization,
                "Charakterdaten nicht aktualisiert",
                "Die öffentlichen ESI-Charakterdaten konnten nicht aktualisiert werden.",
                "Verwende den lokalen Stand oder versuche die Aktualisierung nach Ablauf der Serverfrist erneut."
            )
        case .esiPersonalDataInspect:
            (
                .esiPersonalDataInspectFailed,
                .synchronization,
                "Persönliche EVE-Daten nicht geprüft",
                "Assets, Blueprints und Industry Jobs konnten nicht vollständig als Vorschau geladen werden.",
                "Erneuere bei Bedarf die drei Leseberechtigungen und starte die Prüfung erneut. Der lokale Stand bleibt erhalten."
            )
        case .esiPersonalDataApply:
            (
                .esiPersonalDataApplyFailed,
                .synchronization,
                "ESI-Vorschau nicht übernommen",
                "Der geprüfte persönliche ESI-Datenstand konnte nicht atomar gespeichert werden.",
                "Der bisherige Stand bleibt erhalten. Erzeuge eine neue Vorschau und bestätige sie erneut."
            )
        case .esiWalletInspect:
            (
                .esiWalletInspectFailed,
                .synchronization,
                "Wallet-Daten nicht geprüft",
                "Kontostand, Journal und Transaktionen konnten nicht vollständig als Vorschau geladen werden.",
                "Erneuere bei Bedarf die Wallet-Leseberechtigung und starte die Prüfung erneut. Der lokale Stand bleibt erhalten."
            )
        case .esiWalletApply:
            (
                .esiWalletApplyFailed,
                .synchronization,
                "Wallet-Vorschau nicht übernommen",
                "Der geprüfte Wallet-Datenstand konnte nicht atomar gespeichert werden.",
                "Der bisherige Stand bleibt erhalten. Erzeuge eine neue Vorschau und bestätige sie erneut."
            )
        case .walletAssignmentSave:
            (
                .walletAssignmentSaveFailed,
                .projects,
                "Wallet-Buchung nicht zugeordnet",
                "Die bestätigte Teil- oder Vollzuordnung konnte nicht sicher gespeichert werden.",
                "Prüfe Projekt, Menge und noch nicht zugeordneten Betrag und erzeuge eine neue Vorschau."
            )
        case .authentication:
            (
                .authenticationFailed,
                .authentication,
                "Verbindung fehlgeschlagen",
                "Die Verbindung mit EVE Online konnte nicht abgeschlossen werden.",
                "Prüfe die Konfiguration und starte die Anmeldung erneut."
            )
        case .keychainAccess:
            (
                .keychainAccessFailed,
                .authentication,
                "Lokaler EVE-Zugang nicht verfügbar",
                "Der EVE-Zugang konnte im macOS-Schlüsselbund nicht gelesen oder gespeichert werden.",
                "Starte einen stabil lokal signierten App-Build und verbinde den Charakter erneut."
            )
        case .keychainDelete:
            (
                .keychainDeleteFailed,
                .authentication,
                "Zugangsdaten nicht entfernt",
                "Die lokalen Zugangsdaten konnten nicht sicher aus dem Schlüsselbund entfernt werden.",
                "Versuche das Entfernen erneut."
            )
        case .backupCreate:
            (
                .backupCreateFailed,
                .backup,
                "Backup nicht erstellt",
                "Die lokale Datensicherung konnte nicht sicher erstellt werden.",
                "Prüfe den Speicherort und versuche die Sicherung erneut."
            )
        case .backupInspect:
            (
                .backupInspectFailed,
                .backup,
                "Backup nicht verwendbar",
                "Die ausgewählte Datensicherung konnte nicht vollständig geprüft werden.",
                "Wähle eine andere Sicherung oder erstelle ein neues Backup."
            )
        case .backupRestore:
            (
                .backupRestoreFailed,
                .backup,
                "Wiederherstellung nicht abgeschlossen",
                "Die lokalen Daten konnten nicht sicher wiederhergestellt werden.",
                "Die aktuellen Daten wurden geschützt. Prüfe das Sicherheitsbackup und versuche es erneut."
            )
        case .sdeInspect:
            (
                .sdeInspectFailed,
                .staticData,
                "Statische Daten nicht verwendbar",
                "Der ausgewählte SDE-Datenstand konnte nicht vollständig geprüft werden.",
                "Prüfe Buildnummer und Quelldateien oder wähle einen anderen Datenstand."
            )
        case .sdeStage:
            (
                .sdeStageFailed,
                .staticData,
                "Statische Daten nicht vorbereitet",
                "Der geprüfte SDE-Datenstand konnte nicht sicher vorbereitet werden.",
                "Prüfe den Speicherort und starte die Vorbereitung erneut."
            )
        case .sdeMap:
            (
                .sdeMapFailed,
                .staticData,
                "Statische Daten nicht lesbar",
                "Der vorbereitete SDE-Datenstand konnte nicht fachlich zugeordnet werden.",
                "Prüfe das Datenpaket und verwende einen vollständig validierten Datenstand."
            )
        case .sdeActivate:
            (
                .sdeActivateFailed,
                .staticData,
                "Statische Daten nicht aktiviert",
                "Der geprüfte Datenstand konnte nicht vollständig in der lokalen Datenbank aktiviert werden.",
                "Der bisher aktive Datenstand bleibt erhalten. Versuche den Import erneut."
            )
        case .catalogQuery:
            (
                .catalogQueryFailed,
                .staticData,
                "Katalog nicht verfügbar",
                "Der lokale Item- und Blueprintkatalog konnte nicht vollständig gelesen werden.",
                "Prüfe den aktiven Datenstand und versuche die Abfrage erneut."
            )
        case .recipeResolution:
            (
                .recipeResolutionFailed,
                .staticData,
                "Produktionsrezept nicht verfügbar",
                "Das angeforderte Produktionsrezept konnte nicht vollständig und eindeutig aufgelöst werden.",
                "Prüfe Aktivität, Blueprintauswahl und Diagnosecode des aktiven SDE-Datenstands."
            )
        case .productionTargetSelection:
            (
                .productionTargetSelectionFailed,
                .projects,
                "Produktionsziel nicht übernommen",
                "Das Zielprodukt konnte nicht vollständig gegen den lokalen EVE-Katalog geprüft werden.",
                "Prüfe Produkt, Aktivität und Blueprint und wähle das Ziel erneut aus."
            )
        case .productionGraph:
            (
                .productionGraphFailed,
                .projects,
                "Produktionsgraph nicht verfügbar",
                "Der Produktionsgraph konnte nicht vollständig erzeugt oder geladen werden.",
                "Prüfe Produktionsziel und lokalen SDE-Datenstand und versuche es erneut."
            )
        case .productionPlanning:
            (
                .productionPlanningFailed,
                .projects,
                "Produktionsplanung nicht verfügbar",
                "Build-or-Buy, Lagerabzug oder Fehlmengen konnten nicht vollständig berechnet oder gespeichert werden.",
                "Aktualisiere Graph und Lagerdaten und erzeuge anschließend eine neue Vorschau."
            )
        case .purchasingLoad:
            (
                .purchasingLoadFailed,
                .projects,
                "Einkaufsliste nicht verfügbar",
                "Die aktuellen projektübergreifenden Einkaufsmengen konnten nicht vollständig berechnet werden.",
                "Aktualisiere die betroffenen Produktionspläne und lade die Einkaufsliste erneut."
            )
        case .purchasingSave:
            (
                .purchasingSaveFailed,
                .projects,
                "Kauf-Fortschritt nicht gespeichert",
                "Die bestätigten projektbezogenen Kaufmengen konnten nicht sicher gespeichert werden.",
                "Erzeuge eine neue Vorschau und bestätige die Änderungen erneut."
            )
        case .purchasingExport:
            (
                .purchasingExportFailed,
                .projects,
                "Einkaufsliste nicht exportiert",
                "Die CSV-Datei konnte am ausgewählten Ort nicht gespeichert werden.",
                "Prüfe den Speicherort und starte den Export erneut."
            )
        case .inventoryLoad:
            (
                .inventoryLoadFailed,
                .inventory,
                "Bestände nicht geladen",
                "Die lokalen Lager und Bestandspositionen konnten nicht vollständig gelesen werden.",
                "Versuche die Ansicht erneut zu laden. Gespeicherte Daten werden nicht verändert."
            )
        case .inventorySave:
            (
                .inventorySaveFailed,
                .inventory,
                "Bestandseinstellung nicht geändert",
                "Die Lager-, Bestands- oder Verfügbarkeitseinstellung konnte nicht sicher gespeichert werden.",
                "Prüfe Lagerauswahl, Materialregel und Menge und versuche es erneut."
            )
        case .inventoryImportInspect:
            (
                .inventoryImportInspectFailed,
                .inventory,
                "CSV nicht verwendbar",
                "Die Bestandsdatei konnte nicht vollständig geprüft werden.",
                "Prüfe Kodierung, Trennzeichen und Spaltenzuordnung und erzeuge die Vorschau erneut."
            )
        case .inventoryImportApply:
            (
                .inventoryImportApplyFailed,
                .inventory,
                "CSV-Import nicht gespeichert",
                "Die bestätigten Bestandsänderungen wurden nicht vollständig übernommen.",
                "Erzeuge eine neue Vorschau. Der vorherige Bestand bleibt bei einem fehlgeschlagenen Import erhalten."
            )
        case .priceProfileLoad:
            (
                .priceProfileLoadFailed,
                .prices,
                "Preisprofile nicht geladen",
                "Die lokalen Preisprofile und manuellen Preise konnten nicht vollständig gelesen werden.",
                "Versuche die Ansicht erneut zu laden. Gespeicherte Preise werden nicht verändert."
            )
        case .priceProfileSave:
            (
                .priceProfileSaveFailed,
                .prices,
                "Preisprofil nicht geändert",
                "Das Profil oder der manuelle Preis konnte nicht sicher gespeichert werden.",
                "Prüfe Profilname, Item, ISK-Betrag und Gültigkeit und versuche es erneut."
            )
        case .priceImportInspect:
            (
                .priceImportInspectFailed,
                .prices,
                "Preisdatei nicht verwendbar",
                "Die CSV-Preisdatei konnte nicht vollständig geprüft werden.",
                "Prüfe Kodierung, Trennzeichen, Dezimalformat und Spaltenzuordnung und erzeuge die Vorschau erneut."
            )
        case .priceImportApply:
            (
                .priceImportApplyFailed,
                .prices,
                "Preisimport nicht gespeichert",
                "Die bestätigten Preisänderungen wurden nicht vollständig übernommen.",
                "Erzeuge eine neue Vorschau. Die bisherigen Preise bleiben bei einem fehlgeschlagenen Import erhalten."
            )
        case .marketPriceInspect:
            (
                .marketPriceInspectFailed,
                .prices,
                "Marktpreise nicht geprüft",
                "Die öffentlichen ESI-Verkaufsorders konnten nicht vollständig und sicher ausgewertet werden.",
                "Prüfe Region, optionale Location, Netzwerk und Cache und erzeuge die Vorschau erneut."
            )
        case .marketPriceApply:
            (
                .marketPriceApplyFailed,
                .prices,
                "Marktpreise nicht gespeichert",
                "Die bestätigten Materialpreise konnten nicht atomar übernommen werden.",
                "Erzeuge eine neue Marktvorschau. Die bisherigen Preise bleiben bei einem fehlgeschlagenen Import erhalten."
            )
        case .reservationLoad:
            (
                .reservationLoadFailed,
                .reservations,
                "Reservierungen nicht geladen",
                "Der aktuelle Projekt-, Bestands- oder Reservierungsstand konnte nicht vollständig gelesen werden.",
                "Prüfe den Produktionsgraphen und erzeuge die Reservierungsvorschau erneut."
            )
        case .reservationSave:
            (
                .reservationSaveFailed,
                .reservations,
                "Reservierung nicht geändert",
                "Die bestätigten Reservierungsänderungen konnten nicht atomar gespeichert werden.",
                "Erzeuge eine neue Vorschau und prüfe verfügbare Menge sowie zwischenzeitliche Änderungen."
            )
        case .reservationConflictLoad:
            (
                .reservationConflictLoadFailed,
                .reservations,
                "Reservierungskonflikte nicht geprüft",
                "Der aktuelle Bedarf, Sicherheitsbestand oder konkurrierende Reservierungsstand konnte nicht vollständig gelesen werden.",
                "Aktualisiere Produktionsgraph und Reservierungsdaten und starte die Konfliktprüfung erneut."
            )
        case .reservationConflictSave:
            (
                .reservationConflictSaveFailed,
                .reservations,
                "Konfliktauflösung nicht gespeichert",
                "Die bestätigten Reduktionen oder Freigaben konnten nicht atomar gespeichert werden.",
                "Erzeuge eine neue Konfliktvorschau. Zwischenzeitlich geänderte Reservierungen bleiben unverändert."
            )
        case .sdeMetadataCheck:
            (
                .sdeMetadataCheckFailed,
                .staticData,
                "SDE-Aktualität nicht geprüft",
                "Die offiziellen SDE-Metadaten konnten nicht vollständig geprüft werden.",
                "Der lokale Datenstand bleibt verfügbar. Versuche die Prüfung später erneut."
            )
        case .sdeInstallation:
            (
                .sdeInstallationFailed,
                .staticData,
                "SDE-Update nicht installiert",
                "Der neue statische Datenstand konnte nicht vollständig und sicher aktiviert werden.",
                "Der zuletzt geprüfte Datenstand bleibt verfügbar. Prüfe den Updatebericht und versuche es später erneut."
            )
        case .unexpected:
            (
                .unexpected,
                .general,
                "Unerwarteter Fehler",
                "Der Vorgang konnte nicht abgeschlossen werden.",
                "Versuche den Vorgang erneut. Bleibt der Fehler bestehen, notiere den Diagnosecode."
            )
        }
    }
}

private extension ESIWalletError {
    var diagnosticReason: String {
        switch self {
        case .authorizationRequired:
            "authorization_required"
        case .permissionDenied:
            "wallet_scope_missing"
        case .offline:
            "offline"
        case .rateLimited:
            "rate_limited"
        case .errorLimited:
            "error_limited"
        case .serverUnavailable:
            "server_unavailable"
        case .stalePreview:
            "stale_preview"
        case .previewNotFound:
            "preview_not_found"
        case .invalidConfiguration:
            "invalid_configuration"
        case .invalidCharacterID:
            "invalid_character_id"
        case .invalidResponse:
            "invalid_response"
        case .responseTooLarge:
            "response_too_large"
        case .pageLimitExceeded:
            "page_limit_exceeded"
        case .recordLimitExceeded:
            "record_limit_exceeded"
        case .inconsistentPagination(let issue):
            "inconsistent_pagination_\(issue.rawValue)"
        case .transport:
            "transport"
        case .cacheCorrupted:
            "cache_corrupted"
        case .cacheWriteFailed:
            "cache_write_failed"
        }
    }
}

private extension WalletAssignmentServiceError {
    var diagnosticReason: String {
        switch self {
        case .sourceNotFound:
            "source_not_found"
        case .sourceNotAssignable:
            "source_not_assignable"
        case .confirmationRequired:
            "confirmation_required"
        case .stalePreview:
            "stale_preview"
        case .previewNotFound:
            "preview_not_found"
        case .persistenceFailure:
            "persistence_failure"
        }
    }
}
