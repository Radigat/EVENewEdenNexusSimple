import Foundation
import NewEdenNexusApplication
import CryptoKit

public actor CachedSDEArchiveDownloader:
    SDEArchiveDownloading,
    SDEArchivePrefetching {
    private struct Metadata: Codable {
        let archive: SDEPrefetchedArchive
        let officialURL: URL
        let validators: SDEHTTPValidators
        let archiveSHA256: String
    }

    private enum OperationOwner {
        case base
        case cache
    }

    private let base: any SDEArchiveDownloading
    private let cacheDirectoryURL: URL
    private let fileManager: FileManager
    private let now: @Sendable () -> Date
    private var operationOwners: [UUID: OperationOwner] = [:]

    public init(
        base: any SDEArchiveDownloading,
        cacheDirectoryURL: URL,
        fileManager: FileManager = .default,
        now: @escaping @Sendable () -> Date = Date.init
    ) {
        self.base = base
        self.cacheDirectoryURL = cacheDirectoryURL
        self.fileManager = fileManager
        self.now = now
    }

    public func prefetch(
        buildNumber: Int
    ) async throws -> SDEPrefetchedArchive {
        if let existing = try await prefetchedArchive(
            buildNumber: buildNumber
        ) {
            return existing
        }
        try prepareCacheDirectory()
        let operationID = UUID()
        do {
            let download = try await base.download(
                SDEArchiveDownloadRequest(
                    operationID: operationID,
                    buildNumber: buildNumber
                )
            )
            let archive = SDEPrefetchedArchive(
                buildNumber: buildNumber,
                byteCount: download.byteCount,
                downloadedAt: now()
            )
            let partial = cacheDirectoryURL.appendingPathComponent(
                ".\(buildNumber)-\(operationID.uuidString).partial"
            )
            let final = archiveURL(buildNumber: buildNumber)
            try fileManager.copyItem(at: download.archiveURL, to: partial)
            try validateRegularFile(partial, byteCount: download.byteCount)
            let archiveSHA256 = try sha256(at: partial)
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: partial.path
            )
            try fileManager.moveItem(at: partial, to: final)
            try writeMetadata(
                Metadata(
                    archive: archive,
                    officialURL: download.officialURL,
                    validators: download.validators,
                    archiveSHA256: archiveSHA256
                ),
                buildNumber: buildNumber
            )
            try await base.cleanup(operationID: operationID)
            return archive
        } catch {
            try? await base.cleanup(operationID: operationID)
            try? removeFiles(buildNumber: buildNumber)
            throw error
        }
    }

    public func prefetchedArchive(
        buildNumber: Int
    ) async throws -> SDEPrefetchedArchive? {
        guard buildNumber > 0 else {
            throw SDEInstallationError.invalidBuildNumber
        }
        let archiveURL = archiveURL(buildNumber: buildNumber)
        let metadataURL = metadataURL(buildNumber: buildNumber)
        let archiveExists = fileManager.fileExists(atPath: archiveURL.path)
        let metadataExists = fileManager.fileExists(atPath: metadataURL.path)
        guard archiveExists || metadataExists else {
            return nil
        }
        guard archiveExists && metadataExists else {
            try removeFiles(buildNumber: buildNumber)
            return nil
        }
        do {
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let metadata = try decoder.decode(
                Metadata.self,
                from: Data(contentsOf: metadataURL)
            )
            let expectedURL = try CCPSDEArchiveDownloader.officialURL(
                buildNumber: buildNumber
            )
            guard metadata.archive.buildNumber == buildNumber,
                  metadata.archive.byteCount > 0,
                  metadata.officialURL == expectedURL else {
                throw SDEInstallationError.damagedArchive
            }
            try validateRegularFile(
                archiveURL,
                byteCount: metadata.archive.byteCount
            )
            guard try sha256(at: archiveURL) == metadata.archiveSHA256 else {
                throw SDEInstallationError.damagedArchive
            }
            return metadata.archive
        } catch {
            try removeFiles(buildNumber: buildNumber)
            return nil
        }
    }

    public func removePrefetchedArchive(
        buildNumber: Int
    ) async throws {
        try removeFiles(buildNumber: buildNumber)
    }

    public func download(
        _ request: SDEArchiveDownloadRequest
    ) async throws -> SDEArchiveDownload {
        if let archive = try await cachedDownload(request) {
            operationOwners[request.operationID] = .cache
            return archive
        }
        let download = try await base.download(request)
        operationOwners[request.operationID] = .base
        return download
    }

    public func cleanup(operationID: UUID) async throws {
        let owner = operationOwners.removeValue(forKey: operationID)
        switch owner {
        case .cache:
            let directory = handoffDirectory(operationID: operationID)
            if fileManager.fileExists(atPath: directory.path) {
                try fileManager.removeItem(at: directory)
            }
        case .base:
            try await base.cleanup(operationID: operationID)
        case nil:
            try await base.cleanup(operationID: operationID)
        }
    }

    private func cachedDownload(
        _ request: SDEArchiveDownloadRequest
    ) async throws -> SDEArchiveDownload? {
        guard let cached = try await prefetchedArchive(
            buildNumber: request.buildNumber
        ) else {
            return nil
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let metadata = try decoder.decode(
            Metadata.self,
            from: Data(
                contentsOf: metadataURL(buildNumber: request.buildNumber)
            )
        )
        let handoff = handoffDirectory(operationID: request.operationID)
        try fileManager.createDirectory(
            at: handoff,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700]
        )
        let target = handoff.appendingPathComponent(
            archiveURL(buildNumber: request.buildNumber).lastPathComponent
        )
        do {
            try fileManager.copyItem(
                at: archiveURL(buildNumber: request.buildNumber),
                to: target
            )
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: target.path
            )
            try validateRegularFile(target, byteCount: cached.byteCount)
            guard try sha256(at: target) == metadata.archiveSHA256 else {
                throw SDEInstallationError.damagedArchive
            }
            return SDEArchiveDownload(
                operationID: request.operationID,
                buildNumber: request.buildNumber,
                officialURL: metadata.officialURL,
                archiveURL: target,
                byteCount: cached.byteCount,
                httpStatus: 200,
                validators: metadata.validators,
                cacheDecision: .revalidated
            )
        } catch {
            try? fileManager.removeItem(at: handoff)
            throw error
        }
    }

    private func prepareCacheDirectory() throws {
        if !fileManager.fileExists(atPath: cacheDirectoryURL.path) {
            try fileManager.createDirectory(
                at: cacheDirectoryURL,
                withIntermediateDirectories: true,
                attributes: [.posixPermissions: 0o700]
            )
        }
        let values = try cacheDirectoryURL.resourceValues(
            forKeys: [.isDirectoryKey, .isSymbolicLinkKey]
        )
        guard values.isDirectory == true,
              values.isSymbolicLink != true else {
            throw SDEInstallationError.transport
        }
    }

    private func writeMetadata(
        _ metadata: Metadata,
        buildNumber: Int
    ) throws {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        let url = metadataURL(buildNumber: buildNumber)
        try encoder.encode(metadata).write(to: url, options: [.atomic])
        try fileManager.setAttributes(
            [.posixPermissions: 0o600],
            ofItemAtPath: url.path
        )
    }

    private func validateRegularFile(
        _ url: URL,
        byteCount: Int64
    ) throws {
        let values = try url.resourceValues(
            forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]
        )
        guard values.isRegularFile == true,
              values.isSymbolicLink != true,
              values.fileSize.map(Int64.init) == byteCount else {
            throw SDEInstallationError.damagedArchive
        }
    }

    private func sha256(at url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer {
            try? handle.close()
        }
        var hasher = SHA256()
        while true {
            let data = try handle.read(upToCount: 1_048_576) ?? Data()
            guard !data.isEmpty else {
                break
            }
            hasher.update(data: data)
        }
        return hasher.finalize().hexString
    }

    private func removeFiles(buildNumber: Int) throws {
        for url in [
            archiveURL(buildNumber: buildNumber),
            metadataURL(buildNumber: buildNumber)
        ] where fileManager.fileExists(atPath: url.path) {
            try fileManager.removeItem(at: url)
        }
    }

    private func archiveURL(buildNumber: Int) -> URL {
        cacheDirectoryURL.appendingPathComponent(
            "eve-online-static-data-\(buildNumber)-jsonl.zip"
        )
    }

    private func metadataURL(buildNumber: Int) -> URL {
        cacheDirectoryURL.appendingPathComponent(
            "eve-online-static-data-\(buildNumber)-jsonl.json"
        )
    }

    private func handoffDirectory(operationID: UUID) -> URL {
        cacheDirectoryURL
            .appendingPathComponent("handoff", isDirectory: true)
            .appendingPathComponent(
                operationID.uuidString,
                isDirectory: true
            )
    }
}
