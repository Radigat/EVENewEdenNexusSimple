import Foundation
import NewEdenNexusApplication

public struct ESICharacterClientConfiguration: Equatable, Sendable {
    public let baseURL: URL
    public let compatibilityDate: String
    public let userAgent: SDEUserAgentConfiguration
    public let timeout: TimeInterval
    public let maximumResponseBytes: Int
    public let retryDelay: TimeInterval

    public init(
        baseURL: URL? = nil,
        compatibilityDate: String,
        userAgent: SDEUserAgentConfiguration,
        timeout: TimeInterval = 20,
        maximumResponseBytes: Int = 512 * 1_024,
        retryDelay: TimeInterval = 1
    ) throws {
        guard let resolvedBaseURL = baseURL
                ?? URL(string: "https://esi.evetech.net/"),
              resolvedBaseURL.scheme == "https",
              resolvedBaseURL.host == "esi.evetech.net",
              resolvedBaseURL.user == nil,
              resolvedBaseURL.password == nil,
              resolvedBaseURL.query == nil,
              resolvedBaseURL.fragment == nil,
              resolvedBaseURL.path == "/",
              Self.isISODate(compatibilityDate),
              timeout > 0,
              maximumResponseBytes > 0,
              retryDelay >= 0 else {
            throw ESICharacterSyncError.invalidConfiguration
        }
        self.baseURL = resolvedBaseURL
        self.compatibilityDate = compatibilityDate
        self.userAgent = userAgent
        self.timeout = timeout
        self.maximumResponseBytes = maximumResponseBytes
        self.retryDelay = retryDelay
    }

    private static func isISODate(_ value: String) -> Bool {
        guard value.count == 10 else {
            return false
        }
        let parts = value.split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 3,
              parts[0].count == 4,
              parts[1].count == 2,
              parts[2].count == 2,
              parts.allSatisfy({ $0.allSatisfy(\.isNumber) }),
              let year = Int(parts[0]),
              let month = Int(parts[1]),
              let day = Int(parts[2]) else {
            return false
        }
        var calendar = Calendar(identifier: .gregorian)
        guard let utc = TimeZone(secondsFromGMT: 0) else {
            return false
        }
        calendar.timeZone = utc
        let components = DateComponents(
            calendar: calendar,
            timeZone: TimeZone(secondsFromGMT: 0),
            year: year,
            month: month,
            day: day
        )
        guard let date = components.date else {
            return false
        }
        let resolved = calendar.dateComponents(
            [.year, .month, .day],
            from: date
        )
        return resolved.year == year
            && resolved.month == month
            && resolved.day == day
    }
}

struct ESIHTTPResponse: Sendable {
    let data: Data
    let statusCode: Int
    let headers: [String: String]
    let finalURL: URL

    func header(_ name: String) -> String? {
        headers[name.lowercased()]
    }
}

protocol ESIHTTPTransport: Sendable {
    func execute(_ request: URLRequest) async throws -> ESIHTTPResponse
}

struct URLSessionESIHTTPTransport:
    ESIHTTPTransport,
    @unchecked Sendable
{
    private let session: URLSession

    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
    }

    func execute(_ request: URLRequest) async throws -> ESIHTTPResponse {
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse,
              let finalURL = http.url else {
            throw ESICharacterSyncError.transport
        }
        var headers: [String: String] = [:]
        for (key, value) in http.allHeaderFields {
            headers[String(describing: key).lowercased()] =
                String(describing: value)
        }
        return ESIHTTPResponse(
            data: data,
            statusCode: http.statusCode,
            headers: headers,
            finalURL: finalURL
        )
    }
}

protocol ESIBackoffSleeping: Sendable {
    func sleep(seconds: TimeInterval) async throws
}

private struct ContinuousESIBackoffSleeper: ESIBackoffSleeping {
    func sleep(seconds: TimeInterval) async throws {
        guard seconds > 0 else {
            return
        }
        try await ContinuousClock().sleep(
            for: .milliseconds(Int64((seconds * 1_000).rounded(.up)))
        )
    }
}

public actor URLSessionESICharacterClient: ESICharacterRemoteFetching {
    private let configuration: ESICharacterClientConfiguration
    private let transport: any ESIHTTPTransport
    private let sleeper: any ESIBackoffSleeping
    private let now: @Sendable () -> Date
    private var requestBlock: ESIRequestBlock?

    public init(configuration: ESICharacterClientConfiguration) {
        self.configuration = configuration
        transport = URLSessionESIHTTPTransport()
        sleeper = ContinuousESIBackoffSleeper()
        now = Date.init
    }

    init(
        configuration: ESICharacterClientConfiguration,
        transport: any ESIHTTPTransport,
        sleeper: any ESIBackoffSleeping,
        now: @escaping @Sendable () -> Date
    ) {
        self.configuration = configuration
        self.transport = transport
        self.sleeper = sleeper
        self.now = now
    }

    public func fetch(
        characterID: Int64,
        validators: ESICacheValidators?
    ) async throws -> ESICharacterRemoteResult {
        guard characterID > 0 else {
            throw ESICharacterSyncError.invalidCharacterID
        }
        let requestDate = now()
        if let requestBlock, requestBlock.until > requestDate {
            throw requestBlock.error
        }
        requestBlock = nil
        guard Self.isSafeValidator(validators?.etag),
              Self.isSafeValidator(validators?.lastModified) else {
            throw ESICharacterSyncError.invalidConfiguration
        }
        guard let url = URL(
            string: "characters/\(characterID)/",
            relativeTo: configuration.baseURL
        )?.absoluteURL else {
            throw ESICharacterSyncError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue(
            "application/json",
            forHTTPHeaderField: "Accept"
        )
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        if let etag = validators?.etag {
            request.setValue(etag, forHTTPHeaderField: "If-None-Match")
        }
        if let lastModified = validators?.lastModified {
            request.setValue(
                lastModified,
                forHTTPHeaderField: "If-Modified-Since"
            )
        }

        for attempt in 0...1 {
            let response: ESIHTTPResponse
            do {
                response = try await transport.execute(request)
            } catch is CancellationError {
                throw CancellationError()
            } catch let error as URLError {
                switch error.code {
                case .cancelled:
                    throw CancellationError()
                case .notConnectedToInternet, .timedOut,
                        .networkConnectionLost, .cannotFindHost,
                        .cannotConnectToHost, .dnsLookupFailed:
                    throw ESICharacterSyncError.offline
                default:
                    throw ESICharacterSyncError.transport
                }
            } catch let error as ESICharacterSyncError {
                throw error
            } catch {
                throw ESICharacterSyncError.transport
            }

            guard response.finalURL.scheme == "https",
                  response.finalURL.host == "esi.evetech.net" else {
                throw ESICharacterSyncError.invalidResponse
            }
            guard response.data.count
                    <= configuration.maximumResponseBytes else {
                throw ESICharacterSyncError.responseTooLarge
            }
            let checkedAt = now()
            let metadata = try responseMetadata(
                response,
                checkedAt: checkedAt
            )

            switch response.statusCode {
            case 200:
                let payload: CharacterPayload
                do {
                    payload = try JSONDecoder().decode(
                        CharacterPayload.self,
                        from: response.data
                    )
                } catch {
                    throw ESICharacterSyncError.invalidResponse
                }
                let profile = try payload.profile(
                    characterID: characterID
                )
                return .modified(profile, metadata)
            case 304:
                guard response.data.isEmpty else {
                    throw ESICharacterSyncError.invalidResponse
                }
                return .notModified(metadata)
            case 401, 403:
                throw ESICharacterSyncError.unauthorized
            case 404:
                throw ESICharacterSyncError.notFound
            case 420:
                guard let seconds = Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                ), seconds >= 0 else {
                    throw ESICharacterSyncError.invalidResponse
                }
                let until = checkedAt.addingTimeInterval(
                    TimeInterval(seconds)
                )
                requestBlock = .errorLimit(until)
                throw ESICharacterSyncError.errorLimited(until: until)
            case 429:
                guard let until = retryDate(
                    response.header("retry-after"),
                    relativeTo: checkedAt
                ) else {
                    throw ESICharacterSyncError.invalidResponse
                }
                requestBlock = .rateLimit(until)
                throw ESICharacterSyncError.rateLimited(until: until)
            case 500...599:
                if attempt == 0 {
                    try await sleeper.sleep(
                        seconds: configuration.retryDelay
                    )
                    try Task.checkCancellation()
                    continue
                }
                throw ESICharacterSyncError.serverUnavailable
            default:
                throw ESICharacterSyncError.invalidResponse
            }
        }
        throw ESICharacterSyncError.serverUnavailable
    }

    private func responseMetadata(
        _ response: ESIHTTPResponse,
        checkedAt: Date
    ) throws -> ESIResponseMetadata {
        let etag = response.header("etag")
        let lastModified = response.header("last-modified")
        guard Self.isSafeValidator(etag),
              Self.isSafeValidator(lastModified) else {
            throw ESICharacterSyncError.invalidResponse
        }
        let compatibility = response.header("x-compatibility-date")
            .flatMap {
                ESICharacterClientConfigurationDateValidator
                    .validated($0)
            } ?? configuration.compatibilityDate
        return ESIResponseMetadata(
            checkedAt: checkedAt,
            expiresAt: httpDate(response.header("expires")),
            validators: ESICacheValidators(
                etag: etag,
                lastModified: lastModified
            ),
            compatibilityDate: compatibility,
            rateLimit: ESIRateLimitSnapshot(
                group: response.header("x-ratelimit-group"),
                limit: response.header("x-ratelimit-limit"),
                remaining: Int(
                    response.header("x-ratelimit-remaining") ?? ""
                ),
                used: Int(response.header("x-ratelimit-used") ?? ""),
                errorLimitRemaining: Int(
                    response.header("x-esi-error-limit-remain") ?? ""
                ),
                errorLimitResetSeconds: Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                )
            )
        )
    }

    private static func isSafeValidator(_ value: String?) -> Bool {
        guard let value else {
            return true
        }
        return !value.isEmpty
            && value.utf8.count <= 1_024
            && value.rangeOfCharacter(
                from: .newlines
            ) == nil
    }

    private func retryDate(
        _ value: String?,
        relativeTo date: Date
    ) -> Date? {
        guard let value else {
            return nil
        }
        if let seconds = TimeInterval(value), seconds >= 0 {
            return date.addingTimeInterval(seconds)
        }
        return httpDate(value)
    }

    private func httpDate(_ value: String?) -> Date? {
        guard let value else {
            return nil
        }
        for format in [
            "EEE',' dd MMM yyyy HH':'mm':'ss z",
            "EEEE',' dd-MMM-yy HH':'mm':'ss z",
            "EEE MMM d HH':'mm':'ss yyyy"
        ] {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.timeZone = TimeZone(secondsFromGMT: 0)
            formatter.dateFormat = format
            if let date = formatter.date(from: value) {
                return date
            }
        }
        return nil
    }
}

private enum ESIRequestBlock {
    case rateLimit(Date)
    case errorLimit(Date)

    var until: Date {
        switch self {
        case .rateLimit(let date), .errorLimit(let date):
            date
        }
    }

    var error: ESICharacterSyncError {
        switch self {
        case .rateLimit(let date):
            .rateLimited(until: date)
        case .errorLimit(let date):
            .errorLimited(until: date)
        }
    }
}

private enum ESICharacterClientConfigurationDateValidator {
    static func validated(_ value: String) -> String? {
        let parts = value.split(
            separator: "-",
            omittingEmptySubsequences: false
        )
        guard value.count == 10,
              parts.count == 3,
              parts[0].count == 4,
              parts[1].count == 2,
              parts[2].count == 2,
              parts.allSatisfy({ $0.allSatisfy(\.isNumber) }),
              let year = Int(parts[0]),
              let month = Int(parts[1]),
              let day = Int(parts[2]),
              let utc = TimeZone(secondsFromGMT: 0) else {
            return nil
        }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = utc
        let components = DateComponents(
            calendar: calendar,
            timeZone: utc,
            year: year,
            month: month,
            day: day
        )
        guard let date = components.date else {
            return nil
        }
        let resolved = calendar.dateComponents(
            [.year, .month, .day],
            from: date
        )
        return resolved.year == year
            && resolved.month == month
            && resolved.day == day
            ? value
            : nil
    }
}

private struct CharacterPayload: Decodable {
    let name: String
    let corporationID: Int64
    let allianceID: Int64?
    let factionID: Int64?
    let birthday: String
    let gender: String
    let raceID: Int64
    let bloodlineID: Int64
    let securityStatus: Double?
    let achievementScore: Int64?
    let characterTitleID: Int64?
    let corporationTitleID: Int64?
    let legacyCorporationTitleID: Int64?

    enum CodingKeys: String, CodingKey {
        case name
        case corporationID = "corporation_id"
        case allianceID = "alliance_id"
        case factionID = "faction_id"
        case birthday
        case gender
        case raceID = "race_id"
        case bloodlineID = "bloodline_id"
        case securityStatus = "security_status"
        case achievementScore = "achievement_score"
        case characterTitleID = "character_title_id"
        case corporationTitleID = "corporation_title_id"
        case legacyCorporationTitleID = "title_id"
    }

    func profile(characterID: Int64) throws -> ESICharacterProfile {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [
            .withInternetDateTime,
            .withFractionalSeconds
        ]
        let date = formatter.date(from: birthday)
            ?? ISO8601DateFormatter().date(from: birthday)
        guard let date else {
            throw ESICharacterSyncError.invalidResponse
        }
        return try ESICharacterProfile(
            characterID: characterID,
            name: name,
            corporationID: corporationID,
            allianceID: allianceID,
            factionID: factionID,
            birthday: date,
            gender: gender,
            raceID: raceID,
            bloodlineID: bloodlineID,
            securityStatus: securityStatus,
            achievementScore: achievementScore,
            characterTitleID: characterTitleID,
            corporationTitleID:
                corporationTitleID ?? legacyCorporationTitleID
        )
    }
}
