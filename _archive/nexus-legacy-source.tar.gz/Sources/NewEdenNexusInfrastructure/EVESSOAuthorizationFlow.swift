import AppKit
import CryptoKit
import Foundation
import NewEdenNexusApplication
@preconcurrency import Network
import Security

public struct SystemAuthorizationURLLauncher:
    EVEAuthorizationURLLaunching,
    Sendable
{
    public init() {}

    public func openAuthorizationURL(_ url: URL) async throws {
        let didOpen = await MainActor.run {
            NSWorkspace.shared.open(url)
        }
        guard didOpen else {
            throw EVEAuthenticationError.browserLaunchFailed
        }
    }
}

public struct LoopbackOAuthCallbackReceiver:
    EVEOAuthCallbackReceiving,
    Sendable
{
    public init() {}

    public func prepare(
        redirectURI: URL,
        expectedState: String
    ) async throws -> any EVEOAuthCallbackSession {
        guard redirectURI.scheme == "http",
              ["localhost", "127.0.0.1"].contains(
                  redirectURI.host?.lowercased() ?? ""
              ),
              let port = redirectURI.port,
              (1...65_535).contains(port),
              redirectURI.path.hasPrefix("/"),
              redirectURI.path.count > 1,
              redirectURI.query == nil,
              redirectURI.fragment == nil,
              !expectedState.isEmpty else {
            throw EVEAuthenticationError.invalidConfiguration
        }
        let session = try LoopbackOAuthCallbackSession(
            redirectURI: redirectURI,
            expectedState: expectedState
        )
        try await session.start()
        return session
    }
}

private final class LoopbackOAuthCallbackSession:
    EVEOAuthCallbackSession,
    @unchecked Sendable
{
    private let listener: NWListener
    private let redirectURI: URL
    private let expectedState: String
    private let queue = DispatchQueue(
        label: "de.newedennexus.oauth-callback"
    )
    private let lock = NSLock()
    private var readyContinuation: CheckedContinuation<Void, Error>?
    private var resultContinuation:
        CheckedContinuation<String, Error>?
    private var bufferedResult: Result<String, Error>?
    private var didFinish = false

    init(redirectURI: URL, expectedState: String) throws {
        guard let rawPort = redirectURI.port,
              let port = NWEndpoint.Port(rawValue: UInt16(rawPort)) else {
            throw EVEAuthenticationError.invalidConfiguration
        }
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(
            host: "127.0.0.1",
            port: port
        )
        listener = try NWListener(using: parameters)
        self.redirectURI = redirectURI
        self.expectedState = expectedState
        listener.newConnectionHandler = { [weak self] connection in
            self?.receive(connection)
        }
        listener.stateUpdateHandler = { [weak self] state in
            self?.handle(state)
        }
    }

    func start() async throws {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                lock.withLock {
                    readyContinuation = continuation
                }
                listener.start(queue: queue)
            }
        } onCancel: {
            cancel()
        }
    }

    func waitForAuthorizationCode(
        timeout: Duration
    ) async throws -> String {
        try await withTaskCancellationHandler {
            try await withThrowingTaskGroup(of: String.self) { group in
                group.addTask { [self] in
                    try await waitForResult()
                }
                group.addTask {
                    try await ContinuousClock().sleep(for: timeout)
                    throw EVEAuthenticationError.callbackTimeout
                }
                defer {
                    group.cancelAll()
                    cancel()
                }
                guard let code = try await group.next() else {
                    throw EVEAuthenticationError.callbackUnavailable
                }
                return code
            }
        } onCancel: {
            cancel()
        }
    }

    func cancel() {
        listener.cancel()
        finish(.failure(CancellationError()))
        let continuation = lock.withLock {
            let current = readyContinuation
            readyContinuation = nil
            return current
        }
        continuation?.resume(throwing: CancellationError())
    }

    private func waitForResult() async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            let buffered: Result<String, Error>? = lock.withLock {
                if let bufferedResult {
                    self.bufferedResult = nil
                    return bufferedResult
                }
                resultContinuation = continuation
                return nil
            }
            if let buffered {
                switch buffered {
                case .success(let code):
                    continuation.resume(returning: code)
                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    private func handle(_ state: NWListener.State) {
        switch state {
        case .ready:
            let continuation = lock.withLock {
                let current = readyContinuation
                readyContinuation = nil
                return current
            }
            continuation?.resume()
        case .failed:
            let continuation = lock.withLock {
                let current = readyContinuation
                readyContinuation = nil
                return current
            }
            continuation?.resume(
                throwing: EVEAuthenticationError.callbackUnavailable
            )
            finish(
                .failure(EVEAuthenticationError.callbackUnavailable)
            )
        default:
            break
        }
    }

    private func receive(_ connection: NWConnection) {
        connection.start(queue: queue)
        connection.receive(
            minimumIncompleteLength: 1,
            maximumLength: 16_384
        ) { [weak self] data, _, _, error in
            guard let self else {
                connection.cancel()
                return
            }
            guard error == nil,
                  let data,
                  let request = String(data: data, encoding: .utf8),
                  let requestLine = request
                    .components(separatedBy: "\r\n").first else {
                respond(
                    connection,
                    status: "400 Bad Request",
                    message: "Ungültiger OAuth-Callback."
                )
                return
            }
            let parts = requestLine.split(separator: " ")
            guard parts.count == 3,
                  parts[0] == "GET",
                  parts[2].hasPrefix("HTTP/1."),
                  let callbackURL = callbackURL(
                      requestTarget: String(parts[1])
                  ) else {
                respond(
                    connection,
                    status: "400 Bad Request",
                    message: "Ungültiger OAuth-Callback."
                )
                return
            }
            process(callbackURL, connection: connection)
        }
    }

    private func callbackURL(requestTarget: String) -> URL? {
        guard requestTarget.hasPrefix("/") else {
            return nil
        }
        var components = URLComponents(
            url: redirectURI,
            resolvingAgainstBaseURL: false
        )
        let target = URLComponents(string: requestTarget)
        components?.path = target?.path ?? ""
        components?.percentEncodedQuery = target?.percentEncodedQuery
        return components?.url
    }

    private func process(
        _ callbackURL: URL,
        connection: NWConnection
    ) {
        guard callbackURL.path == redirectURI.path else {
            respond(
                connection,
                status: "404 Not Found",
                message: "Unbekannter Callback-Pfad."
            )
            return
        }
        let items = URLComponents(
            url: callbackURL,
            resolvingAgainstBaseURL: false
        )?.queryItems ?? []
        guard items.first(where: { $0.name == "state" })?.value
            == expectedState else {
            respond(
                connection,
                status: "400 Bad Request",
                message: "Die Anmeldung konnte nicht verifiziert werden."
            )
            finish(.failure(EVEAuthenticationError.stateMismatch))
            return
        }
        if items.contains(where: { $0.name == "error" }) {
            respond(
                connection,
                status: "400 Bad Request",
                message: "Die Anmeldung wurde nicht autorisiert."
            )
            finish(.failure(EVEAuthenticationError.authorizationDenied))
            return
        }
        guard let code = items.first(where: { $0.name == "code" })?.value,
              !code.isEmpty else {
            respond(
                connection,
                status: "400 Bad Request",
                message: "Die Anmeldung lieferte keinen Code."
            )
            finish(
                .failure(EVEAuthenticationError.missingAuthorizationCode)
            )
            return
        }
        respond(
            connection,
            status: "200 OK",
            message: "Anmeldung erfolgreich. Dieses Fenster kann "
                + "geschlossen werden."
        )
        finish(.success(code))
    }

    private func respond(
        _ connection: NWConnection,
        status: String,
        message: String
    ) {
        let escaped = message
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
        let html = """
        <!doctype html><meta charset="utf-8">
        <title>New Eden Nexus</title>
        <style>
        body{font:17px -apple-system;padding:48px;background:#0b1320;\
        color:#e8f4fa}main{max-width:620px;margin:auto}
        </style>
        <main><h1>New Eden Nexus</h1><p>\(escaped)</p></main>
        """
        let response = """
        HTTP/1.1 \(status)\r
        Content-Type: text/html; charset=utf-8\r
        Content-Length: \(html.utf8.count)\r
        Cache-Control: no-store\r
        Connection: close\r
        \r
        \(html)
        """
        connection.send(
            content: Data(response.utf8),
            completion: .contentProcessed { _ in
                connection.cancel()
            }
        )
    }

    private func finish(_ result: Result<String, Error>) {
        let continuation: CheckedContinuation<String, Error>? =
            lock.withLock {
                guard !didFinish else {
                    return nil
                }
                didFinish = true
                listener.cancel()
                if let current = resultContinuation {
                    resultContinuation = nil
                    return current
                }
                bufferedResult = result
                return nil
            }
        continuation?.resume(with: result)
    }
}

public actor EVESSOAuthorizationFlow: EVEAuthorizationFlow {
    private static let discoveryURL = URL(
        string: "https://login.eveonline.com/"
            + ".well-known/oauth-authorization-server"
    )!

    private let browser: any EVEAuthorizationURLLaunching
    private let callbackReceiver: any EVEOAuthCallbackReceiving
    private let transport: any EVEAuthenticationHTTPTransport
    private let tokenValidator: any EVEAccessTokenValidating
    private var cachedDiscovery: CachedDiscovery?

    public init(
        browser: any EVEAuthorizationURLLaunching =
            SystemAuthorizationURLLauncher(),
        callbackReceiver: any EVEOAuthCallbackReceiving =
            LoopbackOAuthCallbackReceiver()
    ) {
        self.browser = browser
        self.callbackReceiver = callbackReceiver
        transport = URLSessionEVEAuthenticationHTTPTransport()
        tokenValidator = EVEJWTAccessTokenValidator()
    }

    init(
        browser: any EVEAuthorizationURLLaunching,
        callbackReceiver: any EVEOAuthCallbackReceiving,
        transport: any EVEAuthenticationHTTPTransport,
        tokenValidator: any EVEAccessTokenValidating
    ) {
        self.browser = browser
        self.callbackReceiver = callbackReceiver
        self.transport = transport
        self.tokenValidator = tokenValidator
    }

    public func authorize(
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVEAuthorizationGrant {
        try validate(configuration)
        let discovery = try await discoveryDocument()
        let verifier = try randomURLSafe(byteCount: 32)
        let state = try randomURLSafe(byteCount: 24)
        let challenge = Data(
            SHA256.hash(data: Data(verifier.utf8))
        ).base64URLEncodedString
        let callback = try await callbackReceiver.prepare(
            redirectURI: configuration.redirectURI,
            expectedState: state
        )
        defer {
            callback.cancel()
        }
        let authorizationURL = try makeAuthorizationURL(
            endpoint: discovery.authorizationEndpoint,
            configuration: configuration,
            challenge: challenge,
            state: state
        )
        try await browser.openAuthorizationURL(authorizationURL)
        let code = try await callback.waitForAuthorizationCode(
            timeout: configuration.callbackTimeout
        )
        let response = try await tokenRequest(
            endpoint: discovery.tokenEndpoint,
            fields: [
                "grant_type": "authorization_code",
                "code": code,
                "client_id": configuration.clientID,
                "code_verifier": verifier,
                "redirect_uri": configuration.redirectURI.absoluteString
            ]
        )
        guard let refreshToken = response.refreshToken,
              !refreshToken.isEmpty else {
            throw EVEAuthenticationError.invalidTokenResponse
        }
        let identity = try await tokenValidator.validate(
            accessToken: response.accessToken,
            clientID: configuration.clientID,
            requiredScopes: configuration.scopes,
            discovery: discovery,
            transport: transport
        )
        return EVEAuthorizationGrant(
            accessToken: response.accessToken,
            refreshToken: refreshToken,
            identity: identity
        )
    }

    public func refresh(
        refreshToken: String,
        configuration: EVEAuthenticationConfiguration
    ) async throws -> EVEAuthorizationGrant {
        try validate(configuration)
        guard !refreshToken.isEmpty else {
            throw EVEAuthenticationError.refreshTokenUnavailable
        }
        let discovery = try await discoveryDocument()
        let response = try await tokenRequest(
            endpoint: discovery.tokenEndpoint,
            fields: [
                "grant_type": "refresh_token",
                "refresh_token": refreshToken,
                "client_id": configuration.clientID
            ]
        )
        let identity = try await tokenValidator.validate(
            accessToken: response.accessToken,
            clientID: configuration.clientID,
            requiredScopes: configuration.scopes,
            discovery: discovery,
            transport: transport
        )
        return EVEAuthorizationGrant(
            accessToken: response.accessToken,
            refreshToken: response.refreshToken ?? refreshToken,
            identity: identity
        )
    }

    private func validate(
        _ configuration: EVEAuthenticationConfiguration
    ) throws {
        guard !configuration.clientID
            .trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
            configuration.redirectURI.scheme == "http",
            ["localhost", "127.0.0.1"].contains(
                configuration.redirectURI.host?.lowercased() ?? ""
            ),
            configuration.redirectURI.port != nil,
            configuration.redirectURI.path.count > 1,
            configuration.redirectURI.query == nil,
            configuration.redirectURI.fragment == nil,
            configuration.scopes.allSatisfy({
                !$0.isEmpty && !$0.contains(where: \.isWhitespace)
            }) else {
            throw EVEAuthenticationError.invalidConfiguration
        }
    }

    private func discoveryDocument() async throws -> EVESSODiscovery {
        if let cachedDiscovery,
           Date().timeIntervalSince(cachedDiscovery.storedAt) < 3_600 {
            return cachedDiscovery.document
        }
        var request = URLRequest(url: Self.discoveryURL)
        request.timeoutInterval = 20
        request.cachePolicy = .reloadRevalidatingCacheData
        let response = try await transport.data(for: request)
        guard (200..<300).contains(response.statusCode),
              let document = try? JSONDecoder().decode(
                  EVESSODiscovery.self,
                  from: response.data
              ),
              document.hasTrustedEndpoints else {
            throw EVEAuthenticationError.invalidDiscovery
        }
        cachedDiscovery = CachedDiscovery(
            document: document,
            storedAt: Date()
        )
        return document
    }

    private func makeAuthorizationURL(
        endpoint: URL,
        configuration: EVEAuthenticationConfiguration,
        challenge: String,
        state: String
    ) throws -> URL {
        var components = URLComponents(
            url: endpoint,
            resolvingAgainstBaseURL: false
        )
        var queryItems = [
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "client_id", value: configuration.clientID),
            URLQueryItem(
                name: "redirect_uri",
                value: configuration.redirectURI.absoluteString
            ),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256")
        ]
        if !configuration.scopes.isEmpty {
            queryItems.insert(
                URLQueryItem(
                    name: "scope",
                    value: configuration.scopes.joined(separator: " ")
                ),
                at: 3
            )
        }
        components?.queryItems = queryItems
        guard let url = components?.url else {
            throw EVEAuthenticationError.invalidConfiguration
        }
        return url
    }

    private func tokenRequest(
        endpoint: URL,
        fields: [String: String]
    ) async throws -> EVETokenResponse {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 30
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue(
            "application/x-www-form-urlencoded",
            forHTTPHeaderField: "Content-Type"
        )
        request.httpBody = try formEncodedBody(fields)
        let response = try await transport.data(for: request)
        guard (200..<300).contains(response.statusCode) else {
            throw EVEAuthenticationError.tokenExchangeFailed(
                status: response.statusCode,
                oauthError: standardizedOAuthError(in: response.data)
            )
        }
        guard let token = try? JSONDecoder().decode(
            EVETokenResponse.self,
            from: response.data
        ),
        !token.accessToken.isEmpty,
        token.tokenType.caseInsensitiveCompare("Bearer") == .orderedSame,
        token.expiresIn > 0 else {
            throw EVEAuthenticationError.invalidTokenResponse
        }
        return token
    }

    private func formEncodedBody(
        _ fields: [String: String]
    ) throws -> Data {
        let allowed = CharacterSet(
            charactersIn:
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "abcdefghijklmnopqrstuvwxyz"
                + "0123456789-._~"
        )
        let body = try fields
            .sorted(by: { $0.key < $1.key })
            .map { key, value -> String in
                guard let encodedKey = key.addingPercentEncoding(
                    withAllowedCharacters: allowed
                ),
                let encodedValue = value.addingPercentEncoding(
                    withAllowedCharacters: allowed
                ) else {
                    throw EVEAuthenticationError.invalidConfiguration
                }
                return "\(encodedKey)=\(encodedValue)"
            }
            .joined(separator: "&")
        guard let data = body.data(using: .utf8) else {
            throw EVEAuthenticationError.invalidConfiguration
        }
        return data
    }

    private func standardizedOAuthError(
        in data: Data
    ) -> EVEOAuthTokenError? {
        guard let response = try? JSONDecoder().decode(
            EVEOAuthErrorResponse.self,
            from: data
        ) else {
            return nil
        }
        return EVEOAuthTokenError(rawValue: response.error)
    }

    private func randomURLSafe(byteCount: Int) throws -> String {
        var data = Data(count: byteCount)
        let status = data.withUnsafeMutableBytes { buffer in
            SecRandomCopyBytes(
                kSecRandomDefault,
                byteCount,
                buffer.baseAddress!
            )
        }
        guard status == errSecSuccess else {
            throw EVEAuthenticationError.invalidConfiguration
        }
        return data.base64URLEncodedString
    }
}

struct EVESSODiscovery: Decodable, Equatable, Sendable {
    let issuer: String
    let authorizationEndpoint: URL
    let tokenEndpoint: URL
    let jwksURI: URL

    enum CodingKeys: String, CodingKey {
        case issuer
        case authorizationEndpoint = "authorization_endpoint"
        case tokenEndpoint = "token_endpoint"
        case jwksURI = "jwks_uri"
    }

    var hasTrustedEndpoints: Bool {
        guard let issuerURL = URL(string: issuer),
              issuerURL.scheme == "https",
              issuerURL.host == "login.eveonline.com" else {
            return false
        }
        return [authorizationEndpoint, tokenEndpoint, jwksURI]
            .allSatisfy {
                $0.scheme == "https"
                    && $0.host == "login.eveonline.com"
            }
    }
}

private struct CachedDiscovery: Sendable {
    let document: EVESSODiscovery
    let storedAt: Date
}

private struct EVETokenResponse: Decodable {
    let accessToken: String
    let expiresIn: Int
    let tokenType: String
    let refreshToken: String?

    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case expiresIn = "expires_in"
        case tokenType = "token_type"
        case refreshToken = "refresh_token"
    }
}

private struct EVEOAuthErrorResponse: Decodable {
    let error: String
}

struct EVEAuthenticationHTTPResponse: Sendable {
    let data: Data
    let statusCode: Int
}

protocol EVEAuthenticationHTTPTransport: Sendable {
    func data(for request: URLRequest) async throws
        -> EVEAuthenticationHTTPResponse
}

private struct URLSessionEVEAuthenticationHTTPTransport:
    EVEAuthenticationHTTPTransport
{
    func data(
        for request: URLRequest
    ) async throws -> EVEAuthenticationHTTPResponse {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse else {
            throw EVEAuthenticationError.invalidDiscovery
        }
        return EVEAuthenticationHTTPResponse(
            data: data,
            statusCode: response.statusCode
        )
    }
}

protocol EVEAccessTokenValidating: Sendable {
    func validate(
        accessToken: String,
        clientID: String,
        requiredScopes: [String],
        discovery: EVESSODiscovery,
        transport: any EVEAuthenticationHTTPTransport
    ) async throws -> EVEAuthenticatedIdentity
}

struct EVEJWTAccessTokenValidator:
    EVEAccessTokenValidating,
    Sendable
{
    func validate(
        accessToken: String,
        clientID: String,
        requiredScopes: [String],
        discovery: EVESSODiscovery,
        transport: any EVEAuthenticationHTTPTransport
    ) async throws -> EVEAuthenticatedIdentity {
        let segments = accessToken.split(
            separator: ".",
            omittingEmptySubsequences: false
        )
        guard segments.count == 3,
              let headerData = Data(
                  base64URLString: String(segments[0])
              ),
              let claimsData = Data(
                  base64URLString: String(segments[1])
              ),
              let signature = Data(
                  base64URLString: String(segments[2])
              ),
              let header = try? JSONDecoder().decode(
                  JWTHeader.self,
                  from: headerData
              ),
              let claims = try? JSONDecoder().decode(
                  JWTClaims.self,
                  from: claimsData
              ) else {
            throw EVEAuthenticationError.invalidTokenResponse
        }
        guard header.algorithm == "RS256" else {
            throw EVEAuthenticationError.unsupportedSigningAlgorithm
        }

        var request = URLRequest(url: discovery.jwksURI)
        request.timeoutInterval = 20
        request.cachePolicy = .reloadRevalidatingCacheData
        let response = try await transport.data(for: request)
        guard (200..<300).contains(response.statusCode),
              let keySet = try? JSONDecoder().decode(
                  JWKSet.self,
                  from: response.data
              ),
              let jwk = keySet.keys.first(where: {
                  $0.keyID == header.keyID
                      && $0.keyType == "RSA"
                      && ($0.use == nil || $0.use == "sig")
                      && ($0.algorithm == nil || $0.algorithm == "RS256")
              }) else {
            throw EVEAuthenticationError.signingKeyUnavailable
        }
        let signedData = Data(
            "\(segments[0]).\(segments[1])".utf8
        )
        try verify(
            signedData: signedData,
            signature: signature,
            jwk: jwk
        )

        let acceptedIssuers = Set([
            discovery.issuer,
            "https://login.eveonline.com/",
            "login.eveonline.com"
        ])
        guard acceptedIssuers.contains(claims.issuer) else {
            throw EVEAuthenticationError.invalidIssuer
        }
        let audience = Set(claims.audience.values)
        guard audience.contains("EVE Online"),
              audience.contains(clientID) else {
            throw EVEAuthenticationError.invalidAudience
        }
        let now = Date().timeIntervalSince1970
        guard claims.expiration > now,
              claims.notBefore.map({ $0 <= now }) ?? true else {
            throw EVEAuthenticationError.expiredToken
        }
        let subject = claims.subject.split(
            separator: ":",
            omittingEmptySubsequences: false
        )
        guard subject.count == 3,
              subject[0] == "CHARACTER",
              subject[1] == "EVE",
              let characterID = Int64(subject[2]),
              characterID > 0,
              !claims.name
                .trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw EVEAuthenticationError.invalidSubject
        }
        let scopes = Set(claims.scopes)
        let missing = Set(requiredScopes).subtracting(scopes).sorted()
        guard missing.isEmpty else {
            throw EVEAuthenticationError.missingScopes(missing)
        }
        return EVEAuthenticatedIdentity(
            characterID: characterID,
            characterName: claims.name,
            grantedScopes: claims.scopes,
            expiresAt: Date(timeIntervalSince1970: claims.expiration)
        )
    }

    private func verify(
        signedData: Data,
        signature: Data,
        jwk: JWK
    ) throws {
        guard let encodedModulus = jwk.modulus,
              let encodedExponent = jwk.exponent,
              let modulus = Data(base64URLString: encodedModulus),
              let exponent = Data(base64URLString: encodedExponent) else {
            throw EVEAuthenticationError.signingKeyUnavailable
        }
        let keyData = ASN1.sequence(
            ASN1.integer(modulus) + ASN1.integer(exponent)
        )
        let attributes: [CFString: Any] = [
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass: kSecAttrKeyClassPublic,
            kSecAttrKeySizeInBits: modulus.count * 8
        ]
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateWithData(
            keyData as CFData,
            attributes as CFDictionary,
            &error
        ) else {
            throw EVEAuthenticationError.signingKeyUnavailable
        }
        let valid = SecKeyVerifySignature(
            key,
            .rsaSignatureMessagePKCS1v15SHA256,
            signedData as CFData,
            signature as CFData,
            &error
        )
        guard valid else {
            throw EVEAuthenticationError.invalidSignature
        }
    }
}

private struct JWTHeader: Decodable {
    let algorithm: String
    let keyID: String

    enum CodingKeys: String, CodingKey {
        case algorithm = "alg"
        case keyID = "kid"
    }
}

private struct JWTClaims: Decodable {
    let issuer: String
    let audience: StringOrStrings
    let expiration: TimeInterval
    let notBefore: TimeInterval?
    let subject: String
    let name: String
    let scopes: [String]

    enum CodingKeys: String, CodingKey {
        case issuer = "iss"
        case audience = "aud"
        case expiration = "exp"
        case notBefore = "nbf"
        case subject = "sub"
        case name
        case scopes = "scp"
    }
}

private enum StringOrStrings: Decodable {
    case one(String)
    case many([String])

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let value = try? container.decode(String.self) {
            self = .one(value)
        } else {
            self = .many(try container.decode([String].self))
        }
    }

    var values: [String] {
        switch self {
        case .one(let value):
            [value]
        case .many(let values):
            values
        }
    }
}

private struct JWKSet: Decodable {
    let keys: [JWK]
}

private struct JWK: Decodable {
    let keyID: String
    let keyType: String
    let use: String?
    let algorithm: String?
    let modulus: String?
    let exponent: String?

    enum CodingKeys: String, CodingKey {
        case keyID = "kid"
        case keyType = "kty"
        case use
        case algorithm = "alg"
        case modulus = "n"
        case exponent = "e"
    }
}

private enum ASN1 {
    static func integer(_ value: Data) -> Data {
        var normalized = value.drop(while: { $0 == 0 })
        if normalized.isEmpty {
            normalized = Data([0])[...]
        }
        var body = Data(normalized)
        if let first = body.first, first & 0x80 != 0 {
            body.insert(0, at: body.startIndex)
        }
        return Data([0x02]) + length(body.count) + body
    }

    static func sequence(_ value: Data) -> Data {
        Data([0x30]) + length(value.count) + value
    }

    private static func length(_ value: Int) -> Data {
        if value < 128 {
            return Data([UInt8(value)])
        }
        var value = value
        var bytes: [UInt8] = []
        while value > 0 {
            bytes.insert(UInt8(value & 0xff), at: 0)
            value >>= 8
        }
        return Data([0x80 | UInt8(bytes.count)] + bytes)
    }
}

private extension Data {
    init?(base64URLString: String) {
        var value = base64URLString
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        value += String(
            repeating: "=",
            count: (4 - value.count % 4) % 4
        )
        self.init(base64Encoded: value)
    }

    var base64URLEncodedString: String {
        base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}
