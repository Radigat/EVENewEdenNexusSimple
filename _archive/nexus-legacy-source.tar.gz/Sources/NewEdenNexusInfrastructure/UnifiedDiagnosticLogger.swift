import NewEdenNexusApplication
import OSLog

public struct UnifiedDiagnosticLogger: DiagnosticLogging {
    private let subsystem: String

    public init(subsystem: String = "de.newedennexus.app") {
        self.subsystem = subsystem
    }

    public func log(_ event: DiagnosticEvent) {
        let logger = Logger(
            subsystem: subsystem,
            category: event.category.rawValue
        )
        let message = event.redactedDescription

        switch event.level {
        case .info:
            logger.info("\(message, privacy: .public)")
        case .warning:
            logger.warning("\(message, privacy: .public)")
        case .error:
            logger.error("\(message, privacy: .public)")
        }
    }
}
