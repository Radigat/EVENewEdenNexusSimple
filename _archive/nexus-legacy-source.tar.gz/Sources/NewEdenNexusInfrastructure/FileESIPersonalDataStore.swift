import Foundation
import NewEdenNexusApplication

public actor FileESIPersonalDataStore: ESIPersonalDataPersisting {
    public static let defaultMaximumByteCount = 64 * 1_024 * 1_024

    private let directoryURL: URL
    private let maximumByteCount: Int
    private let maximumRecords: Int
    private let fileManager: FileManager

    public init(
        directoryURL: URL,
        maximumByteCount: Int = defaultMaximumByteCount,
        maximumRecords: Int = 250_000,
        fileManager: FileManager = .default
    ) throws {
        guard directoryURL.isFileURL,
              maximumByteCount > 0,
              maximumRecords > 0 else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        self.directoryURL = directoryURL.standardizedFileURL
        self.maximumByteCount = maximumByteCount
        self.maximumRecords = maximumRecords
        self.fileManager = fileManager
    }

    public static func defaultDirectoryURL(
        fileManager: FileManager = .default
    ) throws -> URL {
        guard let applicationSupport = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        return applicationSupport
            .appendingPathComponent("New Eden Nexus", isDirectory: true)
            .appendingPathComponent("ESI", isDirectory: true)
            .appendingPathComponent(
                "PersonalSnapshots",
                isDirectory: true
            )
    }

    public func snapshot(
        characterID: Int64
    ) async throws -> ESIPersonalDataSnapshot? {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        let url = fileURL(characterID: characterID)
        guard fileManager.fileExists(atPath: url.path) else {
            return nil
        }
        return try load(url: url, characterID: characterID)
    }

    public func save(
        _ snapshot: ESIPersonalDataSnapshot,
        expectedRevision: UUID?
    ) async throws {
        try Task.checkCancellation()
        guard isValid(snapshot) else {
            throw ESIPersonalDataError.cacheWriteFailed
        }
        let url = fileURL(characterID: snapshot.characterID)
        let existing: ESIPersonalDataSnapshot?
        if fileManager.fileExists(atPath: url.path) {
            existing = try load(
                url: url,
                characterID: snapshot.characterID
            )
        } else {
            existing = nil
        }
        guard existing?.revision == expectedRevision else {
            throw ESIPersonalDataError.stalePreview
        }
        var stagingURL: URL?
        defer {
            if let stagingURL,
               fileManager.fileExists(atPath: stagingURL.path) {
                try? fileManager.removeItem(at: stagingURL)
            }
        }
        do {
            try prepareDirectory()
            let encoder = makeEncoder()
            encoder.outputFormatting = [.sortedKeys]
            let data = try encoder.encode(snapshot)
            guard data.count <= maximumByteCount else {
                throw ESIPersonalDataError.responseTooLarge
            }
            let staged = directoryURL.appendingPathComponent(
                ".character-\(snapshot.characterID)-\(UUID().uuidString).tmp",
                isDirectory: false
            )
            stagingURL = staged
            try Task.checkCancellation()
            try data.write(
                to: staged,
                options: .atomic
            )
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: staged.path
            )
            guard try load(
                url: staged,
                characterID: snapshot.characterID
            ) == snapshot else {
                throw ESIPersonalDataError.cacheWriteFailed
            }
            try Task.checkCancellation()
            if existing != nil {
                _ = try fileManager.replaceItemAt(
                    url,
                    withItemAt: staged,
                    backupItemName: nil,
                    options: []
                )
            } else {
                try fileManager.moveItem(at: staged, to: url)
            }
            stagingURL = nil
        } catch let error as ESIPersonalDataError {
            throw error
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ESIPersonalDataError.cacheWriteFailed
        }
    }

    public func delete(characterID: Int64) async throws {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        try Task.checkCancellation()
        let url = fileURL(characterID: characterID)
        guard fileManager.fileExists(atPath: url.path) else {
            return
        }
        do {
            let values = try url.resourceValues(
                forKeys: [.isRegularFileKey, .isSymbolicLinkKey]
            )
            guard values.isRegularFile == true,
                  values.isSymbolicLink != true else {
                throw ESIPersonalDataError.cacheCorrupted
            }
            try fileManager.removeItem(at: url)
        } catch let error as ESIPersonalDataError {
            throw error
        } catch {
            throw ESIPersonalDataError.cacheWriteFailed
        }
    }

    private func fileURL(characterID: Int64) -> URL {
        directoryURL.appendingPathComponent(
            "character-\(characterID)-v1.json",
            isDirectory: false
        )
    }

    private func prepareDirectory() throws {
        try fileManager.createDirectory(
            at: directoryURL,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700]
        )
        try fileManager.setAttributes(
            [.posixPermissions: 0o700],
            ofItemAtPath: directoryURL.path
        )
        let values = try directoryURL.resourceValues(
            forKeys: [.isDirectoryKey, .isSymbolicLinkKey]
        )
        guard values.isDirectory == true,
              values.isSymbolicLink != true else {
            throw ESIPersonalDataError.cacheWriteFailed
        }
    }

    private func load(
        url: URL,
        characterID: Int64
    ) throws -> ESIPersonalDataSnapshot {
        let values: URLResourceValues
        do {
            values = try url.resourceValues(
                forKeys: [
                    .isRegularFileKey,
                    .isSymbolicLinkKey,
                    .fileSizeKey
                ]
            )
        } catch {
            throw ESIPersonalDataError.cacheCorrupted
        }
        guard values.isRegularFile == true,
              values.isSymbolicLink != true,
              let fileSize = values.fileSize,
              fileSize <= maximumByteCount else {
            throw ESIPersonalDataError.cacheCorrupted
        }
        do {
            let data = try Data(contentsOf: url)
            guard data.count <= maximumByteCount else {
                throw ESIPersonalDataError.cacheCorrupted
            }
            let decoder = makeDecoder()
            let snapshot = try decoder.decode(
                ESIPersonalDataSnapshot.self,
                from: data
            )
            guard snapshot.characterID == characterID,
                  isValid(snapshot) else {
                throw ESIPersonalDataError.cacheCorrupted
            }
            return snapshot
        } catch let error as ESIPersonalDataError {
            throw error
        } catch {
            throw ESIPersonalDataError.cacheCorrupted
        }
    }

    private func isValid(_ snapshot: ESIPersonalDataSnapshot) -> Bool {
        guard snapshot.version == ESIPersonalDataSnapshot.payloadVersion,
              snapshot.characterID > 0,
              snapshot.synchronizedAt
                .timeIntervalSinceReferenceDate.isFinite,
              snapshot.assets.count <= maximumRecords,
              snapshot.blueprints.count <= maximumRecords,
              snapshot.industryJobs.count <= maximumRecords,
              snapshot.assets.allSatisfy(validAsset),
              snapshot.blueprints.allSatisfy(validBlueprint),
              snapshot.industryJobs.allSatisfy(validJob),
              validMetadata(snapshot.assetMetadata),
              validMetadata(snapshot.blueprintMetadata),
              validMetadata(snapshot.jobMetadata),
              let rebuilt = try? ESIPersonalDataSnapshot(
                  revision: snapshot.revision,
                  characterID: snapshot.characterID,
                  synchronizedAt: snapshot.synchronizedAt,
                  assets: snapshot.assets,
                  blueprints: snapshot.blueprints,
                  industryJobs: snapshot.industryJobs,
                  assetMetadata: snapshot.assetMetadata,
                  blueprintMetadata: snapshot.blueprintMetadata,
                  jobMetadata: snapshot.jobMetadata
              ) else {
            return false
        }
        return rebuilt == snapshot
    }

    private func makeEncoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .custom { date, encoder in
            var container = encoder.singleValueContainer()
            try container.encode(
                date.timeIntervalSinceReferenceDate
            )
        }
        return encoder
    }

    private func makeDecoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            if let seconds = try? container.decode(Double.self) {
                return Date(
                    timeIntervalSinceReferenceDate: seconds
                )
            }
            let value = try container.decode(String.self)
            let fractional = ISO8601DateFormatter()
            fractional.formatOptions = [
                .withInternetDateTime,
                .withFractionalSeconds
            ]
            if let date = fractional.date(from: value)
                ?? ISO8601DateFormatter().date(from: value) {
                return date
            }
            throw DecodingError.dataCorruptedError(
                in: container,
                debugDescription: "Ungültiges Snapshot-Datum."
            )
        }
        return decoder
    }

    private func validAsset(_ value: ESICharacterAsset) -> Bool {
        (try? ESICharacterAsset(
            itemID: value.itemID,
            typeID: value.typeID,
            quantity: value.quantity,
            locationID: value.locationID,
            locationType: value.locationType,
            locationFlag: value.locationFlag,
            isSingleton: value.isSingleton,
            isBlueprintCopy: value.isBlueprintCopy,
            sourcePage: value.sourcePage
        )) == value
    }

    private func validBlueprint(
        _ value: ESICharacterBlueprint
    ) -> Bool {
        (try? ESICharacterBlueprint(
            itemID: value.itemID,
            typeID: value.typeID,
            locationID: value.locationID,
            locationFlag: value.locationFlag,
            quantity: value.quantity,
            timeEfficiency: value.timeEfficiency,
            materialEfficiency: value.materialEfficiency,
            runs: value.runs,
            sourcePage: value.sourcePage
        )) == value
    }

    private func validJob(_ value: ESICharacterIndustryJob) -> Bool {
        (try? ESICharacterIndustryJob(
            jobID: value.jobID,
            installerID: value.installerID,
            facilityID: value.facilityID,
            stationID: value.stationID,
            activityID: value.activityID,
            blueprintID: value.blueprintID,
            blueprintTypeID: value.blueprintTypeID,
            blueprintLocationID: value.blueprintLocationID,
            outputLocationID: value.outputLocationID,
            runs: value.runs,
            status: value.status,
            duration: value.duration,
            startDate: value.startDate,
            endDate: value.endDate,
            completedDate: value.completedDate,
            completedCharacterID: value.completedCharacterID,
            cost: value.cost,
            licensedRuns: value.licensedRuns,
            pauseDate: value.pauseDate,
            probability: value.probability,
            productTypeID: value.productTypeID,
            successfulRuns: value.successfulRuns
        )) == value
    }

    private func validMetadata(
        _ value: ESIPersonalEndpointMetadata
    ) -> Bool {
        guard value.checkedAt.timeIntervalSinceReferenceDate.isFinite,
              value.expiresAt?.timeIntervalSinceReferenceDate.isFinite
                ?? true,
              let rebuilt = try? ESIPersonalEndpointMetadata(
                  checkedAt: value.checkedAt,
                  expiresAt: value.expiresAt,
                  compatibilityDate: value.compatibilityDate,
                  pageCount: value.pageCount,
                  validatorsByPage: value.validatorsByPage,
                  rateLimit: value.rateLimit
              ) else {
            return false
        }
        return rebuilt == value
    }
}
