import Foundation
import NewEdenNexusApplication
import Security

public enum KeychainRefreshTokenVaultError:
    Error,
    Equatable,
    Sendable
{
    case operationFailed(OSStatus)
    case invalidStoredValue
}

public struct KeychainRefreshTokenVault:
    EVERefreshTokenVault,
    Sendable
{
    private let service: String

    public init(service: String = "de.newedennexus.tokens") {
        self.service = service
    }

    public func token(characterID: Int64) async throws -> String? {
        try Task.checkCancellation()
        let query = baseQuery(characterID: characterID).merging(
            [
                kSecReturnData as String: true,
                kSecMatchLimit as String: kSecMatchLimitOne
            ],
            uniquingKeysWith: { _, new in new }
        )
        var result: CFTypeRef?
        let status = SecItemCopyMatching(
            query as CFDictionary,
            &result
        )
        if status == errSecItemNotFound {
            return nil
        }
        guard status == errSecSuccess else {
            throw KeychainRefreshTokenVaultError
                .operationFailed(status)
        }
        guard let data = result as? Data,
              let value = String(data: data, encoding: .utf8),
              !value.isEmpty else {
            throw KeychainRefreshTokenVaultError.invalidStoredValue
        }
        return value
    }

    public func save(
        _ token: String,
        characterID: Int64
    ) async throws {
        try Task.checkCancellation()
        guard !token.isEmpty else {
            throw KeychainRefreshTokenVaultError.invalidStoredValue
        }
        let query = baseQuery(characterID: characterID)
        let protectedValue: [String: Any] = [
            kSecValueData as String: Data(token.utf8),
            kSecAttrAccessible as String:
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let updateStatus = SecItemUpdate(
            query as CFDictionary,
            protectedValue as CFDictionary
        )
        if updateStatus == errSecSuccess {
            return
        }
        guard updateStatus == errSecItemNotFound else {
            throw KeychainRefreshTokenVaultError
                .operationFailed(updateStatus)
        }

        let insert = query.merging(
            protectedValue,
            uniquingKeysWith: { _, new in new }
        )
        let insertStatus = SecItemAdd(insert as CFDictionary, nil)
        guard insertStatus == errSecSuccess else {
            throw KeychainRefreshTokenVaultError
                .operationFailed(insertStatus)
        }
    }

    public func delete(characterID: Int64) async throws {
        try Task.checkCancellation()
        let status = SecItemDelete(
            baseQuery(characterID: characterID) as CFDictionary
        )
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainRefreshTokenVaultError
                .operationFailed(status)
        }
    }

    private func baseQuery(characterID: Int64) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: "refresh.\(characterID)"
        ]
    }
}
