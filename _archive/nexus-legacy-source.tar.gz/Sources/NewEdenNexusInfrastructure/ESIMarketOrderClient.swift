import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

public struct ESIMarketOrderClientConfiguration: Equatable, Sendable {
    public let baseURL: URL
    public let compatibilityDate: String
    public let userAgent: SDEUserAgentConfiguration
    public let timeout: TimeInterval
    public let maximumResponseBytes: Int
    public let retryDelay: TimeInterval

    public init(
        baseURL: URL? = nil,
        compatibilityDate: String,
        userAgent: SDEUserAgentConfiguration,
        timeout: TimeInterval = 20,
        maximumResponseBytes: Int = 5 * 1_024 * 1_024,
        retryDelay: TimeInterval = 1
    ) throws {
        guard let resolvedBaseURL = baseURL
                ?? URL(string: "https://esi.evetech.net/"),
              resolvedBaseURL.scheme == "https",
              resolvedBaseURL.host == "esi.evetech.net",
              resolvedBaseURL.user == nil,
              resolvedBaseURL.password == nil,
              resolvedBaseURL.query == nil,
              resolvedBaseURL.fragment == nil,
              resolvedBaseURL.path == "/",
              ESIMarketCompatibilityDateValidator.validated(
                compatibilityDate
              ) != nil,
              timeout > 0,
              maximumResponseBytes > 0,
              retryDelay >= 0 else {
            throw ESIMarketPriceError.invalidConfiguration
        }
        self.baseURL = resolvedBaseURL
        self.compatibilityDate = compatibilityDate
        self.userAgent = userAgent
        self.timeout = timeout
        self.maximumResponseBytes = maximumResponseBytes
        self.retryDelay = retryDelay
    }
}

public actor URLSessionESIMarketOrderClient:
    ESIMarketOrderPageFetching
{
    private let configuration: ESIMarketOrderClientConfiguration
    private let transport: any ESIHTTPTransport
    private let sleeper: any ESIBackoffSleeping
    private let now: @Sendable () -> Date
    private var requestBlock: ESIMarketRequestBlock?

    public init(configuration: ESIMarketOrderClientConfiguration) {
        self.configuration = configuration
        transport = URLSessionESIHTTPTransport()
        sleeper = ContinuousMarketBackoffSleeper()
        now = Date.init
    }

    init(
        configuration: ESIMarketOrderClientConfiguration,
        transport: any ESIHTTPTransport,
        sleeper: any ESIBackoffSleeping,
        now: @escaping @Sendable () -> Date
    ) {
        self.configuration = configuration
        self.transport = transport
        self.sleeper = sleeper
        self.now = now
    }

    public func fetchSellOrders(
        regionID: Int64,
        typeID: Int64,
        page: Int,
        validators: ESICacheValidators?
    ) async throws -> ESIMarketOrderPageRemoteResult {
        guard regionID > 0, typeID > 0, page > 0,
              Self.isSafeValidator(validators?.etag),
              Self.isSafeValidator(validators?.lastModified) else {
            throw ESIMarketPriceError.invalidRequest
        }
        let requestDate = now()
        if let requestBlock, requestBlock.until > requestDate {
            switch requestBlock {
            case .rateLimit(let until):
                throw ESIMarketPriceError.rateLimited(until: until)
            case .errorLimit(let until):
                throw ESIMarketPriceError.errorLimited(until: until)
            }
        }
        requestBlock = nil
        var components = URLComponents(
            url: configuration.baseURL.appendingPathComponent(
                "markets/\(regionID)/orders/"
            ),
            resolvingAgainstBaseURL: false
        )
        components?.queryItems = [
            URLQueryItem(name: "order_type", value: "sell"),
            URLQueryItem(name: "page", value: String(page)),
            URLQueryItem(name: "type_id", value: String(typeID))
        ]
        guard let url = components?.url,
              url.scheme == "https",
              url.host == "esi.evetech.net" else {
            throw ESIMarketPriceError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        if let etag = validators?.etag {
            request.setValue(etag, forHTTPHeaderField: "If-None-Match")
        }
        if let lastModified = validators?.lastModified {
            request.setValue(
                lastModified,
                forHTTPHeaderField: "If-Modified-Since"
            )
        }

        for attempt in 0...1 {
            let response = try await execute(request)
            guard response.finalURL.scheme == "https",
                  response.finalURL.host == "esi.evetech.net",
                  response.data.count
                    <= configuration.maximumResponseBytes else {
                throw response.data.count
                    > configuration.maximumResponseBytes
                    ? ESIMarketPriceError.responseTooLarge
                    : ESIMarketPriceError.invalidResponse
            }
            let checkedAt = now()
            let metadata = try responseMetadata(
                response,
                checkedAt: checkedAt
            )
            switch response.statusCode {
            case 200:
                guard let pageCount = Int(
                    response.header("x-pages") ?? ""
                ), pageCount > 0, page <= pageCount else {
                    throw ESIMarketPriceError.invalidResponse
                }
                let payloads: [OrderPayload]
                do {
                    payloads = try JSONDecoder().decode(
                        [OrderPayload].self,
                        from: response.data
                    )
                } catch {
                    throw ESIMarketPriceError.invalidResponse
                }
                let orders = try payloads.map {
                    try $0.order(expectedTypeID: typeID)
                }
                guard Set(orders.map(\.orderID)).count == orders.count else {
                    throw ESIMarketPriceError.invalidResponse
                }
                return .modified(
                    orders: orders,
                    pageCount: pageCount,
                    metadata: metadata
                )
            case 304:
                guard response.data.isEmpty else {
                    throw ESIMarketPriceError.invalidResponse
                }
                return .notModified(metadata: metadata)
            case 404:
                throw ESIMarketPriceError.notFound
            case 420:
                guard let seconds = Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                ), seconds >= 0 else {
                    throw ESIMarketPriceError.invalidResponse
                }
                let until = checkedAt.addingTimeInterval(
                    TimeInterval(seconds)
                )
                requestBlock = .errorLimit(until)
                throw ESIMarketPriceError.errorLimited(until: until)
            case 429:
                guard let seconds = Int(
                    response.header("retry-after") ?? ""
                ), seconds >= 0 else {
                    throw ESIMarketPriceError.invalidResponse
                }
                let until = checkedAt.addingTimeInterval(
                    TimeInterval(seconds)
                )
                requestBlock = .rateLimit(until)
                throw ESIMarketPriceError.rateLimited(until: until)
            case 500...599:
                if attempt == 0 {
                    try await sleeper.sleep(
                        seconds: configuration.retryDelay
                    )
                    try Task.checkCancellation()
                    continue
                }
                throw ESIMarketPriceError.serverUnavailable
            default:
                throw ESIMarketPriceError.invalidResponse
            }
        }
        throw ESIMarketPriceError.serverUnavailable
    }

    private func execute(_ request: URLRequest) async throws
        -> ESIHTTPResponse {
        do {
            return try await transport.execute(request)
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as URLError {
            switch error.code {
            case .cancelled:
                throw CancellationError()
            case .notConnectedToInternet, .timedOut,
                    .networkConnectionLost, .cannotFindHost,
                    .cannotConnectToHost, .dnsLookupFailed:
                throw ESIMarketPriceError.offline
            default:
                throw ESIMarketPriceError.transport
            }
        } catch let error as ESIMarketPriceError {
            throw error
        } catch {
            throw ESIMarketPriceError.transport
        }
    }

    private func responseMetadata(
        _ response: ESIHTTPResponse,
        checkedAt: Date
    ) throws -> ESIResponseMetadata {
        let etag = response.header("etag")
        let lastModified = response.header("last-modified")
        guard Self.isSafeValidator(etag),
              Self.isSafeValidator(lastModified) else {
            throw ESIMarketPriceError.invalidResponse
        }
        return ESIResponseMetadata(
            checkedAt: checkedAt,
            expiresAt: Self.httpDate(response.header("expires")),
            validators: ESICacheValidators(
                etag: etag,
                lastModified: lastModified
            ),
            compatibilityDate:
                response.header("x-compatibility-date")
                    .flatMap(
                        ESIMarketCompatibilityDateValidator
                            .validated
                    )
                    ?? configuration.compatibilityDate,
            rateLimit: ESIRateLimitSnapshot(
                group: response.header("x-ratelimit-group"),
                limit: response.header("x-ratelimit-limit"),
                remaining: Int(
                    response.header("x-ratelimit-remaining") ?? ""
                ),
                used: Int(response.header("x-ratelimit-used") ?? ""),
                errorLimitRemaining: Int(
                    response.header("x-esi-error-limit-remain") ?? ""
                ),
                errorLimitResetSeconds: Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                )
            )
        )
    }

    private static func isSafeValidator(_ value: String?) -> Bool {
        guard let value else { return true }
        return !value.isEmpty
            && value.count <= 512
            && !value.contains("\r")
            && !value.contains("\n")
    }

    private static func httpDate(_ value: String?) -> Date? {
        guard let value else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "EEE',' dd MMM yyyy HH':'mm':'ss z"
        return formatter.date(from: value)
    }
}

public actor URLSessionMarketUniverseDirectoryClient:
    MarketUniverseDirectoryRemoteFetching
{
    private struct UniverseNamePayload: Decodable {
        let id: Int64
        let name: String
        let category: String
    }

    private struct StationPayload: Decodable {
        let stationID: Int64
        let systemID: Int64

        enum CodingKeys: String, CodingKey {
            case stationID = "station_id"
            case systemID = "system_id"
        }
    }

    private struct SolarSystemPayload: Decodable {
        let systemID: Int64
        let constellationID: Int64

        enum CodingKeys: String, CodingKey {
            case systemID = "system_id"
            case constellationID = "constellation_id"
        }
    }

    private struct ConstellationPayload: Decodable {
        let constellationID: Int64
        let regionID: Int64

        enum CodingKeys: String, CodingKey {
            case constellationID = "constellation_id"
            case regionID = "region_id"
        }
    }

    private let configuration: ESIMarketOrderClientConfiguration
    private let transport: any ESIHTTPTransport
    private var cachedRegions: [MarketRegionOption]?
    private var cachedPublicStructures: Set<Int64>?
    private var stationSystems: [Int64: Int64] = [:]
    private var systemRegions: [Int64: Int64] = [:]
    private var constellationRegions: [Int64: Int64] = [:]

    public init(configuration: ESIMarketOrderClientConfiguration) {
        self.configuration = configuration
        transport = URLSessionESIHTTPTransport()
    }

    init(
        configuration: ESIMarketOrderClientConfiguration,
        transport: any ESIHTTPTransport
    ) {
        self.configuration = configuration
        self.transport = transport
    }

    public func regions() async throws -> [MarketRegionOption] {
        if let cachedRegions {
            return cachedRegions
        }
        let ids: [Int64] = try await get(
            path: "universe/regions"
        )
        guard !ids.isEmpty,
              ids.count <= 500,
              Set(ids).count == ids.count,
              ids.allSatisfy({ $0 > 0 }) else {
            throw ESIMarketPriceError.invalidResponse
        }
        let body = try JSONEncoder().encode(ids.sorted())
        let names: [UniverseNamePayload] = try await request(
            path: "universe/names",
            method: "POST",
            body: body
        )
        guard names.count == ids.count else {
            throw ESIMarketPriceError.invalidResponse
        }
        var result: [MarketRegionOption] = []
        var seen = Set<Int64>()
        for value in names {
            guard value.category == "region",
                  ids.contains(value.id),
                  seen.insert(value.id).inserted else {
                throw ESIMarketPriceError.invalidResponse
            }
            do {
                result.append(
                    try MarketRegionOption(
                        regionID: value.id,
                        name: value.name
                    )
                )
            } catch {
                throw ESIMarketPriceError.invalidResponse
            }
        }
        cachedRegions = result
        return result
    }

    public func publicMarketStructureIDs() async throws -> Set<Int64> {
        if let cachedPublicStructures {
            return cachedPublicStructures
        }
        let ids: [Int64] = try await get(
            path: "universe/structures",
            queryItems: [
                URLQueryItem(name: "filter", value: "market")
            ]
        )
        guard ids.count <= 250_000,
              ids.allSatisfy({ $0 >= 1_000_000_000_000 }) else {
            throw ESIMarketPriceError.invalidResponse
        }
        let values = Set(ids)
        guard values.count == ids.count else {
            throw ESIMarketPriceError.invalidResponse
        }
        cachedPublicStructures = values
        return values
    }

    public func solarSystemID(stationID: Int64) async throws -> Int64 {
        guard (60_000_000...69_999_999).contains(stationID) else {
            throw ESIMarketPriceError.invalidRequest
        }
        if let cached = stationSystems[stationID] {
            return cached
        }
        let payload: StationPayload = try await get(
            path: "universe/stations/\(stationID)"
        )
        guard payload.stationID == stationID,
              payload.systemID > 0 else {
            throw ESIMarketPriceError.invalidResponse
        }
        stationSystems[stationID] = payload.systemID
        return payload.systemID
    }

    public func regionID(solarSystemID: Int64) async throws -> Int64 {
        guard solarSystemID > 0 else {
            throw ESIMarketPriceError.invalidRequest
        }
        if let cached = systemRegions[solarSystemID] {
            return cached
        }
        let system: SolarSystemPayload = try await get(
            path: "universe/systems/\(solarSystemID)"
        )
        guard system.systemID == solarSystemID,
              system.constellationID > 0 else {
            throw ESIMarketPriceError.invalidResponse
        }
        let regionID: Int64
        if let cached = constellationRegions[system.constellationID] {
            regionID = cached
        } else {
            let constellation: ConstellationPayload = try await get(
                path:
                    "universe/constellations/\(system.constellationID)"
            )
            guard constellation.constellationID
                    == system.constellationID,
                  constellation.regionID > 0 else {
                throw ESIMarketPriceError.invalidResponse
            }
            regionID = constellation.regionID
            constellationRegions[system.constellationID] = regionID
        }
        systemRegions[solarSystemID] = regionID
        return regionID
    }

    private func get<Value: Decodable & Sendable>(
        path: String,
        queryItems: [URLQueryItem] = []
    ) async throws -> Value {
        try await request(
            path: path,
            queryItems: queryItems,
            method: "GET",
            body: nil
        )
    }

    private func request<Value: Decodable & Sendable>(
        path: String,
        queryItems: [URLQueryItem] = [],
        method: String,
        body: Data?
    ) async throws -> Value {
        guard var components = URLComponents(
            url: configuration.baseURL.appendingPathComponent(path),
            resolvingAgainstBaseURL: false
        ) else {
            throw ESIMarketPriceError.invalidConfiguration
        }
        components.queryItems = queryItems.isEmpty ? nil : queryItems
        guard let url = components.url,
              url.scheme == "https",
              url.host == "esi.evetech.net" else {
            throw ESIMarketPriceError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.httpBody = body
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .useProtocolCachePolicy
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil {
            request.setValue(
                "application/json",
                forHTTPHeaderField: "Content-Type"
            )
        }
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        let response: ESIHTTPResponse
        do {
            response = try await transport.execute(request)
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as URLError {
            switch error.code {
            case .cancelled:
                throw CancellationError()
            case .notConnectedToInternet, .timedOut,
                    .networkConnectionLost, .cannotFindHost,
                    .cannotConnectToHost, .dnsLookupFailed:
                throw ESIMarketPriceError.offline
            default:
                throw ESIMarketPriceError.transport
            }
        } catch {
            throw ESIMarketPriceError.transport
        }
        guard response.finalURL.scheme == "https",
              response.finalURL.host == "esi.evetech.net",
              response.data.count
                <= configuration.maximumResponseBytes else {
            throw response.data.count
                > configuration.maximumResponseBytes
                ? ESIMarketPriceError.responseTooLarge
                : ESIMarketPriceError.invalidResponse
        }
        switch response.statusCode {
        case 200:
            do {
                return try JSONDecoder().decode(
                    Value.self,
                    from: response.data
                )
            } catch {
                throw ESIMarketPriceError.invalidResponse
            }
        case 404:
            throw ESIMarketPriceError.notFound
        case 420:
            let seconds = Int(
                response.header("x-esi-error-limit-reset") ?? ""
            ) ?? 60
            throw ESIMarketPriceError.errorLimited(
                until: Date().addingTimeInterval(
                    TimeInterval(max(0, seconds))
                )
            )
        case 429:
            let seconds = Int(
                response.header("retry-after") ?? ""
            ) ?? 60
            throw ESIMarketPriceError.rateLimited(
                until: Date().addingTimeInterval(
                    TimeInterval(max(0, seconds))
                )
            )
        case 500...599:
            throw ESIMarketPriceError.serverUnavailable
        default:
            throw ESIMarketPriceError.invalidResponse
        }
    }
}

private struct ContinuousMarketBackoffSleeper: ESIBackoffSleeping {
    func sleep(seconds: TimeInterval) async throws {
        guard seconds > 0 else { return }
        try await ContinuousClock().sleep(
            for: .milliseconds(Int64((seconds * 1_000).rounded(.up)))
        )
    }
}

private enum ESIMarketRequestBlock {
    case rateLimit(Date)
    case errorLimit(Date)

    var until: Date {
        switch self {
        case .rateLimit(let date), .errorLimit(let date):
            date
        }
    }
}

private enum ESIMarketCompatibilityDateValidator {
    static func validated(_ value: String) -> String? {
        guard value.count == 10 else { return nil }
        let parts = value.split(
            separator: "-",
            omittingEmptySubsequences: false
        )
        guard parts.count == 3,
              parts[0].count == 4,
              parts[1].count == 2,
              parts[2].count == 2,
              parts.allSatisfy({ $0.allSatisfy(\.isNumber) }),
              let year = Int(parts[0]),
              let month = Int(parts[1]),
              let day = Int(parts[2]) else {
            return nil
        }
        var calendar = Calendar(identifier: .gregorian)
        guard let utc = TimeZone(secondsFromGMT: 0) else { return nil }
        calendar.timeZone = utc
        let components = DateComponents(
            calendar: calendar,
            timeZone: utc,
            year: year,
            month: month,
            day: day
        )
        guard let date = components.date else { return nil }
        let resolved = calendar.dateComponents(
            [.year, .month, .day],
            from: date
        )
        return resolved.year == year
            && resolved.month == month
            && resolved.day == day
            ? value
            : nil
    }
}

private struct OrderPayload: Decodable {
    let orderID: Int64
    let typeID: Int64
    let locationID: Int64
    let isBuyOrder: Bool
    let price: Decimal
    let volumeRemain: Int64

    enum CodingKeys: String, CodingKey {
        case orderID = "order_id"
        case typeID = "type_id"
        case locationID = "location_id"
        case isBuyOrder = "is_buy_order"
        case price
        case volumeRemain = "volume_remain"
    }

    func order(expectedTypeID: Int64) throws -> ESIMarketSellOrder {
        guard orderID > 0, typeID == expectedTypeID,
              locationID > 0, !isBuyOrder, volumeRemain > 0,
              price > 0 else {
            throw ESIMarketPriceError.invalidResponse
        }
        var scaled = price * 100
        var rounded = Decimal()
        NSDecimalRound(&rounded, &scaled, 0, .up)
        guard rounded <= Decimal(Int64.max),
              rounded >= Decimal(1) else {
            throw ESIMarketPriceError.invalidResponse
        }
        let hundredths = NSDecimalNumber(decimal: rounded).int64Value
        return ESIMarketSellOrder(
            orderID: orderID,
            typeID: typeID,
            locationID: locationID,
            unitPrice: try ISKAmount(hundredths: hundredths),
            remainingVolume: volumeRemain
        )
    }
}
