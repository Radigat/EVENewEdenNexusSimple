import Foundation
import NewEdenNexusApplication

public struct ESIPersonalDataClientConfiguration: Equatable, Sendable {
    public let baseURL: URL
    public let compatibilityDate: String
    public let userAgent: SDEUserAgentConfiguration
    public let timeout: TimeInterval
    public let maximumResponseBytes: Int
    public let maximumPages: Int
    public let maximumRecords: Int
    public let retryDelay: TimeInterval

    public init(
        baseURL: URL? = nil,
        compatibilityDate: String,
        userAgent: SDEUserAgentConfiguration,
        timeout: TimeInterval = 30,
        maximumResponseBytes: Int = 5 * 1_024 * 1_024,
        maximumPages: Int = 100,
        maximumRecords: Int = 250_000,
        retryDelay: TimeInterval = 1
    ) throws {
        guard let resolved = baseURL
                ?? URL(string: "https://esi.evetech.net/"),
              resolved.scheme == "https",
              resolved.host == "esi.evetech.net",
              resolved.path == "/",
              resolved.user == nil,
              resolved.password == nil,
              resolved.query == nil,
              resolved.fragment == nil,
              Self.isISODate(compatibilityDate),
              timeout > 0,
              maximumResponseBytes > 0,
              maximumPages > 0,
              maximumPages <= 100,
              maximumRecords > 0,
              retryDelay >= 0 else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        self.baseURL = resolved
        self.compatibilityDate = compatibilityDate
        self.userAgent = userAgent
        self.timeout = timeout
        self.maximumResponseBytes = maximumResponseBytes
        self.maximumPages = maximumPages
        self.maximumRecords = maximumRecords
        self.retryDelay = retryDelay
    }

    private static func isISODate(_ value: String) -> Bool {
        let components = value.split(
            separator: "-",
            omittingEmptySubsequences: false
        )
        guard value.count == 10,
              components.count == 3,
              components[0].count == 4,
              components[1].count == 2,
              components[2].count == 2,
              components.allSatisfy({ $0.allSatisfy(\.isNumber) }),
              let year = Int(components[0]),
              let month = Int(components[1]),
              let day = Int(components[2]),
              let utc = TimeZone(secondsFromGMT: 0) else {
            return false
        }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = utc
        guard let date = calendar.date(
            from: DateComponents(
                timeZone: utc,
                year: year,
                month: month,
                day: day
            )
        ) else {
            return false
        }
        let resolved = calendar.dateComponents(
            [.year, .month, .day],
            from: date
        )
        return resolved.year == year
            && resolved.month == month
            && resolved.day == day
    }
}

protocol ESIPersonalBackoffSleeping: Sendable {
    func sleep(seconds: TimeInterval) async throws
}

private struct ContinuousESIPersonalBackoffSleeper:
    ESIPersonalBackoffSleeping
{
    func sleep(seconds: TimeInterval) async throws {
        guard seconds > 0 else {
            return
        }
        try await ContinuousClock().sleep(
            for: .milliseconds(Int64((seconds * 1_000).rounded(.up)))
        )
    }
}

public actor URLSessionESIPersonalDataClient:
    ESIPersonalDataRemoteFetching
{
    private struct ResponseMetadata {
        let checkedAt: Date
        let expiresAt: Date?
        let validators: ESICacheValidators
        let compatibilityDate: String
        let rateLimit: ESIRateLimitSnapshot
        let pageCount: Int?
    }

    private enum PageResult {
        case modified(Data, ResponseMetadata)
        case notModified(ResponseMetadata)

        var metadata: ResponseMetadata {
            switch self {
            case .modified(_, let metadata),
                    .notModified(let metadata):
                metadata
            }
        }
    }

    private enum RequestBlock {
        case rate(Date)
        case error(Date)

        var until: Date {
            switch self {
            case .rate(let date), .error(let date):
                date
            }
        }

        var failure: ESIPersonalDataError {
            switch self {
            case .rate(let date):
                .rateLimited(until: date)
            case .error(let date):
                .errorLimited(until: date)
            }
        }
    }

    private let configuration: ESIPersonalDataClientConfiguration
    private let transport: any ESIHTTPTransport
    private let sleeper: any ESIPersonalBackoffSleeping
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var requestBlock: RequestBlock?

    public init(configuration: ESIPersonalDataClientConfiguration) {
        self.configuration = configuration
        transport = URLSessionESIHTTPTransport()
        sleeper = ContinuousESIPersonalBackoffSleeper()
        now = Date.init
        makeID = UUID.init
    }

    init(
        configuration: ESIPersonalDataClientConfiguration,
        transport: any ESIHTTPTransport,
        sleeper: any ESIPersonalBackoffSleeping,
        now: @escaping @Sendable () -> Date,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.configuration = configuration
        self.transport = transport
        self.sleeper = sleeper
        self.now = now
        self.makeID = makeID
    }

    public func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> ESIPersonalDataSnapshot {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        guard !accessToken.isEmpty,
              accessToken.utf8.count <= 16_384,
              accessToken.rangeOfCharacter(from: .newlines) == nil else {
            throw ESIPersonalDataError.authorizationRequired
        }
        try Task.checkCancellation()
        if let existing,
           existing.characterID == characterID,
           existing.assetMetadata.isFresh(at: now()),
           existing.blueprintMetadata.isFresh(at: now()),
           existing.jobMetadata.isFresh(at: now()) {
            return existing
        }

        let assets = try await fetchAssets(
            characterID: characterID,
            accessToken: accessToken,
            existing: existing
        )
        let blueprints = try await fetchBlueprints(
            characterID: characterID,
            accessToken: accessToken,
            existing: existing
        )
        let jobs = try await fetchJobs(
            characterID: characterID,
            accessToken: accessToken,
            existing: existing
        )
        try Task.checkCancellation()
        return try ESIPersonalDataSnapshot(
            revision: makeID(),
            characterID: characterID,
            synchronizedAt: now(),
            assets: assets.values,
            blueprints: blueprints.values,
            industryJobs: jobs.values,
            assetMetadata: assets.metadata,
            blueprintMetadata: blueprints.metadata,
            jobMetadata: jobs.metadata
        )
    }

    private func fetchAssets(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> (
        values: [ESICharacterAsset],
        metadata: ESIPersonalEndpointMetadata
    ) {
        try await fetchPaged(
            path: "characters/\(characterID)/assets",
            accessToken: accessToken,
            existingValues: existing?.assets ?? [],
            existingMetadata: existing?.assetMetadata,
            pageOf: \.sourcePage
        ) { data, page in
            let payload: [AssetPayload]
            do {
                payload = try JSONDecoder().decode(
                    [AssetPayload].self,
                    from: data
                )
            } catch {
                throw ESIPersonalDataError.invalidResponse
            }
            return try payload.map { try $0.value(page: page) }
        }
    }

    private func fetchBlueprints(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> (
        values: [ESICharacterBlueprint],
        metadata: ESIPersonalEndpointMetadata
    ) {
        try await fetchPaged(
            path: "characters/\(characterID)/blueprints",
            accessToken: accessToken,
            existingValues: existing?.blueprints ?? [],
            existingMetadata: existing?.blueprintMetadata,
            pageOf: \.sourcePage
        ) { data, page in
            let payload: [BlueprintPayload]
            do {
                payload = try JSONDecoder().decode(
                    [BlueprintPayload].self,
                    from: data
                )
            } catch {
                throw ESIPersonalDataError.invalidResponse
            }
            return try payload.map { try $0.value(page: page) }
        }
    }

    private func fetchJobs(
        characterID: Int64,
        accessToken: String,
        existing: ESIPersonalDataSnapshot?
    ) async throws -> (
        values: [ESICharacterIndustryJob],
        metadata: ESIPersonalEndpointMetadata
    ) {
        let previousMetadata = existing?.jobMetadata
        let result = try await request(
            path: "characters/\(characterID)/industry/jobs",
            queryItems: [
                URLQueryItem(name: "include_completed", value: "true")
            ],
            accessToken: accessToken,
            validators: previousMetadata?.validatorsByPage[1],
            expectsPagination: false
        )
        let values: [ESICharacterIndustryJob]
        switch result {
        case .modified(let data, _):
            let payload: [IndustryJobPayload]
            do {
                payload = try JSONDecoder.esi.decode(
                    [IndustryJobPayload].self,
                    from: data
                )
            } catch {
                throw ESIPersonalDataError.invalidResponse
            }
            values = try payload.map { try $0.value() }
        case .notModified:
            guard let existing else {
                throw ESIPersonalDataError.invalidResponse
            }
            values = existing.industryJobs
        }
        guard values.count <= configuration.maximumRecords else {
            throw ESIPersonalDataError.recordLimitExceeded
        }
        let response = result.metadata
        let validators = mergedValidators(
            response.validators,
            fallback: previousMetadata?.validatorsByPage[1]
        )
        return (
            values,
            try ESIPersonalEndpointMetadata(
                checkedAt: response.checkedAt,
                expiresAt: response.expiresAt
                    ?? previousMetadata?.expiresAt,
                compatibilityDate: response.compatibilityDate,
                pageCount: 1,
                validatorsByPage: [1: validators],
                rateLimit: response.rateLimit
            )
        )
    }

    private func fetchPaged<Value: Sendable>(
        path: String,
        accessToken: String,
        existingValues: [Value],
        existingMetadata: ESIPersonalEndpointMetadata?,
        pageOf: KeyPath<Value, Int>,
        decode: (Data, Int) throws -> [Value]
    ) async throws -> (
        values: [Value],
        metadata: ESIPersonalEndpointMetadata
    ) {
        var values: [Value] = []
        var validators: [Int: ESICacheValidators] = [:]
        var expectedLastModified: String?
        var earliestExpiry: Date?
        var lastMetadata: ResponseMetadata?
        var pageCount = 1

        let first = try await request(
            path: path,
            queryItems: [URLQueryItem(name: "page", value: "1")],
            accessToken: accessToken,
            validators: existingMetadata?.validatorsByPage[1],
            expectsPagination: true
        )
        pageCount = first.metadata.pageCount
            ?? existingMetadata?.pageCount
            ?? 1
        guard pageCount > 0,
              pageCount <= configuration.maximumPages else {
            throw ESIPersonalDataError.pageLimitExceeded
        }

        for page in 1...pageCount {
            try Task.checkCancellation()
            let result = page == 1
                ? first
                : try await request(
                    path: path,
                    queryItems: [
                        URLQueryItem(
                            name: "page",
                            value: String(page)
                        )
                    ],
                    accessToken: accessToken,
                    validators:
                        existingMetadata?.validatorsByPage[page],
                    expectsPagination: true
                )
            let metadata = result.metadata
            if let returnedPages = metadata.pageCount,
               returnedPages != pageCount {
                throw ESIPersonalDataError.inconsistentPagination
            }
            let merged = mergedValidators(
                metadata.validators,
                fallback: existingMetadata?.validatorsByPage[page]
            )
            guard let lastModified = merged.lastModified else {
                throw ESIPersonalDataError.inconsistentPagination
            }
            if let expectedLastModified,
               expectedLastModified != lastModified {
                throw ESIPersonalDataError.inconsistentPagination
            }
            expectedLastModified = lastModified
            validators[page] = merged
            if let expiry = metadata.expiresAt {
                earliestExpiry = min(earliestExpiry ?? expiry, expiry)
            }
            lastMetadata = metadata
            switch result {
            case .modified(let data, _):
                values += try decode(data, page)
            case .notModified:
                let oldPage = existingValues.filter {
                    $0[keyPath: pageOf] == page
                }
                guard existingMetadata != nil else {
                    throw ESIPersonalDataError.invalidResponse
                }
                values += oldPage
            }
            guard values.count <= configuration.maximumRecords else {
                throw ESIPersonalDataError.recordLimitExceeded
            }
        }
        guard let lastMetadata else {
            throw ESIPersonalDataError.invalidResponse
        }
        return (
            values,
            try ESIPersonalEndpointMetadata(
                checkedAt: lastMetadata.checkedAt,
                expiresAt: earliestExpiry ?? existingMetadata?.expiresAt,
                compatibilityDate: lastMetadata.compatibilityDate,
                pageCount: pageCount,
                validatorsByPage: validators,
                rateLimit: lastMetadata.rateLimit
            )
        )
    }

    private func request(
        path: String,
        queryItems: [URLQueryItem],
        accessToken: String,
        validators: ESICacheValidators?,
        expectsPagination: Bool
    ) async throws -> PageResult {
        let requestDate = now()
        if let requestBlock, requestBlock.until > requestDate {
            throw requestBlock.failure
        }
        requestBlock = nil
        guard isSafeValidator(validators?.etag),
              isSafeValidator(validators?.lastModified),
              var components = URLComponents(
                url: configuration.baseURL
                    .appendingPathComponent(path),
                resolvingAgainstBaseURL: false
              ) else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        components.queryItems = queryItems
        guard let url = components.url else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        request.setValue(
            "Bearer \(accessToken)",
            forHTTPHeaderField: "Authorization"
        )
        if let etag = validators?.etag {
            request.setValue(etag, forHTTPHeaderField: "If-None-Match")
        }
        if let modified = validators?.lastModified {
            request.setValue(
                modified,
                forHTTPHeaderField: "If-Modified-Since"
            )
        }

        for attempt in 0...1 {
            let response: ESIHTTPResponse
            do {
                response = try await transport.execute(request)
            } catch is CancellationError {
                throw CancellationError()
            } catch let error as URLError {
                switch error.code {
                case .cancelled:
                    throw CancellationError()
                case .notConnectedToInternet, .timedOut,
                        .networkConnectionLost, .cannotFindHost,
                        .cannotConnectToHost, .dnsLookupFailed:
                    throw ESIPersonalDataError.offline
                default:
                    throw ESIPersonalDataError.transport
                }
            } catch {
                throw ESIPersonalDataError.transport
            }
            guard response.finalURL.scheme == "https",
                  response.finalURL.host == "esi.evetech.net",
                  response.data.count
                    <= configuration.maximumResponseBytes else {
                if response.data.count
                    > configuration.maximumResponseBytes {
                    throw ESIPersonalDataError.responseTooLarge
                }
                throw ESIPersonalDataError.invalidResponse
            }
            let metadata = try responseMetadata(
                response,
                expectsPagination: expectsPagination
            )
            switch response.statusCode {
            case 200:
                return .modified(response.data, metadata)
            case 304:
                guard response.data.isEmpty else {
                    throw ESIPersonalDataError.invalidResponse
                }
                return .notModified(metadata)
            case 401:
                throw ESIPersonalDataError.authorizationRequired
            case 403:
                throw ESIPersonalDataError.permissionDenied
            case 420:
                guard let seconds = Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                ), seconds >= 0 else {
                    throw ESIPersonalDataError.invalidResponse
                }
                let until = metadata.checkedAt.addingTimeInterval(
                    TimeInterval(seconds)
                )
                requestBlock = .error(until)
                throw ESIPersonalDataError.errorLimited(until: until)
            case 429:
                guard let until = retryDate(
                    response.header("retry-after"),
                    relativeTo: metadata.checkedAt
                ) else {
                    throw ESIPersonalDataError.invalidResponse
                }
                requestBlock = .rate(until)
                throw ESIPersonalDataError.rateLimited(until: until)
            case 500...599:
                if attempt == 0 {
                    try await sleeper.sleep(
                        seconds: configuration.retryDelay
                    )
                    try Task.checkCancellation()
                    continue
                }
                throw ESIPersonalDataError.serverUnavailable
            default:
                throw ESIPersonalDataError.invalidResponse
            }
        }
        throw ESIPersonalDataError.serverUnavailable
    }

    private func responseMetadata(
        _ response: ESIHTTPResponse,
        expectsPagination: Bool
    ) throws -> ResponseMetadata {
        let checkedAt = now()
        let etag = response.header("etag")
        let lastModified = response.header("last-modified")
        guard isSafeValidator(etag),
              isSafeValidator(lastModified) else {
            throw ESIPersonalDataError.invalidResponse
        }
        let pageCount: Int?
        if let rawPages = response.header("x-pages") {
            guard let parsed = Int(rawPages), parsed > 0 else {
                throw ESIPersonalDataError.invalidResponse
            }
            pageCount = parsed
        } else {
            pageCount = nil
        }
        if expectsPagination,
           response.statusCode == 200,
           pageCount == nil {
            throw ESIPersonalDataError.invalidResponse
        }
        return ResponseMetadata(
            checkedAt: checkedAt,
            expiresAt: cacheExpiry(
                response: response,
                relativeTo: checkedAt
            ),
            validators: ESICacheValidators(
                etag: etag,
                lastModified: lastModified
            ),
            compatibilityDate:
                validatedDate(
                    response.header("x-compatibility-date")
                ) ?? configuration.compatibilityDate,
            rateLimit: ESIRateLimitSnapshot(
                group: response.header("x-ratelimit-group"),
                limit: response.header("x-ratelimit-limit"),
                remaining: Int(
                    response.header("x-ratelimit-remaining") ?? ""
                ),
                used: Int(response.header("x-ratelimit-used") ?? ""),
                errorLimitRemaining: Int(
                    response.header("x-esi-error-limit-remain") ?? ""
                ),
                errorLimitResetSeconds: Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                )
            ),
            pageCount: pageCount
        )
    }

    private func mergedValidators(
        _ current: ESICacheValidators,
        fallback: ESICacheValidators?
    ) -> ESICacheValidators {
        ESICacheValidators(
            etag: current.etag ?? fallback?.etag,
            lastModified:
                current.lastModified ?? fallback?.lastModified
        )
    }

    private func cacheExpiry(
        response: ESIHTTPResponse,
        relativeTo date: Date
    ) -> Date? {
        if let cacheControl = response.header("cache-control") {
            for component in cacheControl.split(separator: ",") {
                let pair = component
                    .trimmingCharacters(in: .whitespaces)
                    .split(separator: "=", maxSplits: 1)
                if pair.count == 2,
                   pair[0].lowercased() == "max-age",
                   let seconds = TimeInterval(pair[1]),
                   seconds >= 0 {
                    return date.addingTimeInterval(seconds)
                }
            }
        }
        return httpDate(response.header("expires"))
    }

    private func retryDate(
        _ value: String?,
        relativeTo date: Date
    ) -> Date? {
        guard let value else {
            return nil
        }
        if let seconds = TimeInterval(value), seconds >= 0 {
            return date.addingTimeInterval(seconds)
        }
        return httpDate(value)
    }

    private func httpDate(_ value: String?) -> Date? {
        guard let value else {
            return nil
        }
        for format in [
            "EEE',' dd MMM yyyy HH':'mm':'ss z",
            "EEEE',' dd-MMM-yy HH':'mm':'ss z",
            "EEE MMM d HH':'mm':'ss yyyy"
        ] {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.timeZone = TimeZone(secondsFromGMT: 0)
            formatter.dateFormat = format
            if let date = formatter.date(from: value) {
                return date
            }
        }
        return nil
    }

    private func isSafeValidator(_ value: String?) -> Bool {
        guard let value else {
            return true
        }
        return !value.isEmpty && value.utf8.count <= 1_024
            && value.rangeOfCharacter(from: .newlines) == nil
    }

    private func validatedDate(_ value: String?) -> String? {
        guard let value, value.count == 10 else {
            return nil
        }
        return try? ESIPersonalDataClientConfiguration(
            compatibilityDate: value,
            userAgent: configuration.userAgent
        ).compatibilityDate
    }
}

private struct AssetPayload: Decodable {
    let itemID: Int64
    let typeID: Int64
    let quantity: Int64
    let locationID: Int64
    let locationType: String
    let locationFlag: String
    let isSingleton: Bool
    let isBlueprintCopy: Bool?

    enum CodingKeys: String, CodingKey {
        case itemID = "item_id"
        case typeID = "type_id"
        case quantity
        case locationID = "location_id"
        case locationType = "location_type"
        case locationFlag = "location_flag"
        case isSingleton = "is_singleton"
        case isBlueprintCopy = "is_blueprint_copy"
    }

    func value(page: Int) throws -> ESICharacterAsset {
        try ESICharacterAsset(
            itemID: itemID,
            typeID: typeID,
            quantity: quantity,
            locationID: locationID,
            locationType: locationType,
            locationFlag: locationFlag,
            isSingleton: isSingleton,
            isBlueprintCopy: isBlueprintCopy,
            sourcePage: page
        )
    }
}

private struct BlueprintPayload: Decodable {
    let itemID: Int64
    let typeID: Int64
    let locationID: Int64
    let locationFlag: String
    let quantity: Int64
    let timeEfficiency: Int64
    let materialEfficiency: Int64
    let runs: Int64

    enum CodingKeys: String, CodingKey {
        case itemID = "item_id"
        case typeID = "type_id"
        case locationID = "location_id"
        case locationFlag = "location_flag"
        case quantity
        case timeEfficiency = "time_efficiency"
        case materialEfficiency = "material_efficiency"
        case runs
    }

    func value(page: Int) throws -> ESICharacterBlueprint {
        try ESICharacterBlueprint(
            itemID: itemID,
            typeID: typeID,
            locationID: locationID,
            locationFlag: locationFlag,
            quantity: quantity,
            timeEfficiency: timeEfficiency,
            materialEfficiency: materialEfficiency,
            runs: runs,
            sourcePage: page
        )
    }
}

private struct IndustryJobPayload: Decodable {
    let jobID: Int64
    let installerID: Int64
    let facilityID: Int64
    let stationID: Int64
    let activityID: Int64
    let blueprintID: Int64
    let blueprintTypeID: Int64
    let blueprintLocationID: Int64
    let outputLocationID: Int64
    let runs: Int64
    let status: String
    let duration: Int64
    let startDate: Date
    let endDate: Date
    let completedDate: Date?
    let completedCharacterID: Int64?
    let cost: Double?
    let licensedRuns: Int64?
    let pauseDate: Date?
    let probability: Double?
    let productTypeID: Int64?
    let successfulRuns: Int64?

    enum CodingKeys: String, CodingKey {
        case jobID = "job_id"
        case installerID = "installer_id"
        case facilityID = "facility_id"
        case stationID = "station_id"
        case activityID = "activity_id"
        case blueprintID = "blueprint_id"
        case blueprintTypeID = "blueprint_type_id"
        case blueprintLocationID = "blueprint_location_id"
        case outputLocationID = "output_location_id"
        case runs
        case status
        case duration
        case startDate = "start_date"
        case endDate = "end_date"
        case completedDate = "completed_date"
        case completedCharacterID = "completed_character_id"
        case cost
        case licensedRuns = "licensed_runs"
        case pauseDate = "pause_date"
        case probability
        case productTypeID = "product_type_id"
        case successfulRuns = "successful_runs"
    }

    func value() throws -> ESICharacterIndustryJob {
        try ESICharacterIndustryJob(
            jobID: jobID,
            installerID: installerID,
            facilityID: facilityID,
            stationID: stationID,
            activityID: activityID,
            blueprintID: blueprintID,
            blueprintTypeID: blueprintTypeID,
            blueprintLocationID: blueprintLocationID,
            outputLocationID: outputLocationID,
            runs: runs,
            status: status,
            duration: duration,
            startDate: startDate,
            endDate: endDate,
            completedDate: completedDate,
            completedCharacterID: completedCharacterID,
            cost: cost,
            licensedRuns: licensedRuns,
            pauseDate: pauseDate,
            probability: probability,
            productTypeID: productTypeID,
            successfulRuns: successfulRuns
        )
    }
}

private extension JSONDecoder {
    static var esi: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
