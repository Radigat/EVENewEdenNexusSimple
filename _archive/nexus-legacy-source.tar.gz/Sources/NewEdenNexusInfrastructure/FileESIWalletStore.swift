import Foundation
import NewEdenNexusApplication

public actor FileESIWalletStore: ESIWalletPersisting {
    private let directoryURL: URL
    private let fileManager: FileManager
    private let maximumBytes: Int

    public init(
        directoryURL: URL,
        fileManager: FileManager = .default,
        maximumBytes: Int = 32 * 1_024 * 1_024
    ) throws {
        guard directoryURL.isFileURL, maximumBytes > 0 else {
            throw ESIWalletError.invalidConfiguration
        }
        self.directoryURL = directoryURL.standardizedFileURL
        self.fileManager = fileManager
        self.maximumBytes = maximumBytes
    }

    public static func defaultDirectoryURL(
        fileManager: FileManager = .default
    ) throws -> URL {
        guard let applicationSupport = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw ESIWalletError.invalidConfiguration
        }
        return applicationSupport
            .appendingPathComponent("NewEdenNexus", isDirectory: true)
            .appendingPathComponent("WalletSnapshots", isDirectory: true)
    }

    public func snapshot(
        characterID: Int64
    ) async throws -> ESIWalletSnapshot? {
        let url = try fileURL(characterID: characterID)
        guard fileManager.fileExists(atPath: url.path) else {
            return nil
        }
        let values = try url.resourceValues(
            forKeys: [
                .isRegularFileKey,
                .isSymbolicLinkKey,
                .fileSizeKey
            ]
        )
        guard values.isRegularFile == true,
              values.isSymbolicLink != true,
              let size = values.fileSize,
              size > 0, size <= maximumBytes else {
            throw ESIWalletError.cacheCorrupted
        }
        do {
            let data = try Data(
                contentsOf: url,
                options: [.mappedIfSafe]
            )
            let snapshot = try JSONDecoder.esiWallet.decode(
                ESIWalletSnapshot.self,
                from: data
            )
            guard snapshot.characterID == characterID,
                  snapshot.version == ESIWalletSnapshot.payloadVersion else {
                throw ESIWalletError.cacheCorrupted
            }
            return snapshot
        } catch let error as ESIWalletError {
            throw error
        } catch {
            throw ESIWalletError.cacheCorrupted
        }
    }

    public func save(
        _ snapshot: ESIWalletSnapshot,
        expectedRevision: UUID?
    ) async throws {
        let existing = try await self.snapshot(
            characterID: snapshot.characterID
        )
        guard existing?.revision == expectedRevision else {
            throw ESIWalletError.stalePreview
        }
        try Task.checkCancellation()
        let data: Data
        do {
            data = try JSONEncoder.esiWallet.encode(snapshot)
        } catch {
            throw ESIWalletError.cacheWriteFailed
        }
        guard !data.isEmpty, data.count <= maximumBytes else {
            throw ESIWalletError.responseTooLarge
        }
        let temporary = directoryURL.appendingPathComponent(
            ".wallet-\(UUID().uuidString).partial",
            isDirectory: false
        )
        do {
            try prepareDirectory()
            let destination = try fileURL(
                characterID: snapshot.characterID
            )
            try data.write(to: temporary, options: [.atomic])
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: temporary.path
            )
            if fileManager.fileExists(atPath: destination.path) {
                _ = try fileManager.replaceItemAt(
                    destination,
                    withItemAt: temporary,
                    backupItemName: nil,
                    options: []
                )
            } else {
                try fileManager.moveItem(
                    at: temporary,
                    to: destination
                )
            }
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: destination.path
            )
        } catch is CancellationError {
            if fileManager.fileExists(atPath: temporary.path) {
                do {
                    try fileManager.removeItem(at: temporary)
                } catch {
                    throw ESIWalletError.cacheWriteFailed
                }
            }
            throw CancellationError()
        } catch {
            if fileManager.fileExists(atPath: temporary.path) {
                do {
                    try fileManager.removeItem(at: temporary)
                } catch {
                    throw ESIWalletError.cacheWriteFailed
                }
            }
            throw ESIWalletError.cacheWriteFailed
        }
    }

    public func delete(characterID: Int64) async throws {
        let url = try fileURL(characterID: characterID)
        guard fileManager.fileExists(atPath: url.path) else {
            return
        }
        do {
            let values = try url.resourceValues(
                forKeys: [.isRegularFileKey, .isSymbolicLinkKey]
            )
            guard values.isRegularFile == true,
                  values.isSymbolicLink != true else {
                throw ESIWalletError.cacheCorrupted
            }
            try fileManager.removeItem(at: url)
        } catch let error as ESIWalletError {
            throw error
        } catch {
            throw ESIWalletError.cacheWriteFailed
        }
    }

    private func prepareDirectory() throws {
        try fileManager.createDirectory(
            at: directoryURL,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700]
        )
        let values = try directoryURL.resourceValues(
            forKeys: [.isDirectoryKey, .isSymbolicLinkKey]
        )
        guard values.isDirectory == true,
              values.isSymbolicLink != true else {
            throw ESIWalletError.cacheWriteFailed
        }
        try fileManager.setAttributes(
            [.posixPermissions: 0o700],
            ofItemAtPath: directoryURL.path
        )
    }

    private func fileURL(characterID: Int64) throws -> URL {
        guard characterID > 0 else {
            throw ESIWalletError.invalidCharacterID
        }
        return directoryURL.appendingPathComponent(
            "wallet-\(characterID).json",
            isDirectory: false
        )
    }
}

private extension JSONEncoder {
    static var esiWallet: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        return encoder
    }
}

private extension JSONDecoder {
    static var esiWallet: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
