import Foundation
import NewEdenNexusApplication

public actor URLSessionESILocationNameClient:
    ESILocationNameRemoteFetching,
    ESIStructureNameRemoteFetching
{
    private struct Payload: Decodable {
        let id: Int64
        let name: String
        let category: String
    }

    private struct StructurePayload: Decodable {
        let name: String
        let solarSystemID: Int64

        enum CodingKeys: String, CodingKey {
            case name
            case solarSystemID = "solar_system_id"
        }
    }

    private let configuration: ESIPersonalDataClientConfiguration
    private let transport: any ESIHTTPTransport

    public init(configuration: ESIPersonalDataClientConfiguration) {
        self.configuration = configuration
        transport = URLSessionESIHTTPTransport()
    }

    init(
        configuration: ESIPersonalDataClientConfiguration,
        transport: any ESIHTTPTransport
    ) {
        self.configuration = configuration
        self.transport = transport
    }

    public func names(for ids: [Int64]) async throws
        -> [Int64: String]
    {
        let unique = Array(Set(ids)).sorted()
        guard !unique.isEmpty,
              unique.allSatisfy({ $0 > 0 }),
              unique.count <= 10_000 else {
            throw ESIPersonalDataError.invalidResponse
        }
        var result: [Int64: String] = [:]
        for start in stride(from: 0, to: unique.count, by: 1_000) {
            try Task.checkCancellation()
            let end = min(start + 1_000, unique.count)
            let batch = Array(unique[start..<end])
            let values = try await request(batch)
            for value in values {
                guard batch.contains(value.id),
                      value.category == "station"
                        || value.category == "solar_system",
                      isSafeName(value.name),
                      result.updateValue(
                          value.name.trimmingCharacters(
                              in: .whitespacesAndNewlines
                          ),
                          forKey: value.id
                      ) == nil else {
                    throw ESIPersonalDataError.invalidResponse
                }
            }
        }
        return result
    }

    public func name(
        structureID: Int64,
        accessToken: String,
        validators: ESICacheValidators?
    ) async throws -> ESIStructureNameRemoteResult {
        guard structureID >= 1_000_000_000_000,
              !accessToken.isEmpty,
              accessToken.utf8.count <= 16_384,
              accessToken.rangeOfCharacter(from: .newlines) == nil,
              let url = URL(
                  string: "universe/structures/\(structureID)",
                  relativeTo: configuration.baseURL
              )?.absoluteURL else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        let checkedAt = Date()
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(
            "Bearer \(accessToken)",
            forHTTPHeaderField: "Authorization"
        )
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        if let etag = validators?.etag {
            request.setValue(etag, forHTTPHeaderField: "If-None-Match")
        }
        if let modified = validators?.lastModified {
            request.setValue(
                modified,
                forHTTPHeaderField: "If-Modified-Since"
            )
        }

        let response = try await execute(request)
        guard response.finalURL.scheme == "https",
              response.finalURL.host == "esi.evetech.net",
              response.data.count
                <= configuration.maximumResponseBytes else {
            throw ESIPersonalDataError.invalidResponse
        }
        switch response.statusCode {
        case 200:
            let payload: StructurePayload
            do {
                payload = try JSONDecoder().decode(
                    StructurePayload.self,
                    from: response.data
                )
            } catch {
                throw ESIPersonalDataError.invalidResponse
            }
            guard isSafeName(payload.name),
                  payload.solarSystemID > 0 else {
                throw ESIPersonalDataError.invalidResponse
            }
            return .modified(
                name: payload.name.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ),
                solarSystemID: payload.solarSystemID,
                metadata: responseMetadata(
                    response,
                    checkedAt: checkedAt
                )
            )
        case 304:
            return .notModified(
                metadata: responseMetadata(
                    response,
                    checkedAt: checkedAt
                )
            )
        case 403, 404:
            return .inaccessible
        case 420, 429:
            throw ESIPersonalDataError.rateLimited(
                until: retryDate(response, relativeTo: checkedAt)
            )
        case 500...599:
            throw ESIPersonalDataError.serverUnavailable
        default:
            throw ESIPersonalDataError.invalidResponse
        }
    }

    private func request(_ ids: [Int64]) async throws -> [Payload] {
        guard let url = URL(
            string: "universe/names",
            relativeTo: configuration.baseURL
        )?.absoluteURL else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(
            "application/json",
            forHTTPHeaderField: "Content-Type"
        )
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        request.httpBody = try JSONEncoder().encode(ids)

        let response: ESIHTTPResponse
        do {
            response = try await transport.execute(request)
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as URLError {
            switch error.code {
            case .cancelled:
                throw CancellationError()
            case .notConnectedToInternet, .timedOut,
                    .networkConnectionLost, .cannotFindHost,
                    .cannotConnectToHost, .dnsLookupFailed:
                throw ESIPersonalDataError.offline
            default:
                throw ESIPersonalDataError.transport
            }
        } catch {
            throw ESIPersonalDataError.transport
        }
        guard response.finalURL.scheme == "https",
              response.finalURL.host == "esi.evetech.net",
              response.data.count
                <= configuration.maximumResponseBytes else {
            throw ESIPersonalDataError.invalidResponse
        }
        switch response.statusCode {
        case 200:
            do {
                return try JSONDecoder().decode(
                    [Payload].self,
                    from: response.data
                )
            } catch {
                throw ESIPersonalDataError.invalidResponse
            }
        case 420, 429:
            throw ESIPersonalDataError.rateLimited(until: Date())
        case 500...599:
            throw ESIPersonalDataError.serverUnavailable
        default:
            throw ESIPersonalDataError.invalidResponse
        }
    }

    private func execute(_ request: URLRequest) async throws
        -> ESIHTTPResponse
    {
        do {
            return try await transport.execute(request)
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as URLError {
            switch error.code {
            case .cancelled:
                throw CancellationError()
            case .notConnectedToInternet, .timedOut,
                    .networkConnectionLost, .cannotFindHost,
                    .cannotConnectToHost, .dnsLookupFailed:
                throw ESIPersonalDataError.offline
            default:
                throw ESIPersonalDataError.transport
            }
        } catch {
            throw ESIPersonalDataError.transport
        }
    }

    private func responseMetadata(
        _ response: ESIHTTPResponse,
        checkedAt: Date
    ) -> ESIResponseMetadata {
        ESIResponseMetadata(
            checkedAt: checkedAt,
            expiresAt: expiry(response, relativeTo: checkedAt),
            validators: ESICacheValidators(
                etag: response.header("etag"),
                lastModified: response.header("last-modified")
            ),
            compatibilityDate: configuration.compatibilityDate
        )
    }

    private func expiry(
        _ response: ESIHTTPResponse,
        relativeTo date: Date
    ) -> Date? {
        if let cacheControl = response.header("cache-control"),
           let maxAge = cacheControl
            .split(separator: ",")
            .map({
                $0.trimmingCharacters(in: .whitespaces)
            })
            .first(where: { $0.hasPrefix("max-age=") })?
            .dropFirst("max-age=".count),
           let seconds = TimeInterval(maxAge) {
            return date.addingTimeInterval(max(0, seconds))
        }
        return httpDate(response.header("expires"))
    }

    private func retryDate(
        _ response: ESIHTTPResponse,
        relativeTo date: Date
    ) -> Date {
        guard let value = response.header("retry-after") else {
            return date.addingTimeInterval(60)
        }
        if let seconds = TimeInterval(value) {
            return date.addingTimeInterval(max(0, seconds))
        }
        return httpDate(value) ?? date.addingTimeInterval(60)
    }

    private func httpDate(_ value: String?) -> Date? {
        guard let value else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "EEE',' dd MMM yyyy HH':'mm':'ss z"
        return formatter.date(from: value)
    }

    private func isSafeName(_ value: String) -> Bool {
        let trimmed = value.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        return !trimmed.isEmpty
            && trimmed.utf8.count <= 512
            && value.rangeOfCharacter(from: .newlines) == nil
    }
}

public actor FileESILocationNameStore: ESILocationNamePersisting {
    private let directoryURL: URL
    private let maximumByteCount: Int
    private let fileManager: FileManager

    public init(
        directoryURL: URL,
        maximumByteCount: Int = 2 * 1_024 * 1_024,
        fileManager: FileManager = .default
    ) throws {
        guard directoryURL.isFileURL, maximumByteCount > 0 else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        self.directoryURL = directoryURL.standardizedFileURL
        self.maximumByteCount = maximumByteCount
        self.fileManager = fileManager
    }

    public static func defaultDirectoryURL(
        fileManager: FileManager = .default
    ) throws -> URL {
        guard let applicationSupport = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw ESIPersonalDataError.invalidConfiguration
        }
        return applicationSupport
            .appendingPathComponent("New Eden Nexus", isDirectory: true)
            .appendingPathComponent("ESI", isDirectory: true)
            .appendingPathComponent("LocationNames", isDirectory: true)
    }

    public func cache(characterID: Int64) async throws
        -> ESILocationNameCache?
    {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        let url = fileURL(characterID: characterID)
        guard fileManager.fileExists(atPath: url.path) else {
            return nil
        }
        return try load(url: url, characterID: characterID)
    }

    public func save(_ cache: ESILocationNameCache) async throws {
        try Task.checkCancellation()
        do {
            try prepareDirectory()
            let data = try JSONEncoder().encode(cache)
            guard data.count <= maximumByteCount else {
                throw ESIPersonalDataError.responseTooLarge
            }
            let url = fileURL(characterID: cache.characterID)
            try data.write(to: url, options: .atomic)
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
            guard try load(
                url: url,
                characterID: cache.characterID
            ) == cache else {
                throw ESIPersonalDataError.cacheWriteFailed
            }
        } catch let error as ESIPersonalDataError {
            throw error
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            throw ESIPersonalDataError.cacheWriteFailed
        }
    }

    public func delete(characterID: Int64) async throws {
        guard characterID > 0 else {
            throw ESIPersonalDataError.invalidCharacterID
        }
        let url = fileURL(characterID: characterID)
        guard fileManager.fileExists(atPath: url.path) else {
            return
        }
        do {
            let values = try url.resourceValues(
                forKeys: [.isRegularFileKey, .isSymbolicLinkKey]
            )
            guard values.isRegularFile == true,
                  values.isSymbolicLink != true else {
                throw ESIPersonalDataError.cacheCorrupted
            }
            try fileManager.removeItem(at: url)
        } catch let error as ESIPersonalDataError {
            throw error
        } catch {
            throw ESIPersonalDataError.cacheWriteFailed
        }
    }

    private func prepareDirectory() throws {
        try fileManager.createDirectory(
            at: directoryURL,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700]
        )
        try fileManager.setAttributes(
            [.posixPermissions: 0o700],
            ofItemAtPath: directoryURL.path
        )
        let values = try directoryURL.resourceValues(
            forKeys: [.isDirectoryKey, .isSymbolicLinkKey]
        )
        guard values.isDirectory == true,
              values.isSymbolicLink != true else {
            throw ESIPersonalDataError.cacheWriteFailed
        }
    }

    private func fileURL(characterID: Int64) -> URL {
        directoryURL.appendingPathComponent(
            "character-\(characterID)-v1.json",
            isDirectory: false
        )
    }

    private func load(
        url: URL,
        characterID: Int64
    ) throws -> ESILocationNameCache {
        let values = try url.resourceValues(
            forKeys: [
                .isRegularFileKey,
                .isSymbolicLinkKey,
                .fileSizeKey
            ]
        )
        guard values.isRegularFile == true,
              values.isSymbolicLink != true,
              let size = values.fileSize,
              size <= maximumByteCount else {
            throw ESIPersonalDataError.cacheCorrupted
        }
        do {
            let data = try Data(contentsOf: url)
            let cache = try JSONDecoder().decode(
                ESILocationNameCache.self,
                from: data
            )
            guard cache.version == ESILocationNameCache.payloadVersion,
                  cache.characterID == characterID else {
                throw ESIPersonalDataError.cacheCorrupted
            }
            return cache
        } catch let error as ESIPersonalDataError {
            throw error
        } catch {
            throw ESIPersonalDataError.cacheCorrupted
        }
    }
}
