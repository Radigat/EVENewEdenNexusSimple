import Foundation
import NewEdenNexusApplication

public actor SDEArchiveRecoveryBoundary: SDEArchiveDownloading {
    private let downloadDirectoryURL: URL
    private let cacheDirectoryURL: URL
    private let fileManager: FileManager

    public init(
        downloadDirectoryURL: URL,
        cacheDirectoryURL: URL,
        fileManager: FileManager = .default
    ) {
        self.downloadDirectoryURL = downloadDirectoryURL
        self.cacheDirectoryURL = cacheDirectoryURL
        self.fileManager = fileManager
    }

    public func download(
        _ request: SDEArchiveDownloadRequest
    ) async throws -> SDEArchiveDownload {
        throw SDEInstallationError.transport
    }

    public func cleanup(operationID: UUID) async throws {
        for directory in [
            downloadDirectoryURL.appendingPathComponent(
                operationID.uuidString,
                isDirectory: true
            ),
            cacheDirectoryURL
                .appendingPathComponent("handoff", isDirectory: true)
                .appendingPathComponent(
                    operationID.uuidString,
                    isDirectory: true
                )
        ] where fileManager.fileExists(atPath: directory.path) {
            try fileManager.removeItem(at: directory)
        }
    }
}
