import NewEdenNexusApplication
import NewEdenNexusDomain

public struct NativeMaterialSummaryService: MaterialSummarizing, Sendable {
    private let calculator: MaterialSummaryCalculator

    public init(calculator: MaterialSummaryCalculator = MaterialSummaryCalculator()) {
        self.calculator = calculator
    }

    public func summarize(lines: [MaterialLine]) async throws -> MaterialSummary {
        try calculator.summarize(lines: lines)
    }
}
