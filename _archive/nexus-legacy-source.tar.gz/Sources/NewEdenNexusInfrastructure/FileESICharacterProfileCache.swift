import Foundation
import NewEdenNexusApplication

public actor FileESICharacterProfileCache: ESICharacterProfileCaching {
    public static let defaultMaximumByteCount = 1_048_576

    private let fileURL: URL
    private let maximumByteCount: Int
    private let fileManager: FileManager

    public init(
        fileURL: URL,
        maximumByteCount: Int = defaultMaximumByteCount,
        fileManager: FileManager = .default
    ) throws {
        guard fileURL.isFileURL,
              maximumByteCount > 0 else {
            throw ESICharacterSyncError.invalidConfiguration
        }
        self.fileURL = fileURL.standardizedFileURL
        self.maximumByteCount = maximumByteCount
        self.fileManager = fileManager
    }

    public static func defaultFileURL(
        fileManager: FileManager = .default
    ) throws -> URL {
        guard let applicationSupport = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw ESICharacterSyncError.invalidConfiguration
        }
        return applicationSupport
            .appendingPathComponent("New Eden Nexus", isDirectory: true)
            .appendingPathComponent("ESI", isDirectory: true)
            .appendingPathComponent(
                "character-profiles-v1.json",
                isDirectory: false
            )
    }

    public func snapshot(
        characterID: Int64
    ) async throws -> ESICharacterProfileSnapshot? {
        guard characterID > 0 else {
            throw ESICharacterSyncError.invalidCharacterID
        }
        return try load().snapshots.first {
            $0.profile.characterID == characterID
        }
    }

    public func save(
        _ snapshot: ESICharacterProfileSnapshot
    ) async throws {
        try Task.checkCancellation()
        var document = try load()
        document.snapshots.removeAll {
            $0.profile.characterID == snapshot.profile.characterID
        }
        document.snapshots.append(snapshot)
        document.snapshots.sort {
            $0.profile.characterID < $1.profile.characterID
        }
        try write(document)
    }

    public func delete(characterID: Int64) async throws {
        guard characterID > 0 else {
            throw ESICharacterSyncError.invalidCharacterID
        }
        try Task.checkCancellation()
        guard fileManager.fileExists(atPath: fileURL.path) else {
            return
        }
        var document = try load()
        let previousCount = document.snapshots.count
        document.snapshots.removeAll {
            $0.profile.characterID == characterID
        }
        guard document.snapshots.count != previousCount else {
            return
        }
        if document.snapshots.isEmpty {
            do {
                try fileManager.removeItem(at: fileURL)
            } catch {
                throw ESICharacterSyncError.cacheWriteFailed
            }
        } else {
            try write(document)
        }
    }

    private func load() throws -> CacheDocument {
        guard fileManager.fileExists(atPath: fileURL.path) else {
            return CacheDocument(version: 1, snapshots: [])
        }
        let values: URLResourceValues
        do {
            values = try fileURL.resourceValues(
                forKeys: [
                    .isRegularFileKey,
                    .isSymbolicLinkKey,
                    .fileSizeKey
                ]
            )
        } catch {
            throw ESICharacterSyncError.cacheCorrupted
        }
        guard values.isRegularFile == true,
              values.isSymbolicLink != true,
              let size = values.fileSize,
              size <= maximumByteCount else {
            throw ESICharacterSyncError.cacheCorrupted
        }
        let data: Data
        do {
            data = try Data(contentsOf: fileURL)
        } catch {
            throw ESICharacterSyncError.cacheCorrupted
        }
        guard data.count <= maximumByteCount,
              let document = try? JSONDecoder().decode(
                CacheDocument.self,
                from: data
              ),
              document.version == 1,
              isValid(document) else {
            throw ESICharacterSyncError.cacheCorrupted
        }
        return document
    }

    private func write(_ document: CacheDocument) throws {
        guard isValid(document) else {
            throw ESICharacterSyncError.cacheWriteFailed
        }
        let directoryURL = fileURL.deletingLastPathComponent()
        do {
            try fileManager.createDirectory(
                at: directoryURL,
                withIntermediateDirectories: true,
                attributes: [.posixPermissions: 0o700]
            )
            try fileManager.setAttributes(
                [.posixPermissions: 0o700],
                ofItemAtPath: directoryURL.path
            )
            let directoryValues = try directoryURL.resourceValues(
                forKeys: [.isDirectoryKey, .isSymbolicLinkKey]
            )
            guard directoryValues.isDirectory == true,
                  directoryValues.isSymbolicLink != true else {
                throw ESICharacterSyncError.cacheWriteFailed
            }
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.sortedKeys]
            let data = try encoder.encode(document)
            guard data.count <= maximumByteCount else {
                throw ESICharacterSyncError.responseTooLarge
            }
            try data.write(to: fileURL, options: .atomic)
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: fileURL.path
            )
        } catch let error as ESICharacterSyncError {
            throw error
        } catch {
            throw ESICharacterSyncError.cacheWriteFailed
        }
    }

    private func isValid(_ document: CacheDocument) -> Bool {
        let ids = document.snapshots.map(\.profile.characterID)
        guard Set(ids).count == ids.count else {
            return false
        }
        return document.snapshots.allSatisfy { snapshot in
            let profile = snapshot.profile
            guard (try? ESICharacterProfile(
                characterID: profile.characterID,
                name: profile.name,
                corporationID: profile.corporationID,
                allianceID: profile.allianceID,
                factionID: profile.factionID,
                birthday: profile.birthday,
                gender: profile.gender,
                raceID: profile.raceID,
                bloodlineID: profile.bloodlineID,
                securityStatus: profile.securityStatus,
                achievementScore: profile.achievementScore,
                characterTitleID: profile.characterTitleID,
                corporationTitleID: profile.corporationTitleID
            )) == profile else {
                return false
            }
            let metadata = snapshot.metadata
            guard metadata.checkedAt.timeIntervalSinceReferenceDate.isFinite,
                  metadata.expiresAt?.timeIntervalSinceReferenceDate.isFinite
                    ?? true,
                  profile.birthday.timeIntervalSinceReferenceDate.isFinite,
                  isCompatibilityDate(metadata.compatibilityDate),
                  isSafeValidator(metadata.validators.etag),
                  isSafeValidator(metadata.validators.lastModified) else {
                return false
            }
            return true
        }
    }

    private func isCompatibilityDate(_ value: String) -> Bool {
        let components = value.split(separator: "-", omittingEmptySubsequences: false)
        guard components.count == 3,
              components[0].count == 4,
              components[1].count == 2,
              components[2].count == 2,
              let year = Int(components[0]),
              let month = Int(components[1]),
              let day = Int(components[2]) else {
            return false
        }
        var dateComponents = DateComponents()
        dateComponents.calendar = Calendar(identifier: .gregorian)
        dateComponents.timeZone = TimeZone(secondsFromGMT: 0)
        dateComponents.year = year
        dateComponents.month = month
        dateComponents.day = day
        guard let date = dateComponents.date else {
            return false
        }
        let resolved = dateComponents.calendar?.dateComponents(
            [.year, .month, .day],
            from: date
        )
        return resolved?.year == year
            && resolved?.month == month
            && resolved?.day == day
    }

    private func isSafeValidator(_ value: String?) -> Bool {
        guard let value else {
            return true
        }
        return !value.isEmpty
            && value.utf8.count <= 1_024
            && value.rangeOfCharacter(
                from: .newlines
            ) == nil
    }
}

private struct CacheDocument: Codable {
    let version: Int
    var snapshots: [ESICharacterProfileSnapshot]
}
