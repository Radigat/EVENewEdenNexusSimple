import Foundation
import NewEdenNexusApplication

public actor FileESIMarketOrderPageCache:
    ESIMarketOrderPageCaching
{
    private let directoryURL: URL
    private let fileManager: FileManager
    private let maximumFileBytes: Int

    public init(
        directoryURL: URL,
        fileManager: FileManager = .default,
        maximumFileBytes: Int = 8 * 1_024 * 1_024
    ) throws {
        guard directoryURL.isFileURL, maximumFileBytes > 0 else {
            throw ESIMarketPriceError.invalidConfiguration
        }
        self.directoryURL = directoryURL.standardizedFileURL
        self.fileManager = fileManager
        self.maximumFileBytes = maximumFileBytes
    }

    public static func defaultDirectoryURL(
        fileManager: FileManager = .default
    ) throws -> URL {
        guard let root = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw ESIMarketPriceError.invalidConfiguration
        }
        return root
            .appendingPathComponent("NewEdenNexus", isDirectory: true)
            .appendingPathComponent("ESI", isDirectory: true)
            .appendingPathComponent("MarketOrders", isDirectory: true)
    }

    public func load(
        regionID: Int64,
        typeID: Int64,
        page: Int
    ) async throws -> ESIMarketOrderPageSnapshot? {
        guard regionID > 0, typeID > 0, page > 0 else {
            throw ESIMarketPriceError.invalidRequest
        }
        let url = fileURL(
            regionID: regionID,
            typeID: typeID,
            page: page
        )
        guard fileManager.fileExists(atPath: url.path) else {
            return nil
        }
        do {
            let values = try url.resourceValues(
                forKeys: [.isRegularFileKey, .fileSizeKey]
            )
            guard values.isRegularFile == true,
                  let size = values.fileSize,
                  size > 0,
                  size <= maximumFileBytes else {
                throw ESIMarketPriceError.cacheCorrupted
            }
            let data = try Data(
                contentsOf: url,
                options: [.mappedIfSafe]
            )
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let snapshot = try decoder.decode(
                ESIMarketOrderPageSnapshot.self,
                from: data
            )
            guard snapshot.regionID == regionID,
                  snapshot.typeID == typeID,
                  snapshot.page == page,
                  snapshot.pageCount >= page,
                  snapshot.orders.allSatisfy({
                      $0.typeID == typeID
                  }) else {
                throw ESIMarketPriceError.cacheCorrupted
            }
            return snapshot
        } catch let error as ESIMarketPriceError {
            throw error
        } catch {
            throw ESIMarketPriceError.cacheCorrupted
        }
    }

    public func save(
        _ snapshot: ESIMarketOrderPageSnapshot
    ) async throws {
        guard snapshot.regionID > 0,
              snapshot.typeID > 0,
              snapshot.page > 0,
              snapshot.pageCount >= snapshot.page,
              snapshot.orders.allSatisfy({
                  $0.typeID == snapshot.typeID
              }) else {
            throw ESIMarketPriceError.invalidResponse
        }
        do {
            try fileManager.createDirectory(
                at: directoryURL,
                withIntermediateDirectories: true,
                attributes: [.posixPermissions: 0o700]
            )
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            encoder.outputFormatting = [.sortedKeys]
            let data = try encoder.encode(snapshot)
            guard data.count <= maximumFileBytes else {
                throw ESIMarketPriceError.responseTooLarge
            }
            let url = fileURL(
                regionID: snapshot.regionID,
                typeID: snapshot.typeID,
                page: snapshot.page
            )
            try data.write(to: url, options: [.atomic])
            try fileManager.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
        } catch let error as ESIMarketPriceError {
            throw error
        } catch {
            throw ESIMarketPriceError.cacheWriteFailed
        }
    }

    private func fileURL(
        regionID: Int64,
        typeID: Int64,
        page: Int
    ) -> URL {
        directoryURL.appendingPathComponent(
            "region-\(regionID)-type-\(typeID)-page-\(page).json",
            isDirectory: false
        )
    }
}
