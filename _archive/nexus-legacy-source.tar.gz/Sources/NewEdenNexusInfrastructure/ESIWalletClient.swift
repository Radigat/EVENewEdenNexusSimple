import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain

public struct ESIWalletClientConfiguration: Equatable, Sendable {
    public let baseURL: URL
    public let compatibilityDate: String
    public let userAgent: SDEUserAgentConfiguration
    public let timeout: TimeInterval
    public let maximumResponseBytes: Int
    public let maximumPages: Int
    public let maximumRecords: Int
    public let retryDelay: TimeInterval

    public init(
        baseURL: URL? = nil,
        compatibilityDate: String,
        userAgent: SDEUserAgentConfiguration,
        timeout: TimeInterval = 30,
        maximumResponseBytes: Int = 5 * 1_024 * 1_024,
        maximumPages: Int = 100,
        maximumRecords: Int = 100_000,
        retryDelay: TimeInterval = 1
    ) throws {
        guard let resolved = baseURL
                ?? URL(string: "https://esi.evetech.net/"),
              resolved.scheme == "https",
              resolved.host == "esi.evetech.net",
              resolved.path == "/",
              resolved.user == nil,
              resolved.password == nil,
              resolved.query == nil,
              resolved.fragment == nil,
              compatibilityDate.count == 10,
              timeout > 0,
              maximumResponseBytes > 0,
              maximumPages > 0, maximumPages <= 100,
              maximumRecords > 0,
              retryDelay >= 0 else {
            throw ESIWalletError.invalidConfiguration
        }
        self.baseURL = resolved
        self.compatibilityDate = compatibilityDate
        self.userAgent = userAgent
        self.timeout = timeout
        self.maximumResponseBytes = maximumResponseBytes
        self.maximumPages = maximumPages
        self.maximumRecords = maximumRecords
        self.retryDelay = retryDelay
    }
}

protocol ESIWalletBackoffSleeping: Sendable {
    func sleep(seconds: TimeInterval) async throws
}

private struct ContinuousESIWalletBackoffSleeper:
    ESIWalletBackoffSleeping
{
    func sleep(seconds: TimeInterval) async throws {
        guard seconds > 0 else {
            return
        }
        try await ContinuousClock().sleep(
            for: .milliseconds(Int64((seconds * 1_000).rounded(.up)))
        )
    }
}

public actor URLSessionESIWalletClient: ESIWalletRemoteFetching {
    private struct ResponseMetadata {
        let checkedAt: Date
        let expiresAt: Date?
        let validators: ESICacheValidators
        let compatibilityDate: String
        let rateLimit: ESIRateLimitSnapshot
        let pageCount: Int?
    }

    private enum Result {
        case modified(Data, ResponseMetadata)
        case notModified(ResponseMetadata)

        var metadata: ResponseMetadata {
            switch self {
            case .modified(_, let metadata), .notModified(let metadata):
                metadata
            }
        }
    }

    private enum RequestBlock {
        case rate(Date)
        case error(Date)

        var until: Date {
            switch self {
            case .rate(let date), .error(let date):
                date
            }
        }

        var failure: ESIWalletError {
            switch self {
            case .rate(let date):
                .rateLimited(until: date)
            case .error(let date):
                .errorLimited(until: date)
            }
        }
    }

    private let configuration: ESIWalletClientConfiguration
    private let transport: any ESIHTTPTransport
    private let sleeper: any ESIWalletBackoffSleeping
    private let now: @Sendable () -> Date
    private let makeID: @Sendable () -> UUID
    private var requestBlock: RequestBlock?

    public init(configuration: ESIWalletClientConfiguration) {
        self.configuration = configuration
        transport = URLSessionESIHTTPTransport()
        sleeper = ContinuousESIWalletBackoffSleeper()
        now = Date.init
        makeID = UUID.init
    }

    init(
        configuration: ESIWalletClientConfiguration,
        transport: any ESIHTTPTransport,
        sleeper: any ESIWalletBackoffSleeping,
        now: @escaping @Sendable () -> Date,
        makeID: @escaping @Sendable () -> UUID = UUID.init
    ) {
        self.configuration = configuration
        self.transport = transport
        self.sleeper = sleeper
        self.now = now
        self.makeID = makeID
    }

    public func fetch(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> ESIWalletSnapshot {
        guard characterID > 0 else {
            throw ESIWalletError.invalidCharacterID
        }
        guard !accessToken.isEmpty,
              accessToken.utf8.count <= 16_384,
              accessToken.rangeOfCharacter(from: .newlines) == nil else {
            throw ESIWalletError.authorizationRequired
        }
        if let existing,
           existing.characterID == characterID,
           existing.balanceMetadata.isFresh(at: now()),
           existing.journalMetadata.isFresh(at: now()),
           existing.transactionMetadata.isFresh(at: now()) {
            return existing
        }
        let balance = try await fetchBalance(
            characterID: characterID,
            accessToken: accessToken,
            existing: existing
        )
        let journal = try await fetchJournal(
            characterID: characterID,
            accessToken: accessToken,
            existing: existing
        )
        let transactions = try await fetchTransactions(
            characterID: characterID,
            accessToken: accessToken,
            existing: existing
        )
        return try ESIWalletSnapshot(
            revision: makeID(),
            characterID: characterID,
            synchronizedAt: now(),
            balanceHundredths: balance.value,
            journal: journal.values,
            transactions: transactions.values,
            balanceMetadata: balance.metadata,
            journalMetadata: journal.metadata,
            transactionMetadata: transactions.metadata
        )
    }

    private func fetchBalance(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> (
        value: Int64,
        metadata: ESIWalletEndpointMetadata
    ) {
        let result = try await request(
            path: "characters/\(characterID)/wallet",
            queryItems: [],
            token: accessToken,
            validators: existing?.balanceMetadata.validatorsByPage[1],
            expectsPages: false
        )
        let value: Int64
        switch result {
        case .modified(let data, _):
            let decimal: Decimal
            do {
                decimal = try JSONDecoder.wallet.decode(
                    Decimal.self,
                    from: data
                )
            } catch {
                throw ESIWalletError.invalidResponse
            }
            value = try WalletMoneyNormalizer.hundredths(
                from: decimal,
                allowsNegative: false
            )
        case .notModified:
            guard let existing else {
                throw ESIWalletError.invalidResponse
            }
            value = existing.balanceHundredths
        }
        return (
            value,
            try metadata(
                from: [1: result.metadata],
                previous: existing?.balanceMetadata
            )
        )
    }

    private func fetchJournal(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> (
        values: [ESIWalletJournalEntry],
        metadata: ESIWalletEndpointMetadata
    ) {
        do {
            return try await fetchJournalAttempt(
                characterID: characterID,
                accessToken: accessToken,
                existing: existing
            )
        } catch ESIWalletError.inconsistentPagination {
            try Task.checkCancellation()
            try await sleeper.sleep(
                seconds: configuration.retryDelay
            )
            return try await fetchJournalAttempt(
                characterID: characterID,
                accessToken: accessToken,
                existing: existing
            )
        }
    }

    private func fetchJournalAttempt(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> (
        values: [ESIWalletJournalEntry],
        metadata: ESIWalletEndpointMetadata
    ) {
        let first = try await request(
            path: "characters/\(characterID)/wallet/journal",
            queryItems: [URLQueryItem(name: "page", value: "1")],
            token: accessToken,
            validators: existing?.journalMetadata.validatorsByPage[1],
            expectsPages: true
        )
        let count = first.metadata.pageCount
            ?? existing?.journalMetadata.pageCount
            ?? 1
        guard count <= configuration.maximumPages else {
            throw ESIWalletError.pageLimitExceeded
        }
        var values: [ESIWalletJournalEntry] = []
        var metadataByPage: [Int: ResponseMetadata] = [:]
        var expectedLastModified: String?
        for page in 1...count {
            let result = page == 1
                ? first
                : try await request(
                    path: "characters/\(characterID)/wallet/journal",
                    queryItems: [
                        URLQueryItem(name: "page", value: String(page))
                    ],
                    token: accessToken,
                    validators:
                        existing?.journalMetadata.validatorsByPage[page],
                    expectsPages: true
                )
            guard result.metadata.pageCount == nil
                    || result.metadata.pageCount == count else {
                throw ESIWalletError.inconsistentPagination(
                    .pageCountChanged
                )
            }
            let lastModified = result.metadata.validators.lastModified
                ?? existing?.journalMetadata
                    .validatorsByPage[page]?.lastModified
            guard let lastModified else {
                throw ESIWalletError.inconsistentPagination(
                    .lastModifiedMissing
                )
            }
            if let expectedLastModified,
               expectedLastModified != lastModified {
                throw ESIWalletError.inconsistentPagination(
                    .lastModifiedChanged
                )
            }
            expectedLastModified = lastModified
            metadataByPage[page] = result.metadata
            switch result {
            case .modified(let data, _):
                values += try decodeJournal(data, page: page)
            case .notModified:
                guard existing != nil else {
                    throw ESIWalletError.invalidResponse
                }
                values += existing?.journal.filter {
                    $0.sourcePage == page
                } ?? []
            }
            guard values.count <= configuration.maximumRecords else {
                throw ESIWalletError.recordLimitExceeded
            }
        }
        guard Set(values.map(\.id)).count == values.count else {
            throw ESIWalletError.inconsistentPagination(
                .duplicateJournalEntry
            )
        }
        return (
            values,
            try metadata(
                from: metadataByPage,
                previous: existing?.journalMetadata
            )
        )
    }

    private func fetchTransactions(
        characterID: Int64,
        accessToken: String,
        existing: ESIWalletSnapshot?
    ) async throws -> (
        values: [ESIWalletTransaction],
        metadata: ESIWalletEndpointMetadata
    ) {
        let first = try await request(
            path: "characters/\(characterID)/wallet/transactions",
            queryItems: [],
            token: accessToken,
            validators:
                existing?.transactionMetadata.validatorsByPage[1],
            expectsPages: false
        )
        if case .notModified = first {
            guard let existing else {
                throw ESIWalletError.invalidResponse
            }
            return (
                existing.transactions,
                try metadata(
                    from: [1: first.metadata],
                    previous: existing.transactionMetadata
                )
            )
        }

        var byID: [Int64: ESIWalletTransaction] = [:]
        var metadataByPage: [Int: ResponseMetadata] = [:]
        var page = 1
        var result = first
        var previousCursor: Int64?

        while true {
            let decoded: [ESIWalletTransaction]
            switch result {
            case .modified(let data, _):
                decoded = try decodeTransactions(data, page: page)
            case .notModified:
                throw ESIWalletError.invalidResponse
            }
            metadataByPage[page] = result.metadata
            for value in decoded {
                if let existingValue = byID[value.transactionID] {
                    guard Self.hasSameTransactionPayload(
                        existingValue,
                        value
                    ) else {
                        throw ESIWalletError.inconsistentPagination(
                            .conflictingTransaction
                        )
                    }
                    continue
                }
                byID[value.transactionID] = value
            }
            guard byID.count <= configuration.maximumRecords else {
                throw ESIWalletError.recordLimitExceeded
            }
            guard decoded.count > 1 else {
                break
            }
            guard page < configuration.maximumPages,
                  let cursor = decoded.last?.transactionID,
                  cursor != previousCursor else {
                if page >= configuration.maximumPages {
                    throw ESIWalletError.pageLimitExceeded
                }
                throw ESIWalletError.inconsistentPagination(
                    .transactionCursorStalled
                )
            }
            previousCursor = cursor
            page += 1
            result = try await request(
                path: "characters/\(characterID)/wallet/transactions",
                queryItems: [
                    URLQueryItem(
                        name: "from_id",
                        value: String(cursor)
                    )
                ],
                token: accessToken,
                validators: nil,
                expectsPages: false
            )
        }
        return (
            Array(byID.values),
            try metadata(
                from: metadataByPage,
                previous: existing?.transactionMetadata
            )
        )
    }

    private static func hasSameTransactionPayload(
        _ lhs: ESIWalletTransaction,
        _ rhs: ESIWalletTransaction
    ) -> Bool {
        lhs.transactionID == rhs.transactionID
            && lhs.journalRefID == rhs.journalRefID
            && lhs.date == rhs.date
            && lhs.locationID == rhs.locationID
            && lhs.typeID == rhs.typeID
            && lhs.unitPriceHundredths == rhs.unitPriceHundredths
            && lhs.quantity == rhs.quantity
            && lhs.clientID == rhs.clientID
            && lhs.isBuy == rhs.isBuy
            && lhs.isPersonal == rhs.isPersonal
    }

    private func decodeJournal(
        _ data: Data,
        page: Int
    ) throws -> [ESIWalletJournalEntry] {
        let payload: [JournalPayload]
        do {
            payload = try JSONDecoder.wallet.decode(
                [JournalPayload].self,
                from: data
            )
        } catch {
            throw ESIWalletError.invalidResponse
        }
        return try payload.map { try $0.value(page: page) }
    }

    private func decodeTransactions(
        _ data: Data,
        page: Int
    ) throws -> [ESIWalletTransaction] {
        let payload: [TransactionPayload]
        do {
            payload = try JSONDecoder.wallet.decode(
                [TransactionPayload].self,
                from: data
            )
        } catch {
            throw ESIWalletError.invalidResponse
        }
        return try payload.map { try $0.value(page: page) }
    }

    private func request(
        path: String,
        queryItems: [URLQueryItem],
        token: String,
        validators: ESICacheValidators?,
        expectsPages: Bool
    ) async throws -> Result {
        let requestDate = now()
        if let requestBlock, requestBlock.until > requestDate {
            throw requestBlock.failure
        }
        requestBlock = nil
        guard isSafe(validators?.etag),
              isSafe(validators?.lastModified),
              var components = URLComponents(
                url: configuration.baseURL.appendingPathComponent(path),
                resolvingAgainstBaseURL: false
              ) else {
            throw ESIWalletError.invalidConfiguration
        }
        components.queryItems = queryItems.isEmpty ? nil : queryItems
        guard let url = components.url else {
            throw ESIWalletError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = configuration.timeout
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(
            configuration.userAgent.headerValue,
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue(
            configuration.compatibilityDate,
            forHTTPHeaderField: "X-Compatibility-Date"
        )
        request.setValue(
            "Bearer \(token)",
            forHTTPHeaderField: "Authorization"
        )
        if let etag = validators?.etag {
            request.setValue(etag, forHTTPHeaderField: "If-None-Match")
        }
        if let modified = validators?.lastModified {
            request.setValue(
                modified,
                forHTTPHeaderField: "If-Modified-Since"
            )
        }

        for attempt in 0...1 {
            let response: ESIHTTPResponse
            do {
                response = try await transport.execute(request)
            } catch is CancellationError {
                throw CancellationError()
            } catch let error as URLError {
                switch error.code {
                case .cancelled:
                    throw CancellationError()
                case .notConnectedToInternet, .timedOut,
                        .networkConnectionLost, .cannotFindHost,
                        .cannotConnectToHost, .dnsLookupFailed:
                    throw ESIWalletError.offline
                default:
                    throw ESIWalletError.transport
                }
            } catch {
                throw ESIWalletError.transport
            }
            guard response.finalURL.scheme == "https",
                  response.finalURL.host == "esi.evetech.net" else {
                throw ESIWalletError.invalidResponse
            }
            guard response.data.count
                    <= configuration.maximumResponseBytes else {
                throw ESIWalletError.responseTooLarge
            }
            let metadata = try responseMetadata(
                response,
                expectsPages: expectsPages
            )
            switch response.statusCode {
            case 200:
                return .modified(response.data, metadata)
            case 304:
                guard response.data.isEmpty else {
                    throw ESIWalletError.invalidResponse
                }
                return .notModified(metadata)
            case 401:
                throw ESIWalletError.authorizationRequired
            case 403:
                throw ESIWalletError.permissionDenied
            case 420:
                guard let seconds = Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                ), seconds >= 0 else {
                    throw ESIWalletError.invalidResponse
                }
                let until = metadata.checkedAt.addingTimeInterval(
                    TimeInterval(seconds)
                )
                requestBlock = .error(until)
                throw ESIWalletError.errorLimited(until: until)
            case 429:
                guard let seconds = Int(
                    response.header("retry-after") ?? ""
                ), seconds >= 0 else {
                    throw ESIWalletError.invalidResponse
                }
                let until = metadata.checkedAt.addingTimeInterval(
                    TimeInterval(seconds)
                )
                requestBlock = .rate(until)
                throw ESIWalletError.rateLimited(until: until)
            case 500...599:
                if attempt == 0 {
                    try await sleeper.sleep(
                        seconds: configuration.retryDelay
                    )
                    continue
                }
                throw ESIWalletError.serverUnavailable
            default:
                throw ESIWalletError.invalidResponse
            }
        }
        throw ESIWalletError.serverUnavailable
    }

    private func responseMetadata(
        _ response: ESIHTTPResponse,
        expectsPages: Bool
    ) throws -> ResponseMetadata {
        let checkedAt = now()
        let pageCount: Int?
        if let raw = response.header("x-pages") {
            guard let parsed = Int(raw), parsed > 0 else {
                throw ESIWalletError.invalidResponse
            }
            pageCount = parsed
        } else {
            pageCount = nil
        }
        if expectsPages, response.statusCode == 200, pageCount == nil {
            throw ESIWalletError.invalidResponse
        }
        return ResponseMetadata(
            checkedAt: checkedAt,
            expiresAt: cacheExpiry(response, relativeTo: checkedAt),
            validators: ESICacheValidators(
                etag: response.header("etag"),
                lastModified: response.header("last-modified")
            ),
            compatibilityDate:
                response.header("x-compatibility-date")
                ?? configuration.compatibilityDate,
            rateLimit: ESIRateLimitSnapshot(
                group: response.header("x-ratelimit-group"),
                limit: response.header("x-ratelimit-limit"),
                remaining: Int(
                    response.header("x-ratelimit-remaining") ?? ""
                ),
                used: Int(response.header("x-ratelimit-used") ?? ""),
                errorLimitRemaining: Int(
                    response.header("x-esi-error-limit-remain") ?? ""
                ),
                errorLimitResetSeconds: Int(
                    response.header("x-esi-error-limit-reset") ?? ""
                )
            ),
            pageCount: pageCount
        )
    }

    private func metadata(
        from pages: [Int: ResponseMetadata],
        previous: ESIWalletEndpointMetadata?
    ) throws -> ESIWalletEndpointMetadata {
        guard let last = pages.keys.sorted().last.flatMap({
            pages[$0]
        }) else {
            throw ESIWalletError.invalidResponse
        }
        var validators: [Int: ESICacheValidators] = [:]
        for (page, metadata) in pages {
            validators[page] = ESICacheValidators(
                etag: metadata.validators.etag
                    ?? previous?.validatorsByPage[page]?.etag,
                lastModified: metadata.validators.lastModified
                    ?? previous?.validatorsByPage[page]?.lastModified
            )
        }
        let expiries = pages.values.compactMap(\.expiresAt)
        return try ESIWalletEndpointMetadata(
            checkedAt: last.checkedAt,
            expiresAt: expiries.min() ?? previous?.expiresAt,
            compatibilityDate: last.compatibilityDate,
            pageCount: pages.count,
            validatorsByPage: validators,
            rateLimit: last.rateLimit
        )
    }

    private func cacheExpiry(
        _ response: ESIHTTPResponse,
        relativeTo date: Date
    ) -> Date? {
        if let value = response.header("cache-control")?
            .split(separator: ",")
            .map({ $0.trimmingCharacters(in: .whitespaces) })
            .first(where: { $0.hasPrefix("max-age=") }),
           let seconds = TimeInterval(value.dropFirst("max-age=".count)) {
            return date.addingTimeInterval(seconds)
        }
        guard let raw = response.header("expires") else {
            return nil
        }
        for format in [
            "EEE',' dd MMM yyyy HH':'mm':'ss z",
            "EEEE',' dd-MMM-yy HH':'mm':'ss z",
            "EEE MMM d HH':'mm':'ss yyyy"
        ] {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.timeZone = TimeZone(secondsFromGMT: 0)
            formatter.dateFormat = format
            if let parsed = formatter.date(from: raw) {
                return parsed
            }
        }
        return nil
    }

    private func isSafe(_ value: String?) -> Bool {
        guard let value else {
            return true
        }
        return value.utf8.count <= 1_024
            && value.rangeOfCharacter(from: .newlines) == nil
    }
}

private struct JournalPayload: Decodable {
    let id: Int64
    let date: Date
    let refType: String
    let amount: Decimal?
    let balance: Decimal?
    let contextID: Int64?
    let contextIDType: String?

    enum CodingKeys: String, CodingKey {
        case id, date, amount, balance
        case refType = "ref_type"
        case contextID = "context_id"
        case contextIDType = "context_id_type"
    }

    func value(page: Int) throws -> ESIWalletJournalEntry {
        try ESIWalletJournalEntry(
            id: id,
            date: date,
            refType: refType,
            amountHundredths: try amount.map {
                try WalletMoneyNormalizer.hundredths(
                    from: $0,
                    allowsNegative: true
                )
            },
            balanceHundredths: try balance.map {
                try WalletMoneyNormalizer.hundredths(
                    from: $0,
                    allowsNegative: true
                )
            },
            contextID: contextID,
            contextIDType: contextIDType,
            sourcePage: page
        )
    }
}

private struct TransactionPayload: Decodable {
    let transactionID: Int64
    let journalRefID: Int64
    let date: Date
    let locationID: Int64
    let typeID: Int64
    let unitPrice: Decimal
    let quantity: Int64
    let clientID: Int64
    let isBuy: Bool
    let isPersonal: Bool

    enum CodingKeys: String, CodingKey {
        case date, quantity
        case transactionID = "transaction_id"
        case journalRefID = "journal_ref_id"
        case locationID = "location_id"
        case typeID = "type_id"
        case unitPrice = "unit_price"
        case clientID = "client_id"
        case isBuy = "is_buy"
        case isPersonal = "is_personal"
    }

    func value(page: Int) throws -> ESIWalletTransaction {
        try ESIWalletTransaction(
            transactionID: transactionID,
            journalRefID: journalRefID,
            date: date,
            locationID: locationID,
            typeID: typeID,
            unitPriceHundredths:
                try WalletMoneyNormalizer.hundredths(
                    from: unitPrice,
                    allowsNegative: false
                ),
            quantity: quantity,
            clientID: clientID,
            isBuy: isBuy,
            isPersonal: isPersonal,
            sourcePage: page
        )
    }
}

private extension JSONDecoder {
    static var wallet: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
