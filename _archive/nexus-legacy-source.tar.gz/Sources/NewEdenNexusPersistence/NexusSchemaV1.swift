import Foundation
import NewEdenNexusDomain
import SwiftData

public enum SyncState: String, Codable, CaseIterable, Sendable {
    case never = "Noch nicht synchronisiert"
    case syncing = "Synchronisierung läuft"
    case current = "Aktuell"
    case stale = "Veraltet"
    case failed = "Fehler"
}

public enum NexusSchemaV1: VersionedSchema {
    public static let versionIdentifier = Schema.Version(1, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [CharacterRecord.self, ProductionProject.self]
    }

    @Model
    public final class CharacterRecord {
        @Attribute(.unique) public var characterID: Int64
        public var name: String
        public var accountLabel: String
        public var syncStateRaw: String
        public var lastSync: Date?
        public var industrySlots: Int
        public var scienceSlots: Int
        public var activeJobs: Int
        public var createdAt: Date
        public var recordVersion: Int = 1

        public init(
            characterID: Int64,
            name: String,
            accountLabel: String = "EVE Online",
            syncState: SyncState = .never
        ) {
            self.characterID = characterID
            self.name = name
            self.accountLabel = accountLabel
            self.syncStateRaw = syncState.rawValue
            self.industrySlots = 0
            self.scienceSlots = 0
            self.activeJobs = 0
            self.createdAt = .now
            self.recordVersion = 1
        }

        public var syncState: SyncState {
            get { SyncState(rawValue: syncStateRaw) ?? .never }
            set { syncStateRaw = newValue.rawValue }
        }
    }

    @Model
    public final class ProductionProject {
        @Attribute(.unique) public var id: UUID
        public var name: String
        public var productName: String
        public var targetQuantity: Int
        public var statusRaw: String
        public var priority: Int
        public var targetDate: Date?
        public var notes: String
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int = 1

        public init(
            id: UUID = UUID(),
            name: String,
            productName: String,
            targetQuantity: Int,
            status: ProjectStatus = .planning,
            priority: Int = 2,
            targetDate: Date? = nil,
            notes: String = "",
            createdAt: Date = .now,
            updatedAt: Date = .now
        ) {
            self.id = id
            self.name = name
            self.productName = productName
            self.targetQuantity = max(1, targetQuantity)
            self.statusRaw = status.rawValue
            self.priority = priority
            self.targetDate = targetDate
            self.notes = notes
            self.createdAt = createdAt
            self.updatedAt = max(createdAt, updatedAt)
            self.recordVersion = 1
        }

        public var status: ProjectStatus {
            get { ProjectStatus(rawValue: statusRaw) ?? .planning }
            set {
                statusRaw = newValue.rawValue
                updatedAt = .now
            }
        }
    }
}
