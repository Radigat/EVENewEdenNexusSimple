import Foundation
import SwiftData

public enum NexusSchemaV13: VersionedSchema {
    public static let versionIdentifier = Schema.Version(13, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            NexusSchemaV12.InventoryAvailabilityConfigurationRecord.self,
            StockPolicyRecord.self
        ]
    }

    @Model
    public final class StockPolicyRecord {
        @Attribute(.unique) public var id: UUID
        @Attribute(.unique) public var typeID: Int64
        public var safetyStockQuantity: Int64
        public var minimumQuantity: Int64?
        public var warningQuantity: Int64?
        public var targetQuantity: Int64?
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            typeID: Int64,
            safetyStockQuantity: Int64,
            minimumQuantity: Int64?,
            warningQuantity: Int64?,
            targetQuantity: Int64?,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.typeID = typeID
            self.safetyStockQuantity = safetyStockQuantity
            self.minimumQuantity = minimumQuantity
            self.warningQuantity = warningQuantity
            self.targetQuantity = targetQuantity
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias StockPolicyRecord = NexusSchemaV13.StockPolicyRecord
