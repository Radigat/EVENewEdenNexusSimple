import Foundation
import SwiftData

public enum NexusSchemaV25: VersionedSchema {
    public static let versionIdentifier = Schema.Version(25, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV24.models + [ProjectBudgetConfigurationRecord.self]
    }

    @Model
    public final class ProjectBudgetConfigurationRecord {
        @Attribute(.unique) public var id: UUID
        @Attribute(.unique) public var projectID: UUID
        public var priceProfileID: UUID
        public var logisticsCostHundredths: Int64
        public var productionCostHundredths: Int64
        public var createdAt: Date
        public var updatedAt: Date

        public init(
            id: UUID,
            projectID: UUID,
            priceProfileID: UUID,
            logisticsCostHundredths: Int64,
            productionCostHundredths: Int64,
            createdAt: Date,
            updatedAt: Date
        ) {
            self.id = id
            self.projectID = projectID
            self.priceProfileID = priceProfileID
            self.logisticsCostHundredths = logisticsCostHundredths
            self.productionCostHundredths = productionCostHundredths
            self.createdAt = createdAt
            self.updatedAt = updatedAt
        }
    }
}

public typealias ProjectBudgetConfigurationRecord =
    NexusSchemaV25.ProjectBudgetConfigurationRecord
