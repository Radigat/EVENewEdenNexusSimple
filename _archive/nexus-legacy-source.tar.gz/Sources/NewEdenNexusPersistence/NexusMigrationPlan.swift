import NewEdenNexusApplication
import SwiftData

public enum NexusMigrationPlan: SchemaMigrationPlan {
    public static var schemas: [any VersionedSchema.Type] {
        [
            NexusLegacySchema.self,
            NexusSchemaV1.self,
            NexusSchemaV2.self,
            NexusSchemaV3.self,
            NexusSchemaV4.self,
            NexusSchemaV5.self,
            NexusSchemaV6.self,
            NexusSchemaV7.self,
            NexusSchemaV8.self,
            NexusSchemaV9.self,
            NexusSchemaV10.self,
            NexusSchemaV11.self,
            NexusSchemaV12.self,
            NexusSchemaV13.self,
            NexusSchemaV14.self,
            NexusSchemaV15.self,
            NexusSchemaV16.self,
            NexusSchemaV17.self,
            NexusSchemaV18.self,
            NexusSchemaV19.self,
            NexusSchemaV20.self,
            NexusSchemaV21.self,
            NexusSchemaV22.self,
            NexusSchemaV23.self,
            NexusSchemaV24.self,
            NexusSchemaV25.self,
            NexusSchemaV26.self,
            NexusSchemaV27.self,
            NexusSchemaV28.self
        ]
    }

    public static var stages: [MigrationStage] {
        [
            .lightweight(
                fromVersion: NexusLegacySchema.self,
                toVersion: NexusSchemaV1.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV1.self,
                toVersion: NexusSchemaV2.self
            ),
            .custom(
                fromVersion: NexusSchemaV2.self,
                toVersion: NexusSchemaV3.self,
                willMigrate: nil,
                didMigrate: { context in
                    let items = try context.fetch(
                        FetchDescriptor<NexusSchemaV3.ItemType>()
                    )
                    for item in items {
                        item.searchName = CatalogSearchText.normalize(item.name)
                    }
                    try context.save()
                }
            ),
            .lightweight(
                fromVersion: NexusSchemaV3.self,
                toVersion: NexusSchemaV4.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV4.self,
                toVersion: NexusSchemaV5.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV5.self,
                toVersion: NexusSchemaV6.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV6.self,
                toVersion: NexusSchemaV7.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV7.self,
                toVersion: NexusSchemaV8.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV8.self,
                toVersion: NexusSchemaV9.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV9.self,
                toVersion: NexusSchemaV10.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV10.self,
                toVersion: NexusSchemaV11.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV11.self,
                toVersion: NexusSchemaV12.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV12.self,
                toVersion: NexusSchemaV13.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV13.self,
                toVersion: NexusSchemaV14.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV14.self,
                toVersion: NexusSchemaV15.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV15.self,
                toVersion: NexusSchemaV16.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV16.self,
                toVersion: NexusSchemaV17.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV17.self,
                toVersion: NexusSchemaV18.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV18.self,
                toVersion: NexusSchemaV19.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV19.self,
                toVersion: NexusSchemaV20.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV20.self,
                toVersion: NexusSchemaV21.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV21.self,
                toVersion: NexusSchemaV22.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV22.self,
                toVersion: NexusSchemaV23.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV23.self,
                toVersion: NexusSchemaV24.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV24.self,
                toVersion: NexusSchemaV25.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV25.self,
                toVersion: NexusSchemaV26.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV26.self,
                toVersion: NexusSchemaV27.self
            ),
            .lightweight(
                fromVersion: NexusSchemaV27.self,
                toVersion: NexusSchemaV28.self
            )
        ]
    }
}
