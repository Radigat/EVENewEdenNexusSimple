import Foundation
import SQLite3
import SwiftData

public enum NexusModelContainerFactory {
    enum LegacyStoreClassification: Equatable {
        case newEdenNexus
        case foreign
        case unreadable
    }

    static let storeDirectoryName = "NewEdenNexus"
    static let storeFileName = "NewEdenNexus.store"

    public static var currentSchema: Schema {
        Schema(versionedSchema: NexusSchemaV28.self)
    }

    public static var defaultStoreURL: URL {
        resolvedDefaultStoreURL(
            applicationSupportDirectory: applicationSupportDirectory,
            fileManager: .default,
            classifyLegacyStore: classifyLegacyStore
        )
    }

    public static func makeDefault() throws -> ModelContainer {
        try make(at: defaultStoreURL)
    }

    public static func makeInMemory() throws -> ModelContainer {
        let schema = currentSchema
        let configuration = ModelConfiguration(
            schema: schema,
            isStoredInMemoryOnly: true
        )
        return try ModelContainer(
            for: schema,
            migrationPlan: NexusMigrationPlan.self,
            configurations: [configuration]
        )
    }

    public static func make(at storeURL: URL) throws -> ModelContainer {
        try FileManager.default.createDirectory(
            at: storeURL.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        let schema = currentSchema
        let configuration = ModelConfiguration(
            "NewEdenNexus",
            schema: schema,
            url: storeURL,
            allowsSave: true,
            cloudKitDatabase: .none
        )
        return try ModelContainer(
            for: schema,
            migrationPlan: NexusMigrationPlan.self,
            configurations: [configuration]
        )
    }

    static func resolvedDefaultStoreURL(
        applicationSupportDirectory: URL,
        fileManager: FileManager,
        classifyLegacyStore: (URL) -> LegacyStoreClassification
    ) -> URL {
        let dedicatedURL = applicationSupportDirectory
            .appendingPathComponent(storeDirectoryName, isDirectory: true)
            .appendingPathComponent(storeFileName, isDirectory: false)

        guard !fileManager.fileExists(atPath: dedicatedURL.path) else {
            return dedicatedURL
        }

        let legacyURL = applicationSupportDirectory
            .appendingPathComponent("default.store", isDirectory: false)
        guard fileManager.fileExists(atPath: legacyURL.path) else {
            return dedicatedURL
        }

        switch classifyLegacyStore(legacyURL) {
        case .newEdenNexus, .unreadable:
            return legacyURL
        case .foreign:
            return dedicatedURL
        }
    }

    private static var applicationSupportDirectory: URL {
        FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first ?? FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support")
    }

    static func classifyLegacyStore(
        _ storeURL: URL
    ) -> LegacyStoreClassification {
        var database: OpaquePointer?
        let openResult = sqlite3_open_v2(
            storeURL.path,
            &database,
            SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX,
            nil
        )
        guard openResult == SQLITE_OK, let database else {
            if let database {
                sqlite3_close(database)
            }
            return .unreadable
        }
        defer {
            sqlite3_close(database)
        }

        let query = """
        SELECT COUNT(*)
        FROM sqlite_master
        WHERE type = 'table'
          AND name IN ('ZCHARACTERRECORD', 'ZPRODUCTIONPROJECT')
        """
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(
            database,
            query,
            -1,
            &statement,
            nil
        ) == SQLITE_OK,
        let statement else {
            if let statement {
                sqlite3_finalize(statement)
            }
            return .unreadable
        }
        defer {
            sqlite3_finalize(statement)
        }

        guard sqlite3_step(statement) == SQLITE_ROW else {
            return .unreadable
        }
        return sqlite3_column_int(statement, 0) == 2
            ? .newEdenNexus
            : .foreign
    }
}
