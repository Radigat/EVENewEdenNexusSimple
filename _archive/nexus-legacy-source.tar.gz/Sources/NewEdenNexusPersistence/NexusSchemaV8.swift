import Foundation
import NewEdenNexusDomain
import SwiftData

public enum NexusSchemaV8: VersionedSchema {
    public static let versionIdentifier = Schema.Version(8, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            ProductionGraphRecord.self
        ]
    }

    @Model
    public final class ProductionProject {
        @Attribute(.unique) public var id: UUID
        public var name: String
        public var productName: String
        public var targetQuantity: Int
        public var statusRaw: String
        public var priority: Int
        public var targetDate: Date?
        public var notes: String
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int = 1
        public var productTypeID: Int64?
        public var productActivityRaw: String?
        public var productBlueprintTypeID: Int64?
        public var productCatalogBuildNumber: Int?
        public var productCatalogContentSHA256: String?
        public var materialEfficiency: Int?

        public init(
            id: UUID = UUID(),
            name: String,
            productName: String,
            targetQuantity: Int,
            status: ProjectStatus = .planning,
            priority: Int = 2,
            targetDate: Date? = nil,
            notes: String = "",
            createdAt: Date = .now,
            updatedAt: Date = .now,
            productTypeID: Int64? = nil,
            productActivityRaw: String? = nil,
            productBlueprintTypeID: Int64? = nil,
            productCatalogBuildNumber: Int? = nil,
            productCatalogContentSHA256: String? = nil,
            materialEfficiency: Int? = nil
        ) {
            self.id = id
            self.name = name
            self.productName = productName
            self.targetQuantity = max(1, targetQuantity)
            self.statusRaw = status.rawValue
            self.priority = priority
            self.targetDate = targetDate
            self.notes = notes
            self.createdAt = createdAt
            self.updatedAt = max(createdAt, updatedAt)
            self.recordVersion = 1
            self.productTypeID = productTypeID
            self.productActivityRaw = productActivityRaw
            self.productBlueprintTypeID = productBlueprintTypeID
            self.productCatalogBuildNumber = productCatalogBuildNumber
            self.productCatalogContentSHA256 =
                productCatalogContentSHA256
            self.materialEfficiency = materialEfficiency
        }

        public var status: ProjectStatus {
            get { ProjectStatus(rawValue: statusRaw) ?? .planning }
            set {
                statusRaw = newValue.rawValue
                updatedAt = .now
            }
        }
    }

    @Model
    public final class ProductionGraphRecord {
        @Attribute(.unique) public var projectID: UUID
        public var graphID: UUID
        public var formatVersion: Int
        public var catalogBuildNumber: Int
        public var catalogContentSHA256: String
        public var createdAt: Date
        public var updatedAt: Date
        public var payload: Data
        public var calculationFormulaVersion: Int?
        public var materialFormulaVersion: Int?

        public init(
            projectID: UUID,
            graphID: UUID,
            formatVersion: Int,
            catalogBuildNumber: Int,
            catalogContentSHA256: String,
            createdAt: Date,
            updatedAt: Date,
            payload: Data,
            calculationFormulaVersion: Int?,
            materialFormulaVersion: Int?
        ) {
            self.projectID = projectID
            self.graphID = graphID
            self.formatVersion = formatVersion
            self.catalogBuildNumber = catalogBuildNumber
            self.catalogContentSHA256 = catalogContentSHA256
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.payload = payload
            self.calculationFormulaVersion = calculationFormulaVersion
            self.materialFormulaVersion = materialFormulaVersion
        }
    }
}
