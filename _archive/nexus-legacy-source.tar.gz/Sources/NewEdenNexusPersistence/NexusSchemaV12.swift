import Foundation
import SwiftData

public enum NexusSchemaV12: VersionedSchema {
    public static let versionIdentifier = Schema.Version(12, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            InventoryAvailabilityConfigurationRecord.self
        ]
    }

    @Model
    public final class InventoryAvailabilityConfigurationRecord {
        @Attribute(.unique) public var id: UUID
        @Attribute(.unique) public var projectID: UUID
        public var modeRaw: String
        public var includedLocationIDsPayload: Data
        public var excludedTypeIDsPayload: Data
        public var capsPayload: Data
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            projectID: UUID,
            modeRaw: String,
            includedLocationIDsPayload: Data,
            excludedTypeIDsPayload: Data,
            capsPayload: Data,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.projectID = projectID
            self.modeRaw = modeRaw
            self.includedLocationIDsPayload = includedLocationIDsPayload
            self.excludedTypeIDsPayload = excludedTypeIDsPayload
            self.capsPayload = capsPayload
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias InventoryAvailabilityConfigurationRecord =
    NexusSchemaV12.InventoryAvailabilityConfigurationRecord
