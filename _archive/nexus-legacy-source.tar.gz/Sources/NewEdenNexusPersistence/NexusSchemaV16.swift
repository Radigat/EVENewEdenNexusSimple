import Foundation
import SwiftData

public enum NexusSchemaV16: VersionedSchema {
    public static let versionIdentifier = Schema.Version(16, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            NexusSchemaV12.InventoryAvailabilityConfigurationRecord.self,
            NexusSchemaV13.StockPolicyRecord.self,
            NexusSchemaV14.StockReservationRecord.self,
            NexusSchemaV15.BuildOrBuyDecisionRecord.self,
            PriceProfileRecord.self,
            ManualPriceRecord.self
        ]
    }

    @Model
    public final class PriceProfileRecord {
        @Attribute(.unique) public var id: UUID
        public var name: String
        public var normalizedName: String
        public var currencyRaw: String
        public var isActive: Bool
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            name: String,
            normalizedName: String,
            currencyRaw: String,
            isActive: Bool,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.name = name
            self.normalizedName = normalizedName
            self.currencyRaw = currencyRaw
            self.isActive = isActive
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }

    @Model
    public final class ManualPriceRecord {
        @Attribute(.unique) public var id: UUID
        public var profileID: UUID
        public var typeID: Int64
        public var itemName: String
        public var amountHundredths: Int64
        public var sourceRaw: String
        public var validFrom: Date
        public var validUntil: Date?
        public var catalogBuildNumber: Int
        public var catalogContentSHA256: String
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            profileID: UUID,
            typeID: Int64,
            itemName: String,
            amountHundredths: Int64,
            sourceRaw: String,
            validFrom: Date,
            validUntil: Date?,
            catalogBuildNumber: Int,
            catalogContentSHA256: String,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.profileID = profileID
            self.typeID = typeID
            self.itemName = itemName
            self.amountHundredths = amountHundredths
            self.sourceRaw = sourceRaw
            self.validFrom = validFrom
            self.validUntil = validUntil
            self.catalogBuildNumber = catalogBuildNumber
            self.catalogContentSHA256 = catalogContentSHA256
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias PriceProfileRecord = NexusSchemaV16.PriceProfileRecord
public typealias ManualPriceRecord = NexusSchemaV16.ManualPriceRecord
