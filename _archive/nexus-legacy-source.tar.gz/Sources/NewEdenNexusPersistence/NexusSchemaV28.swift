import Foundation
import SwiftData

public enum NexusSchemaV28: VersionedSchema {
    public static let versionIdentifier = Schema.Version(28, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV27.models + [
            ProductionBatchSaleAllocationRecord.self
        ]
    }

    @Model
    public final class ProductionBatchSaleAllocationRecord {
        @Attribute(.unique) public var id: UUID
        public var batchID: UUID
        public var projectID: UUID
        public var costSnapshotID: UUID
        public var projectAssignmentID: UUID?
        public var characterID: Int64?
        public var sourceID: Int64?
        public var kindRaw: String
        public var sourceRaw: String
        public var quantity: Int64
        public var amountHundredths: Int64
        public var sourceObservedAt: Date
        public var createdAt: Date
        public var contractVersion: Int
        public var payload: Data

        public init(
            id: UUID,
            batchID: UUID,
            projectID: UUID,
            costSnapshotID: UUID,
            projectAssignmentID: UUID?,
            characterID: Int64?,
            sourceID: Int64?,
            kindRaw: String,
            sourceRaw: String,
            quantity: Int64,
            amountHundredths: Int64,
            sourceObservedAt: Date,
            createdAt: Date,
            contractVersion: Int,
            payload: Data
        ) {
            self.id = id
            self.batchID = batchID
            self.projectID = projectID
            self.costSnapshotID = costSnapshotID
            self.projectAssignmentID = projectAssignmentID
            self.characterID = characterID
            self.sourceID = sourceID
            self.kindRaw = kindRaw
            self.sourceRaw = sourceRaw
            self.quantity = quantity
            self.amountHundredths = amountHundredths
            self.sourceObservedAt = sourceObservedAt
            self.createdAt = createdAt
            self.contractVersion = contractVersion
            self.payload = payload
        }
    }
}

public typealias ProductionBatchSaleAllocationRecord =
    NexusSchemaV28.ProductionBatchSaleAllocationRecord
