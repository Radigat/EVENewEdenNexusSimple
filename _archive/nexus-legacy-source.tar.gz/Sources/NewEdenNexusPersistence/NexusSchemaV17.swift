import Foundation
import SwiftData

public enum NexusSchemaV17: VersionedSchema {
    public static let versionIdentifier = Schema.Version(17, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            NexusSchemaV12.InventoryAvailabilityConfigurationRecord.self,
            NexusSchemaV13.StockPolicyRecord.self,
            NexusSchemaV14.StockReservationRecord.self,
            NexusSchemaV15.BuildOrBuyDecisionRecord.self,
            NexusSchemaV16.PriceProfileRecord.self,
            NexusSchemaV16.ManualPriceRecord.self,
            PriceImportRecord.self
        ]
    }

    @Model
    public final class PriceImportRecord {
        @Attribute(.unique) public var id: UUID
        public var profileID: UUID
        public var importedAt: Date
        public var sourceName: String
        public var sourceSHA256: String
        public var payload: Data
        public var payloadVersion: Int

        public init(
            id: UUID,
            profileID: UUID,
            importedAt: Date,
            sourceName: String,
            sourceSHA256: String,
            payload: Data,
            payloadVersion: Int
        ) {
            self.id = id
            self.profileID = profileID
            self.importedAt = importedAt
            self.sourceName = sourceName
            self.sourceSHA256 = sourceSHA256
            self.payload = payload
            self.payloadVersion = payloadVersion
        }
    }
}

public typealias PriceImportRecord = NexusSchemaV17.PriceImportRecord
