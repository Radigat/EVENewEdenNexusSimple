import Foundation
import SwiftData

public enum NexusSchemaV26: VersionedSchema {
    public static let versionIdentifier = Schema.Version(26, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV25.models + [
            ProductionBatchRecord.self,
            ProductionBatchAnnualCounterRecord.self
        ]
    }

    @Model
    public final class ProductionBatchRecord {
        @Attribute(.unique) public var id: UUID
        @Attribute(.unique) public var displayNumber: String
        public var calendarYear: Int
        public var sequenceNumber: Int
        public var projectID: UUID
        public var projectName: String
        public var productTypeID: Int64
        public var productName: String
        public var statusRaw: String
        public var productionDate: Date
        public var characterID: Int64?
        public var characterName: String?
        public var solarSystemID: Int64?
        public var solarSystemName: String?
        public var locationID: Int64?
        public var locationName: String?
        public var createdAt: Date
        public var updatedAt: Date
        public var payload: Data

        public init(
            id: UUID,
            displayNumber: String,
            calendarYear: Int,
            sequenceNumber: Int,
            projectID: UUID,
            projectName: String,
            productTypeID: Int64,
            productName: String,
            statusRaw: String,
            productionDate: Date,
            characterID: Int64?,
            characterName: String?,
            solarSystemID: Int64?,
            solarSystemName: String?,
            locationID: Int64?,
            locationName: String?,
            createdAt: Date,
            updatedAt: Date,
            payload: Data
        ) {
            self.id = id
            self.displayNumber = displayNumber
            self.calendarYear = calendarYear
            self.sequenceNumber = sequenceNumber
            self.projectID = projectID
            self.projectName = projectName
            self.productTypeID = productTypeID
            self.productName = productName
            self.statusRaw = statusRaw
            self.productionDate = productionDate
            self.characterID = characterID
            self.characterName = characterName
            self.solarSystemID = solarSystemID
            self.solarSystemName = solarSystemName
            self.locationID = locationID
            self.locationName = locationName
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.payload = payload
        }
    }

    @Model
    public final class ProductionBatchAnnualCounterRecord {
        @Attribute(.unique) public var calendarYear: Int
        public var nextSequenceNumber: Int
        public var updatedAt: Date

        public init(
            calendarYear: Int,
            nextSequenceNumber: Int,
            updatedAt: Date
        ) {
            self.calendarYear = calendarYear
            self.nextSequenceNumber = nextSequenceNumber
            self.updatedAt = updatedAt
        }
    }
}

public typealias ProductionBatchRecord =
    NexusSchemaV26.ProductionBatchRecord
public typealias ProductionBatchAnnualCounterRecord =
    NexusSchemaV26.ProductionBatchAnnualCounterRecord
