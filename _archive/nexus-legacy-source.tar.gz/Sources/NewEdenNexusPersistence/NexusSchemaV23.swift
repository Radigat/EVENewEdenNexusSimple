import Foundation
import SwiftData

public enum NexusSchemaV23: VersionedSchema {
    public static let versionIdentifier = Schema.Version(23, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV22.models + [ESIAssetAvailabilitySelectionRecord.self]
    }

    @Model
    public final class ESIAssetAvailabilitySelectionRecord {
        @Attribute(.unique) public var id: UUID
        public var projectID: UUID
        public var characterID: Int64
        public var sourceRevision: UUID
        public var linesJSON: Data
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            projectID: UUID,
            characterID: Int64,
            sourceRevision: UUID,
            linesJSON: Data,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.projectID = projectID
            self.characterID = characterID
            self.sourceRevision = sourceRevision
            self.linesJSON = linesJSON
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias ESIAssetAvailabilitySelectionRecord =
    NexusSchemaV23.ESIAssetAvailabilitySelectionRecord
