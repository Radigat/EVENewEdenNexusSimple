import Foundation
import SwiftData

public enum NexusSchemaV4: VersionedSchema {
    public static let versionIdentifier = Schema.Version(4, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV3.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            SDEUpdateCheckRecord.self
        ]
    }

    @Model
    public final class SDEUpdateCheckRecord {
        @Attribute(.unique) public var id: String
        public var lastAttemptAt: Date?
        public var lastSuccessfulCheckAt: Date?
        public var lastKnownOfficialBuildNumber: Int?
        public var officialReleaseDate: Date?
        public var latestETag: String?
        public var latestLastModified: String?
        public var latestFreshUntil: Date?
        public var schemaETag: String?
        public var schemaLastModified: String?
        public var schemaFreshUntil: Date?
        public var schemaHighestAfterBuildNumber: Int?
        public var schemaEntryCount: Int?
        public var schemaParserVersion: Int
        public var lastStatusRaw: String?
        public var lastSafeFailureCode: String?
        public var recordVersion: Int

        public init(id: String = "primary") {
            self.id = id
            self.schemaParserVersion = 1
            self.recordVersion = 1
        }
    }
}

public typealias SDEUpdateCheckRecord =
    NexusSchemaV4.SDEUpdateCheckRecord
