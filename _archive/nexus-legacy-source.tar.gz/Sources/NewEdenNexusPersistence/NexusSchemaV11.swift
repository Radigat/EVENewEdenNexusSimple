import Foundation
import SwiftData

public enum NexusSchemaV11: VersionedSchema {
    public static let versionIdentifier = Schema.Version(11, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            InventoryImportRecord.self
        ]
    }

    @Model
    public final class InventoryImportRecord {
        @Attribute(.unique) public var id: UUID
        public var importedAt: Date
        public var locationID: UUID
        public var locationName: String
        public var sourceName: String
        public var sourceSHA256: String
        public var encodingRaw: String
        public var delimiterRaw: String
        public var totalRows: Int
        public var insertedCount: Int
        public var replacedCount: Int
        public var skippedCount: Int
        public var unchangedCount: Int
        public var invalidCount: Int
        public var payload: Data
        public var recordVersion: Int

        public init(
            id: UUID,
            importedAt: Date,
            locationID: UUID,
            locationName: String,
            sourceName: String,
            sourceSHA256: String,
            encodingRaw: String,
            delimiterRaw: String,
            totalRows: Int,
            insertedCount: Int,
            replacedCount: Int,
            skippedCount: Int,
            unchangedCount: Int,
            invalidCount: Int,
            payload: Data,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.importedAt = importedAt
            self.locationID = locationID
            self.locationName = locationName
            self.sourceName = sourceName
            self.sourceSHA256 = sourceSHA256
            self.encodingRaw = encodingRaw
            self.delimiterRaw = delimiterRaw
            self.totalRows = totalRows
            self.insertedCount = insertedCount
            self.replacedCount = replacedCount
            self.skippedCount = skippedCount
            self.unchangedCount = unchangedCount
            self.invalidCount = invalidCount
            self.payload = payload
            self.recordVersion = recordVersion
        }
    }
}

public typealias InventoryImportRecord =
    NexusSchemaV11.InventoryImportRecord

