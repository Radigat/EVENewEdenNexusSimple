import Foundation
import SwiftData

public enum NexusSchemaV15: VersionedSchema {
    public static let versionIdentifier = Schema.Version(15, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            NexusSchemaV12.InventoryAvailabilityConfigurationRecord.self,
            NexusSchemaV13.StockPolicyRecord.self,
            NexusSchemaV14.StockReservationRecord.self,
            BuildOrBuyDecisionRecord.self
        ]
    }

    @Model
    public final class BuildOrBuyDecisionRecord {
        @Attribute(.unique) public var id: UUID
        public var projectID: UUID
        public var typeID: Int64
        public var choiceRaw: String
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            projectID: UUID,
            typeID: Int64,
            choiceRaw: String,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.projectID = projectID
            self.typeID = typeID
            self.choiceRaw = choiceRaw
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias BuildOrBuyDecisionRecord =
    NexusSchemaV15.BuildOrBuyDecisionRecord
