import Foundation
import SwiftData

public enum NexusSchemaV10: VersionedSchema {
    public static let versionIdentifier = Schema.Version(10, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            StorageLocationRecord.self,
            ManualStockRecord.self
        ]
    }

    @Model
    public final class StorageLocationRecord {
        @Attribute(.unique) public var id: UUID
        @Attribute(.unique) public var normalizedName: String
        public var name: String
        public var kindRaw: String
        public var notes: String
        public var isArchived: Bool
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            normalizedName: String,
            name: String,
            kindRaw: String,
            notes: String,
            isArchived: Bool,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.normalizedName = normalizedName
            self.name = name
            self.kindRaw = kindRaw
            self.notes = notes
            self.isArchived = isArchived
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }

    @Model
    public final class ManualStockRecord {
        @Attribute(.unique) public var id: UUID
        @Attribute(.unique) public var identityKey: String
        public var locationID: UUID
        public var typeID: Int64
        public var itemName: String
        public var quantity: Int64
        public var catalogBuildNumber: Int
        public var catalogContentSHA256: String
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            identityKey: String,
            locationID: UUID,
            typeID: Int64,
            itemName: String,
            quantity: Int64,
            catalogBuildNumber: Int,
            catalogContentSHA256: String,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.identityKey = identityKey
            self.locationID = locationID
            self.typeID = typeID
            self.itemName = itemName
            self.quantity = quantity
            self.catalogBuildNumber = catalogBuildNumber
            self.catalogContentSHA256 = catalogContentSHA256
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias StorageLocationRecord =
    NexusSchemaV10.StorageLocationRecord
public typealias ManualStockRecord = NexusSchemaV10.ManualStockRecord
