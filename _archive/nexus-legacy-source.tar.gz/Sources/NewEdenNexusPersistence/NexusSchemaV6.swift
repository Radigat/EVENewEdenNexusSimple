import Foundation
import SwiftData

public enum NexusSchemaV6: VersionedSchema {
    public static let versionIdentifier = Schema.Version(6, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV5.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            ProductionGraphRecord.self
        ]
    }

    @Model
    public final class ProductionGraphRecord {
        @Attribute(.unique) public var projectID: UUID
        public var graphID: UUID
        public var formatVersion: Int
        public var catalogBuildNumber: Int
        public var catalogContentSHA256: String
        public var createdAt: Date
        public var updatedAt: Date
        public var payload: Data

        public init(
            projectID: UUID,
            graphID: UUID,
            formatVersion: Int,
            catalogBuildNumber: Int,
            catalogContentSHA256: String,
            createdAt: Date,
            updatedAt: Date,
            payload: Data
        ) {
            self.projectID = projectID
            self.graphID = graphID
            self.formatVersion = formatVersion
            self.catalogBuildNumber = catalogBuildNumber
            self.catalogContentSHA256 = catalogContentSHA256
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.payload = payload
        }
    }
}

public typealias ProductionGraphRecord =
    NexusSchemaV6.ProductionGraphRecord
