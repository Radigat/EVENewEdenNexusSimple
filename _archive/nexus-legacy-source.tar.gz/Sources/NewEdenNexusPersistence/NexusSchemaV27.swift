import Foundation
import SwiftData

public enum NexusSchemaV27: VersionedSchema {
    public static let versionIdentifier = Schema.Version(27, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV26.models + [
            ProductionBatchCostSnapshotRecord.self
        ]
    }

    @Model
    public final class ProductionBatchCostSnapshotRecord {
        @Attribute(.unique) public var id: UUID
        public var batchID: UUID
        public var batchUpdatedAt: Date
        public var contractVersion: Int
        public var formulaVersion: Int
        public var priceProfileID: UUID?
        public var createdAt: Date
        public var totalCostHundredths: Int64?
        public var unitCostHundredths: Int64?
        public var payload: Data

        public init(
            id: UUID,
            batchID: UUID,
            batchUpdatedAt: Date,
            contractVersion: Int,
            formulaVersion: Int,
            priceProfileID: UUID?,
            createdAt: Date,
            totalCostHundredths: Int64?,
            unitCostHundredths: Int64?,
            payload: Data
        ) {
            self.id = id
            self.batchID = batchID
            self.batchUpdatedAt = batchUpdatedAt
            self.contractVersion = contractVersion
            self.formulaVersion = formulaVersion
            self.priceProfileID = priceProfileID
            self.createdAt = createdAt
            self.totalCostHundredths = totalCostHundredths
            self.unitCostHundredths = unitCostHundredths
            self.payload = payload
        }
    }
}

public typealias ProductionBatchCostSnapshotRecord =
    NexusSchemaV27.ProductionBatchCostSnapshotRecord
