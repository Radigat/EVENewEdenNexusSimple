import Foundation
import SwiftData

public enum NexusSchemaV14: VersionedSchema {
    public static let versionIdentifier = Schema.Version(14, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            NexusSchemaV12.InventoryAvailabilityConfigurationRecord.self,
            NexusSchemaV13.StockPolicyRecord.self,
            StockReservationRecord.self
        ]
    }

    @Model
    public final class StockReservationRecord {
        @Attribute(.unique) public var id: UUID
        public var projectID: UUID
        public var typeID: Int64
        public var reservedQuantity: Int64
        public var consumedQuantity: Int64
        public var priority: Int
        public var expiresAt: Date?
        public var statusRaw: String
        public var createdAt: Date
        public var updatedAt: Date
        public var releasedAt: Date?
        public var consumedAt: Date?
        public var recordVersion: Int

        public init(
            id: UUID,
            projectID: UUID,
            typeID: Int64,
            reservedQuantity: Int64,
            consumedQuantity: Int64,
            priority: Int,
            expiresAt: Date?,
            statusRaw: String,
            createdAt: Date,
            updatedAt: Date,
            releasedAt: Date?,
            consumedAt: Date?,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.projectID = projectID
            self.typeID = typeID
            self.reservedQuantity = reservedQuantity
            self.consumedQuantity = consumedQuantity
            self.priority = priority
            self.expiresAt = expiresAt
            self.statusRaw = statusRaw
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.releasedAt = releasedAt
            self.consumedAt = consumedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias StockReservationRecord =
    NexusSchemaV14.StockReservationRecord
