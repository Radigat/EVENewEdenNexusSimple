import Foundation
import SwiftData

public enum NexusSchemaV24: VersionedSchema {
    public static let versionIdentifier = Schema.Version(24, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV23.models + [EVEAccountAuthorizationRecord.self]
    }

    @Model
    public final class EVEAccountAuthorizationRecord {
        @Attribute(.unique) public var characterID: Int64
        public var scopesJSON: Data
        public var authorizedAt: Date
        public var recordVersion: Int

        public init(
            characterID: Int64,
            scopesJSON: Data,
            authorizedAt: Date,
            recordVersion: Int = 1
        ) {
            self.characterID = characterID
            self.scopesJSON = scopesJSON
            self.authorizedAt = authorizedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias EVEAccountAuthorizationRecord =
    NexusSchemaV24.EVEAccountAuthorizationRecord
