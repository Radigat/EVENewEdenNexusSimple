import Foundation
import SwiftData

public enum NexusSchemaV19: VersionedSchema {
    public static let versionIdentifier = Schema.Version(19, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            NexusSchemaV3.CharacterRecord.self,
            NexusSchemaV8.ProductionProject.self,
            NexusSchemaV3.StaticDataVersion.self,
            NexusSchemaV3.ItemCategory.self,
            NexusSchemaV3.ItemGroup.self,
            NexusSchemaV3.ItemType.self,
            NexusSchemaV3.BlueprintDefinition.self,
            NexusSchemaV3.BlueprintActivity.self,
            NexusSchemaV3.BlueprintMaterial.self,
            NexusSchemaV3.BlueprintProduct.self,
            NexusSchemaV4.SDEUpdateCheckRecord.self,
            NexusSchemaV8.ProductionGraphRecord.self,
            NexusSchemaV9.ReactionRuleRecord.self,
            NexusSchemaV10.StorageLocationRecord.self,
            NexusSchemaV10.ManualStockRecord.self,
            NexusSchemaV11.InventoryImportRecord.self,
            NexusSchemaV12.InventoryAvailabilityConfigurationRecord.self,
            NexusSchemaV13.StockPolicyRecord.self,
            NexusSchemaV14.StockReservationRecord.self,
            NexusSchemaV15.BuildOrBuyDecisionRecord.self,
            NexusSchemaV16.PriceProfileRecord.self,
            NexusSchemaV16.ManualPriceRecord.self,
            NexusSchemaV17.PriceImportRecord.self,
            NexusSchemaV18.ProjectEconomicsConfigurationRecord.self,
            ShoppingQuantityOverrideRecord.self
        ]
    }

    @Model
    public final class ShoppingQuantityOverrideRecord {
        @Attribute(.unique) public var id: UUID
        public var projectID: UUID
        public var typeID: Int64
        public var quantity: Int64
        public var createdAt: Date
        public var updatedAt: Date

        public init(
            id: UUID,
            projectID: UUID,
            typeID: Int64,
            quantity: Int64,
            createdAt: Date,
            updatedAt: Date
        ) {
            self.id = id
            self.projectID = projectID
            self.typeID = typeID
            self.quantity = quantity
            self.createdAt = createdAt
            self.updatedAt = updatedAt
        }
    }
}

public typealias ShoppingQuantityOverrideRecord =
    NexusSchemaV19.ShoppingQuantityOverrideRecord
