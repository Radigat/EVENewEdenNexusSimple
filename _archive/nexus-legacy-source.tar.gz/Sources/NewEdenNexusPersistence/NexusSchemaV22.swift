import Foundation
import SwiftData

public enum NexusSchemaV22: VersionedSchema {
    public static let versionIdentifier = Schema.Version(22, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV21.models + [WalletProjectAssignmentRecord.self]
    }

    @Model
    public final class WalletProjectAssignmentRecord {
        @Attribute(.unique) public var id: UUID
        public var projectID: UUID
        public var characterID: Int64
        public var sourceKindRaw: String
        public var sourceID: Int64
        public var directionRaw: String
        public var assignedQuantity: Int64
        public var assignedAmountHundredths: Int64
        public var sourceRevision: UUID
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            projectID: UUID,
            characterID: Int64,
            sourceKindRaw: String,
            sourceID: Int64,
            directionRaw: String,
            assignedQuantity: Int64,
            assignedAmountHundredths: Int64,
            sourceRevision: UUID,
            createdAt: Date,
            updatedAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.projectID = projectID
            self.characterID = characterID
            self.sourceKindRaw = sourceKindRaw
            self.sourceID = sourceID
            self.directionRaw = directionRaw
            self.assignedQuantity = assignedQuantity
            self.assignedAmountHundredths = assignedAmountHundredths
            self.sourceRevision = sourceRevision
            self.createdAt = createdAt
            self.updatedAt = updatedAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias WalletProjectAssignmentRecord =
    NexusSchemaV22.WalletProjectAssignmentRecord
