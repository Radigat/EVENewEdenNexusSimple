import Foundation
import SwiftData

public enum NexusLegacySchema: VersionedSchema {
    public static let versionIdentifier = Schema.Version(0, 9, 0)

    public static var models: [any PersistentModel.Type] {
        [CharacterRecord.self, ProductionProject.self]
    }

    @Model
    public final class CharacterRecord {
        @Attribute(.unique) public var characterID: Int64
        public var name: String
        public var accountLabel: String
        public var syncStateRaw: String
        public var lastSync: Date?
        public var industrySlots: Int
        public var scienceSlots: Int
        public var activeJobs: Int
        public var createdAt: Date

        public init(
            characterID: Int64,
            name: String,
            accountLabel: String,
            syncStateRaw: String,
            lastSync: Date?,
            industrySlots: Int,
            scienceSlots: Int,
            activeJobs: Int,
            createdAt: Date
        ) {
            self.characterID = characterID
            self.name = name
            self.accountLabel = accountLabel
            self.syncStateRaw = syncStateRaw
            self.lastSync = lastSync
            self.industrySlots = industrySlots
            self.scienceSlots = scienceSlots
            self.activeJobs = activeJobs
            self.createdAt = createdAt
        }
    }

    @Model
    public final class ProductionProject {
        @Attribute(.unique) public var id: UUID
        public var name: String
        public var productName: String
        public var targetQuantity: Int
        public var statusRaw: String
        public var priority: Int
        public var targetDate: Date?
        public var notes: String
        public var createdAt: Date
        public var updatedAt: Date

        public init(
            id: UUID,
            name: String,
            productName: String,
            targetQuantity: Int,
            statusRaw: String,
            priority: Int,
            targetDate: Date?,
            notes: String,
            createdAt: Date,
            updatedAt: Date
        ) {
            self.id = id
            self.name = name
            self.productName = productName
            self.targetQuantity = targetQuantity
            self.statusRaw = statusRaw
            self.priority = priority
            self.targetDate = targetDate
            self.notes = notes
            self.createdAt = createdAt
            self.updatedAt = updatedAt
        }
    }
}
