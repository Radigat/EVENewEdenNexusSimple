import Foundation
import NewEdenNexusApplication
import NewEdenNexusDomain
import SwiftData

public enum NexusSchemaV3: VersionedSchema {
    public static let versionIdentifier = Schema.Version(3, 0, 0)

    public static var models: [any PersistentModel.Type] {
        [
            CharacterRecord.self,
            ProductionProject.self,
            StaticDataVersion.self,
            ItemCategory.self,
            ItemGroup.self,
            ItemType.self,
            BlueprintDefinition.self,
            BlueprintActivity.self,
            BlueprintMaterial.self,
            BlueprintProduct.self
        ]
    }

    @Model
    public final class CharacterRecord {
        @Attribute(.unique) public var characterID: Int64
        public var name: String
        public var accountLabel: String
        public var syncStateRaw: String
        public var lastSync: Date?
        public var industrySlots: Int
        public var scienceSlots: Int
        public var activeJobs: Int
        public var createdAt: Date
        public var recordVersion: Int = 1

        public init(
            characterID: Int64,
            name: String,
            accountLabel: String = "EVE Online",
            syncState: SyncState = .never
        ) {
            self.characterID = characterID
            self.name = name
            self.accountLabel = accountLabel
            self.syncStateRaw = syncState.rawValue
            self.industrySlots = 0
            self.scienceSlots = 0
            self.activeJobs = 0
            self.createdAt = .now
            self.recordVersion = 1
        }

        public var syncState: SyncState {
            get { SyncState(rawValue: syncStateRaw) ?? .never }
            set { syncStateRaw = newValue.rawValue }
        }
    }

    @Model
    public final class ProductionProject {
        @Attribute(.unique) public var id: UUID
        public var name: String
        public var productName: String
        public var targetQuantity: Int
        public var statusRaw: String
        public var priority: Int
        public var targetDate: Date?
        public var notes: String
        public var createdAt: Date
        public var updatedAt: Date
        public var recordVersion: Int = 1

        public init(
            id: UUID = UUID(),
            name: String,
            productName: String,
            targetQuantity: Int,
            status: ProjectStatus = .planning,
            priority: Int = 2,
            targetDate: Date? = nil,
            notes: String = "",
            createdAt: Date = .now,
            updatedAt: Date = .now
        ) {
            self.id = id
            self.name = name
            self.productName = productName
            self.targetQuantity = max(1, targetQuantity)
            self.statusRaw = status.rawValue
            self.priority = priority
            self.targetDate = targetDate
            self.notes = notes
            self.createdAt = createdAt
            self.updatedAt = max(createdAt, updatedAt)
            self.recordVersion = 1
        }

        public var status: ProjectStatus {
            get { ProjectStatus(rawValue: statusRaw) ?? .planning }
            set {
                statusRaw = newValue.rawValue
                updatedAt = .now
            }
        }
    }

    @Model
    public final class StaticDataVersion {
        @Attribute(.unique) public var contentSHA256: String
        @Attribute(.unique) public var buildNumber: Int
        public var officialArchiveURL: String
        public var sourceFormatRaw: String
        public var importedAt: Date
        public var activatedAt: Date
        public var isActive: Bool
        public var categoryCount: Int
        public var groupCount: Int
        public var itemTypeCount: Int
        public var blueprintCount: Int
        public var activityCount: Int
        public var materialCount: Int
        public var productCount: Int
        public var unresolvedTypeReferenceCount: Int
        public var recordVersion: Int = 1

        public init(
            contentSHA256: String,
            buildNumber: Int,
            officialArchiveURL: String,
            sourceFormat: SDEImportSourceFormat,
            importedAt: Date,
            activatedAt: Date,
            isActive: Bool,
            counts: StaticDataCatalogCounts
        ) {
            self.contentSHA256 = contentSHA256
            self.buildNumber = buildNumber
            self.officialArchiveURL = officialArchiveURL
            self.sourceFormatRaw = sourceFormat.rawValue
            self.importedAt = importedAt
            self.activatedAt = activatedAt
            self.isActive = isActive
            self.categoryCount = counts.categories
            self.groupCount = counts.groups
            self.itemTypeCount = counts.itemTypes
            self.blueprintCount = counts.blueprints
            self.activityCount = counts.activities
            self.materialCount = counts.materials
            self.productCount = counts.products
            self.unresolvedTypeReferenceCount = counts.unresolvedTypeReferences
            self.recordVersion = 1
        }
    }

    @Model
    public final class ItemCategory {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var externalCategoryID: Int64
        public var name: String
        public var published: Bool
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            externalCategoryID: Int64,
            name: String,
            published: Bool
        ) {
            self.identityKey = "\(dataVersion):category:\(externalCategoryID)"
            self.dataVersion = dataVersion
            self.externalCategoryID = externalCategoryID
            self.name = name
            self.published = published
            self.recordVersion = 1
        }
    }

    @Model
    public final class ItemGroup {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var externalGroupID: Int64
        public var categoryExternalID: Int64
        public var name: String
        public var published: Bool
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            externalGroupID: Int64,
            categoryExternalID: Int64,
            name: String,
            published: Bool
        ) {
            self.identityKey = "\(dataVersion):group:\(externalGroupID)"
            self.dataVersion = dataVersion
            self.externalGroupID = externalGroupID
            self.categoryExternalID = categoryExternalID
            self.name = name
            self.published = published
            self.recordVersion = 1
        }
    }

    @Model
    public final class ItemType {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var externalTypeID: Int64
        public var groupExternalID: Int64
        public var categoryExternalID: Int64
        public var marketGroupExternalID: Int64?
        public var name: String
        public var searchName: String = ""
        public var itemDescription: String?
        public var volume: Double?
        public var packagedVolume: Double?
        public var basePrice: Double?
        public var portionSize: Int64
        public var published: Bool
        public var iconExternalID: Int64?
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            snapshot: StaticItemTypeSnapshot
        ) {
            self.identityKey = "\(dataVersion):type:\(snapshot.externalID)"
            self.dataVersion = dataVersion
            self.externalTypeID = snapshot.externalID
            self.groupExternalID = snapshot.groupExternalID
            self.categoryExternalID = snapshot.categoryExternalID
            self.marketGroupExternalID = snapshot.marketGroupExternalID
            self.name = snapshot.name
            self.searchName = CatalogSearchText.normalize(snapshot.name)
            self.itemDescription = snapshot.description
            self.volume = snapshot.volume
            self.packagedVolume = snapshot.packagedVolume
            self.basePrice = snapshot.basePrice
            self.portionSize = snapshot.portionSize
            self.published = snapshot.published
            self.iconExternalID = snapshot.iconExternalID
            self.recordVersion = 1
        }
    }

    @Model
    public final class BlueprintDefinition {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var blueprintTypeID: Int64
        public var maxProductionLimit: Int64?
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            blueprintTypeID: Int64,
            maxProductionLimit: Int64?
        ) {
            self.identityKey = "\(dataVersion):blueprint:\(blueprintTypeID)"
            self.dataVersion = dataVersion
            self.blueprintTypeID = blueprintTypeID
            self.maxProductionLimit = maxProductionLimit
            self.recordVersion = 1
        }
    }

    @Model
    public final class BlueprintActivity {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var blueprintTypeID: Int64
        public var activityRaw: String
        public var timeSeconds: Int64
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            blueprintTypeID: Int64,
            activity: StaticIndustryActivity,
            timeSeconds: Int64
        ) {
            self.identityKey =
                "\(dataVersion):activity:\(blueprintTypeID):\(activity.rawValue)"
            self.dataVersion = dataVersion
            self.blueprintTypeID = blueprintTypeID
            self.activityRaw = activity.rawValue
            self.timeSeconds = timeSeconds
            self.recordVersion = 1
        }
    }

    @Model
    public final class BlueprintMaterial {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var blueprintTypeID: Int64
        public var activityRaw: String
        public var materialTypeID: Int64
        public var typeIsResolved: Bool
        public var quantity: Int64
        public var consumptionTypeRaw: String
        public var sortOrder: Int
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            blueprintTypeID: Int64,
            activity: StaticIndustryActivity,
            snapshot: StaticBlueprintMaterialSnapshot
        ) {
            self.identityKey =
                "\(dataVersion):material:\(blueprintTypeID):"
                + "\(activity.rawValue):\(snapshot.itemTypeID)"
            self.dataVersion = dataVersion
            self.blueprintTypeID = blueprintTypeID
            self.activityRaw = activity.rawValue
            self.materialTypeID = snapshot.itemTypeID
            self.typeIsResolved = snapshot.typeIsResolved
            self.quantity = snapshot.quantity
            self.consumptionTypeRaw = snapshot.consumptionType.rawValue
            self.sortOrder = snapshot.sortOrder
            self.recordVersion = 1
        }
    }

    @Model
    public final class BlueprintProduct {
        @Attribute(.unique) public var identityKey: String
        public var dataVersion: String
        public var blueprintTypeID: Int64
        public var activityRaw: String
        public var productTypeID: Int64
        public var typeIsResolved: Bool
        public var quantity: Int64
        public var probability: Double?
        public var sortOrder: Int
        public var recordVersion: Int = 1

        public init(
            dataVersion: String,
            blueprintTypeID: Int64,
            activity: StaticIndustryActivity,
            snapshot: StaticBlueprintProductSnapshot
        ) {
            self.identityKey =
                "\(dataVersion):product:\(blueprintTypeID):"
                + "\(activity.rawValue):\(snapshot.itemTypeID)"
            self.dataVersion = dataVersion
            self.blueprintTypeID = blueprintTypeID
            self.activityRaw = activity.rawValue
            self.productTypeID = snapshot.itemTypeID
            self.typeIsResolved = snapshot.typeIsResolved
            self.quantity = snapshot.quantity
            self.probability = snapshot.probability
            self.sortOrder = snapshot.sortOrder
            self.recordVersion = 1
        }
    }
}

public typealias CharacterRecord = NexusSchemaV3.CharacterRecord
public typealias StaticDataVersion = NexusSchemaV3.StaticDataVersion
public typealias ItemCategory = NexusSchemaV3.ItemCategory
public typealias ItemGroup = NexusSchemaV3.ItemGroup
public typealias ItemType = NexusSchemaV3.ItemType
public typealias BlueprintDefinition = NexusSchemaV3.BlueprintDefinition
public typealias BlueprintActivity = NexusSchemaV3.BlueprintActivity
public typealias BlueprintMaterial = NexusSchemaV3.BlueprintMaterial
public typealias BlueprintProduct = NexusSchemaV3.BlueprintProduct
