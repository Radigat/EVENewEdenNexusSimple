import Foundation
import SwiftData

public enum NexusSchemaV21: VersionedSchema {
    public static let versionIdentifier = Schema.Version(21, 0, 0)

    public static var models: [any PersistentModel.Type] {
        NexusSchemaV20.models + [MarketPriceProvenanceRecord.self]
    }

    @Model
    public final class MarketPriceProvenanceRecord {
        @Attribute(.unique) public var id: UUID
        public var priceID: UUID
        public var profileID: UUID
        public var typeID: Int64
        public var regionID: Int64
        public var locationID: Int64?
        public var locationLabel: String?
        public var requestedQuantity: Int64
        public var fulfilledQuantity: Int64
        public var orderCount: Int
        public var totalCostHundredths: Int64
        public var ordersFetchedAt: Date
        public var checkedAt: Date
        public var cacheExpiresAt: Date?
        public var sourceRaw: String
        public var createdAt: Date
        public var recordVersion: Int

        public init(
            id: UUID,
            priceID: UUID,
            profileID: UUID,
            typeID: Int64,
            regionID: Int64,
            locationID: Int64?,
            locationLabel: String?,
            requestedQuantity: Int64,
            fulfilledQuantity: Int64,
            orderCount: Int,
            totalCostHundredths: Int64,
            ordersFetchedAt: Date,
            checkedAt: Date,
            cacheExpiresAt: Date?,
            sourceRaw: String,
            createdAt: Date,
            recordVersion: Int = 1
        ) {
            self.id = id
            self.priceID = priceID
            self.profileID = profileID
            self.typeID = typeID
            self.regionID = regionID
            self.locationID = locationID
            self.locationLabel = locationLabel
            self.requestedQuantity = requestedQuantity
            self.fulfilledQuantity = fulfilledQuantity
            self.orderCount = orderCount
            self.totalCostHundredths = totalCostHundredths
            self.ordersFetchedAt = ordersFetchedAt
            self.checkedAt = checkedAt
            self.cacheExpiresAt = cacheExpiresAt
            self.sourceRaw = sourceRaw
            self.createdAt = createdAt
            self.recordVersion = recordVersion
        }
    }
}

public typealias MarketPriceProvenanceRecord =
    NexusSchemaV21.MarketPriceProvenanceRecord
