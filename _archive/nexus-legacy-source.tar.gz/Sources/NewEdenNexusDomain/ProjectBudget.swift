import Foundation

public struct ProjectBudgetConfigurationSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let priceProfileID: UUID
    public let logisticsCost: NonNegativeISKAmount
    public let productionCost: NonNegativeISKAmount
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        priceProfileID: UUID,
        logisticsCost: NonNegativeISKAmount,
        productionCost: NonNegativeISKAmount,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard createdAt <= updatedAt else {
            throw ProjectBudgetError.updatedBeforeCreation
        }
        self.id = id
        self.projectID = projectID
        self.priceProfileID = priceProfileID
        self.logisticsCost = logisticsCost
        self.productionCost = productionCost
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct ProjectBudgetMaterialLine: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let purchaseQuantity: Int64
    public let unitPrice: ISKAmount
    public let cost: ISKValue
    public let sources: [BuildOrBuyRequirementSource]
}

public struct ProjectBudgetCalculation: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let materialLines: [ProjectBudgetMaterialLine]
    public let materialPurchaseCost: ISKValue
    public let logisticsCost: NonNegativeISKAmount
    public let productionCost: NonNegativeISKAmount
    public let requiredBudget: ISKValue
}

public enum ProjectBudgetError: Error, Equatable, Sendable {
    case updatedBeforeCreation
    case invalidPurchase(typeID: Int64, quantity: Int64)
    case duplicatePurchaseTypeID(Int64)
    case missingPrice(Int64)
    case arithmeticOverflow
}

public struct ProjectBudgetCalculator: Sendable {
    public init() {}

    public func calculate(
        purchases: [ShoppingListPosition],
        pricesByTypeID: [Int64: ISKAmount],
        logisticsCost: NonNegativeISKAmount,
        productionCost: NonNegativeISKAmount
    ) throws -> ProjectBudgetCalculation {
        var seenTypeIDs = Set<Int64>()
        var materialLines: [ProjectBudgetMaterialLine] = []
        var materialHundredths: Int64 = 0

        for purchase in purchases.sorted(by: {
            $0.typeID < $1.typeID
        }) {
            guard seenTypeIDs.insert(purchase.typeID).inserted else {
                throw ProjectBudgetError.duplicatePurchaseTypeID(
                    purchase.typeID
                )
            }
            guard purchase.typeID > 0,
                  !purchase.name.trimmingCharacters(
                      in: .whitespacesAndNewlines
                  ).isEmpty,
                  purchase.purchaseQuantity >= 0 else {
                throw ProjectBudgetError.invalidPurchase(
                    typeID: purchase.typeID,
                    quantity: purchase.purchaseQuantity
                )
            }
            guard purchase.purchaseQuantity > 0 else { continue }
            guard let unitPrice = pricesByTypeID[purchase.typeID] else {
                throw ProjectBudgetError.missingPrice(purchase.typeID)
            }
            let lineCost = purchase.purchaseQuantity
                .multipliedReportingOverflow(
                    by: unitPrice.hundredths
                )
            guard !lineCost.overflow else {
                throw ProjectBudgetError.arithmeticOverflow
            }
            let total = materialHundredths.addingReportingOverflow(
                lineCost.partialValue
            )
            guard !total.overflow else {
                throw ProjectBudgetError.arithmeticOverflow
            }
            materialHundredths = total.partialValue
            materialLines.append(
                ProjectBudgetMaterialLine(
                    typeID: purchase.typeID,
                    name: purchase.name,
                    purchaseQuantity: purchase.purchaseQuantity,
                    unitPrice: unitPrice,
                    cost: ISKValue(hundredths: lineCost.partialValue),
                    sources: purchase.sources
                )
            )
        }

        let withLogistics = materialHundredths.addingReportingOverflow(
            logisticsCost.hundredths
        )
        guard !withLogistics.overflow else {
            throw ProjectBudgetError.arithmeticOverflow
        }
        let total = withLogistics.partialValue.addingReportingOverflow(
            productionCost.hundredths
        )
        guard !total.overflow else {
            throw ProjectBudgetError.arithmeticOverflow
        }

        return ProjectBudgetCalculation(
            formulaVersion:
                ProjectBudgetCalculation.currentFormulaVersion,
            materialLines: materialLines,
            materialPurchaseCost: ISKValue(
                hundredths: materialHundredths
            ),
            logisticsCost: logisticsCost,
            productionCost: productionCost,
            requiredBudget: ISKValue(hundredths: total.partialValue)
        )
    }
}
