import Foundation

public enum IndustryTechLevel: String, Codable, Equatable, Sendable {
    case techI
    case techII
}

public enum BlueprintPlanningOrigin:
    String,
    Codable,
    Equatable,
    Sendable
{
    case researchedBPO
    case copiedFromBPO
    case inventedBPC
    case legacyT2BPO
    case manualPlanningAssumption
}

public enum BlueprintPlanningKind:
    String,
    Codable,
    Equatable,
    Sendable
{
    case original
    case copy
    case unspecified
}

public enum InventionDecryptor:
    String,
    CaseIterable,
    Codable,
    Equatable,
    Sendable
{
    case accelerant
    case attainment
    case augmentation
    case parity
    case process
    case symmetry
    case optimizedAttainment
    case optimizedAugmentation
}

public struct InventionDecryptorRule:
    Codable,
    Equatable,
    Sendable
{
    public let decryptor: InventionDecryptor
    public let typeID: Int64
    public let probabilityMultiplierPermille: Int
    public let runModifier: Int64
    public let materialEfficiencyModifier: Int
    public let timeEfficiencyModifier: Int

    public init(
        decryptor: InventionDecryptor,
        typeID: Int64,
        probabilityMultiplierPermille: Int,
        runModifier: Int64,
        materialEfficiencyModifier: Int,
        timeEfficiencyModifier: Int
    ) {
        self.decryptor = decryptor
        self.typeID = typeID
        self.probabilityMultiplierPermille =
            probabilityMultiplierPermille
        self.runModifier = runModifier
        self.materialEfficiencyModifier =
            materialEfficiencyModifier
        self.timeEfficiencyModifier = timeEfficiencyModifier
    }
}

public enum IndustryRuleVerificationStatus:
    String,
    Codable,
    Equatable,
    Sendable
{
    case verified
    case provisional
    case needsReview
}

public struct IndustryRuleSet:
    Codable,
    Equatable,
    Sendable
{
    public static let currentVersion = 1
    public static let inventionQualityVersion = 1

    public let version: Int
    public let inventionQualityVersion: Int
    public let verifiedAt: Date
    public let sourceURLs: [String]
    public let verificationStatus: IndustryRuleVerificationStatus
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String
    public let decryptorRules: [InventionDecryptorRule]

    public init(
        version: Int = Self.currentVersion,
        inventionQualityVersion: Int = Self.inventionQualityVersion,
        verifiedAt: Date,
        sourceURLs: [String],
        verificationStatus: IndustryRuleVerificationStatus,
        catalogBuildNumber: Int,
        catalogContentSHA256: String,
        decryptorRules: [InventionDecryptorRule]
    ) {
        self.version = version
        self.inventionQualityVersion = inventionQualityVersion
        self.verifiedAt = verifiedAt
        self.sourceURLs = sourceURLs
        self.verificationStatus = verificationStatus
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = catalogContentSHA256
        self.decryptorRules = decryptorRules.sorted {
            $0.decryptor.rawValue < $1.decryptor.rawValue
        }
    }

    public static func verified(
        catalogBuildNumber: Int,
        catalogContentSHA256: String
    ) -> IndustryRuleSet {
        IndustryRuleSet(
            verifiedAt: Date(timeIntervalSince1970: 1_784_851_200),
            sourceURLs: [
                "https://support.eveonline.com/hc/en-us/articles/203210642-Invention",
                "https://support.eveonline.com/hc/en-us/articles/203270631-Decryptors",
                "https://support.eveonline.com/hc/en-us/articles/203269951-Blueprints",
                "https://developers.eveonline.com/docs/services/static-data/",
                "https://esi.evetech.net/latest/universe/types/34201/",
                "https://esi.evetech.net/latest/universe/types/34202/",
                "https://esi.evetech.net/latest/universe/types/34203/",
                "https://esi.evetech.net/latest/universe/types/34204/",
                "https://esi.evetech.net/latest/universe/types/34205/",
                "https://esi.evetech.net/latest/universe/types/34206/",
                "https://esi.evetech.net/latest/universe/types/34207/",
                "https://esi.evetech.net/latest/universe/types/34208/"
            ],
            verificationStatus: .verified,
            catalogBuildNumber: catalogBuildNumber,
            catalogContentSHA256: catalogContentSHA256,
            decryptorRules: [
                InventionDecryptorRule(
                    decryptor: .accelerant,
                    typeID: 34_201,
                    probabilityMultiplierPermille: 1_200,
                    runModifier: 1,
                    materialEfficiencyModifier: 2,
                    timeEfficiencyModifier: 10
                ),
                InventionDecryptorRule(
                    decryptor: .attainment,
                    typeID: 34_202,
                    probabilityMultiplierPermille: 1_800,
                    runModifier: 4,
                    materialEfficiencyModifier: -1,
                    timeEfficiencyModifier: 4
                ),
                InventionDecryptorRule(
                    decryptor: .augmentation,
                    typeID: 34_203,
                    probabilityMultiplierPermille: 600,
                    runModifier: 9,
                    materialEfficiencyModifier: -2,
                    timeEfficiencyModifier: 2
                ),
                InventionDecryptorRule(
                    decryptor: .parity,
                    typeID: 34_204,
                    probabilityMultiplierPermille: 1_500,
                    runModifier: 3,
                    materialEfficiencyModifier: 1,
                    timeEfficiencyModifier: -2
                ),
                InventionDecryptorRule(
                    decryptor: .process,
                    typeID: 34_205,
                    probabilityMultiplierPermille: 1_100,
                    runModifier: 0,
                    materialEfficiencyModifier: 3,
                    timeEfficiencyModifier: 6
                ),
                InventionDecryptorRule(
                    decryptor: .symmetry,
                    typeID: 34_206,
                    probabilityMultiplierPermille: 1_000,
                    runModifier: 2,
                    materialEfficiencyModifier: 1,
                    timeEfficiencyModifier: 8
                ),
                InventionDecryptorRule(
                    decryptor: .optimizedAttainment,
                    typeID: 34_207,
                    probabilityMultiplierPermille: 1_900,
                    runModifier: 2,
                    materialEfficiencyModifier: 1,
                    timeEfficiencyModifier: -2
                ),
                InventionDecryptorRule(
                    decryptor: .optimizedAugmentation,
                    typeID: 34_208,
                    probabilityMultiplierPermille: 900,
                    runModifier: 7,
                    materialEfficiencyModifier: 2,
                    timeEfficiencyModifier: 0
                )
            ]
        )
    }
}

public struct BlueprintPlanningQuality:
    Codable,
    Equatable,
    Sendable
{
    public let blueprintTypeID: Int64
    public let origin: BlueprintPlanningOrigin
    public let kind: BlueprintPlanningKind
    public let materialEfficiency: Int
    public let timeEfficiency: Int?
    public let licensedRunsPerCopy: Int64?
    public let decryptor: InventionDecryptor?
    public let decryptorTypeID: Int64?
    public let ruleVersion: Int
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String

    public init(
        blueprintTypeID: Int64,
        origin: BlueprintPlanningOrigin,
        kind: BlueprintPlanningKind,
        materialEfficiency: Int,
        timeEfficiency: Int?,
        licensedRunsPerCopy: Int64?,
        decryptor: InventionDecryptor?,
        decryptorTypeID: Int64? = nil,
        ruleVersion: Int,
        catalogBuildNumber: Int,
        catalogContentSHA256: String
    ) {
        self.blueprintTypeID = blueprintTypeID
        self.origin = origin
        self.kind = kind
        self.materialEfficiency = materialEfficiency
        self.timeEfficiency = timeEfficiency
        self.licensedRunsPerCopy = licensedRunsPerCopy
        self.decryptor = decryptor
        self.decryptorTypeID = decryptorTypeID
        self.ruleVersion = ruleVersion
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = catalogContentSHA256
    }

    public static func manual(
        blueprintTypeID: Int64,
        materialEfficiency: Int,
        catalogBuildNumber: Int,
        catalogContentSHA256: String
    ) -> BlueprintPlanningQuality {
        BlueprintPlanningQuality(
            blueprintTypeID: blueprintTypeID,
            origin: .manualPlanningAssumption,
            kind: .unspecified,
            materialEfficiency: materialEfficiency,
            timeEfficiency: nil,
            licensedRunsPerCopy: nil,
            decryptor: nil,
            decryptorTypeID: nil,
            ruleVersion: IndustryRuleSet.currentVersion,
            catalogBuildNumber: catalogBuildNumber,
            catalogContentSHA256: catalogContentSHA256
        )
    }
}

public struct InventionStageReference:
    Codable,
    Equatable,
    Sendable
{
    public let sourceBlueprintTypeID: Int64
    public let baseProbabilityMillionths: Int
    public let baseLicensedRuns: Int64
    public let licensedRunsPerCopy: Int64
    public let requiredSuccessfulCopies: Int64
    public let materialTypeIDs: [Int64]

    public init(
        sourceBlueprintTypeID: Int64,
        baseProbabilityMillionths: Int,
        baseLicensedRuns: Int64,
        licensedRunsPerCopy: Int64,
        requiredSuccessfulCopies: Int64,
        materialTypeIDs: [Int64]
    ) {
        self.sourceBlueprintTypeID = sourceBlueprintTypeID
        self.baseProbabilityMillionths = baseProbabilityMillionths
        self.baseLicensedRuns = baseLicensedRuns
        self.licensedRunsPerCopy = licensedRunsPerCopy
        self.requiredSuccessfulCopies = requiredSuccessfulCopies
        self.materialTypeIDs = materialTypeIDs.sorted()
    }
}

public enum IndustryRuleValidationError:
    Error,
    Equatable,
    Sendable
{
    case unsupportedRuleVersion(Int)
    case unsupportedInventionQualityVersion(Int)
    case rulesNeedReview
    case catalogVersionMismatch
    case invalidBlueprintTypeID(Int64)
    case invalidMaterialEfficiency(Int)
    case invalidTimeEfficiency(Int?)
    case invalidLicensedRuns(Int64?)
    case invalidDecryptorRule(InventionDecryptor)
    case invalidBlueprintOrigin
    case invalidInventionProbability
    case invalidInventionBaseRuns(Int64)
    case arithmeticOverflow
}

public enum IndustryPreflightResult:
    String,
    Codable,
    Equatable,
    Sendable
{
    case pass
    case fail
    case needsReview
}

public enum IndustryRuleValidator {
    public static func preflight(
        ruleSet: IndustryRuleSet,
        catalogBuildNumber: Int,
        catalogContentSHA256: String
    ) -> IndustryPreflightResult {
        guard ruleSet.version == IndustryRuleSet.currentVersion,
              ruleSet.inventionQualityVersion
                == IndustryRuleSet.inventionQualityVersion else {
            return .fail
        }
        guard ruleSet.catalogBuildNumber == catalogBuildNumber,
              ruleSet.catalogContentSHA256 == catalogContentSHA256 else {
            return .fail
        }
        guard ruleSet.verificationStatus == .verified else {
            return .needsReview
        }
        let expected = Set(InventionDecryptor.allCases)
        let actual = Set(ruleSet.decryptorRules.map(\.decryptor))
        guard expected == actual,
              Set(ruleSet.decryptorRules.map(\.typeID)).count
                == ruleSet.decryptorRules.count,
              ruleSet.decryptorRules.allSatisfy({
                  $0.typeID > 0
                    && $0.probabilityMultiplierPermille > 0
              }) else {
            return .fail
        }
        return .pass
    }

    public static func inventedQuality(
        blueprintTypeID: Int64,
        baseLicensedRuns: Int64,
        decryptor: InventionDecryptor?,
        ruleSet: IndustryRuleSet
    ) throws -> BlueprintPlanningQuality {
        guard blueprintTypeID > 0 else {
            throw IndustryRuleValidationError
                .invalidBlueprintTypeID(blueprintTypeID)
        }
        guard baseLicensedRuns > 0 else {
            throw IndustryRuleValidationError
                .invalidInventionBaseRuns(baseLicensedRuns)
        }
        let rule = decryptor.flatMap { selected in
            ruleSet.decryptorRules.first { $0.decryptor == selected }
        }
        if let decryptor, rule == nil {
            throw IndustryRuleValidationError
                .invalidDecryptorRule(decryptor)
        }
        let runs = try adding(
            baseLicensedRuns,
            rule?.runModifier ?? 0
        )
        let materialEfficiency =
            2 + (rule?.materialEfficiencyModifier ?? 0)
        let timeEfficiency =
            4 + (rule?.timeEfficiencyModifier ?? 0)
        return BlueprintPlanningQuality(
            blueprintTypeID: blueprintTypeID,
            origin: .inventedBPC,
            kind: .copy,
            materialEfficiency: materialEfficiency,
            timeEfficiency: timeEfficiency,
            licensedRunsPerCopy: runs,
            decryptor: decryptor,
            decryptorTypeID: rule?.typeID,
            ruleVersion: ruleSet.version,
            catalogBuildNumber: ruleSet.catalogBuildNumber,
            catalogContentSHA256: ruleSet.catalogContentSHA256
        )
    }

    public static func validate(
        _ quality: BlueprintPlanningQuality,
        ruleSet: IndustryRuleSet
    ) throws {
        guard quality.blueprintTypeID > 0 else {
            throw IndustryRuleValidationError
                .invalidBlueprintTypeID(quality.blueprintTypeID)
        }
        guard (0...10).contains(quality.materialEfficiency) else {
            throw IndustryRuleValidationError
                .invalidMaterialEfficiency(quality.materialEfficiency)
        }
        if let timeEfficiency = quality.timeEfficiency,
           !(0...20).contains(timeEfficiency) {
            throw IndustryRuleValidationError
                .invalidTimeEfficiency(quality.timeEfficiency)
        }
        guard quality.ruleVersion == ruleSet.version,
              quality.catalogBuildNumber == ruleSet.catalogBuildNumber,
              quality.catalogContentSHA256
                == ruleSet.catalogContentSHA256 else {
            throw IndustryRuleValidationError.catalogVersionMismatch
        }
        switch quality.origin {
        case .inventedBPC:
            guard quality.kind == .copy,
                  let runs = quality.licensedRunsPerCopy,
                  runs > 0 else {
                throw IndustryRuleValidationError.invalidBlueprintOrigin
            }
            let expected = try inventedQuality(
                blueprintTypeID: quality.blueprintTypeID,
                baseLicensedRuns:
                    runs - (ruleSet.decryptorRules.first {
                        $0.decryptor == quality.decryptor
                    }?.runModifier ?? 0),
                decryptor: quality.decryptor,
                ruleSet: ruleSet
            )
            guard quality.materialEfficiency
                    == expected.materialEfficiency,
                  quality.timeEfficiency == expected.timeEfficiency,
                  quality.licensedRunsPerCopy
                    == expected.licensedRunsPerCopy,
                  quality.decryptorTypeID
                    == expected.decryptorTypeID else {
                throw IndustryRuleValidationError.invalidBlueprintOrigin
            }
        case .legacyT2BPO, .researchedBPO:
            guard quality.kind == .original,
                  quality.licensedRunsPerCopy == nil,
                  quality.decryptor == nil,
                  quality.decryptorTypeID == nil,
                  quality.timeEfficiency != nil else {
                throw IndustryRuleValidationError.invalidBlueprintOrigin
            }
        case .copiedFromBPO:
            guard quality.kind == .copy,
                  quality.licensedRunsPerCopy.map({ $0 > 0 }) == true,
                  quality.decryptor == nil,
                  quality.decryptorTypeID == nil,
                  quality.timeEfficiency != nil else {
                throw IndustryRuleValidationError.invalidBlueprintOrigin
            }
        case .manualPlanningAssumption:
            guard quality.decryptor == nil,
                  quality.decryptorTypeID == nil else {
                throw IndustryRuleValidationError.invalidBlueprintOrigin
            }
        }
    }

    public static func requiredSuccessfulCopies(
        requiredRuns: Int64,
        licensedRunsPerCopy: Int64
    ) throws -> Int64 {
        guard requiredRuns > 0, licensedRunsPerCopy > 0 else {
            throw IndustryRuleValidationError
                .invalidLicensedRuns(licensedRunsPerCopy)
        }
        let (adjusted, overflow) = requiredRuns.addingReportingOverflow(
            licensedRunsPerCopy - 1
        )
        guard !overflow else {
            throw IndustryRuleValidationError.arithmeticOverflow
        }
        return adjusted / licensedRunsPerCopy
    }

    private static func adding(
        _ lhs: Int64,
        _ rhs: Int64
    ) throws -> Int64 {
        let (result, overflow) = lhs.addingReportingOverflow(rhs)
        guard !overflow, result > 0 else {
            throw IndustryRuleValidationError.arithmeticOverflow
        }
        return result
    }
}
