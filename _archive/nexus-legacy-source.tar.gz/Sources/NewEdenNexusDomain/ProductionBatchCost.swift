import Foundation

public enum ProductionBatchCostKind:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case material
    case industryJob = "industry_job"
    case facilityAndTax = "facility_and_tax"
    case blueprintAndInvention = "blueprint_and_invention"
    case logistics
    case marketFees = "market_fees"
    case manualOther = "manual_other"
}

public enum ProductionBatchCostSource:
    String,
    Codable,
    Sendable
{
    case projectBudget = "project_budget"
    case esiMarket = "esi_market"
    case esiIndustryJob = "esi_industry_job"
    case transaction
    case journal
    case manual
}

public enum ProductionBatchCostAssignment:
    String,
    Codable,
    Sendable
{
    case calculated
    case esi
    case transaction
    case journal
    case manual
}

public struct ProductionBatchCostLine:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public let id: UUID
    public let kind: ProductionBatchCostKind
    public let label: String
    public let amount: NonNegativeISKAmount?
    public let source: ProductionBatchCostSource
    public let assignment: ProductionBatchCostAssignment
    public let sourceObservedAt: Date
    public let warnings: [String]

    public init(
        id: UUID,
        kind: ProductionBatchCostKind,
        label: String,
        amount: NonNegativeISKAmount?,
        source: ProductionBatchCostSource,
        assignment: ProductionBatchCostAssignment,
        sourceObservedAt: Date,
        warnings: [String] = []
    ) throws {
        let normalized = label.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !normalized.isEmpty else {
            throw ProductionBatchCostError.emptyLabel
        }
        self.id = id
        self.kind = kind
        self.label = normalized
        self.amount = amount
        self.source = source
        self.assignment = assignment
        self.sourceObservedAt = sourceObservedAt
        self.warnings = warnings
    }
}

public enum ProductionPriceQuoteSide:
    String,
    Codable,
    Sendable
{
    case sell
}

public enum ProductionPriceQuoteFallback:
    String,
    Codable,
    Sendable
{
    case none
    case freshCache = "fresh_cache"
    case staleCache = "stale_cache"
    case manualPriceSet = "manual_price_set"
    case unavailable
}

public struct PriceQuoteBinding:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public let id: UUID
    public let typeID: Int64
    public let itemName: String
    public let regionID: Int64?
    public let regionName: String?
    public let locationID: Int64?
    public let locationName: String?
    public let side: ProductionPriceQuoteSide
    public let quantity: Int64
    public let fulfilledQuantity: Int64
    public let orderCount: Int
    public let unitPrice: ISKAmount?
    public let observedAt: Date
    public let expiresAt: Date?
    public let sourceSnapshotID: UUID
    public let policyVersion: Int
    public let fallback: ProductionPriceQuoteFallback
    public let warnings: [String]

    public init(
        id: UUID,
        typeID: Int64,
        itemName: String,
        regionID: Int64?,
        regionName: String?,
        locationID: Int64?,
        locationName: String?,
        side: ProductionPriceQuoteSide = .sell,
        quantity: Int64,
        fulfilledQuantity: Int64,
        orderCount: Int,
        unitPrice: ISKAmount?,
        observedAt: Date,
        expiresAt: Date?,
        sourceSnapshotID: UUID,
        policyVersion: Int,
        fallback: ProductionPriceQuoteFallback,
        warnings: [String] = []
    ) throws {
        guard typeID > 0 else {
            throw ProductionBatchCostError.invalidTypeID(typeID)
        }
        guard quantity > 0,
            fulfilledQuantity >= 0,
            fulfilledQuantity <= quantity,
            orderCount >= 0
        else {
            throw ProductionBatchCostError.invalidQuoteQuantity
        }
        guard policyVersion > 0 else {
            throw ProductionBatchCostError.invalidPolicyVersion
        }
        self.id = id
        self.typeID = typeID
        self.itemName = itemName
        self.regionID = regionID
        self.regionName = regionName
        self.locationID = locationID
        self.locationName = locationName
        self.side = side
        self.quantity = quantity
        self.fulfilledQuantity = fulfilledQuantity
        self.orderCount = orderCount
        self.unitPrice = unitPrice
        self.observedAt = observedAt
        self.expiresAt = expiresAt
        self.sourceSnapshotID = sourceSnapshotID
        self.policyVersion = policyVersion
        self.fallback = fallback
        self.warnings = warnings
    }
}

public struct ProductionBatchCostCalculation:
    Equatable,
    Codable,
    Sendable
{
    public let totalCost: ISKValue?
    public let unitCost: ISKValue?
    public let suggestionFivePercent: ISKValue?
    public let suggestionTenPercent: ISKValue?
    public let selectedSaleUnitPrice: ISKAmount?
    public let forecastRevenue: ISKValue?
    public let forecastProfit: ISKValue?
    public let margin: ISKPercentage?
    public let roi: ISKPercentage?
    public let breakEvenUnitPrice: ISKValue?
}

public struct ProductionBatchCostSnapshot:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public static let currentContractVersion = 1
    public static let currentFormulaVersion = 1
    public static let currentQuotePolicyVersion = 1

    public let id: UUID
    public let batchID: UUID
    public let batchUpdatedAt: Date
    public let contractVersion: Int
    public let formulaVersion: Int
    public let priceProfileID: UUID?
    public let priceProfileName: String?
    public let costLines: [ProductionBatchCostLine]
    public let jitaQuote: PriceQuoteBinding?
    public let alternativeQuote: PriceQuoteBinding?
    public let selectedSaleQuoteID: UUID?
    public let calculation: ProductionBatchCostCalculation
    public let createdAt: Date

    public init(
        id: UUID,
        batchID: UUID,
        batchUpdatedAt: Date,
        contractVersion: Int = currentContractVersion,
        formulaVersion: Int = currentFormulaVersion,
        priceProfileID: UUID?,
        priceProfileName: String?,
        costLines: [ProductionBatchCostLine],
        jitaQuote: PriceQuoteBinding?,
        alternativeQuote: PriceQuoteBinding?,
        selectedSaleQuoteID: UUID?,
        calculation: ProductionBatchCostCalculation,
        createdAt: Date
    ) throws {
        guard contractVersion > 0, formulaVersion > 0 else {
            throw ProductionBatchCostError.invalidPolicyVersion
        }
        let quoteIDs = Set(
            [jitaQuote?.id, alternativeQuote?.id].compactMap { $0 }
        )
        guard selectedSaleQuoteID.map(quoteIDs.contains) ?? true else {
            throw ProductionBatchCostError.invalidSelectedQuote
        }
        self.id = id
        self.batchID = batchID
        self.batchUpdatedAt = batchUpdatedAt
        self.contractVersion = contractVersion
        self.formulaVersion = formulaVersion
        self.priceProfileID = priceProfileID
        self.priceProfileName = priceProfileName
        self.costLines = costLines
        self.jitaQuote = jitaQuote
        self.alternativeQuote = alternativeQuote
        self.selectedSaleQuoteID = selectedSaleQuoteID
        self.calculation = calculation
        self.createdAt = createdAt
    }
}

public enum ProductionBatchCostError:
    Error,
    Equatable,
    Sendable
{
    case emptyLabel
    case invalidTypeID(Int64)
    case invalidOutputUnits(Int64)
    case invalidQuoteQuantity
    case invalidPolicyVersion
    case invalidSelectedQuote
    case arithmeticOverflow
}

public struct ProductionBatchCostCalculator: Sendable {
    public init() {}

    public func calculate(
        outputUnits: Int64,
        costLines: [ProductionBatchCostLine],
        selectedSaleUnitPrice: ISKAmount?
    ) throws -> ProductionBatchCostCalculation {
        guard outputUnits > 0 else {
            throw ProductionBatchCostError.invalidOutputUnits(outputUnits)
        }
        guard costLines.allSatisfy({ $0.amount != nil }) else {
            return ProductionBatchCostCalculation(
                totalCost: nil,
                unitCost: nil,
                suggestionFivePercent: nil,
                suggestionTenPercent: nil,
                selectedSaleUnitPrice: selectedSaleUnitPrice,
                forecastRevenue: nil,
                forecastProfit: nil,
                margin: nil,
                roi: nil,
                breakEvenUnitPrice: nil
            )
        }
        let total = try costLines.reduce(Int64.zero) { partial, line in
            try add(partial, line.amount?.hundredths ?? 0)
        }
        let unit = try ceilingDivide(total, by: outputUnits)
        let five = try percentageMarkup(unit, numerator: 105)
        let ten = try percentageMarkup(unit, numerator: 110)

        guard let selectedSaleUnitPrice else {
            return ProductionBatchCostCalculation(
                totalCost: ISKValue(hundredths: total),
                unitCost: ISKValue(hundredths: unit),
                suggestionFivePercent: ISKValue(hundredths: five),
                suggestionTenPercent: ISKValue(hundredths: ten),
                selectedSaleUnitPrice: nil,
                forecastRevenue: nil,
                forecastProfit: nil,
                margin: nil,
                roi: nil,
                breakEvenUnitPrice: ISKValue(hundredths: unit)
            )
        }
        let revenue = try multiply(
            outputUnits,
            selectedSaleUnitPrice.hundredths
        )
        let profit = try subtract(revenue, total)
        return ProductionBatchCostCalculation(
            totalCost: ISKValue(hundredths: total),
            unitCost: ISKValue(hundredths: unit),
            suggestionFivePercent: ISKValue(hundredths: five),
            suggestionTenPercent: ISKValue(hundredths: ten),
            selectedSaleUnitPrice: selectedSaleUnitPrice,
            forecastRevenue: ISKValue(hundredths: revenue),
            forecastProfit: ISKValue(hundredths: profit),
            margin: revenue == 0
                ? nil
                : try percentage(profit, denominator: revenue),
            roi: total == 0
                ? nil
                : try percentage(profit, denominator: total),
            breakEvenUnitPrice: ISKValue(hundredths: unit)
        )
    }

    private func percentageMarkup(
        _ value: Int64,
        numerator: Int64
    ) throws -> Int64 {
        let product = try multiply(value, numerator)
        return try ceilingDivide(product, by: 100)
    }

    private func ceilingDivide(
        _ numerator: Int64,
        by denominator: Int64
    ) throws -> Int64 {
        guard numerator >= 0, denominator > 0 else {
            throw ProductionBatchCostError.arithmeticOverflow
        }
        let quotient = numerator / denominator
        return numerator % denominator == 0
            ? quotient
            : try add(quotient, 1)
    }

    private func percentage(
        _ numerator: Int64,
        denominator: Int64
    ) throws -> ISKPercentage {
        let scaled = try multiply(numerator, 10_000)
        var quotient = scaled / denominator
        let remainder = scaled % denominator
        let threshold = denominator / 2 + denominator % 2
        if remainder.magnitude >= UInt64(threshold) {
            quotient = try add(quotient, scaled < 0 ? -1 : 1)
        }
        return ISKPercentage(basisPoints: quotient)
    }

    private func multiply(_ lhs: Int64, _ rhs: Int64) throws -> Int64 {
        let result = lhs.multipliedReportingOverflow(by: rhs)
        guard !result.overflow else {
            throw ProductionBatchCostError.arithmeticOverflow
        }
        return result.partialValue
    }

    private func add(_ lhs: Int64, _ rhs: Int64) throws -> Int64 {
        let result = lhs.addingReportingOverflow(rhs)
        guard !result.overflow else {
            throw ProductionBatchCostError.arithmeticOverflow
        }
        return result.partialValue
    }

    private func subtract(_ lhs: Int64, _ rhs: Int64) throws -> Int64 {
        let result = lhs.subtractingReportingOverflow(rhs)
        guard !result.overflow else {
            throw ProductionBatchCostError.arithmeticOverflow
        }
        return result.partialValue
    }
}
