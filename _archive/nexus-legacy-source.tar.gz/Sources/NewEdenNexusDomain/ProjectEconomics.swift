import Foundation

public struct NonNegativeISKAmount:
    Hashable,
    Comparable,
    Codable,
    Sendable
{
    public let hundredths: Int64

    public init(hundredths: Int64) throws {
        guard hundredths >= 0 else {
            throw ProjectEconomicsError.negativeJobCost(hundredths)
        }
        self.hundredths = hundredths
    }

    private init(uncheckedHundredths: Int64) {
        self.hundredths = uncheckedHundredths
    }

    public static let zero = NonNegativeISKAmount(uncheckedHundredths: 0)

    public static func parse(_ text: String) throws -> Self {
        do {
            return try .init(hundredths: ISKAmount.parse(text).hundredths)
        } catch ISKAmountValidationError.notPositive {
            let normalized = text.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            let zeroForms = ["0", "0.0", "0.00", "0,0", "0,00"]
            guard zeroForms.contains(normalized) else {
                throw ISKAmountValidationError.notPositive
            }
            return .zero
        }
    }

    public var displayText: String {
        ISKValue(hundredths: hundredths).displayText
    }

    public static func < (
        lhs: NonNegativeISKAmount,
        rhs: NonNegativeISKAmount
    ) -> Bool {
        lhs.hundredths < rhs.hundredths
    }
}

public struct ISKValue:
    Hashable,
    Comparable,
    Codable,
    Sendable
{
    public let hundredths: Int64

    public init(hundredths: Int64) {
        self.hundredths = hundredths
    }

    public var displayText: String {
        let magnitude = hundredths.magnitude
        let whole = magnitude / UInt64(ISKAmount.scale)
        let fraction = magnitude % UInt64(ISKAmount.scale)
        let sign = hundredths < 0 ? "-" : ""
        return "\(sign)\(whole).\(String(format: "%02llu", fraction))"
    }

    public static func < (lhs: ISKValue, rhs: ISKValue) -> Bool {
        lhs.hundredths < rhs.hundredths
    }
}

public struct ISKPercentage:
    Hashable,
    Comparable,
    Codable,
    Sendable
{
    /// 10,000 basis points are 100.00 percent.
    public let basisPoints: Int64

    public init(basisPoints: Int64) {
        self.basisPoints = basisPoints
    }

    public var displayText: String {
        let magnitude = basisPoints.magnitude
        let whole = magnitude / 100
        let fraction = magnitude % 100
        let sign = basisPoints < 0 ? "-" : ""
        return "\(sign)\(whole).\(String(format: "%02llu", fraction)) %"
    }

    public static func < (lhs: ISKPercentage, rhs: ISKPercentage) -> Bool {
        lhs.basisPoints < rhs.basisPoints
    }
}

public struct ProjectEconomicsMaterialLine: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let requiredQuantity: Int64
    public let inventoryQuantity: Int64
    public let missingQuantity: Int64
    public let unitPrice: ISKAmount
    public let cashCost: ISKValue
    public let economicCost: ISKValue
}

public struct ProjectEconomicsConfigurationSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let priceProfileID: UUID
    public let manualJobCost: NonNegativeISKAmount
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        priceProfileID: UUID,
        manualJobCost: NonNegativeISKAmount,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard createdAt <= updatedAt else {
            throw ProjectEconomicsError.updatedBeforeCreation
        }
        self.id = id
        self.projectID = projectID
        self.priceProfileID = priceProfileID
        self.manualJobCost = manualJobCost
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct ProjectEconomicsCalculation: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let targetTypeID: Int64
    public let targetName: String
    public let targetQuantity: Int64
    public let targetUnitPrice: ISKAmount
    public let materialLines: [ProjectEconomicsMaterialLine]
    public let cashMaterialCost: ISKValue
    public let economicMaterialCost: ISKValue
    public let manualJobCost: NonNegativeISKAmount
    public let cashTotalCost: ISKValue
    public let economicTotalCost: ISKValue
    public let expectedRevenue: ISKValue
    public let expectedProfit: ISKValue
    public let margin: ISKPercentage
    public let roi: ISKPercentage?
    public let breakEvenTotal: ISKValue
    public let breakEvenUnitPrice: ISKValue
}

public enum ProjectEconomicsError: Error, Equatable, Sendable {
    case invalidTargetTypeID(Int64)
    case emptyTargetName
    case invalidTargetQuantity(Int64)
    case negativeJobCost(Int64)
    case updatedBeforeCreation
    case invalidRequirement(
        typeID: Int64,
        required: Int64,
        inventory: Int64,
        missing: Int64
    )
    case duplicateRequirementTypeID(Int64)
    case missingPrice(Int64)
    case arithmeticOverflow
}

public struct ProjectEconomicsCalculator: Sendable {
    public init() {}

    public func calculate(
        targetTypeID: Int64,
        targetName: String,
        targetQuantity: Int64,
        requirements: [BuildOrBuyRequirementLine],
        pricesByTypeID: [Int64: ISKAmount],
        manualJobCost: NonNegativeISKAmount
    ) throws -> ProjectEconomicsCalculation {
        guard targetTypeID > 0 else {
            throw ProjectEconomicsError.invalidTargetTypeID(targetTypeID)
        }
        let normalizedName = targetName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !normalizedName.isEmpty else {
            throw ProjectEconomicsError.emptyTargetName
        }
        guard targetQuantity > 0 else {
            throw ProjectEconomicsError.invalidTargetQuantity(targetQuantity)
        }
        guard let targetUnitPrice = pricesByTypeID[targetTypeID] else {
            throw ProjectEconomicsError.missingPrice(targetTypeID)
        }

        var seenTypeIDs = Set<Int64>()
        var materialLines: [ProjectEconomicsMaterialLine] = []
        var cashMaterialHundredths: Int64 = 0
        var economicMaterialHundredths: Int64 = 0

        for requirement in requirements.sorted(by: {
            $0.typeID < $1.typeID
        }) {
            guard seenTypeIDs.insert(requirement.typeID).inserted else {
                throw ProjectEconomicsError.duplicateRequirementTypeID(
                    requirement.typeID
                )
            }
            let (accountedQuantity, quantityOverflow) =
                requirement.inventoryQuantity.addingReportingOverflow(
                    requirement.missingQuantity
                )
            guard requirement.typeID > 0,
                  requirement.requiredQuantity >= 0,
                  requirement.inventoryQuantity >= 0,
                  requirement.missingQuantity >= 0,
                  !quantityOverflow,
                  accountedQuantity == requirement.requiredQuantity else {
                throw ProjectEconomicsError.invalidRequirement(
                    typeID: requirement.typeID,
                    required: requirement.requiredQuantity,
                    inventory: requirement.inventoryQuantity,
                    missing: requirement.missingQuantity
                )
            }
            guard requirement.requiredQuantity > 0 else { continue }
            guard let unitPrice = pricesByTypeID[requirement.typeID] else {
                throw ProjectEconomicsError.missingPrice(requirement.typeID)
            }
            let cash = try multiply(
                requirement.missingQuantity,
                unitPrice.hundredths
            )
            let economic = try multiply(
                requirement.requiredQuantity,
                unitPrice.hundredths
            )
            cashMaterialHundredths = try add(
                cashMaterialHundredths,
                cash
            )
            economicMaterialHundredths = try add(
                economicMaterialHundredths,
                economic
            )
            materialLines.append(
                ProjectEconomicsMaterialLine(
                    typeID: requirement.typeID,
                    name: requirement.name,
                    requiredQuantity: requirement.requiredQuantity,
                    inventoryQuantity: requirement.inventoryQuantity,
                    missingQuantity: requirement.missingQuantity,
                    unitPrice: unitPrice,
                    cashCost: ISKValue(hundredths: cash),
                    economicCost: ISKValue(hundredths: economic)
                )
            )
        }

        let cashTotal = try add(
            cashMaterialHundredths,
            manualJobCost.hundredths
        )
        let economicTotal = try add(
            economicMaterialHundredths,
            manualJobCost.hundredths
        )
        let revenue = try multiply(
            targetQuantity,
            targetUnitPrice.hundredths
        )
        let profit = try subtract(revenue, economicTotal)
        let margin = try percentage(
            numerator: profit,
            denominator: revenue
        )
        let roi = economicTotal == 0
            ? nil
            : try percentage(
                numerator: profit,
                denominator: economicTotal
            )
        let breakEvenPerUnit = try ceilingDivide(
            economicTotal,
            by: targetQuantity
        )

        return ProjectEconomicsCalculation(
            formulaVersion: Self.formulaVersion,
            targetTypeID: targetTypeID,
            targetName: normalizedName,
            targetQuantity: targetQuantity,
            targetUnitPrice: targetUnitPrice,
            materialLines: materialLines,
            cashMaterialCost: ISKValue(
                hundredths: cashMaterialHundredths
            ),
            economicMaterialCost: ISKValue(
                hundredths: economicMaterialHundredths
            ),
            manualJobCost: manualJobCost,
            cashTotalCost: ISKValue(hundredths: cashTotal),
            economicTotalCost: ISKValue(hundredths: economicTotal),
            expectedRevenue: ISKValue(hundredths: revenue),
            expectedProfit: ISKValue(hundredths: profit),
            margin: margin,
            roi: roi,
            breakEvenTotal: ISKValue(hundredths: economicTotal),
            breakEvenUnitPrice: ISKValue(
                hundredths: breakEvenPerUnit
            )
        )
    }

    private static var formulaVersion: Int {
        ProjectEconomicsCalculation.currentFormulaVersion
    }

    private func multiply(_ lhs: Int64, _ rhs: Int64) throws -> Int64 {
        let (result, overflow) = lhs.multipliedReportingOverflow(by: rhs)
        guard !overflow else {
            throw ProjectEconomicsError.arithmeticOverflow
        }
        return result
    }

    private func add(_ lhs: Int64, _ rhs: Int64) throws -> Int64 {
        let (result, overflow) = lhs.addingReportingOverflow(rhs)
        guard !overflow else {
            throw ProjectEconomicsError.arithmeticOverflow
        }
        return result
    }

    private func subtract(_ lhs: Int64, _ rhs: Int64) throws -> Int64 {
        let (result, overflow) = lhs.subtractingReportingOverflow(rhs)
        guard !overflow else {
            throw ProjectEconomicsError.arithmeticOverflow
        }
        return result
    }

    private func percentage(
        numerator: Int64,
        denominator: Int64
    ) throws -> ISKPercentage {
        guard denominator > 0 else {
            throw ProjectEconomicsError.arithmeticOverflow
        }
        let scaled = try multiply(numerator, 10_000)
        var quotient = scaled / denominator
        let remainder = scaled % denominator
        let threshold = denominator / 2 + denominator % 2
        if remainder.magnitude >= UInt64(threshold) {
            quotient = try add(quotient, scaled < 0 ? -1 : 1)
        }
        return ISKPercentage(basisPoints: quotient)
    }

    private func ceilingDivide(
        _ numerator: Int64,
        by denominator: Int64
    ) throws -> Int64 {
        guard numerator >= 0, denominator > 0 else {
            throw ProjectEconomicsError.arithmeticOverflow
        }
        let quotient = numerator / denominator
        return numerator % denominator == 0
            ? quotient
            : try add(quotient, 1)
    }
}
