import Foundation

public enum ProductionMaterialCalculationError:
    Error,
    Equatable,
    Sendable
{
    case unsupportedFormulaVersion(Int)
    case invalidBaseQuantityPerRun(Int64)
    case invalidRequiredRuns(Int64)
    case invalidMaterialEfficiency(Int)
    case materialEfficiencyUnsupportedForReaction(Int)
    case rawQuantityMultiplicationOverflow(
        baseQuantityPerRun: Int64,
        runs: Int64
    )
    case reductionNumeratorMultiplicationOverflow(
        rawQuantity: Int64,
        reductionFactor: Int64
    )
    case inconsistentPersistedValues
}

public struct ProductionMaterialCalculation:
    Equatable,
    Codable,
    Sendable
{
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let activity: ProductionTargetActivity
    public let baseQuantityPerRun: Int64
    public let requiredRuns: Int64
    public let materialEfficiency: Int
    public let rawQuantity: Int64
    public let effectiveQuantity: Int64
    public let savedQuantity: Int64

    public init(
        activity: ProductionTargetActivity,
        baseQuantityPerRun: Int64,
        requiredRuns: Int64,
        materialEfficiency: Int,
        formulaVersion: Int = Self.currentFormulaVersion
    ) throws {
        guard formulaVersion == Self.currentFormulaVersion else {
            throw ProductionMaterialCalculationError
                .unsupportedFormulaVersion(formulaVersion)
        }
        guard baseQuantityPerRun > 0 else {
            throw ProductionMaterialCalculationError
                .invalidBaseQuantityPerRun(baseQuantityPerRun)
        }
        guard requiredRuns > 0 else {
            throw ProductionMaterialCalculationError
                .invalidRequiredRuns(requiredRuns)
        }
        guard (0...10).contains(materialEfficiency) else {
            throw ProductionMaterialCalculationError
                .invalidMaterialEfficiency(materialEfficiency)
        }
        if activity == .reaction, materialEfficiency != 0 {
            throw ProductionMaterialCalculationError
                .materialEfficiencyUnsupportedForReaction(
                    materialEfficiency
                )
        }

        let raw = baseQuantityPerRun.multipliedReportingOverflow(
            by: requiredRuns
        )
        guard !raw.overflow else {
            throw ProductionMaterialCalculationError
                .rawQuantityMultiplicationOverflow(
                    baseQuantityPerRun: baseQuantityPerRun,
                    runs: requiredRuns
                )
        }

        let effectiveQuantity: Int64
        if activity == .reaction
            || materialEfficiency == 0
            || baseQuantityPerRun == 1 {
            effectiveQuantity = raw.partialValue
        } else {
            let factor = Int64(100 - materialEfficiency)
            let numerator = raw.partialValue
                .multipliedReportingOverflow(by: factor)
            guard !numerator.overflow else {
                throw ProductionMaterialCalculationError
                    .reductionNumeratorMultiplicationOverflow(
                        rawQuantity: raw.partialValue,
                        reductionFactor: factor
                    )
            }
            let quotient = numerator.partialValue / 100
            let remainder = numerator.partialValue % 100
            effectiveQuantity = quotient + (remainder == 0 ? 0 : 1)
        }

        self.formulaVersion = formulaVersion
        self.activity = activity
        self.baseQuantityPerRun = baseQuantityPerRun
        self.requiredRuns = requiredRuns
        self.materialEfficiency = materialEfficiency
        self.rawQuantity = raw.partialValue
        self.effectiveQuantity = effectiveQuantity
        self.savedQuantity = raw.partialValue - effectiveQuantity
    }

    private enum CodingKeys: String, CodingKey {
        case formulaVersion
        case activity
        case baseQuantityPerRun
        case requiredRuns
        case materialEfficiency
        case rawQuantity
        case effectiveQuantity
        case savedQuantity
    }

    public init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let expected = try Self(
            activity: container.decode(
                ProductionTargetActivity.self,
                forKey: .activity
            ),
            baseQuantityPerRun: container.decode(
                Int64.self,
                forKey: .baseQuantityPerRun
            ),
            requiredRuns: container.decode(
                Int64.self,
                forKey: .requiredRuns
            ),
            materialEfficiency: container.decode(
                Int.self,
                forKey: .materialEfficiency
            ),
            formulaVersion: container.decode(
                Int.self,
                forKey: .formulaVersion
            )
        )
        guard try container.decode(
            Int64.self,
            forKey: .rawQuantity
        ) == expected.rawQuantity,
        try container.decode(
            Int64.self,
            forKey: .effectiveQuantity
        ) == expected.effectiveQuantity,
        try container.decode(
            Int64.self,
            forKey: .savedQuantity
        ) == expected.savedQuantity else {
            throw ProductionMaterialCalculationError
                .inconsistentPersistedValues
        }
        self = expected
    }

    public func encode(to encoder: any Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(formulaVersion, forKey: .formulaVersion)
        try container.encode(activity, forKey: .activity)
        try container.encode(
            baseQuantityPerRun,
            forKey: .baseQuantityPerRun
        )
        try container.encode(requiredRuns, forKey: .requiredRuns)
        try container.encode(
            materialEfficiency,
            forKey: .materialEfficiency
        )
        try container.encode(rawQuantity, forKey: .rawQuantity)
        try container.encode(
            effectiveQuantity,
            forKey: .effectiveQuantity
        )
        try container.encode(savedQuantity, forKey: .savedQuantity)
    }
}
