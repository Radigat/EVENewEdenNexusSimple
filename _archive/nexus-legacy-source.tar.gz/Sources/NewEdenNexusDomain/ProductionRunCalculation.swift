import Foundation

public enum ProductionRunCalculationError:
    Error,
    Equatable,
    Sendable
{
    case unsupportedFormulaVersion(Int)
    case invalidRequestedOutputQuantity(Int64)
    case invalidOutputQuantityPerRun(Int64)
    case outputMultiplicationOverflow(runs: Int64, outputPerRun: Int64)
    case inconsistentPersistedValues
}

public struct ProductionRunCalculation:
    Equatable,
    Codable,
    Sendable
{
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let requestedOutputQuantity: Int64
    public let outputQuantityPerRun: Int64
    public let requiredRuns: Int64
    public let producedOutputQuantity: Int64
    public let surplusOutputQuantity: Int64

    public init(
        requestedOutputQuantity: Int64,
        outputQuantityPerRun: Int64,
        formulaVersion: Int = Self.currentFormulaVersion
    ) throws {
        guard formulaVersion == Self.currentFormulaVersion else {
            throw ProductionRunCalculationError
                .unsupportedFormulaVersion(formulaVersion)
        }
        guard requestedOutputQuantity > 0 else {
            throw ProductionRunCalculationError
                .invalidRequestedOutputQuantity(requestedOutputQuantity)
        }
        guard outputQuantityPerRun > 0 else {
            throw ProductionRunCalculationError
                .invalidOutputQuantityPerRun(outputQuantityPerRun)
        }

        let quotient = requestedOutputQuantity / outputQuantityPerRun
        let remainder = requestedOutputQuantity % outputQuantityPerRun
        let requiredRuns = quotient + (remainder == 0 ? 0 : 1)
        let product = requiredRuns.multipliedReportingOverflow(
            by: outputQuantityPerRun
        )
        guard !product.overflow else {
            throw ProductionRunCalculationError
                .outputMultiplicationOverflow(
                    runs: requiredRuns,
                    outputPerRun: outputQuantityPerRun
                )
        }

        self.formulaVersion = formulaVersion
        self.requestedOutputQuantity = requestedOutputQuantity
        self.outputQuantityPerRun = outputQuantityPerRun
        self.requiredRuns = requiredRuns
        self.producedOutputQuantity = product.partialValue
        self.surplusOutputQuantity =
            product.partialValue - requestedOutputQuantity
    }

    private enum CodingKeys: String, CodingKey {
        case formulaVersion
        case requestedOutputQuantity
        case outputQuantityPerRun
        case requiredRuns
        case producedOutputQuantity
        case surplusOutputQuantity
    }

    public init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let formulaVersion = try container.decode(
            Int.self,
            forKey: .formulaVersion
        )
        let requestedOutputQuantity = try container.decode(
            Int64.self,
            forKey: .requestedOutputQuantity
        )
        let outputQuantityPerRun = try container.decode(
            Int64.self,
            forKey: .outputQuantityPerRun
        )
        let expected = try Self(
            requestedOutputQuantity: requestedOutputQuantity,
            outputQuantityPerRun: outputQuantityPerRun,
            formulaVersion: formulaVersion
        )
        guard try container.decode(
            Int64.self,
            forKey: .requiredRuns
        ) == expected.requiredRuns,
        try container.decode(
            Int64.self,
            forKey: .producedOutputQuantity
        ) == expected.producedOutputQuantity,
        try container.decode(
            Int64.self,
            forKey: .surplusOutputQuantity
        ) == expected.surplusOutputQuantity else {
            throw ProductionRunCalculationError
                .inconsistentPersistedValues
        }
        self = expected
    }

    public func encode(to encoder: any Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(formulaVersion, forKey: .formulaVersion)
        try container.encode(
            requestedOutputQuantity,
            forKey: .requestedOutputQuantity
        )
        try container.encode(
            outputQuantityPerRun,
            forKey: .outputQuantityPerRun
        )
        try container.encode(requiredRuns, forKey: .requiredRuns)
        try container.encode(
            producedOutputQuantity,
            forKey: .producedOutputQuantity
        )
        try container.encode(
            surplusOutputQuantity,
            forKey: .surplusOutputQuantity
        )
    }
}
