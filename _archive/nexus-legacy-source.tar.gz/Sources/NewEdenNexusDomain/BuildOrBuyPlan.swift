import Foundation

public enum BuildOrBuyChoice: String, Codable, CaseIterable, Sendable {
    case build
    case buy
}

public struct BuildOrBuyDecisionSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let typeID: Int64
    public let choice: BuildOrBuyChoice
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        typeID: Int64,
        choice: BuildOrBuyChoice,
        createdAt: Date,
        updatedAt: Date
    ) {
        self.id = id
        self.projectID = projectID
        self.typeID = typeID
        self.choice = choice
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct BuildOrBuyInventionMaterial: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let quantityPerSuccessfulCopy: Int64

    public init(
        typeID: Int64,
        name: String,
        quantityPerSuccessfulCopy: Int64
    ) {
        self.typeID = typeID
        self.name = name
        self.quantityPerSuccessfulCopy = quantityPerSuccessfulCopy
    }
}

public struct BuildOrBuyProductionJob: Equatable, Sendable {
    public let nodeID: ProductionGraphNodeID
    public let typeID: Int64
    public let name: String
    public let blueprintTypeID: Int64
    public let activity: ProductionTargetActivity
    public let requestedQuantity: Int64
    public let inventoryQuantity: Int64
    public let requiredRuns: Int64
    public let producedQuantity: Int64
    public let surplusQuantity: Int64
}

public struct BuildOrBuyInventionJob: Equatable, Sendable {
    public let nodeID: ProductionGraphNodeID
    public let inventedBlueprintTypeID: Int64
    public let sourceBlueprintTypeID: Int64
    public let requiredSuccessfulCopies: Int64
    public let licensedRunsPerCopy: Int64
    public let baseProbabilityMillionths: Int
    public let materials: [BuildOrBuyInventionMaterial]
}

public enum BuildOrBuyRequirementKind:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case material
    case stockedIntermediate
    case boughtIntermediate
    case inventionMaterial
}

public struct BuildOrBuyRequirementSource: Equatable, Sendable {
    public let kind: BuildOrBuyRequirementKind
    public let nodeID: ProductionGraphNodeID
    public let quantity: Int64
}

public struct BuildOrBuyRequirementLine: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let requiredQuantity: Int64
    public let inventoryQuantity: Int64
    public let missingQuantity: Int64
    public let sources: [BuildOrBuyRequirementSource]
}

public struct BuildOrBuyPlan: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let graphID: UUID
    public let productionJobs: [BuildOrBuyProductionJob]
    public let inventionJobs: [BuildOrBuyInventionJob]
    public let requirements: [BuildOrBuyRequirementLine]
    public let activeBuyTypeIDs: [Int64]
    public let inactiveBuyTypeIDs: [Int64]
}

public enum BuildOrBuyPlanError: Error, Equatable, Sendable {
    case invalidDecisionTypeID(Int64)
    case decisionNotBuildable(Int64)
    case conflictingName(Int64)
    case missingInventionMaterials(ProductionGraphNodeID)
    case invalidInventionMaterial(typeID: Int64, quantity: Int64)
    case invalidAvailableQuantity(typeID: Int64, quantity: Int64)
    case missingNode(ProductionGraphNodeID)
    case missingRecipe(ProductionGraphNodeID)
    case missingEffectiveQuantity(ProductionGraphNodeID)
    case arithmeticOverflow(Int64)
    case runCalculation(ProductionRunCalculationError)
    case materialCalculation(ProductionMaterialCalculationError)
    case reactionCalculation(ReactionCalculationError)
    case inventionCalculation(IndustryRuleValidationError)
    case graph(ProductionGraphValidationError)
}

public struct BuildOrBuyPlanCalculator: Sendable {
    public init() {}

    public func calculate(
        graph: ProductionGraphSnapshot,
        buyTypeIDs: Set<Int64>,
        availableQuantityByTypeID: [Int64: Int64],
        inventionMaterialsByNodeID:
            [ProductionGraphNodeID: [BuildOrBuyInventionMaterial]]
    ) throws -> BuildOrBuyPlan {
        do {
            _ = try graph.validatedCopy()
        } catch let error as ProductionGraphValidationError {
            throw BuildOrBuyPlanError.graph(error)
        }
        for (typeID, quantity) in availableQuantityByTypeID
        where typeID <= 0 || quantity < 0 {
            throw BuildOrBuyPlanError.invalidAvailableQuantity(
                typeID: typeID,
                quantity: quantity
            )
        }

        let nodes = Dictionary(
            uniqueKeysWithValues: graph.nodes.map { ($0.id, $0) }
        )
        let buildableTypeIDs = Set(
            graph.nodes.filter {
                $0.kind == .intermediate && $0.recipe != nil
            }.map(\.typeID)
        )
        for typeID in buyTypeIDs {
            guard typeID > 0 else {
                throw BuildOrBuyPlanError.invalidDecisionTypeID(typeID)
            }
            guard buildableTypeIDs.contains(typeID) else {
                throw BuildOrBuyPlanError.decisionNotBuildable(typeID)
            }
        }
        var edgesByParent:
            [ProductionGraphNodeID: [ProductionGraphEdge]] = [:]
        for edge in graph.edges {
            edgesByParent[edge.parentID, default: []].append(edge)
        }
        for key in edgesByParent.keys {
            edgesByParent[key]?.sort {
                $0.sortOrder == $1.sortOrder
                    ? $0.childID.rawValue < $1.childID.rawValue
                    : $0.sortOrder < $1.sortOrder
            }
        }

        var state = State(inventory: availableQuantityByTypeID)
        guard let root = nodes[graph.rootNodeID] else {
            throw BuildOrBuyPlanError.missingNode(graph.rootNodeID)
        }
        try expand(
            node: root,
            requestedQuantity: Int64(graph.projectTargetQuantity),
            isRoot: true,
            buyTypeIDs: buyTypeIDs,
            nodes: nodes,
            edgesByParent: edgesByParent,
            inventionMaterialsByNodeID: inventionMaterialsByNodeID,
            state: &state
        )
        let active = state.activeBuyTypeIDs.sorted()
        return BuildOrBuyPlan(
            formulaVersion: BuildOrBuyPlan.currentFormulaVersion,
            graphID: graph.id,
            productionJobs: state.productionJobs.sorted {
                $0.nodeID.rawValue < $1.nodeID.rawValue
            },
            inventionJobs: state.inventionJobs.sorted {
                $0.nodeID.rawValue < $1.nodeID.rawValue
            },
            requirements: state.requirements.values.map { $0.line() }
                .sorted { $0.typeID < $1.typeID },
            activeBuyTypeIDs: active,
            inactiveBuyTypeIDs:
                buyTypeIDs.subtracting(state.activeBuyTypeIDs).sorted()
        )
    }

    private func expand(
        node: ProductionGraphNode,
        requestedQuantity: Int64,
        isRoot: Bool,
        buyTypeIDs: Set<Int64>,
        nodes: [ProductionGraphNodeID: ProductionGraphNode],
        edgesByParent: [ProductionGraphNodeID: [ProductionGraphEdge]],
        inventionMaterialsByNodeID:
            [ProductionGraphNodeID: [BuildOrBuyInventionMaterial]],
        state: inout State
    ) throws {
        let inventory = isRoot
            ? 0
            : state.consumeInventory(
                typeID: node.typeID,
                requested: requestedQuantity
            )
        let remaining = requestedQuantity - inventory

        if !isRoot, buyTypeIDs.contains(node.typeID) {
            state.activeBuyTypeIDs.insert(node.typeID)
            try state.addRequirement(
                typeID: node.typeID,
                name: node.name,
                required: requestedQuantity,
                inventory: inventory,
                missing: remaining,
                source: .init(
                    kind: .boughtIntermediate,
                    nodeID: node.id,
                    quantity: remaining
                )
            )
            return
        }

        guard node.kind != .material else {
            try state.addRequirement(
                typeID: node.typeID,
                name: node.name,
                required: requestedQuantity,
                inventory: inventory,
                missing: remaining,
                source: .init(
                    kind: .material,
                    nodeID: node.id,
                    quantity: remaining
                )
            )
            return
        }
        if !isRoot, inventory > 0 {
            try state.addRequirement(
                typeID: node.typeID,
                name: node.name,
                required: inventory,
                inventory: inventory,
                missing: 0,
                source: .init(
                    kind: .stockedIntermediate,
                    nodeID: node.id,
                    quantity: inventory
                )
            )
        }
        guard remaining > 0 else { return }
        guard let recipe = node.recipe else {
            throw BuildOrBuyPlanError.missingRecipe(node.id)
        }
        let run: ProductionRunCalculation
        do {
            run = try ProductionRunCalculation(
                requestedOutputQuantity: remaining,
                outputQuantityPerRun: recipe.outputQuantityPerRun
            )
        } catch let error as ProductionRunCalculationError {
            throw BuildOrBuyPlanError.runCalculation(error)
        }
        state.productionJobs.append(
            .init(
                nodeID: node.id,
                typeID: node.typeID,
                name: node.name,
                blueprintTypeID: recipe.blueprintTypeID,
                activity: recipe.activity,
                requestedQuantity: requestedQuantity,
                inventoryQuantity: inventory,
                requiredRuns: run.requiredRuns,
                producedQuantity: run.producedOutputQuantity,
                surplusQuantity: run.surplusOutputQuantity
            )
        )

        if let invention = recipe.invention {
            guard let materials = inventionMaterialsByNodeID[node.id] else {
                throw BuildOrBuyPlanError.missingInventionMaterials(node.id)
            }
            let copies: Int64
            do {
                copies = try IndustryRuleValidator.requiredSuccessfulCopies(
                    requiredRuns: run.requiredRuns,
                    licensedRunsPerCopy: invention.licensedRunsPerCopy
                )
            } catch let error as IndustryRuleValidationError {
                throw BuildOrBuyPlanError.inventionCalculation(error)
            }
            state.inventionJobs.append(
                .init(
                    nodeID: node.id,
                    inventedBlueprintTypeID: recipe.blueprintTypeID,
                    sourceBlueprintTypeID:
                        invention.sourceBlueprintTypeID,
                    requiredSuccessfulCopies: copies,
                    licensedRunsPerCopy: invention.licensedRunsPerCopy,
                    baseProbabilityMillionths:
                        invention.baseProbabilityMillionths,
                    materials: materials.sorted { $0.typeID < $1.typeID }
                )
            )
            for material in materials.sorted(by: { $0.typeID < $1.typeID }) {
                guard material.typeID > 0,
                      material.quantityPerSuccessfulCopy > 0 else {
                    throw BuildOrBuyPlanError.invalidInventionMaterial(
                        typeID: material.typeID,
                        quantity: material.quantityPerSuccessfulCopy
                    )
                }
                let product = material.quantityPerSuccessfulCopy
                    .multipliedReportingOverflow(by: copies)
                guard !product.overflow else {
                    throw BuildOrBuyPlanError
                        .arithmeticOverflow(material.typeID)
                }
                let used = state.consumeInventory(
                    typeID: material.typeID,
                    requested: product.partialValue
                )
                try state.addRequirement(
                    typeID: material.typeID,
                    name: material.name,
                    required: product.partialValue,
                    inventory: used,
                    missing: product.partialValue - used,
                    source: .init(
                        kind: .inventionMaterial,
                        nodeID: node.id,
                        quantity: product.partialValue - used
                    )
                )
            }
        }

        for edge in edgesByParent[node.id] ?? [] {
            guard let child = nodes[edge.childID] else {
                throw BuildOrBuyPlanError.missingNode(edge.childID)
            }
            let quantity = try effectiveQuantity(
                edge: edge,
                recipe: recipe,
                requiredRuns: run.requiredRuns
            )
            try expand(
                node: child,
                requestedQuantity: quantity,
                isRoot: false,
                buyTypeIDs: buyTypeIDs,
                nodes: nodes,
                edgesByParent: edgesByParent,
                inventionMaterialsByNodeID:
                    inventionMaterialsByNodeID,
                state: &state
            )
        }
    }

    private func effectiveQuantity(
        edge: ProductionGraphEdge,
        recipe: ProductionGraphRecipeReference,
        requiredRuns: Int64
    ) throws -> Int64 {
        if recipe.activity == .reaction {
            guard let stored = edge.reactionMaterialCalculation else {
                throw BuildOrBuyPlanError
                    .missingEffectiveQuantity(edge.childID)
            }
            let modifiers = ReactionResolvedModifiers(
                facilityTimeFactorBasisPoints: 10_000,
                skillTimeFactorBasisPoints: 10_000,
                rigTimeFactorBasisPoints: 10_000,
                rigMaterialFactorBasisPoints:
                    stored.materialFactorBasisPoints,
                securityBonusMultiplierPermille: 1_000
            )
            do {
                return try ReactionMaterialCalculation(
                    baseQuantityPerRun: edge.baseQuantityPerRun,
                    requiredRuns: requiredRuns,
                    context: stored.context,
                    modifiers: modifiers
                ).effectiveQuantity
            } catch let error as ReactionCalculationError {
                throw BuildOrBuyPlanError.reactionCalculation(error)
            }
        }
        guard let efficiency = recipe.materialEfficiency else {
            throw BuildOrBuyPlanError.missingEffectiveQuantity(edge.childID)
        }
        do {
            return try ProductionMaterialCalculation(
                activity: recipe.activity,
                baseQuantityPerRun: edge.baseQuantityPerRun,
                requiredRuns: requiredRuns,
                materialEfficiency: efficiency
            ).effectiveQuantity
        } catch let error as ProductionMaterialCalculationError {
            throw BuildOrBuyPlanError.materialCalculation(error)
        }
    }
}

private extension BuildOrBuyPlanCalculator {
    struct RequirementAccumulator {
        let typeID: Int64
        let name: String
        var required: Int64
        var inventory: Int64
        var missing: Int64
        var sources: [BuildOrBuyRequirementSource]

        func line() -> BuildOrBuyRequirementLine {
            .init(
                typeID: typeID,
                name: name,
                requiredQuantity: required,
                inventoryQuantity: inventory,
                missingQuantity: missing,
                sources: sources.sorted {
                    $0.nodeID.rawValue == $1.nodeID.rawValue
                        ? $0.kind.rawValue < $1.kind.rawValue
                        : $0.nodeID.rawValue < $1.nodeID.rawValue
                }
            )
        }
    }

    struct State {
        var inventory: [Int64: Int64]
        var productionJobs: [BuildOrBuyProductionJob] = []
        var inventionJobs: [BuildOrBuyInventionJob] = []
        var requirements: [Int64: RequirementAccumulator] = [:]
        var activeBuyTypeIDs: Set<Int64> = []

        mutating func consumeInventory(
            typeID: Int64,
            requested: Int64
        ) -> Int64 {
            let available = inventory[typeID] ?? 0
            let used = min(available, requested)
            inventory[typeID] = available - used
            return used
        }

        mutating func addRequirement(
            typeID: Int64,
            name: String,
            required: Int64,
            inventory: Int64,
            missing: Int64,
            source: BuildOrBuyRequirementSource
        ) throws {
            if var current = requirements[typeID] {
                guard current.name == name else {
                    throw BuildOrBuyPlanError.conflictingName(typeID)
                }
                current.required = try add(current.required, required, typeID)
                current.inventory = try add(
                    current.inventory,
                    inventory,
                    typeID
                )
                current.missing = try add(
                    current.missing,
                    missing,
                    typeID
                )
                current.sources.append(source)
                requirements[typeID] = current
            } else {
                requirements[typeID] = RequirementAccumulator(
                    typeID: typeID,
                    name: name,
                    required: required,
                    inventory: inventory,
                    missing: missing,
                    sources: [source]
                )
            }
        }

        private func add(
            _ lhs: Int64,
            _ rhs: Int64,
            _ typeID: Int64
        ) throws -> Int64 {
            let result = lhs.addingReportingOverflow(rhs)
            guard !result.overflow else {
                throw BuildOrBuyPlanError.arithmeticOverflow(typeID)
            }
            return result.partialValue
        }
    }
}
