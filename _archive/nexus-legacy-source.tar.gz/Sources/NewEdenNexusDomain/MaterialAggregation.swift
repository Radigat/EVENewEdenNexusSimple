import Foundation

public struct MaterialLine: Codable, Equatable, Sendable {
    public let typeID: Int
    public let name: String
    public let quantity: Int
    public let unitPrice: Double

    public init(typeID: Int, name: String, quantity: Int, unitPrice: Double) {
        self.typeID = typeID
        self.name = name
        self.quantity = quantity
        self.unitPrice = unitPrice
    }
}

public struct MaterialSummary: Codable, Equatable, Sendable {
    public let totalQuantity: Int
    public let totalCost: Double
    public let lines: [MaterialLine]

    public init(totalQuantity: Int, totalCost: Double, lines: [MaterialLine]) {
        self.totalQuantity = totalQuantity
        self.totalCost = totalCost
        self.lines = lines
    }
}

public enum MaterialAggregationError: Error, Equatable, Sendable {
    case invalidTypeID(Int)
    case emptyName(typeID: Int)
    case nonFiniteUnitPrice(typeID: Int)
}

public struct MaterialSummaryCalculator: Sendable {
    public init() {}

    public func summarize(lines: [MaterialLine]) throws -> MaterialSummary {
        var merged: [Int: MaterialLine] = [:]

        for line in lines {
            guard line.typeID > 0 else {
                throw MaterialAggregationError.invalidTypeID(line.typeID)
            }
            guard !line.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw MaterialAggregationError.emptyName(typeID: line.typeID)
            }
            guard line.unitPrice.isFinite else {
                throw MaterialAggregationError.nonFiniteUnitPrice(typeID: line.typeID)
            }

            let normalizedQuantity = max(0, line.quantity)
            if let existing = merged[line.typeID] {
                merged[line.typeID] = MaterialLine(
                    typeID: existing.typeID,
                    name: existing.name,
                    quantity: existing.quantity + normalizedQuantity,
                    unitPrice: existing.unitPrice
                )
            } else {
                merged[line.typeID] = MaterialLine(
                    typeID: line.typeID,
                    name: line.name,
                    quantity: normalizedQuantity,
                    unitPrice: line.unitPrice
                )
            }
        }

        let sortedMergedLines = merged.values.sorted { lhs, rhs in
            let leftName = Self.sortKey(lhs.name)
            let rightName = Self.sortKey(rhs.name)
            return leftName == rightName ? lhs.typeID < rhs.typeID : leftName < rightName
        }

        let totalQuantity = sortedMergedLines.reduce(0) { $0 + $1.quantity }
        let totalCost = sortedMergedLines.reduce(Decimal.zero) { partialResult, line in
            partialResult + Decimal(line.quantity) * Self.decimal(line.unitPrice)
        }
        let outputLines = sortedMergedLines.map { line in
            MaterialLine(
                typeID: line.typeID,
                name: line.name,
                quantity: line.quantity,
                unitPrice: Self.roundCurrency(line.unitPrice)
            )
        }

        return MaterialSummary(
            totalQuantity: totalQuantity,
            totalCost: Self.double(Self.roundCurrency(totalCost)),
            lines: outputLines
        )
    }

    private static func sortKey(_ value: String) -> String {
        value.folding(
            options: [.caseInsensitive],
            locale: Locale(identifier: "en_US_POSIX")
        )
    }

    private static func decimal(_ value: Double) -> Decimal {
        Decimal(value)
    }

    private static func roundCurrency(_ value: Double) -> Double {
        double(roundCurrency(decimal(value)))
    }

    private static func roundCurrency(_ value: Decimal) -> Decimal {
        var source = value
        var result = Decimal.zero
        NSDecimalRound(&result, &source, 2, .plain)
        return result
    }

    private static func double(_ value: Decimal) -> Double {
        Double(NSDecimalNumber(decimal: value).stringValue) ?? .zero
    }
}
