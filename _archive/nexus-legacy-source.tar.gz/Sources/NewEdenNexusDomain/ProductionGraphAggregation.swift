import Foundation

public struct ProductionGraphMaterialOccurrence:
    Equatable,
    Codable,
    Sendable
{
    public let leafNodeID: ProductionGraphNodeID
    public let quantity: Int64
    public let path: [ProductionGraphNodeID]
    public let leafReason: ProductionGraphLeafReason

    public init(
        leafNodeID: ProductionGraphNodeID,
        quantity: Int64,
        path: [ProductionGraphNodeID],
        leafReason: ProductionGraphLeafReason
    ) {
        self.leafNodeID = leafNodeID
        self.quantity = quantity
        self.path = path
        self.leafReason = leafReason
    }
}

public struct ProductionGraphMaterialLine:
    Equatable,
    Codable,
    Sendable
{
    public let typeID: Int64
    public let name: String
    public let totalQuantity: Int64
    public let occurrences: [ProductionGraphMaterialOccurrence]

    public init(
        typeID: Int64,
        name: String,
        totalQuantity: Int64,
        occurrences: [ProductionGraphMaterialOccurrence]
    ) {
        self.typeID = typeID
        self.name = name
        self.totalQuantity = totalQuantity
        self.occurrences = occurrences
    }
}

public struct ProductionGraphMaterialAggregation:
    Equatable,
    Codable,
    Sendable
{
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let lines: [ProductionGraphMaterialLine]

    public var materialTypeCount: Int {
        lines.count
    }

    public var occurrenceCount: Int {
        lines.reduce(0) { $0 + $1.occurrences.count }
    }

    public init(
        formulaVersion: Int = Self.currentFormulaVersion,
        lines: [ProductionGraphMaterialLine]
    ) {
        self.formulaVersion = formulaVersion
        self.lines = lines
    }
}

public enum ProductionGraphMaterialAggregationError:
    Error,
    Equatable,
    Sendable
{
    case duplicateNodeID(ProductionGraphNodeID)
    case missingRoot(ProductionGraphNodeID)
    case missingEdgeEndpoint(ProductionGraphNodeID)
    case missingIncomingEdge(ProductionGraphNodeID)
    case duplicateIncomingEdge(ProductionGraphNodeID)
    case cycleDetected([ProductionGraphNodeID])
    case incompletePath(ProductionGraphNodeID)
    case missingLeafReason(ProductionGraphNodeID)
    case missingEffectiveQuantity(ProductionGraphNodeID)
    case invalidEffectiveQuantity(ProductionGraphNodeID, Int64)
    case conflictingName(
        typeID: Int64,
        expected: String,
        actual: String
    )
    case quantityOverflow(
        typeID: Int64,
        leafNodeID: ProductionGraphNodeID
    )
}

public struct ProductionGraphMaterialAggregator: Sendable {
    public init() {}

    public func aggregate(
        rootNodeID: ProductionGraphNodeID,
        nodes: [ProductionGraphNode],
        edges: [ProductionGraphEdge]
    ) throws -> ProductionGraphMaterialAggregation {
        var nodesByID: [
            ProductionGraphNodeID: ProductionGraphNode
        ] = [:]
        for node in nodes {
            guard nodesByID[node.id] == nil else {
                throw ProductionGraphMaterialAggregationError
                    .duplicateNodeID(node.id)
            }
            nodesByID[node.id] = node
        }
        guard nodesByID[rootNodeID] != nil else {
            throw ProductionGraphMaterialAggregationError
                .missingRoot(rootNodeID)
        }

        var incomingByChild: [
            ProductionGraphNodeID: ProductionGraphEdge
        ] = [:]
        for edge in edges {
            guard nodesByID[edge.parentID] != nil else {
                throw ProductionGraphMaterialAggregationError
                    .missingEdgeEndpoint(edge.parentID)
            }
            guard nodesByID[edge.childID] != nil else {
                throw ProductionGraphMaterialAggregationError
                    .missingEdgeEndpoint(edge.childID)
            }
            guard incomingByChild[edge.childID] == nil else {
                throw ProductionGraphMaterialAggregationError
                    .duplicateIncomingEdge(edge.childID)
            }
            incomingByChild[edge.childID] = edge
        }

        struct Accumulator {
            let typeID: Int64
            let name: String
            let normalizedName: String
            var totalQuantity: Int64
            var occurrences: [ProductionGraphMaterialOccurrence]
        }

        var accumulators: [Int64: Accumulator] = [:]
        let leaves = nodes
            .filter { $0.kind == .material }
            .sorted { $0.id.rawValue < $1.id.rawValue }

        for leaf in leaves {
            guard let leafReason = leaf.leafReason else {
                throw ProductionGraphMaterialAggregationError
                    .missingLeafReason(leaf.id)
            }
            guard let incoming = incomingByChild[leaf.id] else {
                throw ProductionGraphMaterialAggregationError
                    .missingIncomingEdge(leaf.id)
            }
            guard let quantity =
                    incoming.reactionMaterialCalculation?
                        .effectiveQuantity
                    ?? incoming.materialCalculation?.effectiveQuantity
            else {
                throw ProductionGraphMaterialAggregationError
                    .missingEffectiveQuantity(leaf.id)
            }
            guard quantity > 0 else {
                throw ProductionGraphMaterialAggregationError
                    .invalidEffectiveQuantity(leaf.id, quantity)
            }

            let path = try path(
                from: leaf.id,
                to: rootNodeID,
                incomingByChild: incomingByChild
            )
            let occurrence = ProductionGraphMaterialOccurrence(
                leafNodeID: leaf.id,
                quantity: quantity,
                path: path,
                leafReason: leafReason
            )
            let name = leaf.name.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            let normalizedName = Self.normalizedName(name)

            if var existing = accumulators[leaf.typeID] {
                guard existing.normalizedName == normalizedName else {
                    throw ProductionGraphMaterialAggregationError
                        .conflictingName(
                            typeID: leaf.typeID,
                            expected: existing.name,
                            actual: name
                        )
                }
                let sum = existing.totalQuantity
                    .addingReportingOverflow(quantity)
                guard !sum.overflow else {
                    throw ProductionGraphMaterialAggregationError
                        .quantityOverflow(
                            typeID: leaf.typeID,
                            leafNodeID: leaf.id
                        )
                }
                existing.totalQuantity = sum.partialValue
                existing.occurrences.append(occurrence)
                accumulators[leaf.typeID] = existing
            } else {
                accumulators[leaf.typeID] = Accumulator(
                    typeID: leaf.typeID,
                    name: name,
                    normalizedName: normalizedName,
                    totalQuantity: quantity,
                    occurrences: [occurrence]
                )
            }
        }

        let lines = accumulators.values.map { accumulator in
            ProductionGraphMaterialLine(
                typeID: accumulator.typeID,
                name: accumulator.name,
                totalQuantity: accumulator.totalQuantity,
                occurrences: accumulator.occurrences.sorted {
                    $0.leafNodeID.rawValue < $1.leafNodeID.rawValue
                }
            )
        }.sorted { lhs, rhs in
            let leftName = Self.normalizedName(lhs.name)
            let rightName = Self.normalizedName(rhs.name)
            if leftName != rightName {
                return leftName < rightName
            }
            return lhs.typeID < rhs.typeID
        }

        return ProductionGraphMaterialAggregation(lines: lines)
    }

    private func path(
        from leafNodeID: ProductionGraphNodeID,
        to rootNodeID: ProductionGraphNodeID,
        incomingByChild: [
            ProductionGraphNodeID: ProductionGraphEdge
        ]
    ) throws -> [ProductionGraphNodeID] {
        var reversedPath: [ProductionGraphNodeID] = []
        var visited: Set<ProductionGraphNodeID> = []
        var current = leafNodeID

        while true {
            guard visited.insert(current).inserted else {
                throw ProductionGraphMaterialAggregationError
                    .cycleDetected(reversedPath + [current])
            }
            reversedPath.append(current)
            if current == rootNodeID {
                return reversedPath.reversed()
            }
            guard let edge = incomingByChild[current] else {
                throw ProductionGraphMaterialAggregationError
                    .incompletePath(leafNodeID)
            }
            current = edge.parentID
        }
    }

    private static func normalizedName(_ value: String) -> String {
        value.precomposedStringWithCanonicalMapping.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "en_US_POSIX")
        )
    }
}
