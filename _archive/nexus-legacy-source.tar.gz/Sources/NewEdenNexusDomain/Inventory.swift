import Foundation

public enum StorageLocationKind: String, Codable, CaseIterable, Sendable {
    case main
    case production
    case trade
    case intermediate
    case reaction
    case capitalProduction
    case sales
    case other
}

public enum InventoryValidationError: Error, Equatable, Sendable {
    case emptyLocationName
    case updatedBeforeCreation
    case invalidTypeID(Int64)
    case emptyItemName
    case invalidQuantity(Int64)
    case invalidCatalogBuildNumber(Int)
    case emptyCatalogContentSHA256
}

public struct StorageLocationSnapshot: Identifiable, Equatable, Sendable {
    public let id: UUID
    public let name: String
    public let kind: StorageLocationKind
    public let notes: String
    public let isArchived: Bool
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        name: String,
        kind: StorageLocationKind,
        notes: String,
        isArchived: Bool,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        let normalizedName = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !normalizedName.isEmpty else {
            throw InventoryValidationError.emptyLocationName
        }
        guard createdAt <= updatedAt else {
            throw InventoryValidationError.updatedBeforeCreation
        }
        self.id = id
        self.name = normalizedName
        self.kind = kind
        self.notes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        self.isArchived = isArchived
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct ManualStockSnapshot: Identifiable, Equatable, Sendable {
    public let id: UUID
    public let locationID: UUID
    public let typeID: Int64
    public let itemName: String
    public let quantity: Int64
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        locationID: UUID,
        typeID: Int64,
        itemName: String,
        quantity: Int64,
        catalogBuildNumber: Int,
        catalogContentSHA256: String,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        let normalizedName = itemName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let normalizedHash = catalogContentSHA256.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard typeID > 0 else {
            throw InventoryValidationError.invalidTypeID(typeID)
        }
        guard !normalizedName.isEmpty else {
            throw InventoryValidationError.emptyItemName
        }
        guard quantity > 0 else {
            throw InventoryValidationError.invalidQuantity(quantity)
        }
        guard catalogBuildNumber > 0 else {
            throw InventoryValidationError.invalidCatalogBuildNumber(
                catalogBuildNumber
            )
        }
        guard !normalizedHash.isEmpty else {
            throw InventoryValidationError.emptyCatalogContentSHA256
        }
        guard createdAt <= updatedAt else {
            throw InventoryValidationError.updatedBeforeCreation
        }
        self.id = id
        self.locationID = locationID
        self.typeID = typeID
        self.itemName = normalizedName
        self.quantity = quantity
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = normalizedHash
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}
