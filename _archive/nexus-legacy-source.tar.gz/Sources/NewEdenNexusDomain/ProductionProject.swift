import Foundation

public enum ProjectStatus: String, Codable, CaseIterable, Sendable {
    case planning = "Planung"
    case procurement = "Beschaffung"
    case ready = "Produktionsbereit"
    case active = "In Produktion"
    case completed = "Abgeschlossen"
    case archived = "Archiviert"
}

public enum ProductionTargetActivity: String, Codable, CaseIterable, Sendable {
    case manufacturing
    case reaction
}

public enum ProductionTargetSelectionValidationError:
    Error,
    Equatable,
    Sendable
{
    case invalidProductTypeID(Int64)
    case emptyProductName
    case invalidBlueprintTypeID(Int64)
    case invalidCatalogBuildNumber(Int)
    case emptyCatalogContentSHA256
}

public struct ProductionTargetSelection: Equatable, Sendable {
    public let productTypeID: Int64
    public let productName: String
    public let activity: ProductionTargetActivity
    public let blueprintTypeID: Int64
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String

    public init(
        productTypeID: Int64,
        productName: String,
        activity: ProductionTargetActivity,
        blueprintTypeID: Int64,
        catalogBuildNumber: Int,
        catalogContentSHA256: String
    ) throws {
        let normalizedName = productName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let normalizedHash = catalogContentSHA256.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard productTypeID > 0 else {
            throw ProductionTargetSelectionValidationError
                .invalidProductTypeID(productTypeID)
        }
        guard !normalizedName.isEmpty else {
            throw ProductionTargetSelectionValidationError.emptyProductName
        }
        guard blueprintTypeID > 0 else {
            throw ProductionTargetSelectionValidationError
                .invalidBlueprintTypeID(blueprintTypeID)
        }
        guard catalogBuildNumber > 0 else {
            throw ProductionTargetSelectionValidationError
                .invalidCatalogBuildNumber(catalogBuildNumber)
        }
        guard !normalizedHash.isEmpty else {
            throw ProductionTargetSelectionValidationError
                .emptyCatalogContentSHA256
        }

        self.productTypeID = productTypeID
        self.productName = normalizedName
        self.activity = activity
        self.blueprintTypeID = blueprintTypeID
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = normalizedHash
    }
}

public enum ProductionProjectValidationError: Error, Equatable, Sendable {
    case emptyName
    case emptyProductName
    case invalidTargetQuantity(Int)
    case invalidPriority(Int)
    case updatedBeforeCreation
    case productNameDoesNotMatchTarget
    case invalidMaterialEfficiency(Int)
    case materialEfficiencyUnsupportedForReaction(Int)
}

public struct ProductionProjectSnapshot: Identifiable, Equatable, Sendable {
    public let id: UUID
    public let name: String
    public let productName: String
    public let targetQuantity: Int
    public let status: ProjectStatus
    public let priority: Int
    public let targetDate: Date?
    public let notes: String
    public let createdAt: Date
    public let updatedAt: Date
    public let target: ProductionTargetSelection?
    public let materialEfficiency: Int

    public init(
        id: UUID,
        name: String,
        productName: String,
        targetQuantity: Int,
        status: ProjectStatus,
        priority: Int,
        targetDate: Date?,
        notes: String,
        createdAt: Date,
        updatedAt: Date,
        target: ProductionTargetSelection? = nil,
        materialEfficiency: Int = 0
    ) throws {
        let normalizedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedProductName = productName.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !normalizedName.isEmpty else {
            throw ProductionProjectValidationError.emptyName
        }
        guard !normalizedProductName.isEmpty else {
            throw ProductionProjectValidationError.emptyProductName
        }
        guard targetQuantity > 0 else {
            throw ProductionProjectValidationError.invalidTargetQuantity(targetQuantity)
        }
        guard (1...3).contains(priority) else {
            throw ProductionProjectValidationError.invalidPriority(priority)
        }
        guard createdAt <= updatedAt else {
            throw ProductionProjectValidationError.updatedBeforeCreation
        }
        if let target, normalizedProductName != target.productName {
            throw ProductionProjectValidationError
                .productNameDoesNotMatchTarget
        }
        guard (0...10).contains(materialEfficiency) else {
            throw ProductionProjectValidationError
                .invalidMaterialEfficiency(materialEfficiency)
        }
        if target?.activity == .reaction, materialEfficiency != 0 {
            throw ProductionProjectValidationError
                .materialEfficiencyUnsupportedForReaction(
                    materialEfficiency
                )
        }

        self.id = id
        self.name = normalizedName
        self.productName = normalizedProductName
        self.targetQuantity = targetQuantity
        self.status = status
        self.priority = priority
        self.targetDate = targetDate
        self.notes = notes
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.target = target
        self.materialEfficiency = materialEfficiency
    }
}
