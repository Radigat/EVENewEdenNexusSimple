import Foundation

public enum StockReservationStatus:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case reserved
    case partiallyConsumed
    case consumed
    case released

    public var isBinding: Bool {
        self == .reserved || self == .partiallyConsumed
    }
}

public enum StockReservationValidationError:
    Error,
    Equatable,
    Sendable
{
    case invalidTypeID(Int64)
    case invalidReservedQuantity(Int64)
    case invalidConsumedQuantity(Int64)
    case invalidPriority(Int)
    case expiresBeforeCreation
    case updatedBeforeCreation
    case invalidStatus
}

public struct StockReservationSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let typeID: Int64
    public let reservedQuantity: Int64
    public let consumedQuantity: Int64
    public let priority: Int
    public let expiresAt: Date?
    public let status: StockReservationStatus
    public let createdAt: Date
    public let updatedAt: Date
    public let releasedAt: Date?
    public let consumedAt: Date?

    public init(
        id: UUID,
        projectID: UUID,
        typeID: Int64,
        reservedQuantity: Int64,
        consumedQuantity: Int64,
        priority: Int,
        expiresAt: Date?,
        status: StockReservationStatus,
        createdAt: Date,
        updatedAt: Date,
        releasedAt: Date?,
        consumedAt: Date?
    ) throws {
        guard typeID > 0 else {
            throw StockReservationValidationError.invalidTypeID(typeID)
        }
        guard reservedQuantity > 0 else {
            throw StockReservationValidationError
                .invalidReservedQuantity(reservedQuantity)
        }
        guard consumedQuantity >= 0,
              consumedQuantity <= reservedQuantity else {
            throw StockReservationValidationError
                .invalidConsumedQuantity(consumedQuantity)
        }
        guard (1...3).contains(priority) else {
            throw StockReservationValidationError.invalidPriority(priority)
        }
        if let expiresAt, expiresAt < createdAt {
            throw StockReservationValidationError.expiresBeforeCreation
        }
        guard createdAt <= updatedAt else {
            throw StockReservationValidationError.updatedBeforeCreation
        }
        guard Self.isConsistent(
            status: status,
            reservedQuantity: reservedQuantity,
            consumedQuantity: consumedQuantity,
            releasedAt: releasedAt,
            consumedAt: consumedAt
        ) else {
            throw StockReservationValidationError.invalidStatus
        }

        self.id = id
        self.projectID = projectID
        self.typeID = typeID
        self.reservedQuantity = reservedQuantity
        self.consumedQuantity = consumedQuantity
        self.priority = priority
        self.expiresAt = expiresAt
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.releasedAt = releasedAt
        self.consumedAt = consumedAt
    }

    public var remainingQuantity: Int64 {
        status.isBinding ? reservedQuantity - consumedQuantity : 0
    }

    public func isExpired(at date: Date) -> Bool {
        status.isBinding && expiresAt.map { $0 <= date } == true
    }

    private static func isConsistent(
        status: StockReservationStatus,
        reservedQuantity: Int64,
        consumedQuantity: Int64,
        releasedAt: Date?,
        consumedAt: Date?
    ) -> Bool {
        switch status {
        case .reserved:
            consumedQuantity == 0
                && releasedAt == nil
                && consumedAt == nil
        case .partiallyConsumed:
            consumedQuantity > 0
                && consumedQuantity < reservedQuantity
                && releasedAt == nil
                && consumedAt == nil
        case .consumed:
            consumedQuantity == reservedQuantity
                && releasedAt == nil
                && consumedAt != nil
        case .released:
            consumedQuantity < reservedQuantity
                && releasedAt != nil
                && consumedAt == nil
        }
    }
}

public struct ProjectReservationLine: Equatable, Sendable {
    public let safetyStock: SafetyStockLine
    public let otherProjectsReservedQuantity: Int64
    public let currentProjectReservedQuantity: Int64
    public let freeBeforeCurrentProjectQuantity: Int64
    public let maximumReservableQuantity: Int64
    public let freeAfterCurrentProjectQuantity: Int64
    public let unreservedRequirementQuantity: Int64
    public let currentReservation: StockReservationSnapshot?
    public let isCurrentReservationExpired: Bool
}

public struct ProjectReservationCalculation: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let lines: [ProjectReservationLine]

    public init(
        formulaVersion: Int = Self.currentFormulaVersion,
        lines: [ProjectReservationLine]
    ) {
        self.formulaVersion = formulaVersion
        self.lines = lines
    }

    public var reservedMaterialCount: Int {
        lines.filter { $0.currentProjectReservedQuantity > 0 }.count
    }

    public var fullyReservedMaterialCount: Int {
        lines.filter { $0.unreservedRequirementQuantity == 0 }.count
    }

    public var expiredReservationCount: Int {
        lines.filter(\.isCurrentReservationExpired).count
    }
}

public enum ProjectReservationCalculationError:
    Error,
    Equatable,
    Sendable
{
    case duplicateSafetyStockTypeID(Int64)
    case duplicateActiveReservation(projectID: UUID, typeID: Int64)
    case unknownReservationTypeID(Int64)
    case reservationSumOverflow(Int64)
    case invalidSafetyStockLine(Int64)
}

public struct ProjectReservationCalculator: Sendable {
    public init() {}

    public func calculate(
        projectID: UUID,
        safetyStock: SafetyStockCalculation,
        reservations: [StockReservationSnapshot],
        at date: Date
    ) throws -> ProjectReservationCalculation {
        var linesByTypeID: [Int64: SafetyStockLine] = [:]
        for line in safetyStock.lines {
            let typeID = line.availability.typeID
            guard typeID > 0,
                  line.availability.requiredQuantity > 0,
                  line.availableAfterSafetyStockQuantity >= 0 else {
                throw ProjectReservationCalculationError
                    .invalidSafetyStockLine(typeID)
            }
            guard linesByTypeID[typeID] == nil else {
                throw ProjectReservationCalculationError
                    .duplicateSafetyStockTypeID(typeID)
            }
            linesByTypeID[typeID] = line
        }

        var activeByProjectAndType:
            [ReservationKey: StockReservationSnapshot] = [:]
        for reservation in reservations where reservation.status.isBinding {
            guard linesByTypeID[reservation.typeID] != nil else {
                throw ProjectReservationCalculationError
                    .unknownReservationTypeID(reservation.typeID)
            }
            let key = ReservationKey(
                projectID: reservation.projectID,
                typeID: reservation.typeID
            )
            guard activeByProjectAndType[key] == nil else {
                throw ProjectReservationCalculationError
                    .duplicateActiveReservation(
                        projectID: reservation.projectID,
                        typeID: reservation.typeID
                    )
            }
            activeByProjectAndType[key] = reservation
        }

        let result = try linesByTypeID.values.map { line in
            let typeID = line.availability.typeID
            var otherReserved: Int64 = 0
            var current: StockReservationSnapshot?
            for reservation in activeByProjectAndType.values
            where reservation.typeID == typeID {
                if reservation.projectID == projectID {
                    current = reservation
                } else {
                    let addition = otherReserved.addingReportingOverflow(
                        reservation.remainingQuantity
                    )
                    guard !addition.overflow else {
                        throw ProjectReservationCalculationError
                            .reservationSumOverflow(typeID)
                    }
                    otherReserved = addition.partialValue
                }
            }
            let available = line.availableAfterSafetyStockQuantity
            let freeBefore = otherReserved >= available
                ? 0
                : available - otherReserved
            let maximum = min(
                line.availability.requiredQuantity,
                freeBefore
            )
            let currentQuantity = current?.remainingQuantity ?? 0
            let freeAfter = currentQuantity >= freeBefore
                ? 0
                : freeBefore - currentQuantity
            let unreserved = currentQuantity
                >= line.availability.requiredQuantity
                ? 0
                : line.availability.requiredQuantity - currentQuantity
            return ProjectReservationLine(
                safetyStock: line,
                otherProjectsReservedQuantity: otherReserved,
                currentProjectReservedQuantity: currentQuantity,
                freeBeforeCurrentProjectQuantity: freeBefore,
                maximumReservableQuantity: maximum,
                freeAfterCurrentProjectQuantity: freeAfter,
                unreservedRequirementQuantity: unreserved,
                currentReservation: current,
                isCurrentReservationExpired:
                    current?.isExpired(at: date) ?? false
            )
        }.sorted {
            let left = normalizedName($0.safetyStock.availability.name)
            let right = normalizedName($1.safetyStock.availability.name)
            return left == right
                ? $0.safetyStock.availability.typeID
                    < $1.safetyStock.availability.typeID
                : left < right
        }
        return ProjectReservationCalculation(lines: result)
    }

    private func normalizedName(_ name: String) -> String {
        name.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "en_US_POSIX")
        )
    }
}

private struct ReservationKey: Hashable {
    let projectID: UUID
    let typeID: Int64
}
