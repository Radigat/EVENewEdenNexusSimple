import Foundation

public enum WalletAssignmentSourceKind:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case transaction
    case journal
}

public enum WalletAssignmentDirection:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case cost
    case revenue
}

public struct WalletProjectAssignmentSnapshot:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let characterID: Int64
    public let sourceKind: WalletAssignmentSourceKind
    public let sourceID: Int64
    public let direction: WalletAssignmentDirection
    public let assignedQuantity: Int64
    public let assignedAmountHundredths: Int64
    public let sourceRevision: UUID
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        characterID: Int64,
        sourceKind: WalletAssignmentSourceKind,
        sourceID: Int64,
        direction: WalletAssignmentDirection,
        assignedQuantity: Int64,
        assignedAmountHundredths: Int64,
        sourceRevision: UUID,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard characterID > 0,
              sourceID > 0,
              assignedQuantity >= 0,
              assignedAmountHundredths > 0,
              (sourceKind == .transaction
                ? assignedQuantity > 0
                : assignedQuantity == 0),
              createdAt <= updatedAt else {
            throw WalletFinanceError.invalidAssignment
        }
        self.id = id
        self.projectID = projectID
        self.characterID = characterID
        self.sourceKind = sourceKind
        self.sourceID = sourceID
        self.direction = direction
        self.assignedQuantity = assignedQuantity
        self.assignedAmountHundredths = assignedAmountHundredths
        self.sourceRevision = sourceRevision
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct WalletProjectActuals: Equatable, Sendable {
    public let projectID: UUID
    public let costHundredths: Int64
    public let revenueHundredths: Int64
    public let profitHundredths: Int64
    public let assignmentCount: Int
}

public enum WalletFinanceError: Error, Equatable, Sendable {
    case invalidMoney
    case moneyOverflow
    case invalidAssignment
    case duplicateAssignment(UUID)
    case allocationExceeded
}

public enum WalletMoneyNormalizer {
    public static func hundredths(
        from value: Decimal,
        allowsNegative: Bool
    ) throws -> Int64 {
        guard value.isFinite,
              allowsNegative || value >= 0 else {
            throw WalletFinanceError.invalidMoney
        }
        var source = value
        var rounded = Decimal()
        NSDecimalRound(&rounded, &source, 2, .plain)
        let scaled = rounded * 100
        let number = NSDecimalNumber(decimal: scaled)
        guard number != .notANumber else {
            throw WalletFinanceError.invalidMoney
        }
        let result = number.int64Value
        guard NSDecimalNumber(value: result).compare(number)
                == .orderedSame else {
            throw WalletFinanceError.moneyOverflow
        }
        return result
    }

    public static func multiplied(
        unitHundredths: Int64,
        quantity: Int64
    ) throws -> Int64 {
        guard unitHundredths >= 0, quantity >= 0 else {
            throw WalletFinanceError.invalidMoney
        }
        let (result, overflow) =
            unitHundredths.multipliedReportingOverflow(by: quantity)
        guard !overflow else {
            throw WalletFinanceError.moneyOverflow
        }
        return result
    }
}

public struct WalletProjectActualsCalculator: Sendable {
    public init() {}

    public func calculate(
        projectID: UUID,
        assignments: [WalletProjectAssignmentSnapshot]
    ) throws -> WalletProjectActuals {
        let relevant = assignments.filter { $0.projectID == projectID }
        guard Set(relevant.map(\.id)).count == relevant.count else {
            throw WalletFinanceError.duplicateAssignment(
                relevant.first?.id ?? UUID()
            )
        }
        var costs: Int64 = 0
        var revenue: Int64 = 0
        for assignment in relevant {
            switch assignment.direction {
            case .cost:
                let result = costs.addingReportingOverflow(
                    assignment.assignedAmountHundredths
                )
                guard !result.overflow else {
                    throw WalletFinanceError.moneyOverflow
                }
                costs = result.partialValue
            case .revenue:
                let result = revenue.addingReportingOverflow(
                    assignment.assignedAmountHundredths
                )
                guard !result.overflow else {
                    throw WalletFinanceError.moneyOverflow
                }
                revenue = result.partialValue
            }
        }
        let profit = revenue.subtractingReportingOverflow(costs)
        guard !profit.overflow else {
            throw WalletFinanceError.moneyOverflow
        }
        return WalletProjectActuals(
            projectID: projectID,
            costHundredths: costs,
            revenueHundredths: revenue,
            profitHundredths: profit.partialValue,
            assignmentCount: relevant.count
        )
    }
}

private extension Decimal {
    var isFinite: Bool {
        self != Decimal.nan
    }
}
