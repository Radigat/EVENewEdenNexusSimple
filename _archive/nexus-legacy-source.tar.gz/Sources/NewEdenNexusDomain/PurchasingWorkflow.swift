import Foundation

public struct ProjectPurchaseAllocation: Equatable, Sendable {
    public let projectID: UUID
    public let projectName: String
    public let typeID: Int64
    public let itemName: String
    public let targetQuantity: Int64
    public let recordedPurchasedQuantity: Int64

    public init(
        projectID: UUID,
        projectName: String,
        typeID: Int64,
        itemName: String,
        targetQuantity: Int64,
        recordedPurchasedQuantity: Int64
    ) {
        self.projectID = projectID
        self.projectName = projectName
        self.typeID = typeID
        self.itemName = itemName
        self.targetQuantity = targetQuantity
        self.recordedPurchasedQuantity = recordedPurchasedQuantity
    }
}

public struct ProjectPurchaseSource: Equatable, Sendable {
    public let projectID: UUID
    public let projectName: String
    public let targetQuantity: Int64
    public let recordedPurchasedQuantity: Int64
    public let creditedPurchasedQuantity: Int64
    public let remainingQuantity: Int64

    public var isPurchased: Bool {
        remainingQuantity == 0
    }

    public var hasExcessProgress: Bool {
        recordedPurchasedQuantity > targetQuantity
    }
}

public struct PurchasingWorkflowPosition: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let targetQuantity: Int64
    public let purchasedQuantity: Int64
    public let remainingQuantity: Int64
    public let sources: [ProjectPurchaseSource]

    public var isPurchased: Bool {
        remainingQuantity == 0
    }
}

public struct PurchasingWorkflowAggregation: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let positions: [PurchasingWorkflowPosition]
    public let openPositionCount: Int
    public let totalRemainingQuantity: Int64

    public var openPositions: [PurchasingWorkflowPosition] {
        positions.filter { $0.remainingQuantity > 0 }
    }

    public var textList: String {
        openPositions.map {
            "\($0.name)\t\($0.remainingQuantity)"
        }.joined(separator: "\n")
    }

    public var csv: String {
        let header =
            "type_id,item_name,target_quantity,purchased_quantity,remaining_quantity,project_count"
        let rows = openPositions.map { position in
            [
                String(position.typeID),
                Self.csvField(position.name),
                String(position.targetQuantity),
                String(position.purchasedQuantity),
                String(position.remainingQuantity),
                String(position.sources.count)
            ].joined(separator: ",")
        }
        return ([header] + rows).joined(separator: "\r\n") + "\r\n"
    }

    private static func csvField(_ value: String) -> String {
        guard value.contains(",")
                || value.contains("\"")
                || value.contains("\r")
                || value.contains("\n") else {
            return value
        }
        return "\"\(value.replacingOccurrences(of: "\"", with: "\"\""))\""
    }
}

public enum PurchasingWorkflowAggregationError:
    Error,
    Equatable,
    Sendable
{
    case invalidAllocation(projectID: UUID, typeID: Int64)
    case duplicateAllocation(projectID: UUID, typeID: Int64)
    case conflictingName(typeID: Int64)
    case arithmeticOverflow(typeID: Int64)
}

public struct PurchasingWorkflowAggregator: Sendable {
    public init() {}

    public func aggregate(
        _ allocations: [ProjectPurchaseAllocation]
    ) throws -> PurchasingWorkflowAggregation {
        var seen: Set<AllocationKey> = []
        var accumulated: [Int64: Accumulator] = [:]

        for allocation in allocations {
            let projectName = allocation.projectName.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            let itemName = allocation.itemName.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            guard allocation.typeID > 0,
                  !projectName.isEmpty,
                  !itemName.isEmpty,
                  allocation.targetQuantity > 0,
                  allocation.recordedPurchasedQuantity >= 0 else {
                throw PurchasingWorkflowAggregationError.invalidAllocation(
                    projectID: allocation.projectID,
                    typeID: allocation.typeID
                )
            }
            let key = AllocationKey(
                projectID: allocation.projectID,
                typeID: allocation.typeID
            )
            guard seen.insert(key).inserted else {
                throw PurchasingWorkflowAggregationError
                    .duplicateAllocation(
                        projectID: allocation.projectID,
                        typeID: allocation.typeID
                    )
            }
            let credited = min(
                allocation.targetQuantity,
                allocation.recordedPurchasedQuantity
            )
            let source = ProjectPurchaseSource(
                projectID: allocation.projectID,
                projectName: projectName,
                targetQuantity: allocation.targetQuantity,
                recordedPurchasedQuantity:
                    allocation.recordedPurchasedQuantity,
                creditedPurchasedQuantity: credited,
                remainingQuantity: allocation.targetQuantity - credited
            )

            if var current = accumulated[allocation.typeID] {
                guard current.name == itemName else {
                    throw PurchasingWorkflowAggregationError
                        .conflictingName(typeID: allocation.typeID)
                }
                current.targetQuantity = try checkedSum(
                    current.targetQuantity,
                    allocation.targetQuantity,
                    typeID: allocation.typeID
                )
                current.purchasedQuantity = try checkedSum(
                    current.purchasedQuantity,
                    credited,
                    typeID: allocation.typeID
                )
                current.remainingQuantity = try checkedSum(
                    current.remainingQuantity,
                    source.remainingQuantity,
                    typeID: allocation.typeID
                )
                current.sources.append(source)
                accumulated[allocation.typeID] = current
            } else {
                accumulated[allocation.typeID] = Accumulator(
                    typeID: allocation.typeID,
                    name: itemName,
                    targetQuantity: allocation.targetQuantity,
                    purchasedQuantity: credited,
                    remainingQuantity: source.remainingQuantity,
                    sources: [source]
                )
            }
        }

        let positions = accumulated.values.map { value in
            PurchasingWorkflowPosition(
                typeID: value.typeID,
                name: value.name,
                targetQuantity: value.targetQuantity,
                purchasedQuantity: value.purchasedQuantity,
                remainingQuantity: value.remainingQuantity,
                sources: value.sources.sorted(by: sourceOrder)
            )
        }.sorted(by: positionOrder)

        var totalRemaining: Int64 = 0
        for position in positions {
            totalRemaining = try checkedSum(
                totalRemaining,
                position.remainingQuantity,
                typeID: position.typeID
            )
        }
        return PurchasingWorkflowAggregation(
            formulaVersion:
                PurchasingWorkflowAggregation.currentFormulaVersion,
            positions: positions,
            openPositionCount:
                positions.count { $0.remainingQuantity > 0 },
            totalRemainingQuantity: totalRemaining
        )
    }

    private func checkedSum(
        _ lhs: Int64,
        _ rhs: Int64,
        typeID: Int64
    ) throws -> Int64 {
        let sum = lhs.addingReportingOverflow(rhs)
        guard !sum.overflow else {
            throw PurchasingWorkflowAggregationError
                .arithmeticOverflow(typeID: typeID)
        }
        return sum.partialValue
    }

    private func positionOrder(
        _ lhs: PurchasingWorkflowPosition,
        _ rhs: PurchasingWorkflowPosition
    ) -> Bool {
        lhs.name == rhs.name
            ? lhs.typeID < rhs.typeID
            : lhs.name < rhs.name
    }

    private func sourceOrder(
        _ lhs: ProjectPurchaseSource,
        _ rhs: ProjectPurchaseSource
    ) -> Bool {
        lhs.projectName == rhs.projectName
            ? lhs.projectID.uuidString < rhs.projectID.uuidString
            : lhs.projectName < rhs.projectName
    }
}

private extension PurchasingWorkflowAggregator {
    struct AllocationKey: Hashable {
        let projectID: UUID
        let typeID: Int64
    }

    struct Accumulator {
        let typeID: Int64
        let name: String
        var targetQuantity: Int64
        var purchasedQuantity: Int64
        var remainingQuantity: Int64
        var sources: [ProjectPurchaseSource]
    }
}
