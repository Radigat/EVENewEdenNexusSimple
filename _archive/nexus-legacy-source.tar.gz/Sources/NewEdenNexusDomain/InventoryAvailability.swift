import Foundation

public enum InventoryAvailabilityMode:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case allActiveLocations
    case selectedLocations
    case ignoreInventory
}

public struct InventoryAvailabilityCap:
    Equatable,
    Codable,
    Sendable
{
    public let typeID: Int64
    public let maximumQuantity: Int64

    public init(typeID: Int64, maximumQuantity: Int64) {
        self.typeID = typeID
        self.maximumQuantity = maximumQuantity
    }
}

public enum InventoryAvailabilityValidationError:
    Error,
    Equatable,
    Sendable
{
    case updatedBeforeCreation
    case includedLocationsOutsideSelectedMode
    case duplicateLocationID(UUID)
    case invalidTypeID(Int64)
    case duplicateExcludedTypeID(Int64)
    case negativeMaximumQuantity(typeID: Int64, quantity: Int64)
    case duplicateCapTypeID(Int64)
    case excludedTypeHasCap(Int64)
}

public struct InventoryAvailabilityConfigurationSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let projectID: UUID
    public let mode: InventoryAvailabilityMode
    public let includedLocationIDs: [UUID]
    public let excludedTypeIDs: [Int64]
    public let caps: [InventoryAvailabilityCap]
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        projectID: UUID,
        mode: InventoryAvailabilityMode,
        includedLocationIDs: [UUID],
        excludedTypeIDs: [Int64],
        caps: [InventoryAvailabilityCap],
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard createdAt <= updatedAt else {
            throw InventoryAvailabilityValidationError.updatedBeforeCreation
        }
        guard mode == .selectedLocations
                || includedLocationIDs.isEmpty else {
            throw InventoryAvailabilityValidationError
                .includedLocationsOutsideSelectedMode
        }

        var locationIDs: Set<UUID> = []
        for locationID in includedLocationIDs {
            guard locationIDs.insert(locationID).inserted else {
                throw InventoryAvailabilityValidationError
                    .duplicateLocationID(locationID)
            }
        }

        var excludedIDs: Set<Int64> = []
        for typeID in excludedTypeIDs {
            guard typeID > 0 else {
                throw InventoryAvailabilityValidationError
                    .invalidTypeID(typeID)
            }
            guard excludedIDs.insert(typeID).inserted else {
                throw InventoryAvailabilityValidationError
                    .duplicateExcludedTypeID(typeID)
            }
        }

        var capIDs: Set<Int64> = []
        for cap in caps {
            guard cap.typeID > 0 else {
                throw InventoryAvailabilityValidationError
                    .invalidTypeID(cap.typeID)
            }
            guard cap.maximumQuantity >= 0 else {
                throw InventoryAvailabilityValidationError
                    .negativeMaximumQuantity(
                        typeID: cap.typeID,
                        quantity: cap.maximumQuantity
                    )
            }
            guard capIDs.insert(cap.typeID).inserted else {
                throw InventoryAvailabilityValidationError
                    .duplicateCapTypeID(cap.typeID)
            }
            guard !excludedIDs.contains(cap.typeID) else {
                throw InventoryAvailabilityValidationError
                    .excludedTypeHasCap(cap.typeID)
            }
        }

        self.id = id
        self.projectID = projectID
        self.mode = mode
        self.includedLocationIDs = includedLocationIDs.sorted {
            $0.uuidString < $1.uuidString
        }
        self.excludedTypeIDs = excludedTypeIDs.sorted()
        self.caps = caps.sorted { $0.typeID < $1.typeID }
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct InventoryAvailabilityLine: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let requiredQuantity: Int64
    public let storedPhysicalQuantity: Int64
    public let externalPhysicalQuantity: Int64
    public let activePhysicalQuantity: Int64
    public let archivedExcludedQuantity: Int64
    public let selectionExcludedQuantity: Int64
    public let materialExcludedQuantity: Int64
    public let capExcludedQuantity: Int64
    public let eligiblePhysicalQuantity: Int64
    public let usableQuantity: Int64
    public let uncoveredQuantity: Int64
    public let unusedEligibleQuantity: Int64

    public init(
        typeID: Int64,
        name: String,
        requiredQuantity: Int64,
        storedPhysicalQuantity: Int64,
        externalPhysicalQuantity: Int64 = 0,
        activePhysicalQuantity: Int64,
        archivedExcludedQuantity: Int64,
        selectionExcludedQuantity: Int64,
        materialExcludedQuantity: Int64,
        capExcludedQuantity: Int64,
        eligiblePhysicalQuantity: Int64,
        usableQuantity: Int64,
        uncoveredQuantity: Int64,
        unusedEligibleQuantity: Int64
    ) {
        self.typeID = typeID
        self.name = name
        self.requiredQuantity = requiredQuantity
        self.storedPhysicalQuantity = storedPhysicalQuantity
        self.externalPhysicalQuantity = externalPhysicalQuantity
        self.activePhysicalQuantity = activePhysicalQuantity
        self.archivedExcludedQuantity = archivedExcludedQuantity
        self.selectionExcludedQuantity = selectionExcludedQuantity
        self.materialExcludedQuantity = materialExcludedQuantity
        self.capExcludedQuantity = capExcludedQuantity
        self.eligiblePhysicalQuantity = eligiblePhysicalQuantity
        self.usableQuantity = usableQuantity
        self.uncoveredQuantity = uncoveredQuantity
        self.unusedEligibleQuantity = unusedEligibleQuantity
    }
}

public struct InventoryAvailabilityCalculation:
    Equatable,
    Sendable
{
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let lines: [InventoryAvailabilityLine]

    public init(
        formulaVersion: Int = Self.currentFormulaVersion,
        lines: [InventoryAvailabilityLine]
    ) {
        self.formulaVersion = formulaVersion
        self.lines = lines
    }

    public var fullyCoveredMaterialCount: Int {
        lines.filter { $0.uncoveredQuantity == 0 }.count
    }

    public var partiallyCoveredMaterialCount: Int {
        lines.filter {
            $0.usableQuantity > 0 && $0.uncoveredQuantity > 0
        }.count
    }

    public var uncoveredMaterialCount: Int {
        lines.filter { $0.usableQuantity == 0 }.count
    }
}

public enum InventoryAvailabilityCalculationError:
    Error,
    Equatable,
    Sendable
{
    case duplicateLocationID(UUID)
    case duplicateStockID(UUID)
    case stockReferencesMissingLocation(UUID)
    case duplicateStockIdentity(locationID: UUID, typeID: Int64)
    case duplicateRequirementTypeID(Int64)
    case invalidRequirement(typeID: Int64, quantity: Int64)
    case quantityOverflow(typeID: Int64)
}

public struct InventoryAvailabilityCalculator: Sendable {
    public init() {}

    public func calculate(
        requirements: [ProductionGraphMaterialLine],
        locations: [StorageLocationSnapshot],
        stocks: [ManualStockSnapshot],
        configuration: InventoryAvailabilityConfigurationSnapshot
    ) throws -> InventoryAvailabilityCalculation {
        let locationsByID = try validatedLocations(locations)
        let stocksByTypeID = try validatedStocks(
            stocks,
            locationsByID: locationsByID
        )
        let requirementsByTypeID = try validatedRequirements(requirements)
        let selectedLocationIDs = Set(configuration.includedLocationIDs)
        let excludedTypeIDs = Set(configuration.excludedTypeIDs)
        let capsByTypeID = Dictionary(
            uniqueKeysWithValues: configuration.caps.map {
                ($0.typeID, $0.maximumQuantity)
            }
        )

        let lines = try requirementsByTypeID.values.map { requirement in
            var stored: Int64 = 0
            var active: Int64 = 0
            var archived: Int64 = 0
            var selectionExcluded: Int64 = 0
            var selectedCandidate: Int64 = 0

            for stock in stocksByTypeID[requirement.typeID] ?? [] {
                guard let location = locationsByID[stock.locationID] else {
                    throw InventoryAvailabilityCalculationError
                        .stockReferencesMissingLocation(stock.locationID)
                }
                stored = try add(
                    stored,
                    stock.quantity,
                    typeID: requirement.typeID
                )
                if location.isArchived {
                    archived = try add(
                        archived,
                        stock.quantity,
                        typeID: requirement.typeID
                    )
                    continue
                }
                active = try add(
                    active,
                    stock.quantity,
                    typeID: requirement.typeID
                )
                let isSelected: Bool
                switch configuration.mode {
                case .allActiveLocations:
                    isSelected = true
                case .selectedLocations:
                    isSelected = selectedLocationIDs.contains(location.id)
                case .ignoreInventory:
                    isSelected = false
                }
                if isSelected {
                    selectedCandidate = try add(
                        selectedCandidate,
                        stock.quantity,
                        typeID: requirement.typeID
                    )
                } else {
                    selectionExcluded = try add(
                        selectionExcluded,
                        stock.quantity,
                        typeID: requirement.typeID
                    )
                }
            }

            let materialExcluded: Int64
            let afterMaterial: Int64
            if excludedTypeIDs.contains(requirement.typeID) {
                materialExcluded = selectedCandidate
                afterMaterial = 0
            } else {
                materialExcluded = 0
                afterMaterial = selectedCandidate
            }

            let eligible: Int64
            let capExcluded: Int64
            if let cap = capsByTypeID[requirement.typeID],
               cap < afterMaterial {
                eligible = cap
                capExcluded = afterMaterial - cap
            } else {
                eligible = afterMaterial
                capExcluded = 0
            }
            let usable = min(requirement.totalQuantity, eligible)
            return InventoryAvailabilityLine(
                typeID: requirement.typeID,
                name: requirement.name,
                requiredQuantity: requirement.totalQuantity,
                storedPhysicalQuantity: stored,
                activePhysicalQuantity: active,
                archivedExcludedQuantity: archived,
                selectionExcludedQuantity: selectionExcluded,
                materialExcludedQuantity: materialExcluded,
                capExcludedQuantity: capExcluded,
                eligiblePhysicalQuantity: eligible,
                usableQuantity: usable,
                uncoveredQuantity: requirement.totalQuantity - usable,
                unusedEligibleQuantity: eligible - usable
            )
        }.sorted {
            let left = normalizedName($0.name)
            let right = normalizedName($1.name)
            return left == right ? $0.typeID < $1.typeID : left < right
        }
        return InventoryAvailabilityCalculation(lines: lines)
    }

    private func validatedLocations(
        _ locations: [StorageLocationSnapshot]
    ) throws -> [UUID: StorageLocationSnapshot] {
        var result: [UUID: StorageLocationSnapshot] = [:]
        for location in locations {
            guard result[location.id] == nil else {
                throw InventoryAvailabilityCalculationError
                    .duplicateLocationID(location.id)
            }
            result[location.id] = location
        }
        return result
    }

    private func validatedStocks(
        _ stocks: [ManualStockSnapshot],
        locationsByID: [UUID: StorageLocationSnapshot]
    ) throws -> [Int64: [ManualStockSnapshot]] {
        var stockIDs: Set<UUID> = []
        var identities: Set<String> = []
        var result: [Int64: [ManualStockSnapshot]] = [:]
        for stock in stocks {
            guard stockIDs.insert(stock.id).inserted else {
                throw InventoryAvailabilityCalculationError
                    .duplicateStockID(stock.id)
            }
            guard locationsByID[stock.locationID] != nil else {
                throw InventoryAvailabilityCalculationError
                    .stockReferencesMissingLocation(stock.locationID)
            }
            let identity = "\(stock.locationID.uuidString):\(stock.typeID)"
            guard identities.insert(identity).inserted else {
                throw InventoryAvailabilityCalculationError
                    .duplicateStockIdentity(
                        locationID: stock.locationID,
                        typeID: stock.typeID
                    )
            }
            result[stock.typeID, default: []].append(stock)
        }
        return result
    }

    private func validatedRequirements(
        _ requirements: [ProductionGraphMaterialLine]
    ) throws -> [Int64: ProductionGraphMaterialLine] {
        var result: [Int64: ProductionGraphMaterialLine] = [:]
        for requirement in requirements {
            guard requirement.typeID > 0,
                  requirement.totalQuantity > 0 else {
                throw InventoryAvailabilityCalculationError
                    .invalidRequirement(
                        typeID: requirement.typeID,
                        quantity: requirement.totalQuantity
                    )
            }
            guard result[requirement.typeID] == nil else {
                throw InventoryAvailabilityCalculationError
                    .duplicateRequirementTypeID(requirement.typeID)
            }
            result[requirement.typeID] = requirement
        }
        return result
    }

    private func add(
        _ lhs: Int64,
        _ rhs: Int64,
        typeID: Int64
    ) throws -> Int64 {
        let sum = lhs.addingReportingOverflow(rhs)
        guard !sum.overflow else {
            throw InventoryAvailabilityCalculationError
                .quantityOverflow(typeID: typeID)
        }
        return sum.partialValue
    }

    private func normalizedName(_ name: String) -> String {
        name.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "en_US_POSIX")
        )
    }
}
