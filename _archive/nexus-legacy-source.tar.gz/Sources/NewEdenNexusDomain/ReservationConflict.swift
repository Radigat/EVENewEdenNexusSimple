import Foundation

public enum ReservationConflictReason:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case stockShortage
    case requirementExceeded
    case noLongerRequired
}

public struct ReservationConflictProjectSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let name: String
    public let priority: Int
    public let updatedAt: Date

    public init(
        id: UUID,
        name: String,
        priority: Int,
        updatedAt: Date
    ) throws {
        let normalizedName = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !normalizedName.isEmpty else {
            throw ReservationConflictCalculationError
                .invalidProject(id)
        }
        guard (1...3).contains(priority) else {
            throw ReservationConflictCalculationError
                .invalidProject(id)
        }
        self.id = id
        self.name = normalizedName
        self.priority = priority
        self.updatedAt = updatedAt
    }
}

public struct ReservationConflictParticipant:
    Identifiable,
    Equatable,
    Sendable
{
    public var id: UUID { reservation.id }

    public let reservation: StockReservationSnapshot
    public let project: ReservationConflictProjectSnapshot
    public let isCurrentProject: Bool
    public let suggestedRemainingQuantity: Int64
    public let isExpired: Bool
}

public struct ReservationConflictLine:
    Identifiable,
    Equatable,
    Sendable
{
    public var id: Int64 { typeID }

    public let typeID: Int64
    public let materialName: String
    public let reasons: [ReservationConflictReason]
    public let requiredQuantity: Int64?
    public let availableAfterSafetyStockQuantity: Int64?
    public let totalActiveReservedQuantity: Int64
    public let requiredReductionQuantity: Int64
    public let participants: [ReservationConflictParticipant]
}

public struct ReservationConflictAnalysis:
    Equatable,
    Sendable
{
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let conflicts: [ReservationConflictLine]
    public let expiredActiveReservationCount: Int

    public init(
        formulaVersion: Int = Self.currentFormulaVersion,
        conflicts: [ReservationConflictLine],
        expiredActiveReservationCount: Int
    ) {
        self.formulaVersion = formulaVersion
        self.conflicts = conflicts
        self.expiredActiveReservationCount =
            expiredActiveReservationCount
    }

    public var hasConflicts: Bool {
        !conflicts.isEmpty
    }

    public var affectedReservationCount: Int {
        Set(conflicts.flatMap { $0.participants.map(\.id) }).count
    }
}

public enum ReservationConflictCalculationError:
    Error,
    Equatable,
    Sendable
{
    case duplicateMaterialTypeID(Int64)
    case duplicateProject(UUID)
    case invalidProject(UUID)
    case missingProject(UUID)
    case duplicateActiveReservation(projectID: UUID, typeID: Int64)
    case reservationSumOverflow(Int64)
    case invalidMaterialLine(Int64)
}

public struct ReservationConflictCalculator: Sendable {
    public init() {}

    public func analyze(
        currentProjectID: UUID,
        safetyStock: SafetyStockCalculation,
        reservations: [StockReservationSnapshot],
        projects: [ReservationConflictProjectSnapshot],
        materialNames: [Int64: String],
        at date: Date
    ) throws -> ReservationConflictAnalysis {
        let projectsByID = try projectIndex(projects)
        guard projectsByID[currentProjectID] != nil else {
            throw ReservationConflictCalculationError
                .missingProject(currentProjectID)
        }
        let materials = try materialIndex(safetyStock)
        let active = try activeReservationIndex(
            reservations,
            projectsByID: projectsByID
        )
        let activeCurrentTypeIDs = Set(
            active.values
                .filter { $0.projectID == currentProjectID }
                .map(\.typeID)
        )
        let relevantTypeIDs = Set(materials.keys)
            .union(activeCurrentTypeIDs)

        var conflicts: [ReservationConflictLine] = []
        for typeID in relevantTypeIDs {
            let material = materials[typeID]
            let grouped = active.values
                .filter { $0.typeID == typeID }
                .sorted {
                    reservationOrder(
                        $0,
                        $1,
                        projectsByID: projectsByID
                    )
                }
            let current = grouped.first {
                $0.projectID == currentProjectID
            }
            let total = try sumRemaining(
                grouped,
                typeID: typeID
            )
            let available = material?
                .availableAfterSafetyStockQuantity
            let required = material?.availability.requiredQuantity
            let stockShortage = available.map {
                total > $0
            } ?? false
            let requirementExceeded = if let current, let required {
                current.remainingQuantity > required
            } else {
                false
            }
            let noLongerRequired = material == nil && current != nil

            var reasons: [ReservationConflictReason] = []
            if stockShortage {
                reasons.append(.stockShortage)
            }
            if requirementExceeded {
                reasons.append(.requirementExceeded)
            }
            if noLongerRequired {
                reasons.append(.noLongerRequired)
            }
            guard !reasons.isEmpty else {
                continue
            }

            var suggestions: [UUID: Int64] = Dictionary(
                uniqueKeysWithValues: grouped.map {
                    ($0.id, $0.remainingQuantity)
                }
            )
            if stockShortage, let available {
                var remainingAvailable = available
                for reservation in grouped {
                    let suggested = min(
                        reservation.remainingQuantity,
                        remainingAvailable
                    )
                    suggestions[reservation.id] = suggested
                    remainingAvailable -= suggested
                }
            }
            if let current {
                if noLongerRequired {
                    suggestions[current.id] = 0
                } else if let required {
                    suggestions[current.id] = min(
                        suggestions[current.id]
                            ?? current.remainingQuantity,
                        required
                    )
                }
            }

            let participants = grouped.compactMap {
                reservation
                -> ReservationConflictParticipant? in
                let isCurrent =
                    reservation.projectID == currentProjectID
                guard stockShortage || isCurrent else {
                    return nil
                }
                guard let project =
                        projectsByID[reservation.projectID] else {
                    return nil
                }
                return ReservationConflictParticipant(
                    reservation: reservation,
                    project: project,
                    isCurrentProject: isCurrent,
                    suggestedRemainingQuantity:
                        suggestions[reservation.id]
                            ?? reservation.remainingQuantity,
                    isExpired: reservation.isExpired(at: date)
                )
            }
            let reduction = try participants.reduce(Int64(0)) {
                partial,
                participant in
                let delta = participant.reservation.remainingQuantity
                    - participant.suggestedRemainingQuantity
                let addition = partial.addingReportingOverflow(delta)
                guard !addition.overflow else {
                    throw ReservationConflictCalculationError
                        .reservationSumOverflow(typeID)
                }
                return addition.partialValue
            }
            let name = normalizedMaterialName(
                material?.availability.name
                    ?? materialNames[typeID],
                typeID: typeID
            )
            conflicts.append(
                ReservationConflictLine(
                    typeID: typeID,
                    materialName: name,
                    reasons: reasons,
                    requiredQuantity: required,
                    availableAfterSafetyStockQuantity: available,
                    totalActiveReservedQuantity: total,
                    requiredReductionQuantity: reduction,
                    participants: participants
                )
            )
        }

        let ordered = conflicts.sorted {
            let left = normalizedName($0.materialName)
            let right = normalizedName($1.materialName)
            return left == right
                ? $0.typeID < $1.typeID
                : left < right
        }
        return ReservationConflictAnalysis(
            conflicts: ordered,
            expiredActiveReservationCount: active.values.filter {
                $0.isExpired(at: date)
            }.count
        )
    }

    private func projectIndex(
        _ projects: [ReservationConflictProjectSnapshot]
    ) throws -> [UUID: ReservationConflictProjectSnapshot] {
        var result: [UUID: ReservationConflictProjectSnapshot] = [:]
        for project in projects {
            guard result[project.id] == nil else {
                throw ReservationConflictCalculationError
                    .duplicateProject(project.id)
            }
            result[project.id] = project
        }
        return result
    }

    private func materialIndex(
        _ safetyStock: SafetyStockCalculation
    ) throws -> [Int64: SafetyStockLine] {
        var result: [Int64: SafetyStockLine] = [:]
        for line in safetyStock.lines {
            let typeID = line.availability.typeID
            guard typeID > 0,
                  line.availability.requiredQuantity > 0,
                  line.availableAfterSafetyStockQuantity >= 0 else {
                throw ReservationConflictCalculationError
                    .invalidMaterialLine(typeID)
            }
            guard result[typeID] == nil else {
                throw ReservationConflictCalculationError
                    .duplicateMaterialTypeID(typeID)
            }
            result[typeID] = line
        }
        return result
    }

    private func activeReservationIndex(
        _ reservations: [StockReservationSnapshot],
        projectsByID: [UUID: ReservationConflictProjectSnapshot]
    ) throws -> [ReservationKey: StockReservationSnapshot] {
        var result: [ReservationKey: StockReservationSnapshot] = [:]
        for reservation in reservations
        where reservation.status.isBinding {
            guard projectsByID[reservation.projectID] != nil else {
                throw ReservationConflictCalculationError
                    .missingProject(reservation.projectID)
            }
            let key = ReservationKey(
                projectID: reservation.projectID,
                typeID: reservation.typeID
            )
            guard result[key] == nil else {
                throw ReservationConflictCalculationError
                    .duplicateActiveReservation(
                        projectID: reservation.projectID,
                        typeID: reservation.typeID
                    )
            }
            result[key] = reservation
        }
        return result
    }

    private func sumRemaining(
        _ reservations: [StockReservationSnapshot],
        typeID: Int64
    ) throws -> Int64 {
        try reservations.reduce(Int64(0)) { partial, reservation in
            let addition = partial.addingReportingOverflow(
                reservation.remainingQuantity
            )
            guard !addition.overflow else {
                throw ReservationConflictCalculationError
                    .reservationSumOverflow(typeID)
            }
            return addition.partialValue
        }
    }

    private func reservationOrder(
        _ left: StockReservationSnapshot,
        _ right: StockReservationSnapshot,
        projectsByID: [UUID: ReservationConflictProjectSnapshot]
    ) -> Bool {
        if left.priority != right.priority {
            return left.priority < right.priority
        }
        let leftProject = projectsByID[left.projectID]
        let rightProject = projectsByID[right.projectID]
        if leftProject?.priority != rightProject?.priority {
            return (leftProject?.priority ?? Int.max)
                < (rightProject?.priority ?? Int.max)
        }
        if left.createdAt != right.createdAt {
            return left.createdAt < right.createdAt
        }
        if left.projectID != right.projectID {
            return left.projectID.uuidString
                < right.projectID.uuidString
        }
        return left.id.uuidString < right.id.uuidString
    }

    private func normalizedMaterialName(
        _ name: String?,
        typeID: Int64
    ) -> String {
        let normalized = name?.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        if let normalized, !normalized.isEmpty {
            return normalized
        }
        return "Type-ID \(typeID)"
    }

    private func normalizedName(_ name: String) -> String {
        name.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "en_US_POSIX")
        )
    }
}

private struct ReservationKey: Hashable {
    let projectID: UUID
    let typeID: Int64
}
