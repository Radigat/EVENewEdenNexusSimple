import Foundation

public enum ProductionBatchStatus:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case planned
    case produced
    case forSale
    case completed
    case archived
}

public enum ProductionBatchValidationError:
    Error,
    Equatable,
    Sendable
{
    case invalidCalendarYear(Int)
    case invalidSequence(Int)
    case invalidProductTypeID(Int64)
    case emptyProductName
    case invalidRuns(Int64)
    case invalidMaterialEfficiency(Int)
    case invalidTimeEfficiency(Int)
    case invalidOutputUnits(Int64)
    case invalidIdentifier(field: String, value: Int64)
    case invalidCatalogBuildNumber(Int)
    case emptyCatalogContentSHA256
    case invalidGraphFormatVersion(Int)
    case invalidRuleVersion(field: String, value: Int)
    case completedBeforeProduction
    case updatedBeforeCreation
}

public struct ProductionBatchSnapshot:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public static let currentContractVersion = 1

    public let id: UUID
    public let calendarYear: Int
    public let sequenceNumber: Int
    public let projectID: UUID
    public let projectName: String
    public let sourceProjectUpdatedAt: Date
    public let graphID: UUID
    public let graphUpdatedAt: Date
    public let graphFormatVersion: Int
    public let expansionPolicyVersion: Int
    public let runFormulaVersion: Int
    public let materialFormulaVersion: Int
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String
    public let productionDate: Date
    public let completedAt: Date?
    public let status: ProductionBatchStatus
    public let productTypeID: Int64
    public let productName: String
    public let activity: ProductionTargetActivity
    public let runs: Int64
    public let materialEfficiency: Int
    public let timeEfficiency: Int
    public let outputUnits: Int64
    public let characterID: Int64?
    public let characterName: String?
    public let blueprintInstanceID: Int64?
    public let esiIndustryJobID: Int64?
    public let solarSystemID: Int64?
    public let solarSystemName: String?
    public let locationID: Int64?
    public let locationName: String?
    public let facilityID: Int64?
    public let facilityName: String?
    public let createdAt: Date
    public let updatedAt: Date

    public var displayNumber: String {
        "\(calendarYear)-\(String(format: "%04d", sequenceNumber))"
    }

    public init(
        id: UUID,
        calendarYear: Int,
        sequenceNumber: Int,
        projectID: UUID,
        projectName: String,
        sourceProjectUpdatedAt: Date,
        graphID: UUID,
        graphUpdatedAt: Date,
        graphFormatVersion: Int,
        expansionPolicyVersion: Int,
        runFormulaVersion: Int,
        materialFormulaVersion: Int,
        catalogBuildNumber: Int,
        catalogContentSHA256: String,
        productionDate: Date,
        completedAt: Date? = nil,
        status: ProductionBatchStatus,
        productTypeID: Int64,
        productName: String,
        activity: ProductionTargetActivity,
        runs: Int64,
        materialEfficiency: Int,
        timeEfficiency: Int,
        outputUnits: Int64,
        characterID: Int64? = nil,
        characterName: String? = nil,
        blueprintInstanceID: Int64? = nil,
        esiIndustryJobID: Int64? = nil,
        solarSystemID: Int64? = nil,
        solarSystemName: String? = nil,
        locationID: Int64? = nil,
        locationName: String? = nil,
        facilityID: Int64? = nil,
        facilityName: String? = nil,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard (2003...9999).contains(calendarYear) else {
            throw ProductionBatchValidationError
                .invalidCalendarYear(calendarYear)
        }
        guard sequenceNumber > 0 else {
            throw ProductionBatchValidationError
                .invalidSequence(sequenceNumber)
        }
        guard productTypeID > 0 else {
            throw ProductionBatchValidationError
                .invalidProductTypeID(productTypeID)
        }
        let productName = productName.trimmedNonempty
        guard let productName else {
            throw ProductionBatchValidationError.emptyProductName
        }
        guard runs > 0 else {
            throw ProductionBatchValidationError.invalidRuns(runs)
        }
        guard (0...10).contains(materialEfficiency) else {
            throw ProductionBatchValidationError
                .invalidMaterialEfficiency(materialEfficiency)
        }
        guard (0...20).contains(timeEfficiency) else {
            throw ProductionBatchValidationError
                .invalidTimeEfficiency(timeEfficiency)
        }
        guard outputUnits > 0 else {
            throw ProductionBatchValidationError
                .invalidOutputUnits(outputUnits)
        }
        try Self.validateID(characterID, field: "characterID")
        try Self.validateID(
            blueprintInstanceID,
            field: "blueprintInstanceID"
        )
        try Self.validateID(
            esiIndustryJobID,
            field: "esiIndustryJobID"
        )
        try Self.validateID(solarSystemID, field: "solarSystemID")
        try Self.validateID(locationID, field: "locationID")
        try Self.validateID(facilityID, field: "facilityID")
        guard catalogBuildNumber > 0 else {
            throw ProductionBatchValidationError
                .invalidCatalogBuildNumber(catalogBuildNumber)
        }
        let catalogHash = catalogContentSHA256
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !catalogHash.isEmpty else {
            throw ProductionBatchValidationError
                .emptyCatalogContentSHA256
        }
        guard graphFormatVersion > 0 else {
            throw ProductionBatchValidationError
                .invalidGraphFormatVersion(graphFormatVersion)
        }
        for (field, version) in [
            ("expansionPolicyVersion", expansionPolicyVersion),
            ("runFormulaVersion", runFormulaVersion),
            ("materialFormulaVersion", materialFormulaVersion)
        ] where version <= 0 {
            throw ProductionBatchValidationError
                .invalidRuleVersion(field: field, value: version)
        }
        if let completedAt, completedAt < productionDate {
            throw ProductionBatchValidationError
                .completedBeforeProduction
        }
        guard createdAt <= updatedAt else {
            throw ProductionBatchValidationError.updatedBeforeCreation
        }

        self.id = id
        self.calendarYear = calendarYear
        self.sequenceNumber = sequenceNumber
        self.projectID = projectID
        self.projectName = projectName
            .trimmingCharacters(in: .whitespacesAndNewlines)
        self.sourceProjectUpdatedAt = sourceProjectUpdatedAt
        self.graphID = graphID
        self.graphUpdatedAt = graphUpdatedAt
        self.graphFormatVersion = graphFormatVersion
        self.expansionPolicyVersion = expansionPolicyVersion
        self.runFormulaVersion = runFormulaVersion
        self.materialFormulaVersion = materialFormulaVersion
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = catalogHash
        self.productionDate = productionDate
        self.completedAt = completedAt
        self.status = status
        self.productTypeID = productTypeID
        self.productName = productName
        self.activity = activity
        self.runs = runs
        self.materialEfficiency = materialEfficiency
        self.timeEfficiency = timeEfficiency
        self.outputUnits = outputUnits
        self.characterID = characterID
        self.characterName = characterName.trimmedNonempty
        self.blueprintInstanceID = blueprintInstanceID
        self.esiIndustryJobID = esiIndustryJobID
        self.solarSystemID = solarSystemID
        self.solarSystemName = solarSystemName.trimmedNonempty
        self.locationID = locationID
        self.locationName = locationName.trimmedNonempty
        self.facilityID = facilityID
        self.facilityName = facilityName.trimmedNonempty
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    private static func validateID(
        _ value: Int64?,
        field: String
    ) throws {
        if let value, value <= 0 {
            throw ProductionBatchValidationError
                .invalidIdentifier(field: field, value: value)
        }
    }
}

private extension Optional where Wrapped == String {
    var trimmedNonempty: String? {
        guard let value = self?.trimmingCharacters(
            in: .whitespacesAndNewlines
        ), !value.isEmpty else {
            return nil
        }
        return value
    }
}

private extension String {
    var trimmedNonempty: String? {
        Optional(self).trimmedNonempty
    }
}
