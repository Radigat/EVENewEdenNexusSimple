import Foundation

public enum ProductionGraphNodeKind: String, Codable, Sendable {
    case target
    case intermediate
    case material
}

public enum ProductionGraphMaterialEfficiencySource:
    String,
    Equatable,
    Codable,
    Sendable
{
    case projectBlueprint
    case neutralIntermediate
    case regularT2Invention
    case t2StageOverride
    case reactionFormula
}

public enum ProductionGraphLeafReason:
    String,
    Equatable,
    Codable,
    Sendable
{
    case noManufacturingRecipe
    case noProductionRecipe
    case reactionDeferred
}

public struct ProductionGraphNodeID:
    RawRepresentable,
    Hashable,
    Codable,
    Sendable
{
    public let rawValue: String

    public init(rawValue: String) {
        self.rawValue = rawValue
    }
}

public struct ProductionGraphRecipeReference:
    Equatable,
    Codable,
    Sendable
{
    public let blueprintTypeID: Int64
    public let activity: ProductionTargetActivity
    public let outputQuantityPerRun: Int64
    public let timeSeconds: Int64
    public let maxProductionLimit: Int64?
    public let materialEfficiency: Int?
    public let materialEfficiencySource:
        ProductionGraphMaterialEfficiencySource?
    public let techLevel: IndustryTechLevel?
    public let blueprintPlanningQuality: BlueprintPlanningQuality?
    public let invention: InventionStageReference?
    public let reactionKind: ReactionKind?
    public let requiredReactorTypeID: Int64?
    public let reactionContext: ReactionPlanningContext?
    public let reactionTimeCalculation: ReactionTimeCalculation?

    public init(
        blueprintTypeID: Int64,
        activity: ProductionTargetActivity,
        outputQuantityPerRun: Int64,
        timeSeconds: Int64,
        maxProductionLimit: Int64?,
        materialEfficiency: Int? = nil,
        materialEfficiencySource:
            ProductionGraphMaterialEfficiencySource? = nil,
        techLevel: IndustryTechLevel? = nil,
        blueprintPlanningQuality: BlueprintPlanningQuality? = nil,
        invention: InventionStageReference? = nil,
        reactionKind: ReactionKind? = nil,
        requiredReactorTypeID: Int64? = nil,
        reactionContext: ReactionPlanningContext? = nil,
        reactionTimeCalculation: ReactionTimeCalculation? = nil
    ) {
        self.blueprintTypeID = blueprintTypeID
        self.activity = activity
        self.outputQuantityPerRun = outputQuantityPerRun
        self.timeSeconds = timeSeconds
        self.maxProductionLimit = maxProductionLimit
        self.materialEfficiency = materialEfficiency
        self.materialEfficiencySource = materialEfficiencySource
        self.techLevel = techLevel
        self.blueprintPlanningQuality = blueprintPlanningQuality
        self.invention = invention
        self.reactionKind = reactionKind
        self.requiredReactorTypeID = requiredReactorTypeID
        self.reactionContext = reactionContext
        self.reactionTimeCalculation = reactionTimeCalculation
    }
}

public struct ProductionGraphNode: Equatable, Codable, Sendable {
    public let id: ProductionGraphNodeID
    public let typeID: Int64
    public let name: String
    public let kind: ProductionGraphNodeKind
    public let depth: Int
    public let recipe: ProductionGraphRecipeReference?
    public let runCalculation: ProductionRunCalculation?
    public let leafReason: ProductionGraphLeafReason?

    public init(
        id: ProductionGraphNodeID,
        typeID: Int64,
        name: String,
        kind: ProductionGraphNodeKind,
        depth: Int,
        recipe: ProductionGraphRecipeReference?,
        runCalculation: ProductionRunCalculation? = nil,
        leafReason: ProductionGraphLeafReason? = nil
    ) {
        self.id = id
        self.typeID = typeID
        self.name = name
        self.kind = kind
        self.depth = depth
        self.recipe = recipe
        self.runCalculation = runCalculation
        self.leafReason = leafReason
    }
}

public struct ProductionGraphEdge: Equatable, Codable, Sendable {
    public let parentID: ProductionGraphNodeID
    public let childID: ProductionGraphNodeID
    public let baseQuantityPerRun: Int64
    public let sortOrder: Int
    public let materialCalculation: ProductionMaterialCalculation?
    public let reactionMaterialCalculation: ReactionMaterialCalculation?

    public init(
        parentID: ProductionGraphNodeID,
        childID: ProductionGraphNodeID,
        baseQuantityPerRun: Int64,
        sortOrder: Int,
        materialCalculation: ProductionMaterialCalculation? = nil,
        reactionMaterialCalculation: ReactionMaterialCalculation? = nil
    ) {
        self.parentID = parentID
        self.childID = childID
        self.baseQuantityPerRun = baseQuantityPerRun
        self.sortOrder = sortOrder
        self.materialCalculation = materialCalculation
        self.reactionMaterialCalculation = reactionMaterialCalculation
    }
}

public enum ProductionGraphValidationError:
    Error,
    Equatable,
    Sendable
{
    case unsupportedFormatVersion(Int)
    case invalidTargetQuantity(Int)
    case invalidCatalogBuildNumber(Int)
    case emptyCatalogContentSHA256
    case invalidTimestamps
    case emptyGraph
    case maximumDepthExceeded(Int)
    case maximumNodeCountExceeded(Int)
    case emptyNodeID
    case duplicateNodeID(ProductionGraphNodeID)
    case invalidTypeID(Int64)
    case emptyNodeName(ProductionGraphNodeID)
    case invalidDepth(ProductionGraphNodeID)
    case invalidRecipe(ProductionGraphNodeID)
    case missingRecipeMaterialEfficiency(ProductionGraphNodeID)
    case unexpectedRecipeMaterialEfficiency(ProductionGraphNodeID)
    case invalidRecipeMaterialEfficiency(ProductionGraphNodeID)
    case invalidRecipeMaterialEfficiencySource(ProductionGraphNodeID)
    case missingIndustryProvenance(ProductionGraphNodeID)
    case invalidIndustryProvenance(ProductionGraphNodeID)
    case invalidInventionReference(ProductionGraphNodeID)
    case missingReactionProvenance(ProductionGraphNodeID)
    case invalidReactionProvenance(ProductionGraphNodeID)
    case missingLeafReason(ProductionGraphNodeID)
    case unexpectedLeafReason(ProductionGraphNodeID)
    case missingRunCalculation(ProductionGraphNodeID)
    case unexpectedRunCalculation(ProductionGraphNodeID)
    case runCalculationOutputMismatch(ProductionGraphNodeID)
    case runCalculationTargetMismatch(ProductionGraphNodeID)
    case runCalculationIncomingQuantityMismatch(ProductionGraphNodeID)
    case missingExpansionPolicyVersion
    case unexpectedExpansionPolicyVersion
    case unsupportedExpansionPolicyVersion(Int)
    case missingMaterialEfficiency
    case unexpectedMaterialEfficiency
    case invalidMaterialEfficiency(Int)
    case materialEfficiencyUnsupportedForReaction(Int)
    case invalidNodeKind(ProductionGraphNodeID)
    case invalidRoot(ProductionGraphNodeID)
    case multipleTargetNodes
    case missingEdgeEndpoint(ProductionGraphNodeID)
    case selfEdge(ProductionGraphNodeID)
    case invalidEdgeQuantity(ProductionGraphNodeID)
    case invalidEdgeSortOrder(ProductionGraphNodeID)
    case duplicateSiblingSortOrder(
        parentID: ProductionGraphNodeID,
        sortOrder: Int
    )
    case missingMaterialCalculation(ProductionGraphNodeID)
    case unexpectedMaterialCalculation(ProductionGraphNodeID)
    case materialCalculationBaseMismatch(ProductionGraphNodeID)
    case materialCalculationRunsMismatch(ProductionGraphNodeID)
    case materialCalculationActivityMismatch(ProductionGraphNodeID)
    case materialCalculationEfficiencyMismatch(ProductionGraphNodeID)
    case missingReactionMaterialCalculation(ProductionGraphNodeID)
    case unexpectedReactionMaterialCalculation(ProductionGraphNodeID)
    case reactionMaterialCalculationMismatch(ProductionGraphNodeID)
    case duplicateIncomingEdge(ProductionGraphNodeID)
    case missingIncomingEdge(ProductionGraphNodeID)
    case rootHasIncomingEdge
    case invalidEdgeDepth(ProductionGraphNodeID)
    case cycleDetected(ProductionGraphNodeID)
    case unreachableNode(ProductionGraphNodeID)
    case targetProvenanceMismatch
    case missingMaterialAggregation
    case unexpectedMaterialAggregation
    case unsupportedMaterialAggregationFormulaVersion(Int)
    case materialAggregationMismatch
    case materialAggregationCalculationFailed(
        ProductionGraphMaterialAggregationError
    )
}

public struct ProductionGraphSnapshot:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public static let currentFormatVersion = 7
    public static let reactionFormatVersion = 6
    public static let t2FormatVersion = 5
    public static let t1RecursiveFormatVersion = 4
    public static let recursiveManufacturingFormatVersion = 4
    public static let materialEfficiencyFormatVersion = 3
    public static let runOutputFormatVersion = 2
    public static let legacyFormatVersion = 1
    public static let currentExpansionPolicyVersion = 3
    public static let t2ExpansionPolicyVersion = 2
    public static let t1ExpansionPolicyVersion = 1
    public static let maximumValidatedDepth = 64
    public static let maximumValidatedNodeCount = 25_000

    public let id: UUID
    public let projectID: UUID
    public let formatVersion: Int
    public let projectTargetQuantity: Int
    public let sourceProjectUpdatedAt: Date
    public let targetProductTypeID: Int64
    public let targetActivity: ProductionTargetActivity
    public let targetBlueprintTypeID: Int64
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String
    public let blueprintMaterialEfficiency: Int?
    public let expansionPolicyVersion: Int?
    public let rootNodeID: ProductionGraphNodeID
    public let nodes: [ProductionGraphNode]
    public let edges: [ProductionGraphEdge]
    public let materialAggregation:
        ProductionGraphMaterialAggregation?
    public let createdAt: Date
    public let updatedAt: Date

    public var graphID: UUID {
        id
    }

    public init(
        id: UUID,
        projectID: UUID,
        formatVersion: Int = Self.currentFormatVersion,
        projectTargetQuantity: Int,
        sourceProjectUpdatedAt: Date,
        targetProductTypeID: Int64,
        targetActivity: ProductionTargetActivity,
        targetBlueprintTypeID: Int64,
        catalogBuildNumber: Int,
        catalogContentSHA256: String,
        blueprintMaterialEfficiency: Int? = nil,
        expansionPolicyVersion: Int? = nil,
        rootNodeID: ProductionGraphNodeID,
        nodes: [ProductionGraphNode],
        edges: [ProductionGraphEdge],
        materialAggregation:
            ProductionGraphMaterialAggregation? = nil,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        let normalizedHash = catalogContentSHA256.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let sortedNodes = nodes.sorted(by: Self.nodeSort)
        let sortedEdges = edges.sorted(by: Self.edgeSort)

        try Self.validate(
            formatVersion: formatVersion,
            projectTargetQuantity: projectTargetQuantity,
            sourceProjectUpdatedAt: sourceProjectUpdatedAt,
            targetProductTypeID: targetProductTypeID,
            targetActivity: targetActivity,
            targetBlueprintTypeID: targetBlueprintTypeID,
            catalogBuildNumber: catalogBuildNumber,
            catalogContentSHA256: normalizedHash,
            blueprintMaterialEfficiency: blueprintMaterialEfficiency,
            expansionPolicyVersion: expansionPolicyVersion,
            rootNodeID: rootNodeID,
            nodes: sortedNodes,
            edges: sortedEdges,
            materialAggregation: materialAggregation,
            createdAt: createdAt,
            updatedAt: updatedAt
        )

        self.id = id
        self.projectID = projectID
        self.formatVersion = formatVersion
        self.projectTargetQuantity = projectTargetQuantity
        self.sourceProjectUpdatedAt = sourceProjectUpdatedAt
        self.targetProductTypeID = targetProductTypeID
        self.targetActivity = targetActivity
        self.targetBlueprintTypeID = targetBlueprintTypeID
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = normalizedHash
        self.blueprintMaterialEfficiency = blueprintMaterialEfficiency
        self.expansionPolicyVersion = expansionPolicyVersion
        self.rootNodeID = rootNodeID
        self.nodes = sortedNodes
        self.edges = sortedEdges
        self.materialAggregation = materialAggregation
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    public func validatedCopy() throws -> ProductionGraphSnapshot {
        try ProductionGraphSnapshot(
            id: id,
            projectID: projectID,
            formatVersion: formatVersion,
            projectTargetQuantity: projectTargetQuantity,
            sourceProjectUpdatedAt: sourceProjectUpdatedAt,
            targetProductTypeID: targetProductTypeID,
            targetActivity: targetActivity,
            targetBlueprintTypeID: targetBlueprintTypeID,
            catalogBuildNumber: catalogBuildNumber,
            catalogContentSHA256: catalogContentSHA256,
            blueprintMaterialEfficiency: blueprintMaterialEfficiency,
            expansionPolicyVersion: expansionPolicyVersion,
            rootNodeID: rootNodeID,
            nodes: nodes,
            edges: edges,
            materialAggregation: materialAggregation,
            createdAt: createdAt,
            updatedAt: updatedAt
        )
    }

    private static func validate(
        formatVersion: Int,
        projectTargetQuantity: Int,
        sourceProjectUpdatedAt: Date,
        targetProductTypeID: Int64,
        targetActivity: ProductionTargetActivity,
        targetBlueprintTypeID: Int64,
        catalogBuildNumber: Int,
        catalogContentSHA256: String,
        blueprintMaterialEfficiency: Int?,
        expansionPolicyVersion: Int?,
        rootNodeID: ProductionGraphNodeID,
        nodes: [ProductionGraphNode],
        edges: [ProductionGraphEdge],
        materialAggregation:
            ProductionGraphMaterialAggregation?,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard formatVersion == legacyFormatVersion
                || formatVersion == runOutputFormatVersion
                || formatVersion == materialEfficiencyFormatVersion
                || formatVersion == t1RecursiveFormatVersion
                || formatVersion == t2FormatVersion
                || formatVersion == reactionFormatVersion
                || formatVersion == currentFormatVersion else {
            throw ProductionGraphValidationError
                .unsupportedFormatVersion(formatVersion)
        }
        guard projectTargetQuantity > 0 else {
            throw ProductionGraphValidationError
                .invalidTargetQuantity(projectTargetQuantity)
        }
        guard targetProductTypeID > 0, targetBlueprintTypeID > 0 else {
            throw ProductionGraphValidationError
                .targetProvenanceMismatch
        }
        guard catalogBuildNumber > 0 else {
            throw ProductionGraphValidationError
                .invalidCatalogBuildNumber(catalogBuildNumber)
        }
        guard !catalogContentSHA256.isEmpty else {
            throw ProductionGraphValidationError.emptyCatalogContentSHA256
        }
        switch formatVersion {
        case legacyFormatVersion, runOutputFormatVersion:
            guard blueprintMaterialEfficiency == nil else {
                throw ProductionGraphValidationError
                    .unexpectedMaterialEfficiency
            }
            guard expansionPolicyVersion == nil else {
                throw ProductionGraphValidationError
                    .unexpectedExpansionPolicyVersion
            }
        case materialEfficiencyFormatVersion:
            guard let blueprintMaterialEfficiency else {
                throw ProductionGraphValidationError
                    .missingMaterialEfficiency
            }
            guard (0...10).contains(blueprintMaterialEfficiency) else {
                throw ProductionGraphValidationError
                    .invalidMaterialEfficiency(
                        blueprintMaterialEfficiency
                    )
            }
            if targetActivity == .reaction,
               blueprintMaterialEfficiency != 0 {
                throw ProductionGraphValidationError
                    .materialEfficiencyUnsupportedForReaction(
                        blueprintMaterialEfficiency
                    )
            }
            guard expansionPolicyVersion == nil else {
                throw ProductionGraphValidationError
                    .unexpectedExpansionPolicyVersion
            }
        case t1RecursiveFormatVersion, t2FormatVersion,
             reactionFormatVersion,
             currentFormatVersion:
            guard let blueprintMaterialEfficiency else {
                throw ProductionGraphValidationError
                    .missingMaterialEfficiency
            }
            guard (0...10).contains(blueprintMaterialEfficiency) else {
                throw ProductionGraphValidationError
                    .invalidMaterialEfficiency(
                        blueprintMaterialEfficiency
                    )
            }
            if targetActivity == .reaction,
               blueprintMaterialEfficiency != 0 {
                throw ProductionGraphValidationError
                    .materialEfficiencyUnsupportedForReaction(
                        blueprintMaterialEfficiency
                    )
            }
            guard let expansionPolicyVersion else {
                throw ProductionGraphValidationError
                    .missingExpansionPolicyVersion
            }
            let expectedPolicy: Int
            switch formatVersion {
            case t1RecursiveFormatVersion:
                expectedPolicy = t1ExpansionPolicyVersion
            case t2FormatVersion:
                expectedPolicy = t2ExpansionPolicyVersion
            default:
                expectedPolicy = currentExpansionPolicyVersion
            }
            guard expansionPolicyVersion == expectedPolicy else {
                throw ProductionGraphValidationError
                    .unsupportedExpansionPolicyVersion(
                        expansionPolicyVersion
                    )
            }
        default:
            throw ProductionGraphValidationError
                .unsupportedFormatVersion(formatVersion)
        }
        guard sourceProjectUpdatedAt <= updatedAt, createdAt <= updatedAt else {
            throw ProductionGraphValidationError.invalidTimestamps
        }
        guard !nodes.isEmpty else {
            throw ProductionGraphValidationError.emptyGraph
        }
        guard nodes.count <= maximumValidatedNodeCount else {
            throw ProductionGraphValidationError
                .maximumNodeCountExceeded(maximumValidatedNodeCount)
        }

        var nodesByID: [ProductionGraphNodeID: ProductionGraphNode] = [:]
        for node in nodes {
            guard !node.id.rawValue.trimmingCharacters(
                in: .whitespacesAndNewlines
            ).isEmpty else {
                throw ProductionGraphValidationError.emptyNodeID
            }
            guard nodesByID[node.id] == nil else {
                throw ProductionGraphValidationError
                    .duplicateNodeID(node.id)
            }
            guard node.typeID > 0 else {
                throw ProductionGraphValidationError
                    .invalidTypeID(node.typeID)
            }
            guard !node.name.trimmingCharacters(
                in: .whitespacesAndNewlines
            ).isEmpty else {
                throw ProductionGraphValidationError
                    .emptyNodeName(node.id)
            }
            guard node.depth >= 0 else {
                throw ProductionGraphValidationError.invalidDepth(node.id)
            }
            guard node.depth <= maximumValidatedDepth else {
                throw ProductionGraphValidationError
                    .maximumDepthExceeded(maximumValidatedDepth)
            }
            switch (node.kind, node.recipe) {
            case (.material, nil):
                break
            case (.target, .some), (.intermediate, .some):
                break
            default:
                throw ProductionGraphValidationError
                    .invalidNodeKind(node.id)
            }
            if let recipe = node.recipe {
                guard recipe.blueprintTypeID > 0,
                      recipe.outputQuantityPerRun > 0,
                      recipe.timeSeconds >= 0,
                      recipe.maxProductionLimit.map({ $0 > 0 }) ?? true else {
                    throw ProductionGraphValidationError
                        .invalidRecipe(node.id)
                }
            }
            if formatVersion >= t1RecursiveFormatVersion {
                switch node.kind {
                case .material:
                    guard node.leafReason != nil else {
                        throw ProductionGraphValidationError
                            .missingLeafReason(node.id)
                    }
                    guard node.recipe == nil else {
                        throw ProductionGraphValidationError
                            .invalidNodeKind(node.id)
                    }
                    if formatVersion >= reactionFormatVersion,
                       node.leafReason != .noProductionRecipe {
                        throw ProductionGraphValidationError
                            .unexpectedLeafReason(node.id)
                    }
                case .target, .intermediate:
                    guard node.leafReason == nil else {
                        throw ProductionGraphValidationError
                            .unexpectedLeafReason(node.id)
                    }
                    guard let recipe = node.recipe,
                          let efficiency = recipe.materialEfficiency,
                          recipe.materialEfficiencySource != nil else {
                        throw ProductionGraphValidationError
                            .missingRecipeMaterialEfficiency(node.id)
                    }
                    guard (0...10).contains(efficiency) else {
                        throw ProductionGraphValidationError
                            .invalidRecipeMaterialEfficiency(node.id)
                    }
                    let hasValidSource: Bool
                    if formatVersion == t1RecursiveFormatVersion {
                        switch node.kind {
                        case .target:
                            hasValidSource =
                                recipe.materialEfficiencySource
                                    == .projectBlueprint
                                && efficiency
                                    == blueprintMaterialEfficiency
                        case .intermediate:
                            hasValidSource =
                                recipe.materialEfficiencySource
                                    == .neutralIntermediate
                                && efficiency == 0
                        case .material:
                            hasValidSource = false
                        }
                    } else {
                        hasValidSource = recipe.materialEfficiencySource
                            != nil
                    }
                    guard hasValidSource else {
                        throw ProductionGraphValidationError
                            .invalidRecipeMaterialEfficiencySource(
                                node.id
                            )
                    }
                    if formatVersion >= t2FormatVersion {
                        if recipe.activity == .reaction,
                           formatVersion >= reactionFormatVersion {
                            guard efficiency == 0,
                                  recipe.materialEfficiencySource
                                    == .reactionFormula,
                                  recipe.techLevel == nil,
                                  recipe.blueprintPlanningQuality == nil,
                                  recipe.invention == nil,
                                  recipe.reactionKind != nil,
                                  let reactorID =
                                    recipe.requiredReactorTypeID,
                                  reactorID > 0,
                                  let context = recipe.reactionContext,
                                  let time =
                                    recipe.reactionTimeCalculation,
                                  context.ruleVersion
                                    == ReactionRuleProfile.currentVersion,
                                  context.catalogBuildNumber
                                    == catalogBuildNumber,
                                  context.catalogContentSHA256
                                    == catalogContentSHA256,
                                  time.context == context,
                                  time.baseTimeSeconds
                                    == recipe.timeSeconds,
                                  time.requiredRuns
                                    == node.runCalculation?.requiredRuns,
                                  (try? time.validatedCopy()) == time else {
                                throw ProductionGraphValidationError
                                    .invalidReactionProvenance(node.id)
                            }
                        } else {
                            guard let techLevel = recipe.techLevel,
                                  let quality =
                                    recipe.blueprintPlanningQuality else {
                                throw ProductionGraphValidationError
                                    .missingIndustryProvenance(node.id)
                            }
                            guard quality.blueprintTypeID
                                    == recipe.blueprintTypeID,
                                  quality.materialEfficiency == efficiency,
                                  quality.ruleVersion
                                    == IndustryRuleSet.currentVersion,
                                  quality.catalogBuildNumber
                                    == catalogBuildNumber,
                                  quality.catalogContentSHA256
                                    == catalogContentSHA256,
                                  recipe.reactionKind == nil,
                                  recipe.requiredReactorTypeID == nil,
                                  recipe.reactionContext == nil,
                                  recipe.reactionTimeCalculation == nil else {
                                throw ProductionGraphValidationError
                                    .invalidIndustryProvenance(node.id)
                            }
                            switch techLevel {
                        case .techI:
                            guard recipe.invention == nil,
                                  quality.origin
                                    == .manualPlanningAssumption,
                                  recipe.materialEfficiencySource
                                    == (node.kind == .target
                                        ? .projectBlueprint
                                        : .neutralIntermediate) else {
                                throw ProductionGraphValidationError
                                    .invalidIndustryProvenance(node.id)
                            }
                        case .techII:
                            switch quality.origin {
                            case .inventedBPC:
                                guard let invention = recipe.invention,
                                      invention.sourceBlueprintTypeID > 0,
                                      invention.baseProbabilityMillionths
                                        > 0,
                                      invention.baseProbabilityMillionths
                                        <= 1_000_000,
                                      invention.baseLicensedRuns > 0,
                                      invention.licensedRunsPerCopy > 0,
                                      invention.requiredSuccessfulCopies
                                        > 0,
                                      recipe.materialEfficiencySource
                                        == .regularT2Invention
                                        || recipe.materialEfficiencySource
                                            == .t2StageOverride else {
                                    throw ProductionGraphValidationError
                                        .invalidInventionReference(node.id)
                                }
                            case .legacyT2BPO, .copiedFromBPO:
                                guard recipe.invention == nil,
                                      recipe.materialEfficiencySource
                                        == .t2StageOverride else {
                                    throw ProductionGraphValidationError
                                        .invalidIndustryProvenance(node.id)
                                }
                            case .researchedBPO,
                                 .manualPlanningAssumption:
                                throw ProductionGraphValidationError
                                    .invalidIndustryProvenance(node.id)
                            }
                        }
                        }
                    } else if recipe.invention != nil {
                        throw ProductionGraphValidationError
                            .unexpectedRecipeMaterialEfficiency(node.id)
                    }
                }
            } else {
                guard node.leafReason == nil else {
                    throw ProductionGraphValidationError
                        .unexpectedLeafReason(node.id)
                }
                guard node.recipe?.materialEfficiency == nil,
                      node.recipe?.materialEfficiencySource == nil else {
                    throw ProductionGraphValidationError
                        .unexpectedRecipeMaterialEfficiency(node.id)
                }
            }
            switch formatVersion {
            case legacyFormatVersion:
                guard node.runCalculation == nil else {
                    throw ProductionGraphValidationError
                        .unexpectedRunCalculation(node.id)
                }
            case runOutputFormatVersion,
                 materialEfficiencyFormatVersion,
                 t1RecursiveFormatVersion,
                 t2FormatVersion,
                 reactionFormatVersion,
                 currentFormatVersion:
                switch (node.recipe, node.runCalculation) {
                case (.none, .none):
                    break
                case let (.some(recipe), .some(calculation)):
                    guard calculation.outputQuantityPerRun
                            == recipe.outputQuantityPerRun else {
                        throw ProductionGraphValidationError
                            .runCalculationOutputMismatch(node.id)
                    }
                case (.some, .none):
                    throw ProductionGraphValidationError
                        .missingRunCalculation(node.id)
                case (.none, .some):
                    throw ProductionGraphValidationError
                        .unexpectedRunCalculation(node.id)
                }
            default:
                throw ProductionGraphValidationError
                    .unsupportedFormatVersion(formatVersion)
            }
            nodesByID[node.id] = node
        }

        guard let root = nodesByID[rootNodeID],
              root.kind == .target,
              root.depth == 0 else {
            throw ProductionGraphValidationError.invalidRoot(rootNodeID)
        }
        guard nodes.filter({ $0.kind == .target }).count == 1 else {
            throw ProductionGraphValidationError.multipleTargetNodes
        }
        guard root.typeID == targetProductTypeID,
              root.recipe?.blueprintTypeID == targetBlueprintTypeID,
              root.recipe?.activity == targetActivity else {
            throw ProductionGraphValidationError.targetProvenanceMismatch
        }
        if formatVersion >= t2FormatVersion,
           root.recipe?.materialEfficiency
            != blueprintMaterialEfficiency {
            throw ProductionGraphValidationError
                .targetProvenanceMismatch
        }
        if formatVersion >= runOutputFormatVersion,
           root.runCalculation?.requestedOutputQuantity
            != Int64(projectTargetQuantity) {
            throw ProductionGraphValidationError
                .runCalculationTargetMismatch(root.id)
        }

        var incomingCount: [ProductionGraphNodeID: Int] = [:]
        var children: [ProductionGraphNodeID: [ProductionGraphNodeID]] = [:]
        var parentByChild: [
            ProductionGraphNodeID: ProductionGraphNodeID
        ] = [:]
        var siblingSortOrders: [
            ProductionGraphNodeID: Set<Int>
        ] = [:]
        for edge in edges {
            guard let parent = nodesByID[edge.parentID] else {
                throw ProductionGraphValidationError
                    .missingEdgeEndpoint(edge.parentID)
            }
            guard let child = nodesByID[edge.childID] else {
                throw ProductionGraphValidationError
                    .missingEdgeEndpoint(edge.childID)
            }
            guard edge.parentID != edge.childID else {
                throw ProductionGraphValidationError.selfEdge(edge.parentID)
            }
            guard edge.baseQuantityPerRun > 0 else {
                throw ProductionGraphValidationError
                    .invalidEdgeQuantity(edge.childID)
            }
            guard edge.sortOrder >= 0 else {
                throw ProductionGraphValidationError
                    .invalidEdgeSortOrder(edge.childID)
            }
            guard siblingSortOrders[
                edge.parentID,
                default: []
            ].insert(edge.sortOrder).inserted else {
                throw ProductionGraphValidationError
                    .duplicateSiblingSortOrder(
                        parentID: edge.parentID,
                        sortOrder: edge.sortOrder
                    )
            }
            guard parent.recipe != nil else {
                throw ProductionGraphValidationError
                    .invalidNodeKind(parent.id)
            }
            switch formatVersion {
            case legacyFormatVersion, runOutputFormatVersion:
                guard edge.materialCalculation == nil else {
                    throw ProductionGraphValidationError
                        .unexpectedMaterialCalculation(child.id)
                }
            case materialEfficiencyFormatVersion,
                 t1RecursiveFormatVersion,
                 t2FormatVersion,
                 reactionFormatVersion,
                 currentFormatVersion:
                guard let calculation = edge.materialCalculation else {
                    throw ProductionGraphValidationError
                        .missingMaterialCalculation(child.id)
                }
                guard calculation.baseQuantityPerRun
                        == edge.baseQuantityPerRun else {
                    throw ProductionGraphValidationError
                        .materialCalculationBaseMismatch(child.id)
                }
                guard calculation.requiredRuns
                        == parent.runCalculation?.requiredRuns else {
                    throw ProductionGraphValidationError
                        .materialCalculationRunsMismatch(child.id)
                }
                guard calculation.activity
                        == parent.recipe?.activity else {
                    throw ProductionGraphValidationError
                        .materialCalculationActivityMismatch(child.id)
                }
                if formatVersion == materialEfficiencyFormatVersion {
                    if parent.id == rootNodeID,
                       calculation.materialEfficiency
                        != blueprintMaterialEfficiency {
                        throw ProductionGraphValidationError
                            .materialCalculationEfficiencyMismatch(
                                child.id
                            )
                    }
                } else {
                    guard calculation.materialEfficiency
                            == parent.recipe?.materialEfficiency else {
                        throw ProductionGraphValidationError
                            .materialCalculationEfficiencyMismatch(
                                child.id
                            )
                    }
                    if child.kind == .intermediate,
                       child.runCalculation?.requestedOutputQuantity
                        != (
                            edge.reactionMaterialCalculation?
                                .effectiveQuantity
                                ?? calculation.effectiveQuantity
                        ) {
                        throw ProductionGraphValidationError
                            .runCalculationIncomingQuantityMismatch(
                                child.id
                            )
                    }
                    if formatVersion >= reactionFormatVersion,
                       parent.recipe?.activity == .reaction {
                        guard let reaction =
                                edge.reactionMaterialCalculation,
                              reaction.baseQuantityPerRun
                                == edge.baseQuantityPerRun,
                              reaction.requiredRuns
                                == parent.runCalculation?.requiredRuns,
                              reaction.context
                                == parent.recipe?.reactionContext,
                              (try? reaction.validatedCopy())
                                == reaction else {
                            throw ProductionGraphValidationError
                                .reactionMaterialCalculationMismatch(
                                    child.id
                                )
                        }
                    } else if edge.reactionMaterialCalculation != nil {
                        throw ProductionGraphValidationError
                            .unexpectedReactionMaterialCalculation(
                                child.id
                            )
                    }
                }
            default:
                throw ProductionGraphValidationError
                    .unsupportedFormatVersion(formatVersion)
            }
            incomingCount[child.id, default: 0] += 1
            if incomingCount[child.id, default: 0] > 1 {
                throw ProductionGraphValidationError
                    .duplicateIncomingEdge(child.id)
            }
            parentByChild[child.id] = parent.id
            children[parent.id, default: []].append(child.id)
        }

        guard incomingCount[rootNodeID, default: 0] == 0 else {
            throw ProductionGraphValidationError.rootHasIncomingEdge
        }
        for node in nodes where node.id != rootNodeID {
            guard incomingCount[node.id, default: 0] == 1 else {
                throw ProductionGraphValidationError
                    .missingIncomingEdge(node.id)
            }
        }

        var cycleChecked: Set<ProductionGraphNodeID> = [rootNodeID]
        for node in nodes where !cycleChecked.contains(node.id) {
            var current = node.id
            var currentPath: Set<ProductionGraphNodeID> = []
            while !cycleChecked.contains(current) {
                guard currentPath.insert(current).inserted else {
                    throw ProductionGraphValidationError
                        .cycleDetected(current)
                }
                guard let parent = parentByChild[current] else {
                    break
                }
                current = parent
            }
            cycleChecked.formUnion(currentPath)
        }
        for edge in edges {
            guard let parent = nodesByID[edge.parentID],
                  let child = nodesByID[edge.childID],
                  child.depth == parent.depth + 1 else {
                throw ProductionGraphValidationError
                    .invalidEdgeDepth(edge.childID)
            }
        }

        var reachable: Set<ProductionGraphNodeID> = []
        var pending = [rootNodeID]
        while let current = pending.popLast() {
            guard reachable.insert(current).inserted else {
                continue
            }
            pending.append(contentsOf: children[current, default: []])
        }
        if let unreachable = nodes.first(where: {
            !reachable.contains($0.id)
        }) {
            throw ProductionGraphValidationError
                .unreachableNode(unreachable.id)
        }

        if formatVersion >= currentFormatVersion {
            guard let materialAggregation else {
                throw ProductionGraphValidationError
                    .missingMaterialAggregation
            }
            guard materialAggregation.formulaVersion
                    == ProductionGraphMaterialAggregation
                        .currentFormulaVersion else {
                throw ProductionGraphValidationError
                    .unsupportedMaterialAggregationFormulaVersion(
                        materialAggregation.formulaVersion
                    )
            }
            let expected: ProductionGraphMaterialAggregation
            do {
                expected = try ProductionGraphMaterialAggregator()
                    .aggregate(
                        rootNodeID: rootNodeID,
                        nodes: nodes,
                        edges: edges
                    )
            } catch let error as
                ProductionGraphMaterialAggregationError {
                throw ProductionGraphValidationError
                    .materialAggregationCalculationFailed(error)
            }
            guard materialAggregation == expected else {
                throw ProductionGraphValidationError
                    .materialAggregationMismatch
            }
        } else if materialAggregation != nil {
            throw ProductionGraphValidationError
                .unexpectedMaterialAggregation
        }
    }

    private static func nodeSort(
        _ lhs: ProductionGraphNode,
        _ rhs: ProductionGraphNode
    ) -> Bool {
        if lhs.depth != rhs.depth {
            return lhs.depth < rhs.depth
        }
        return lhs.id.rawValue < rhs.id.rawValue
    }

    private static func edgeSort(
        _ lhs: ProductionGraphEdge,
        _ rhs: ProductionGraphEdge
    ) -> Bool {
        if lhs.parentID != rhs.parentID {
            return lhs.parentID.rawValue < rhs.parentID.rawValue
        }
        if lhs.sortOrder != rhs.sortOrder {
            return lhs.sortOrder < rhs.sortOrder
        }
        return lhs.childID.rawValue < rhs.childID.rawValue
    }
}
