import Foundation

public enum ISKAmountValidationError: Error, Equatable, Sendable {
    case empty
    case invalidCharacters
    case invalidFractionDigits
    case notPositive
    case overflow
}

public struct ISKAmount:
    Hashable,
    Comparable,
    Codable,
    Sendable
{
    public static let scale: Int64 = 100

    public let hundredths: Int64

    public init(hundredths: Int64) throws {
        guard hundredths > 0 else {
            throw ISKAmountValidationError.notPositive
        }
        self.hundredths = hundredths
    }

    public static func parse(_ text: String) throws -> ISKAmount {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else {
            throw ISKAmountValidationError.empty
        }
        guard !value.contains(".") || !value.contains(",") else {
            throw ISKAmountValidationError.invalidCharacters
        }
        let separator: Character? = value.contains(",") ? "," :
            (value.contains(".") ? "." : nil)
        let parts: [Substring]
        if let separator {
            parts = value.split(
                separator: separator,
                omittingEmptySubsequences: false
            )
        } else {
            parts = [Substring(value)]
        }
        guard parts.count <= 2,
              let wholeText = parts.first,
              !wholeText.isEmpty,
              wholeText.allSatisfy(\.isNumber) else {
            throw ISKAmountValidationError.invalidCharacters
        }
        let fractionText = parts.count == 2 ? parts[1] : Substring()
        guard parts.count == 1
                || (!fractionText.isEmpty && fractionText.count <= 2)
        else {
            throw ISKAmountValidationError.invalidFractionDigits
        }
        guard fractionText.allSatisfy(\.isNumber) else {
            throw ISKAmountValidationError.invalidCharacters
        }
        guard let whole = Int64(wholeText) else {
            throw ISKAmountValidationError.overflow
        }
        let (scaledWhole, didOverflow) = whole.multipliedReportingOverflow(
            by: Self.scale
        )
        guard !didOverflow else {
            throw ISKAmountValidationError.overflow
        }
        let fraction: Int64
        switch fractionText.count {
        case 0:
            fraction = 0
        case 1:
            guard let digit = Int64(fractionText) else {
                throw ISKAmountValidationError.invalidCharacters
            }
            fraction = digit * 10
        default:
            guard let digits = Int64(fractionText) else {
                throw ISKAmountValidationError.invalidCharacters
            }
            fraction = digits
        }
        let (amount, additionOverflow) = scaledWhole.addingReportingOverflow(
            fraction
        )
        guard !additionOverflow else {
            throw ISKAmountValidationError.overflow
        }
        return try ISKAmount(hundredths: amount)
    }

    public var displayText: String {
        let whole = hundredths / Self.scale
        let fraction = hundredths % Self.scale
        return "\(whole).\(String(format: "%02lld", fraction))"
    }

    public static func < (lhs: ISKAmount, rhs: ISKAmount) -> Bool {
        lhs.hundredths < rhs.hundredths
    }
}

public enum PriceCurrency: String, Codable, Sendable {
    case isk = "ISK"
}

public enum PriceSource: String, Codable, Sendable {
    case manual
    case csv
    case esiMarket = "esi_market"
}

public enum PriceProfileValidationError: Error, Equatable, Sendable {
    case emptyName
    case updatedBeforeCreation
    case invalidTypeID(Int64)
    case emptyItemName
    case invalidCatalogBuildNumber(Int)
    case emptyCatalogContentSHA256
    case invalidValidityRange
}

public struct PriceProfileSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let name: String
    public let currency: PriceCurrency
    public let isActive: Bool
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        name: String,
        currency: PriceCurrency = .isk,
        isActive: Bool,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        let normalizedName = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard !normalizedName.isEmpty else {
            throw PriceProfileValidationError.emptyName
        }
        guard createdAt <= updatedAt else {
            throw PriceProfileValidationError.updatedBeforeCreation
        }
        self.id = id
        self.name = normalizedName
        self.currency = currency
        self.isActive = isActive
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct ManualPriceSnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let profileID: UUID
    public let typeID: Int64
    public let itemName: String
    public let amount: ISKAmount
    public let source: PriceSource
    public let validFrom: Date
    public let validUntil: Date?
    public let catalogBuildNumber: Int
    public let catalogContentSHA256: String
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        profileID: UUID,
        typeID: Int64,
        itemName: String,
        amount: ISKAmount,
        source: PriceSource = .manual,
        validFrom: Date,
        validUntil: Date?,
        catalogBuildNumber: Int,
        catalogContentSHA256: String,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        let normalizedName = itemName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let normalizedHash = catalogContentSHA256.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        guard typeID > 0 else {
            throw PriceProfileValidationError.invalidTypeID(typeID)
        }
        guard !normalizedName.isEmpty else {
            throw PriceProfileValidationError.emptyItemName
        }
        guard catalogBuildNumber > 0 else {
            throw PriceProfileValidationError.invalidCatalogBuildNumber(
                catalogBuildNumber
            )
        }
        guard !normalizedHash.isEmpty else {
            throw PriceProfileValidationError.emptyCatalogContentSHA256
        }
        guard validUntil.map({ validFrom < $0 }) ?? true else {
            throw PriceProfileValidationError.invalidValidityRange
        }
        guard createdAt <= updatedAt else {
            throw PriceProfileValidationError.updatedBeforeCreation
        }
        self.id = id
        self.profileID = profileID
        self.typeID = typeID
        self.itemName = normalizedName
        self.amount = amount
        self.source = source
        self.validFrom = validFrom
        self.validUntil = validUntil
        self.catalogBuildNumber = catalogBuildNumber
        self.catalogContentSHA256 = normalizedHash
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    public func isValid(at date: Date) -> Bool {
        validFrom <= date && (validUntil.map { date < $0 } ?? true)
    }
}

public struct PriceResolution: Equatable, Sendable {
    public let profile: PriceProfileSnapshot?
    public let pricesByTypeID: [Int64: ISKAmount]
    public let missingTypeIDs: [Int64]

    public init(
        profile: PriceProfileSnapshot?,
        pricesByTypeID: [Int64: ISKAmount],
        missingTypeIDs: [Int64]
    ) {
        self.profile = profile
        self.pricesByTypeID = pricesByTypeID
        self.missingTypeIDs = missingTypeIDs
    }
}
