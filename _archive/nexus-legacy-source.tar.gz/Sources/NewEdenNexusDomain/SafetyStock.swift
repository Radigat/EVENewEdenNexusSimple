import Foundation

public enum SafetyStockPolicyValidationError:
    Error,
    Equatable,
    Sendable
{
    case invalidTypeID(Int64)
    case negativeSafetyStock(Int64)
    case negativeMinimum(Int64)
    case negativeWarning(Int64)
    case negativeTarget(Int64)
    case updatedBeforeCreation
}

public struct SafetyStockPolicySnapshot:
    Identifiable,
    Equatable,
    Sendable
{
    public let id: UUID
    public let typeID: Int64
    public let safetyStockQuantity: Int64
    public let minimumQuantity: Int64?
    public let warningQuantity: Int64?
    public let targetQuantity: Int64?
    public let createdAt: Date
    public let updatedAt: Date

    public init(
        id: UUID,
        typeID: Int64,
        safetyStockQuantity: Int64,
        minimumQuantity: Int64?,
        warningQuantity: Int64?,
        targetQuantity: Int64?,
        createdAt: Date,
        updatedAt: Date
    ) throws {
        guard typeID > 0 else {
            throw SafetyStockPolicyValidationError.invalidTypeID(typeID)
        }
        guard safetyStockQuantity >= 0 else {
            throw SafetyStockPolicyValidationError
                .negativeSafetyStock(safetyStockQuantity)
        }
        if let minimumQuantity, minimumQuantity < 0 {
            throw SafetyStockPolicyValidationError
                .negativeMinimum(minimumQuantity)
        }
        if let warningQuantity, warningQuantity < 0 {
            throw SafetyStockPolicyValidationError
                .negativeWarning(warningQuantity)
        }
        if let targetQuantity, targetQuantity < 0 {
            throw SafetyStockPolicyValidationError
                .negativeTarget(targetQuantity)
        }
        guard createdAt <= updatedAt else {
            throw SafetyStockPolicyValidationError.updatedBeforeCreation
        }
        self.id = id
        self.typeID = typeID
        self.safetyStockQuantity = safetyStockQuantity
        self.minimumQuantity = minimumQuantity
        self.warningQuantity = warningQuantity
        self.targetQuantity = targetQuantity
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public enum SafetyStockAlertKind:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case safetyStock
    case minimum
    case warning
    case target

    public var priority: Int {
        switch self {
        case .safetyStock: 0
        case .minimum: 1
        case .warning: 2
        case .target: 3
        }
    }
}

public struct SafetyStockAlert: Equatable, Sendable {
    public let kind: SafetyStockAlertKind
    public let thresholdQuantity: Int64
    public let projectedQuantity: Int64
    public let shortfallQuantity: Int64

    public init(
        kind: SafetyStockAlertKind,
        thresholdQuantity: Int64,
        projectedQuantity: Int64,
        shortfallQuantity: Int64
    ) {
        self.kind = kind
        self.thresholdQuantity = thresholdQuantity
        self.projectedQuantity = projectedQuantity
        self.shortfallQuantity = shortfallQuantity
    }
}

public struct SafetyStockLine: Equatable, Sendable {
    public let availability: InventoryAvailabilityLine
    public let policy: SafetyStockPolicySnapshot?
    public let activeOutsideP22Quantity: Int64
    public let safetyCoveredOutsideP22Quantity: Int64
    public let protectedFromP22Quantity: Int64
    public let availableAfterSafetyStockQuantity: Int64
    public let usableQuantity: Int64
    public let uncoveredQuantity: Int64
    public let projectedActiveRemainingQuantity: Int64
    public let targetReplenishmentQuantity: Int64
    public let alerts: [SafetyStockAlert]

    public var primaryAlert: SafetyStockAlert? {
        alerts.min { $0.kind.priority < $1.kind.priority }
    }
}

public struct SafetyStockCalculation: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let lines: [SafetyStockLine]

    public init(
        formulaVersion: Int = Self.currentFormulaVersion,
        lines: [SafetyStockLine]
    ) {
        self.formulaVersion = formulaVersion
        self.lines = lines
    }

    public var protectedMaterialCount: Int {
        lines.filter { $0.protectedFromP22Quantity > 0 }.count
    }

    public var warningMaterialCount: Int {
        lines.filter { !$0.alerts.isEmpty }.count
    }

    public var fullyCoveredMaterialCount: Int {
        lines.filter { $0.uncoveredQuantity == 0 }.count
    }
}

public enum SafetyStockCalculationError:
    Error,
    Equatable,
    Sendable
{
    case duplicateAvailabilityTypeID(Int64)
    case duplicatePolicyTypeID(Int64)
    case invalidAvailabilityLine(Int64)
}

public struct SafetyStockCalculator: Sendable {
    public init() {}

    public func calculate(
        availability: InventoryAvailabilityCalculation,
        policies: [SafetyStockPolicySnapshot]
    ) throws -> SafetyStockCalculation {
        var linesByTypeID: [Int64: InventoryAvailabilityLine] = [:]
        for line in availability.lines {
            guard line.typeID > 0,
                  line.requiredQuantity > 0,
                  line.activePhysicalQuantity >= 0,
                  line.eligiblePhysicalQuantity >= 0,
                  line.eligiblePhysicalQuantity
                    <= line.activePhysicalQuantity else {
                throw SafetyStockCalculationError
                    .invalidAvailabilityLine(line.typeID)
            }
            guard linesByTypeID[line.typeID] == nil else {
                throw SafetyStockCalculationError
                    .duplicateAvailabilityTypeID(line.typeID)
            }
            linesByTypeID[line.typeID] = line
        }

        var policiesByTypeID: [Int64: SafetyStockPolicySnapshot] = [:]
        for policy in policies {
            guard policiesByTypeID[policy.typeID] == nil else {
                throw SafetyStockCalculationError
                    .duplicatePolicyTypeID(policy.typeID)
            }
            policiesByTypeID[policy.typeID] = policy
        }

        let result = try linesByTypeID.values.map { line in
            try calculate(
                line: line,
                policy: policiesByTypeID[line.typeID]
            )
        }.sorted {
            let left = normalizedName($0.availability.name)
            let right = normalizedName($1.availability.name)
            return left == right
                ? $0.availability.typeID < $1.availability.typeID
                : left < right
        }
        return SafetyStockCalculation(lines: result)
    }

    private func calculate(
        line: InventoryAvailabilityLine,
        policy: SafetyStockPolicySnapshot?
    ) throws -> SafetyStockLine {
        let outside = line.activePhysicalQuantity
            - line.eligiblePhysicalQuantity
        let safety = policy?.safetyStockQuantity ?? 0
        let coveredOutside = min(safety, outside)
        let remainingSafety = safety - coveredOutside
        let protected = min(
            line.eligiblePhysicalQuantity,
            remainingSafety
        )
        let available = line.eligiblePhysicalQuantity - protected
        let usable = min(line.requiredQuantity, available)
        let uncovered = line.requiredQuantity - usable
        let projectedRemaining = line.activePhysicalQuantity - usable
        let targetReplenishment = shortfall(
            threshold: policy?.targetQuantity,
            actual: projectedRemaining
        )
        let alerts = alerts(
            policy: policy,
            projectedRemaining: projectedRemaining
        )
        return SafetyStockLine(
            availability: line,
            policy: policy,
            activeOutsideP22Quantity: outside,
            safetyCoveredOutsideP22Quantity: coveredOutside,
            protectedFromP22Quantity: protected,
            availableAfterSafetyStockQuantity: available,
            usableQuantity: usable,
            uncoveredQuantity: uncovered,
            projectedActiveRemainingQuantity: projectedRemaining,
            targetReplenishmentQuantity: targetReplenishment,
            alerts: alerts
        )
    }

    private func alerts(
        policy: SafetyStockPolicySnapshot?,
        projectedRemaining: Int64
    ) -> [SafetyStockAlert] {
        guard let policy else { return [] }
        let thresholds: [(SafetyStockAlertKind, Int64?)] = [
            (.safetyStock, policy.safetyStockQuantity),
            (.minimum, policy.minimumQuantity),
            (.warning, policy.warningQuantity),
            (.target, policy.targetQuantity)
        ]
        return thresholds.compactMap { kind, threshold in
            guard let threshold,
                  projectedRemaining < threshold else {
                return nil
            }
            return SafetyStockAlert(
                kind: kind,
                thresholdQuantity: threshold,
                projectedQuantity: projectedRemaining,
                shortfallQuantity: threshold - projectedRemaining
            )
        }.sorted { $0.kind.priority < $1.kind.priority }
    }

    private func shortfall(
        threshold: Int64?,
        actual: Int64
    ) -> Int64 {
        guard let threshold, actual < threshold else { return 0 }
        return threshold - actual
    }

    private func normalizedName(_ name: String) -> String {
        name.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "en_US_POSIX")
        )
    }
}
