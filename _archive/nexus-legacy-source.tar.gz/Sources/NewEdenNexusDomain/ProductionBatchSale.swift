import Foundation

public enum ProductionBatchSaleEvidenceSource:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case walletTransaction = "wallet_transaction"
    case walletJournal = "wallet_journal"
    case manual
}

public enum ProductionBatchSaleAllocationKind:
    String,
    Codable,
    CaseIterable,
    Sendable
{
    case sale
    case fee
}

public struct ProductionBatchSaleAllocationSnapshot:
    Identifiable,
    Equatable,
    Codable,
    Sendable
{
    public static let currentContractVersion = 1

    public let id: UUID
    public let batchID: UUID
    public let projectID: UUID
    public let costSnapshotID: UUID
    public let contractVersion: Int
    public let kind: ProductionBatchSaleAllocationKind
    public let source: ProductionBatchSaleEvidenceSource
    public let projectAssignmentID: UUID?
    public let characterID: Int64?
    public let sourceID: Int64?
    public let sourceRevision: UUID?
    public let sourceObservedAt: Date
    public let quantity: Int64
    public let amountHundredths: Int64
    public let reason: String?
    public let createdAt: Date

    public init(
        id: UUID,
        batchID: UUID,
        projectID: UUID,
        costSnapshotID: UUID,
        contractVersion: Int = currentContractVersion,
        kind: ProductionBatchSaleAllocationKind,
        source: ProductionBatchSaleEvidenceSource,
        projectAssignmentID: UUID?,
        characterID: Int64?,
        sourceID: Int64?,
        sourceRevision: UUID?,
        sourceObservedAt: Date,
        quantity: Int64,
        amountHundredths: Int64,
        reason: String?,
        createdAt: Date
    ) throws {
        guard contractVersion > 0,
              amountHundredths > 0,
              sourceObservedAt <= createdAt else {
            throw ProductionBatchSaleError.invalidAllocation
        }
        switch kind {
        case .sale:
            guard quantity > 0 else {
                throw ProductionBatchSaleError.invalidAllocation
            }
        case .fee:
            guard quantity == 0 else {
                throw ProductionBatchSaleError.invalidAllocation
            }
        }
        let normalizedReason = reason?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        switch source {
        case .walletTransaction:
            guard kind == .sale,
                  projectAssignmentID != nil,
                  characterID.map({ $0 > 0 }) == true,
                  sourceID.map({ $0 > 0 }) == true,
                  sourceRevision != nil,
                  normalizedReason == nil else {
                throw ProductionBatchSaleError.invalidAllocation
            }
        case .walletJournal:
            guard kind == .fee,
                  projectAssignmentID != nil,
                  characterID.map({ $0 > 0 }) == true,
                  sourceID.map({ $0 > 0 }) == true,
                  sourceRevision != nil,
                  normalizedReason == nil else {
                throw ProductionBatchSaleError.invalidAllocation
            }
        case .manual:
            guard projectAssignmentID == nil,
                  characterID == nil,
                  sourceID == nil,
                  sourceRevision == nil,
                  let normalizedReason,
                  !normalizedReason.isEmpty,
                  normalizedReason.utf8.count <= 512,
                  normalizedReason.rangeOfCharacter(from: .newlines)
                    == nil else {
                throw ProductionBatchSaleError.invalidAllocation
            }
        }
        self.id = id
        self.batchID = batchID
        self.projectID = projectID
        self.costSnapshotID = costSnapshotID
        self.contractVersion = contractVersion
        self.kind = kind
        self.source = source
        self.projectAssignmentID = projectAssignmentID
        self.characterID = characterID
        self.sourceID = sourceID
        self.sourceRevision = sourceRevision
        self.sourceObservedAt = sourceObservedAt
        self.quantity = quantity
        self.amountHundredths = amountHundredths
        self.reason = normalizedReason
        self.createdAt = createdAt
    }
}

public struct ProductionBatchRealizedSummary:
    Equatable,
    Codable,
    Sendable
{
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let batchID: UUID
    public let costSnapshotID: UUID
    public let outputUnits: Int64
    public let soldUnits: Int64
    public let openUnits: Int64
    public let grossRevenue: ISKValue
    public let sellingFees: ISKValue
    public let realizedCost: ISKValue
    public let realizedProfit: ISKValue
    public let averageSaleUnitPrice: ISKValue?
    public let margin: ISKPercentage?
    public let roi: ISKPercentage?
    public let allocationCount: Int
}

public enum ProductionBatchSaleError:
    Error,
    Equatable,
    Sendable
{
    case invalidAllocation
    case duplicateAllocation(UUID)
    case mixedBatch
    case mixedCostSnapshot
    case invalidOutputUnits(Int64)
    case overSale
    case arithmeticOverflow
}

public struct ProductionBatchRealizedCalculator: Sendable {
    public init() {}

    public func calculate(
        batchID: UUID,
        costSnapshotID: UUID,
        outputUnits: Int64,
        totalCostHundredths: Int64,
        allocations: [ProductionBatchSaleAllocationSnapshot]
    ) throws -> ProductionBatchRealizedSummary {
        guard outputUnits > 0, totalCostHundredths >= 0 else {
            throw ProductionBatchSaleError.invalidOutputUnits(outputUnits)
        }
        guard Set(allocations.map(\.id)).count == allocations.count else {
            throw ProductionBatchSaleError.duplicateAllocation(
                allocations.first?.id ?? UUID()
            )
        }
        guard allocations.allSatisfy({ $0.batchID == batchID }) else {
            throw ProductionBatchSaleError.mixedBatch
        }
        guard allocations.allSatisfy({
            $0.costSnapshotID == costSnapshotID
        }) else {
            throw ProductionBatchSaleError.mixedCostSnapshot
        }

        let sales = allocations.filter { $0.kind == .sale }
        let fees = allocations.filter { $0.kind == .fee }
        let soldUnits = try sum(sales.map(\.quantity))
        guard soldUnits <= outputUnits else {
            throw ProductionBatchSaleError.overSale
        }
        let grossRevenue = try sum(sales.map(\.amountHundredths))
        let sellingFees = try sum(fees.map(\.amountHundredths))
        let costProduct = totalCostHundredths
            .multipliedReportingOverflow(by: soldUnits)
        guard !costProduct.overflow else {
            throw ProductionBatchSaleError.arithmeticOverflow
        }
        let realizedCost = soldUnits == outputUnits
            ? totalCostHundredths
            : costProduct.partialValue / outputUnits
        let afterCost = grossRevenue.subtractingReportingOverflow(
            realizedCost
        )
        guard !afterCost.overflow else {
            throw ProductionBatchSaleError.arithmeticOverflow
        }
        let profit = afterCost.partialValue.subtractingReportingOverflow(
            sellingFees
        )
        guard !profit.overflow else {
            throw ProductionBatchSaleError.arithmeticOverflow
        }
        let invested = realizedCost.addingReportingOverflow(sellingFees)
        guard !invested.overflow else {
            throw ProductionBatchSaleError.arithmeticOverflow
        }
        return ProductionBatchRealizedSummary(
            formulaVersion:
                ProductionBatchRealizedSummary.currentFormulaVersion,
            batchID: batchID,
            costSnapshotID: costSnapshotID,
            outputUnits: outputUnits,
            soldUnits: soldUnits,
            openUnits: outputUnits - soldUnits,
            grossRevenue: ISKValue(hundredths: grossRevenue),
            sellingFees: ISKValue(hundredths: sellingFees),
            realizedCost: ISKValue(hundredths: realizedCost),
            realizedProfit: ISKValue(hundredths: profit.partialValue),
            averageSaleUnitPrice: soldUnits > 0
                ? ISKValue(
                    hundredths: grossRevenue / soldUnits
                )
                : nil,
            margin: grossRevenue > 0
                ? try percentage(
                    profit.partialValue,
                    denominator: grossRevenue
                )
                : nil,
            roi: invested.partialValue > 0
                ? try percentage(
                    profit.partialValue,
                    denominator: invested.partialValue
                )
                : nil,
            allocationCount: allocations.count
        )
    }

    private func sum(_ values: [Int64]) throws -> Int64 {
        try values.reduce(Int64.zero) { partial, value in
            let result = partial.addingReportingOverflow(value)
            guard !result.overflow else {
                throw ProductionBatchSaleError.arithmeticOverflow
            }
            return result.partialValue
        }
    }

    private func percentage(
        _ numerator: Int64,
        denominator: Int64
    ) throws -> ISKPercentage {
        let scaled = numerator.multipliedReportingOverflow(by: 10_000)
        guard !scaled.overflow else {
            throw ProductionBatchSaleError.arithmeticOverflow
        }
        return ISKPercentage(
            basisPoints: scaled.partialValue / denominator
        )
    }
}
