import Foundation

public struct ShoppingQuantityOverride: Equatable, Sendable {
    public let typeID: Int64
    public let quantity: Int64

    public init(typeID: Int64, quantity: Int64) {
        self.typeID = typeID
        self.quantity = quantity
    }
}

public struct ShoppingListPosition: Equatable, Sendable {
    public let typeID: Int64
    public let name: String
    public let calculatedQuantity: Int64
    public let purchaseQuantity: Int64
    public let isOverridden: Bool
    public let sources: [BuildOrBuyRequirementSource]
}

public struct ShoppingListAggregation: Equatable, Sendable {
    public static let currentFormulaVersion = 1

    public let formulaVersion: Int
    public let positions: [ShoppingListPosition]
    public let effectivePositionCount: Int
    public let totalPurchaseQuantity: Int64

    public var effectivePositions: [ShoppingListPosition] {
        positions.filter { $0.purchaseQuantity > 0 }
    }

    public var textList: String {
        effectivePositions.map {
            "\($0.name)\t\($0.purchaseQuantity)"
        }.joined(separator: "\n")
    }
}

public enum ShoppingListAggregationError:
    Error,
    Equatable,
    Sendable
{
    case invalidRequirement(typeID: Int64)
    case conflictingName(typeID: Int64)
    case duplicateOverride(typeID: Int64)
    case invalidOverride(typeID: Int64, quantity: Int64)
    case unknownOverride(typeID: Int64)
    case arithmeticOverflow(typeID: Int64)
}

public struct ShoppingListAggregator: Sendable {
    public init() {}

    public func aggregate(
        requirements: [BuildOrBuyRequirementLine],
        overrides: [ShoppingQuantityOverride]
    ) throws -> ShoppingListAggregation {
        var accumulated: [Int64: Accumulator] = [:]
        for requirement in requirements {
            guard requirement.typeID > 0,
                  !requirement.name.trimmingCharacters(
                      in: .whitespacesAndNewlines
                  ).isEmpty,
                  requirement.requiredQuantity >= 0,
                  requirement.inventoryQuantity >= 0,
                  requirement.missingQuantity >= 0 else {
                throw ShoppingListAggregationError.invalidRequirement(
                    typeID: requirement.typeID
                )
            }
            let covered = requirement.inventoryQuantity
                .addingReportingOverflow(requirement.missingQuantity)
            guard !covered.overflow,
                  covered.partialValue == requirement.requiredQuantity else {
                throw ShoppingListAggregationError.invalidRequirement(
                    typeID: requirement.typeID
                )
            }
            guard requirement.sources.allSatisfy({
                $0.quantity >= 0
            }) else {
                throw ShoppingListAggregationError.invalidRequirement(
                    typeID: requirement.typeID
                )
            }
            guard requirement.missingQuantity > 0 else { continue }

            if var current = accumulated[requirement.typeID] {
                guard current.name == requirement.name else {
                    throw ShoppingListAggregationError.conflictingName(
                        typeID: requirement.typeID
                    )
                }
                let sum = current.calculatedQuantity
                    .addingReportingOverflow(
                        requirement.missingQuantity
                    )
                guard !sum.overflow else {
                    throw ShoppingListAggregationError
                        .arithmeticOverflow(typeID: requirement.typeID)
                }
                current.calculatedQuantity = sum.partialValue
                current.sources.append(contentsOf: requirement.sources)
                accumulated[requirement.typeID] = current
            } else {
                accumulated[requirement.typeID] = Accumulator(
                    typeID: requirement.typeID,
                    name: requirement.name,
                    calculatedQuantity: requirement.missingQuantity,
                    sources: requirement.sources
                )
            }
        }

        var overrideByTypeID: [Int64: Int64] = [:]
        for override in overrides {
            guard override.typeID > 0, override.quantity >= 0 else {
                throw ShoppingListAggregationError.invalidOverride(
                    typeID: override.typeID,
                    quantity: override.quantity
                )
            }
            guard accumulated[override.typeID] != nil else {
                throw ShoppingListAggregationError.unknownOverride(
                    typeID: override.typeID
                )
            }
            guard overrideByTypeID[override.typeID] == nil else {
                throw ShoppingListAggregationError.duplicateOverride(
                    typeID: override.typeID
                )
            }
            overrideByTypeID[override.typeID] = override.quantity
        }

        let positions = accumulated.values.map { value in
            let override = overrideByTypeID[value.typeID]
            return ShoppingListPosition(
                typeID: value.typeID,
                name: value.name,
                calculatedQuantity: value.calculatedQuantity,
                purchaseQuantity:
                    override ?? value.calculatedQuantity,
                isOverridden:
                    override != nil
                        && override != value.calculatedQuantity,
                sources: value.sources.sorted(by: sourceOrder)
            )
        }.sorted(by: positionOrder)

        var total: Int64 = 0
        for position in positions where position.purchaseQuantity > 0 {
            let sum = total.addingReportingOverflow(
                position.purchaseQuantity
            )
            guard !sum.overflow else {
                throw ShoppingListAggregationError.arithmeticOverflow(
                    typeID: position.typeID
                )
            }
            total = sum.partialValue
        }
        return ShoppingListAggregation(
            formulaVersion:
                ShoppingListAggregation.currentFormulaVersion,
            positions: positions,
            effectivePositionCount:
                positions.count { $0.purchaseQuantity > 0 },
            totalPurchaseQuantity: total
        )
    }

    private func positionOrder(
        _ lhs: ShoppingListPosition,
        _ rhs: ShoppingListPosition
    ) -> Bool {
        lhs.name == rhs.name
            ? lhs.typeID < rhs.typeID
            : lhs.name < rhs.name
    }

    private func sourceOrder(
        _ lhs: BuildOrBuyRequirementSource,
        _ rhs: BuildOrBuyRequirementSource
    ) -> Bool {
        if lhs.nodeID.rawValue != rhs.nodeID.rawValue {
            return lhs.nodeID.rawValue < rhs.nodeID.rawValue
        }
        if lhs.kind.rawValue != rhs.kind.rawValue {
            return lhs.kind.rawValue < rhs.kind.rawValue
        }
        return lhs.quantity < rhs.quantity
    }
}

private extension ShoppingListAggregator {
    struct Accumulator {
        let typeID: Int64
        let name: String
        var calculatedQuantity: Int64
        var sources: [BuildOrBuyRequirementSource]
    }
}
