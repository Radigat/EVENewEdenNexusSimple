#!/usr/bin/env python3

from __future__ import annotations

import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PACKAGE = ROOT / "Package.swift"
PROJECT_SPEC = ROOT / "project.yml"
PBXPROJ = ROOT / "NewEdenNexus.xcodeproj" / "project.pbxproj"
SCHEME_DIR = (
    ROOT
    / "NewEdenNexus.xcodeproj"
    / "xcshareddata"
    / "xcschemes"
)

EXPECTED_SCHEMES = {
    "NewEdenNexus.xcscheme",
    "NewEdenNexusSDEAcceptance.xcscheme",
}
EXPECTED_TEST_TARGETS = {
    "NewEdenNexusTests",
    "NewEdenNexusDomainTests",
    "NewEdenNexusApplicationTests",
    "NewEdenNexusInfrastructureTests",
    "NewEdenNexusArchitectureTests",
    "NewEdenNexusPersistenceTests",
    "NewEdenNexusTestSupportTests",
    "NewEdenNexusUITests",
}
XCODE_ONLY_TARGETS = {
    "NewEdenNexusUITests",
}
ALLOWED_XCODE_ONLY_SOURCES = {
    "Tests/NewEdenNexusUITests/P35AccessibilityUITests.swift",
    "XcodeSupport/NewEdenNexusTestSupportBundle.swift",
}


def fail(messages: list[str]) -> None:
    for message in messages:
        print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def package_targets(package_text: str) -> dict[str, str]:
    pattern = re.compile(
        r"\.(?:target|executableTarget|testTarget)\(\s*"
        r'name:\s*"(?P<name>[^"]+)".*?'
        r'path:\s*"(?P<path>[^"]+)"',
        re.DOTALL,
    )
    return {
        match.group("name"): match.group("path")
        for match in pattern.finditer(package_text)
    }


def declared_spec_targets(spec_text: str) -> set[str]:
    targets_block = spec_text.split("\ntargets:\n", 1)[1].split(
        "\nschemes:\n", 1
    )[0]
    return set(
        re.findall(r"^  ([A-Za-z0-9_]+):\s*$", targets_block, re.MULTILINE)
    )


def main() -> None:
    missing_paths = [
        str(path.relative_to(ROOT))
        for path in (PACKAGE, PROJECT_SPEC, PBXPROJ, SCHEME_DIR)
        if not path.exists()
    ]
    if missing_paths:
        fail([f"required path missing: {path}" for path in missing_paths])

    package_text = PACKAGE.read_text(encoding="utf-8")
    spec_text = PROJECT_SPEC.read_text(encoding="utf-8")
    project_text = PBXPROJ.read_text(encoding="utf-8")
    targets = package_targets(package_text)
    spec_targets = declared_spec_targets(spec_text)
    errors: list[str] = []

    expected_spec_targets = set(targets) | XCODE_ONLY_TARGETS
    if expected_spec_targets != spec_targets:
        missing = sorted(expected_spec_targets - spec_targets)
        extra = sorted(spec_targets - expected_spec_targets)
        if missing:
            errors.append(
                "Package targets missing from project.yml: "
                + ", ".join(missing)
            )
        if extra:
            errors.append(
                "Unexpected targets in project.yml: " + ", ".join(extra)
            )

    for target_name, source_path in targets.items():
        if target_name not in project_text:
            errors.append(f"target absent from project.pbxproj: {target_name}")
        directory = ROOT / source_path
        if not directory.is_dir():
            errors.append(f"Package target path missing: {source_path}")
            continue
        for source in sorted(directory.rglob("*.swift")):
            relative = source.relative_to(ROOT).as_posix()
            if source.name not in project_text:
                errors.append(f"Swift source absent from Xcode project: {relative}")

    for relative in ALLOWED_XCODE_ONLY_SOURCES:
        source = ROOT / relative
        if not source.is_file():
            errors.append(f"Xcode support source missing: {relative}")
        elif source.name not in project_text:
            errors.append(f"Xcode support source absent from project: {relative}")

    actual_schemes = {
        path.name for path in SCHEME_DIR.glob("*.xcscheme")
    }
    if actual_schemes != EXPECTED_SCHEMES:
        errors.append(
            "shared schemes differ: expected "
            f"{sorted(EXPECTED_SCHEMES)}, found {sorted(actual_schemes)}"
        )

    app_scheme = (SCHEME_DIR / "NewEdenNexus.xcscheme").read_text(
        encoding="utf-8"
    )
    for test_target in EXPECTED_TEST_TARGETS:
        if f'BlueprintName = "{test_target}"' not in app_scheme:
            errors.append(f"app scheme omits test target: {test_target}")

    combined_project_metadata = project_text + "\n" + "\n".join(
        path.read_text(encoding="utf-8")
        for path in SCHEME_DIR.glob("*.xcscheme")
    )
    prohibited_patterns = {
        "absolute user path": r"/Users/",
        "Apple development team": r"\bDEVELOPMENT_TEAM\b",
        "personal Xcode metadata": r"\bxcuserdata\b|\bxcuserstate\b",
    }
    for label, pattern in prohibited_patterns.items():
        if re.search(pattern, combined_project_metadata):
            errors.append(f"prohibited {label} found in project metadata")

    fixture_files = sorted(
        (ROOT / "Tests/NewEdenNexusTestSupport/Fixtures").rglob("*")
    )
    if not any(path.is_file() for path in fixture_files):
        errors.append("test fixture directory is empty")
    if "Tests/NewEdenNexusTestSupport/Fixtures" not in spec_text:
        errors.append("project.yml does not map the SwiftPM fixture directory")

    if errors:
        fail(errors)

    print(
        "Xcode project consistency verified: "
        f"{len(expected_spec_targets)} targets, "
        f"{len(EXPECTED_TEST_TARGETS)} test targets, "
        f"{len(EXPECTED_SCHEMES)} shared schemes."
    )


if __name__ == "__main__":
    main()
