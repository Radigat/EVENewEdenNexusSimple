#!/bin/zsh

set -euo pipefail

repository_root="${0:A:h:h}"
configuration_path="$repository_root/XcodeSupport/LocalSigning.xcconfig"
identity_output="$(
    security find-identity -p codesigning -v 2>/dev/null
)"
identity_lines=("${(@f)$(print -r -- "$identity_output" | \
    grep '"Apple Development:' || true)}")

if (( ${#identity_lines[@]} != 1 )); then
    print -u2 \
        "Expected exactly one valid Apple Development identity, found " \
        "${#identity_lines[@]}."
    exit 1
fi

identity_hash="$(
    print -r -- "$identity_lines[1]" | \
        sed -E 's/^[[:space:]]*[0-9]+\)[[:space:]]+([A-F0-9]+).*/\1/'
)"
if [[ -z "$identity_hash" || "$identity_hash" == "$identity_lines[1]" ]]; then
    print -u2 "Could not determine the signing identity."
    exit 1
fi
certificate_name="$(
    print -r -- "$identity_lines[1]" | \
        sed -E 's/^[^"]*"([^"]+)".*/\1/'
)"
certificate_subject="$(
    security find-certificate -c "$certificate_name" -p 2>/dev/null | \
        openssl x509 -noout -subject -nameopt RFC2253 2>/dev/null || true
)"
team_id="$(
    print -r -- "$certificate_subject" | \
        sed -E 's/.*OU=([^,]+).*/\1/'
)"
if [[ -z "$certificate_name" ||
      -z "$team_id" ||
      "$team_id" == "$certificate_subject" ]]; then
    print -u2 "Could not determine the development team from certificate OU."
    exit 1
fi

temporary_path="${configuration_path}.tmp.$$"
trap 'rm -f "$temporary_path"' EXIT

{
    print '// Local-only signing configuration. Do not commit.'
    print 'CODE_SIGNING_ALLOWED = YES'
    print 'CODE_SIGNING_REQUIRED = YES'
    print 'CODE_SIGN_STYLE = Manual'
    print "CODE_SIGN_IDENTITY = $identity_hash"
    print "DEVELOPMENT_TEAM = $team_id"
} > "$temporary_path"

chmod 600 "$temporary_path"
mv "$temporary_path" "$configuration_path"
trap - EXIT

print "Local Apple Development signing configured."
