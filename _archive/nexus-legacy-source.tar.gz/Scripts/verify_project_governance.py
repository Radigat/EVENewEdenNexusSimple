#!/usr/bin/env python3

from __future__ import annotations

import re
import sys
from pathlib import Path
from urllib.parse import unquote


ROOT = Path(__file__).resolve().parent.parent
DOCUMENTATION = ROOT / "Documentation"
PROMPT_REGISTER = DOCUMENTATION / "Prompts" / "README.md"
CANONICAL_PROJECT = ROOT / "NewEdenNexus.xcodeproj"
PROJECT_ARCHIVE = DOCUMENTATION / "Archive" / "XcodeProjects"
CANONICAL_P21 = DOCUMENTATION / "Prompts" / "MVP" / "P21_CSV-Bestandsimport.md"
ARCHIVED_P21 = (
    DOCUMENTATION / "Prompts" / "Archive" / "P21_CSV-Bestandsimport_Entwurf.md"
)

EXPECTED_PROMPT_IDS = {
    *(f"P{number:02d}" for number in range(49)),
    *(f"P{number:02d}" for number in range(50, 62)),
    "P07A",
    "P07B",
    "P07C",
    "P09A",
    "P09B",
}

AUTHORITATIVE_MARKDOWN = [
    ROOT / "AGENTS.md",
    DOCUMENTATION / "CURRENT_PROJECT_STATUS.md",
    DOCUMENTATION / "DEVELOPER_MENU.md",
    DOCUMENTATION / "FEATURE_MATRIX.md",
    DOCUMENTATION / "IMPLEMENTATION_ROADMAP.md",
    DOCUMENTATION / "KNOWN_ISSUES.md",
    DOCUMENTATION / "LEAN_MVP_PLAN.md",
    DOCUMENTATION / "OFFEN.md",
    DOCUMENTATION / "OPEN_TASKS.md",
    PROMPT_REGISTER,
    DOCUMENTATION
    / "Prompts"
    / "Future"
    / "P53_Steuerung-und-Xcode-Kanon-Bereinigung.md",
    DOCUMENTATION
    / "Prompts"
    / "Future"
    / "P54_Gepruefter-lokaler-Git-Sicherungspunkt.md",
]

STALE_CURRENT_PHRASES = {
    "P53-Dateiverschiebungen anhand der Einzelvorschau bestätigen oder ablehnen",
    "P53 ist aktiv und wartet vor Dateiverschiebungen",
    "P53 ist nach Eigentümerauftrag aktiv und wartet",
}


def fail(messages: list[str]) -> None:
    for message in messages:
        print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def markdown_targets(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    return [
        match.group(1).strip()
        for match in re.finditer(r"(?<!!)\[[^\]]+\]\(([^)]+)\)", text)
    ]


def resolved_markdown_target(source: Path, target: str) -> Path | None:
    target = target.split("#", 1)[0].strip()
    if not target or target.startswith(("http://", "https://", "mailto:")):
        return None
    if target.startswith("<") and target.endswith(">"):
        target = target[1:-1]
    return (source.parent / unquote(target)).resolve()


def main() -> None:
    errors: list[str] = []

    root_projects = sorted(ROOT.glob("NewEdenNexus*.xcodeproj"))
    if root_projects != [CANONICAL_PROJECT]:
        names = ", ".join(path.name for path in root_projects) or "none"
        errors.append(
            "repository root must contain only NewEdenNexus.xcodeproj; "
            f"found: {names}"
        )

    archived_projects = sorted(PROJECT_ARCHIVE.glob("NewEdenNexus *.xcodeproj"))
    expected_archive_names = {
        f"NewEdenNexus {number}.xcodeproj" for number in range(2, 11)
    }
    archive_names = {path.name for path in archived_projects}
    if archive_names != expected_archive_names:
        missing = sorted(expected_archive_names - archive_names)
        extra = sorted(archive_names - expected_archive_names)
        if missing:
            errors.append("archived Xcode projects missing: " + ", ".join(missing))
        if extra:
            errors.append("unexpected archived Xcode projects: " + ", ".join(extra))

    for required in (CANONICAL_P21, ARCHIVED_P21):
        if not required.is_file():
            errors.append(f"required prompt file missing: {required.relative_to(ROOT)}")
    duplicate_p21 = sorted(
        path
        for path in (DOCUMENTATION / "Prompts").rglob("P21* 2.md")
        if "Archive" not in path.parts
    )
    if duplicate_p21:
        errors.append(
            "active duplicate P21 prompt remains: "
            + ", ".join(str(path.relative_to(ROOT)) for path in duplicate_p21)
        )

    if not PROMPT_REGISTER.is_file():
        errors.append("prompt register is missing")
    else:
        register_text = PROMPT_REGISTER.read_text(encoding="utf-8")
        registered_ids = re.findall(r"^\| (P\d{2}[A-C]?) \|", register_text, re.MULTILINE)
        missing_ids = sorted(EXPECTED_PROMPT_IDS - set(registered_ids))
        duplicate_ids = sorted(
            prompt_id
            for prompt_id in set(registered_ids)
            if registered_ids.count(prompt_id) > 1
        )
        unexpected_ids = sorted(set(registered_ids) - EXPECTED_PROMPT_IDS)
        if missing_ids:
            errors.append("prompt IDs missing from register: " + ", ".join(missing_ids))
        if duplicate_ids:
            errors.append("duplicate prompt IDs in register: " + ", ".join(duplicate_ids))
        if unexpected_ids:
            errors.append(
                "unexpected prompt IDs in register: " + ", ".join(unexpected_ids)
            )

    checked_links = 0
    for source in AUTHORITATIVE_MARKDOWN:
        if not source.is_file():
            errors.append(f"authoritative document missing: {source.relative_to(ROOT)}")
            continue
        text = source.read_text(encoding="utf-8")
        for phrase in STALE_CURRENT_PHRASES:
            if phrase in text:
                errors.append(
                    f"stale current-state phrase in {source.relative_to(ROOT)}: "
                    f"{phrase}"
                )
        for target in markdown_targets(source):
            resolved = resolved_markdown_target(source, target)
            if resolved is None:
                continue
            checked_links += 1
            if not resolved.exists():
                errors.append(
                    f"broken link in {source.relative_to(ROOT)}: {target}"
                )

    if errors:
        fail(errors)

    print(
        "Project governance verified: one root Xcode project, "
        f"{len(archived_projects)} archived project copies, "
        f"{len(EXPECTED_PROMPT_IDS)} registered prompt IDs, "
        f"{checked_links} current documentation links."
    )


if __name__ == "__main__":
    main()
