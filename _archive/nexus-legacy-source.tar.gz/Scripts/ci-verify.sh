#!/bin/zsh

set -euo pipefail

script_directory="$(cd -- "$(dirname -- "$0")" && pwd)"
project_root="$(cd -- "${script_directory}/.." && pwd)"
cache_root="${TMPDIR:-/tmp}/NewEdenNexus-SwiftPM"

mkdir -p "${cache_root}/clang" "${cache_root}/swiftpm"
export CLANG_MODULE_CACHE_PATH="${cache_root}/clang"
export SWIFTPM_MODULECACHE_OVERRIDE="${cache_root}/swiftpm"

cd "${project_root}"

python3 Scripts/verify_project_governance.py
python3 Scripts/verify_xcode_project.py
swift package describe
swift build -c debug
swift build -c release
swift test -c debug --enable-code-coverage
swift test -c release
