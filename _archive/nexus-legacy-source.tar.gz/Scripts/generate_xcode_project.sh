#!/bin/zsh

set -euo pipefail

repository_root="${0:A:h:h}"
cd "$repository_root"

if ! command -v xcodegen >/dev/null 2>&1; then
    echo "xcodegen is required to regenerate NewEdenNexus.xcodeproj." >&2
    exit 1
fi

xcodegen generate \
    --spec "$repository_root/project.yml" \
    --project "$repository_root" \
    --project-root "$repository_root"

"$repository_root/Scripts/verify_xcode_project.py"
