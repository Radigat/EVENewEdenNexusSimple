# AGENTS.md – New Eden Nexus

Diese Regeln gelten dauerhaft für alle Arbeiten im Repository **New Eden Nexus – Assets, Industry, Markets**. Sie ergänzen den jeweiligen Auftrag. Übergeordnete Systemvorgaben und die konkrete Benutzeranweisung bleiben vorrangig.

## 1. Projektauftrag

New Eden Nexus ist eine native macOS-Anwendung zur Planung, Berechnung und Verwaltung industrieller Aktivitäten in EVE Online.

Der aktuell verbindliche Entwicklungsumfang ist der in `Documentation/PROJECT_DESCRIPTION.md` definierte Produktionsplaner-MVP:

- statische EVE-Daten,
- Produktionsprojekte und Produktionsgraphen,
- T1- und T2-Produktion,
- notwendige Reaktionen als Berechnungsstufen,
- lokale und importierte Bestände,
- Sicherheitsbestände und Materialreservierungen,
- Build-or-Buy,
- manuelle und importierte Preise,
- Kosten-, Gewinn-, Margen-, ROI- und Break-even-Berechnung,
- Einkaufslisten,
- lokale Backups,
- Tests und Dokumentation.

Später geplante Funktionen dürfen nicht ohne ausdrücklichen Auftrag vorgezogen werden. Dazu gehören insbesondere:

- EVE SSO,
- ESI-Live-Synchronisation,
- automatische Asset-, Blueprint- und Industry-Job-Synchronisation,
- Wallet und Live-Märkte,
- Planetary Industry,
- Corporation-Funktionen,
- Cloud-Synchronisation und Mehrbenutzerbetrieb,
- KI, Constraint Solver und Optimierungsengine.

Bereits vorhandener Zukunftscode, insbesondere SSO/PKCE, Keychain und Synchronisationsplatzhalter, bleibt erhalten, wird aber weder ohne Auftrag erweitert noch als MVP-Fortschritt gewertet.

### Verbindliches Betriebs- und Distributionsziel

Der aktuelle Zielbetrieb ist die **lokale Eigennutzung auf dem Mac des
Projekteigentümers**. Ein lokaler Xcode-/SwiftPM-Build, ein lokaler
App-Start und lokale Datenhaltung sind der maßgebliche Betriebsweg.

Nicht Bestandteil des aktuellen Abschlusses sind:

- Veröffentlichung im Mac App Store,
- öffentliche Direktverteilung,
- Developer-ID- oder App-Store-Signierung,
- Apple-Team-/Provisioning-Konfiguration,
- Hardened Runtime nur für Notarisierungszwecke,
- Archivierung, Notarisierung, Stapling und Gatekeeper-Distributionsabnahme,
- öffentliche Release-, Support-, Marketing- oder Datenschutzprozesse.

Diese Punkte bilden **P48 – Optionale öffentliche macOS-/App-Store-
Distribution**. P48 steht nach P47 als letztes optionales Zukunftspaket,
darf nur auf ausdrücklichen Auftrag begonnen werden und blockiert weder den
lokalen MVP noch lokale Folgefeatures.

Der Begriff `Release` in Buildbefehlen bezeichnet ausschließlich die
optimierte Buildkonfiguration. Er ist kein Nachweis oder Auftrag für eine
öffentliche Veröffentlichung. CCP-Vorgaben für tatsächlich verwendete
offizielle Datenquellen gelten auch im lokalen Betrieb weiterhin.

## 2. Verbindliche Informationsquellen

Prüfe vor jeder Änderung in dieser Reihenfolge:

1. aktuellen Quellcode,
2. aktuellen Git-Diff und Git-Status,
3. konkrete Aufgabenstellung des aktuellen Prompts,
4. diese `AGENTS.md`,
5. `Documentation/CURRENT_PROJECT_STATUS.md`,
6. `Documentation/DEVELOPER_MENU.md`,
7. `Documentation/FEATURE_MATRIX.md`,
8. `Documentation/KNOWN_ISSUES.md`,
9. relevante Kapitel und Anhänge des Projektbuchs,
10. vorhandene Architekturentscheidungen und Abschlussberichte.

Für bereits implementierte Funktionen ist der tatsächliche Quellcode maßgeblich. Für geplante Anforderungen sind `Documentation/PROJECT_DESCRIPTION.md` und das Projektbuch maßgeblich. Der reduzierte MVP hat bei Scope-Fragen Vorrang vor dem umfassenden Zukunftsbild des Projektbuchs.

Stelle geplante Funktionen niemals als implementiert dar. Bei Widersprüchen:

- Widerspruch sichtbar dokumentieren,
- keine stillschweigende Annahme treffen,
- funktionierenden Code und Benutzerdaten erhalten,
- kleinste tragfähige Änderung wählen,
- notwendige Abweichung mit Grund und Auswirkung dokumentieren.

## 3. Arbeitsweise

Vor jeder Implementierung:

1. vollständigen aktuellen Prompt lesen,
2. Prompt-ID und Abnahmekriterien ermitteln,
3. aktuellen Projektstatus prüfen,
4. Git-Branch und Git-Status prüfen,
5. uncommittete und untracked Änderungen ermitteln,
6. betroffene Module und Dateien identifizieren,
7. bestehende Tests prüfen,
8. relevante Projektbuchkapitel und ADRs prüfen,
9. alle aktiven Einträge in `Documentation/OFFEN.md`,
   `Documentation/OPEN_TASKS.md` und `Documentation/KNOWN_ISSUES.md` prüfen,
10. Abhängigkeiten und Regressionen bewerten,
11. intern einen kleinen, überprüfbaren Arbeitsplan erstellen.

Anschließend in kleinen, abgeschlossenen Schritten arbeiten. Nur erforderliche Dateien ändern. Keine großflächige Neustrukturierung durchführen, wenn eine begrenzte Anpassung genügt. Funktionierenden Code nicht ohne nachvollziehbare Begründung löschen oder ersetzen. Fremde oder bereits vorhandene Benutzeränderungen weder verändern noch verwerfen.

### Offene Punkte in den nächsten Prompt übernehmen

Beim Spezifizieren oder Ausführen eines Prompts müssen alle offenen Punkte
verbindlich in dessen Scope aufgenommen werden, die für das vollständige,
korrekte und prüfbare Ergebnis dieses Prompts notwendig sind. Ein offener Punkt
ist notwendig, wenn er:

- dem aktuellen Prompt als Zielprompt zugeordnet ist,
- eine Voraussetzung oder ein Abnahmekriterium des Prompts blockiert,
- Build, relevante Tests, Datenintegrität oder die Definition of Done des
  Prompts verhindert,
- im unmittelbar betroffenen Modul liegt und das Ergebnis andernfalls
  nachweislich unvollständig oder widersprüchlich bliebe.

Jeder vollständig spezifizierte Prompt enthält dafür einen Abschnitt
`Mit zu erledigende offene Punkte` mit ID, konkreter Restarbeit und
Prüfnachweis. Diese Punkte sind innerhalb desselben Arbeitspakets zu bearbeiten
und nach Abschluss erneut gegen Quellcode, Tests und Dokumentation zu prüfen.

Nicht automatisch vorgezogen werden unabhängige Aufgaben, spätere
Entwicklungsstufen, bewusst verschobene Funktionen oder Punkte, deren
Bearbeitung eine wesentliche Scope-Erweiterung beziehungsweise neue Autorität
erfordert. Solche Punkte bleiben mit Begründung, Zielprompt und Auswirkung
offen. Kann ein notwendiger Punkt nicht sicher innerhalb des aktuellen Prompts
erledigt werden, darf der Prompt nicht als `✅ erledigt` gelten; der Blocker ist
konkret zu dokumentieren und dem Benutzer vorzulegen.

### Tokenarme Arbeitsweise

Für die verbleibenden Pakete gilt `Documentation/LEAN_MVP_PLAN.md`:

- nur betroffene Quellen und relevante Dokumentabschnitte mit `rg` und
  gezielten Ausschnitten lesen; Projektbuch, Altberichte und unveränderte
  Dateien nicht bei jedem Prompt vollständig erneut laden,
- abgeschlossene Historie nicht in neue Spezifikationen oder Berichte
  kopieren, sondern auf vorhandene Nachweise verlinken,
- ausführbare Promptdateien auf Ziel, Voraussetzungen, Umfang,
  Nicht-Ziele, notwendige offene Punkte und messbare Abnahme begrenzen;
  normalerweise höchstens etwa 120 Zeilen,
- keinen zweiten Plan, Parallelprompt oder zusätzliche Dokumentkopie
  erstellen, wenn ein vorhandener Prompt erweitert werden kann,
- Fortschrittsmeldungen und Chatabschluss knapp halten,
- bei unverändertem Sachstand keine Dokumentdatei nur zur Wiederholung
  umschreiben.

Diese Kürzung betrifft Wiederholungen und vorläufigen Funktionsumfang,
nicht Datenintegrität, deterministische Berechnungen, notwendige
Regressionstests, Sicherheitsgrenzen oder wahrheitsgemäße Statusangaben.

PLAN-002 und die Pakete P26 bis P37 sind abgeschlossen. PLAN-004 legte die
Ausbaureihenfolge fest:

**P38 → P39 → P40 → P41 → P42 → P43 → P44 → P45 → P46 → P47 → P48.**

P38 bis P42 sind technisch umgesetzt. P43 und P44 wurden nach Nutzenreview
zurückgestellt. PLAN-005 ordnet die beim anschließenden Funktionsaudit
gefundenen notwendigen Korrekturen und Betriebsnachweise verbindlich als
**P50 → P51 → P52 → P53 → P54**. P49 bleibt auf ausdrücklichen Wunsch
unbelegt. P50 und P51 sind abgeschlossen; P52 wurde mit ausdrücklich
dokumentierten offenen P42-Eigentümergates beendet. P53 ist nach
bestätigter recoverbarer Archivierung und vollständiger Kanonprüfung
abgeschlossen. P54 beginnt nur nach gesonderter ausdrücklicher
Commit-Freigabe. P45 bis P48 bleiben davon unberührt zurückgestellt
beziehungsweise optional; nach P54 beginnt kein Zukunftspaket automatisch.

## 4. Technische Vorgaben

Für neuen oder geänderten Code grundsätzlich verwenden:

- Swift und SwiftUI,
- AppKit nur bei begründetem Bedarf,
- Swift Concurrency mit `async`/`await` und strukturierter Nebenläufigkeit,
- starke Typisierung,
- Dependency Injection,
- klar definierte Protokolle,
- testbare Services und Repositories,
- lokale persistente Datenhaltung,
- zentrale Fehlerbehandlung und Konfiguration,
- zentrale Design Tokens.

Vermeiden:

- Fachlogik in SwiftUI-Views,
- Datenbank- oder Netzwerkzugriffe direkt aus Views,
- globale veränderliche Zustände und unkontrollierte Singletons,
- fest codierte Zugangsdaten oder Pfade,
- nicht lokalisierbare neue UI-Texte,
- doppelte Implementierungen,
- übergroße Dateien mit mehreren Verantwortlichkeiten,
- Force-Unwraps ohne zwingenden dokumentierten Grund,
- leere `catch`-Blöcke, `try?` bei fachlich relevanten Operationen und ignorierte Fehler,
- nicht abgebrochene asynchrone Aufgaben,
- Änderungen an Signing- oder Team-Einstellungen ohne Auftrag.

Bestehende Abweichungen sind technische Schulden, keine Vorlage für neuen Code.

## 5. Architekturprinzipien

Dauerhaft beachten:

- Local First und Offline First,
- modulare Architektur,
- Trennung von UI, Anwendungslogik, Domänenlogik und Datenhaltung,
- deterministische, reproduzierbare Berechnungen,
- versionierte Datenbankmigrationen,
- sichere Datenhaltung und nachvollziehbare Fehler,
- wartbare Abhängigkeiten und austauschbare Datenquellen,
- testbare Fachlogik und erweiterbare Module,
- benutzerkontrollierte Automatisierung.

Views stellen Zustände dar und nehmen Interaktionen entgegen. Fachliche Berechnungen gehören in Domänenservices oder klar abgegrenzte Berechnungskomponenten. Persistente Modelle dürfen nicht ungeprüft zugleich UI- oder Domänenmodelle sein.

## 6. Fachliche Berechnungen

Alle Produktions-, Mengen-, Kosten- und Gewinnberechnungen müssen:

- zentral implementiert,
- deterministisch,
- mit festen Eingabewerten testbar,
- nachvollziehbar aufgeschlüsselt,
- frei von UI-Abhängigkeiten,
- fachlich versionierbar

sein.

Rundungsregeln dürfen nicht willkürlich gewählt werden. Verwende verifizierte statische Daten und die verbindlichen Regeln aus Kapitel 30 beziehungsweise Anhang E des Projektbuchs. Die dort selbst als prüfbedürftig markierte ME-Regel ist vor endgültiger Implementierung gegen eine belastbare CCP-/SDE-Grundlage zu verifizieren.

Ist eine Regel nicht eindeutig:

- keine Vermutung als endgültige Lösung implementieren,
- offene Regel und Auswirkung kennzeichnen,
- Testplatzhalter oder offene Aufgabe ergänzen,
- Unsicherheit im Abschlussbericht dokumentieren.

## 7. Datenintegrität und Migrationen

Bei jeder Änderung am Datenmodell:

1. aktuelle Schemaversion prüfen,
2. nachvollziehbare versionierte Migration anlegen,
3. bestehende Benutzerdaten erhalten,
4. Migration mit Altbestand testen,
5. neue leere Datenbank testen,
6. Schemaänderung und Datenwirkung dokumentieren,
7. Datenbankschemaversion aktualisieren.

Destruktive Migrationen vermeiden. Sind sie unvermeidbar:

- vorher ein verifiziertes Backup erstellen,
- möglichen Datenverlust exakt dokumentieren,
- bewusste Benutzerbestätigung einholen,
- Wiederherstellungsstrategie bereitstellen und prüfen.

Schreibvorgänge sollen validiert, atomar und bei Fehlern rückrollbar sein. Unvollständige Zwischenstände dürfen nicht als erfolgreich gespeichert gelten.

## 8. Benutzeroberfläche

Neue oder geänderte Ansichten müssen berücksichtigen:

- klare visuelle Hierarchie und konsistente Navigation,
- einheitliche Terminologie,
- Tastaturbedienung und VoiceOver,
- ausreichenden Kontrast und skalierbare Inhalte,
- Empty-, Loading-, Error- und Warnzustände,
- lange Texte und Lokalisierbarkeit,
- große Datenmengen,
- schmale und breite Fenster.

Vorhandene Designsystem-Komponenten und Design Tokens wiederverwenden. Keine lokalen Kopien bestehender Standardkomponenten erstellen.

## 9. Performance

Vermeiden:

- vollständige Datenbankabfragen bei jeder UI-Aktualisierung,
- unnötige Neuberechnungen,
- blockierende Arbeiten auf dem Main Thread,
- unbeschränkte parallele Aufgaben,
- wiederholtes Parsen unveränderter statischer Daten,
- Laden großer vollständiger Datenmengen ohne Pagination, Begrenzung oder Lazy-Strategie.

Performancebehauptungen sind nur mit dokumentierter Messung zulässig. Erst Korrektheit sicherstellen, dann einen nachgewiesenen Engpass gezielt optimieren.

## 10. Sicherheit

Niemals Passwörter, Access Tokens, Refresh Tokens, Client Secrets oder fachlich nicht notwendige personenbezogene Daten speichern in:

- Quellcodedateien oder Git,
- Logs,
- normalen Preferences/UserDefaults,
- Testfixtures,
- Screenshots,
- Abschlussberichten.

Sensible Werte nicht protokollieren. Tokens gehören ausschließlich in den sicheren Schlüsselspeicher des Betriebssystems. Importierte Dateien und Benutzereingaben validieren. Dateizugriffe, Import, Export und Backups defensiv behandeln. Diagnosepakete vor Ausgabe von Geheimnissen und personenbezogenen Daten bereinigen.

## 11. Git-Regeln

Vor jeder Arbeit aktuellen Branch, Git-Status, uncommittete Änderungen und untracked Dateien prüfen. Fremde Änderungen nicht ohne ausdrücklichen Auftrag verändern.

Ohne ausdrücklichen Auftrag keine der folgenden Aktionen ausführen:

- Commit oder Push,
- Rebase oder Merge,
- Reset,
- Branch-Löschung,
- Tag-Erstellung,
- Überschreiben der Git-Historie.

`git reset --hard`, Force-Push und vergleichbare destruktive Befehle sind ohne ausdrückliche Bestätigung verboten.

**Aktuelle projektspezifische Sicherheitslage:** Seit OFF-001 ist `/Users/svenstolze/Documents/Codex/EVE Nexus` eine eigene Git-Wurzel. Alle Git-Befehle für dieses Projekt ausschließlich in dieser Wurzel ausführen. Das weiterhin vorhandene übergeordnete Repository `/Users/svenstolze/.git` und andere Inhalte des Benutzerverzeichnisses niemals im Rahmen dieses Projekts stagen, bereinigen, verschieben, löschen oder verändern.

## 12. Build-Regeln

Vor dem ersten Build ermitteln:

- vorhandene `.xcodeproj` und `.xcworkspace`,
- verfügbare Schemes,
- Buildkonfigurationen,
- Zielplattformen,
- Testtargets.

Anschließend die passende Buildkonfiguration verwenden. Für den aktuellen Swift-Package-Ist-Stand ist SwiftPM der verifizierte CLI-Weg, solange kein funktionierendes Xcode-Projekt beziehungsweise kein von `xcodebuild` erkennbarer Workspace vorliegt.

Ein Build gilt nur als erfolgreich, wenn der Befehl tatsächlich erfolgreich beendet wurde. Dokumentiere Befehl, Scheme oder Produkt, Konfiguration, Ziel, Ergebnis, Warnungen und Fehler. Warnungen nicht pauschal unterdrücken.

Je normalem Fachpaket genügt ein vollständiger SwiftPM-Debuglauf zusätzlich
zu den fokussierten Tests. Xcode Debug ist bei App-, UI- oder
Projektänderungen erforderlich. Release-Konfigurationen, Real-SDE- und
mehrfach identische Vollsuiten werden nur ausgeführt, wenn die betroffene
technische Grenze oder der konkrete Prompt sie verlangt. Ein reduzierter
Testumfang muss im Bericht genannt werden. Kein lokaler `Release`-Build darf
als öffentliche Distributionsabnahme dargestellt werden.

## 13. Testregeln

Für jede fachliche Änderung passende Tests erstellen oder anpassen. Mindestens prüfen:

- Normalfall,
- Grenzfälle,
- leere Eingaben,
- ungültige Eingaben,
- Fehlerpfade,
- persistente Speicherung,
- Migrationen, sofern betroffen,
- Wiederholbarkeit,
- relevante Regressionen.

Berechnungen benötigen Referenztests mit festen Eingaben und erwarteten Werten. Tests gelten nur als erfolgreich, wenn sie tatsächlich ausgeführt wurden. Übersprungene Tests sind nicht bestanden. Bestehende Tests nicht entfernen, nur weil sie nach einer Änderung fehlschlagen.

Produktive Benutzerdaten dürfen niemals als Testdatenbank oder Fixture verwendet werden. Referenzdaten müssen anonymisiert und versioniert sein.

## 14. Dokumentationspflicht

Nach jedem Implementierungsauftrag die folgenden Steuerdateien prüfen, aber
nur bei tatsächlicher Status- oder Nachweisänderung bearbeiten:

- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- relevante Fachdokumentation.

Zwingend sind ein kurzer Statusdelta in Entwickler-Menü/Projektstatus und
ein zugehöriger Abschlussbericht. Feature-Matrix, Tagebuch, offene Punkte,
Probleme und Testhistorie erhalten jeweils nur den betroffenen kompakten
Deltaeintrag; unveränderte Historie wird nicht wiederholt. Die erneute
Prüfung aktiver offener Punkte wird im Bericht bestätigt, ohne jede alte
Zeile neu zu erzählen.

Bei Architekturänderungen zusätzlich `Documentation/ARCHITECTURE_CHANGES.md` und einen passenden ADR aktualisieren beziehungsweise neu anlegen. Nur tatsächlich ausgeführte Arbeiten und tatsächlich geprüfte Ergebnisse dokumentieren.

## 15. Abschlussberichte

Nach jedem Arbeitspaket einen neuen Bericht unter `Documentation/Progress/Reports/` speichern.

Dateiformat: `YYYY-MM-DD_PXX_Kurztitel.md`

Vorhandene Berichte niemals überschreiben. Berichte bleiben möglichst kurz,
verlinken bestehende Architektur-/Testnachweise und enthalten nur
zutreffende Punkte:

- Prompt-ID und Ziel,
- Ausgangszustand,
- durchgeführte Änderungen,
- neu erstellte Dateien,
- geänderte Dateien,
- gelöschte oder verschobene Dateien,
- Architekturentscheidungen,
- Datenmodelländerungen,
- Build-Ergebnis,
- Testergebnis,
- manuelle Prüfungen,
- bekannte Probleme,
- offene Anforderungen,
- Abweichungen vom Projektbuch,
- erfüllte und nicht erfüllte Abnahmekriterien,
- Reviewentscheidung,
- nächsten empfohlenen Prompt.

Nicht betroffene Abschnitte dürfen mit `nicht betroffen` in einer Zeile
zusammengefasst werden. Lange Konsolenausgaben werden nicht kopiert;
Befehl, Exitstatus, Testzahl und relevanter Fehler-/Warnungsauszug genügen.

## 16. Definition of Done

Ein Arbeitspaket darf nur als `✅ erledigt` markiert werden, wenn alle zutreffenden Bedingungen erfüllt und nachgewiesen sind:

- verpflichtende Anforderungen umgesetzt,
- Code kompiliert,
- relevanter Build erfolgreich,
- relevante Tests erfolgreich,
- keine verursachte kritische Regression offen,
- betroffene Migrationen getestet,
- Dokumentation und Feature-Matrix aktualisiert,
- Entwicklertagebuch aktualisiert,
- Abschlussbericht gespeichert,
- Review und Kontrollprüfung bestanden.

Ist eine Voraussetzung nicht erfüllt, Status auf `⚠️ teilweise oder blockiert`, `❌ fehlgeschlagen` oder `⏸️ bewusst verschoben` setzen. Nie allein aufgrund einer Selbsteinschätzung `✅` vergeben.

## 17. Review-Pflicht

Nach jedem Implementierungsprompt einen gesonderten Review- und Kontrollschritt gemäß `Documentation/REVIEW_RULES.md` ausführen.

Der Review darf Abschlussaussagen nicht ungeprüft übernehmen. Er prüft tatsächlichen Diff, Quellcode, Architektur, Buildausgaben, Testergebnisse, Datenwirkung und Dokumentation. Mögliche Entscheidungen:

- `✅ bestanden`,
- `⚠️ mit Einschränkungen bestanden`,
- `❌ nicht bestanden`.

Bei `⚠️` oder `❌` konkrete Korrekturaufgaben mit Priorität, betroffenen Dateien und Prüfnachweis erstellen.

## 18. Umgang mit Fehlern

Bei einem Fehler:

1. Fehler reproduzieren,
2. Ursache eingrenzen,
3. kleinstmögliche Korrektur entwickeln,
4. Regressionstest ergänzen,
5. Build und Tests erneut ausführen,
6. Dokumentation aktualisieren.

Keinen Fehler verstecken, ignorieren oder durch Warnungsunterdrückung kaschieren, um einen Arbeitsschritt als abgeschlossen darzustellen.

## 19. Grenzen des Auftrags

Ausschließlich den aktuellen Auftrag implementieren. Nicht automatisch mit dem nächsten Prompt beginnen und keine zusätzlichen großen Features einführen.

Sinnvolle kleine Korrekturen sind nur zulässig, wenn sie unmittelbar notwendig, risikoarm, getestet und dokumentiert sind. Erfordert die Korrektur neue Autorität, destruktive Datenänderungen oder eine wesentliche Scope-Erweiterung, zuerst den Benutzer fragen.

## 20. Abschlussausgabe

Nach einem Implementierungsauftrag im Chat kompakt ausgeben:

- Prompt-ID,
- Status,
- wichtigste Änderungen,
- Build-Ergebnis,
- Testergebnis,
- Reviewstatus,
- Pfad zum Abschlussbericht,
- offene Punkte,
- nächsten empfohlenen Prompt.
