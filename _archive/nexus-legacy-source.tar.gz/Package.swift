// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "NewEdenNexus",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "NewEdenNexus", targets: ["NewEdenNexus"]),
        .executable(
            name: "NewEdenNexusSDEAcceptance",
            targets: ["NewEdenNexusSDEAcceptance"]
        )
    ],
    targets: [
        .target(
            name: "NewEdenNexusDomain",
            path: "Sources/NewEdenNexusDomain"
        ),
        .target(
            name: "NewEdenNexusApplication",
            dependencies: ["NewEdenNexusDomain"],
            path: "Sources/NewEdenNexusApplication"
        ),
        .target(
            name: "NewEdenNexusInfrastructure",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusApplication"
            ],
            path: "Sources/NewEdenNexusInfrastructure"
        ),
        .target(
            name: "NewEdenNexusPersistence",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusApplication"
            ],
            path: "Sources/NewEdenNexusPersistence"
        ),
        .executableTarget(
            name: "NewEdenNexus",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusApplication",
                "NewEdenNexusInfrastructure",
                "NewEdenNexusPersistence"
            ],
            path: "Sources/NewEdenNexus"
        ),
        .executableTarget(
            name: "NewEdenNexusSDEAcceptance",
            dependencies: [
                "NewEdenNexusApplication",
                "NewEdenNexusInfrastructure",
                "NewEdenNexusPersistence"
            ],
            path: "Sources/NewEdenNexusSDEAcceptance"
        ),
        .target(
            name: "NewEdenNexusLegacySchema",
            path: "Tests/Fixtures/NewEdenNexusLegacySchema"
        ),
        .target(
            name: "NewEdenNexusTestSupport",
            dependencies: ["NewEdenNexusDomain"],
            path: "Tests/NewEdenNexusTestSupport",
            resources: [
                .copy("Fixtures")
            ]
        ),
        .testTarget(
            name: "NewEdenNexusTests",
            dependencies: [
                "NewEdenNexus",
                "NewEdenNexusDomain",
                "NewEdenNexusApplication",
                "NewEdenNexusInfrastructure",
                "NewEdenNexusPersistence"
            ],
            path: "Tests/NewEdenNexusTests"
        ),
        .testTarget(
            name: "NewEdenNexusDomainTests",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusTestSupport"
            ],
            path: "Tests/NewEdenNexusDomainTests"
        ),
        .testTarget(
            name: "NewEdenNexusApplicationTests",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusApplication"
            ],
            path: "Tests/NewEdenNexusApplicationTests"
        ),
        .testTarget(
            name: "NewEdenNexusInfrastructureTests",
            dependencies: [
                "NewEdenNexusApplication",
                "NewEdenNexusInfrastructure",
                "NewEdenNexusTestSupport"
            ],
            path: "Tests/NewEdenNexusInfrastructureTests"
        ),
        .testTarget(
            name: "NewEdenNexusArchitectureTests",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusApplication",
                "NewEdenNexusPersistence"
            ],
            path: "Tests/NewEdenNexusArchitectureTests"
        ),
        .testTarget(
            name: "NewEdenNexusPersistenceTests",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusApplication",
                "NewEdenNexusInfrastructure",
                "NewEdenNexusPersistence",
                "NewEdenNexusLegacySchema",
                "NewEdenNexusTestSupport"
            ],
            path: "Tests/NewEdenNexusPersistenceTests"
        ),
        .testTarget(
            name: "NewEdenNexusTestSupportTests",
            dependencies: [
                "NewEdenNexusDomain",
                "NewEdenNexusTestSupport"
            ],
            path: "Tests/NewEdenNexusTestSupportTests"
        )
    ]
)
