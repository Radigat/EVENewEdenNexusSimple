# CSV-Preisimport

Stand: 2026-07-25 · P28 · Schema v17

## Vertrag

P28 importiert Einheitspreise in ein vorhandenes P27-Profil. Pflichtspalten
sind `type_id` und `price`; `item_name` ist eine optionale
Kataloggegenprüfung. Kodierung, Trennzeichen, Spalten und Dezimalpunkt oder
Dezimalkomma werden vor der Vorschau festgelegt.

Es gelten die P21-Grenzen von 16 MiB, 100.000 Datenzeilen und 64 Spalten.
Preiswerte bleiben exakte positive Hundertstel ISK. Tausendertrennzeichen,
Vorzeichen, mehr als zwei Nachkommastellen und nicht veröffentlichte Items
werden abgelehnt.

## Sicherer Ablauf

1. Datei ausschließlich lesen und hashen.
2. Format und Kopfzeile prüfen.
3. Spalten sichtbar zuordnen.
4. Zielprofil und gemeinsames Gültigkeitsfenster festlegen.
5. jede Zeile gegen den aktiven Itemkatalog prüfen,
6. neue, unveränderte, konflikthafte und ungültige Zeilen anzeigen,
7. jeden Konflikt einzeln ersetzen oder überspringen,
8. Import nochmals ausdrücklich bestätigen,
9. Preise und bereinigten Detailbericht atomar speichern.

Abbruch, fehlende Entscheidung, Profil-/Preisänderung oder
Persistenzfehler schreiben nichts. Nicht in der Datei vorkommende Preise
werden nicht gelöscht.

## Persistierte Daten

Importierte Preise tragen Quelle `csv`. Der Bericht speichert Profil,
Zeitpunkt, bereinigten Dateinamen, SHA-256, Format, Gültigkeit, Summen und
Zeilenergebnisse. Rohdatei und lokaler Dateipfad werden nicht gespeichert.
Beim Löschen eines Profils werden seine Importberichte mit entfernt.

Schema v17 ergänzt nur `PriceImportRecord`. Die Migration v16→v17 erhält
Profile und Preise; Backupformat 17.0.0 akzeptiert weiterhin alle Formate
ab 1.0.0.
