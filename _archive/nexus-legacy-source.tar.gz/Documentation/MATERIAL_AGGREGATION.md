# Materialaggregation und Graphschutz

Stand: 2026-07-24 · P19

## Zweck

P19 überführt die erklärbaren Einzelvorkommen des Produktionsgraphen in
eine reproduzierbare Endmaterialübersicht. Die Übersicht ist noch keine
Einkaufs- oder Verfügbarkeitsliste: Bestände, Reservierungen,
Sicherheitsmengen und Build-or-Buy werden erst in P20 bis P26 verrechnet.

## Fachliche Grundlage

Aggregiert werden ausschließlich `material`-Blattknoten. Ziel und
rezepttragende Zwischenprodukte werden nicht zusätzlich gezählt. Der
fachliche Schlüssel ist die positive CCP-Type-ID; Namen sind nur Anzeige-
und Sortierwerte.

Für jedes Blatt wird die bereits berechnete effektive Kantenmenge verwendet:

1. `reactionMaterialCalculation.effectiveQuantity` bei einer
   Reaktionskante,
2. andernfalls `materialCalculation.effectiveQuantity`.

Gleiche Type-IDs werden addiert. Gleiche Namen mit unterschiedlichen
Type-IDs bleiben getrennt. Unterschiedliche normalisierte Namen für dieselbe
Type-ID blockieren den Graphen als inkonsistent.

## Erklärbarkeit

`ProductionGraphMaterialAggregation` verwendet Formelversion 1 und enthält
für jede Position:

- Type-ID und Anzeilename,
- positive `Int64`-Gesamtmenge,
- alle beitragenden Blattknoten,
- effektive Menge und Blattgrund je Vorkommen,
- vollständigen Knotenpfad von der Wurzel zum Blatt.

Positionen werden nach POSIX-normalisiertem Namen und Type-ID sortiert,
Vorkommen nach Knoten-ID. Die Eingabereihenfolge ändert das Ergebnis nicht.

## Mengen- und Bestandsschutz

Jede Addition verwendet `addingReportingOverflow`. Exakt `Int64.max` ist
gültig; die nächste positive Addition schlägt typisiert mit Type-ID und
Blattknoten fehl. Es gibt weder Clamping noch einen Wechsel zu
Gleitkommazahlen. Der Application-Service aggregiert vor der
Repository-Speicherung, sodass ein Fehler den vorhandenen Graphen
unverändert lässt.

## Graphformat und Persistenz

Graphformat 7 speichert Aggregationsformel 1 in der bestehenden kanonischen
Graphpayload. Es gibt keine neue SwiftData-Spalte und keine Migration:
Schema v9 sowie Backupformat 9.0.0 bleiben unverändert.

Beim Laden wird zuerst die Graphstruktur validiert, anschließend die
Aggregation aus Knoten und Kanten neu berechnet und exakt mit der
gespeicherten Payload verglichen. Manipulierte Mengen, Vorkommen oder Pfade
werden abgelehnt. Formate 1 bis 6 bleiben lesbar, besitzen keine
P19-Aggregation und gelten als veraltet.

## Graphschutz

Generierung und geladene Payloads verwenden dieselben Obergrenzen:

- maximale Tiefe 64,
- maximal 25.000 Knoten.

Zusätzlich werden unter anderem eindeutige Knoten, gültige Endpunkte,
positive Mengen, eindeutige Geschwister-Sortierwerte, genau eine eingehende
Kante je Nichtwurzel, keine Wurzel-Eingangskante, keine Selbstkante,
Eltern-/Kindtiefe, Erreichbarkeit und Zyklusfreiheit geprüft. Die
Zyklusprüfung geladener Payloads arbeitet iterativ und benötigt keine
rekursive Aufrufkette.

## Benutzeroberfläche

Die Graphansicht zeigt Anzahl der Materialtypen und Vorkommen, Type-ID,
Gesamtmenge sowie aufklappbare Einzelvorkommen mit vollständigem
Erklärpfad. Alte Graphformate zeigen einen Hinweis zur bewussten
Neuerzeugung. Loading-, Empty-, Error-, Veraltet- und Abbruchzustände
bleiben erhalten.

## Nachweise

- Domain: Gruppierung, Namen/IDs, Pfade, Determinismus, fehlende Daten,
  Zyklus und `Int64`-Grenzen,
- Application: gemischte T1-/T2-/Reaktionsgraphen und Erhalt des Altgraphen
  bei Überlauf,
- Persistenz: Format-7-Roundtrip, Format-6-Lesbarkeit und manipulierte
  Aggregation,
- Graphvalidierung: Sortierkollision, Tiefe und Knotenlimit,
- UI/Architektur: sichtbare Aggregation und Erklärpfade,
- SwiftPM und Xcode in Debug und Release jeweils 321 Tests ohne Fehler oder
  übersprungene Tests,
- isolierter App-/Schema-v9-Store mit `PRAGMA integrity_check = ok`.

## Abgrenzung

- P20–P25: Lager, Bestände, Ausschlüsse, Schutzmengen und Reservierungen,
- P26: Build-or-Buy,
- P29/P30: Kosten und Einkaufslisten,
- P34: gemessene Performancebudgets jenseits der Schutzgrenzen.
