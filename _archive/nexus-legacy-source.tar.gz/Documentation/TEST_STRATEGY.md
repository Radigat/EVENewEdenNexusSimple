# Teststrategie und Referenzdaten

Stand: 2026-07-24 · nach P16

## Ziel

Tests für New Eden Nexus müssen reproduzierbar, isoliert, offline und
unabhängig von produktiven Benutzerdaten sein. P07 bis P09 verwenden eine
synthetische formatkompatible SDE-Fixture. Ein optional konfigurierter
Realtest darf offizielle Daten nur temporär außerhalb des Repositorys nutzen.
Die Testbasis behauptet keine Abdeckung nicht implementierter MVP-Funktionen.

Grundlage sind Kapitel 20.9 und 32 sowie Anhang F des Projektbuchs, eingegrenzt auf den reduzierten Produktionsplaner-MVP und den tatsächlich vorhandenen Quellcode.

## Testpyramide

1. **Unit- und Referenztests:** schnelle deterministische Prüfung einzelner Domainregeln und Application-Use-Cases.
2. **Integrations- und Migrationstests:** Zusammenspiel von Repository, Mapping, SwiftData-Schema und dateibasierten Stores.
3. **App- und Architekturregressionstests:** Composition Root, Fehlerdarstellung und verbotene Abhängigkeiten.
4. **UI- und End-to-End-Tests:** erst mit fachlich vollständigen Workflows; P05 richtet hierfür noch kein Xcode-UI-Testtarget ein.
5. **Manuelle Abnahme:** ergänzt automatisierte Prüfungen, ersetzt sie aber nicht.

## Testtargets

| Target | Verantwortung |
|---|---|
| `NewEdenNexusDomainTests` | deterministische Fachmodelle, Berechnungen und Referenz-Sollwerte |
| `NewEdenNexusApplicationTests` | Use-Cases, Ports, Fehler- und Redaktionsregeln |
| `NewEdenNexusInfrastructureTests` | konkrete Datei-/Systemadapter, SDE-Prüfung, Staging und Feldmapping |
| `NewEdenNexusPersistenceTests` | SwiftData-Store, Migration, Repository und SDE-Aktivierung |
| `NewEdenNexusArchitectureTests` | Compile-Time- und Quellcodegrenzen |
| `NewEdenNexusTests` | App-Runtime und Composition-Regressionen |
| `NewEdenNexusTestSupportTests` | Loader, Fixture-Versionierung, Builder und temporäre Testpfade |

`NewEdenNexusTestSupport` ist kein Produkt und wird ausschließlich von Testtargets verwendet.

## Referenzpaket

Pfad:

`Tests/NewEdenNexusTestSupport/Fixtures/Foundation/v1/foundation-reference.json`

Manifest:

- ID `new-eden-nexus-foundation-reference`,
- Version `1.0.0`,
- kompatibles Schema `1.0.0`,
- Klassifikation `synthetic`,
- keine SDE-Version,
- keine ESI-Kompatibilitätsversion.

Die leeren SDE-/ESI-Felder sind absichtlich: P05 enthält keine importierten EVE-Rezepte und keine Live-Antworten. Das synthetische Referenzprodukt darf nicht als SDE-Wahrheit oder fachlich korrektes EVE-Rezept verwendet werden.

Vorhandene Fälle:

| Test-ID | Ebene | Zweck |
|---|---|---|
| `MAT-REF-001` | Domain | Gruppierung, Sortierung, Mengenbegrenzung und Geldrundung |
| `MAT-REF-002` | Domain | leere Materialaggregation |
| `PROJECT-REF-001` | Domain | feste Projektidentität, Zeitwerte und Normalisierung |

Neue Referenzfälle werden ergänzt, nicht stillschweigend umgeschrieben. Ändert sich ein fachlicher Sollwert bewusst, benötigt das Referenzpaket eine neue Version und einen dokumentierten Grund.

Seit P14–P16 liegen die produktiven Fachreferenzen zusätzlich direkt an den
versionierten Domainberechnungen:

- Runs 25/10 → 3, Ausgabe 30, Überschuss 5,
- ME 0: 240 × 15 → 3.600,
- ME 10: 240 × 15 → 3.240, Ersparnis 360,
- ME 10 mit Basismenge 2 und 8 Runs → 15 nach einmaliger Jobaufrundung,
- Basismenge 1 bleibt je Run vollständig geschützt,
- Reaktionsrezepte akzeptieren keine Blueprint-ME ungleich 0.

Diese Werte werden nicht aus synthetischen SDE-Namen als Spielwahrheit
abgeleitet, sondern prüfen die separat dokumentierte und offiziell
verifizierte Rechenregel.

### SDE-Importfixture

Pfad:

`Tests/NewEdenNexusTestSupport/Fixtures/SDE/v1/`

Die Fixture ist als `synthetic-format-fixture` klassifiziert und enthält vier
kleine JSONL-Dateien mit erfundenen Bezeichnern und IDs. Seit P08 enthält sie
zusätzlich zusammenhängende Manufacturing-, Invention- und Reaction-Daten.
Sie ist weder ein CCP-SDE-Auszug noch eine fachliche EVE-Referenz.

Das Manifest bindet:

- Fixture-ID und Version,
- synthetische Klassifikation,
- feste Test-Buildnummer,
- vier Pflichtdateien,
- erwarteten kanonischen Gesamt-SHA-256.

Fehlerfälle werden aus einer frischen temporären Kopie erzeugt. Die eingebettete Referenzfixture bleibt unverändert.

## Gemeinsame Testhelfer

- `ProductionProjectSnapshotBuilder`: feste UUID und Zeitwerte, gezielte Overrides pro Test.
- `TemporaryStoreLocation`: eindeutiges Verzeichnis unter `FileManager.temporaryDirectory` und explizite Entfernung.
- `ReferenceDatasetLoader`: eingebetteter Offline-Loader mit Datensatz- und Schemaversionsprüfung sowie Schutz vor doppelten Test-IDs.
- `SDEReferenceFixture`: Manifestloader und eindeutige temporäre Kopie der synthetischen JSONL-Quelle.

Produktive Storepfade, echte Tokens, Accounts und Benutzerdaten sind in Tests verboten.

## Testfalldokumentation

Jeder fachliche Referenzfall besitzt:

- stabile Test-ID,
- Ziel,
- Voraussetzungen,
- feste Eingaben,
- festes erwartetes Ergebnis,
- automatisierten Ist-Vergleich,
- Ergebnis im Testlauf beziehungsweise in `TEST_HISTORY.md`.

Fehlertestdaten werden ausdrücklich als fehlerhaft gekennzeichnet. Ein absichtlich fehlschlagender Test wird nicht eingecheckt.

## Coverage-Ziele

- Jede zentrale deterministische Berechnung: mindestens ein versionierter Referenztest.
- Neue oder geänderte nicht visuelle Fachlogik: Normalfall, leere Eingabe, ungültige Eingabe und relevanter Fehlerpfad.
- Repositorys und Migrationen: jeder öffentliche Schreib-/Leseweg und jeder Migrationspfad mindestens einmal.
- Neue Domain- und Applicationlogik: Zielwert mindestens 80 % Line Coverage.
- Kritische Material-, Kosten- und Gewinnregeln: vollständige fachliche Referenzfälle unabhängig von der Prozentzahl.

Die SwiftPM-Coverage-Baseline ist ein Trendindikator. SwiftUI-, Makro- und Fixture-Code wird nicht durch wertlose Tests zur künstlichen Kennzahlerhöhung aufgebläht. Die konkrete Baseline jedes relevanten Laufs wird in `TEST_HISTORY.md` dokumentiert.

P05-Baseline vom 2026-07-23:

- alle instrumentierten Dateien einschließlich Tests: `1779/3022` Zeilen, `58,87 %`,
- produktive Sources einschließlich SwiftUI/Future-Code: `462/1677`, `27,55 %`,
- Domain und Application: `286/288`, `99,31 %`,
- P05-TestSupport: `103/106`, `97,17 %`.

Die niedrige Gesamtquote der produktiven Sources beruht vor allem auf noch nicht vorhandenen UI-Tests und dem eingefrorenen Future-Code. Sie wird nicht als vollständige MVP-Abdeckung interpretiert.

P07-Stand vom 2026-07-23:

- alle instrumentierten Dateien: `4232/5702`, `74,22 %`,
- produktive Sources: `1637/3045`, `53,76 %`,
- JSONL-SDE-Dateiadapter: `507/560`, `90,54 %`,
- 67 Tests in Debug und Release.

P08-Stand vom 2026-07-23:

- alle instrumentierten Dateien: `6231/7999`, `77,90 %`,
- produktive Sources: `2914/4543`, `64,14 %`,
- Katalogsnapshot 81,97 %, Mapper 82,42 %, Aktivierungsrepository 93,26 %,
- 83 Tests in Debug und Release,
- zusätzlicher offizieller Build-3424810-E2E-Lauf erfolgreich.

P09-Stand vom 2026-07-23:

- alle instrumentierten Dateien: `7922/9825`, `80,63 %`,
- produktive Sources: `3652/5397`, `67,66 %`,
- Application-Katalogvertrag `133/136`,
- SwiftData-Katalogadapter `497/527`,
- Migrationsplan `43/43`,
- 100 Tests in Debug und Release,
- 50.000-Item-Fall: zehn Suchen mit Limit 50 in 0,300 s Debug und
  0,296 s Release; je höchstens 51 geladene Itemzeilen,
- zusätzlicher offizieller Build-3424810-E2E-Lauf im Schema-v3-Stand
  erfolgreich.

P07A-Stand vom 2026-07-23:

- alle instrumentierten Dateien: `10111/12186`, `82,97 %`,
- produktive Sources: `4668/6568`, `71,07 %`,
- `SDEUpdateChecking.swift`: `436/469`, `92,96 %`,
- `CCPSDEMetadataClient.swift`: `430/541`, `79,48 %`,
- `SwiftDataSDEUpdateStateRepository.swift`: `117/128`, `91,41 %`,
- 130 Tests in Debug und Release,
- 30 neue Tests für Service, HTTP/Parser und Persistenz/Migration,
- echte CCP-Endpunkte nur einmal manuell read-only geprüft; automatisierte
  Tests verwenden ausschließlich injizierte HTTP-Stubs.

P07C-Stand vom 2026-07-23:

- produktive Source-Zeilenabdeckung einschließlich SwiftUI: `7509/11801`,
  `63,63 %`,
- `SDEManagement.swift`: `121/121`, `100 %`,
- `CachedSDEArchiveDownloader.swift`: `235/259`, `90,73 %`,
- `SwiftDataSDECatalogRetentionRepository.swift`: `137/147`, `93,20 %`,
- `SDEManagementViewModel.swift`: `223/564`, `39,54 %`,
- `SDEArchiveRecoveryBoundary.swift`: `21/24`, `87,50 %`,
- 167 Tests in Debug und Release,
- manueller Fenster-/Accessibility-Nachweis nicht als bestanden gewertet und
  als `OFF-025` P09B zugeordnet.

P10-Stand vom 2026-07-23:

- neun Application- und fünf Persistence-Resolvertests,
- 181 Tests in Xcode und SwiftPM, jeweils Debug und Release,
- Fertigungs-/Reaktionsauflösung, Mehrdeutigkeit, Versionsisolation,
  Validierung, Fehler und Cancellation geprüft,
- aktueller offizieller Build 3444265 in isoliertem Store geprüft,
- alle 21 tatsächlichen Referenzlücken itemgenau blockiert,
- P09B hat den zuvor offenen P07C-Fenster-/Accessibility-Nachweis
  zwischenzeitlich geschlossen.

## Befehle

Einzelprüfungen:

```bash
swift package describe
swift build -c debug
swift build -c release
swift test -c debug --enable-code-coverage
swift test -c release
swift test --show-codecov-path
```

Providerneutraler Gesamtlauf:

```bash
./Scripts/ci-verify.sh
```

Das Skript verändert keine Signing-, Team- oder produktiven Datenbankeinstellungen. Eine spätere CI-Plattform kann exakt diesen Einstieg verwenden.

## Erweiterungsregeln

- P06 ergänzt temporäre Backup-/Restore-Datenstände.
- P07 ergänzt versionierte synthetische SDE-Format- und Importfehlerdaten.
- P08 ergänzt Mapping-, Referenz-, Migrations- und Aktivierungsfälle.
- P09 ergänzt Katalog-, Versionierungs-, Migrations- und Performancefälle.
- P07A ergänzt Buildvergleich, Validatoren, 304, Cache-Control,
  24-h-Drosselung, Retry/Backoff/Jitter, Offline, Schema-Gate,
  Statuspersistenz, v3→v4-Migration und Backupkompatibilität.
- P07C ergänzt Automation, Startscheduler, Parallelität, Offlinezustand,
  Cacheintegrität, Logleser, Diagnose-Redaction, Retention und statische
  Composition-/UI-/Accessibility-/Rechtstextprüfung.
- P10 ergänzt Resolverfälle und die sichere Behandlung nicht aufgelöster
  Typreferenzen.
- P14 ergänzt auf der P13-Graphbasis verifizierte Run-/Outputreferenzen.
  P15 und P16 erweitern diese um ME und Manufacturing-only-T1-Ketten;
  P17 und P18 ergänzen T2 und Reaktionen.
- P19 ergänzt Type-ID-/Namensregeln, deterministische
  Vorkommens-/Wurzelpfade, Aggregationsüberlauf und Altgraph-Erhalt,
  Format-7-Roundtrip, Altformat-Lesbarkeit, Manipulationsablehnung sowie
  geladene Tiefe-/Knoten-/Beziehungsgrenzen.
- P20 ergänzt Lager-/Bestandsinvarianten, Katalogbindung, Archiv- und
  Löschschutz, Repository-Roundtrip, v9→v10-Migration, Backupkompatibilität
  und UI-/Schichtengrenzen.
- P21 ergänzt versionierte CSV-Referenzdateien, Kodierungs-/Delimiter-/
  Quote- und Ressourcengrenzen, itemgenaue schreibfreie Vorschau,
  Bestätigung und Konfliktentscheidungen, Abbruch, veraltete Zustände,
  atomaren Bestand-/Berichtscommit, Rollback, v10→v11-Migration,
  Backupkompatibilität und UI-/Schichtengrenzen.
- P22 ergänzt alle drei Lagerfreigabemodi, Archiv-/Lager-/Material-/
  Cap-Priorität, deterministische Sortierung, `Int64`-Überlauf,
  Preview-before-write, Bestätigung, Stale-State, Abbruch, persistierte
  ungenutzte Regeln, Repository-Roundtrip, v11→v12-Migration,
  Backupkompatibilität und UI-/Schichtengrenzen.
- P23 ergänzt unverändertes P22-Verhalten ohne Regel, vollständige und
  teilweise Schutzdeckung, archivierte Bestände, unabhängige Schwellen,
  Zielauffüllung, `Int64`-Grenzen, Preview/Bestätigung, Service- und
  Repository-Stale-State, Abbruch, atomare Anlage/Änderung/Löschung,
  v12→v13-Migration, Backupkompatibilität und UI-/Schichtengrenzen.
- P24 ergänzt eigene und fremde Bindungen, Teil- und Vollverbrauch,
  Freigabe, Ablaufhinweis, Priorität, Überbuchungs- und `Int64`-Grenzen,
  Preview/Bestätigung, Service- und Repository-Stale-State, Abbruch,
  atomare Anlage/Änderung, Historien-Roundtrip, Projektarchivschutz,
  unbekanntes Projekt, Duplikation ohne Reservierungsübernahme,
  v13→v14-Migration, v14-Leerstore, zweite Öffnung,
  Backupkompatibilität und UI-/Schichtengrenzen.
- P25 ergänzt Bestandsunterdeckung, Bedarfsüberschreitung, nicht mehr
  benötigte Bindungen, Prioritätsdeterminismus, Ablaufwarnung,
  `Int64`-Grenzen, schreibfreie Vorschau, Bestätigung, ungültige
  Teilauflösung, Abbruch, Service-/Repository-Stale-State, atomare
  Mehrprojekt-Reduktion/-Freigabe und UI-/Schichtengrenzen. Fokussiert
  bestanden 21 Tests; alle vier Gesamtwege bestanden jeweils 423 Tests.
- P26 bis P31 ergänzen Build-or-Buy-, Preis- und
  Einkaufslistenfälle.
- UI-, Performance- und Releasepakete folgen erst in den dafür vorgesehenen Prompts.

Noch nicht implementierte Module werden nicht durch Placebo-Fixtures als getestet dargestellt.

## PLAN-002 – risikobasierte Kernprüfung

Für P26, P32 und P37 gilt:

- neue/geänderte Fachlogik immer fokussiert mit Normal-, Rand-, Fehler-,
  Abbruch- und Persistenzfällen prüfen,
- je Paket einmal die vollständige SwiftPM-Debugsuite ausführen,
- Xcode Debug nur bei App-, UI- oder Projektänderungen zusätzlich
  ausführen,
- Release, Real-SDE und mehrfach identische Vollsuiten nur bei betroffener
  Grenze oder ausdrücklichem Releaseauftrag ausführen,
- P37 prüft zusätzlich je ein T1- und T2-/Inventionsszenario mit
  Lagerbestand und isoliertem App-Start.

Ein ausgelassener Release-Lauf ist kein Fehler des internen Kernstands,
muss aber sichtbar dokumentiert werden. Er darf niemals als
Release-Nachweis gelten.
