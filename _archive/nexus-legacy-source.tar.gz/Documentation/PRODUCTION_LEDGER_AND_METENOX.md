# Produktionsbuch, Verkaufserfolg und Metenox-Wirtschaftlichkeit

Stand: 2026-07-29 · P59 technisch umgesetzt; Eigentümergate offen

## Zweck und Referenz

Diese Spezifikation überführt die fachliche Absicht der am 2026-07-29
schreibfrei analysierten Eigentümer-Arbeitsmappe in native Nexus-Module. Die
Arbeitsmappe selbst und ihre privaten ESI-Daten werden nicht in das Repository
übernommen.

Die Referenz enthält:

- eine Produktionsübersicht mit 25 Spalten und 166 Datenzeilen,
- Wallet-Transaktionen und Marktaufträge aus Excel-EVE-Funktionen,
- ein manuelles Metenox-Monatsmodell,
- SDE-/ESI-Hilfstabellen für Items, Regionen, Systeme, Charaktere und Hubs.

Die Excel-Formeln sind Referenz für den gewünschten Arbeitsablauf, aber keine
verbindliche Fachimplementierung. Erkannte Fehler werden nicht kopiert:

- Kosten pro Einheit müssen durch die tatsächliche Ausgabemenge, nicht durch
  die Zahl der Runs geteilt werden.
- Fehlende Werte dürfen keine Division-durch-null oder implizite Nullkosten
  erzeugen.
- Textkonvertierungen von Preisen werden nicht übernommen; Nexus rechnet
  weiterhin ganzzahlig in ISK-Hundertsteln.
- Excel-Add-in-Fehler (`#NAME?`, `#VALUE!`) werden durch bestehende
  SDE-/ESI-Verträge ersetzt.

## Vorhandene Nexus-Grundlagen

| Bereich | Ist-Stand | Verwendung |
|---|---|---|
| Produktionsprojekt, Produkt, Zielmenge und ME | vorhanden | Projekt bleibt Planungswurzel |
| Runs, Output, T1/T2, Invention und Reaktionen | vorhanden | deterministische Planbasis |
| Build-or-Buy, Einkaufsliste und Projektbudget | vorhanden | erwartete Material- und Beschaffungskosten |
| ESI Industry Jobs einschließlich Jobkosten | vorhanden | optionale, bestätigte Vorbelegung einer Produktionscharge |
| Wallet-Snapshots und Projektzuordnungen | technisch vorhanden, UI zurückgezogen | kontrollierte Istkosten-/Erlösquelle |
| öffentliche Marktpreise und benannte Hubs | vorhanden | Jita-/Home-Hub-Vergleich und Preisvorschläge |
| Marktaufträge | persönlicher ESI-Snapshot vorhanden | Verkaufsfortschritt, nicht automatisch Realgewinn |
| Produktionsbuch/Chargenhistorie | technisch und im realen Neustartlauf bestätigt | P57/OFF-059 |
| Produktionskostenaufschlüsselung | technisch und im Eigentümer-Sichttest bestätigt | P58/OFF-060 |
| bestätigte Chargen-/Verkaufszuordnung | technisch umgesetzt; Eigentümer-Betriebsnachweis offen | P59/OFF-061 |
| Zeitreihen, Produktstatistik, Gesamtwallet | fehlt | P60 |
| Metenox-Rechner | fehlt | P61 |

## Trennung der fachlichen Zustände

1. **Projekt/Plan:** Was soll mit welchen Entscheidungen und welchem Budget
   hergestellt werden?
2. **Produktionscharge:** Was wurde wann und in welcher Ausprägung
   hergestellt? Charakter und Ort können bei Bedarf ergänzt werden.
3. **Kostenbeleg:** Welche berechnete, manuelle oder bestätigte ESI-Quelle
   trägt welchen Kostenbetrag?
4. **Verkauf:** Welche produzierte Menge wurde zu welchem Preis verkauft?
5. **Auswertung:** Welche Prognose und welcher realisierte Erfolg ergeben sich
   aus unveränderlichen, nachvollziehbaren Quellen?

Eine Neuberechnung des Plans überschreibt niemals eine bereits dokumentierte
Charge oder bestätigte Istzuordnung.

## P57 – Produktionsbuch und Chargen

P57 ist abgeschlossen: native Tabellen-/Detailansicht, manuelle und
optionale ESI-Job-Vorbelegung, Schreibvorschau mit ausdrücklicher Bestätigung,
Schema v26, Backup/Restore sowie Filter nach Jahr, Produkt, Projekt,
Charakter, Ort und Status. OFF-059 bestätigte Charge `2026-0001` für Rhea in
UALX-3 nach vollständigem Prozessende und Neustart mit unveränderter Nummer,
Ausgabemenge, Status und Ort.

Jede Charge erhält mindestens:

- UUID sowie fortlaufende, pro Kalenderjahr eindeutige Anzeigenummer,
- zugehöriges Projekt und Plan-/Graphversion,
- Produktions- beziehungsweise Abschlussdatum,
- Produkt-Type-ID und Namenssnapshot,
- Produktionsaktivität,
- Runs, ME, TE und tatsächliche Ausgabemenge,
- optionalen Charakter, ESI-Industry-Job und Blueprintbezug,
- optional System, Facility, Station oder Struktur,
- Status `geplant`, `produziert`, `im Verkauf`, `abgeschlossen`,
- Quellenidentitäten, Erstellungs- und Änderungszeit.

Projekt, Datum, Status, Runs, ME, TE und Ausgabemenge bilden den
Hauptarbeitsweg. Ort, ESI-Job, Charakter, Blueprintbezug und technische IDs
sind optionale Zusatzangaben und blockieren eine lokale Planungscharge nicht.
Namen können ohne technische ID festgehalten werden; technische Felder sind
eingeklappt. Eine ESI-Jobauswahl erzeugt nur eine Vorschau. Speicherung
erfolgt erst nach Bestätigung. Unvollständig aufgelöste Quellen bleiben
sichtbar und werden nicht erfunden.

## P58 – Kosten und Verkaufspreisvorschläge

P58 ist technisch umgesetzt. Das Produktionsbuch führt pro Charge eine
Vorschau für typisierte Material-, Job-/Index-, Facility-/SCC-/Steuer-,
Blueprint-/Inventions-, Logistik-, Marktgebühren- und sonstige Kosten. Nach
ausdrücklicher Bestätigung wird ein unveränderlicher
`ProductionBatchCostSnapshot` in Schema v27 gespeichert. Leere manuelle
Felder bedeuten unbekannt; eine bewusste Null muss als `0` eingegeben werden.
Unvollständige Kosten sperren Stückkosten und Gewinnkennzahlen.

Jita ist voreingestellt. Eine zweite benannte Region, ein Trade Hub oder ein
bekannter öffentlicher Standort kann als Alternativquote gewählt werden.
Beide Werte sind mengenbezogene Sell-Quotes des bestehenden P41-Vertrags.
Ein manueller/CSV-Preissatz ist nur als ausdrücklich aktivierter Fallback
zulässig. Der technische Review sowie 704 SwiftPM-Tests und der signierte
Xcode-Debugbuild sind bestanden; der Eigentümer hat den realen Sichttest mit
Jita und geänderter Marktquelle als OFF-060 bestätigt.

Kosten werden als typisierte Zeilen geführt:

- Material,
- System-Cost-Index/Jobkosten,
- SCC-/Facility-Abgaben und sonstige Produktionssteuern,
- BPO-/BPC-/Inventionskosten,
- Logistik,
- Markt-/Broker-/Transaktionsgebühren,
- manuelle sonstige Kosten.

Jede Zeile trägt Quelle, Stand, Betrag und Zuordnungsart
`berechnet`, `ESI`, `Transaktion`, `Journal` oder `manuell`.
BPO-Anschaffungskosten werden nicht automatisch vollständig einer Charge
zugeschlagen. BPO/BPC-/Inventionskosten benötigen eine explizite manuelle oder
beleggebundene Zuordnung.

```text
Prognostizierte Gesamtkosten = Summe aller erwarteten Kostenzeilen
Kosten je Unit = Prognostizierte Gesamtkosten / tatsächliche Units
Preisvorschlag +5 % = Kosten je Unit × 1,05
Preisvorschlag +10 % = Kosten je Unit × 1,10
Prognoseerlös = gewählter Verkaufspreis je Unit × Units
Prognosegewinn = Prognoseerlös − prognostizierte Gesamtkosten
Marge = Prognosegewinn / Prognoseerlös
```

Die Vorschläge sind Aufschläge auf Kosten, keine Zielmargenformel. Angezeigt
werden zusätzlich getrennte, mit Ort und Zeitpunkt belegte Jita- und
Home-Hub-Verkaufspreise. Ein Marktwert ersetzt nie stillschweigend eine
manuelle Auswahl.

Für P58 bis P61 ist Jita IV – Moon 4 die voreingestellte, aber jederzeit
änderbare Marktquelle. Alternativ kann der Benutzer eine andere benannte
ESI-Region, einen Trade Hub oder eine bekannte öffentlich abrufbare
Station/Struktur wählen. Jeder Wert trägt Region, Location, Buy-/Sell-Rolle,
Menge, Beobachtungszeit, Cache-/Fallbackstatus und Policy-Version.

Die Reihenfolge ist Live-ESI, gültiger Cache derselben Quelle, sichtbar stale
Cache derselben Quelle, ausdrücklich gewählter manueller/CSV-Preissatz und
schließlich `nicht verfügbar`. Eine Sell-Quote darf nicht als Buy-Quote oder
als realisierter Walletwert ausgegeben werden.

## P59 – Verkauf, Wallet und Realgewinn

P59 ist technisch umgesetzt. Das Produktionsbuch zeigt je Charge vorhandene
Wallet-Verkäufe, Wallet-Gebühren, manuelle Altbelege, die verbleibende
Quellkapazität sowie verkaufte und offene Units. Jede neue Zuordnung besitzt
eine schreibfreie Vorschau und einen getrennten Bestätigungsdialog.

Wallet-/Marktquellen werden nicht automatisch geschrieben. Nexus darf anhand
von Type-ID, Zeitraum, Ort und Restmenge Vorschläge erzeugen. Der Benutzer
wählt und bestätigt:

- Materialkäufe,
- Industry-Job-/Steuer-/SCC-Buchungen,
- BPO-/BPC-Käufe oder manuelle Kosten,
- Verkaufs-Transaktionen,
- Markt-/Broker-/Transaktionssteuern.

Die bestehende Projektzuordnung bleibt Eigentümer der ESI-Quellkapazität.
Eine neue Chargenzuordnung teilt nur bestätigte Projektzuordnungen auf und
darf deren Menge/Betrag nicht überschreiten. Damit kann derselbe Beleg nicht
doppelt als Projekt- und Chargenkosten gezählt werden.

```text
Verkaufte Units = Summe bestätigter Verkaufsmengen
Realisierter Erlös = Summe bestätigter Verkaufstransaktionen
Realisierte Kosten = der verkauften Menge zugeordnete Chargenkosten
Realisierter Gewinn = realisierter Erlös − realisierte Kosten − Verkaufsgebühren
Durchschnittspreis = realisierter Erlös / verkaufte Units
Offene Units = produzierte Units − verkaufte Units
```

Unverkaufte Units behalten ihren Kostenanteil und erzeugen keinen realisierten
Gewinn. Marktaufträge zeigen Angebot und Restmenge; allein ein Auftrag gilt
noch nicht als Verkauf.

Die erste bestätigte Zuordnung bindet die Charge an genau einen
unveränderlichen P58-Kostensnapshot. Schema v28 speichert Verkaufs- und
Gebührenzuordnungen additiv. Eine Offline- oder Accounttrennung entfernt
bestätigte Historie nicht; lediglich neue Walletvorschläge sind dann nicht
verfügbar. Der reale Eigentümernachweis für Teilzuordnung, Vollzuordnung und
identischen Neustartstand bleibt OFF-061.

## P60 – Übersichten und Diagramme

Die Produktionsübersicht bietet Tabelle, Filter und Detailansicht für:

- Jahr, Monat, Produkt, Projekt, Charakter, System und Status,
- produzierte und verkaufte Units,
- prognostizierte und realisierte Kosten/Erlöse/Gewinne,
- durchschnittlichen Verkaufspreis und Gewinn je Unit,
- offene Verkaufsmenge,
- Jita-/Home-Hub-Vergleich.

Diagramme zeigen mindestens Monatsgewinn, Umsatz/Kosten, verkaufte Units und
Produktanteile. Aggregationen nennen Datenstand, unvollständige Zuordnungen
und ausgeblendete/stale Quellen.

Die Walletübersicht zeigt jeden verbundenen Charakter separat sowie eine
Gesamtsumme. Fehlende, veraltete oder nicht autorisierte Wallets werden nicht
als 0 ISK behandelt.

## P61 – Metenox-Wirtschaftlichkeitsrechner

Der Rechner ist vom Produktionsbuch getrennt, kann aber dieselben
Preisangebote verwenden. Eingaben:

- Name/Notiz und optional System/Mond,
- Moon-Ore-Zusammensetzung; Summe muss 100 % ergeben,
- monatliches Fördervolumen oder Betriebsstunden,
- Moon-Ore- und Reprocessing-Zuordnung aus versionierten statischen Daten,
- 40-%-Metenox-Ausbeute,
- Fuel-Block- und Magmatic-Gas-Verbrauch,
- Brennstoff-, Miet-, Logistik-, Anschaffungs- und sonstige Monatskosten,
- Kauf-/Verkaufspreisquelle je Output.

Ausgaben:

- Outputmenge und Wert je Moon Material,
- Buy-/Sell-Szenario,
- monatliche Betriebs- und Gesamtkosten,
- monatlicher Gewinn, Marge und Break-even-Miete,
- optional Amortisationsdauer der einmaligen Investition,
- Monats- und Jahresvergleich mehrerer Monde.

Offiziell belegt sind derzeit die 40-%-Effizienz und 150 Magmatic Gas pro
Stunde. Fuel-Block-Verbrauch, Startmenge und Reprocessingregeln müssen vor P61
erneut gegen aktuelle offizielle Daten beziehungsweise das aktive SDE geprüft
werden. Sie bleiben bis dahin versionierte, sichtbare Annahmen und werden
nicht als endgültige CCP-Regel behauptet.

Offizielle Referenzen:

- https://www.eveonline.com/news/view/equinox-expansion-notes
- https://www.eveonline.com/news/view/patch-notes-version-22-02
- https://support.eveonline.com/hc/en-us/articles/14341380413212-Metenox-Moon-Drill

## Nicht-Ziele

- keine automatische Buchhaltung ohne Benutzerbestätigung,
- keine Corporation-Wallets oder Corporation-Strukturen,
- keine automatische BPO-Amortisationsannahme,
- keine automatische Steuer-/Gebührenannahme bei fehlender Quelle,
- kein Import der privaten Referenzarbeitsmappe in Git,
- keine nachträgliche Erfindung fehlender ESI-Historie,
- kein Start der verbleibenden P58–P61 ohne ausdrücklichen Auftrag.

## Reihenfolge

P57 ist abgeschlossen. Verbleibende Reihenfolge:

1. P58 – Kostenaufschlüsselung und Preisvorschläge,
2. P59 – Wallet-/Verkaufszuordnung und Realgewinn,
3. P60 – Produktionsanalyse und Gesamtwallet,
4. P61 – Metenox-Wirtschaftlichkeitsrechner.

P54 bleibt ein unabhängiger optionaler lokaler Sicherungscommit und benötigt
weiterhin eine eigene ausdrückliche Freigabe.
