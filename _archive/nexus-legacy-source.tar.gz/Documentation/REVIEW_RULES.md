# Review-Regeln

Verbindliche Kontrollregeln für New Eden Nexus  
Stand: 2026-07-23

## 1. Zweck und Unabhängigkeit

Jeder Implementierungsprompt endet mit einem gesonderten Review. Der Review ist keine Wiederholung des Abschlussberichts und übernimmt keine Selbstaussage ungeprüft. Er bewertet ausschließlich nachprüfbare Artefakte: Auftrag, Abnahmekriterien, tatsächlichen Dateidiff, Quellcode, Datenwirkung, Build- und Testausgaben sowie aktualisierte Dokumentation.

Der Review darf vom Implementierungsergebnis abweichen. Ein erfolgreicher Build oder eine sichtbare Benutzeroberfläche reicht nicht für eine positive Gesamtentscheidung.

## 2. Review-Voraussetzungen

Vor Beginn des Reviews erfassen:

- Prompt-ID, Ziel, Scope und Abnahmekriterien,
- Ausgangsbranch und aktuelle Git-Wurzel,
- Git-Status vor und nach der Änderung,
- vorhandene Benutzeränderungen,
- Liste neuer, geänderter, gelöschter und verschobener Dateien,
- betroffene Module, Datenmodelle und Schnittstellen,
- relevante Projektbuchkapitel, ADRs und bekannte Probleme,
- dokumentierte Build- und Testbefehle.

Fehlt eine für die Bewertung notwendige Grundlage, darf der Review nicht stillschweigend positiv entscheiden. Er kennzeichnet die Prüfung als eingeschränkt oder blockiert.

Für PLAN-002 werden nur der aktuelle Prompt, die betroffenen Dateien,
relevante ADRs/offene Punkte und die tatsächlich verwendeten Nachweise
geladen. Unveränderte Altberichte oder das vollständige Projektbuch werden
nicht erneut wiedergegeben. Das reduziert Kontext, nicht Prüftiefe.

## 3. Scope- und Anforderungsreview

Prüfen:

- Wurde ausschließlich der aktuelle Auftrag umgesetzt?
- Sind alle Muss-Anforderungen enthalten?
- Wurden alle für das Prompt-Ergebnis notwendigen aktiven Punkte aus
  `OFFEN.md`, `OPEN_TASKS.md` und `KNOWN_ISSUES.md` mit ID, Restarbeit und
  Prüfnachweis übernommen und tatsächlich bearbeitet?
- Wurden verschobene Funktionen nicht vorgezogen?
- Wurde vorhandener Zukunftscode nicht fälschlich als MVP-Fortschritt gewertet?
- Sind Abweichungen vom Prompt, Projektbeschreibung oder Projektbuch ausdrücklich dokumentiert?
- Wurden Annahmen als Annahmen gekennzeichnet?
- Wurden keine Benutzeränderungen verloren oder überschrieben?

Jede nicht erfüllte Muss-Anforderung ist ein Review-Fund. Fehlende Kernanforderungen verhindern `✅ bestanden`.

## 4. Diff- und Dateireview

Den tatsächlichen Diff beziehungsweise bei untracked Dateien den vollständigen aktuellen Inhalt prüfen. Insbesondere:

- Gehört jede Änderung zum Auftrag?
- Gibt es unbeabsichtigte Format-, Buildartefakt- oder Benutzerdateiänderungen?
- Wurden Dateien ohne Not gelöscht, verschoben oder vollständig ersetzt?
- Sind neue Dateien am richtigen Ort und korrekt verlinkt?
- Sind lokale Pfade, Konfigurationswerte oder Geheimnisse fest codiert?
- Sind Duplikate, tote Pfade oder widersprüchliche Dokumente entstanden?

Die gültige Projekt-Git-Wurzel ist ausschließlich
`/Users/svenstolze/Documents/Codex/EVE Nexus`. Das weiterhin vorhandene
übergeordnete Repository `/Users/svenstolze/.git` und andere Home-Inhalte
niemals als Projekt-Diff akzeptieren, stagen oder verändern. Seit P09A besteht
auf `main` eine geprüfte Root-Baseline. Künftige Reviews erfassen deshalb vor
der Arbeit den Ausgangscommit und prüfen danach `git diff`, Status sowie neue
untracked Dateien gegen genau diesen Stand. Untracked Dateien sind weiterhin
vollständig zu lesen; ein leerer tracked Diff genügt dafür nicht.

## 5. Architekturreview

Prüfen:

- Trennung von UI, Anwendungslogik, Domäne und Datenhaltung,
- keine Fachlogik, Datenbank- oder Netzwerkzugriffe direkt in neuen Views,
- Dependency Injection statt versteckter globaler Abhängigkeiten,
- klare Protokolle und austauschbare Datenquellen,
- Local-/Offline-First-Eignung,
- deterministische Fachlogik,
- zentrale Konfiguration, Fehlerbehandlung und Design Tokens,
- Single Responsibility und angemessene Dateigrößen,
- keine unnötige neue Abhängigkeit oder Großrestrukturierung.

Architekturentscheidungen müssen mit bestehenden ADRs vereinbar sein. Eine neue oder ersetzende Grundentscheidung benötigt einen ADR mit Kontext, Alternativen, Entscheidung, Begründung und Konsequenzen.

## 6. Fachlichkeits- und Berechnungsreview

Für Produktions-, Mengen-, Kosten- und Gewinnlogik prüfen:

- identische Eingaben liefern identische Ergebnisse,
- feste Eingaben und erwartete Werte sind als Referenztests vorhanden,
- Berechnungsreihenfolge entspricht den verbindlichen Regeln,
- Rundungsregeln sind zentral, begründet und nicht willkürlich,
- Runs, Outputmengen und Einheiten sind korrekt,
- Herkunft statischer Daten und Preisquellen ist nachvollziehbar,
- Bestände, Reservierungen und Sicherheitsbestände werden in richtiger Reihenfolge berücksichtigt,
- Build-or-Buy bleibt erklärbar und manuell übersteuerbar,
- unklare Regeln sind offen dokumentiert statt geraten,
- Berechnungsergebnis und Zwischenstufen sind versionierbar und nachvollziehbar.

Eine fachlich nicht verifizierte Formel ist mindestens ein hoher Fund. Eine nachweislich falsche Kernberechnung ist kritisch.

## 7. Datenintegritäts- und Migrationsreview

Bei Datenmodell- oder Persistenzänderungen prüfen:

- aktuelle und neue Schemaversion,
- explizite, versionierte Migration,
- Erhalt bestehender Daten und Referenzen,
- Migrationstest mit Altbestand,
- Test einer leeren neuen Datenbank,
- Transaktions- und Rollbackverhalten,
- Constraints, Eindeutigkeit und Referenzintegrität,
- Backup vor potenziell destruktiver Änderung,
- geprüfte Wiederherstellungsstrategie,
- dokumentierte Datenwirkung.

Nicht autorisierte destruktive Migration, ungesicherter Datenverlust oder fehlender Rückweg ist kritisch und führt zu `❌ nicht bestanden`.

## 8. Nebenläufigkeits- und Lebenszyklusreview

Prüfen:

- blockierende Arbeit läuft nicht auf dem Main Thread,
- `async`/`await` und strukturierte Nebenläufigkeit werden korrekt verwendet,
- Tasks besitzen Abbruch- und Lebenszyklusverhalten,
- keine unbeschränkte Parallelität oder Datenrennen,
- UI-Zustand wird auf dem richtigen Actor aktualisiert,
- Fehler und Cancellation werden nicht verschluckt,
- Ressourcen, Prozesse, Dateien und Netzwerkoperationen werden zuverlässig beendet.

## 9. Sicherheits- und Datenschutzreview

Prüfen:

- keine Passwörter, Tokens oder Client Secrets in Code, Git, Logs, Preferences, Tests, Screenshots oder Berichten,
- Tokens ausschließlich im Betriebssystem-Schlüsselspeicher,
- Logs und Diagnosepakete sind redigiert,
- importierte Dateien und Eingaben werden validiert,
- Dateipfade und Exporte werden defensiv behandelt,
- Backups berücksichtigen Vertraulichkeit und Integrität,
- Berechtigungen sind minimal und nachvollziehbar,
- Signing- und Team-Einstellungen wurden nicht ohne Auftrag geändert.

Ein eingechecktes Geheimnis oder ungeschützte Tokenpersistenz ist kritisch.

## 10. Benutzeroberflächenreview

Für neue oder geänderte Ansichten prüfen:

- klare Hierarchie und konsistente Navigation,
- vorhandene Komponenten und Design Tokens verwendet,
- einheitliche Terminologie,
- Empty-, Loading-, Error- und Warnzustände,
- Tastaturbedienung, Fokusführung und VoiceOver,
- Kontrast, Dynamic Type beziehungsweise skalierbare Inhalte,
- lange/lokalisierte Texte,
- schmale und breite Fenster,
- große Datenmengen und sinnvolle Begrenzung/Pagination,
- keine unnötige Fachlogik im View.

Manuelle Prüfungsschritte und gegebenenfalls Screenshots dürfen nur als bestanden dokumentiert werden, wenn sie tatsächlich durchgeführt wurden.

## 11. Performancereview

Prüfen:

- keine vollständigen Abfragen bei jeder View-Aktualisierung,
- keine unnötigen wiederholten Berechnungen oder Parserläufe,
- keine ungebremste Materialisierung großer Datenmengen,
- keine Main-Thread-Blockade,
- Caching und Pagination sind bei Bedarf begründet,
- Performancebehauptungen besitzen Messbefehl, Datensatz, Umgebung und Ergebnis.

Unbelegte Aussagen wie „performant“ oder „optimiert“ sind aus Dokumentation und Abschlussbericht zu entfernen oder als ungemessen zu kennzeichnen.

## 12. Buildreview

Vor Bewertung Scheme/Produkt, Konfiguration, Zielplattform und Testtargets feststellen. Dann prüfen:

- dokumentierter Befehl wurde tatsächlich ausgeführt,
- Exit-Status war erfolgreich,
- richtige Konfiguration und richtiges Ziel wurden verwendet,
- Warnungen und Fehler sind vollständig erfasst,
- Warnungen wurden nicht pauschal unterdrückt,
- Buildartefakte wurden nicht versehentlich als Quelländerungen behandelt.

Ein nicht ausgeführter oder fehlgeschlagener relevanter Build darf nicht als erfolgreich gelten.

Die Prüftiefe ist risikobasiert: fokussierte Tests plus vollständiges
SwiftPM Debug sind der Normalfall. Xcode Debug ist bei App-/UI-/
Projektänderungen Pflicht. Release, Real-SDE und wiederholte Vollsuiten
werden nur bei betroffener Grenze oder explizitem Releaseauftrag verlangt.
Der Review muss den tatsächlich kleineren Umfang sichtbar nennen.

## 13. Testreview

Prüfen:

- neue oder geänderte Fachlogik besitzt passende Tests,
- Normalfall, Grenzen, leere/ungültige Eingaben und Fehlerpfade sind abgedeckt,
- Persistenz und Migrationen sind bei Betroffenheit getestet,
- Referenztests verwenden feste Ein- und Erwartungswerte,
- Regressionstests schützen geänderte Altlogik,
- Tests sind deterministisch, isoliert und nutzen keine Produktivdaten,
- keine Tests wurden zur Fehlervermeidung gelöscht, abgeschwächt oder übersprungen,
- dokumentierte Anzahl und Ergebnis entsprechen der echten Ausgabe.

Übersprungene oder nicht ausgeführte Tests zählen nicht als bestanden. Eine grüne Testsuite mit fehlender relevanter Abdeckung kann höchstens `⚠️ mit Einschränkungen bestanden` rechtfertigen.

## 14. Dokumentationsreview

Mindestens prüfen:

- `CURRENT_PROJECT_STATUS.md`,
- `DEVELOPER_MENU.md`,
- `FEATURE_MATRIX.md`,
- `DEVELOPER_DIARY.md`,
- `OPEN_TASKS.md`,
- `KNOWN_ISSUES.md`,
- `TEST_HISTORY.md`,
- relevante Fachdokumentation,
- Abschlussbericht,
- bei Architekturänderungen `ARCHITECTURE_CHANGES.md` und ADR.

Status, Build-/Testzahlen, Dateilisten, offene Punkte und nächster Prompt müssen untereinander konsistent sein. Geplantes darf nicht als implementiert erscheinen. Alte Berichte bleiben unverändert.

Nur Dateien mit geändertem Status oder Nachweis benötigen einen
Deltaeintrag. Keine positive Reviewentscheidung darf jedoch auf fehlende
oder veraltete Steuerinformationen gestützt werden.

## 15. Schweregrade

### Kritisch

- Datenverlust oder unautorisierte destruktive Änderung,
- falsche Kernberechnung mit produktiver Wirkung,
- offengelegtes Geheimnis oder Token,
- beschädigte Migration ohne Wiederherstellungsweg,
- schwerwiegende Regression einer Kernfunktion.

### Hoch

- Muss-Anforderung fehlt,
- relevante Funktion nicht nutzbar,
- zentrale Fehler-/Datenintegritätsregel verletzt,
- Build oder relevante Tests fehlgeschlagen,
- Architekturgrenze mit erheblichem Folgerisiko verletzt.

### Mittel

- Teilfunktion eingeschränkt,
- relevante Rand- oder Fehlerfälle fehlen,
- Dokumentation widersprüchlich,
- Accessibility- oder Performanceproblem ohne Datenverlust.

### Niedrig

- lokaler Text-, Layout- oder Komfortmangel ohne fachliche Auswirkung.

## 16. Reviewentscheidung

### ✅ bestanden

Alle Muss-Kriterien und die Definition of Done sind belegt. Kein kritischer oder hoher Fund ist offen. Relevante Build-, Test-, Dokumentations- und Datenprüfungen sind erfolgreich.

### ⚠️ mit Einschränkungen bestanden

Der Kernauftrag ist nutzbar, aber nichtkritische Einschränkungen, fehlende nichtzentrale Prüfungen oder klar begrenzte Blocker bleiben. Jeder Fund besitzt konkrete Korrekturaufgabe, Priorität und Nachweisweg. Der Promptstatus bleibt entsprechend `⚠️`, sofern seine DoD nicht vollständig erfüllt ist.

### ❌ nicht bestanden

Eine Muss-Anforderung, Build-/Testgrundlage, Datenintegrität, Sicherheit oder Kernfachlichkeit ist nicht erfüllt. Der Prompt darf nicht als erledigt markiert werden.

## 17. Reviewprotokoll

Der Abschlussbericht enthält mindestens:

- Reviewumfang und geprüfte Artefakte,
- Befunde nach Schweregrad mit Datei-/Bereichsbezug,
- Build- und Testnachweis,
- manuelle Prüfungen,
- nicht prüfbare Punkte,
- Entscheidung mit Begründung,
- konkrete Korrekturaufgaben bei `⚠️` oder `❌`,
- Namen/Pfad des Reviewberichts beziehungsweise Abschlussberichts.

## 18. Kontrollprüfung nach Korrekturen

Nach jeder Reviewkorrektur:

1. betroffenen Fehler erneut reproduzieren beziehungsweise den Fund erneut prüfen,
2. tatsächlichen Korrekturdiff lesen,
3. Regressionstest oder strukturellen Nachweis prüfen,
4. relevanten Build und Tests wiederholen,
5. Dokumentation und Fundstatus aktualisieren,
6. Reviewentscheidung neu treffen.

Ein Fund wird erst geschlossen, wenn sein Nachweis tatsächlich geprüft wurde.
