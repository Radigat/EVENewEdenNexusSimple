# Manuelle Preise und Preissätze

Stand: 2026-07-25 · P27 · Schema v16

## Zweck und Grenzen

P27 verwaltet ausschließlich lokale manuelle ISK-Einheitspreise in
wiederverwendbaren Preissätzen. CSV-Import, Live-Marktpreise, Kosten, Gewinn,
ROI und Einkaufsstatus gehören nicht zu P27.

## Fachliche Regeln

- Beträge werden exakt als positive `Int64`-Hundertstel ISK gespeichert.
- Zulässige Eingaben: `123`, `123.4`, `123.45`, `123,4`, `123,45`.
- Null, Vorzeichen, Tausendertrennzeichen, mehr als zwei Nachkommastellen
  und Überlauf werden abgelehnt.
- Pro Profil und CCP-Type-ID existiert höchstens ein Preis.
- Nur veröffentlichte Items der aktiven lokalen SDE-Version sind zulässig.
- Quelle ist in P27 immer `manual`.
- `validFrom` ist inklusive, `validUntil` optional und exklusiv.
- Fehlende, zukünftige oder abgelaufene Preise bleiben explizit fehlend.

## Preissätze

Ein Preissatz ist keine Währungswahl. Alle Beträge werden ausschließlich in
ISK geführt. Er trennt einen nachvollziehbaren Preisstand oder ein Szenario,
beispielsweise „Jita Einkauf“, „Amarr Einkauf“ oder „manuell konservativ“.
Der interne Typname `PriceProfileSnapshot` bleibt zur Datenkompatibilität
erhalten.

Preissatznamen sind nach der projektweiten POSIX-Normalisierung eindeutig. Der
erste Preissatz wird aktiv. Ein anderer Preissatz wird nur durch „Als aktiv
verwenden“ aktiviert. Beim bestätigten Löschen eines aktiven Profils wird das
normalisiert alphabetisch erste verbleibende Profil aktiv; alle Preise des
gelöschten Profils werden atomar entfernt.

## Architektur

- Domain: `ISKAmount`, `PriceProfileSnapshot`, `ManualPriceSnapshot`,
  `PriceResolution`
- Application: `PriceProfileManaging`,
  `PriceProfileManagementService`, `PriceProfileRepository`
- Persistence: `NexusSchemaV16`,
  `SwiftDataPriceProfileRepository`
- UI: `PriceProfileViewModel`, `PriceProfileView`,
  `PriceProfileAppComposition`

Views importieren kein SwiftData. Speichern erfolgt explizit über Formulare;
Löschungen verlangen eine sichtbare Bestätigung. Optimistische
Änderungszeitpunkte verhindern das Überschreiben veralteter Datensätze.

## Auflösung für Folgepakete

`resolve(typeIDs:profileID:at:)` liefert das verwendete Profil, gültige
Beträge als `pricesByTypeID` und sortierte `missingTypeIDs`. Der Service
erzeugt nie einen Nullpreis. P29 kann diese Grenze verwenden, ohne
Preisvalidierung oder Gültigkeitslogik zu duplizieren.

## Daten- und Migrationsschutz

Schema v16 ergänzt `PriceProfileRecord` und `ManualPriceRecord` additiv.
Die leichte v15→v16-Migration erhält Projekte, Graphen, Lager,
Reservierungen und Build-or-Buy-Entscheidungen und legt keine erfundenen
Profile an. Der Backupdienst schreibt 16.0.0 und akzeptiert 1.0.0 bis
16.0.0.
