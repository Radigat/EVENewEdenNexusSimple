# P36 – Migration und Recovery-Drill

- **Datum:** 2026-07-26
- **Status:** ✅ erledigt
- **Review:** ✅ bestanden

## Ziel und Ausgangszustand

OFF-006 war mit Vor-Migrations-Backup, Restore und Wiederöffnung erledigt.
Offen war OFF-024: ein real von außen beendeter SDE-Installationsprozess und
der Neustart derselben isolierten Store-Composition.

## Durchgeführte Änderungen

- Optionalen Acceptance-Checkpoint nach erfolgreicher
  Installationsjournal-Persistenz ergänzt.
- `NewEdenNexusSDEAcceptance` um einen Mehrprozess-Recovery-Drill erweitert.
- Fünf getrennte temporäre Stores mit synthetischem SDE-Archiv und festem
  Charakter-/Projektbestand vorbereitet.
- Je einen Installationsprozess bei `downloading`, `validatingSource`,
  `validatingStagingStore`, `creatingSafetyBackup` und `promoting` nach
  Prüfung der exakten PID durch `SIGKILL` beendet.
- Je eine neue Recovery-Composition auf demselben Store gestartet und
  Altbuild, Katalog, Benutzerdaten, Journal, Rollback, Aufbewahrung,
  idempotenten zweiten Start und Cleanup geprüft.

## Dateien

Neu: `P36RecoveryAcceptance.swift`, ADR-0042 und dieser Bericht.

Geändert: SDE-Installationsvertrag/-service, Acceptance-Runner,
`SDEInstallationServiceTests`, Xcode-Projekt sowie die betroffenen
Steuer-, SDE-, Architektur- und Testdokumente. `main.swift` wurde in
`SDEAcceptanceRunner.swift` umbenannt. Gelöscht wurden keine fachlichen
Dateien.

## Architektur und Daten

Der Checkpoint ist eine optionale Dependency und bleibt in produktiven
Compositions `nil`; es existiert kein Release-Crashschalter. Der externe
Koordinator akzeptiert nur eigens benannte temporäre Szenariowurzeln und
beendet ausschließlich die selbst gestartete PID. Schema v20, Migrationen
und produktive Benutzerdaten wurden nicht verändert.

## Build und Tests

- `swift test --disable-sandbox --scratch-path
  /tmp/new-eden-nexus-p36-full`: **527/527 bestanden**.
- Xcode Debug `NewEdenNexusSDEAcceptance`: **BUILD SUCCEEDED**.
- Xcode Debug `NewEdenNexus`: **BUILD SUCCEEDED**.
- `xcrun xctest -XCTest SDEInstallationServiceTests ...`:
  **6/6 bestanden**.
- Mehrprozess-Drill: fünf verschiedene PIDs, fünf `SIGKILL`-Exits mit
  Signalstatus 9 und **5/5 erfolgreiche Neustart-/Integritätsprüfungen**.
- Unsichere Wurzel `/tmp/not-a-p36-store`: Exit 1 wie erwartet.

Ein Xcode-Scheme-Testlauf konnte in der Codex-Sandbox
`testmanagerd.control` nicht erreichen. Der Wiederholungsversuch außerhalb
der Sandbox blieb vor Testbeginn stehen und wurde beendet. Der
Xcode-kompilierte relevante Testbund lief direkt im nativen Runner grün.
OFF-031 bleibt deshalb als Release-Testinfrastrukturpunkt bestehen.

## Review und Abnahme

Geprüft wurden tatsächlicher Diff, Reihenfolge Persistenz→Checkpoint,
PID-Bindung, Signalexit, Wiederöffnung, Datenwertgleichheit, aktiver
Altbuild, Katalogabfrage, terminales Journal, Rollback, Paket-/Backupregel,
Cleanup, Fremdpfad-Ablehnung, Builds, Tests und Dokumentation.

Alle P36-Abnahmekriterien sind erfüllt. OFF-024 und KI-024 sind geschlossen.
Es blieb keine durch P36 verursachte kritische oder hohe Regression offen.

## Bekannte Probleme und offene Anforderungen

OFF-031 sowie die zeitabhängige öffentliche Release-/Complianceprüfung
bleiben offen. Sie sind keine P36-Fachrestarbeit. Abweichungen vom Projektbuch
oder Datenmodelländerungen: keine.

## Nächster empfohlener Prompt

Öffentliche Release-/Complianceprüfung einschließlich OFF-031. P38
(SSO-Härtung) bleibt bis zu einem ausdrücklichen Auftrag verschoben.
