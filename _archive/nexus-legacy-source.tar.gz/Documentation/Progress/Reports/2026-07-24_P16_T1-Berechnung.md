# Abschlussbericht – P16: T1-Berechnung

Datum: 2026-07-24  
Prompt-ID: P16  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

P16 vollständig spezifizieren und den bisher einstufigen Produktionsgraphen
zu einer deterministischen, mehrstufigen Manufacturing-only-T1-Kette
erweitern, ohne T2, Reaktionen, Aggregation oder Build-or-Buy vorzuziehen.

## Ausgangszustand

P15 lieferte Schema v8 und Graphformat 3 mit Zielruns, Ausgabe, Überschuss
und ME-berechneten Materialkanten der ersten Rezeptstufe.
Manufacturing-Zwischenprodukte wurden noch nicht aufgelöst. Der Arbeitsbaum
enthielt umfangreiche uncommittete Änderungen aus P09B bis P15; sie wurden
erhalten und weder zurückgesetzt noch überschrieben. Es wurde nicht
committed, gepusht, gemerged oder rebased.

## Durchgeführte Änderungen

- P16 mit Zweck, Abgrenzung, Referenzketten, Abbruchregeln, Schutzgrenzen,
  offenen Punkten, Tests und Definition of Done vollständig spezifiziert.
- `ProductionGraphService` löst eindeutige Manufacturing-Rezepte
  rekursiv auf.
- Jede Rezeptstufe berechnet Sollmenge, Runs, Ausgabe, Überschuss,
  Rohmaterial, Effektivmaterial und Ersparnis.
- Graphformat 4 mit Expansionsrichtlinienversion 1 eingeführt.
- Ziel-ME und neutraler Zwischenprodukt-ME 0 werden mit unterschiedlicher
  Herkunft gespeichert und dargestellt.
- Materialblätter unterscheiden `kein Herstellungsrezept` und
  `Reaktion folgt in P18`.
- Gleiche Typen bleiben in verschiedenen Zweigen getrennte Vorkommen.
- Zyklen werden über den Vorfahrenpfad erkannt.
- Tiefe 64 und ein globales Budget von 25.000 Knoten schützen die
  Traversierung.
- Mehrdeutige, ungelöste, ungültige und versionsfremde Rezepte brechen
  ohne Speichern ab.
- Cancellation und alle vorhandenen Run-/Materialüberlaufpfade erhalten
  den Altgraphen.
- Format 1, 2 und 3 bleiben lesbar und gelten als veraltet.
- Format 4 nutzt die vorhandene Schema-v8-Payload; keine Schemamigration
  oder Backupversionsänderung war erforderlich.
- Graphansicht um Expansionsregel, Knotenzahl, Stufen-ME, Herkunft,
  Zwischenproduktwerte und Blattgründe ergänzt.
- P16-Anteile von OFF-004, OFF-009 und OFF-021 geprüft und dokumentiert.

## Neu erstellte Dateien

- `Documentation/T1_CALCULATION.md`
- `Documentation/Architecture/ADRs/ADR-0021_Manufacturing-Rekursion-und-Graphformat-4.md`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusDomain/ProductionGraph.swift`
- `Sources/NewEdenNexusApplication/ProductionGraph.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionGraphRepository.swift`
- `Sources/NewEdenNexus/ProductionGraphView.swift`
- Graph-Domain-, Application-, Persistence-, ViewModel- und
  Architekturtests,
- `NewEdenNexus.xcodeproj/project.pbxproj`,
- P16-Prompt, Graph-, Architektur-, Datenmodell-, Status-, Roadmap-,
  Feature-, Tagebuch-, Test-, Aufgaben-, Problem- und ADR-Register.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

1. P16 ist ein Manufacturing-only-Rechenpfad und rät keine Tech-Stufe.
2. Die effektive Menge einer Materialkante ist die Sollausgabe des
   zugehörigen Zwischenprodukts.
3. Automatisch entdeckte Zwischenprodukte verwenden transparent den
   neutralen Planungswert ME 0, nicht einen erfundenen Benutzer-Blueprint.
4. Knoten sind Vorkommen; Aggregation bleibt P19.
5. Ein vollständiger Kandidat wird erst nach aller Traversierung und
   Domänenvalidierung gespeichert.
6. Graphformat 4 benötigt keine neue SwiftData-Schemaversion.

Siehe
[`ADR-0021`](../../Architecture/ADRs/ADR-0021_Manufacturing-Rekursion-und-Graphformat-4.md).

## Datenmodelländerungen

Keine SwiftData-Schemaänderung. Das codierte Graphpayload ergänzt optional:

- `expansionPolicyVersion`,
- `recipe.materialEfficiency`,
- `recipe.materialEfficiencySource`,
- `node.leafReason`.

Format 3 behält Materialformelmetadatum 1; Format 4 verwendet dieselbe
Run- und Materialformelversion. Schema v8 und Backupmanifest 8.0.0 bleiben
unverändert.

## Build-Ergebnis

Erfolgreich:

```text
env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P16-Debug/module-cache \
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P16-Debug/module-cache \
  swift test --scratch-path /private/tmp/NewEdenNexus-P16-Debug/build -c debug

env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P16-Release/module-cache \
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P16-Release/module-cache \
  swift test --scratch-path /private/tmp/NewEdenNexus-P16-Release/build -c release

Scripts/generate_xcode_project.sh
python3 Scripts/verify_xcode_project.py

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Debug -destination platform=macOS \
  -derivedDataPath /private/tmp/NewEdenNexus-P16-Xcode-Debug \
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Release -destination platform=macOS \
  -derivedDataPath /private/tmp/NewEdenNexus-P16-Xcode-Release \
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
```

Signing- und Teamwerte wurden nicht geändert. Xcode wählte aus zwei
passenden My-Mac-Zielen arm64. Die Projektprüfung meldete 15 Targets, sieben
Testtargets und zwei gemeinsame Schemes.

Der erste SwiftPM-Aufruf innerhalb der verschachtelten Ausführungssandbox
scheiterte an `sandbox_apply: Operation not permitted`. Derselbe Befehl
wurde außerhalb dieser äußeren Sandbox erfolgreich ausgeführt; dies war
kein Quellcodefehler.

## Testergebnis

- SwiftPM Debug: 280 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 280 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 280 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Release: 280 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode-Ergebnisse mit `xcresulttool` ausgelesen.
- Xcode-Projektprüfung: bestanden.
- `git diff --check`: bestanden.

Geprüft wurden insbesondere:

- dreistufige Referenzkette mit den Sollmengen 18, 15, 45, 35 und 22,
- Runs und Überschuss jedes Zwischenprodukts,
- deterministische Wiederholung,
- getrennte gleiche Materialvorkommen,
- Endmaterial- und Reaktionsblattgründe,
- Projekt-ME und neutraler Zwischenprodukt-ME,
- Kanten-/Sollmengenkopplung,
- mehrdeutige und ungelöste Zwischenrezepte,
- Zykluspfad,
- Tiefen- und globales Knotenbudget,
- Cancellation während der Traversierung,
- Run- und Materialüberlauf,
- Bestandsschutz bei allen Fehlern und Savefehler,
- Graphformat 1 bis 4 und Format-4-Manipulationsschutz,
- Format-4-Persistenz und Format-3-Altbestand,
- unveränderte Schema-v8-/Backupgrenze,
- UI-, ViewModel- und Schichtengrenzen.

## Manuelle Prüfungen

Das gebaute Xcode-Debug-App-Binary lief sechs Sekunden mit dem isolierten
Store `/private/tmp/NewEdenNexus-P16-Smoke/P16.store`.

- `PRAGMA integrity_check`: `ok`
- App-Log: leer
- Prozess anschließend kontrolliert beendet

Produktive Benutzerdaten wurden nicht geöffnet oder verändert. Ein neuer
visueller VoiceOver-Lauf wurde nicht durchgeführt und wird nicht behauptet;
UI-Kompilation, Texte, Accessibility-Metadaten und Schichtengrenzen sind
automatisiert geprüft.

## Gefundene und behobene Probleme

1. Nach Anhebung von `currentFormatVersion` auf 4 verwendeten frühere Tests
   den alten Alias unbeabsichtigt für Format-3-Fixtures. Die Tests wurden
   fachlich getrennt: Altformatprüfungen nennen Format 3 explizit, aktuelle
   Fixtures tragen vollständige Format-4-Provenienz.
2. Der gesonderte Review erkannte, dass eine erste Knotenlimitprüfung den
   Grenzwert zwar vor Persistenz abwies, kombinierte Teilbäume aber
   vorübergehend über das globale Budget hinaus aufbauen konnte. Die
   Traversierung erhielt ein verbleibendes globales Knotenbudget; fokussierte
   und alle vier vollständigen Suites wurden danach erneut erfolgreich
   ausgeführt.

## Bekannte Probleme und offene Anforderungen

- `OFF-004`/`KI-003`: teilweise; T1 ist geschlossen, T2 folgt P17,
  Reaktionen P18 und Aggregation P19.
- `OFF-009`/`KI-012`: rekursive Einzelberechnungen sind geschützt;
  Aggregationssummen folgen P19.
- `OFF-021`/`KI-021`: vorhandene Typ-, Blueprint-, Aktivitäts-, Produkt-
  und Materialdaten genügen P16; spätere Daten bleiben bedarfsgesteuert.
- `OFF-006`/`KI-006`/`KI-013`: keine P16-Schemaänderung; automatisches
  Vor-Migrationsbackup und Recovery-Drill bleiben P36.
- `OFF-027`/`KI-027`: die vorhandene Graphansicht wurde begrenzt ergänzt;
  Editoraufteilung bleibt P34.

Keine dieser Restaufgaben verhindert die vollständige P16-Abnahme.

## Abweichungen vom Projektbuch

Die Projektbuchforderung nach rekursiver Auflösung wird für den
Manufacturing-only-T1-Pfad umgesetzt. Materialaggregation wird bewusst
nicht vorgezogen. Eine nicht importierte Tech-Stufe und konkrete
Zwischenprodukt-Blueprint-ME-Werte werden nicht geraten.

## Erfüllte Abnahmekriterien

- vollständige P16-Spezifikation: erfüllt,
- dreistufige Referenzkette: erfüllt,
- Graphformat-4-Invarianten: erfüllt,
- Altformate lesbar und veraltet: erfüllt,
- Fehler-/Abbruch-Bestandsschutz: erfüllt,
- notwendige offene Punkte geprüft: erfüllt,
- SwiftPM Debug/Release: erfüllt,
- Xcode Debug/Release: erfüllt,
- keine übersprungenen Tests: erfüllt,
- isolierter App-/Store-Smoke: erfüllt,
- Pflichtdokumentation und Bericht: erfüllt,
- gesonderter Review: erfüllt.

## Nicht erfüllte Abnahmekriterien

Keine für P16.

## Reviewentscheidung

**✅ bestanden.** Der gesonderte Review prüfte tatsächliche Quelltexte,
Graph- und Persistenzinvarianten, globales Knotenbudget, Datenwirkung,
Fehler- und Abbruchpfade, alle endgültigen Build-/Testergebnisse, den
isolierten Store, Dokumentation und offene Register. Die im Review gefundene
Budgetschwäche wurde korrigiert und vollständig nachgetestet. P17 wurde
nicht begonnen.

## Nächster empfohlener Prompt

P17 – T2-Berechnung zunächst vollständig spezifizieren und anschließend
ausführen. Alle für P17 notwendigen offenen Punkte sind verbindlich in den
Scope aufzunehmen.
