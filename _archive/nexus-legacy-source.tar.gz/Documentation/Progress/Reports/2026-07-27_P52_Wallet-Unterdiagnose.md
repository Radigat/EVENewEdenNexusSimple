# P52 – Wallet-Unterdiagnose

Status: ⚠️ technisch bestanden; Livenachweis offen

## Ziel und Ausgangszustand

Wallet-Inspect meldete trotz eines begrenzten Pagination-Retry erneut
`NEN-ESI-004`. Der bisherige redigierte Grund `inconsistent_pagination`
bezeichnete mehrere unterschiedliche Schutzgrenzen.

## Änderungen

- `ESIWalletError` trägt einen typisierten, wertfreien Pagination-Untergrund.
- Der Walletclient unterscheidet Seitenzahlwechsel, fehlendes oder
  abweichendes `Last-Modified`, Journalduplikate, widersprüchliche
  Transaktionen und einen stehenden Transaktionscursor.
- Die UI behält `NEN-ESI-004`; Diagnoseereignisse enthalten keine Walletwerte,
  IDs, Tokens oder Headerwerte.
- Bestehender einmaliger Retry und CCP-Konsistenzprüfung bleiben unverändert.

Keine Schema-, Migrations- oder Fachdatenänderung. Keine Walletvorschau wurde
übernommen.

## Prüfung

- fokussiert: **15/15 Tests bestanden**,
- SwiftPM vollständig außerhalb der Dateisandbox: **644/644 bestanden**,
- signierter Xcode Debug, Scheme `NewEdenNexus`, macOS arm64:
  **BUILD SUCCEEDED**,
- `git diff --check`: **bestanden**.

Der eingeschränkte SwiftPM-Vorlauf konnte drei bereits vorhandene
Security.framework-`SecKey`-Fixtures nicht erzeugen; dieselben Fälle bestanden
im vollständigen Lauf außerhalb der Dateisandbox.

## Review und offene Abnahme

Technischer Review: **✅ bestanden**. Die Änderung erweitert ausschließlich
die redigierte Fehlerklassifikation und lockert keine Daten- oder
Konsistenzgrenze.

P52/OFF-041: **⚠️ offen**. Der Projekteigentümer muss den neuen Build starten,
Wallet genau einmal prüfen und nur den sicheren
`error_reason=inconsistent_pagination_…` melden. Ein Apply bleibt bis zu einem
erfolgreichen Inspect gesperrt. P53 wurde nicht begonnen.
