# Abschlussbericht – P14: Runs und Ausgabemengen

Datum: 2026-07-24  
Prompt-ID: P14  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

P14 zunächst vollständig spezifizieren und anschließend benötigte
vollständige Runs, tatsächliche Ausgabemenge und Überschuss zentral,
deterministisch, integer- und überlaufsicher in den P13-Produktionsgraphen
integrieren. P15 durfte nicht begonnen werden.

## Ausgangszustand

P13 lieferte einen validierten und persistierten Graphsnapshot der ersten
Rezeptstufe in Graphformat 1 und Schema v6. Rezeptoutput und rohe
Materialmengen waren vorhanden; Runs, Gesamtausgabe, Überschuss und
Formelprovenienz fehlten. Format-1-Bestand durfte nicht unkontrolliert
überschrieben werden.

Der Arbeitsbaum enthielt bereits umfangreiche, uncommittete Änderungen aus
P09B bis P13. Sie wurden erhalten. Es wurde weder committed noch gepusht,
gemerged, rebased oder zurückgesetzt.

## Durchgeführte Änderungen

- P14 vollständig mit Zweck, Quellen, Scope, offenen Punkten, Formeln,
  Invarianten, Fehlern, Tests und Definition of Done spezifiziert.
- `ProductionRunCalculation` mit Formelversion 1 implementiert.
- Ganzzahlige Ceiling-Division über Quotient und Rest verwendet.
- Outputmultiplikation auf `Int64`-Überlauf geprüft.
- Abgeleitete Codable-Werte werden beim Laden neu berechnet; manipulierte
  Payloads werden abgelehnt.
- Graphformat 2 ergänzt und Runberechnung für jeden Rezeptknoten verlangt.
- Rezeptoutput, Runoutput und Projektzielmenge werden gegeneinander
  validiert; Materialknoten dürfen keine Runberechnung besitzen.
- Format-1-Graphen bleiben lesbar und gelten als veraltet.
- Der Graphservice berechnet Runs vor dem Speichern und erhält vorhandene
  Graphen bei Rechen-, Abbruch- oder Persistenzfehlern.
- Schema v7 als echte additive Modellstufe mit optionaler
  `calculationFormulaVersion` umgesetzt.
- Repository gleicht Formelmetadaten, Payloadformat und Domainwert ab.
- Backupversion 7.0.0 sowie Kompatibilität 1.0.0 bis 7.0.0 ergänzt.
- Separate Graphansicht zeigt Ziel, Output je Run, Runs, tatsächliche
  Ausgabe, Überschuss und Formelversion.
- Xcode-Projekt reproduzierbar regeneriert und Parität geprüft.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionRunCalculation.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV7.swift`
- `Tests/NewEdenNexusDomainTests/ProductionRunCalculationTests.swift`
- `Documentation/RUNS_AND_OUTPUTS.md`
- `Documentation/Architecture/ADRs/ADR-0019_Integer-Runs-Graphformat-2-und-Schema-v7.md`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusDomain/ProductionGraph.swift`
- `Sources/NewEdenNexusApplication/ProductionGraph.swift`
- `Sources/NewEdenNexusPersistence/NexusMigrationPlan.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexusPersistence/SQLiteLocalBackupService.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionGraphRepository.swift`
- `Sources/NewEdenNexus/ProductionGraphView.swift`
- `Tests/NewEdenNexusDomainTests/ProductionGraphTests.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionGraphServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ProductionGraphPersistenceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/NexusPersistenceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/SQLiteLocalBackupServiceTests.swift`
- `Tests/NewEdenNexusTests/ProductionGraphViewModelTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ProductionGraphArchitectureTests.swift`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- P14-Prompt, Architektur-, Datenmodell-, Graph-, Status-, Roadmap-,
  Feature-, Tagebuch-, Test-, Aufgaben-, Problem- und ADR-Register.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

1. Runs sind ein UI-freier unveränderlicher Domainwert.
2. Die Ceiling-Berechnung verwendet keine Fließkommazahlen und nicht die
   potenziell überlaufende Formel `(Z + O - 1) / O`.
3. `maxProductionLimit` bleibt SDE-Provenienz. Ohne konkreten
   BPO-/BPC-Besitz ist es keine Projekt-, Job- oder Batchgrenze.
4. Alte Graphen werden nicht automatisch fachlich neu berechnet.
5. Graphformat und Formelversion sind getrennte, gegeneinander geprüfte
   Provenienzen.

Siehe
[`ADR-0019`](../../Architecture/ADRs/ADR-0019_Integer-Runs-Graphformat-2-und-Schema-v7.md).

## Datenmodelländerungen

Schema v7 führt `ProductionGraphRecord` mit den v6-Feldern fort und ergänzt
optional `calculationFormulaVersion`.

- neue Format-2-Graphen: Wert `1`,
- migrierte Format-1-Graphen: `nil`,
- v6→v7: leichtgewichtig und datenerhaltend,
- Backupmanifest: 7.0.0,
- akzeptierte Backupvorgänger: 1.0.0 bis 7.0.0.

Der direkte v6→v7-Test erhält Projekt, aktiven SDE-Datenstand,
Format-1-Payload und zweite Storeöffnung. Die vorhandene v3-Migration prüft
zusätzlich die vollständige Kette bis v7.

## Build-Ergebnis

Erfolgreich:

```text
swift test --scratch-path /private/tmp/NewEdenNexus-P14-Debug.34groP/build -c debug
swift test --scratch-path /private/tmp/NewEdenNexus-P14-Release.dn2wzF/build -c release
Scripts/generate_xcode_project.sh
Scripts/verify_xcode_project.py
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P14-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P14-Xcode-Release
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
```

Signing- und Teamwerte wurden nicht geändert. Xcode wählte aus zwei
passenden My-Mac-Zielen arm64. Die Projektprüfung meldete 15 Targets, sieben
Testtargets und zwei gemeinsame Schemes.

## Testergebnis

- SwiftPM Debug: 253 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 253 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 253 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Release: 253 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- `git diff --check`: bestanden.

Geprüft wurden insbesondere:

- Projektbuchreferenz 25/10 → 3 Runs, 30 Ausgabe, 5 Überschuss,
- exakte Teilung, Output größer Ziel, Output 1,
- `Int64.max` und typisierter Multiplikationsüberlauf,
- ungültige Eingaben und unbekannte Formelversion,
- Codable-Roundtrip und Payloadmanipulation,
- Graphformat 1 und 2, Rezept-/Ziel-/Materialinvarianten,
- Fertigungs- und Reaktionsoutput,
- deterministische Wiederholung und Stale-Erkennung,
- Bestandserhalt bei Rechen-, Abbruch- und Repositoryfehlern,
- Payload- und Formelmetadatenwiderspruch,
- v3→v7, v6→v7, zweite Öffnung und leeres aktuelles Schema,
- Backupvorgänger 1.0.0 bis 7.0.0 und Ablehnung 8.0.0,
- sichtbare UI-Werte, Tastatur-/Accessibility-Metadaten und
  SwiftData-freie View-/ViewModel-Grenze.

## Manuelle Prüfungen

Das gebaute Xcode-Debug-App-Binary lief mehr als fünf Sekunden mit dem
isolierten Store
`/private/tmp/NewEdenNexus-P14-Smoke.2uJ0ah/P14.store`.

- `PRAGMA integrity_check`: `ok`
- Produktionsgraphtabelle vorhanden
- optionale Spalte `ZCALCULATIONFORMULAVERSION` vorhanden
- Prozess anschließend kontrolliert beendet

Produktive Benutzerdaten wurden nicht geöffnet oder verändert. Ein neuer
visueller VoiceOver-Lauf wurde nicht durchgeführt und wird nicht behauptet;
UI-Kompilation, Texte, Accessibility-Metadaten und Schichtengrenzen sind
automatisiert geprüft.

## Gefundene und behobene Probleme

1. Der erste vollständige Debuglauf endete in der bestehenden
   v3-Migrationsprüfung mit Signal 6. Der Fehler war mit leerem Cache
   reproduzierbar. Ursache war die zunächst nur nominelle v7-Stufe mit exakt
   wiederverwendeten v6-PersistentModel-Typen. Eine echte additive
   v7-Modellversion beseitigte den Fehler; fokussierte und vollständige
   Migrationstests bestanden danach.
2. Der Review ergänzte einen fehlenden Regressionstest für den Widerspruch
   zwischen `calculationFormulaVersion` und gültiger Format-2-Payload.
   Anschließend wurden alle vier vollständigen Suites erneut ausgeführt.

## Bekannte Probleme und offene Anforderungen

- `OFF-004`/`KI-003`: teilweise; ME und rekursive T1-/T2-/
  Reaktionsketten sowie Aggregation folgen P15 bis P19.
- `OFF-009`/`KI-012`: teilweise; Run-/Outputüberlauf ist geschlossen,
  Materialmultiplikation und Aggregationssumme folgen P19.
- `OFF-006`/`KI-006`/`KI-013`: additive v7-Migration und Backup 7.0.0 sind
  geprüft; automatische Vor-Migrations-Sicherung und echter Recovery-Drill
  bleiben P36.
- `OFF-021`/`KI-021`: P14 benötigte keine weiteren SDE-Datensätze.
- `OFF-027`/`KI-027`: Run-UI blieb getrennt; mechanische
  Projekteditor-Teilung bleibt P34.

Keine dieser Restaufgaben verhindert die vollständige P14-Abnahme.

## Abweichungen vom Projektbuch

Keine unbelegte Regel wurde als EVE-Fachregel ergänzt. Die im Projektbuch
dokumentierte Run-Aufrundung wurde umgesetzt. P14 interpretiert
`maxProductionLimit` bewusst nicht als Projekt-/Jobgrenze; konkrete
BPO-/BPC-Runs sind ohne persönliche Blueprintdaten nicht verfügbar.

## Abnahmekriterien

- zentrale Runformel und Invarianten: erfüllt,
- Referenz- und Grenzwerte: erfüllt,
- Graphformat 2 mit Runwerten: erfüllt,
- Format-1-Bestand lesbar und stale: erfüllt,
- Schema v7 und Backup 7.0.0: erfüllt,
- sichtbare Runs, Ausgabe, Überschuss und Formelversion: erfüllt,
- keine vorgezogene P15–P19-Logik: erfüllt,
- offene Punkte erneut geprüft: erfüllt,
- SwiftPM/Xcode Debug/Release: erfüllt,
- isolierter App-Smoke: erfüllt,
- Pflichtdokumentation und Bericht: erfüllt,
- Review und Kontrollprüfung: erfüllt.

## Reviewentscheidung

**✅ bestanden.** Der Review prüfte tatsächliche Quelltexte, Scope,
Graph-/Formelinvarianten, Datenwirkung, Fehlerpfade, vollständige
Build-/Testergebnisse, manuelle Storeprüfung, Dokumentation und offene
Register. Die zwei Reviewbefunde wurden vor der Entscheidung korrigiert und
vollständig regressionsgeprüft.

## Nächster empfohlener Prompt

P15 – Material Efficiency zunächst vollständig spezifizieren und erst
anschließend ausführen. P15 wurde in P14 nicht begonnen.
