# P52/OFF-047 – Produktionsworkspace-Navigation

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden, Eigentümer-Sichttest offen

## Ziel und Ausgangszustand

P41-1 war vor dem Marktpreis-Livetest gestoppt, weil der Produktionsworkspace
mit 760 pt Mindestbreite Planung, Materialsumme und Graphstufen in einer
schwer überblickbaren langen Seite darstellte.

## Durchgeführte Änderungen

- Graph-Sheet auf 1.080 pt Mindest- und 1.360 pt Idealbreite erweitert,
- horizontale segmentierte Navigation für Übersicht, Bauen/Kaufen,
  Lager/Einkauf, Kosten/ROI, Materialsumme und Produktionsstufen ergänzt,
- jeweils nur den gewählten Bereich dargestellt,
- Übersicht um kompakte Planmetriken sowie Produktions-/Inventionsjobs
  ergänzt,
- Architektur- und Renderprüfungen auf die neue UI-Grenze aktualisiert.

Keine Fachlogik, Datenbank, Migration, Preis-, Projekt- oder ESI-Daten wurden
geändert. Der optionale Umbau der Projektliste zu einem permanenten Split-View
wurde wegen der größeren Navigations- und Zustandswirkung nicht vorgezogen.

## Build und Tests

- fokussiert: 1/1 Workspace-Architektur, 5/5 Workspace-ViewModel/Render und
  3/3 P35-Accessibility-Architektur bestanden,
- erster Volltest: 661/662; ausschließlich der veraltete P35-Quelltextzähler
  erwartete zwei frühere `ViewThatFits`-Blöcke,
- Test auf die neue adaptive Grenze korrigiert,
- abschließende Vollsuite: 662/662 bestanden,
- Xcode: Scheme `NewEdenNexus`, `Debug`, Ziel `platform=macOS`, arm64,
  Apple-Development-signiert: `BUILD SUCCEEDED`,
- `git diff --check`: bestanden.

## Review

Entscheidung: ⚠️ mit Einschränkungen bestanden.

Der Diff bleibt in der SwiftUI-Darstellungsschicht; ViewModels, Services,
Persistenz und Bestätigungsgates sind unverändert. Die Einschränkung ist der
noch fehlende sichtbare Eigentümernachweis im neuen App-Bundle.

## Offene Punkte und nächster Schritt

- OFF-047: Breite und alle sechs Bereiche im neuen Build sichtbar prüfen.
- Danach P41-1 über **Kosten & ROI** neu beginnen, Marktpreisvorschau abrufen
  und zunächst ohne Preisübernahme schließen.
- OFF-045/OFF-046 sowie weitere P41-/P42-Gates bleiben unverändert offen.
