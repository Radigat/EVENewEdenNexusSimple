# P09B – Eigenständiges Xcode-Projekt und gemeinsame Schemes

Datum: 2026-07-23  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Prompt-ID und Ziel

P09B ergänzt ein dauerhaft versionierbares Xcode-Projekt für die native
macOS-App, ohne den bestehenden SwiftPM-Weg oder die Modulgrenzen zu
beschädigen. Zusätzlich werden `OFF-014` und der aus P07C übernommene
GUI-/Tastatur-/VoiceOver-Nachweis `OFF-025` geschlossen.

## Ausgangszustand

- P09A hatte den geprüften Projektstand als erste Git-Baseline auf `main`
  gesichert.
- `Package.swift` beschrieb 15 Targets und war der einzige verifizierte
  Buildweg.
- Ein eigenständiges `.xcodeproj`, gemeinsame Schemes und reproduzierbare
  `xcodebuild`-Nachweise fehlten.
- P07C war technisch und automatisiert geprüft, blieb aber wegen des
  fehlenden echten App-Bundle-/Accessibility-Smoke-Tests teilweise.
- Es bestanden keine vom Benutzer stammenden uncommitteten Änderungen, die
  überschrieben oder verworfen werden durften.

## Durchgeführte Änderungen

- `project.yml` als reproduzierbare XcodeGen-Beschreibung aller 15
  SwiftPM-Targets angelegt,
- `NewEdenNexus.xcodeproj` mit Debug/Release und gemeinsamen Schemes
  `NewEdenNexus` sowie `NewEdenNexusSDEAcceptance` erzeugt,
- alle sieben Testtargets in das gemeinsame App-Scheme aufgenommen,
- vorhandene Quellen unter `Sources/` und `Tests/` referenziert; keine
  Fachimplementierung dupliziert,
- bestehende Test-Fixtures über eine nur außerhalb SwiftPM aktive
  `Bundle.module`-Brücke für Xcode nutzbar gemacht,
- Run- und Testprofile des App-Schemes auf projektlokale isolierte
  `CFFIXED_USER_HOME`-Pfade unter `.build` begrenzt,
- statischen Package-/Xcode-Paritätscheck sowie reproduzierbares
  Generierungsskript ergänzt,
- lokale Entwicklungs-Bundle-ID klar als nicht freigegebenen Platzhalter
  dokumentiert,
- Build-/Startanleitung, Architektur und ADR-Register aktualisiert,
- echten App-Start sowie P07C-Navigation, Normal-, Offline- und
  Schema-Warnzustand, Einstellungen, Rechtsansicht, Tastatur und VoiceOver
  mit isolierten Profilen manuell geprüft.

## Neu erstellte Dateien

- `project.yml`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- `NewEdenNexus.xcodeproj/project.xcworkspace/contents.xcworkspacedata`
- `NewEdenNexus.xcodeproj/xcshareddata/xcschemes/NewEdenNexus.xcscheme`
- `NewEdenNexus.xcodeproj/xcshareddata/xcschemes/NewEdenNexusSDEAcceptance.xcscheme`
- `Scripts/generate_xcode_project.sh`
- `Scripts/verify_xcode_project.py`
- `XcodeSupport/NewEdenNexusTestSupportBundle.swift`
- `Documentation/Architecture/ADRs/ADR-0013_Xcode-Projekt-und-SwiftPM-Paritaet.md`
- sechs datenschutzneutrale Nachweisbilder unter
  `Documentation/Progress/Screenshots/P09B/`
- dieser Abschlussbericht

## Geänderte Dateien

- `README.md`
- `Documentation/ARCHITECTURE.md`
- `Documentation/ARCHITECTURE_CHANGES.md`
- `Documentation/Architecture/ADRs/README.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/FEATURE_MATRIX.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/TEST_HISTORY.md`
- `Documentation/Prompts/README.md`
- P07C- und P09B-Promptdatei

## Gelöschte oder verschobene Dateien

Es wurden keine Benutzerdateien gelöscht. Eine ältere, untracked
Generierungskopie `NewEdenNexus 2.xcodeproj` wurde nach Prüfung als durch das
finale Projekt ersetzt erkannt und zur Wiederherstellbarkeit nach
`/private/tmp/NewEdenNexus-2-P09B-superseded-20260723.xcodeproj` verschoben.
Von Xcode lokal erzeugte persönliche `xcuserdata`-Verzeichnisse wurden
ebenfalls nach `/private/tmp` verschoben und gehören nicht zum Projektumfang.

## Architekturentscheidungen

[ADR-0013](../../Architecture/ADRs/ADR-0013_Xcode-Projekt-und-SwiftPM-Paritaet.md)
legt fest:

- SwiftPM und Xcode referenzieren dieselben Quellen,
- `project.yml` erzeugt die versionierte Xcode-Baseline,
- zwei gemeinsame Schemes werden versioniert,
- das App-Scheme enthält alle sieben Testtargets,
- ein statischer Check verhindert Target-/Quelldrift und persönliche
  Metadaten,
- Signing, Team, Distribution und Release-Bundle-ID bleiben unentschieden.

## Datenmodelländerungen

Keine. Es wurde keine SwiftData-Schemaversion, Migration oder produktive
Persistenzlogik geändert. Manuelle Zustandsprüfungen verwendeten
ausschließlich isolierte Stores unter `.build`; produktive Benutzerdaten
wurden nicht geöffnet oder verändert.

## Build-Ergebnis

Verwendete Zielplattform: My Mac, macOS, arm64.  
Xcode: 26.6, Build 17F113.  
CLI-Signing: `CODE_SIGNING_ALLOWED=NO`.

Erfolgreich ausgeführt:

```bash
xcodebuild -list -project NewEdenNexus.xcodeproj

xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build

xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build

xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexusSDEAcceptance -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build

swift build
swift build -c release
```

Ergebnis:

- Projektliste erkannte 15 Targets, Debug/Release und die gemeinsamen
  App-/Runner-Schemes,
- App Debug: erfolgreich,
- App Release: erfolgreich,
- SDE-Abnahmerunner: erfolgreich gebaut,
- SwiftPM Debug: erfolgreich,
- SwiftPM Release: erfolgreich,
- der SDE-Abnahmerunner wurde nicht ausgeführt und löste keinen Download aus.

## Testergebnis

Abschließender Xcode-Test:

```bash
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
```

- **167 bestanden**
- **0 fehlgeschlagen**
- **0 übersprungen**
- Testoperation: 18,086 Sekunden

Abschließende SwiftPM-Regression:

```bash
swift test
```

- **167 bestanden**
- **0 fehlgeschlagen**
- **0 übersprungen**
- XCTest-Dauer: 52,206 Sekunden
- der vorhandene 50.000-Item-Performancefall benötigte 44,679 Sekunden und
  lud weiterhin höchstens `limit + 1` Zeilen.

Statischer Projektcheck:

```bash
Scripts/verify_xcode_project.py
```

Ergebnis: **15 Targets, sieben Testtargets, zwei gemeinsame Schemes**. Keine
absoluten Benutzerpfade, `DEVELOPMENT_TEAM`-Werte oder persönlichen
Xcode-Metadaten in den lieferbaren Projektdateien.

## Warnungen und korrigierte Zwischenbefunde

1. Der erste Xcode-Build blockierte die von XcodeGen erzeugte
   Headerkopie durch die Benutzerskriptsandbox. Das Projekt setzt deshalb
   `ENABLE_USER_SCRIPT_SANDBOXING=NO`; Signing- oder Teamwerte wurden nicht
   verändert.
2. Der erste Runner-Build benötigte wegen `@main` die explizite
   Compileroption `-parse-as-library`. Danach war der Runner-Build grün.
3. Ein früher Xcode-Testlauf bestand zwar alle 167 Tests, war wegen einer
   gleichzeitig laufenden manuellen Desktopprüfung unbrauchbar langsam. Der
   isolierte Abschlusslauf wurde deshalb unabhängig wiederholt.
4. Nicht freigegebene Kontrollläufe meldeten nicht projektspezifische
   CoreSimulator-/Cachewarnungen. Die freigegebenen macOS-Build-/Testläufe
   endeten erfolgreich.
5. Der erste SwiftPM-Versuch konnte den globalen Modulcache im eingeschränkten
   Prüfumfeld nicht schreiben; derselbe unveränderte Befehl wurde mit
   freigegebenem Cachezugriff erfolgreich wiederholt.

Keine Warnung wurde pauschal unterdrückt.

## Manuelle Prüfungen

Die gebaute Debug-App lief mit einem isolierten Testprofil. Geprüft wurden:

- App-Start und leerer Dashboardzustand,
- Navigation zu `EVE-Daten`,
- Status `Update verfügbar`,
- manuelle Aktualitätsprüfung über `⌘⇧R`; der isolierte Store protokollierte
  den neuen erfolgreichen Prüfzeitpunkt,
- Offlinezustand mit erhaltener lokaler Datenbasis und sicherem Diagnosecode,
- Schemaänderungs-Warnzustand mit blockierter Installation,
- Einstellungen über `⌘,`,
- Automationsoptionen, 24-Stunden-Mindestintervall, Keychain-Kontaktgrenze
  und Retention,
- unabhängige Drittanbieter-/Eigentumsansicht und offizielle Links,
- VoiceOver real aktiviert; aktiver Screenreader-Dienst bestätigt,
  Fokusnavigation mit `VO-Rechtspfeil` bei vor und nach der Navigation
  aktiver New-Eden-Nexus-App ausgeführt und VoiceOver danach wieder
  deaktiviert.

Nachweisbilder:

- [Dashboard](../Screenshots/P09B/2026-07-23_P09B_Dashboard.png)
- [Update verfügbar](../Screenshots/P09B/2026-07-23_P09B_EVE-Daten.png)
- [Offlinezustand](../Screenshots/P09B/2026-07-23_P09B_Offline-Zustand.png)
- [Schemawarnung](../Screenshots/P09B/2026-07-23_P09B_Schemawarnung.png)
- [EVE-Daten-Einstellungen](../Screenshots/P09B/2026-07-23_P09B_Einstellungen-EVE-Daten.png)
- [Rechtliche Hinweise](../Screenshots/P09B/2026-07-23_P09B_Rechtliche-Hinweise.png)

Die Bilder zeigen ausschließlich App-Fenster. Ein während der
Desktopsteuerung temporär erfasster Ausschnitt einer fremden App wurde sofort
gelöscht und nicht in das Repository übernommen.

## Bekannte Probleme

- Die 21 offiziellen nicht aufgelösten Blueprint-Material-/Produktreferenzen
  bleiben unverändert und müssen in P10 itemgenau abgelehnt werden.
- Der echte externe Prozessabbruch-/Neustart-Drill bleibt P36.
- Die aktuellen CCP-/Marken-/Releasebedingungen müssen vor P37 erneut
  persönlich und technisch geprüft werden.
- Die große P07B-Dateiaufteilung bleibt als wartungsbezogene P34-Aufgabe
  offen.

Kein durch P09B verursachter kritischer Fehler ist offen.

## Offene Anforderungen

Alle für P09B notwendigen offenen Punkte wurden erneut geprüft:

- `OFF-014`: erledigt,
- `OFF-025`: erledigt,
- `OFF-020`: nur noch der unabhängige zeitabhängige P37-Release-Recheck,
- alle übrigen aktiven Punkte bleiben ihren dokumentierten späteren Prompts
  zugeordnet und wurden nicht vorgezogen.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. P09B ergänzt ausschließlich die Build- und
Abnahmeinfrastruktur. Die lokale Bundle-ID ist kein Releasewert. Der
verschobene SSO-/ESI-Umfang wurde nicht erweitert.

## Erfüllte Abnahmekriterien

- eigenständiges, versionierbares Xcode-Projekt vorhanden,
- alle Package-Targets und Quellen referenziert,
- zwei gemeinsame Schemes vorhanden,
- App-Scheme führt alle sieben Testtargets aus,
- Debug, Release und Runner-Build erfolgreich,
- SwiftPM Debug/Release weiterhin grün,
- Xcode und SwiftPM jeweils 167 Tests grün,
- App auf My Mac manuell gestartet,
- P07C-Normal-, Offline-, Warn-, Settings-, Rechts-, Tastatur- und
  VoiceOver-Nachweise erbracht,
- keine persönlichen/Signing-Daten im Projektumfang,
- Pflichtdokumentation, Feature-Matrix, Tagebuch, Testhistorie und
  Abschlussbericht aktualisiert,
- gesonderter Review bestanden.

## Nicht erfüllte Abnahmekriterien

Keine für P09B. Es wurde bewusst kein Commit erstellt, weil dieser Auftrag
keine Git-Commit-Autorisierung enthielt. Das Projekt ist commitfähig.

## Reviewentscheidung

**✅ bestanden**

Der Review hat tatsächliche Projektdateien, Package-/Xcode-Parität, Schemes,
Build- und Testausgaben, manuelle Zustände, Datenschutz der Screenshots,
Signing-/Metadatengrenzen und Dokumentation unabhängig kontrolliert. P09B
darf auf `✅` gesetzt werden. Die frühere P07C-Einschränkung ist durch den
nachgeholten tatsächlichen GUI-/Accessibility-Nachweis ebenfalls geschlossen.

## Nächster empfohlener Prompt

**P10 – Rezept- und Aktivitätsresolver**, einschließlich `OFF-003`,
`OFF-016`, `KI-004` und `KI-016`. P10 wurde nicht begonnen.
