# P44 – Nutzenreview PI, Logistik und Kapazität

Datum: 2026-07-27  
Status Review: ✅ abgeschlossen  
Status Umsetzung: ⏸️ zurückgestellt

## Ziel und Ausgangszustand

Geprüft wurde, ob PI-Kolonien, Transporte, Kalender und Kapazitätsplanung
nach P43 genügend lokalen Zusatznutzen bieten. P44 war ein verschobener
Kurzentwurf; eine Implementierung war nicht freigegeben.

## Geprüfter Ist-Stand

- P18–P26/P32: Produktionszeiten, Lager, Reservierungen, Einkauf und
  Build-or-Buy,
- P40: persönliche Assets und Industry Jobs einschließlich Location-IDs,
  Start-/Endzeit und Dauer,
- keine PI-, Routengraph-, Transportauftrag- oder geplante
  Slotkapazitätsimplementierung,
- Projektbuchkapitel 14, 21 und 23 sowie aktuelle offizielle CCP-PI-,
  ESI-, Routen- und Manufacturing-Grundlagen.

Die aktuelle OpenAPI-Spezifikation bestätigt zwei private PI-Endpunkte mit
einem zusätzlichen Scope und einen öffentlichen Routenendpunkt. Der
offizielle PI-Leitfaden weist zusätzliche zeit- und Dogma-abhängige
Projektionsregeln aus.

## Entscheidung

**Stop/No-Go für das gebündelte vollständige P44-Paket.** PI-Monitoring,
Logistik und Kapazitätssteuerung sind drei eigenständige Großbereiche. Ohne
belegten Kolonie-, Mehrstandort- oder Mehrlinienbetrieb rechtfertigt ihr
Nutzen die zusätzlichen Scope-, Daten-, Schema-, Recovery- und
Oberflächengrenzen nicht.

P44 darf später nur für genau einen nachgewiesenen Teilbedarf reaktiviert
werden: read-only PI-Monitor, manuelle Transportcheckliste oder read-only
Industry-Job-Zeitleiste. Automatische Planung bleibt ausgeschlossen.

## Änderungen und Datenwirkung

Geändert wurden ausschließlich P44-Spezifikation und
Steuerdokumentation. Neu erstellt wurde dieser Bericht. Kein Quellcode,
Datenmodell, Schema, SSO-Scope, Benutzerbestand oder Xcode-Projekt wurde
verändert; keine Datei wurde gelöscht oder verschoben.

## Build, Tests und manuelle Prüfung

Build und Tests wurden nicht erneut ausgeführt, weil keine Laufzeitdatei
geändert wurde. Der zuletzt nachgewiesene Stand bleibt SwiftPM/Xcode Debug
erfolgreich mit 608/608 Tests. Dokumentkonsistenz, vorhandene Abdeckung,
OpenAPI-Grenzen und offene Punkte wurden gezielt geprüft.

Die schreibgeschützte OpenAPI-Abfrage
`curl -fsSL https://esi.evetech.net/meta/openapi.json | jq …` bestätigte
Kolonieliste/-layout mit `esi-planets.manage_planets.v1` sowie den
öffentlichen Routenendpunkt. Es wurden keine Live-Charakterdaten abgerufen.

## Offene Punkte und Review

`OFF-021` bleibt das Bedarfsgate für PI-Schematics/Dogma und
Universe-/Stargate-Daten. Manuelle Lager-UUIDs und ESI-Location-IDs besitzen
noch keine bestätigte Zuordnung. Kein neuer kritischer Fehler wurde erkannt.

Reviewentscheidung: **✅ Nutzenreview bestanden; Gesamtumsetzung bewusst
zurückgestellt.**

## Nächster empfohlener Schritt

Den vorhandenen Produktions-, Lager- und Industry-Job-Fluss lokal nutzen.
Ein P45-Nutzenreview beginnt nur auf ausdrücklichen Auftrag.
