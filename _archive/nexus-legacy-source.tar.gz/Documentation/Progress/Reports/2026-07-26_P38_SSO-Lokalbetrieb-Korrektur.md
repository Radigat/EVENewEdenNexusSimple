# P38 – SSO-Lokalbetrieb-Korrektur

Datum: 2026-07-26  
Status: **⚠️ teilweise – Korrekturen bestanden, OFF-033 blockiert Realabnahme**

## Ziel und Ausgangszustand

Die gemeldeten Fehler `NEN-AUTH-001` beim Verbinden,
`NEN-PER-004` beim Trennen sowie zwei Hauptfenster beim Xcode-Start
reproduzieren und mit kleinstmöglichen Änderungen beheben.

Unified-/Security-Logs ordneten beide Accountfehler einem verweigerten
Keychain-Zugriff zu. Der bestehende Token war von einem ad-hoc-signierten
Build angelegt worden; dessen buildabhängige Code-Identität ist keine
stabile Keychain-Grenze.

## Änderungen

- eigener Application-Fehler `localCredentialAccessFailed`,
- Diagnose `NEN-AUTH-003` für Lesen/Speichern und `NEN-AUTH-002` für
  fehlgeschlagenes Löschen statt irreführender Auth-/Persistenzcodes,
- lokale Apple-Development-Konfiguration über
  `Scripts/configure_local_signing.sh` und git-ignorierte
  `XcodeSupport/LocalSigning.xcconfig`,
- Standard-/CI-Xcode-Konfiguration bleibt ohne persönliche Werte unsigned,
- Hauptfenster eindeutig markiert, Restaurierungsduplikate geschlossen und
  `⌘N` idempotent gemacht,
- Vault-Fehler- und Einzel-Fenster-Regressionstests ergänzt.

Keine Schema-, Konto-, Projekt-, Lager-, Preis- oder Tokendaten wurden
verändert. Kein Keychain-Eintrag wurde gelöscht. Kein Commit oder Push.

## Dateien

Neu:

- `Scripts/configure_local_signing.sh`
- `XcodeSupport/AppSigning.xcconfig`
- dieser Bericht

Geändert:

- `.gitignore`, `project.yml`, generiertes `NewEdenNexus.xcodeproj`,
- App-Fensterlebenszyklus und Account-Fehlerdarstellung,
- Application-Authentifizierungs- und Fehlerverträge,
- Application-/UI-Tests,
- P38-Architektur-, Status-, Aufgaben-, Befund-, Test- und
  Fortschrittsdokumentation.

`XcodeSupport/LocalSigning.xcconfig` ist lokal erzeugt, Modus 600 und
git-ignoriert; persönliche Team-/Zertifikatswerte erscheinen nicht in
Projektquellen oder diesem Bericht.

## Build und Tests

- Xcode-Projektgenerierung/-konsistenz: **16 Targets, 8 Testtargets,
  2 gemeinsame Schemes – bestanden**.
- vollständiger SwiftPM-Debuglauf in unveränderlichem temporären Abbild:
  **542/542 bestanden**, 0 Fehler.
- nativer Xcode-UI-Test
  `testLaunchKeepsExactlyOneMainWindow`: **1/1 bestanden**,
  `TEST SUCCEEDED`.
- ad-hoc-Xcode-Debugbuild wurde innerhalb des UI-Laufs erfolgreich erstellt.
- Apple-Development-Build erreichte CodeSign, endete aber wegen des
  gesperrten Anmeldeschlüsselbunds mit `errSecInternalComponent`.

Ein aktiver SwiftPM-Volltest war zuvor durch gleichzeitige
Dateikoordination im stark veränderten Arbeitsbaum unbrauchbar; der
identische unveränderliche Snapshotlauf bestand vollständig und ist der
gewertete Nachweis.

## Review und offene Punkte

Reviewentscheidung: **⚠️ mit Einschränkung bestanden**.

Bestanden:

- Fehlerursache aus Systemlogs statt Vermutung abgeleitet,
- keine unsichere Keychain-Freigabe und keine automatische Tokenlöschung,
- persönliche Signierwerte bleiben außerhalb von Git,
- Account-Fehlerpfade und Einzel-Fenster-Verhalten regressionsgeprüft,
- vollständige SwiftPM-Suite grün.

Offen in `OFF-033`:

1. Login-Keychain durch den Projekteigentümer in macOS entsperren,
2. Apple-Development-Build erfolgreich signieren und stabile Designated
   Requirement prüfen,
3. alten ad-hoc-Keychain-Eintrag nach bewusster Bestätigung kontrolliert
   bereinigen,
4. Verbinden, App-Neustart, Refresh und Trennen real ausführen.

P38 bleibt deshalb `⚠️`; P39 wurde nicht begonnen.

## Nächster Schritt

P38/OFF-033 nach Entsperren des Anmeldeschlüsselbunds abschließen. Erst nach
erfolgreichem realem SSO-Lauf mit Datenbestandsschutz P39 beginnen.
