# PLAN-003 – Lokaler Betrieb und optionale Distribution

Datum: 2026-07-26  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Die Projektsteuerung auf lokale Eigennutzung ausrichten und Apple Store
beziehungsweise öffentliche Distribution als letztes optionales
Zukunftspaket erhalten.

## Ausgangszustand

REL-001 hatte die technische öffentliche Releasebereitschaft geprüft.
OFF-020 und OFF-032 wurden dabei als öffentliche Freigabegates behandelt.
Der Projekteigentümer plant jedoch auf absehbare Zeit ausschließlich den
lokalen Betrieb auf dem eigenen Mac.

## Änderungen

- lokaler Betrieb als verbindliches aktuelles Ziel in `AGENTS.md` und
  Projektbeschreibung festgelegt,
- lokale `Release`-Buildkonfiguration ausdrücklich von öffentlicher
  Veröffentlichung getrennt,
- App Store, öffentliche Direktverteilung, Signing, Hardened Runtime und
  Notarisierung aus den aktuellen MVP-/DoD-Gates entfernt,
- neue optionale Stufe F und P48 nach P47 ergänzt,
- OFF-020/OFF-032 auf P48 verschoben und als Nichtblocker des lokalen
  Betriebs gekennzeichnet,
- Entwickler-Menü, Promptregister, Roadmap, Status, Feature-Matrix,
  offene Aufgaben und Complianceeinordnung konsistent angepasst,
- REL-001 als gültigen historischen technischen Befund erhalten.

## Dateien

Neu:

- `Documentation/Prompts/MVP/PLAN-003_Lokaler-Betrieb-und-optionale-Distribution.md`
- `Documentation/Prompts/Future/P48_Optionale-Apple-Distribution.md`
- dieser Bericht

Geändert:

- `AGENTS.md`
- Projekt-, Roadmap-, Status-, Prompt-, Feature-, Compliance- und
  Aufgabensteuerung.

Code, Datenmodell und Benutzerdaten: nicht geändert.  
Signing, Team und Xcode-Projekt: nicht geändert.  
Gelöschte oder verschobene Dateien: keine.

## Build und Tests

Kein App-Code und kein Xcode-Projekt wurden geändert. Deshalb wurde kein
erneuter App-Build behauptet. Der letzte verifizierte Stand bleibt:

- SwiftPM Release 527/527 Tests,
- nativer Xcode-UI-Testworker 2/2,
- Xcode Universal Release erfolgreich.

Dokumentationsprüfung und Xcode-Projektparität wurden ausgeführt.

## Review

- lokale Betriebsgrenze eindeutig,
- öffentliche Distribution nicht mehr MVP-Blocker,
- P48 nach P47 und nur ausdrücklich aktivierbar,
- P38 unverändert verschoben,
- historische Nachweise nicht überschrieben oder umgedeutet,
- keine Benutzeränderung verworfen.

Entscheidung: **✅ bestanden**.

## Offene Punkte

OFF-020 und OFF-032 bleiben bewusst als optionale P48-Voraussetzungen
erhalten. Sie sind für den lokalen Betrieb nicht zu bearbeiten.

## Nächster Schritt

Kein Prompt ist automatisch aktiv. Die App kann lokal weiter genutzt und
auf ausdrücklichen Auftrag fachlich weiterentwickelt werden. P48 bleibt das
letzte optionale Distributionspaket.
