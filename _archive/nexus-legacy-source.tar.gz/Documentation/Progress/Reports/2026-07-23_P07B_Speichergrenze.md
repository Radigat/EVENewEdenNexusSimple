# P07B – Speichergrenze schließen

Datum: 2026-07-23  
Prompt-ID: P07B  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Die nach der ersten Realabnahme verbliebene Gesamtmaterialisierung des
offiziellen SDE-Katalogs beseitigen. Mapping, isoliertes Staging und
Promotion müssen blockweise arbeiten, ohne Rollback, Datenintegrität oder
fachliche Ergebnisse zu verändern.

## Ausgangszustand

Download, ZIP-Schutz, isolierter Store, Backup, Aktivierung, Rollback und
Phasenjournal waren vorhanden. Zwei vollständige Importe des offiziellen
Builds 3444265 waren funktional erfolgreich, erreichten aber
2.448.506.880–2.454.126.592 Bytes maximalen RSS. `OFF-019`/`KI-019`
blockierten deshalb P07B.

## Durchgeführte Änderungen

- Streaming- und Batchverträge in Application ergänzt.
- `JSONLinesSDECatalogMapper` auf zeilenweises Mapping mit begrenzten Batches
  umgestellt.
- Kategorien, Gruppen, Typen und Blueprintaktivitäten weiterhin vollständig
  validiert; Hash- und Mengenprüfung erhalten.
- isoliertes SwiftData-Staging sowie Promotion blockweise implementiert.
- Katalogversion und Aktivmarker erst nach vollständigem Mengenabgleich
  gespeichert.
- Kandidaten-Inhaltshash für sichere Orphan-Bereinigung ergänzt.
- Fehler, Abbruch und Wiederanlauf schützen die alte aktive Version.
- P07B lehnt nicht streamingfähige Legacy-Verdrahtung vor dem Download ab.

## Neu erstellte Dateien

- `Sources/NewEdenNexusPersistence/SwiftDataStaticDataStreamingRepository.swift`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusApplication/StaticDataCatalog.swift`
- `Sources/NewEdenNexusApplication/SDEInstallation.swift`
- `Sources/NewEdenNexusInfrastructure/JSONLinesSDECatalogMapper.swift`
- relevante Infrastructure-, Persistence- und Application-Tests
- verpflichtende Projekt-, Architektur-, Status- und Testdokumentation

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

ADR-0011 wurde auf den durchgängig blockweisen Pfad aktualisiert. Die
Streamingfähigkeit ist für P07B verbindlich. Die aktive Katalogversion bleibt
bis zur abschließenden Transaktion unverändert; Kandidatenzeilen werden über
den Inhaltshash identifiziert.

## Datenmodelländerungen

Keine neue SwiftData-Schemaversion. Parser- und Importschemaversion des
P07B-Pfads wurden auf 2 erhöht. Vorhandene Benutzer- und Katalogdaten bleiben
erhalten.

## Build-Ergebnis

- Debug-Build im Coverage-Testlauf: ✅
- Release-Build: ✅
- keine Änderung an Signing- oder Team-Einstellungen

## Testergebnis

- Debug: 153 Tests, 0 Fehler
- Release: 153 Tests, 0 Fehler
- fünf Architekturtests bestanden
- produktive Source-Coverage: 74,43 %
- Mapper-Coverage: 84,42 %
- Streaming-Repository-Coverage: 83,29 %
- Installationsservice-Coverage: 93,26 %

## Manueller Realtest

Der am Prüftag aktuelle offizielle CCP-Build 3444265 wurde zweimal
vollständig importiert:

| Merkmal | Lauf 1 | Lauf 2 |
|---|---:|---:|
| Dauer | 33,391 s | 33,202 s |
| maximaler RSS | 952.057.856 Bytes | 948.125.696 Bytes |
| Peak Footprint | 855.131.432 Bytes | 855.065.896 Bytes |
| Ergebnis | ✅ | ✅ |

Beide Läufe ergaben denselben Inhaltshash und dieselben Mengen:
48 Kategorien, 1.609 Gruppen, 52.821 Typen, 5.082 Blueprints,
19.137 Aktivitäten, 36.499 Materialien, 6.329 Produkte und 21 explizit
nicht aufgelöste Referenzen. Backup, Aktivierung, Wiederöffnung,
Rifter-/Blueprintabfrage und Cleanup waren erfolgreich. Gegenüber der
Snapshot-Baseline sank der maximale RSS um rund 61 %.

## Bekannte Probleme und offene Anforderungen

- Der tatsächliche Prozessabbruch mit anschließendem App-Neustart bleibt im
  vollständigen P36-Recovery-Drill.
- SDE-Einstellungen, Startautomation, sichtbarer Verlauf, Diagnoseexport und
  Rechtshinweise folgen P07C.
- Die mechanische Aufteilung großer P07B-Dateien bleibt `OFF-022`/P34.
- 21 vom offiziellen Datenstand nicht auflösbare Typreferenzen müssen in P10
  fachlich sichtbar abgelehnt werden.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. Der blockweise technische Import konkretisiert
die Local-First-, Datenintegritäts- und Performanceprinzipien.

## Abnahmekriterien

- [x] ausschließlich offizieller, validierter Downloadpfad
- [x] defensive ZIP-Verarbeitung
- [x] isolierter und streamingfähiger Import
- [x] blockweise Persistenz ohne Gesamtmaterialisierung
- [x] Aktivierung erst nach vollständiger Prüfung
- [x] Rollback, Wiederöffnung und Phasen-Recovery
- [x] vorhandene Benutzerdaten geschützt
- [x] zwei aktuelle Real-SDE-Läufe unter 1 GiB maximalem RSS
- [x] Debug und Release grün
- [x] Dokumentation, Feature-Matrix, Tagebuch und Bericht aktualisiert

## Reviewentscheidung

✅ bestanden. Der tatsächliche Diff, die Streaminggrenzen, Fehlerpfade,
Build-/Testausgaben, Realmessungen und Dokumentation wurden getrennt geprüft.
P34, P36 und P07C sind eigenständige Folgearbeiten und keine offenen
P07B-Abnahmekriterien.

## Nächster empfohlener Prompt

P07C – SDE-Einstellungen, Automatisierung und rechtliche Hinweise.
