# P41 – Live-Marktpreise

Status: **⚠️ technisch umgesetzt, Xcode-Buildnachweis offen**  
Datum: 2026-07-27

## Ziel und Ausgangszustand

Öffentliche ESI-Sell-Orders sollten als optionale, mengenbezogene
Beschaffungspreise in den Produktionsworkspace integriert werden. Vor P41
existierten manuelle/CSV-Preisprofile und Projektwirtschaftlichkeit, aber kein
öffentlicher Marktclient oder Marktpreis-Provenienzmodell.

## Änderungen

- öffentlicher, tokenloser und type-gefilterter ESI-Marktclient mit
  Pagination, Validatoren, 304, Limits, Retry und Größenobergrenzen,
- separater atomarer Dateicache mit Offline-/Limit-/Server-Fallback,
- deterministische mengenbezogene Preisbildung für die aktuelle Einkaufsliste,
- revisions- und zeitgebundene Vorschau vor jedem bestätigten Schreibvorgang,
- Schema v21 mit `MarketPriceProvenanceRecord` und Migration v20→v21,
- atomarer Preis-/Herkunftsschreibweg sowie Herkunftsentfernung bei manueller
  oder CSV-Ersetzung,
- Produktionsworkspace-Sheet und Herkunftsanzeige im Preisprofil,
- zentrale Fehlercodes `NEN-MKT-001` und `NEN-MKT-002`,
- Xcode-Projekt aus `project.yml` regeneriert und strukturell verifiziert.

Neue Hauptdateien:
`MarketPriceImport.swift`, `ESIMarketOrderClient.swift`,
`FileESIMarketOrderPageCache.swift`, `NexusSchemaV21.swift`,
`MarketPriceImportView.swift`, `MarketPriceImportViewModel.swift`,
`MARKET_PRICES.md` und ADR-0046.

Gelöscht oder verschoben: keine P41-Datei. Datenmodelländerung: additive
leichte Migration v20→v21; bestehende Preise und Benutzerdaten bleiben
erhalten.

## Build und Tests

- `swift build`: **erfolgreich**.
- `swift test --filter ESIMarketOrderClientTests`: **3/3 bestanden**.
- P41-/Schema-/Backup-Sammellauf: **21/21 bestanden**.
- `swift test --skip-build`: **593/593 bestanden**, 0 Fehler.
- `Scripts/generate_xcode_project.sh`: **erfolgreich**; 16 Targets, acht
  Testtargets, zwei gemeinsame Schemes.
- Zwei `xcodebuild`-Debugversuche, der zweite mit isoliertem DerivedData,
  blieben vor der eigentlichen Buildphase ohne weitere Ausgabe hängen und
  wurden kontrolliert abgebrochen. Deshalb liegt kein erfolgreicher
  Xcode-Buildnachweis vor.

Der erste Volltestlauf deckte einen echten P41-Folgebefund auf:
`NexusStoreSchemaInspector` erkannte v21 noch nicht. Die Erkennung,
Backupversion und Migrationstests wurden korrigiert; der finale Volltestlauf
ist grün.

## Review

Geprüft wurden Diff, Schichtengrenzen, tokenloser Request, Type-/Seiten- und
Größenlimits, Preisrundung, Cacheidentität, Offlinepfad,
Vorschau-vor-Schreiben, Stale-State, atomare Persistenz, Migration,
Backupkompatibilität, sichere Fehlertexte und Dokumentation.

Entscheidung: **⚠️ mit Einschränkung bestanden**. Der Fachstand und die
SwiftPM-Abnahme sind vollständig grün. Nach `AGENTS.md` ist wegen der UI- und
Projektänderung zusätzlich ein tatsächlich erfolgreicher Xcode-Debugbuild
erforderlich.

## Offene Punkte und Abnahmekriterien

Erfüllt: Kriterien 1–7 des P41-Prompts sind implementiert und automatisiert
geprüft. OFF-021 wurde erneut geprüft; P41 benötigt keinen zusätzlichen
SDE-Datensatz und das Bedarfsgate bleibt für spätere Ortsdaten offen.

Offen: Xcode schließen beziehungsweise dessen hängenden lokalen Buildzustand
auflösen und anschließend den unsigned macOS-arm64-Debugbuild erneut
ausführen. Bis dahin bleibt P41 `⚠️` und P42 wird nicht begonnen.

Kein Commit oder Push wurde ausgeführt. Es wurden keine Signing-/Teamwerte
geändert und kein persönlicher Live-Marktabruf vorgenommen.

## Nächster Schritt

P41-Xcode-Abnahme nach bereinigtem lokalem Xcode-Zustand; danach Nutzenreview
für P42 und P42 nur auf ausdrücklichen Auftrag.
