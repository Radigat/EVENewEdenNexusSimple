# PLAN-001 – Restbefunde und Promptzuordnung

Datum: 2026-07-23  
Status: **✅ Planung abgeschlossen – keine Implementierung**

## Prompt-ID und Ziel

PLAN-001 prüft zehn gemeldete Restbefunde gegen aktuellen Quellcode,
Git-Status, offene Register und geplante Prompts. Nur ungedeckte Arbeiten
werden als neue Zwischenprompts eingeordnet; bereits abgedeckte Punkte
erhalten keine doppelte Implementierung.

## Ausgangszustand

- eigene Projekt-Git-Wurzel vorhanden, Branch `main` ohne Commit,
- sämtliche Projektdateien untracked,
- SwiftPM als einziger verifizierter Buildweg,
- P07B-Technikkern und Realabnahme abgeschlossen,
- P07C in Bearbeitung und P10 offen,
- spätere Qualitäts- und Releaseprompts P34/P36/P37 nur als Entwürfe.

## Zuordnungsentscheidung

| Befund | Entscheidung | Zielprompt und Reihenfolge |
|---|---|---|
| keine Commit-Historie | bisher ungedeckt; neuer Zwischenprompt | P09A direkt nach dem bereits laufenden P07C |
| direkte SwiftData-Zugriffe in Views | bereits inkrementell geplant, jetzt dateibezogen präzisiert | P11 `ProjectsView`, P32 produktive MVP-/Dashboardreste, P38 eingefrorene Character-/SSO-Views |
| kein eigenständiges Xcode-Projekt/Scheme | bisher nur „separater Auftrag“; neuer Zwischenprompt | P09B nach P09A, vor P10 |
| SDE-Updatecheck nicht produktiv verdrahtet | kein neuer Prompt | P07C, Composition-Root- und App-Start-Gate ergänzt |
| P07B-Installationsservice nicht produktiv verdrahtet | kein neuer Prompt | P07C, manueller echter App-Pfad und isolierter E2E-Smoke-Test ergänzt |
| echter Prozessabbruch/App-Neustart offen | bereits P36; eigener offener Punkt und Nachweis waren zu schwach | OFF-024/KI-024; P36 verlangt nun externe harte Prozessbeendigung und Neustart derselben isolierten App-Composition |
| große P07B-Dateien | bereits OFF-022/P34 | P34 übernimmt verhaltensneutrale mechanische Teilung |
| Settings, Historie, Diagnoseexport, Recht fehlen | bereits P07C | P07C bleibt zuständig |
| DLA/Kontakt entschieden, Marken-/Releasefreigaben offen | bereits P07C/P37 | P07C Rechtstext-Owner-Gate, P37 itemweiser persönlicher Release-Sign-off |
| 21 nicht aufgelöste Blueprintreferenzen | bereits P10; Entwurf unzureichend | P10 vollständig spezifiziert: betroffene Rezepte blockieren, fehlende Typen niemals erfinden |

## Neu erstellte Dateien

- `Documentation/Prompts/MVP/P09A_Repository-Baseline-Git-Historie.md`
- `Documentation/Prompts/MVP/P09B_Xcode-Projekt-Schemes.md`
- `Documentation/Progress/Reports/2026-07-23_PLAN-001_Restbefunde-Promptzuordnung.md`

## Geänderte Dateien

- P07C, P10, P11, P32, P34, P36 und P37,
- Promptregister und Roadmap,
- Projektstatus, Entwickler-Menü und Feature-Matrix,
- offene Punkte, offene Aufgaben und bekannte Probleme,
- Reviewregeln und Entwicklertagebuch.

## Gelöschte oder verschobene Dateien

Keine. Der kurze P10-Entwurf wurde am gleichen Pfad durch eine vollständige
Spezifikation ersetzt.

## Architekturentscheidungen

Keine produktive Architekturänderung. Geplant sind:

- Git-Baseline unmittelbar nach dem bereits laufenden P07C,
- Xcode-Projekt ohne Aufhebung des SwiftPM-Wegs,
- konkrete Adapter ausschließlich an der App-Composition Root,
- stufenweise Entfernung direkter SwiftData-Viewzugriffe,
- keine erfundenen SDE-Referenzen.

## Datenmodelländerungen

Keine.

## Build- und Testergebnis

Nicht ausgeführt; PLAN-001 ist ein reines Planungs- und
Dokumentationsarbeitspaket. Der letzte bestätigte Produktnachweis bleibt der
P07B-Stand mit 153 Tests in Debug und Release.

## Manuelle Prüfungen

- Git-Wurzel, Branch und fehlende Historie geprüft,
- fehlendes `.xcodeproj`/`.xcworkspace` geprüft,
- direkte SwiftData-Zugriffe in App-Views gesucht,
- Dateigrößen der beiden P07B-Schwerpunkte geprüft,
- P07C/P10/P34/P36/P37 sowie alle aktiven offenen Register abgeglichen.

## Bekannte Probleme und offene Anforderungen

Alle zehn technischen Befunde bleiben bis zur Ausführung ihrer Zielprompts
offen. PLAN-001 löst ausschließlich die Zuordnung und Spezifikation.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. P09A/P09B sind zusätzliche
Entwicklungsqualitätsgates, die den reduzierten MVP weder erweitern noch
Zukunftsfunktionen vorziehen.

## Abnahmekriterien

- jeder gemeldete Befund besitzt genau einen nachvollziehbaren Zielpfad:
  **erfüllt**,
- ungedeckte Punkte als vollständige Zwischenprompts:
  **erfüllt**,
- Reihenfolge ohne konkurrierende Implementierung:
  **erfüllt**,
- keine technische Umsetzung:
  **erfüllt**.

## Reviewentscheidung

**✅ Planung bestanden.** Zwei neue Zwischenprompts schließen die
Planungslücken; die übrigen Befunde bleiben ohne Doppelung in ihren
zuständigen Prompts.

## Nächster empfohlener Prompt

Das bereits laufende P07C abschließen; danach P09A – Repository-Baseline und
Git-Nachvollziehbarkeit.
