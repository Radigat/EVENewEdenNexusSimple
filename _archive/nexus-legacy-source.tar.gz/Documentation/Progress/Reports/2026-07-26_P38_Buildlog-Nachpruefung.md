# P38 – Buildlog-Nachprüfung

Datum: 2026-07-26  
Status: **⚠️ P38 weiterhin durch OFF-033 blockiert**

## Befund

Die gemeldeten `com.apple.linkd.autoShortcut`-/AppIntents-Zeilen sind
Laufzeitdiagnostik des macOS-Systemdienstes und kein Swift-Compiler- oder
Linkerfehler. Der anschließend isoliert ausgeführte Xcode-Debugbuild endete
mit `BUILD SUCCEEDED`.

Die protokollierten Codes `NEN-AUTH-001` und `NEN-PER-004` stammen aus
einem älteren App-Lauf. Der aktuelle Quellstand klassifiziert den
Keychain-Vault-Fehler als `NEN-AUTH-003` beziehungsweise beim Trennen als
`NEN-AUTH-002`. OFF-033 bleibt für den stabil signierten Real-SSO-Lauf
offen.

Zusätzlich wurde ein echter UI-Befund behoben:
`cart.badge.checkmark` ist auf dem Zielsystem kein verfügbares SF Symbol.
Der Empty State verwendet nun `checkmark.circle.fill`.

## Änderungen

- `Sources/NewEdenNexus/PurchasingView.swift`: gültiges SF Symbol.
- `Tests/NewEdenNexusArchitectureTests/PurchasingWorkflowArchitectureTests.swift`:
  Regressionstest gegen den ungültigen Symbolnamen.
- kompakte Status-, Test- und Befunddokumentation.

Keine Daten-, Schema-, Signing-, Keychain- oder Kontomutation. Kein Commit
oder Push.

## Prüfung

- isolierter SwiftPM-Test `PurchasingWorkflowArchitectureTests`:
  **bestanden**.
- isolierter Xcode-Debugbuild, arm64, Signing deaktiviert:
  **BUILD SUCCEEDED**.
- Xcode-Projektprüfung:
  **16 Targets, 8 Testtargets, 2 gemeinsame Schemes**.
- Apple-Development-Build weiterhin nicht abnehmbar, weil der
  Anmeldeschlüsselbund gesperrt ist.

Reviewentscheidung: **⚠️ mit Einschränkung bestanden**. Der gemeldete Build
kompiliert; P38 bleibt ausschließlich an OFF-033 und dem Real-SSO-Lauf
blockiert.
