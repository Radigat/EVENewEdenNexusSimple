# P35 – Accessibility- und UX-Politur

Datum: 2026-07-26  
Status: **⚠️ mit Einschränkungen bestanden**

## Ziel und Ausgangszustand

P35 wurde ausdrücklich reaktiviert. Der Entwurf verlangte Fokus-, Label-,
Kontrast- und Layoutpolitur, enthielt aber veraltete OFF-Zuordnungen.
Schema v20, Graphformat 7 und die große vorhandene Arbeitskopie wurden
erhalten.

## Änderungen

- funktionale Sidebar-Suche mit Empty State und deutschen Suchbegriffen,
- Hauptfenster-Minimum auf 780 × 560 reduziert,
- Dashboard, Produktionsworkspace, Einkauf und SDE responsiv angeordnet,
- Theme auf adaptive macOS-Systemfarben umgestellt,
- Metriken, Projektzeilen und SDE-Status semantisch beschriftet,
- Fokusfolge im Projekteditor ergänzt,
- P35-Spezifikation, Accessibility-Dokument und ADR-0040 erstellt,
- sechs neue Tests für Navigation und Accessibility-Architektur ergänzt.

Neu: `AppNavigationAccessibilityTests.swift`,
`P35AccessibilityArchitectureTests.swift`, `ACCESSIBILITY_AND_UX.md`,
ADR-0040 und dieser Bericht. Keine Dateien wurden gelöscht oder verschoben.

## Architektur- und Datenwirkung

Die Änderung bleibt in der SwiftUI-/Navigationsschicht. Keine neue
Abhängigkeit, Migration, Schema-, Backup-, Graph- oder Benutzerdatenänderung.
Weitere UI-Sprachen und SDE-Übersetzungsdaten bleiben ohne bestätigten Bedarf
außerhalb des Scopes.

## Build und Tests

- Projektgenerierung/-prüfung: 15 Targets, 7 Testtargets, 2 Schemes.
- fokussiert: 10/10 Tests bestanden.
- SwiftPM Debug: 518/518, 0 Fehler, 0 übersprungen.
- Xcode Debug: 518/518, 0 Fehler, 0 übersprungen.
- Xcode musste nach einem sandboxbedingten SwiftData-Makrofehler außerhalb
  der Dateisandbox wiederholt werden und bestand dort.

Bekannte nicht fatale Testhost-Hinweise: Core-Data-Migrationsmeldungen,
eingeschränkte Test-UserDefaults und AppIntents-Dienstmeldungen.

## Manuelle Prüfung

Das echte Debug-App-Bundle startete mit
`--new-eden-nexus-isolated-store /private/tmp/new-eden-nexus-p35-ui.store`;
der isolierte Store wurde angelegt. Der native Computer-Use-Kanal schloss
seine Pipe jedoch vor Ausgabe des Accessibility-Baums. Daher werden weder
ein aktueller vollständiger VoiceOver-Durchlauf noch Screenshots behauptet.

## Offene Punkte und Abweichungen

- `OFF-030`: manuellen Tastatur-/VoiceOver-Durchlauf des aktuellen Builds
  bei schmalem und breitem Fenster wiederholen.
- `OFF-020` bleibt Release-/Complianceprüfung.
- `OFF-021` bleibt das bedarfsgesteuerte SDE-Datengate; kein Blindimport.
- P36 und öffentlicher Release-Sign-off bleiben unbegonnen.

## Abnahmekriterien und Review

Suche, responsive Pfade, Fokus, semantische Farben, Statusbeschriftung,
Build, Tests und Dokumentation sind erfüllt. Der aktuelle manuelle
Accessibility-Nachweis fehlt.

Reviewentscheidung: **⚠️ mit Einschränkungen bestanden**. Kein bestätigter
Produktfehler, aber P35 darf bis `OFF-030` nicht auf ✅ gesetzt werden.

Nächster Schritt: `OFF-030` bei verfügbarem Accessibility-Kanal schließen;
danach P35 final abnehmen. P36 nur nach ausdrücklichem Auftrag.
