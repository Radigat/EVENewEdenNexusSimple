# Abschlussbericht – P21: CSV-Bestandsimport

Datum: 2026-07-24  
Prompt-ID: P21  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

Einen sicheren lokalen CSV-Bestandsimport mit Formatprüfung,
Spaltenzuordnung, schreibfreier Detailvorschau, positionsgenauen
Konfliktentscheidungen, ausdrücklicher Bestätigung, atomarem Commit und
dauerhaftem Importbericht vollständig spezifizieren und umsetzen.

## Ausgangszustand

P20 stellte Lager und manuelle Bestandspositionen in Schema v10 bereit. Es
gab keinen CSV-Parser, keine Importvorschau, keinen Konfliktvertrag und
keinen Bericht. OFF-005/KI-005 waren für P21 bis P25 teilweise offen. Der
Arbeitsbaum enthielt bestehende uncommittete Änderungen aus früheren
Paketen; sie wurden erhalten. Es erfolgte kein Commit, Push, Reset, Rebase
oder Merge.

## Durchgeführte Änderungen

- vollständige P21-Spezifikation mit 17 messbaren Abnahmekriterien,
- begrenzter CSV-Dateileser mit SHA-256 und regulärer-Datei-Prüfung,
- Parser für Komma/Semikolon/Tab, UTF-8, UTF-16 LE/BE, Windows-1252 und
  ISO-8859-1,
- korrekte Behandlung von LF, CRLF, Zitaten, `""` und Mehrzeilenfeldern,
- sichtbares Header-Mapping und positive `Int64`-Mengenregeln,
- schreibfreie, zeilengenaue Katalog- und Bestandsvorschau,
- vollständige Ablehnung doppelter Type-IDs ohne Aggregation,
- positionsgenaue Ersetzen-/Überspringen-Entscheidungen,
- ausdrückliche Bestätigung und Stale-Preview-Schutz,
- atomarer Repository-Commit mit zeilengenauem Importbericht,
- additives Schema v11 und leichte v10→v11-Migration,
- Backupformat 11.0.0 und Kompatibilität bis Schema 11,
- native Importansicht mit Fortschritt, Abbruch, Fehlern und Bericht,
- zentrale Fehlercodes `NEN-INV-003` und `NEN-INV-004`,
- versionierte synthetische CSV-Fixtures und 18 neue Tests,
- Xcode-Projekt regeneriert und Parität geprüft.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/InventoryCSVImport.swift`
- `Sources/NewEdenNexusInfrastructure/DelimitedInventoryCSVParser.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV11.swift`
- `Sources/NewEdenNexus/InventoryCSVImportView.swift`
- `Sources/NewEdenNexus/InventoryCSVImportViewModel.swift`
- `Tests/NewEdenNexusApplicationTests/InventoryCSVImportServiceTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/InventoryCSVParserTests.swift`
- `Tests/NewEdenNexusPersistenceTests/InventoryCSVImportPersistenceTests.swift`
- versionierte Fixtures unter
  `Tests/NewEdenNexusTestSupport/Fixtures/InventoryCSV/v1`
- `Tests/NewEdenNexusTestSupport/InventoryCSVReferenceFixture.swift`
- `Documentation/INVENTORY_CSV_IMPORT.md`
- `Documentation/Architecture/ADRs/ADR-0026_Sicherer-CSV-Bestandsimport-und-Schema-v11.md`
- dieser Abschlussbericht.

## Geänderte Dateien

Inventory-Repository und Composition, Lageransicht und ViewModel,
Migrationsplan, Containerfactory, Backupdienst, zentrale Fehlerbehandlung,
Backup- und Architekturtests, `project.yml`/generiertes Xcode-Projekt sowie
alle verpflichtenden Status-, Architektur-, Test- und
Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Prüfung und Schreiben sind getrennt. Ein Import zielt auf ein vorhandenes
Lager, bindet die Vorschau an Datei-Hash, Lager-, Bestands- und
Katalogzustand und schreibt Änderungen samt Bericht in einer Transaktion.
Details: ADR-0026.

## Datenmodelländerungen

Schema v11 ergänzt additiv `InventoryImportRecord` mit Metadaten, Zählern
und versionierter bereinigter Detailpayload. Bestehende SDE-, Projekt-,
Graph-, Reaktions-, Lager- und Bestandsdaten bleiben unverändert. Die
v10→v11-Migration, zweite Öffnung, Leerstore und Backups 1.0.0 bis 11.0.0
sind geprüft; 12.0.0 wird abgelehnt.

## Build-Ergebnis

| Weg | Konfiguration | Ergebnis |
|---|---|---|
| SwiftPM | Debug | ✅ erfolgreich |
| SwiftPM | Release | ✅ erfolgreich |
| Xcode, Scheme `NewEdenNexus`, Signing aus | Debug | ✅ erfolgreich |
| Xcode, Scheme `NewEdenNexus`, Signing aus | Release | ✅ erfolgreich |

Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
Signing- und Teamwerte wurden nicht geändert.

## Testergebnis

| Weg | Konfiguration | Ergebnis |
|---|---|---|
| SwiftPM | Debug | 353 bestanden, 0 Fehler, 0 übersprungen |
| SwiftPM | Release | 353 bestanden, 0 Fehler, 0 übersprungen |
| Xcode | Debug | 353 bestanden, 0 Fehler, 0 übersprungen |
| Xcode | Release | 353 bestanden, 0 Fehler, 0 übersprungen |

Die Xcode-`xcresult`-Zusammenfassungen bestätigen je 353 erfolgreiche
Tests. Der erste eingeschränkte Xcode-Lauf scheiterte erwartungsgemäß an
der Dateisandbox des SwiftData-Makroservers und zählt nicht als Erfolg; die
freigegebenen Abschlussläufe waren grün.

## Manuelle Prüfungen

- App-Binary mit
  `--new-eden-nexus-isolated-store /tmp/new-eden-nexus-p21-manual.store`
  gestartet und kontrolliert beendet,
- erzeugter Schema-v11-Store mit `PRAGMA integrity_check = ok`,
- Projektparität, Git-Diff und Pflichtpfade geprüft,
- Import-UI und Schichtengrenzen statisch kontrolliert.

Eine vollständige visuelle VoiceOver-/Bedienabnahme wurde nicht als P21-
Nachweis behauptet; sie bleibt im vorgesehenen P35/P37-Gate.

## Gefundene und behobene Probleme

Der neue Parser behandelte CRLF zunächst nicht als von Swift zu einem
`Character` zusammengefasstes Zeilenende. Der vollständige Testlauf
reproduzierte den Fehler bei Headern und zitierten Feldern. Eine zentrale
Zeilenendeprüfung für CR, LF und CRLF behebt ihn; Regressionstests decken
UTF-8, UTF-16 und zitierte Mehrzeilenfelder ab.

Die abschließende Kontrollprüfung fand außerdem, dass eine doppelte Type-ID
bei einer zusätzlich mengenfehlerhaften Zeile nur die ansonsten gültige
Zeile blockiert hätte. Die Duplikaterkennung berücksichtigt nun jede
parsebare Type-ID und lehnt alle Vorkommen ab; der bestehende Servicetest
enthält diesen kombinierten Randfall.

## Bekannte Probleme und offene Anforderungen

- Keine durch P21 verursachte kritische Regression.
- OFF-005/KI-005 bleiben teilweise offen für P22 bis P25.
- OFF-006/KI-006/KI-013 bleiben für automatisches
  Vor-Migrationsbackup und Recovery-Drill in P36 teilweise offen.
- Importhistorienverwaltung und Berichtsexport sind nicht Teil von P21.
- vollständige manuelle Accessibility-Abnahme bleibt P35/P37.

## Abweichungen vom Projektbuch

P21 importiert ausschließlich lokale aggregierte Bestände in ein
vorhandenes Lager. ESI-Assets, automatische Lagererzeugung und andere
Importformate wurden entsprechend dem reduzierten MVP nicht vorgezogen.

## Erfüllte und nicht erfüllte Abnahmekriterien

Alle 17 Kriterien der vollständigen P21-Spezifikation sind erfüllt.
Insbesondere sind Preview-before-write, Einzelkonflikte, Atomarität,
Wiederanlauf, Schema-/Backupkompatibilität und vier Abschlussläufe
nachgewiesen. Keine P21-Pflicht blieb offen.

## Reviewentscheidung

Der gesonderte Kontrollschritt verglich Spezifikation, Diff, produktiven
Code, Schichtengrenzen, Parsergrenzen, atomaren Persistenzpfad,
Migrations-/Backupverhalten, vier Abschlussläufe, manuellen isolierten
App-Start und Dokumentation. Der CRLF-Restbefund wurde vor der Entscheidung
behoben und regressionsgetestet.

**Entscheidung: ✅ bestanden.**

## Nächster empfohlener Prompt

**P22 – Verfügbarkeit und Ausschlüsse zunächst vollständig spezifizieren
und anschließend ausführen.** P22 wurde nicht begonnen.
