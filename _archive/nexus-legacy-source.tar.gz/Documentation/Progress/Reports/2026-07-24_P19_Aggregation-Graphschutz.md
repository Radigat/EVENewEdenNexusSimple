# Abschlussbericht – P19: Aggregation und Graphschutz

Datum: 2026-07-24

Prompt-ID: P19

Status: **✅ erledigt**

Review: **✅ bestanden**

## Ziel

Die getrennten Materialvorkommen der vollständigen T1-/T2-/
Reaktionsgraphbasis nach stabiler CCP-Type-ID zusammenführen, ihre Herkunft
erklärbar erhalten und Graphen gegen fehlerhafte Beziehungen,
Lastüberschreitung, Manipulation und Summenüberlauf schützen.

## Ausgangszustand

P13 bis P18 lieferten Graphbasis, Runs, Output, Blueprint-ME, T1/T2,
notwendige Reaktionen, Graphformat 6 und Schema v9. Materialblätter blieben
bewusst getrennt; nur eine alte flache Aggregationskomponente außerhalb des
Produktionsgraphen existierte. Die Aggregationsanteile von OFF-004/KI-003
und OFF-009/KI-012 waren offen.

Der Branch war `main`, Git-Wurzel war ausschließlich
`/Users/svenstolze/Documents/Codex/EVE Nexus`. Der Arbeitsbaum enthielt
vorhandene P09B–P18-Änderungen. Nichts wurde verworfen, zurückgesetzt,
gestaged, committet oder gepusht.

## Vollständige Spezifikation

`Documentation/Prompts/MVP/P19_Aggregation-Graphschutz.md` wurde vor der
Umsetzung vervollständigt. Sie definiert Zweck, Voraussetzungen, Ergebnis,
Risiken, Aggregationsschlüssel und -menge, Erklärpfade,
Überlaufentscheidung, Graphgrenzen, Datenhaltung, UI, Fehler-/Bestandsschutz,
notwendige offene Punkte, Testmatrix, 15 messbare Abnahmekriterien und
Nichtumfang.

## Durchgeführte Änderungen

### Domain

- neue reine `ProductionGraphMaterialAggregator`-Komponente,
- Aggregation ausschließlich tatsächlicher Materialblätter,
- Gruppierung nach positiver CCP-Type-ID,
- effektive Manufacturing- oder Reaktionsmenge je Vorkommen,
- Ausschluss rezepttragender Zwischenprodukte,
- Einzelvorkommen mit Blattgrund und vollständigem Wurzelpfad,
- stabile Sortierung unabhängig von Eingabereihenfolge,
- Namenskonsistenz je Type-ID,
- `Int64.addingReportingOverflow` ohne Clamping oder Gleitkomma,
- Graphformat 7 und Aggregationsformel 1,
- exakte Neuberechnung gespeicherter Aggregationen,
- gleiche Tiefe- und Knotenlimits für Generierung und geladene Payloads,
- eindeutige Geschwister-Sortierung und iterative Zyklusprüfung.

### Application und Bestandsschutz

Der Service aggregiert erst den vollständigen Kandidaten und erzeugt danach
den validierten Snapshot. Aggregationsfehler werden typisiert weitergegeben.
Repository-`save` wird bei Fehler oder Cancellation nicht erreicht; ein
vorhandener Graph bleibt unverändert.

### Persistenz

Die Aggregation liegt in der kanonischen `ProductionGraphRecord.payload`.
Graphformat 7 wird rundgeführt und beim Laden verifiziert. Format 6 bleibt
lesbar und veraltet. Ein veränderter Gesamtwert wird abgelehnt.

Es gibt keine SwiftData-Modelländerung:

- aktuelle Datenbankschemaversion: v9,
- Backupformat: 9.0.0,
- Migration: nicht erforderlich,
- Benutzer-, Projekt- und SDE-Daten: unverändert.

### Benutzeroberfläche

Die Graphansicht zeigt Materialtypen und Vorkommenszahl, Type-ID,
Gesamtmenge und aufklappbare Einzelvorkommen mit vollständigem Pfad.
Altformate ohne Aggregation zeigen einen Hinweis zur bewussten
Neuerzeugung. Accessibility-Beschriftungen sind vorhanden.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionGraphAggregation.swift`
- `Tests/NewEdenNexusDomainTests/ProductionGraphAggregationTests.swift`
- `Documentation/MATERIAL_AGGREGATION.md`
- `Documentation/Architecture/ADRs/ADR-0024_Graphaggregation-und-Graphformat-7.md`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusDomain/ProductionGraph.swift`
- `Sources/NewEdenNexusApplication/ProductionGraph.swift`
- `Sources/NewEdenNexus/ProductionGraphView.swift`
- `Tests/NewEdenNexusDomainTests/ProductionGraphTests.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionGraphServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ProductionGraphPersistenceTests.swift`
- `Tests/NewEdenNexusTests/ProductionGraphViewModelTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ProductionGraphArchitectureTests.swift`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- P19-Prompt und verpflichtende Projekt-, Architektur-, Status-, Test- und
  Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidung

[ADR-0024](../../Architecture/ADRs/ADR-0024_Graphaggregation-und-Graphformat-7.md)
entscheidet sich für eine zusätzliche Type-ID-Aggregation bei weiterhin
vorkommensbasiertem Graphen. Eine Namensaggregation, globale
Knotendeduplizierung, quellenlose Summe, Clamping und eine neue
SwiftData-Spalte wurden verworfen.

## Build-Ergebnis

Erfolgreich:

```text
env HOME=/private/tmp/nen-p19-home
  CLANG_MODULE_CACHE_PATH=/private/tmp/nen-p19-clang
  swift test --disable-sandbox
  --scratch-path /private/tmp/nen-p19-temp-build

swift test --disable-sandbox
  --scratch-path /private/tmp/nen-p19-temp-build-release -c release

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P19-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO test -quiet

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P19-Xcode-Release
  CODE_SIGNING_ALLOWED=NO test -quiet

python3 Scripts/verify_xcode_project.py
```

- SwiftPM Debug/Release: erfolgreich,
- Xcode Debug/Release: erfolgreich,
- Xcode: Debug und Release, 15 Targets, sieben Testtargets,
- Paritätsprüfung: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes,
- keine Signing- oder Teameinstellung verändert.

Die Abschlussläufe erfolgten in einer identischen temporären Quellkopie,
weil ein direkter Workspace-Lauf mit parallel veränderten Eingaben
abgebrochen war und SwiftData-/Swift-Modulplugins in der CLI-Dateisandbox
keine stabile Cachegrenze hatten.

## Testergebnis

- SwiftPM Debug: 321 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 321 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 321 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Release: 321 bestanden, 0 fehlgeschlagen, 0 übersprungen.

P19 deckt insbesondere ab:

- leere und gemischte Mehrzweigaggregation,
- gleiche Type-ID und gleiche Namen bei unterschiedlichen Type-IDs,
- Ausschluss von Zwischenprodukten,
- Wurzelpfade und deterministische Reihenfolge,
- widersprüchliche Namen,
- `Int64.max` und nächster Summenüberlauf,
- fehlende Menge/Kante und Zyklus,
- Altgraph-Erhalt bei Überlauf,
- doppelte Geschwister-Sortierwerte,
- Tiefe über 64 und mehr als 25.000 geladene Knoten,
- Graphformat-7-Roundtrip,
- Graphformat-6-Lesbarkeit,
- manipulierte Aggregationspayload,
- UI-/Architekturgrenze.

Nicht fehlschlagende Umgebungsdiagnosen waren SwiftPM-Benutzercaches in der
Dateisandbox und Core-Data-Store-Change-Notification im temporären
Testhost. Keine Warnung wurde unterdrückt.

## Manuelle Prüfungen

Das finale Xcode-Debug-App-Binary startete mit
`/private/tmp/NewEdenNexus-P19-App.BC5lz9/P19.store`.
`ProductionProject`, `ProductionGraphRecord` und `ReactionRuleRecord` waren
vorhanden. `PRAGMA integrity_check` meldete während und nach dem Lauf `ok`.
Der Prozess wurde kontrolliert beendet. Produktive Benutzerdaten wurden
nicht geöffnet. Es wird keine neue visuelle oder VoiceOver-Abnahme
behauptet.

## Bekannte Probleme und Risiken

Keine durch P19 verursachte kritische Regression ist offen.

Bewusst verbleiben:

- reale Großgraph-Performancebudgets und Speicherprofile in P34,
- Bestandsabzug, Ausschlüsse und Schutzmengen P20 bis P25,
- Build-or-Buy P26,
- tatsächlicher externer SDE-Prozessabbruch/Neustart P36,
- zeitabhängige Release-/CCP-Prüfung P37.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. Die Regeln aus Kapitel 11.23, 28.4.8, 30.9 und
Anhang E.8 wurden auf den reduzierten MVP angewandt. Eine „Nettoliste“
bezeichnet in P19 noch keinen Bestandsabzug; dieser bleibt korrekt P22.

## Erfüllte Abnahmekriterien

Alle 15 Kriterien der vollständigen P19-Spezifikation sind erfüllt:
zentraler deterministischer Algorithmus, Schließung der vier
OFF/KI-Einträge, Type-ID-Zusammenführung, kein Zwischenprodukt-Doppelzählen,
Erklärpfade, typisierter Überlauf und Altgraph-Erhalt,
Payload-Neuverifikation, Format 7/Formel 1, Lesbarkeit 1 bis 6,
geladene Lastgrenzen, relevante Tests, vier erfolgreiche Buildwege,
isolierter App-/Storetest sowie vollständige Dokumentation und Review.

## Nicht erfüllte Abnahmekriterien

Keine.

## Reviewentscheidung

**✅ bestanden.**

Der Review prüfte nicht nur die Abschlussaussagen, sondern Quellcode,
Graphinvarianten, Testfälle, Xcode-Ergebnisbundles, SwiftPM-Ausgaben,
Projektparität, isolierten Store und Dokumentationskonsistenz.

## Nächster empfohlener Prompt

**P20 – Lager und manuelle Bestände zunächst vollständig spezifizieren und
anschließend ausführen.** P20 wurde nicht begonnen. Der für P20 notwendige
Teil von OFF-005 ist verbindlich in seine Spezifikation zu übernehmen;
Sicherheitsbestände und Reservierungen bleiben P23 bis P25.
