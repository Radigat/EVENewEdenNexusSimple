# P58 – Produktionskosten und Preisvorschläge

Datum: 2026-07-29

Status: ⚠️ technisch umgesetzt; Eigentümer-Sichttest OFF-060 offen

Review: ⚠️ mit ausschließlich betrieblicher Einschränkung bestanden

## Ziel und Ausgangszustand

P57 stellte unveränderliche Produktionschargen bereit. Projektbudget,
Preissätze und P41-Marktquotes waren vorhanden, aber nicht als reproduzierbare
Chargenkosten verbunden. OFF-058 blockierte außerdem die Preisübernahme, wenn
noch kein Ziel-Preissatz existierte.

## Durchgeführte Änderungen

- typisierte Kostenzeilen für Material, Job/Index, Facility/SCC/Steuer,
  Blueprint/Invention, Logistik, Marktgebühren und manuelle Zusatzkosten,
- deterministische Berechnung von Gesamtkosten, Stückkosten, +5/+10 Prozent,
  Erlös, Gewinn, Marge, ROI und Break-even in ISK-Hundertsteln,
- vollständige `PriceQuoteBinding`-Provenienz für Jita und einen optionalen
  benannten Alternativmarkt; expliziter manueller/CSV-Fallback,
- Vorschau, Source-State-Prüfung und ausdrückliche Bestätigung vor Speicherung,
- Schema v27 und Repository für unveränderliche
  `ProductionBatchCostSnapshot`-Datensätze,
- Produktionsbuch-UI für Eingaben, Quotes, Warnungen und Kennzahlen,
- OFF-058 geschlossen: Ziel-Preissatz eingebettet anlegen/auswählen,
  bestätigte Preise übernehmen und Budget neu laden,
- Xcode-Projekt aus dem Kanon regeneriert; keine Benutzeränderung verworfen
  und kein Commit erstellt.

## Architektur und Datenmodell

ADR-0061 ist akzeptiert. Kosten- und Quotegrundlagen werden beim Bestätigen
kopiert und nicht über veränderliche Budgets oder Marktstände referenziert.
Unbekannte Kosten bleiben unbekannt und sperren vollständige Kennzahlen.
Schema v27 ist additiv; v26→v27 erzeugt keine Kostenhistorie. Projekt-,
Chargen-, Wallet-, Preis-, Lager- und SDE-Daten bleiben getrennt.

## Build und Tests

- fokussiert: **37/37** bestanden,
- vollständige SwiftPM-Suite mit realem macOS-Security-Zugriff:
  **704/704** bestanden,
- Xcode Debug, Scheme `NewEdenNexus`, Ziel macOS:
  Apple-Development-signiert, **BUILD SUCCEEDED**,
- `git diff --check`: bestanden,
- Projektgenerator: **16 Targets, 8 Testtargets, 2 gemeinsame Schemes**.

Getestet wurden Mehrfachoutput, Rundung, Null und unbekannt, Division durch
null, Overflow, alternative Quotes, unveränderte Projekt-/Graphbasis,
v26→v27, Wiederöffnung, fehlende Chargenreferenz, Backupkompatibilität sowie
OFF-058-Anlage und Übernahme. Ein beschränkter Sandboxlauf scheiterte nur in
drei bestehenden JWT-Tests an dort nicht erzeugbaren `SecKey`-Objekten; der
abschließende uneingeschränkte Lauf war vollständig grün.

## Review und Datenwirkung

Diff, Schichtgrenzen, vorhandene P41-/P55-Wiederverwendung, Quoteprovenienz,
Unknown-/Overflow-Verhalten, Stale-Schutz, Migration, Backup und
Dokumentation wurden gesondert geprüft. Es gibt keine zweite ESI-, Cache- oder
Preissatzimplementierung. Keine produktive Charge, kein Preis und kein Budget
wurde durch die technische Prüfung verändert.

Die technischen Abnahmekriterien sind erfüllt. Nicht erfüllt ist der
ausdrücklich verlangte reale Eigentümer-Sichttest mit Jita und einer
geänderten Marktquelle. Deshalb bleibt P58 definition-of-done-konform `⚠️`.

## Offene Punkte und nächster Schritt

- OFF-060: In der App bei einer realen Charge Jita laden, anschließend einen
  anderen benannten öffentlichen Markt wählen, Herkunft/Kennzahlen prüfen,
  einmal verwerfen und nur bei gewünschtem Snapshot ausdrücklich bestätigen.
- OFF-056 bleibt für Verkaufszuordnung und Analyse in P59/P60 teilweise.
- P59 wurde nicht begonnen und startet erst nach OFF-060 sowie ausdrücklichem
  Auftrag.
- P54 bleibt unabhängig commit-freigabepflichtig; es erfolgte kein Commit.
