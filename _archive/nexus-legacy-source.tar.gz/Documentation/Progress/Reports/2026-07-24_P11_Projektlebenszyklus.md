# Abschlussbericht – P11 Projektlebenszyklus

- Prompt-ID: P11
- Datum: 2026-07-24
- Status: ✅ erledigt
- Review: ✅ bestanden

## Ziel

Den lokalen Produktionsprojekt-Lebenszyklus vollständig spezifizieren und
umsetzen: anlegen, laden, bearbeiten, Status ändern, duplizieren, reversibel
archivieren und wiederherstellen. `ProjectsView` sollte dabei vollständig von
direkten SwiftData-Zugriffen gelöst werden.

## Ausgangszustand

- Persistentes Projektmodell, Domain-Snapshot und Repository-Port waren aus
  P03 vorhanden.
- `ProjectsView` verwendete `@Query` und `modelContext` direkt.
- Nur der initiale Projektstatus war praktisch verdrahtet.
- Duplizieren, Archivieren, Wiederherstellen und ein verbindlicher
  Statusgraph fehlten.
- Schema v4 und Migrationen Legacy→v1→v2→v3→v4 waren grün.
- Der Arbeitsbaum enthielt bereits uncommittete P09B-/P10- und
  Dokumentationsänderungen; sie wurden weder verworfen noch überschrieben.

## Mit bearbeitete offene Punkte

| ID | Ergebnis |
|---|---|
| OFF-008 / KI-011 | Der `ProjectsView`-Anteil ist erledigt: keine SwiftData-Imports, kein `@Query`, kein `modelContext`; Application-Service, ViewModel und Composition Root sind nachgewiesen. Die unabhängigen Restanteile bleiben P32/P38. |

Neu erkannt wurde `OFF-026` / `KI-026`: Ein zusätzlicher manueller
Debug-App-Start zeigte `NEN-PER-001`. Die sichere Fehlergrenze funktionierte;
der Lauf wurde nicht als UI-Erfolg gewertet und veränderte keine
Benutzerdaten. Die isolierte Eingrenzung ist Voraussetzung für die
P12-UI-Abnahme.

## Durchgeführte Änderungen

### Application und Fachregeln

- `ProductionProjectDraft` und `ProductionProjectListScope`,
- `ProductionProjectLifecycleManaging`,
- `ProductionProjectLifecycleService`,
- `ProductionProjectStatusPolicy`,
- typisierte Fehler für fehlende Projekte, Archivschreibschutz und
  unzulässige Statuswechsel,
- injizierbare Uhr und UUID-Quelle,
- idempotente gleiche Statuswechsel ohne Schreibvorgang,
- Filter für aktuelle, archivierte und alle Projekte.

### Persistenz

- vorhandenen `SwiftDataProductionProjectRepository` weiterverwendet,
- Cancellation vor/nach Zugriffen geprüft,
- Einzelabfrage auf höchstens zwei Treffer begrenzt, damit doppelte IDs
  kontrolliert erkannt werden,
- keine Schemaversion und keine Migration ergänzt.

### Presentation und Composition

- `ProjectLifecycleViewModel` als `@MainActor`-UI-Zustandsgrenze,
- `ProjectAppComposition` für Repository, Service und ViewModel,
- `NexusAppRuntime` stellt das Projekt-ViewModel bereit,
- `RootView` injiziert es in `ProjectsView`,
- Projektfilter, Tabelle, Loading-/Empty-/Fehlerzustände,
- Anlege-/Bearbeitungsformular,
- Statusmenü, Duplizieren, bestätigte Archivierung und Restore,
- Tastaturkürzel und Accessibility-Labels,
- zentraler Projektladefehler `NEN-PER-006`.

### Testhost-Isolation

Gehostete Xcode-Tests verwenden einen In-Memory-Container und starten keine
produktive SDE-Composition. Statische Quellprüfungen laufen im nicht
gehosteten Architekturtarget, damit kein Dokumenten-TCC-Zugriff im
App-Testprozess nötig ist. `project.yml` verlinkt das gehostete Testbundle
nur mit dem App-Target und verhindert doppelte statische Modultypen.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ProductionProjectLifecycle.swift`
- `Sources/NewEdenNexus/ProjectLifecycleViewModel.swift`
- `Sources/NewEdenNexus/ProjectAppComposition.swift`
- `Sources/NewEdenNexus/AppExecutionEnvironment.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionProjectLifecycleTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ProductionProjectLifecyclePersistenceTests.swift`
- `Tests/NewEdenNexusTests/ProjectLifecycleViewModelTests.swift`
- `Tests/NewEdenNexusArchitectureTests/AppSourceArchitectureTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ProjectLifecycleArchitectureTests.swift`
- `Documentation/PROJECT_LIFECYCLE.md`
- `Documentation/Architecture/ADRs/ADR-0015_Projektlebenszyklus-und-reversible-Archivierung.md`
- dieser Bericht.

## Geänderte Dateien

- `Package.swift`, `project.yml`, `NewEdenNexus.xcodeproj`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Sources/NewEdenNexus/NexusAppRuntime.swift`
- `Sources/NewEdenNexus/ProjectsView.swift`
- `Sources/NewEdenNexus/RootView.swift`
- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionProjectRepository.swift`
- zugehörige Fehler-, Runtime- und Architekturtests
- verpflichtende Status-, Feature-, Architektur-, Datenmodell-, Test-,
  Prompt- und Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine produktiven Dateien wurden gelöscht. Reine statische
App-Quellprüfungen wurden aus dem gehosteten App-Testtarget in den
Architekturtarget verschoben. Bestehende Benutzeränderungen blieben erhalten.

## Architekturentscheidungen

ADR-0015 hält fest:

- Lebenszyklusregeln liegen in Application,
- Views kennen keine Persistenzadapter,
- Archivierung ist reversibel,
- dauerhaftes Löschen ist nicht Teil von P11,
- Katalogbindung bleibt P12.

## Datenmodelländerungen

Keine. Schema v4, Migrationen und vorhandene Benutzerdaten bleiben
unverändert. Archivierung verwendet den bestehenden Projektstatus.

## Build-Ergebnis

| Weg | Konfiguration | Ergebnis |
|---|---|---|
| SwiftPM | Debug | ✅ erfolgreich |
| SwiftPM | Release | ✅ erfolgreich |
| Xcode `NewEdenNexus` | Debug, My Mac arm64, Signing aus | ✅ erfolgreich |
| Xcode `NewEdenNexus` | Release, My Mac arm64, Signing aus | ✅ erfolgreich |
| Projektparität | 15 Targets, 7 Testtargets, 2 Schemes | ✅ erfolgreich |

Es wurden keine Signing-, Team- oder Releasewerte geändert.

## Testergebnis

| Weg | Debug | Release |
|---|---:|---:|
| SwiftPM | 198 bestanden, 0 fehlgeschlagen, 0 übersprungen | 198 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| Xcode | 198 bestanden, 0 fehlgeschlagen, 0 übersprungen | 198 bestanden, 0 fehlgeschlagen, 0 übersprungen |

P11 ergänzt 17 Tests: zwölf Application-, einen dateibasierten Persistence-,
drei ViewModel-/App-Integrations- und einen Architektur-/UI-Quelltest.

Verwendete Abschlussbefehle:

```bash
./Scripts/generate_xcode_project.sh
Scripts/verify_xcode_project.py
swift test -c debug
swift test -c release
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P11XcodeFinal \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P11XcodeFinalRelease \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
```

## Manuelle Prüfungen

- Quellcode, Diff, Branch, Status und uncommittierte Änderungen geprüft.
- Statusgraph und UI-Aktionen gegen Spezifikation kontrolliert.
- Projektparität und Ergebnisbundles ausgewertet.
- Ein zusätzlicher Debug-App-Start zeigte die sichere Startfehleransicht
  `NEN-PER-001`. Dieser Lauf ist ausdrücklich kein erfolgreicher UI-Smoke-
  Test. Es wurde kein produktiver Store gelöscht, ersetzt oder repariert.

## Zwischenfehler und Korrekturen

1. Ein früher vollständiger Xcode-Lauf hing vor Abschluss des gehosteten
   Testtargets.
2. Doppelte statische Module in Host und Testbundle wurden durch die
   Abhängigkeitskorrektur in `project.yml` beseitigt.
3. Produktive SDE-/Keychain-Nebeneffekte beim XCTest-App-Start wurden durch
   In-Memory-/Testcomposition-Isolation entfernt.
4. Statische Quellprüfungen über den Dokumentenpfad wurden in den
   Architekturtarget verschoben.
5. Ein Closure-Aufruf mit falschen Argumentlabels wurde korrigiert.
6. Eingeschränkte Swift-/Xcode-Läufe scheiterten am globalen Cache
   beziehungsweise an Xcode-Systemdiensten; identische Abschlussläufe mit
   freigegebenem Zugriff waren erfolgreich.

Kein fehlgeschlagener oder hängender Zwischenlauf wurde als Erfolg gewertet.

## Bekannte Probleme

- `OFF-026` / `KI-026`: lokalen App-Start vor/in P12 mit nachweislich
  isoliertem Store reproduzieren und `NEN-PER-001` eingrenzen.
- `OFF-008` / `KI-011` bleibt nur für unabhängige Views in P32/P38 teilweise
  offen.
- SDE-Recovery-, Wartbarkeits- und Releasepunkte bleiben ihren bisherigen
  Zielprompts P34/P36/P37 zugeordnet.

## Offene Anforderungen

- P12: kataloggestützte Zielproduktauswahl,
- P13–P19: Graph, Runs, ME, T1/T2 und Reaktionsketten,
- P20 ff.: Bestand, Entscheidungen, Kosten und Einkauf.

## Abweichungen vom Projektbuch

Der in P11 verwendete Statusgraph ist bewusst kleiner als das langfristige
Projektbuchmodell. Materialprüfung, Reservierung, Transport, Auslieferung und
Verkauf werden erst mit ihren Fachmodulen ergänzt. Diese Reduktion verhindert
Scheinstati ohne implementierte Fachwirkung.

## Abnahmekriterien

| Kriterium | Ergebnis |
|---|---|
| Lebenszyklusaktionen fachlich und lokal implementiert | ✅ |
| Wiederöffnung desselben Stores | ✅ |
| ungültige Übergänge/Archivmutationen blockiert | ✅ |
| `ProjectsView` ohne direkte SwiftData-Abhängigkeit | ✅ |
| keine Schemaänderung oder Löschung | ✅ |
| SwiftPM und Xcode Debug/Release grün | ✅ |
| UI-Zustände und Bedienpfade automatisiert geprüft | ✅ |
| Pflichtdokumentation aktualisiert | ✅ |
| gesonderter Review | ✅ bestanden |

Der zusätzliche echte App-Start war eingeschränkt, ist aber kein durch P11
verursachter Regressionstestfehler. Er bleibt transparent als OFF-026 offen.

## Reviewentscheidung

Der Review hat den tatsächlichen Diff, Schichtengrenzen, Statuspolicy,
Repositoryverhalten, Datenwirkung, Fehlerabbildung, Testhost-Isolation,
vollständige Testresultate und Dokumentation geprüft.

Entscheidung: **✅ bestanden**.

Begründung: Alle verpflichtenden P11-Anforderungen und automatisierten
Abnahmen sind nachgewiesen; keine Schemamigration, Datenlöschung oder
kritische durch P11 verursachte Regression ist offen. Der unabhängige lokale
Startbefund ist klar getrennt und als Voraussetzung für P12 erfasst.

## Nächster empfohlener Prompt

P12 – Zielproduktauswahl zunächst vollständig spezifizieren und anschließend
ausführen. `OFF-026` muss als notwendige Voraussetzung innerhalb desselben
Arbeitspakets bearbeitet werden. P12 wurde nicht begonnen.

