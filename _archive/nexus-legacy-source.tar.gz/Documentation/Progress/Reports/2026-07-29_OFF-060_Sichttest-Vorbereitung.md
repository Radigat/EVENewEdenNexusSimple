# OFF-060 – Sichtbarer Eigentümertest mit Jita und geänderter Marktquelle

Datum: 2026-07-29

Status: 🔄 vorbereitet; realer Eigentümer-Sichttest offen

Review: ⚠️ Technik bestanden, Betriebsnachweis offen

## Ziel und Ausgangszustand

P58 war technisch umgesetzt. Für die verlangte sichtbare Abnahme fehlten in
der Kostenansicht jedoch eindeutige Angaben zu Herkunft und Zeitstand der
Quotes sowie sichtbare Marge und ROI.

## Änderungen

- Jita- und Alternativquote zeigen Marktname, Live-/Cache-/Fallbackherkunft,
  Beobachtungszeit, Mengenabdeckung, Orderzahl und Preisregel,
- Cacheablauf und Quote-Warnungen erscheinen, soweit vorhanden,
- Marge und ROI stehen bei den Kostenkennzahlen,
- der Architekturtest fordert diese sichtbaren Angaben.

Es wurden keine produktiven Chargen, Preise oder Snapshots geschrieben und
keine vorhandenen Benutzeränderungen verworfen.

## Build und Tests

- 18/18 fokussierte SwiftPM-Tests bestanden,
- Apple-Development-signierter Xcode-Debugbuild:
  `/private/tmp/NewEdenNexus-OFF060-DerivedData/Build/Products/Debug/NewEdenNexus.app`,
- Build-Ergebnis: `BUILD SUCCEEDED`,
- unmittelbar vorheriger vollständiger P58-Lauf: 704/704 bestanden,
- nach der reinen UI-/Architekturtestkorrektur wurde die Vollsuite nicht
  erneut ausgeführt.

## Review und offene Abnahme

Quellcode, fokussierte Tests und Build wurden geprüft. Die native
macOS-Steuerverbindung der Codex-Sitzung schloss vor der App-Zustandsabfrage;
deshalb wurde kein Eigentümerergebnis erfunden.

OFF-060 bleibt offen, bis der Eigentümer in einer realen Charge:

1. eine Jita-Vorschau mit Herkunft, Zeitstand und Kennzahlen prüft,
2. eine andere benannte öffentliche Marktquelle wählt und erneut prüft,
3. die Vorschau verwirft und bestätigt, dass kein Snapshot geschrieben wurde,
4. nur bei gewünschtem Ergebnis eine neue Vorschau ausdrücklich speichert.

P58 bleibt bis dahin `⚠️`. P59 wurde nicht begonnen und startet nur auf
ausdrücklichen Auftrag. Es erfolgte kein Commit.
