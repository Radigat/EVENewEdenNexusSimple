# Abschlussbericht – P29 Kosten, Gewinn und ROI

Datum: 2026-07-26  
Prompt-ID: P29  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel und Ausgangszustand

Der vorhandene Produktions-/Inventionsplan und lokale Preisprofile sollten
zu einer erklärbaren Projektwirtschaftlichkeit verbunden werden. Vor P29
fehlten zentrale Kennzahlen und eine projektbezogene Kostenbasis.

## Durchgeführte Änderungen

- Cash- und wirtschaftliche Materialkosten getrennt,
- Lagerbestand wirtschaftlich bewertet, ohne neuen Cash-Abfluss zu erfinden,
- manuelle Jobkosten ergänzt,
- erwarteten Erlös, Gewinn, Marge, ROI und Break-even berechnet,
- Geldwerte als geprüfte `Int64`-Hundertstel und Prozentwerte auf einen
  Basispunkt gerundet,
- fehlende Preise vollständig sichtbar und blockierend behandelt,
- Vorschau, erneute Preisprüfung, Bestätigung und Stale-State-Schutz
  implementiert,
- Produktionsworkspace um Preisprofil, Jobkosten und Kennzahlen erweitert,
- Schema v18, Migration und Backupformat 18.0.0 ergänzt.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProjectEconomics.swift`
- `Sources/NewEdenNexusApplication/ProjectEconomics.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV18.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProjectEconomicsRepository.swift`
- vier P29-Testdateien
- `Documentation/PROJECT_ECONOMICS.md`
- `Documentation/Architecture/ADRs/ADR-0035_Reproduzierbare-Projektwirtschaftlichkeit-und-Schema-v18.md`

## Geänderte Dateien

Produktionsworkspace/-ViewModel/-Composition, Migrationsplan,
Containerfactory, Backupdienst/-tests, Xcode-Projekt und
Pflichtdokumentation.

## Gelöschte oder verschobene Dateien

Keine. P30/P31 wurden nicht implementiert.

## Architektur- und Datenmodellentscheidung

Die Domain berechnet deterministisch ohne UI/Persistenz. Der
Application-Service verbindet aktuellen P26-Plan und P27-/P28-Preise.
Persistiert werden nur Preisprofilwahl und manuelle Jobkosten; Ergebniszahlen
werden immer neu erzeugt. Schema v18 ergänzt genau eine Konfiguration je
Projekt. Details:
[ADR-0035](../../Architecture/ADRs/ADR-0035_Reproduzierbare-Projektwirtschaftlichkeit-und-Schema-v18.md).

## Build- und Testergebnis

- SwiftPM Debug: erfolgreich,
- Xcode Debug, macOS arm64, Signing deaktiviert: erfolgreich,
- Projektparität: 15 Targets, sieben Testtargets, zwei Schemes,
- 22 fokussierte Prüfungen bestanden,
- 473/473 SwiftPM-Debugtests bestanden, 0 übersprungen,
- 473/473 Xcode-Debugtests bestanden, 0 übersprungen.

## Manuelle Prüfungen

Das erzeugte App-Bundle wurde mit einem isolierten Store gestartet. Der
Prozess blieb lauffähig, die Schema-v18-Tabelle war vorhanden und
`PRAGMA integrity_check` meldete `ok`. Ein visueller GUI-/VoiceOver-Test
wurde nicht durchgeführt und wird nicht behauptet.

## Gefundene und behobene Probleme

- Backup-Zukunftsfixture nach Schemaerhöhung von 18 auf 19 korrigiert.
- Architekturtest vom aktuellen Arbeitsverzeichnis auf `#filePath`
  umgestellt, sodass SwiftPM und Xcode denselben Quellpfad prüfen.
- Post-Commit-Rückgabe so gehärtet, dass ein später Task-Abbruch keinen
  bereits gespeicherten Vorgang als fehlgeschlagen meldet.

## Bekannte Probleme und offene Anforderungen

Kein kritischer oder hoher P29-Fehler ist offen. P30/P31 bleiben für
persistente Einkaufsbearbeitung, gekauft-Markierung und Export offen.
Gebühren, Steuern, SCI, Live-Märkte und reale Finanzen bleiben verschoben.

## Abweichungen vom Projektbuch

Das Projektbuch beschreibt zusätzlich Gebühren, Steuern, SCI, Transport,
historische und realisierte Gewinne. P29 setzt diese ohne belegte Eingaben
nicht als Nullwerte an. Es verwendet ausschließlich die für den reduzierten
MVP vorhandenen Preise, Mengen und manuellen Jobkosten.

## Abnahmekriterien und Review

Formeln, Rundung, Verlust-/Nullfälle, fehlende Preise, Vorschau/Bestätigung,
Stale-State, Migration, Backup, UI, Builds, Tests und Dokumentation sind
nachgewiesen.

Reviewentscheidung: **✅ bestanden.**

## Nächster empfohlener Prompt

**P30 – Erweiterte Einkaufslisten-Aggregation vollständig spezifizieren und
ausführen.**
