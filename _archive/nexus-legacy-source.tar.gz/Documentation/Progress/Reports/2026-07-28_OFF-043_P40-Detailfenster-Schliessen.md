# OFF-043 – P40-Detailfenster schließen

Datum: 2026-07-28  
Prompt: P52/P40-1  
Status: ✅ technisch und live bestanden  
Review: ✅ bestanden

## Ziel und Ausgangszustand

Der Projekteigentümer bestätigte den P40-1-Datenpfad für Assets,
Blueprints und Industry Jobs. Das modale Detailfenster zeigte jedoch keinen
Schließen-Button.

## Änderung

`ESIPersonalDataDetailView` besitzt nun rechts im Kopf einen sichtbaren
Button **Schließen**. Er beendet das Sheet über Swifts
Dismiss-Umgebung und ist zusätzlich über Escape erreichbar. Fachlogik,
Snapshots, Lager, Projekte und Persistenz wurden nicht verändert.

Ein Architekturtest schützt Beschriftung und Tastaturkurzbefehl.

## Prüfung

- fokussierter Architekturtest: **1/1 bestanden**,
- vollständige SwiftPM-Suite: **650/650 bestanden**, 0 Fehler,
- Xcode Debug, Scheme `NewEdenNexus`, Ziel macOS arm64,
  Apple-Development-signiert: **BUILD SUCCEEDED**,
- erwartete nicht blockierende Warnung: AppIntents-Metadatenextraktion
  mangels AppIntents-Abhängigkeit übersprungen.

## Datenwirkung, Review und Abschluss

Keine Daten-, Schema-, Token- oder Migrationswirkung. Der tatsächliche Diff,
Testausgaben und Build wurden geprüft. Der Projekteigentümer bestätigte den
sichtbaren Schließen-Button anschließend im neuen Build.

Reviewentscheidung: **✅ bestanden**. OFF-043/KI-046 sind geschlossen.
Nächster Schritt: P40-2, schreibfreier Neustart-/Offline-Nachweis.
