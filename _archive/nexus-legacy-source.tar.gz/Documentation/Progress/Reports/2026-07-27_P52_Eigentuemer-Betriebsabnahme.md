# P52 – Eigentümer-Betriebsabnahme, Zwischenbericht

Status: ⚠️ angehalten  
Datum: 2026-07-27

## Ziel und Ausgangszustand

Die P40-/P41-/P42-Livepfade sollten im lokalen Eigentümerbetrieb kontrolliert
mit Vorschau vor jeder Übernahme geprüft werden. P50 und P51 waren technisch
abgenommen; der produktive Datenlauf stand aus.

## Durchgeführte Prüfungen

- Git- und Storezustand ohne Verwerfen vorhandener Änderungen geprüft.
- Vor der Migration ein lokales Backup erzeugt und dessen SQLite-Integrität
  bestätigt; der Store wurde leer und konsistent von Schema v20 auf v24
  migriert.
- SwiftPM-Vollsuite und signierten lokalen Xcode-Debugbuild ausgeführt.
- Eigentümer bestätigte Migration, Owner-Contact und den ersten SSO-Lauf mit
  genau drei persönlichen Produktions-Lesescopes.
- Erster PKCE-Login sowie Trennen funktionierten.
- Zugangserneuerung, öffentliche Charakterdaten, persönliche Inspect-Daten
  und der getrennt bestätigte Wallet-Inspect wurden ohne Apply geprüft.

## Laufzeitbefund und Ursache

Die redigierten Diagnosegründe zeigen zwei getrennte Grenzen:

- `token_exchange_http_400` bei Refresh und privaten Inspect-Pfaden,
- `owner_contact_missing` bei öffentlichen ESI-Pfaden.

Der technische Kontrolltest des aktuellen Form-Encoders ergibt für das rein
synthetische Token `ab+c/d==` den Body
`refresh_token=ab+c/d%3D%3D`. Ein literales `+` ist damit nicht als `%2B`
geschützt und kann nach den Regeln von
`application/x-www-form-urlencoded` als Leerzeichen dekodiert werden. Das
erklärt, warum der erste PKCE-Codeaustausch funktioniert, der gespeicherte
Refresh-Token später aber von CCP mit HTTP 400 abgelehnt wird. Die bisherige
Testfixture `existing` deckte reservierte Tokenzeichen nicht ab.
[CCP weist für SSO ausdrücklich auf die notwendige URL-Codierung hin.](https://developers.eveonline.com/blog/technical-note-dont-forget-to-url-encode-your-query-params)

Die Owner-Contact-Angabe wurde außerhalb des Appprozesses vorbereitet. Ihre
Lesbarkeit durch die signierte App ist nicht nachgewiesen; der produktive
Weg muss über die App selbst gespeichert und nach Neustart geprüft werden.

## Build- und Testergebnis

- SwiftPM Debug: **631/631 Tests bestanden**, 0 Fehler.
- Xcode Debug, macOS arm64, lokaler signierter isolierter Build:
  **BUILD SUCCEEDED**; strikte Signaturprüfung bestanden.
- Manueller Livebetrieb: **nicht bestanden** wegen KI-043.

## Datenwirkung und Datenschutz

Keine persönliche ESI-, Wallet- oder Marktvorschau wurde übernommen. Keine
Projekt-, Lager-, Preis- oder Walletzuordnung wurde geschrieben. Tokens,
Kontaktdaten, Charaktername, Walletwerte und Rohantworten sind nicht im
Bericht enthalten. Vorhandene Benutzeränderungen blieben erhalten; kein
Commit oder Push.

## Review und Abnahme

Review: **⚠️ mit Einschränkungen, P52 nicht bestanden**.

Erfüllt sind Vorprüfung, Backup, Build, automatisierte Tests, Scope-Gates,
redigierte Diagnose und Abbruch vor Datenübernahme. Nicht erfüllt sind
Refresh, P40-/P41-/P42-Livevorschauen, Apply-Gates, Neustart-/Offlineprüfung
und konsistenter Endzustand der vollständigen Betriebsabnahme.

## Offene Punkte und nächster Schritt

OFF-040/KI-043 wird als begrenzte P51-Nachkorrektur bearbeitet:
RFC-konforme Formularcodierung, Rotationstest, sichere Fehlerdiagnose und
Owner-Contact-Nachweis über den App-Keychainpfad. Danach wird P52 nur nach
erneuter ausdrücklicher Eigentümerfreigabe fortgesetzt. P53 wurde nicht
begonnen.
