# Abschlussbericht – P08: Statisches Datenschema

## Prompt-ID und Ziel

**P08 – Statisches Datenschema vollständig spezifizieren und ausführen**

Ziel war, das validierte P07-Stagingpaket fachlich zu mappen und
Kategorien, Gruppen, Typen, Blueprints, Aktivitäten, Materialien und Produkte
versioniert, referenzgeprüft und atomar aktivierbar in SwiftData zu speichern.

## Ausgangszustand

- `NexusSchemaV1` 1.0.0 enthielt nur Charakter und Projekt.
- P07 validierte und staged vier JSONL-Dateien.
- Kein fachliches Feldmapping, keine statischen Entitäten und keine Aktivierung.
- Kein Test mit einem aktuellen offiziellen SDE-Archiv.
- Backupmanifeste waren an Schema 1.0.0 gebunden.

## Durchgeführte Änderungen

- P08 mit verbindlichem Feldmapping, Index-, Referenz-, Migrations- und
  Aktivierungsregeln vollständig spezifiziert.
- Application-Snapshots und zentrale Kataloginvarianten implementiert.
- Mapper- und Repository-Ports sowie `ImportStaticDataUseCase` ergänzt.
- `.nensde`-Manifest, Dateien und Hashes vor Mapping erneut geprüft.
- Kategorien, Gruppen, Typen und Blueprints blockweise fachlich gemappt.
- sechs Aktivitätsarten, Materialien, Produkte, Zeiten und
  Wahrscheinlichkeiten abgebildet.
- `NexusSchemaV2` 2.0.0 und additive Migration v1 → v2 implementiert.
- acht statische SwiftData-Entitäten mit eindeutigen versionsgebundenen
  Lookup-Schlüsseln ergänzt.
- atomare Aktivierung, Rollback, Idempotenz, Buildkonflikt und Erhalt alter
  Versionen umgesetzt.
- Backup-Schemaversion auf 2.0.0 aktualisiert; 1.0.0 bleibt migrierbar.
- sichere Fehleroperationen `NEN-SDE-003` und `NEN-SDE-004` ergänzt.
- synthetische SDE-Fixture um Manufacturing, Invention und Reaction erweitert.
- offiziellen Build 3424810 temporär end-to-end geprüft.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/StaticDataCatalog.swift`
- `Sources/NewEdenNexusInfrastructure/JSONLinesSDECatalogMapper.swift`
- `Sources/NewEdenNexusInfrastructure/SDEContentHash.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV2.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataStaticDataCatalogRepository.swift`
- `Tests/NewEdenNexusInfrastructureTests/JSONLinesSDECatalogMapperTests.swift`
- `Tests/NewEdenNexusPersistenceTests/StaticDataCatalogRepositoryTests.swift`
- `Tests/NewEdenNexusPersistenceTests/OfficialSDEPersistenceIntegrationTests.swift`
- `Documentation/Architecture/ADRs/ADR-0008_Versionierter-SDE-Stammdatenkatalog.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusInfrastructure/JSONLinesSDEImportService.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV1.swift`
- `Sources/NewEdenNexusPersistence/NexusMigrationPlan.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexusPersistence/SQLiteLocalBackupService.swift`
- bestehende Application-, Infrastructure-, Persistence- und Backup-Tests,
- synthetische SDE-Fixture und Fixturemanifest,
- P08-Prompt und alle verpflichtenden Status-, Architektur-, Datenmodell-,
  Test-, Aufgaben-, Problem- und Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine. Es wurde kein funktionierender Benutzer- oder Produktionscode gelöscht.
Die Typealiases wurden lediglich vom Schema-v1- an den aktuellen
Schema-v2-Rand verschoben.

## Architekturentscheidungen

- statische Datenstände sind unveränderlich und über den Inhalts-SHA
  versioniert,
- zusammengesetzte `identityKey`s bilden eindeutige exakte Lookup-Indizes,
- Mapping und vollständige Validierung erfolgen vor dem ersten Schreibzugriff,
- Datensätze und Aktivmarker werden in demselben Save veröffentlicht,
- alte Versionen bleiben als Rückfallstand erhalten,
- gleiches Paket ist idempotent, gleiche Buildnummer mit anderem Inhalt ist
  ein Konflikt,
- Application bleibt datei-, CryptoKit-, SwiftData- und UI-frei,
- Details stehen in ADR-0008.

## Datenmodelländerungen

Neue Schemaversion 2.0.0:

- `StaticDataVersion`
- `ItemCategory`
- `ItemGroup`
- `ItemType`
- `BlueprintDefinition`
- `BlueprintActivity`
- `BlueprintMaterial`
- `BlueprintProduct`

Bestehende Charakter- und Projektfelder bleiben unverändert. Die Migration
1.0.0 → 2.0.0 ist additiv und als Lightweight-Migration registriert.

## Offizieller Realstand

Der aktuelle offizielle Tranquility-JSONL-Build 3424810 wurde temporär,
außerhalb des Repositorys und ohne produktive Benutzerdaten geprüft:

| Datentyp | Anzahl |
|---|---:|
| Kategorien | 48 |
| Gruppen | 1.605 |
| Typen | 52.743 |
| Blueprints | 5.082 |
| Aktivitäten | 19.137 |
| Materialien | 36.499 |
| Produkte | 6.329 |
| nicht aufgelöste Typreferenzen | 21 |

Der Lauf deckte gültige IDs `0`, gültige Aktivitätszeiten `0` und 21
Blueprintreferenzen ohne Typdatensatz auf. IDs und Zeiten wurden fachlich
korrigiert. Fehlende Typen werden nicht erfunden; die Originalzeilen bleiben
mit `typeIsResolved == false` und Versionszähler erhalten.

## Build-Ergebnis

Ausgeführt:

```bash
./Scripts/ci-verify.sh
```

Ergebnis:

- Packagegraph erfolgreich beschrieben,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen im erfolgreichen Abschlusslauf.

## Testergebnis

- Debug mit Coverage: 83 Tests, 0 Fehler, 0 unerwartete Fehler.
- Release: 83 Tests, 0 Fehler, 0 unerwartete Fehler.
- keine übersprungenen XCTest-Tests.
- offizieller SDE-E2E-Test: 1 Test, erfolgreich, 18,765 Sekunden.

Coverage:

- alle instrumentierten Dateien: 77,90 %,
- produktive Sources: 64,14 %,
- Katalogsnapshot: 81,97 %,
- JSONL-Mapper: 82,42 %,
- Aktivierungsrepository: 93,26 %.

## Manuelle Prüfungen

- aktueller offizieller Archivendpunkt und HTTP-Metadaten geprüft,
- Archivinhalt und reale Feldformen der vier Pflichtdateien geprüft,
- reale Aktivitätsschlüssel und Datenmengen ermittelt,
- 21 fehlende Typreferenzen unabhängig gegen `types.jsonl` verglichen,
- Git-Wurzel, Branch und untracked Benutzerstand erneut geprüft,
- kein offizieller SDE-Inhalt im Repository,
- nichts gestaged, committed oder gepusht.

Keine GUI-Prüfung war anwendbar, da P08 keine Ansicht einführt.

## Bekannte Probleme

- `OFF-016`/`KI-016`: P10 muss 21 nicht aufgelöste Referenzen beim
  Rezeptzugriff sichtbar ablehnen.
- Namenssuche und Katalogabfragen fehlen bis P09.
- SDE-Skillanforderungen und Marktgruppenstammtabelle sind nicht gespeichert.
- Rotation alter SDE-Stände und Performancebudgets fehlen.
- automatische `beforeMigration`-Sicherung und Recovery-Drill fehlen bis P36.
- eigenständiges Xcode-Projekt/Scheme fehlt; SwiftPM ist geprüft.

## Offene Anforderungen

- P09: aktiver Item-/Blueprintkatalog, ID-Lookup, Suche, Pagination.
- P10: deterministischer Rezeptresolver und Umgang mit nicht aufgelösten
  Referenzen.
- P34: Messbudgets und große Datenstände.
- P36: automatische Vor-Migrations-Sicherung und Recovery.

## Abweichungen vom Projektbuch

- Blueprintaktivität ist normalisiert als eigene Entität gespeichert, weil ein
  Blueprint mehrere Aktivitäten und Produkte besitzen kann.
- `Double` bildet optionale SDE-Gleitkommawerte ab; Geldberechnungen verwenden
  später weiterhin fachlich geeignete Dezimalregeln.
- SwiftData-Skalarreferenzen werden vor dem Schreiben zentral geprüft, statt
  alle SDE-Beziehungen als Objektgraph zu materialisieren.
- Fehlende offizielle Material-/Produkt-Typreferenzen werden als
  Auflösungsstatus erhalten, nicht durch erfundene Items geschlossen.
- Skillanforderungen und Marktgruppenentität sind bewusst nicht Teil von P08.

Diese Abweichungen sind in ADR-0008 dokumentiert.

## Erfüllte Abnahmekriterien

- [x] P08 vollständig spezifiziert.
- [x] Schema v2 und additive Migration implementiert.
- [x] Feldmapping und Invarianten implementiert.
- [x] eindeutige versionsgebundene Lookup-Schlüssel.
- [x] atomare, idempotente Aktivierung mit Rückfallstand.
- [x] v1- und Legacy-Migrationspfade geprüft.
- [x] Backupkompatibilität aktualisiert und getestet.
- [x] synthetische Debug-/Release-Gesamttests erfolgreich.
- [x] offizieller Realstand gemappt, gespeichert und erneut geöffnet.
- [x] Pflichtdokumentation und ADR aktualisiert.
- [x] gesonderter Review bestanden.

## Nicht erfüllte Abnahmekriterien

Keine innerhalb des vollständig spezifizierten P08-Umfangs.

## Reviewentscheidung

**✅ bestanden**

Der gesonderte Review prüfte den vollständigen P08-Quellcode, Targetgrenzen,
Schema- und Migrationswirkung, Aktivierung und Rollback, offizielle
Realbefunde, Backupkompatibilität, Debug-/Release-Ausgaben, Coverage,
Dokumentation und Git-Sicherheit.

Die drei wesentlichen Reviewbefunde – ID `0`, Zeit `0` und nicht aufgelöste
offizielle Referenzen – wurden vor Abschluss korrigiert beziehungsweise
explizit modelliert und mit Regressionstests abgesichert. Keine offene
kritische oder hohe P08-Regression.

## Nächster empfohlener Prompt

**P09 – Item- und Blueprintkatalog vollständig spezifizieren und ausführen.**
