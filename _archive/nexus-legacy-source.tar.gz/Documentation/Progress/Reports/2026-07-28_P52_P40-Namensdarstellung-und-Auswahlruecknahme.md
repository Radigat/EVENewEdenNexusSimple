# P52/OFF-044 – P40-Namensdarstellung und Auswahlrücknahme

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden; Eigentümer-Livetest offen  
Review: ⚠️ mit Einschränkung bestanden

## Ziel und Ausgangszustand

P40-3 wurde nach Anlage eines Referenzprojekts mit Vorschau und Verwerfen
live bestanden. Eine weitere Auswahl wurde unbeabsichtigt übernommen.
Persönliche Asset-, Blueprint-, Vorschau- und Jobansichten zeigten
technische IDs statt fachlicher Namen.

## Änderungen

- Item-, Blueprint- und Produktnamen stammen aus dem aktiven SDE-Katalog.
- Aktivität, Status, Location Flag, Station/System und Ergebnis werden
  fachlich dargestellt; technische IDs sind in der normalen UI ausgeblendet.
- Der offizielle öffentliche ESI-Namensendpunkt wird tokenfrei, begrenzt und
  validiert verwendet; ein atomarer lokaler Cache erhält Namen offline.
- Private Spielerstrukturen werden ohne neuen Scope transparent generisch
  dargestellt.
- Speichern besitzt eine zweite Bestätigung.
- Eine gespeicherte Projekt-Asset-Auswahl kann nach detaillierter
  Rücknahmevorschau, Stale-Prüfung und ausdrücklicher Bestätigung gezielt
  gelöscht werden. ESI-Snapshot und manuelle/CSV-Bestände bleiben erhalten.
- Keine Schema- oder automatische Benutzerdatenänderung.

Neue Dateien:

- `Sources/NewEdenNexusApplication/ESILocationNames.swift`
- `Sources/NewEdenNexusInfrastructure/ESILocationNameClient.swift`
- zugehörige Application-/Infrastructure-Tests
- `Documentation/Architecture/ADRs/ADR-0050_Semantische-ESI-Namen-und-reversible-Asset-Auswahl.md`

Weitere Änderungen betreffen App-Composition, ViewModel, persönliche
Detail-/Vorschauansichten, Asset-Auswahlservice und -Repository, das
kanonische Xcode-Projekt sowie die kompakten Statusdokumente.

## Datenwirkung und Sicherheit

Die Korrektur schrieb oder entfernte keine produktiven Benutzerdaten.
Ortsnamen sind abgeleitete Cachewerte. Rücknahme löscht ausschließlich die
projektbezogene ESI-Asset-Auswahl und erst nach Vorschau, unverändertem
Stand und Bestätigung. Kein Scope wurde ergänzt.

## Build und Tests

- fokussiert: **18/18 bestanden**,
- vollständig: **658/658 SwiftPM-Tests bestanden**,
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64,
  Apple-Development-signiert: **BUILD SUCCEEDED**,
- `plutil -lint` und `git diff --check`: bestanden.

Verwendete offizielle CCP-Grundlagen:

- [ESI Overview](https://developers.eveonline.com/docs/services/esi/overview/)
- [ESI Best Practices](https://developers.eveonline.com/docs/services/esi/best-practices/)
- [offizielle ESI-OpenAPI-Spezifikation](https://esi.evetech.net/meta/openapi.json)

## Reviewentscheidung und offene Punkte

Diff, Schichtengrenzen, Datenwirkung, Tests, Build und Dokumentation wurden
gesondert geprüft. Keine technische Regression ist offen. Die Entscheidung
bleibt `⚠️ mit Einschränkung bestanden`, bis:

1. der Eigentümer die semantischen Namen und ausgeblendeten IDs im neuen
   Build sichtbar bestätigt,
2. die unbeabsichtigte Auswahl über die Rücknahmevorschau ausdrücklich
   entfernt und der unveränderte ESI-Snapshot bestätigt wurde.

Exakte Namen privater Spielerstrukturen bleiben OFF-045 und dürfen nur nach
einer ausdrücklichen Entscheidung über den zusätzlichen Lesescope ergänzt
werden. P40-4 folgt danach als neues, bewusst freigegebenes Gate.
