# Abschlussbericht – P10 Rezept- und Aktivitätsresolver

Datum: 2026-07-23  
Prompt-ID: P10  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Fertigungs- und Reaktionsrezepte aus genau einer aktiven SDE-Version
deterministisch auflösen. Fehlende, mehrdeutige, unzulässige oder
referenziell unvollständige Rezepte dürfen niemals eine scheinbar
vollständige Materialliste erzeugen. `OFF-003`, `OFF-016`, `KI-004` und
`KI-016` waren verbindlicher Bestandteil.

## Ausgangszustand

P08/P09 importierten und erschlossen Blueprintaktivitäten, Materialien und
Produkte versionsisoliert. Es gab jedoch keinen fachlichen Resolver. Der
offizielle Build 3444265 enthielt 21 gespeicherte, ausdrücklich als nicht
aufgelöst markierte Typreferenzen.

Die uncommitteten P09B-Projekt- und Dokumentationsänderungen lagen bereits im
Arbeitsbaum. Sie wurden erhalten, nicht verworfen und nur dort ergänzt, wo
P10 die gemeinsame Xcode-Konfiguration benötigte. Es wurde weder committed
noch gepusht.

## Durchgeführte Änderungen

### Application

- `RecipeCandidateReading` als Persistenzport,
- `RecipeReferenceAuditing` für vollständige aktive Referenzaudits,
- sendbare Kandidaten-, Ergebnis- und Diagnosetypen,
- `ResolveRecipeUseCase` für `manufacturing` und `reaction`,
- typisierte Fehler für ungültige IDs, nicht unterstützte Aktivitäten,
  fehlende, falsche und mehrdeutige Rezepte, Referenzlücken,
  Kandidateninkonsistenzen und Katalogfehler,
- sichere Diagnosecodes `NEN-RECIPE-001` bis `NEN-RECIPE-004`,
- zentrale Fehlergrenze `NEN-SDE-008`.

### Persistence

`SwiftDataItemBlueprintCatalog` liest vollständige Kandidaten und
Referenzlücken ausschließlich aus genau einer aktiven `StaticDataVersion`.
Kandidaten enthalten Blueprint-/Produktveröffentlichung, Zeiten,
Produktionslimit, Materialien und sämtliche Produkte. Persistenzmodelle
verlassen den Adapter nicht.

### Auswahl- und Validierungsregeln

- explizite Blueprint-ID muss exakt passen,
- ohne Auswahl ist genau ein Kandidat erforderlich,
- mehrere Kandidaten werden stabil gemeldet und nicht automatisch
  priorisiert,
- Blueprint und Zielprodukt müssen veröffentlicht sein,
- Materialliste darf bei Fertigung/Reaktion nicht leer sein,
- Mengen und Produktionslimit müssen positiv, Zeiten/Sortierwerte nicht
  negativ sein,
- probabilistische Ausgaben werden nicht als deterministisches Rezept
  akzeptiert,
- jede nicht aufgelöste Material- oder Produktreferenz blockiert das gesamte
  Rezept vor weiteren Veröffentlichungs-/Mengenprüfungen.

### Abnahmerunner

Der bestehende opt-in Runner prüft nun zusätzlich:

- Rifter-Fertigungsrezept über Produkt 587 und Blueprint 691,
- ein vollständiges Reaktionsrezept aus dem aktiven Katalog,
- vollständigen Audit aller Referenzlücken,
- itemgenaue Ablehnung jedes betroffenen Rezepts,
- Wiederöffnung, Backup und vollständiges Cleanup.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/RecipeResolution.swift`
- `Tests/NewEdenNexusApplicationTests/RecipeResolutionTests.swift`
- `Tests/NewEdenNexusPersistenceTests/RecipeResolutionPersistenceTests.swift`
- `Documentation/RECIPE_RESOLUTION.md`
- `Documentation/Architecture/ADRs/ADR-0014_Deterministischer-Rezeptresolver.md`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataItemBlueprintCatalog.swift`
- `Sources/NewEdenNexusSDEAcceptance/main.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `project.yml` und daraus regeneriertes `NewEdenNexus.xcodeproj`
- Architektur-, Datenmodell-, Katalog-, Prompt-, Status-, Aufgaben-,
  Problem-, Test- und Fortschrittsdokumentation

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

ADR-0014 legt Application als Ort der Fachauswahl fest. Persistence liefert
nur versionsisolierte Daten. Unvollständige Referenzen werden nicht
repariert, gefiltert oder buildübergreifend ergänzt. Mehrdeutige Kandidaten
benötigen eine explizite Auswahl.

## Datenmodelländerungen

Keine neue SwiftData-Schemaversion und keine Migration. P10 ergänzt
ausschließlich read-only Application-Verträge und Adapterabfragen.
Produktive Benutzerdaten wurden nicht geöffnet oder verändert.

## Build-Ergebnis

Erfolgreich:

- SwiftPM Debug und Release,
- Xcode `NewEdenNexus` Debug und Release,
- Xcode `NewEdenNexusSDEAcceptance` Debug und Release,
- statischer Xcode-/SwiftPM-Paritätscheck: 15 Targets, sieben Testtargets,
  zwei gemeinsame Schemes.

Der erste Xcode-Release-Testlauf scheiterte reproduzierbar mit Exitcode 65,
weil die generierten Release-Module für vorhandene `@testable`-Importe nicht
testbar waren. `ENABLE_TESTABILITY = YES` wurde in `project.yml` gesetzt,
das Projekt regeneriert und sämtliche Abschlussläufe erfolgreich wiederholt.

## Testergebnis

- neun Application-Resolvertests: bestanden,
- fünf Persistence-Resolvertests: bestanden,
- SwiftPM Debug: 181/181 bestanden,
- SwiftPM Release: 181/181 bestanden,
- Xcode Debug: 181/181 bestanden,
- Xcode Release: 181/181 bestanden,
- keine Fehler, keine übersprungenen Tests.

Geprüft wurden eindeutige Fertigung/Reaktion, explizite Auswahl,
Nichtfund/Mehrdeutigkeit, nicht produktive Aktivitäten, Veröffentlichung,
leere/ungültige Mengen, Wahrscheinlichkeit, Produktionslimit,
Versionsisolation, keine/mehrere aktive Versionen, Referenzlücken,
Persistenzfehler, Cancellation und Wiederholbarkeit.

## Manueller und offizieller Funktionstest

Der abschließende isolierte Release-Lauf verwendete den am 2026-07-23
offiziell gemeldeten Build `3444265`.

- Inhaltshash:
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`
- Kategorien: 48
- Gruppen: 1.609
- Itemtypen: 52.821
- Blueprints: 5.082
- Aktivitäten: 19.137
- Materialien: 36.499
- Produkte: 6.329
- Referenzlücken: 21
- Fertigungsrezept: aufgelöst
- Reaktionsrezept: aufgelöst
- alle Referenzlücken blockiert: ja
- Backup/Wiederöffnung/Cleanup: erfolgreich
- Dauer: 46,556 Sekunden

### Itemgenaue Referenzlücken

| Blueprint | Aktivität | Rolle | fehlende Type-ID | Code |
|---:|---|---|---:|---|
| 3927 | manufacturing | material | 3924 | NEN-RECIPE-001 |
| 37398 | manufacturing | product | 37236 | NEN-RECIPE-001 |
| 37399 | manufacturing | product | 37237 | NEN-RECIPE-001 |
| 37400 | manufacturing | product | 37238 | NEN-RECIPE-001 |
| 37401 | manufacturing | product | 37239 | NEN-RECIPE-001 |
| 37402 | manufacturing | product | 37240 | NEN-RECIPE-001 |
| 37403 | manufacturing | product | 37241 | NEN-RECIPE-001 |
| 37404 | manufacturing | product | 37242 | NEN-RECIPE-001 |
| 37405 | manufacturing | product | 37243 | NEN-RECIPE-001 |
| 37406 | manufacturing | product | 37244 | NEN-RECIPE-001 |
| 37407 | manufacturing | product | 37245 | NEN-RECIPE-001 |
| 37408 | manufacturing | product | 37286 | NEN-RECIPE-001 |
| 37409 | manufacturing | product | 37247 | NEN-RECIPE-001 |
| 37425 | manufacturing | product | 37262 | NEN-RECIPE-001 |
| 37426 | manufacturing | product | 37263 | NEN-RECIPE-001 |
| 37427 | manufacturing | product | 37264 | NEN-RECIPE-001 |
| 37428 | manufacturing | product | 37265 | NEN-RECIPE-001 |
| 37429 | manufacturing | product | 37266 | NEN-RECIPE-001 |
| 37430 | manufacturing | product | 37267 | NEN-RECIPE-001 |
| 37441 | manufacturing | product | 37278 | NEN-RECIPE-001 |
| 37442 | manufacturing | product | 37279 | NEN-RECIPE-001 |

Die Zahl ist kein fest codierter Sollwert. Künftige aktive Builds werden
erneut vollständig gezählt.

## Bekannte Probleme und Risiken

- Der Quelldatenbefund der 21 fehlenden Itemtypen bleibt bestehen; P10
  verhindert dessen unsichere Nutzung.
- Mehrere gültige Blueprints benötigen eine explizite Auswahl.
- Runs, ME, Graph, T1/T2 und Reaktionsketten sind bewusst nicht Teil von
  P10.
- Unabhängige Schulden für P34, P36 und P37 bleiben offen.

## Offene Anforderungen

- P11 Projektlebenszyklus,
- P12 kataloggestützte Zielproduktauswahl,
- P13–P19 Produktionsgraph und Mengenberechnung.

## Abweichungen vom Projektbuch

Keine unbegründete Abweichung. Der reduzierte MVP und P10 begrenzen den
Resolver bewusst auf deterministische Fertigung und Reaktion. Invention und
spätere Berechnungsstufen werden nicht vorgezogen.

## Abnahmekriterien

| Kriterium | Ergebnis |
|---|---|
| eindeutige Fertigung und Reaktion vollständig aufgelöst | ✅ |
| explizite Auswahl und stabile Mehrdeutigkeit | ✅ |
| genau eine aktive SDE-Version | ✅ |
| jede unvollständige Referenz blockiert | ✅ |
| aktueller Real-SDE-Nachweis itemgenau | ✅ |
| keine Runs-/ME-/Graphlogik vorgezogen | ✅ |
| SwiftPM Debug/Release | ✅ |
| Xcode Debug/Release | ✅ |
| Dokumentation/Matrix/Tagebuch/Bericht | ✅ |
| gesonderter Review | ✅ bestanden |

## Reviewentscheidung

**✅ bestanden.** Der Review prüfte tatsächlichen Diff, Schichtengrenzen,
Fehlerverhalten, Xcode-/SwiftPM-Ergebnisse, Real-SDE-Ausgabe und
Dokumentation. Die gefundenen Lücken bei Release-Testbarkeit,
Wahrscheinlichkeitsprodukten und Produktionslimits wurden vor der
abschließenden Wiederholung aller Nachweise geschlossen.

## Nächster empfohlener Prompt

P11 – Projektlebenszyklus zunächst vollständig spezifizieren, die dafür
notwendigen offenen Punkte verbindlich übernehmen und erst anschließend
ausführen. P11 wurde in P10 nicht begonnen.
