# P41 – Nutzenreview Live-Marktpreise

Datum: 2026-07-26  
Status: **✅ Nutzenreview abgeschlossen · P41 nicht begonnen**

## Entscheidung

**Bedingtes Go** für einen reduzierten P41-Umfang. Der hohe praktische Nutzen
liegt in aktuellen Material-Beschaffungspreisen für Build-or-Buy, Einkauf und
Wirtschaftlichkeit. Ein vollständiger Marktclient ist für die lokale
Produktionsplanung derzeit nicht wirtschaftlich.

## Geprüfter Ausgangszustand

- P27/P28: manuelle und CSV-basierte Preisprofile sind vorhanden.
- P29: ein gemeinsames Preisprofil versorgt Materialkosten und Zielerlös.
- P39: HTTP-Cache-, Rate-Limit-, Offline- und Fehlergrenzen sind
  wiederverwendbar.
- P40: persönliche ESI-Synchronisation ist getrennt; Marktorders sind
  öffentliche Daten und benötigen keinen zusätzlichen SSO-Scope.
- `OFF-021`: Zusätzliche SDE-Daten bleiben bedarfsgesteuert.

## Empfohlener erster Umfang

- öffentliche regionale ESI-Orders nur für benötigte Type-IDs,
- optionaler benutzerkonfigurierter Location-Filter,
- mengenbezogener Beschaffungspreis aus passenden Verkaufsorders,
- nicht persistierte Vorschau und ausdrückliche Bestätigung,
- Quelle, Zeitpunkt, Filter, Menge und Cachealter sichtbar,
- bestätigter Offline-Snapshot sowie manuelle/CSV-Werte als Fallback.

Vollständige Orderbuchspiegel, Historien, Prognosen und automatische
Erlöspreise bleiben verschoben. `/markets/prices` wird nicht als
stillschweigender Ersatz für einen aktuellen Beschaffungspreis verwendet.

## Technische und fachliche Risiken

- Ein einzelner Minimalpreis kann nur eine Kleinmenge abdecken; deshalb muss
  der Preis die benötigte Menge berücksichtigen.
- Materialkosten und erwarteter Erlös benötigen unterschiedliche Preisrollen.
  Der erste Umfang aktualisiert daher nur Beschaffungspreise.
- Regionweite Komplettabzüge wären daten- und requestintensiv; der Abruf wird
  auf die aktuelle Type-ID-Menge begrenzt.
- Veraltete oder unvollständige Daten müssen sichtbar bleiben und dürfen
  lokale Preise nicht automatisch überschreiben.

## Offizielle Grundlage

Am 2026-07-26 geprüft:

- <https://developers.eveonline.com/docs/services/esi/overview/>
- <https://developers.eveonline.com/docs/services/esi/best-practices/>
- <https://developers.eveonline.com/docs/services/esi/rate-limiting/>
- <https://esi.evetech.net/meta/openapi.json>

Der aktuelle OpenAPI-Stand beschreibt regionale Orders als öffentlichen,
Type-ID-filterbaren, paginierten Endpunkt mit ETag/Last-Modified,
fünfminütigem Cachealter und Markt-Rate-Limit-Gruppe.

## Prüfung und Abnahme

- Codeänderungen: keine
- Datenmodelländerungen: keine
- Build: nicht ausgeführt, da reine Nutzenprüfung
- Tests: nicht ausgeführt, da keine Implementierung
- Benutzeränderungen: nicht verworfen
- Commit/Push: nicht ausgeführt

Das Nutzenreview ist abgeschlossen. **P41 bleibt `⏸️ verschoben` und darf
erst auf einen ausdrücklichen Ausführungsauftrag begonnen werden.**
