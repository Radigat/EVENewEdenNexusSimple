# P42 – Wallet und reale Projektfinanzen

Datum: 2026-07-27  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel und Ausgangszustand

Der positive P42-Nutzenreview gab ausschließlich persönliche
Wallet-Lesedaten und benutzerbestätigte Projektzuordnungen frei. P40/P41,
SSO, ESI-Fehlerbehandlung und P29-Planwirtschaftlichkeit waren vorhanden;
Walletsnapshot, Istwertmodell und Zuordnungspersistenz fehlten.

## Durchgeführte Änderungen

- genau `esi-wallet.read_character_wallet.v1` als vierten persönlichen
  Read-Scope ergänzt,
- Kontostand, Journal und Transaktionen über offizielle Charakterrouten mit
  Cachevalidatoren, begrenzter Pagination, Retry-/Rate-Limit- und
  Offlinepfad geladen,
- privaten versionierten Wallet-Dateisnapshot mit Staging,
  Revisionsschutz, Größenlimit und restriktiven Rechten umgesetzt,
- Schema v22 additiv um bestätigte Voll-/Teilzuordnungen zu Projekten
  erweitert,
- Vorschau-vor-Schreiben, Überzuordnungs- und Stale-Schutz sowie
  kompensierbare Charaktertrennung umgesetzt,
- Planwerte und tatsächliche Kosten/Erlöse fachlich und in der UI getrennt,
- neue Fehlercodes `NEN-ESI-004`, `NEN-ESI-005` und `NEN-FIN-001` ergänzt.

Neu erstellt wurden die Wallet-Domäne, Synchronisationsservices,
ESI-/Dateiadapter, Schema-/Repositoryschicht, `WalletFinanceView`, vier
Testdateien, [Wallet-Dokumentation](../../WALLET_AND_PROJECT_FINANCE.md) und
[ADR-0047](../../Architecture/ADRs/ADR-0047_Persoenliche-Wallet-Snapshots-und-bestaetigte-Projektzuordnung.md).
Geändert wurden Composition, Account-UI/-ViewModel, Fehlergrenze,
Migrations-/Backupintegration, Xcode-Projekt und Steuerdokumentation.
Gelöscht oder verschoben wurde nichts.

## Architektur- und Datenmodellentscheidung

Der Wallet-Rohbestand bleibt als charaktergebundener privater Dateisnapshot
außerhalb von SwiftData. Nur bestätigte Zuordnungen werden in Schema v22
gespeichert. Die leichte v21→v22-Migration erhält vorhandene Benutzerdaten.
Keine Walletinformation verändert Preise, Lager, Produktionspläne oder
P29-Kennzahlen.

## Build- und Testergebnis

- `swift build`: erfolgreich.
- `swift test --filter Wallet`: 15/15 bestanden.
- `swift test`: 608/608 bestanden, 0 Fehler.
- `Scripts/verify_xcode_project.py`: 16 Targets, 8 Testtargets und
  2 gemeinsame Schemes konsistent.
- isoliertes `xcodebuild -project NewEdenNexus.xcodeproj -scheme
  NewEdenNexus -configuration Debug -destination 'platform=macOS'
  -derivedDataPath <temporär> build`: `BUILD SUCCEEDED`.

Der direkte Xcode-Aufruf im synchronisierten Repositorypfad blieb wie beim
bekannten File-Provider-/`NSFileCoordinator`-Befund ohne Fortschritt und
wurde kontrolliert beendet. Die isolierte identische Arbeitskopie baute
erfolgreich. Nicht blockierend waren die Mehrdeutigkeitswarnung für zwei
macOS-Ziele und die ausgelassene AppIntents-Metadatenextraktion.

## Manuelle Prüfungen und Datenschutz

UI-Texte erklären den neuen Scope, Vorschau, Bestätigung und Löschwirkung.
Ein produktiver Walletabruf wurde bewusst nicht ausgeführt, weil er eine
erneute persönliche SSO-Zustimmung und echte personenbezogene Daten
erfordert. Tokens, Walletrohwerte und Eigentümerkontakt wurden nicht in
Logs, Fixtures oder Dokumente übernommen.

## Offene Punkte und Abweichungen

`OFF-021` bleibt als Bedarfsgate offen; P42 benötigte keinen zusätzlichen
SDE-Datensatz. Corporation-Wallets, automatische Projektzuordnung,
vollständige Buchhaltung und Exporte bleiben ausgeschlossen. Keine
Abweichung vom freigegebenen P42-Umfang.

## Abnahmekriterien

Alle zehn Kriterien der
[P42-Spezifikation](../../Prompts/Future/P42_Wallet-Projektfinanzen.md) sind
automatisiert oder durch Build-/Dokumentationsnachweis erfüllt. Der
produktive persönliche SSO-Abruf ist kein automatisierbares
Abnahmekriterium und bleibt eine bewusste Benutzerhandlung.

## Nächster empfohlener Prompt

P43-Nutzenreview für vollständiges Reaktionsmanagement, nur auf
ausdrücklichen Auftrag.
