# P38 – SSO-Härtung

Datum: 2026-07-26  
Status: **⚠️ teilweise – technische Umsetzung bestanden, manueller Eigentümer-SSO-Lauf offen**

## Ziel und Ausgangszustand

Den vorhandenen lokalen SSO-Zukunftscode sicher und testbar in die
Schichtenarchitektur integrieren, ohne ESI-Fachdaten vorwegzunehmen. Zuvor
waren Browser, Callback, Token, Keychain, SwiftData und UI eng gekoppelt;
Claims wurden nicht vollständig kryptografisch abgenommen.

Offizielle Grundlage wurde am 2026-07-26 geprüft:
[CCP EVE SSO](https://developers.eveonline.com/docs/services/sso/) und der
offizielle OAuth-Discovery-Endpunkt. Desktop-SSO verwendet Authorization
Code mit PKCE und kein Client Secret.

## Durchgeführte Änderungen

- Auth-, Browser-, Callback-, Token-Vault-, Account-Repository- und
  Account-Management-Ports in Application ergänzt.
- Authorization Code mit PKCE S256, kryptografischem `state`, vorbereitetem
  exaktem Loopback, Timeout und Abbruch implementiert.
- OIDC-Discovery und JWKS-basierte RS256-Prüfung einschließlich Issuer,
  Audience, Ablauf, Subject/Character-ID, Name und Scopes umgesetzt.
- Refresh-Token ausschließlich im macOS-Keychain; Access-Token ohne
  Persistenz; Rotation und Identitätswechsel behandelt.
- `CharacterRecord` über ein Repository adaptiert; Verbinden/Trennen
  kompensieren Keychain-/SwiftData-Teilfehler.
- Accounts- und Synchronisationsansicht auf injiziertes ViewModel
  umgestellt; direkte SwiftData-/Keychain-Zugriffe entfernt.
- Trennen erfordert sichtbare Bestätigung und bewahrt Projekte, Lager,
  Preise und sonstige Benutzerdaten.
- Architektur-, Application-, Infrastructure- und Persistenztests ergänzt.

## Dateien

Neu:

- `Sources/NewEdenNexusApplication/EVEAuthentication.swift`
- `Sources/NewEdenNexusInfrastructure/EVESSOAuthorizationFlow.swift`
- `Sources/NewEdenNexusInfrastructure/KeychainRefreshTokenVault.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataCharacterAccountRepository.swift`
- `Sources/NewEdenNexus/AccountAppComposition.swift`
- `Sources/NewEdenNexus/AccountsViewModel.swift`
- `Tests/NewEdenNexusApplicationTests/EVEAccountConnectionServiceTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/EVESSOAuthorizationFlowTests.swift`
- `Tests/NewEdenNexusPersistenceTests/CharacterAccountPersistenceTests.swift`
- `Tests/NewEdenNexusArchitectureTests/AppSourceArchitectureTests.swift`
- `Documentation/SSO_ARCHITECTURE.md`
- `Documentation/Architecture/ADRs/ADR-0043_SSO-Ports-JWT-und-Kompensation.md`

Geändert:

- Account-/Synchronisationsviews, Runtime/Root-Composition,
  Architekturgrenztest und generiertes Xcode-Projekt,
- P38-Prompt sowie betroffene Architektur-, Status-, Feature-, Test-,
  Tagebuch-, Aufgaben-, Befund- und ADR-Übersichten.

Gelöscht:

- `Sources/NewEdenNexus/EVESSOService.swift`; durch Ports und Adapter ersetzt.

Nicht verändert: SwiftData-Schemaversion, Projekt-/Bestands-/Preis- und
Einkaufsdaten. Kein Commit oder Push.

## Architektur- und Datenentscheidung

Application bleibt frameworkneutral; AppKit, Network und Security bilden
Infrastructure-Adapter, SwiftData bleibt Persistence. Keychain und SwiftData
werden nicht als atomare Transaktion behauptet, sondern durch
`EVEAccountConnectionService` getestet kompensiert. Siehe
[ADR-0043](../../Architecture/ADRs/ADR-0043_SSO-Ports-JWT-und-Kompensation.md).

## Build und Tests

- `swift build --scratch-path .build-p38 --jobs 2`:
  **erfolgreich**.
- Xcodegen und Xcode Debug App-Build, Codesigning deaktiviert:
  **BUILD SUCCEEDED**.
- `swift test --scratch-path .build-p38 --jobs 1`:
  **540/540 bestanden**, 0 Fehler.
- fokussierter Xcode-Debugtest außerhalb der Sandbox:
  **13/13 bestanden**, `TEST SUCCEEDED`.

Ein signierter Xcode-Vorlauf scheiterte vor Testbeginn an Finder-Metadaten im
generierten Testbundle. Ein Sandbox-Vorlauf blockierte SwiftData-Makros.
Der identische unsignierte Lauf bestand außerhalb der Sandbox; Details stehen
in `Documentation/TEST_HISTORY.md`.

## Manuelle Prüfung, Probleme und Risiken

Ein sichtbarer App-/Real-SSO-End-to-End-Lauf wurde nicht ausgeführt.
Die Kontoautorisierung erzeugt externen Zugriff und benötigt deshalb eine
ausdrückliche Eigentümerbestätigung unmittelbar vor dem Verbinden. Offen ist:

1. real verbinden und erwartete minimale Scopes prüfen,
2. App neu starten und Kontodatensatz/Keychain-Wiederaufnahme prüfen,
3. Refresh auslösen,
4. Trennen bestätigen und Datenbestandsschutz prüfen.

Kein bestätigter technischer P38-Produktfehler. Tokens, Codes, Verifier und
`state` wurden nicht in Berichte oder Logs übernommen. Die Umsetzung ist
keine rechtliche Prüfung oder CCP-Genehmigung.

## Abnahmekriterien und Review

Erfüllt: Schichtengrenzen, PKCE/State, Loopback-Implementierung,
JWT-Signatur/Claims/Scopes, Refresh, bestätigtes Trennen, Kompensation,
Persistenz, Debugbuilds, vollständige automatisierte Tests und
Dokumentation.

Nicht erfüllt: realer manueller Eigentümer-SSO-End-to-End-Lauf.

Reviewentscheidung: **⚠️ mit Einschränkung bestanden**. P38 darf nach
Definition of Done noch nicht auf `✅` gesetzt werden.

## Offene Punkte und nächster Prompt

- OFF-008 und OFF-013 sind geschlossen.
- Der technische SSO-Anteil von OFF-010 ist geschlossen; manueller P38-Lauf
  sowie ESI in P39/P40 bleiben getrennt offen.
- Nächster Schritt: P38 manuell abnehmen. Erst danach P39 – ESI-
  Infrastruktur und Charaktere, nur auf ausdrücklichen Auftrag.
