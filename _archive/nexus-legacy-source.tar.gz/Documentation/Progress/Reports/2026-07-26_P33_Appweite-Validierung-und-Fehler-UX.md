# Abschlussbericht – P33 Appweite Validierung und Fehler-UX

Prompt-ID: **P33**  
Datum: **2026-07-26**  
Status: **✅ erledigt**

## Ziel und Ausgangszustand

Die P04-Fehlergrenze besaß sichere Codes, Redaction und zentrale Alerts.
Kernformulare erklärten deaktivierte Schreibaktionen jedoch nicht einheitlich,
und Laufzeitalerts boten für reine Lesevorgänge keinen Retry. P33 wurde am
2026-07-26 ausdrücklich reaktiviert. Schema v20 und der P31-Stand blieben
unverändert.

## Änderungen

- `NexusValidationIssue` und `NEN-VAL-001` bis `NEN-VAL-006` ergänzt,
- gemeinsame `NexusValidationSummary` und sichere Fehlerzustandsansicht
  eingeführt,
- Projekt-, Lager-, Bestands-, Preisprofil-, Preis- und Einkaufsformular
  zeigen konkrete, rohwertfreie Validierungsgründe,
- geschlossene Retry-Positivliste für idempotente Lese-/Inspect-/
  Previewoperationen umgesetzt,
- Runtime entfernt Präsentation und Closure vor einmaliger Ausführung,
- Schreib-, Apply-, Restore-, Aktivierungs- und Löschoperationen verwerfen
  Retries,
- sichere Retries für aktuelle Kern-Ladepfade verdrahtet.

Neu: ADR-0038 und dieser Bericht. Geändert: zentrale Application-/
Runtime-Fehlergrenze, gemeinsame Fehler-UI, betroffene Kernviews,
P33-Spezifikation, Tests und Statusdokumentation. Gelöscht oder verschoben:
nichts.

## Architektur und Daten

Entscheidung: [ADR-0038](../../Architecture/ADRs/ADR-0038_Sichere-Validierung-und-kontrollierter-UI-Retry.md).
Domain- und Application-Validatoren bleiben die letzte Schreibgrenze; die
UI-Prüfung ist seiteneffektfrei. Kein SwiftData-Modell, keine Migration und
keine Benutzerdaten wurden verändert.

## Build und Tests

Ausgeführt:

```text
swift test -c debug --filter
  'ErrorHandlingTests|NewEdenNexusTests/testRuntime|
   PurchasingViewModelTests|AppSourceArchitectureTests'
swift test -c debug --quiet
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p33-xcode-final
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
```

Ergebnis:

- fokussiert: **16/16 bestanden**,
- SwiftPM Debug: **507/507 bestanden**, 0 übersprungen,
- Xcode Debug: **507/507 bestanden**, 0 übersprungen,
- Xcode-Parität: 15 Targets, sieben Testtargets, zwei Schemes.

Der erste fokussierte Compile deckte ausschließlich einen Swift-6-
Actor-Isolationfehler in einem neuen Testhelper auf. Der Test wurde ohne
produktive Verhaltensänderung actor-sicher formuliert. Ein früher Xcode-Lauf
meldete die bekannte DTDeviceKit-Warnung eines gesperrten angeschlossenen
Mobilgeräts; das explizite macOS-Ziel und der finale Exitstatus waren nicht
betroffen. Eine manuelle vollständige VoiceOver-/Lokalisierungsprüfung wurde
nicht durchgeführt und bleibt P35.

## Offene Punkte und Abweichungen

Alle aktiven Einträge in `OFFEN.md`, `OPEN_TASKS.md` und `KNOWN_ISSUES.md`
wurden geprüft. Kein aktiver Punkt blockiert P33. KI-007/OFF-007 ist nun
einschließlich der P33-Harmonisierung geschlossen. P34 Performance,
P35 vollständige Accessibility/Lokalisierung, P36 Recovery und der
Release-/Compliance-Recheck bleiben offen. Keine fachliche Abweichung vom
reduzierten MVP.

## Abnahme und Review

Alle P33-Kriterien sind erfüllt: sichere Feldvalidierung, kontrollierter
Lese-Retry, blockierter Schreib-Retry, Redaction, fokussierte und vollständige
Tests, Xcode/SwiftPM-Parität sowie Dokumentation sind nachgewiesen.

Reviewentscheidung: **✅ bestanden**. Der tatsächliche Diff, die Retry-
Positivliste, Einmalausführung, Rohfehlerfreiheit, UI-Verwendung,
Buildausgaben und Testzahlen wurden getrennt kontrolliert. Keine durch P33
verursachte kritische oder hohe Regression ist offen.

Nächster empfohlener Prompt: **P34 – Performance und große Graphen**, nur
nach ausdrücklicher Reaktivierung.
