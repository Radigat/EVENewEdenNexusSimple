# P38 – JWKS-Mischschlüssel-Korrektur

## Ziel und Ausgangszustand

Der reale Account-Login erreichte die Tokenprüfung, endete jedoch mit
`NEN-AUTH-001` und `error_reason=signing_key_unavailable`.

## Ursache und Änderung

Der am 2026-07-26 geprüfte offizielle CCP-JWKS enthält gleichzeitig einen
RSA-/RS256- und einen EC-/ES256-Schlüssel. Das bisherige `JWK`-Modell
verlangte RSA-Modulus und -Exponent bei jedem Eintrag. Der zusätzliche
EC-Schlüssel ließ deshalb die Dekodierung des gesamten Schlüsselsatzes
fehlschlagen.

Algorithmusspezifische Felder sind nun optional. Die Auswahl bleibt
unverändert streng: Nur der `kid`-, `kty`- und `alg`-passende
RSA-/RS256-Schlüssel wird zur Access-Token-Prüfung verwendet. Ein
unpassender EC-Schlüssel wird ignoriert; ES256 wurde nicht freigeschaltet.

Offizielle Grundlagen:

- [SSO-Metadaten](https://login.eveonline.com/.well-known/oauth-authorization-server)
- [CCP-JWKS](https://login.eveonline.com/oauth/jwks)
- [CCP-SSO-Dokumentation](https://developers.eveonline.com/docs/services/sso/)

## Geänderte Dateien

- `Sources/NewEdenNexusInfrastructure/EVESSOAuthorizationFlow.swift`
- `Tests/NewEdenNexusInfrastructureTests/EVESSOAuthorizationFlowTests.swift`
- betroffene P38-Status-, Test- und Architekturdokumente

Keine Datenbank-, Portal-, Keychain- oder Benutzerdaten wurden verändert.

## Build und Tests

- fokussierte SSO-/JWKS-Tests: 7/7 bestanden,
- vollständige SwiftPM-Debugsuite: 545/545 bestanden,
- isolierter lokal signierter Xcode-Debugbuild, macOS arm64:
  `BUILD SUCCEEDED`,
- Quellparität und `codesign --verify --deep --strict`: bestanden.

## Review

Der tatsächliche Diff, die polymorphe JWK-Dekodierung, unverändert strenge
RSA-Auswahl, Testnachweise, Signatur und Dokumentation wurden geprüft.
Keine Token-, Schlüssel- oder Charakterwerte wurden gespeichert oder
protokolliert.

Entscheidung: **⚠️ mit Einschränkungen bestanden**. KI-036 ist technisch
behoben. P38 bleibt offen, bis der Projekteigentümer Verbinden, Neustart,
Refresh und Trennen mit diesem Build real erfolgreich bestätigt.

## Nächster Schritt

`OFF-033`: Xcode-Build bereinigen, App neu starten und den vollständigen
Eigentümer-SSO-Lauf wiederholen. Bei einem erneuten Fehler ist die
redigierte Logzeile mit `error_reason` der nächste Prüfnachweis. P39 wurde
nicht begonnen.
