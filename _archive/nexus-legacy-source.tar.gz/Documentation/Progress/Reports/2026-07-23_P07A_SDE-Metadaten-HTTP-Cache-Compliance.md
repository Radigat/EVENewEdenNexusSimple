# Abschlussbericht – P07A: SDE-Metadaten, HTTP-Cache und CCP-Compliance

Datum: 2026-07-23  
Prompt-ID: P07A  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

Die Anwendung soll den lokal aktiven SDE-Build mit CCPs offiziell gemeldetem
Build vergleichen, HTTP-Caching und konservative Retryregeln einhalten,
Schemaänderungen sichtbar stoppen und den technischen Prüfzustand lokal
speichern. Archivdownload, Aktivierung und UI sind ausdrücklich nicht Teil von
P07A.

## Ausgangszustand

P07–P09 stellten einen validierten lokalen JSONL-Pfad, einen versionierten
SwiftData-Katalog und read-only Item-/Blueprintabfragen bereit. Es fehlten:

- offizieller `latest.jsonl`- und Schema-Changelog-Abruf,
- ETag, Last-Modified, 304 und Cache-Control,
- 24-Stunden-Policy,
- Timeout und begrenztes Retry/Backoff/Jitter,
- zentraler SDE-User-Agent,
- persistenter Prüfstatus,
- Schema-Changelog-Gate.

Der letzte offizielle Importtest verwendete Build `3424810`; der Audit hatte
bereits Build `3444265` als neueren Metadatenstand festgestellt.

## Durchgeführte Änderungen

### Application

- `SDEUpdateService` und UI-/adapterfreie Zustände implementiert,
- Ports für Releaseprüfung, aktive lokale Version, Statuspersistenz, Zeit,
  HTTP-Transport, Sleeper und Jitter definiert,
- 24-Stunden-Mindestintervall und Servercacheentscheidung implementiert,
- Zustände `current`, `updateAvailable`, `notModified`, `offline`,
  `schemaReviewRequired` und `failed` definiert,
- sichere zentrale User-Agent-Konfiguration ergänzt,
- Fehleroperation `sdeMetadataCheck` mit `NEN-SDE-006` ergänzt.

### Infrastructure

- URLSession-Transport mit expliziten Timeouts und deaktiviertem URLCache,
- feste offizielle HTTPS-URLs für `latest.jsonl` und
  `schema-changelog.yaml`,
- Redirects nicht verfolgen und abweichende finale URL ablehnen,
- `If-None-Match`/ETag und `If-Modified-Since`/Last-Modified,
- 200-/304-Verarbeitung und Cache-Control-/Age-Auswertung,
- begrenzte Retries für Transport/Timeout, 408, 429, 500, 502, 503 und 504,
- `Retry-After` oder exponentielles Backoff mit Jitter,
- keine Wiederholung anderer 4xx und keine Polling-Schleife,
- defensiver JSONL- und begrenzter YAML-Parser,
- Schutz der Headerkonfiguration gegen Steuerzeichen/CRLF.

### Persistence

- `NexusSchemaV4` 4.0.0 mit `SDEUpdateCheckRecord`,
- additive Migration v3→v4,
- Repository für genau einen Prüfstatusdatensatz,
- aktive lokale Buildnummer nur bei genau einer konsistenten Aktivversion,
- Backup-Schemabindung auf 4.0.0 und Restorekompatibilität 1.0.0 bis 4.0.0.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/SDEUpdateChecking.swift`
- `Sources/NewEdenNexusInfrastructure/CCPSDEMetadataClient.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV4.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSDEUpdateStateRepository.swift`
- `Tests/NewEdenNexusApplicationTests/SDEUpdateServiceTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/CCPSDEMetadataClientTests.swift`
- `Tests/NewEdenNexusPersistenceTests/SDEUpdateStateRepositoryTests.swift`
- `Documentation/SDE_UPDATE_CHECK.md`
- `Documentation/Architecture/ADRs/ADR-0010_SDE-Metadaten-HTTP-Cache-und-Schema-Gate.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- zentrale Fehlerbehandlung,
- Schemamigrationsplan und ModelContainer,
- Backup-Schemabindung und Backuptests,
- Fehler-, Architektur-, Datenmodell-, SDE-, Compliance- und
  Testdokumentation,
- Entwickler-Menü, Roadmap, Promptregister, Feature-Matrix, Status,
  offene Punkte, Aufgaben, bekannte Probleme, Tagebuch und Testhistorie.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

ADR-0010 trennt die Metadatenprüfung von Download und Aktivierung. Application
orchestriert ausschließlich über Ports; Infrastructure kapselt HTTP und
Parser; Persistence speichert den nachvollziehbaren Cache-/Prüfzustand.
Unverstandene Schemaänderungen werden vor einer späteren Installation als
`schemaReviewRequired` sichtbar.

## Datenmodelländerungen

Schema 4.0.0 ergänzt additiv einen technischen Prüfstatus. Bestehende
Charakter-, Projekt- und SDE-Katalogdaten werden nicht geändert. Die
dateibasierte v3→v4-Migration erhielt Projekt und aktiven Katalog. Kein
produktiver Benutzerstore wurde geöffnet.

## Offizielle CCP-Quellen

Am Ausführungstag geprüft:

- Developer License Agreement,
- SDE-Dokumentation und SDE-Übersicht,
- `latest.jsonl`,
- `schema-changelog.yaml`,
- ESI Best Practices und Rate Limiting,
- Third Party Policies,
- EULA und Terms of Service.

Die Prüfung ist technische Dokumentation, keine Rechtsberatung, keine
Vertragsannahme und keine Behauptung einer CCP-Freigabe.

## Manueller read-only Abruf

- `latest.jsonl`: HTTP 200, Build `3444265`, Release
  `2026-07-23T11:06:22Z`, `application/jsonlines+json`, ETag, Last-Modified,
  `Cache-Control: max-age=300`.
- `schema-changelog.yaml`: HTTP 200, `text/vnd.yaml`, ETag, Last-Modified,
  `Cache-Control: max-age=300`, höchster `afterBuildNumber` `3407448`.
- Kein SDE-Archiv heruntergeladen, entpackt, importiert oder aktiviert.

## Build-Ergebnis

Erfolgreich:

```bash
swift package --disable-sandbox describe
swift test --disable-sandbox -c debug --enable-code-coverage
swift build --disable-sandbox -c release
swift test --disable-sandbox -c release
```

Alle Befehle verwendeten isolierte `CLANG_MODULE_CACHE_PATH`- und
`SWIFTPM_MODULECACHE_OVERRIDE`-Verzeichnisse. Die Standardbefehle in der
eingeschränkten Umgebung können die globalen SwiftPM-Caches nicht beschreiben;
die isolierten Abschlussläufe endeten mit Exitcode 0.

## Testergebnis

- gezielte P07A-/Backup-/Fehlerregression: **41 Tests, 0 Fehler**,
- nach Reviewkorrekturen fokussiert: **11 Service-** und **13 HTTP-Tests**,
  jeweils 0 Fehler,
- Debug mit Coverage: **130 Tests, 0 Fehler**,
- Release: **130 Tests, 0 Fehler**,
- keine übersprungenen XCTest-Tests,
- fünf Architekturgrenztests erfolgreich.

Coverage:

- gesamt `10111/12186` = `82,97 %`,
- produktive Sources `4668/6568` = `71,07 %`,
- Application-Service `92,96 %`,
- HTTP-/Parseradapter `79,48 %`,
- Persistenzrepository `91,41 %`.

## Zwischenfehler und Korrekturen

- XCTest akzeptierte `await` nicht in Assertions-Autoclosures; Werte werden
  nun vorher aufgelöst.
- Der CRLF-Test deckte eine Graphemgrenze in der Stringprüfung auf. Die
  Headervalidierung prüft deshalb Unicode-Scalars. Der Regressionstest wurde
  beibehalten.
- Der gesonderte Review deckte asymmetrische Frischezeiten der beiden
  Metadatenressourcen auf. Die Cacheentscheidung erfolgt nun je Ressource;
  ein fokussierter Regressionstest verhindert unnötige Abrufe.
- Der finale Sicherheitsreview deckte die standardmäßige URLSession-
  Redirectfolge auf. Der Produkttransport folgt Redirects nicht mehr und der
  Client lehnt abweichende finale URLs ab.

## Manuelle Prüfungen

- Git-Wurzel und untracked Benutzerstand kontrolliert; nichts verworfen,
  gestaged, committed oder gepusht,
- feste offizielle URLs und tatsächliche Inhaltstypen geprüft,
- keine CCP-Bilder/Logos oder Geheimnisse ergänzt,
- kein produktiver Store und kein SDE-Archiv geöffnet,
- alle aktiven Einträge in `OFFEN.md`, `OPEN_TASKS.md` und
  `KNOWN_ISSUES.md` erneut bewertet.

## Bekannte Probleme und offene Anforderungen

- `OFF-019` / `KI-019`: Download, ZIP-/Zip-Slip-/Größen-/Speicherplatzschutz,
  isolierter Stagingstore, Crash-Recovery, Promotion und Rollback – P07B/P36.
- `OFF-020` / `KI-020`: Eigentümerkontakt, Startverdrahtung, Einstellungen,
  Fortschritt, Verlauf, Diagnoseexport und rechtliche Ansicht – P07C/P37.
- Die Core-Data-Tests geben nicht fehlschlagende Hinweise zur
  Store-Change-Benachrichtigung aus.
- Globale SwiftPM-Caches sind in der Ausführungsumgebung nicht beschreibbar.

## Eigentümeraufgaben

Der Projekteigentümer muss die aktuellen CCP-Bedingungen persönlich prüfen,
eine geeignete Kontaktmöglichkeit für die zentrale User-Agent-Konfiguration
festlegen und den späteren Marken-/Eigentumshinweis vor Veröffentlichung
freigeben. P07A hat keine Vereinbarung stellvertretend akzeptiert.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. P07A ergänzt die technische Härtung des
SDE-Pfads. Weitere Datensätze werden weiterhin nur bei nachgewiesenem
Featurebedarf importiert.

## Abnahmekriterien

| Kriterium | Ergebnis |
|---|---|
| notwendige offene Punkte bearbeitet | ✅ OFF-018 erledigt, technischer Anteil OFF-020 erledigt |
| lokale und offizielle Buildnummer verglichen | ✅ |
| ETag, Last-Modified, 304, Cache-Control, 24 h getestet | ✅ |
| Retry/Backoff/Jitter und User-Agent zentral | ✅ |
| Schema-Changelog sicher bewertet | ✅ |
| Offlinebetrieb erhält aktiven Katalog | ✅ |
| Debug/Release und relevante Tests grün | ✅ |
| Compliance-/Owner-Aufgaben dokumentiert | ✅ |
| gesonderter Review bestanden | ✅ |

## Reviewentscheidung

**✅ bestanden.** Der tatsächliche Quellcode, Migrationen, Tests,
Buildausgaben und Pflichtdokumentation erfüllen P07A. Es wurde keine
Download-, Aktivierungs- oder UI-Funktion vorgezogen.

## Nächster empfohlener Prompt

**P07B – Sicherer SDE-Download, Archivprüfung und Aktivierung.**
