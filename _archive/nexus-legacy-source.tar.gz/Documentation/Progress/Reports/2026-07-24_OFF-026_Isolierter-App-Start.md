# Abschlussbericht – OFF-026: Isolierter App-Start

Datum: 2026-07-24  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

P12 vollständig spezifizieren und anschließend den in P11 beobachteten
Startfehler `NEN-PER-001` ursächlich klären. Ein echter App-Start muss einen
nachweislich isolierten Store verwenden. Vorhandene Daten dürfen weder
gelöscht noch ersetzt, verschoben oder ungefragt repariert werden.

P12 selbst wurde in diesem Arbeitspaket nicht fachlich implementiert.

## Ausgangszustand

- P11 war mit 198 Tests in allen vier Konfigurationen abgeschlossen.
- Ein zusätzlicher App-Start zeigte die sichere Fehleransicht
  `NEN-PER-001`.
- `NexusModelContainerFactory` verwendete die URL einer unbenannten
  SwiftData-Standardkonfiguration.
- Unter `~/Library/Application Support/default.store` existierte bereits
  eine Datenbank unbekannter Herkunft.
- P12 lag nur als kurzer Entwurf ohne vollständiges Zielmodell,
  Migrationsplan, UX-/Fehlervertrag und Abnahmekriterien vor.

## Diagnose

Der globale `default.store` wurde ausschließlich read-only untersucht:

| Prüfung | Ergebnis |
|---|---|
| Größe | 86.016 Bytes |
| Änderungszeit | 2026-07-23T10:36:45+0200 |
| SHA-256 | `6acc13fe889a37e807f7908957e39073406667a53b99efa073c3f6040fd64ec0` |
| SQLite `quick_check` | `ok` |
| Fachsignatur | `ZAPIREQUESTMODEL` |
| New-Eden-Nexus-Tabellen | nicht vorhanden |

Ursache war damit keine beschädigte New-Eden-Nexus-Migration, sondern eine
Namenskollision: Mehrere SwiftData-/Core-Data-Anwendungen können einen
generischen `default.store` im selben Application-Support-Verzeichnis
verwenden. Die bestehende Datei war konsistent, aber fachfremd.

## Durchgeführte Änderungen

### Persistenz

`NexusModelContainerFactory` verwendet nun:

```text
~/Library/Application Support/NewEdenNexus/NewEdenNexus.store
```

Auflösungsregeln:

1. Ein vorhandener app-spezifischer Store hat Vorrang.
2. Ein vorhandener globaler Legacy-Store wird read-only klassifiziert.
3. Nur die gemeinsame Signatur `ZCHARACTERRECORD` und
   `ZPRODUCTIONPROJECT` gilt als New Eden Nexus.
4. Ein erkannter eigener Legacy-Store bleibt unverändert am bisherigen Ort.
5. Ein fremder Store wird nicht übernommen oder verändert.
6. Ein nicht lesbarer Legacy-Store führt weiterhin zum sicheren Startfehler
   statt zu einem stillen leeren Ersatzstore.

`make(at:)` legt ausschließlich das notwendige Elternverzeichnis an.

### App-Startisolation

Der App-Einstieg akzeptiert für kontrollierte Tests:

```text
--new-eden-nexus-isolated-store <absoluter Pfad>
```

Relative oder fehlende Pfade werden abgelehnt. Der Modus verwendet den
normalen versionierten Container, zählt aber als Testumgebung, damit keine
produktive SDE- oder Keychain-Composition gestartet wird.

### P12-Spezifikation

`Documentation/Prompts/MVP/P12_Zielproduktauswahl.md` wurde vollständig
spezifiziert:

- persistentes Ziel mit Produkt-ID, Aktivität, Blueprint-ID und
  Katalogprovenienz,
- additive Schema-v5-Migration ohne erfundene Namenszuordnung,
- Katalog- und P10-Resolvervalidierung,
- positive Ganzzahlmenge ohne willkürliche Fachobergrenze,
- Such-, Auswahl-, Fehler-, Versionswechsel- und Accessibilityzustände,
- Domain-, Application-, Persistenz-, ViewModel-/UI- und
  Migrationsabnahme,
- kein Marktgruppenimport nur für Navigation,
- P13 wird nicht vorgezogen.

## Neu erstellte Dateien

- `Tests/NewEdenNexusPersistenceTests/NexusDefaultStoreResolutionTests.swift`
- `Documentation/STORE_LOCATION_AND_ISOLATION.md`
- `Documentation/Architecture/ADRs/ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexus/AppExecutionEnvironment.swift` (bereits im
  uncommitteten P11-Stand vorhanden, um die explizite Store-URL erweitert)
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- `README.md`
- P12-Prompt und Promptregister
- Architektur-, ADR-, Datenmodell-, Status-, Feature-, Tagebuch-, offene
  Punkte-, bekannte Probleme- und Testdokumentation

## Gelöschte oder verschobene Dateien

Keine.

Insbesondere wurden weder der globale `default.store` noch seine
Begleitdateien gelöscht, verschoben, ersetzt, repariert oder umbenannt.

## Architekturentscheidung

[ADR-0016](../../Architecture/ADRs/ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md)
legt app-spezifischen Produktivpfad, read-only Legacy-Klassifikation,
Fail-closed-Verhalten und explizite Testisolation verbindlich fest.

## Datenmodelländerungen

Keine. Schema v4 und `NexusMigrationPlan` blieben unverändert.

Der echte normale Start legte regulär einen neuen app-spezifischen
Schema-v4-Store an. Ein zweiter echter Prozess verwendete einen expliziten
neutralen `/private/tmp`-Store. Beide besitzen die erwarteten
New-Eden-Nexus-Signaturtabellen.

## Build-Ergebnis

| Weg | Debug | Release |
|---|---|---|
| SwiftPM | ✅ erfolgreich | ✅ erfolgreich |
| Xcode | ✅ erfolgreich | ✅ erfolgreich |

Zusätzlich:

- 15 Targets,
- sieben Testtargets,
- zwei gemeinsame Schemes,
- Projektparitätsprüfung erfolgreich,
- keine Team- oder Projekteinstellung für Signing geändert.

## Testergebnis

| Weg | Debug | Release |
|---|---:|---:|
| SwiftPM | 205 bestanden, 0 fehlgeschlagen, 0 übersprungen | 205 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| Xcode | 205 bestanden, 0 fehlgeschlagen, 0 übersprungen | 205 bestanden, 0 fehlgeschlagen, 0 übersprungen |

OFF-026 ergänzt sieben Tests:

- kein Legacy-Store → app-spezifischer Pfad,
- fremder Legacy-Store → nicht übernommen und erhalten,
- eigener Legacy-Store → am Ort erhalten,
- unlesbarer Legacy-Store → fail closed,
- bestehender app-spezifischer Store → Vorrang,
- expliziter verschachtelter Store → Elternpfad und Container erfolgreich,
- Startargument → nur vollständiger absoluter Pfad akzeptiert.

Xcode-Ergebnisbündel:

- Debug:
  `.build/OFF026XcodeDebug/Logs/Test/Test-NewEdenNexus-2026.07.24_06-54-26-+0200.xcresult`
- Release:
  `.build/OFF026XcodeRelease/Logs/Test/Test-NewEdenNexus-2026.07.24_06-53-49-+0200.xcresult`

## Manueller Funktionstest

Ein echter App-Prozess wurde über LaunchServices mit folgendem isolierten
Pfad gestartet:

```text
/private/tmp/NewEdenNexus-OFF026-Store.BPuOl1/OFF026.store
```

Nachweise:

- Prozessargument enthielt exakt den isolierten Store,
- `lsof` zeigte ausschließlich diesen Store sowie dessen WAL/SHM,
- Hauptdatei 180.224 Bytes,
- SQLite-`quick_check`: `ok`,
- Tabellen `ZCHARACTERRECORD` und `ZPRODUCTIONPROJECT` vorhanden,
- kein strukturierter `NEN-PER-001`-Startfehler,
- Prozess anschließend geordnet beendet,
- Store nach Prozessende weiter konsistent.

Die Computer-Use-Accessibility-Abfrage brach wiederholt auf Transportebene
ab. Deshalb wird kein visueller UI-Smoke-Test behauptet. Der echte
Prozessstart, der tatsächlich geöffnete Pfad und die Datenbankintegrität
sind unabhängig belegt.

## Bestandsschutz

Vor und nach dem Reallauf waren beim fremden globalen Store identisch:

- SHA-256:
  `6acc13fe889a37e807f7908957e39073406667a53b99efa073c3f6040fd64ec0`,
- Größe: 86.016 Bytes,
- Änderungszeit: 2026-07-23T10:36:45+0200.

Es gab keinen Recovery- oder Reparaturversuch.

## Bekannte Probleme und Grenzen

- P12 ist vollständig spezifiziert, aber weiterhin offen.
- Die GUI-Accessibility-Abfrage des Automatisierungswerkzeugs lieferte
  keinen belastbaren visuellen Nachweis.
- Ein SQLite-Store innerhalb des File-Provider-Workspace war für den echten
  Prozess kein geeigneter Smoke-Testpfad; `/private/tmp` funktionierte.
- Ein später unveränderter Wiederholungslauf traf eine beschädigte
  generierte `.build/build.db` und danach File-Provider-Meldungen zu
  tatsächlich unveränderten Quellen. Es wurde kein Cache gelöscht oder
  repariert. Die finalen Produktivquellen und Tests entsprechen dem zuvor
  in allen vier Vollsuites bestandenen Stand.
- Benutzergesteuerte Recovery, Backup-vor-Migration und Storeverschiebung
  bleiben P36.
- OFF-024, der harte SDE-Prozessabbruch an persistenten Phasengrenzen,
  bleibt unabhängig offen.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. Die konkrete app-spezifische Store-URL war dort
nicht festgelegt und wurde als technische Sicherheitsentscheidung ergänzt.

## Abnahmekriterien

| Kriterium | Ergebnis |
|---|---|
| P12 vollständig spezifiziert | ✅ |
| notwendige offene Punkte geprüft | ✅ |
| OFF-021 für P12 entschieden | ✅ kein Marktgruppenimport erforderlich |
| OFF-026 ursächlich eingegrenzt | ✅ |
| fremden Store nicht verändert | ✅ |
| app-spezifischer Produktivpfad | ✅ |
| eigener Legacy-Store erhalten | ✅ |
| echter isolierter App-Prozess | ✅ |
| Build Debug/Release | ✅ |
| relevante Tests vollständig | ✅ |
| Dokumentation und Abschlussbericht | ✅ |
| gesonderter Review | ✅ bestanden |

## Reviewentscheidung

**✅ bestanden**

Der tatsächliche Diff, Pfadauflösung, Fehlerfälle, Datenwirkung, vier
vollständige Testläufe, Xcode-/SwiftPM-Parität, echter Prozess, geöffnete
Dateideskriptoren, SQLite-Integrität und Dokumentation wurden getrennt
geprüft. Es besteht kein OFF-026-Blocker für P12 mehr.

## Nächster empfohlener Prompt

**P12 – Kataloggestützte Zielproduktauswahl anhand der vollständigen
Spezifikation ausführen.**

P13 darf nicht automatisch begonnen werden.
