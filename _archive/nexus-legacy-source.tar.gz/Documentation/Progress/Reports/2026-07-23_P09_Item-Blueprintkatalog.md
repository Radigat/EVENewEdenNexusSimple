# Abschlussbericht – P09: Item- und Blueprintkatalog

## Prompt-ID und Ziel

**P09 – Item- und Blueprintkatalog vollständig spezifizieren und ausführen**

Ziel war ein lokaler, deterministischer, begrenzter und über
Application-Use-Cases erreichbarer Lesezugriff auf Items, Blueprints und ihre
Produktionsbezüge aus genau einer aktiven SDE-Version.

## Ausgangszustand

- P08 speicherte den statischen Katalog in Schema v2 und aktivierte Versionen.
- Es gab keinen Application-Port für Item- oder Blueprintabfragen.
- Name, Kategorie, Gruppe, Veröffentlichung und Produktionsfähigkeit waren
  nicht such- oder filterbar.
- Nachgelagerte Views hätten SwiftData direkt abfragen müssen.
- Namensnormalisierung und messbare Ergebnisbegrenzung fehlten.
- `OFF-003`/`KI-004` umfassten Katalog und Rezeptresolver.

## Durchgeführte Änderungen

- `CatalogDataVersion`, Suchanfrage, Filter, Seiten-, Item-, Blueprint-,
  Aktivitäts-, Material-, Produkt- und Linktypen in Application ergänzt.
- `ItemBlueprintCatalogReading` sowie Such-, Item- und Blueprint-Use-Case
  implementiert.
- zentrale Normalisierung für Groß-/Kleinschreibung, Diakritika,
  Zeichenbreite und Leerraum ergänzt.
- Eingaben mit Limits 1–100, nichtnegativen IDs und sinnvoller leerer Suche
  validiert.
- `SwiftDataItemBlueprintCatalog` als `@ModelActor` implementiert.
- genau eine aktive SDE-Version pro Abfrage erzwungen.
- exakte Item-/Blueprint-Lookups und typisiertes `notFound` umgesetzt.
- Publikations-, Kategorie-, Gruppen-, Produktions- und Aktivitätsfilter
  umgesetzt.
- stabile Sortierung, Deduplizierung, `hasMore` und begrenzte Fetches
  implementiert.
- Produktionsbezüge und zusammengefassten Auflösungsstatus ohne
  Rezeptpriorisierung verfügbar gemacht.
- Konsistenzprüfung für Version, Gruppen/Kategorien, Blueprintdefinitionen,
  Aktivitäten und Hash ergänzt.
- `CancellationError` unverändert durchgereicht.
- `NexusSchemaV3` 3.0.0 mit `ItemType.searchName` eingeführt.
- benutzerdefinierte v2→v3-Backfillmigration implementiert.
- aktuelle Schemaaliases und Containerfactory auf v3 umgestellt.
- Backup-Schema auf 3.0.0 aktualisiert; 1.0.0/2.0.0 kompatibel gehalten.
- Katalogoperation `catalogQuery` und Code `NEN-SDE-005` ergänzt.
- Application-, Persistence-, Migrations-, Backup-, Performance- und
  Real-SDE-Tests ergänzt beziehungsweise angepasst.
- Pflichtdokumentation, ADR-0009 und OFFEN-Audit aktualisiert.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ItemBlueprintCatalog.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV3.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataItemBlueprintCatalog.swift`
- `Tests/NewEdenNexusApplicationTests/ItemBlueprintCatalogTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ItemBlueprintCatalogPersistenceTests.swift`
- `Documentation/ITEM_BLUEPRINT_CATALOG.md`
- `Documentation/Architecture/ADRs/ADR-0009_Deterministischer-Item-und-Blueprintkatalog.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV2.swift`
- `Sources/NewEdenNexusPersistence/NexusMigrationPlan.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexusPersistence/SQLiteLocalBackupService.swift`
- bestehende Application-, Persistence-, Backup- und offizielle
  SDE-Integrationstests,
- P09-Prompt und Promptregister,
- Entwickler-Menü, Status, Feature-Matrix, Tagebuch, OFFEN, Aufgaben,
  Probleme, Testhistorie, Roadmap,
- Architektur-, Datenmodell-, Backup-, Fehler- und Testdokumentation.

## Gelöschte oder verschobene Dateien

Keine. Die aktuellen globalen Schemaaliases wurden von v2 an v3 verschoben;
die historischen Schemata und ihre Migration bleiben erhalten.

## Architekturentscheidungen

- Application-Vertrag statt direkter SwiftData-Abfrage aus UI oder
  nachgelagerten Use-Cases.
- genau eine aktive Version ist Voraussetzung jeder Katalogabfrage.
- persistenter kanonischer Suchschlüssel statt vollständiger
  Laufzeitnormalisierung.
- harte Ergebnisgrenze und tatsächliche Fetchmetriken statt bloßer
  Performancebehauptung.
- erwartbares Fehlen ist ein typisiertes Ergebnis, kein technischer Fehler.
- rohe Produktionsbezüge werden transparent geliefert; Rezeptwahl bleibt P10.
- Mindestziel macOS 14 bleibt erhalten. Ein nativer nicht-eindeutiger
  SwiftData-Index wird nur bei später gemessenem Bedarf erwogen.

Details stehen in ADR-0009.

## Datenmodelländerungen

Neue Schemaversion 3.0.0:

- bestehende Entitäten und Felder aus v2 bleiben erhalten,
- `ItemType.searchName: String` wird ergänzt,
- neue Imports setzen den Wert im Initializer,
- v2→v3 füllt ihn für vorhandene Itemtypen und speichert den Store,
- ModelContainer und aktuelle Typealiases verwenden v3,
- Backupmanifeste verwenden 3.0.0.

Die Migration ist datenerhaltend. Kein produktiver Benutzerstore wurde
geöffnet oder verändert.

## Build-Ergebnis

Ausgeführt:

```bash
./Scripts/ci-verify.sh
```

Ergebnis:

- Packagegraph erfolgreich beschrieben,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen im erfolgreichen Abschlusslauf.

Ein vorheriger normaler Sandbox-Build konnte ausschließlich den globalen
Clang-/SwiftPM-Cache nicht beschreiben. Mit isoliertem Cache und deaktivierter
SwiftPM-Sandbox bestand derselbe Quellstand.

## Testergebnis

- Debug mit Coverage: 100 Tests, 0 Fehler, 0 unerwartete Fehler.
- Release: 100 Tests, 0 Fehler, 0 unerwartete Fehler.
- keine übersprungenen XCTest-Tests.
- offizieller SDE-E2E-Test im finalen Schema-v3-Stand:
  1 Test, erfolgreich, 19,407 Sekunden.

Coverage:

- alle instrumentierten Dateien: 80,63 %,
- produktive Sources: 67,66 %,
- Application-Katalogvertrag: 133/136 Zeilen,
- SwiftData-Katalogadapter: 497/527 Zeilen,
- Migrationsplan: 43/43 Zeilen.

## Performance-Nachweis

Der reproduzierbare Test erzeugt 50.000 synthetische Itemtypen und führt zehn
Suchen mit Limit 50 aus:

Prüfgerät: MacBook Pro (Mac16,8), Apple M4 Pro, 14 CPU-Kerne, 24 GB RAM,
macOS 26.5.2.

| Konfiguration | Abfrageblock | Geladene Itemzeilen |
|---|---:|---:|
| Debug | 0,300 s | höchstens 51 je Abfrage |
| Release | 0,296 s | höchstens 51 je Abfrage |

Der einfache Suchpfad benötigt einen Item-Fetch-Batch. Die Zeit zum Aufbau des
Teststores ist nicht in der ausgewiesenen Abfragezeit enthalten.

## Offizieller Realstand

Der temporäre offizielle Tranquility-Build 3424810 wurde im finalen Stand:

1. fachlich gemappt,
2. in einen Schema-v3-Store gespeichert,
3. erneut geöffnet,
4. über Item-ID 587 (Rifter) abgefragt,
5. über Blueprint-ID 691 (Rifter Blueprint) abgefragt,
6. über normalisierte Namenssuche geprüft,
7. einschließlich Produkt-/Blueprintbezug validiert.

Die bereits bekannten 21 nicht aufgelösten Typreferenzen bleiben erhalten und
sichtbar. Es wurden keine offiziellen SDE-Dateien eingecheckt.

## Manuelle Prüfungen

- Git-Wurzel `/Users/svenstolze/Documents/Codex/EVE Nexus`, Branch `main` und
  vollständig untracked Ausgangsstand erneut geprüft.
- keine Datei gestaged, committed oder gepusht.
- kein Home-Repository und keine Datei außerhalb des Projektumfangs verändert.
- Application importiert für den Katalog weder SwiftData noch SwiftUI.
- normale Suchpfade besitzen eine harte Begrenzung.
- alle aktiven Einträge in `OFFEN.md` wurden einzeln erneut bewertet.

Eine GUI-Prüfung war nicht anwendbar, weil P09 keine View einführt.

## Bekannte Probleme

- `OFF-016`/`KI-016`: P10 muss 21 nicht aufgelöste offizielle Referenzen beim
  Rezeptzugriff sichtbar ablehnen.
- `OFF-017`/`KI-017`: Unter macOS 14 wird kein nativer nicht-eindeutiger
  SwiftData-Index genutzt; P09-Messung ist grün, erneute Bewertung folgt P34.
- automatische Vor-Migrations-Sicherung und Recovery-Drill fehlen bis P36.
- eigenständiges Xcode-Projekt/Scheme fehlt; SwiftPM ist der geprüfte Weg.
- alte SDE-Versionen werden noch nicht rotiert.

## Offene Anforderungen

- P10: deterministischer Rezept-/Aktivitätsresolver.
- P12: sichtbare kataloggestützte Zielproduktauswahl.
- P13 ff.: Produktionsgraph und Fachberechnungen.
- P34: reale Performancehärtung.
- P36: automatische Vor-Migrations-Sicherung und Recovery.

## Mit erledigte offene Punkte

| ID | Ergebnis | Nachweis |
|---|---|---|
| `OFF-003` / `KI-004` | Kataloganteil erledigt; nur P10-Resolver bleibt teilweise offen. | Application-/Persistence-Tests, Versionswechsel, offizieller Realtest |
| `OFF-008` | Neue Katalogzugriffe halten die Application-Grenze ein. | Port/Use-Cases und Quellcodeprüfung |
| `OFF-016` / `KI-016` | Kennzeichnung unverändert erhalten und in Details sichtbar; fachliche Ablehnung bleibt P10. | Inkonsistenz-/Detailtests und offizieller Realtest |
| `OFF-014` | Kein Blocker; verifizierter SwiftPM-Pfad verwendet. | Debug-/Release-Gesamtlauf |

Alle übrigen aktiven Punkte wurden geprüft, aber mangels P09-Abhängigkeit nicht
vorgezogen.

## Abweichungen vom Projektbuch

- P09 führt einen persistenten normalisierten Suchschlüssel ein, weil
  reproduzierbare Suche und Sortierung nicht als Viewlogik implementiert
  werden sollen.
- Das Mindestziel bleibt macOS 14; ein neueres SwiftData-Indexfeature wird
  nicht durch einen Plattformwechsel vorgezogen.
- Katalogdetails liefern alle vorhandenen Aktivitäten und Bezüge, treffen aber
  bewusst keine Rezeptpriorisierung.

Diese Entscheidungen sind in ADR-0009 dokumentiert.

## Erfüllte Abnahmekriterien

- [x] notwendige offene Punkte geprüft und Kataloganteil von OFF-003 erledigt,
- [x] aktive Versionsabfragen implementiert,
- [x] exakte Item- und Blueprint-Lookups implementiert,
- [x] normalisierte Suche und fachliche Filter implementiert,
- [x] Begrenzung, `hasMore` und stabile Sortierung implementiert,
- [x] Blueprint-/Produktbezüge ohne Rezeptpriorisierung verfügbar,
- [x] keine unbeschränkte Vollmaterialisierung im normalen Suchpfad,
- [x] Normal-, Rand-, Fehler-, Versions-, Abbruch- und Regressionstests grün,
- [x] Schema-v3-Migration und Backupkompatibilität geprüft,
- [x] Debug- und Release-Prüfung erfolgreich,
- [x] Performanceprüfung tatsächlich ausgeführt,
- [x] offizieller Realstand im finalen Schema-v3-Code geprüft,
- [x] Pflichtdokumentation und OFFEN-Audit aktualisiert,
- [x] gesonderter Review bestanden.

## Nicht erfüllte Abnahmekriterien

Keine innerhalb des vollständig spezifizierten P09-Umfangs.

## Reviewentscheidung

**✅ bestanden**

Der gesonderte Review prüfte tatsächlichen Quellcode und Git-Diff,
Application-/Persistence-Grenze, Normalisierung, Versionsisolation,
Determinismus, Begrenzung, Konsistenz- und Abbruchpfade, v2→v3-Datenwirkung,
Backupkompatibilität, realen SDE-Nachweis, Debug-/Release-Ausgaben, Coverage,
Performanceinstrumentierung, OFFEN-Audit und Pflichtdokumentation.

Keine offene kritische oder hohe P09-Regression. Die hohe offene
Referenzproblematik ist unverändert P10 zugeordnet und wird vom P09-Katalog
nicht verdeckt.

## Nächster empfohlener Prompt

**P10 – Rezept- und Aktivitätsresolver vollständig spezifizieren und
ausführen.** Dabei sind `OFF-003`, `OFF-016`, `KI-004` und `KI-016` soweit
verbindlich zu übernehmen, wie sie für das vollständige P10-Ergebnis
notwendig sind. P10 wurde nicht begonnen.
