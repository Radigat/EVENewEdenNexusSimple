# P52/OFF-053 – Wallet-Zuordnungsrest

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden, Eigentümer-Retest offen  
Review: ⚠️ mit ausstehendem P42-1-Livenachweis

## Ziel und Ausgangszustand

P42-1 sollte eine Projektzuordnung nur als Vorschau öffnen und anschließend
schreibfrei abbrechen. Der Eigentümer erhielt dabei `NEN-FIN-001`.
Xcode zeigte außerdem einen ungültigen leeren Pickerzustand.

## Änderungen

- sichere Restkapazitätsprojektion für Transaktionen und Journaleinträge im
  Application-Layer ergänzt,
- vollständig ausgeschöpfte oder inkonsistente Quellen aus der Auswahl
  entfernt,
- Restmenge beziehungsweise Restbetrag sichtbar gemacht,
- Eingaben vor dem Serviceaufruf gegen den verbleibenden Anteil geprüft,
- erwartbare Überbuchung und veraltete Quelle als Inline-Hinweis behandelt,
- gültige leere Picker-Auswahl ergänzt,
- Regressionen für Teil-, Voll-, inkonsistente Zuordnung und schreibfreies
  Verwerfen ergänzt.

Geändert wurden ausschließlich Wallet-Application/UI, zugehörige Tests und
Statusdokumentation. Datenmodell, Migrationen, Signing, Wallet-Snapshot und
produktive Projektzuordnungen blieben unverändert. Kein Commit oder Push.

## Build und Tests

- Wallet-Fachtests: 9/9 bestanden.
- P42-UI-Vertrag: 1/1 bestanden.
- SwiftPM Debug vollständig: 673/673 bestanden.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64, isoliertes Derived Data:
  Apple-Development-signiert, `BUILD SUCCEEDED`.
- Der nachgelagerte Befehl `codesign --verify --deep --strict` meldete für
  dieses isolierte Debugartefakt `CSSMERR_TP_NOT_TRUSTED`, obwohl alle
  Xcode-Signierschritte erfolgreich beendet wurden. Der reale Start über
  Xcode ist deshalb Teil des noch offenen Eigentümer-Retests; dies ist kein
  Nachweis einer öffentlichen Vertrauenskette.
- Swift-Format-Lint ist kein bestehendes Projektgate und meldet tausende
  vorbestehende Stilabweichungen; es wurde nichts pauschal umformatiert.

## Review und offene Abnahme

Diff, Schichtengrenze, Überlauf-/Inkonsistenzschutz, Vorschau-vor-Schreiben,
Tests und Dokumentation wurden geprüft. Die Technik ist bestanden. P42-1
bleibt jedoch offen, bis der Eigentümer im neuen Build:

1. eine Quelle mit sichtbarer Restkapazität wählt,
2. einmal `Zuordnung prüfen` ausführt,
3. die Vorschau über `Abbrechen` verwirft,
4. bestätigt, dass keine neue Zeile unter `Bereits bestätigt` erscheint.

P42-2 benötigt danach eine neue ausdrückliche Bestätigung und wurde nicht
begonnen. Nächstes Gate: P42-1-Eigentümer-Retest einschließlich realem
Xcode-Start.
