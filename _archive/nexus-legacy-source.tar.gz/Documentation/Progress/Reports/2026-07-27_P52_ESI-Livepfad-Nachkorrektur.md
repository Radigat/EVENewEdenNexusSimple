# P52 – ESI-Livepfad-Nachkorrektur

Status: ⚠️ technisch bestanden; Wallet-Unterursache im Eigentümerlauf offen

## Livebefund

Der redigierte lokale Diagnosepfad ordnete die Meldungen eindeutig zu:

- Refresh ohne positives UI-Feedback und ohne Fehlerlog,
- persönlicher Apply: `cache_write_failed`,
- Wallet-Inspect: `inconsistent_pagination`.

Token-, Kontakt-, Charakter-, Wallet- und Fachdatenwerte wurden weder gelesen
noch dokumentiert.

## Korrekturen

- Refresh zeigt laufenden, erfolgreichen oder fehlgeschlagenen Zustand.
- Persönliche Snapshots codieren Datumswerte verlustfrei; der Decoder liest
  zusätzlich das bisherige ISO-8601-Format.
- Wallet-Journal behält gleiche `Last-Modified`-Werte als
  Konsistenzbedingung und wiederholt nach einem erkannten Cachewechsel genau
  einmal mit dem vorhandenen begrenzten Backoff.
- Regressionsfälle für alle drei Grenzen wurden ergänzt.

## Offizielle Grundlage

- [CCP ESI Best Practices](https://developers.eveonline.com/docs/services/esi/best-practices/)
- [CCP X-Pages Pagination](https://developers.eveonline.com/docs/services/esi/pagination/x-pages/)

Die Konsistenzprüfung wurde nicht gelockert. Der Neuversuch behandelt
ausschließlich den von CCP beschriebenen Cachewechsel zwischen Seiten.

## Prüfung

- fokussiert: **4/4 bestanden**,
- SwiftPM Debug: **642/642 bestanden**, 0 Fehler,
- signierter Xcode Debug für macOS arm64: **BUILD SUCCEEDED**,
- keine Schema- oder Fachdatenänderung durch die Korrektur.

## Review

Technisch: **✅ bestanden**. Änderungen sind auf die drei belegten
Liveursachen begrenzt; Retry ist einmalig, abbrechbar und respektiert die
Konsistenzgrenze.

Gesamt: **⚠️ mit Einschränkung**. Real bestanden sind Refresh, persönlicher
Inspect und der ausdrücklich bestätigte Apply ohne `NEN-ESI-003`.
OFF-040/KI-043 sind geschlossen. OFF-041/KI-044 bleiben nur bis zum
Wallet-Inspect-Retest teilweise offen.

### Wallet-Retest und sichere Unterdiagnose

Der Eigentümer-Retest meldete nach dem einmaligen Retry erneut
`NEN-ESI-004`. Der Sammelgrund wurde deshalb ohne Lockerung der
Konsistenzprüfung in sechs erlaubte Untergründe aufgeteilt: Seitenzahl,
fehlendes/abweichendes `Last-Modified`, Journalduplikat,
Transaktionswiderspruch und stehender Cursor. Walletwerte, IDs, Tokens und
Headerwerte bleiben aus der Diagnose ausgeschlossen.

Nachweis: **15/15 fokussierte und 644/644 vollständige Tests**, signierter
Xcode Debug `BUILD SUCCEEDED`. P52 bleibt bis zum einmaligen Livenachweis des
neuen sicheren `error_reason` offen.

## Nächster Schritt

Neuen Build vollständig starten, Wallet genau einmal prüfen und ausschließlich
den neuen `error_reason=inconsistent_pagination_…` melden. Keine
Walletvorschau übernehmen. P53 wurde nicht begonnen.
