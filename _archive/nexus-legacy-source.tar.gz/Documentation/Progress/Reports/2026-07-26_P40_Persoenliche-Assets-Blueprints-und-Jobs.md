# P40 – Persönliche Assets, Blueprints und Industry Jobs

Datum: 2026-07-26 · Status: ✅ erledigt · Review: ✅ bestanden

## Ziel und Ausgangszustand

Nach P39 waren nur öffentliche Charakterprofile verfügbar. P40 sollte
persönliche Assets, Blueprints und Industry Jobs nach einem positiven
Nutzenreview sicher abrufen, vor jedem Schreiben detailliert anzeigen und
als getrennten Offline-Snapshot speichern.

## Umsetzung

- exakt drei Read-Scopes:
  `esi-assets.read_assets.v1`,
  `esi-characters.read_blueprints.v1`,
  `esi-industry.read_character_jobs.v1`,
- flüchtiger Access-Token über den vorhandenen validierten Refresh-Flow;
  nur rotierte Refresh-Tokens werden im Keychain ersetzt,
- offizielle GET-Routen für Assets, Blueprints und persönliche Industry
  Jobs einschließlich `include_completed=true`,
- sequenzielle Pagination mit `X-Pages`, seitenweisen Validatoren,
  einheitlichem Last-Modified, festen Seiten-/Datensatz-/Antwortlimits,
- 200/304, 401/403, 420/429, ein begrenzter 5xx-Retry, Offlinebetrieb,
  Abbruch und Schemafehler,
- vollständig gezählte Vorschau mit bis zu 500 Einzeländerungen; Inspect
  schreibt nichts,
- bestätigtes Apply mit Basisrevision, validiertem Staging und atomarem
  Dateiaustausch,
- Wiederöffnung, Korruptions-/Symlinkschutz und kompensierbare Entfernung
  beim Trennen,
- Anzeige der lokalen Summen und Vorschau in der Accountansicht.

Manuelle Lager, CSV-Bestände, Sicherheitsbestände, Reservierungen,
Produktionsprojekte und Preise werden nicht verändert. Es gab keine
SwiftData-Migration.

## Architektur und Dateien

Neu sind die P40-Applicationgrenze, der persönliche ESI-Client, der
Dateistore, die Vorschauansicht, drei fokussierte Testsuiten und
[ADR-0045](../../Architecture/ADRs/ADR-0045_Persoenliche-ESI-Snapshots-mit-Vorschau.md).
Geändert wurden Account-Composition, ViewModel/View, SSO-Trennkompensation,
Fehlercodes, Xcode-Projekt sowie die betroffenen Steuer- und
ESI-Dokumente. Gelöscht oder verschoben wurde nichts.

Die verwendeten offiziellen Grundlagen sind:

- [ESI Overview](https://developers.eveonline.com/docs/services/esi/overview/),
- [ESI Best Practices](https://developers.eveonline.com/docs/services/esi/best-practices/),
- [ESI Rate Limiting](https://developers.eveonline.com/docs/services/esi/rate-limiting/),
- [EVE SSO](https://developers.eveonline.com/docs/services/sso/),
- [offizielle OpenAPI-Spezifikation](https://esi.evetech.net/meta/openapi.json).

## Build und Tests

- fokussiert: **37 eindeutige P40-Tests** über zwei Läufe bestanden
  (33/33 sowie die erweiterte Client-Suite 9/9),
- vollständig:
  `swift test --disable-sandbox --scratch-path
  .build-p40-full-unsandboxed --jobs 2` – **583/583 bestanden**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination 'platform=macOS,arch=arm64'
  -derivedDataPath .build-p40-xcode-unsandboxed
  CODE_SIGNING_ALLOWED=NO build` – **BUILD SUCCEEDED**,
- Projektprüfung: 16 Targets, 8 Testtargets, 2 gemeinsame Schemes.

Die Dateisandbox blockierte zunächst drei Security.framework-RSA-Fixtures
und den SwiftData-Makroserver. Außerhalb dieser Einschränkung bestanden
derselbe Test- und Quellstand vollständig. Ein im Dateistore-Test
aufgedeckter unzulässiger Foundation-Optionsmix wurde korrigiert und erneut
geprüft.

## Review

Geprüft wurden tatsächlicher Diff, Scope-Minimierung, Tokenlebenszyklus,
URL-/Headergrenzen, Pagination, Cachekonsistenz, Ressourcenlimits,
Vorschau-vor-Schreiben, Stale-Preview-Schutz, atomare Aktivierung,
Bestandsschutz, Trennen, Build, Tests und Dokumentation.

Entscheidung: **✅ bestanden**. `OFF-010` und `KI-010` sind geschlossen;
`OFF-021` bleibt als allgemeines Bedarfsgate bestehen, da P40 keinen
zusätzlichen SDE-Blindimport einführt.

## Manuelle Prüfung und offene Anforderungen

Kein persönlicher Live-ESI-Abruf wurde im Namen des Eigentümers ausgeführt.
Beim ersten Einsatz muss der Eigentümer den Charakter erneut verbinden und
die drei Leseberechtigungen bestätigen. Dies ist eine bewusste
Benutzerhandlung, kein offener Codefehler.

P41 wurde nicht begonnen. Nächster empfohlener Schritt ist ein Nutzenreview
für P41; Implementierung nur auf ausdrücklichen Auftrag. Es gab keinen
Commit und keinen Push.
