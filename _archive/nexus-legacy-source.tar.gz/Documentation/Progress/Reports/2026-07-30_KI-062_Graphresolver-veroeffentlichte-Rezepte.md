# KI-062 – Graphresolver und veröffentlichte Rezepte

Datum: 2026-07-30  
Status: ✅ technisch und sichtbar bestanden

## Ziel und Ursache

`NEN-GRAPH-001` beim Projekt `Module für DOC` reproduzieren und mit der
kleinsten fachlich belegten Resolverkorrektur beheben.

Der aktive SDE-Build 3.448.696, das Projektziel und der Blueprint waren
konsistent. Die reale Diagnose auf einer temporären Storekopie ergab:

```text
intermediateRecipeResolutionFailed(
  productTypeID: 16672,
  ambiguousRecipe(candidateBlueprintTypeIDs: [45732, 46207])
)
```

Blueprint 45732 ist der unveröffentlichte `Test Reaction Blueprint`;
Blueprint 46207 ist die veröffentlichte
`Tungsten Carbide Reaction Formula`.

## Änderung

- Implizite Auswahl verwendet vorhandene veröffentlichte Kandidaten für die
  Eindeutigkeitsprüfung.
- Ein einziger veröffentlichter Kandidat wird gewählt.
- Mehrere veröffentlichte Kandidaten bleiben blockiert.
- Eine explizite Blueprint-ID wird niemals durch einen anderen Kandidaten
  ersetzt; explizit gewählte unveröffentlichte Blueprints bleiben ungültig.
- Drei deterministische Regressionstests schützen implizite Auswahl,
  explizite Nichtsubstitution und unveröffentlichte explizite Auswahl.

Keine Datenbank-, Migrations-, Signing- oder Benutzerdatenänderung.

## Nachweise

- Reproduktion vor Korrektur auf konsistenter temporärer Storekopie:
  `NEN-GRAPH-001`, Type 16672, Kandidaten 45732/46207.
- Derselbe reale temporäre Datenstand nach Korrektur:
  **566 Knoten, 565 Kanten**, vollständige Graphgenerierung.
- Fokussierte Resolver-, Graph-, Persistenz- und T2-Tests:
  **44/44 bestanden**.
- Apple-Development-signierter arm64-Xcode-Debugbuild:
  **BUILD SUCCEEDED**.
- `git diff --check`: bestanden.

## Review

✅ Technisch bestanden. Die Änderung nutzt ausschließlich die offizielle
`published`-Eigenschaft und erfindet keine Rezeptpriorität. Bestehende echte
Mehrdeutigkeits-, Unresolved-, Versions- und Abbruchgrenzen bleiben erhalten.

## Offen

Kein KI-062-Punkt offen. Der Projekteigentümer bestätigte am 2026-07-30 nach
dem neuen Build, dass der Produktionsgraph wieder erzeugt werden kann.
OFF-061 bleibt als getrenntes Budget-, Chargen-, Kosten- und Verkaufsgate
offen.
