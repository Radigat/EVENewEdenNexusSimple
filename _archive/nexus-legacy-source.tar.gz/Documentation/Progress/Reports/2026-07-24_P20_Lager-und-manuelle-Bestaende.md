# Abschlussbericht – P20: Lager und manuelle Bestände

Datum: 2026-07-24  
Prompt-ID: P20  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

P20 vollständig spezifizieren und lokale logische Lager sowie manuelle,
kataloggebundene Bestandsmengen migrationssicher in Domain, Application,
Persistenz und nativer macOS-Oberfläche umsetzen. CSV-Import,
Verfügbarkeit, Schutzbestände und Reservierungen durften nicht vorgezogen
werden.

## Ausgangszustand

- Schema v9 enthielt keine Lager- oder Bestandsentitäten.
- `Assets` war ein Platzhalter.
- Es gab keine Lager-/Bestandsdomäne, keinen Application-Service und keinen
  Repository-Port.
- OFF-005/KI-005 umfassten den gesamten Block P20–P25.
- Der Arbeitsbaum enthielt uncommittete und untracked Änderungen aus
  P09B–P19. Sie wurden erhalten; es erfolgte kein Commit, Push, Reset,
  Rebase oder Merge.

## Durchgeführte Änderungen

- vollständige P20-Spezifikation mit zwölf messbaren Abnahmekriterien,
- Domainmodelle und Validierungsfehler für Lager und Bestände,
- `InventoryManaging`, `InventoryRepository` und
  `InventoryManagementService`,
- Katalogprüfung veröffentlichter Items und gespeicherte SDE-Provenienz,
- normalisiert eindeutige Lagernamen,
- eindeutige Bestandsidentität je Lager und CCP-Type-ID,
- reversible Archivierung und Schreibschutz archivierter Lager,
- positives `Int64`-Mengenmodell mit Update-statt-Addition,
- positionsgenaues Löschen hinter ausdrücklicher UI-Bestätigung,
- SwiftData-Schema v10 und leichte v9→v10-Migration,
- Backupformat 10.0.0 und Kompatibilität 1.0.0 bis 10.0.0,
- native Lager-/Bestandsansicht mit ViewModel und separaten Editoransichten,
- zentrale Inventory-Fehlercodes,
- 14 neue Tests und regeneriertes Xcode-Projekt,
- vollständige Status-, Architektur-, Test- und Fortschrittsdokumentation.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/Inventory.swift`
- `Sources/NewEdenNexusApplication/InventoryManagement.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV10.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataInventoryRepository.swift`
- `Sources/NewEdenNexus/InventoryAppComposition.swift`
- `Sources/NewEdenNexus/InventoryViewModel.swift`
- `Sources/NewEdenNexus/InventoryView.swift`
- `Sources/NewEdenNexus/InventoryEditorViews.swift`
- `Tests/NewEdenNexusDomainTests/InventoryTests.swift`
- `Tests/NewEdenNexusApplicationTests/InventoryManagementServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/InventoryPersistenceTests.swift`
- `Tests/NewEdenNexusArchitectureTests/InventoryArchitectureTests.swift`
- `Documentation/INVENTORY_MANAGEMENT.md`
- `Documentation/Architecture/ADRs/ADR-0025_Lokale-Lager-und-manuelle-Bestaende.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- App-Composition, Runtime und Root-/Assets-Navigation,
- zentrale Fehlerbehandlung,
- `NexusMigrationPlan`, `NexusModelContainerFactory`,
  `SQLiteLocalBackupService`,
- `project.yml` und generiertes `NewEdenNexus.xcodeproj`,
- P20-Prompt und Promptregister,
- Entwickler-Menü, Projektstatus, Feature-Matrix, Tagebuch,
  OFFEN/OPEN_TASKS/KNOWN_ISSUES, Testhistorie,
  Datenmodell, Architektur und ADR-Register.

## Gelöschte oder verschobene Dateien

Keine. Vorhandene Benutzeränderungen und frühere Arbeitspakete blieben
erhalten.

## Architekturentscheidungen

- lokale manuelle Bestände bleiben von späteren ESI-Assetinstanzen getrennt,
- SwiftUI kennt weder SwiftData-Modelle noch `ModelContext`,
- `(locationID, typeID)` bildet die Bestandsidentität,
- Archivierung ersetzt das harte Löschen von Lagern,
- siehe ADR-0025.

## Datenmodelländerungen

Schema v10 ergänzt additiv `StorageLocationRecord` und
`ManualStockRecord`. Die Migration v9→v10 erzeugt keine fachlichen
Defaultlager und verändert vorhandene SDE-, Projekt-, Graph- oder
Reaktionsdaten nicht. Das Backupmanifest verwendet 10.0.0.

## Build-Ergebnis

| Weg | Konfiguration | Ergebnis |
|---|---|---|
| SwiftPM | Debug | ✅ erfolgreich |
| SwiftPM | Release | ✅ erfolgreich |
| Xcode, Scheme `NewEdenNexus`, Signing aus | Debug | ✅ erfolgreich |
| Xcode, Scheme `NewEdenNexus`, Signing aus | Release | ✅ erfolgreich |

Der Projektcheck bestätigte 15 Targets, sieben Testtargets und zwei
gemeinsame Schemes. Signing- und Teamwerte wurden nicht verändert.

## Testergebnis

| Weg | Konfiguration | Ergebnis |
|---|---|---|
| SwiftPM | Debug | 335 bestanden, 0 Fehler, 0 übersprungen |
| SwiftPM | Release | 335 bestanden, 0 Fehler, 0 übersprungen |
| Xcode | Debug | 335 erfolgreich, 0 Fehler, 0 übersprungen |
| Xcode | Release | 335 erfolgreich, 0 Fehler, 0 übersprungen |

Die Xcode-Result-Datenbanken enthalten je 335 Testfälle und ausschließlich
erfolgreiche Testläufe. `git diff --check` blieb ohne Befund.

## Manuelle Prüfungen

- Git-Wurzel, Branch, Status und uncommittete Änderungen erneut geprüft,
- generiertes Xcode-Projekt gegen `project.yml` geprüft,
- P20-UI-Quellen auf Loading-, Empty-, Error-, Fortschritts-,
  Archivierungs- und Löschbestätigungszustände geprüft,
- Schichtengrenzen auf fehlenden SwiftData-Zugriff aus der UI geprüft,
- alle aktiven OFFEN-/KNOWN_ISSUES-Einträge erneut zugeordnet.

Keine neue visuelle VoiceOver-Sitzung wurde durchgeführt. Die vollständige
Bedien- und Accessibility-Abnahme bleibt P35/P37.

## Bekannte Probleme

- Keine durch P20 verursachte kritische Regression.
- Die eingeschränkte Ausführungsumgebung erlaubte keine benutzerweiten
  SwiftPM-Caches; isolierte Cachepfade wurden verwendet.
- SwiftData-Makro-Plugins erforderten für Xcode die freigegebene Ausführung
  außerhalb der Dateisandbox.
- Lokal ausgelagerte iCloud-Dateien mussten nach einer Bereinigung erneut
  geladen werden; Inhalte wurden nicht verändert.

## Offene Anforderungen

- P21: CSV-Bestandsimport mit Prüfung, Detailvorschau und Bestätigung,
- P22: Verfügbarkeit und Ausschlüsse,
- P23: Mindest-, Ziel- und Warnbestände,
- P24/P25: Reservierungen und Konflikte,
- P34/P36/P37: unabhängige Performance-, Recovery- und Releasegates.

OFF-005/KI-005 bleiben deshalb **teilweise** offen; ihr P20-Anteil ist
erledigt.

## Abweichungen vom Projektbuch

Das Projektbuch beschreibt auch ESI-Assets, Containerhierarchien und
virtuelle Lager. Entsprechend dem reduzierten MVP implementiert P20 nur
lokale logische Lager und manuelle aggregierte Mengen. Diese Abgrenzung ist
bewusst und in ADR-0025 dokumentiert.

## Abnahmekriterien

| Nr. | Ergebnis | Nachweis |
|---:|---|---|
| 1 | ✅ | Lagerlebenszyklus in Service, Repository und UI |
| 2 | ✅ | Domain-/Service-/Persistenztests für Namen |
| 3 | ✅ | veröffentlichte Katalogitems und positive Mengen |
| 4 | ✅ | Fehlerfälle für IDs, Veröffentlichung, Mengen und Parsing |
| 5 | ✅ | Update-statt-Duplikat und getrennte Lager |
| 6 | ✅ | Archivbestand und Schreibschutz |
| 7 | ✅ | bestätigte, positionsgenaue Löschung |
| 8 | ✅ | v10-Leerstore und befüllte v9→v10-Migration |
| 9 | ✅ | Backup 10.0.0, Altversionen und Ablehnung 11.0.0 |
| 10 | ✅ | vier vollständige grüne Build-/Testläufe |
| 11 | ✅ | alle Pflichtdokumente aktualisiert |
| 12 | ✅ | gesonderter Review bestanden |

## Reviewentscheidung

Der Kontrollschritt verglich Spezifikation, Code, Tests, Migration,
Backupgrenze, UI-/Schichtengrenzen, offene Punkte, vier Abschlussläufe und
Dokumentation. Keine notwendige P20-Anforderung blieb offen.

**Entscheidung: ✅ bestanden.**

## Nächster empfohlener Prompt

**P21 – CSV-Bestandsimport vollständig spezifizieren und anschließend
ausführen.** P21 wurde nicht begonnen.

