# Abschlussbericht – P07B: Aktuelle Real-SDE-Abnahme

Datum: 2026-07-23  
Prompt-ID: P07B  
Status: **⚠️ teilweise/blockiert**  
Reviewentscheidung: **⚠️ mit Einschränkungen bestanden**

## Ziel

Nach ausdrücklicher persönlicher Bestätigung der aktuellen CCP-Bedingungen
den aktuellen offiziellen SDE-Build vollständig und isoliert herunterladen,
sicher prüfen, importieren, aktivieren, erneut öffnen, abfragen,
speichervermessen und bereinigen. P07C wird nicht begonnen.

## Ausgangszustand

- P07B-Technikkern mit offiziellem Downloadpfad, ZIP-Schutz, Stagingstore,
  Backup, Promotion, Rollback und Journal war implementiert.
- Debug und Release jeweils 145 Tests, 0 Fehler.
- Eigentümerentscheidung, reale Kontaktangabe und aktueller Real-SDE-Lauf
  fehlten.
- `JSONLinesSDECatalogMapper` erzeugte weiterhin einen vollständigen
  `StaticDataCatalogSnapshot`; ein aktuelles Speicherprofil fehlte.
- Branch `main`; alle Projektdateien waren bereits untracked. Nichts wurde
  gestaged, committed, gepusht oder verworfen.

## Persönliche und rechtliche Grenze

Der Projekteigentümer erklärte am Ausführungstag ausdrücklich, die aktuellen
CCP-Bedingungen selbst geprüft zu haben, und autorisierte den offiziellen
SDE-Download. Eine reale Kontaktangabe wurde für den User-Agent bereitgestellt.

Die Kontaktangabe:

- wurde ausschließlich zur Laufzeit über verdeckte Standardeingabe übergeben,
- steht nicht im Quellcode, in Befehlen, Dokumentation oder Journalen,
- wurde nach dem Lauf nicht in Abnahmeartefakten gefunden.

Eine zusätzlich genannte Accountbezeichnung wurde nicht benötigt, nicht
verwendet und nicht gespeichert. Dies ist keine Rechtsberatung und keine
Behauptung einer CCP-Genehmigung.

## Offizielle Quellen

Am 2026-07-23 erneut geprüft:

- `https://developers.eveonline.com/license-agreement`
- `https://developers.eveonline.com/docs/services/static-data/`
- `https://developers.eveonline.com/static-data/tranquility/latest.jsonl`
- `https://developers.eveonline.com/static-data/tranquility/schema-changelog.yaml`
- versioniertes offizielles JSONL-Archiv für Build 3444265.

Ergebnis:

- Build `3444265`,
- Release `2026-07-23T11:06:22Z`,
- höchster Schema-Changelog-Eintrag `3407448`,
- Archiv HTTP 200, `application/zip`, 98.707.648 Bytes,
- keine Weiterleitung und kein Spiegel.

## Durchgeführte Änderungen

### Opt-in Abnahmerunner

Das neue SwiftPM-Executable `NewEdenNexusSDEAcceptance`:

- verlangt `NEN_SDE_OWNER_ACCEPTED=YES`,
- verlangt positiven Build und geprüften Schemastand,
- akzeptiert den Kontakt zur Laufzeit,
- verdrahtet ausschließlich vorhandene P07B-Ports,
- verwendet einen isolierten temporären Store,
- erzwingt Sicherheitsbackup, Terminaljournal und Cleanup,
- öffnet den Store erneut,
- fragt Rifter und Blueprint 691 ab,
- prüft fachliche Mindestmengen,
- entfernt nach Erfolg alle Abnahmeartefakte.

Es ist nicht in den produktiven App-Start eingebunden.

### Recoverytest

Der Application-Test simuliert einen Neustart nach jeder persistenten
Installationsphase von `started` bis `promoting` und prüft:

- vorherige aktive Version bleibt nutzbar,
- genau ein Vorgang wird wiederhergestellt,
- Cleanup ist erfolgreich,
- Journal endet in `recovered`.

## Neu erstellte Dateien

- `Sources/NewEdenNexusSDEAcceptance/main.swift`
- dieser Abschlussbericht.

## Geänderte Dateien

- `Package.swift`
- `Tests/NewEdenNexusApplicationTests/SDEInstallationServiceTests.swift`
- `Documentation/ARCHITECTURE.md`
- `Documentation/ARCHITECTURE_CHANGES.md`
- `Documentation/CCP_COMPLIANCE.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/FEATURE_MATRIX.md`
- `Documentation/IMPLEMENTATION_ROADMAP.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/Prompts/README.md`
- `Documentation/Prompts/MVP/P07B_SDE-Download-Archiv-Aktivierung.md`
- `Documentation/SDE_ARCHIVE_INSTALLATION.md`
- `Documentation/TEST_HISTORY.md`

## Gelöschte oder verschobene Dateien

Keine Projektdateien. Das erste 210-MB-Abnahmeverzeichnis und alle Artefakte
des zweiten Laufs wurden nach erfolgreicher Prüfung vollständig entfernt.

## Architekturentscheidungen

- Realabnahme als getrenntes opt-in Executable statt produktiver
  Startverdrahtung,
- Kontakt nur zur Laufzeit, keine Persistenz,
- produktive Datenbank niemals als Teststore,
- identische fachliche Prüfpunkte für wiederholbare Realabnahmen,
- gemessenen Speicherverbrauch nicht als bestandene Streaminggrenze
  umdeuten.

## Datenmodelländerungen

Keine. Schema v4 und alle Migrationen bleiben unverändert.

## Real-SDE-Ergebnis

Beide Läufe lieferten:

| Datenbereich | Anzahl |
|---|---:|
| Kategorien | 48 |
| Gruppen | 1.609 |
| Itemtypen | 52.821 |
| Blueprints | 5.082 |
| Aktivitäten | 19.137 |
| Materialien | 36.499 |
| Produkte | 6.329 |
| Nicht aufgelöste Typreferenzen | 21 |

Inhaltshash:
`3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`.

Rifter (Type-ID 587), Blueprint 691, Aktivbuild, Hash und Mengen waren nach
Wiederöffnung konsistent.

## Speicher- und Laufzeitmessung

| Lauf | Fachliche Laufzeit | Peak-RSS | Peak Memory Footprint |
|---|---:|---:|---:|
| 1 | 34,10 s | 2.454.126.592 Bytes | 2.222.164.416 Bytes |
| 2 | 32,55 s | 2.448.506.880 Bytes | 2.213.284.264 Bytes |

Die Messung ist reproduzierbar und zeigt, dass Snapshot-Mapping und
nachgelagerte Persistenz noch nicht durchgängig blockweise sind.

## Build-Ergebnis

- Release-Produkt `NewEdenNexusSDEAcceptance`: erfolgreich,
- vollständiger Debug-Coverage-Build: erfolgreich,
- vollständiger Release-Build: erfolgreich.

Verwendet wurden isolierte Modulcaches und Scratch-Verzeichnisse unter
`/private/tmp`. Signing- oder Team-Einstellungen wurden nicht verändert.

## Testergebnis

- fokussierte `SDEInstallationServiceTests`: 4 Tests, 0 Fehler,
- Debug mit Coverage: 146 Tests, 0 Fehler,
- Release: 146 Tests, 0 Fehler,
- keine übersprungenen XCTest-Tests,
- Produktquellcode-Coverage: 72,98 %,
- fünf Architekturgrenztests erfolgreich.

## Manuelle Prüfungen

- aktueller Build- und Schema-Endpunkt,
- direkter Archivkopf,
- zwei vollständige Real-SDE-Läufe,
- Wiederöffnung und Rifter-/Blueprintabfrage,
- kein persistierter Kontakt-/Accountwert,
- kein verbleibendes Realabnahmeverzeichnis,
- Git-Status und untracked Benutzerbestand unverändert erhalten.

## Bekannte Probleme

- Peak-RSS rund 2,45 GB durch vollständige Snapshot-Materialisierung,
- große P07B-Quelldateien bleiben als Wartbarkeitsschuld,
- tatsächlicher Prozessabbruch/App-Neustart folgt P36,
- produktive Startverdrahtung und Rechts-/Einstellungsoberfläche fehlen.

## Abweichungen vom Projektbuch

Keine neue fachliche Abweichung. Der bedarfsgesteuerte Import der vier für den
MVP benötigten Datensätze bleibt bewusst kleiner als das langfristige
SDE-Zielbild.

## Abnahmekriterien

Erfüllt:

- persönliche Owner-Entscheidung,
- reale Kontaktkonfiguration ohne Persistenz,
- ausschließlich offizieller aktueller Download,
- ZIP-Sicherheitsprüfung und isolierte Extraktion,
- Streamingvalidierung der JSONL-Quelldateien,
- isolierter Store, Backup, Aktivierung und Rollbackgrenzen,
- Wiederöffnung, Katalogabfrage und Cleanup,
- automatisierter Wiederanlauf an jeder persistenten Phase,
- Debug/Release und Dokumentation.

Nicht erfüllt:

- vollständiges Mapping/Persistieren ohne Gesamtmaterialisierung,
- deutlich geringerer Low-Memory-Realnachweis.

## Reviewentscheidung

**⚠️ mit Einschränkungen bestanden.**

Der reale Pfad ist funktional, sicher und reproduzierbar. P07B darf dennoch
nicht `✅` werden, weil der gemessene Peak-RSS die verbindliche blockweise
Verarbeitungsgrenze widerlegt.

## Nächster empfohlener Prompt

P07B-Speichergrenze schließen: Mapping und Persistenz blockweise umstellen,
Build 3444265 mit identischen Mengen und Hash erneut abnehmen und den Peak-RSS
deutlich reduzieren. P07C wurde nicht begonnen.
