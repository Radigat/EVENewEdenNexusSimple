# Abschlussbericht – P13: Erklärbarer Produktionsgraph

Datum: 2026-07-24  
Prompt-ID: P13  
Status: ✅ erledigt

## Ziel

P13 zunächst vollständig spezifizieren und anschließend einen
deterministischen, erklärbaren, persistierbaren Produktionsgraphen für das
kataloggebundene Projektziel umsetzen. P14 und spätere Berechnungsregeln
durften nicht begonnen werden.

## Ausgangszustand

P10 stellte eindeutige Fertigungs- und Reaktionsrezepte bereit. P11 lieferte
den lokalen Projektlebenszyklus, P12 ein versionsgebundenes Ziel mit Produkt,
Aktivität, Blueprint und Menge in Schema v5. Ein Graphmodell, eine
Graphpersistenz und eine Graphansicht existierten nicht.

Die P13-relevanten Einträge OFF-004/KI-003, OFF-006/KI-006/KI-013,
OFF-009/KI-012, OFF-021/KI-021 und OFF-027/KI-027 wurden in die
Spezifikation aufgenommen und vor Abschluss erneut geprüft.

## Durchgeführte Änderungen

- vollständige P13-Spezifikation mit Scope, Nichtzielen,
  Akzeptanzfällen und Prüfbefehlen,
- unveränderliches Domainmodell für Knoten, Kanten, Rezepte und Snapshot,
- kanonische Sortierung und Validierung von Identität, Rollen, Endpunkten,
  Mengen, Tiefen, Erreichbarkeit und Zyklen,
- Application-Service für die exakt katalog- und blueprintgebundene erste
  Rezeptstufe,
- Aktualitätsprüfung und sicherer Bestandsschutz bei Fehler oder Abbruch,
- additives SwiftData-Schema v6 und Graphrepository,
- Backupformat 6.0.0 mit Kompatibilität 1.0.0 bis 6.0.0,
- eigenständige SwiftUI-Graphansicht mit ViewModel, Zuständen,
  Tastatur- und Accessibility-Metadaten,
- vollständige Domain-, Application-, Persistenz-, ViewModel-,
  Architektur-, Migrations- und Regressionstests,
- technische Dokumentation und ADR.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionGraph.swift`
- `Sources/NewEdenNexusApplication/ProductionGraph.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV6.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionGraphRepository.swift`
- `Sources/NewEdenNexus/ProductionGraphViewModel.swift`
- `Sources/NewEdenNexus/ProductionGraphView.swift`
- `Tests/NewEdenNexusDomainTests/ProductionGraphTests.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionGraphServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ProductionGraphPersistenceTests.swift`
- `Tests/NewEdenNexusTests/ProductionGraphViewModelTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ProductionGraphArchitectureTests.swift`
- `Documentation/PRODUCTION_GRAPH.md`
- `Documentation/Architecture/ADRs/ADR-0018_Erklaerbarer-Produktionsgraph-und-Schema-v6.md`
- dieser Abschlussbericht.

## Geänderte Dateien

Betroffen sind Composition Root, Runtime, Projekt- und Rootansicht, zentrale
Fehlerbehandlung, Migrationsplan, Model-Container, Backupdienst,
Paket-/Xcode-Metadaten, bestehende Runtime-, Fehler-, Persistenz- und
Backuptests sowie die verpflichtenden Projekt- und Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Knotenidentität ist eine Vorkommens-ID, nicht die CCP-Type-ID. Der Graph ist
ein Domain-Snapshot; SwiftData speichert eine kanonische Payload mit
redundanter Integritätsmetadatenprüfung. P13 erzeugt ausschließlich die erste
Rezeptstufe. Details stehen in ADR-0018.

## Datenmodelländerungen

Schema v6 ergänzt additiv `ProductionGraphRecord` mit eindeutiger Projekt-ID,
Graph- und Katalogmetadaten sowie codierter Payload. Die v5→v6-Migration
erhält alle Bestandsdaten und erzeugt eine leere Graphentabelle. Backups
verwenden Schema 6.0.0.

## Build-Ergebnis

Erfolgreich:

```text
swift test --disable-sandbox --scratch-path /private/tmp/nen-p13-final-debug
swift test -c release --disable-sandbox --scratch-path /private/tmp/nen-p13-final-release
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/nen-p13-xcode-review2-debug-escalated
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/nen-p13-xcode-review2-release-escalated
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
```

Die abschließenden Xcode-Tests liefen wegen der bekannten koordinierten
File-Provider-Blockade aus einer unveränderten isolierten Quellkopie unter
`/private/tmp/nen-p13-xcode-review2`. Signing- und Teamwerte wurden nicht
geändert. Debug und Release endeten jeweils mit Exitcode 0. Der
Release-Compiler meldete vorübergehend fehlende Module-Cache-Dateien; Build
und Tests wurden dennoch erfolgreich abgeschlossen.

SwiftPM deaktivierte wegen der Sandbox seine nicht beschreibbaren
Benutzer-Caches und Core Data meldete bei temporären Teststores, dass
verteilte Store-Change-Benachrichtigungen nicht registriert werden konnten.
Xcode wählte bei zwei passenden My-Mac-Architekturen nachvollziehbar arm64.
Keine dieser Warnungen verursachte einen Fehler oder übersprungenen Test.

## Testergebnis

- SwiftPM Debug: 238 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 238 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: alle sieben konfigurierten Testtargets bestanden.
- Xcode Release: alle sieben konfigurierten Testtargets bestanden.
- Projektprüfung: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
- `git diff --check`: bestanden.

## Manuelle Prüfungen

Das abschließend gebaute isolierte Debug-App-Binary blieb mehr als fünf
Sekunden stabil aktiv und erzeugte
einen neuen Schema-v6-Store. `PRAGMA integrity_check` ergab `ok`; genau eine
Produktionsgraphtabelle war vorhanden. Der Prozess wurde anschließend
kontrolliert beendet.

Eine zusätzliche visuelle Accessibility-Prüfung konnte wegen einer
geschlossenen Computer-Use-Transportverbindung nicht ausgeführt werden.
Deshalb wird für P13 kein neuer Screenshot- oder VoiceOver-Manuallauf
behauptet. UI-Kompilation, Zustände, Beschriftungen und Schichtengrenzen sind
automatisiert geprüft.

## Bekannte Probleme und offene Anforderungen

- OFF-004/KI-003 ist teilweise erledigt: Graphbasis und erste Rezeptstufe
  stehen; Runs, ME und rekursive T1-/T2-/Reaktionsketten folgen P14–P18,
  Aggregation und Schutzgrenzen P19.
- OFF-006/KI-006/KI-013 bleibt teilweise: additive v5→v6-Migration und
  Backupkompatibilität sind geprüft; automatische Vor-Migrations-Sicherung
  und echter Recovery-Drill bleiben P36.
- OFF-009/KI-012 bleibt für die spätere Mengenaggregation P19 offen.
- OFF-021/KI-021 bleibt bedarfsgesteuert; P13 benötigte keine weiteren
  SDE-Datensätze.
- OFF-027/KI-027 bleibt P34 zugeordnet. Die neue Graphansicht liegt bereits
  in einer eigenen Datei und vergrößert den Projekteditor nicht um die
  Graphdarstellung.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. Der Gesamtgraph aus dem Projektbuch wird
inkrementell über P13 bis P19 geliefert. P13 setzt nur die ausdrücklich
abgegrenzte erklärbare Graphbasis um.

## Abnahmekriterien

- vollständig spezifizierter Prompt: erfüllt,
- Graphdomain und erste Rezeptstufe: erfüllt,
- deterministische Topologie und typisierte Validierung: erfüllt,
- persistenter Schema-v6-Snapshot: erfüllt,
- Bestandsschutz bei Fehlern: erfüllt,
- SwiftUI-Anbindung ohne Persistenzzugriff aus Views: erfüllt,
- Migration, Backup, Debug/Release und relevante Tests: erfüllt,
- offene Punkte und Pflichtdokumentation aktualisiert: erfüllt,
- P14 nicht begonnen: erfüllt.

## Reviewentscheidung

✅ bestanden.

Der gesonderte Review prüfte Spezifikation, tatsächlichen Diff,
Schichtengrenzen, Domaininvarianten, Fehler- und Abbruchpfade,
v5→v6-Bestandsschutz, Backupgrenzen, UI-Metadaten, alle vier
Build-/Testkonfigurationen und die Dokumentation. Dabei wurden zwei Befunde
vor Abschluss korrigiert:

1. Die Zyklusdiagnose wird nun vor der Tiefenkonsistenz geprüft.
2. Die Graphansicht zeigt zusätzlich Aktivität, Produktionszeit und Tiefe.
3. Das SwiftData-Repository rollt bereits angewendete In-Memory-Änderungen
   bei Cancellation oder Savefehler explizit zurück.

Der anschließende vollständige Debug-/Release-Nachweis bestand.

## Nächster empfohlener Prompt

P14 zunächst vollständig spezifizieren und anschließend ausführen. Dabei
sind alle für Runs und Ausgabemengen notwendigen offenen Punkte erneut
verbindlich aufzunehmen. P14 wurde in P13 nicht begonnen.
