# Abschlussbericht P04 – Fehlerbehandlung und Logging

- **Prompt-ID:** P04
- **Datum:** 2026-07-23
- **Status:** ✅ erledigt
- **Review:** ✅ bestanden

## Ziel

Eine zentrale, verständliche und datenschutzgerechte Fehler- und Diagnosegrundlage schaffen. Datenbankstartfehler und bestehende lokale Schreibfehler sollten ohne Absturz, stille Fehlerunterdrückung, Datenbankreset oder Offenlegung technischer Rohdaten behandelt werden.

Zusätzlich sollte `Documentation/OFFEN.md` als dauerhafte, bei jedem Prompt erneut zu prüfende Restpunkteliste eingeführt werden.

## Ausgangszustand

P03 war mit 26 Tests abgeschlossen. Der App-Start verwendete bei einem Containerfehler `fatalError`. Projektanlage, Charakterlöschung und simulierter Synchronisationsstatus verwendeten `try? modelContext.save()`. Die Accountansicht zeigte direkt `error.localizedDescription`. Ein Logger-Port, Unified-Logging-Adapter, verbindliche Redaktionsregeln und ein zentrales Fehlerzentrum fehlten.

Git-Wurzel, Branch und untracked Zustand blieben unverändert: Root `/Users/svenstolze`, Branch `main`, keine Commits, Projektdateien untracked. Es wurde nichts gestaged, committed, verworfen oder außerhalb des Projektordners verändert.

## Durchgeführte Änderungen

- P04 vollständig spezifiziert.
- UI-unabhängige Fehlertaxonomie mit acht Operationen und stabilen Diagnosecodes implementiert.
- sichere UI-Präsentationen vom technischen Rohfehler getrennt.
- strukturierte Diagnoseereignisse, Level, Kategorien, Korrelations-ID und typisierte Metadaten eingeführt.
- `DiagnosticLogging` als `Sendable`-fähigen Application-Port erstellt.
- `UnifiedDiagnosticLogger` als OSLog-Adapter in Infrastructure implementiert.
- `NexusAppRuntime` als injizierte zentrale Start- und Fehlergrenze erstellt.
- Startfehleransicht mit sicherem Text, Diagnosecode und Retry eingebaut.
- zentralen Laufzeitfehler-Alert am Root-View ergänzt.
- aktuelle SwiftData-Speicherpfade auf `do/catch`, Rollback und zentrale Meldung umgestellt.
- Keychain-Ersetzen auf `SecItemUpdate` ohne vorheriges Löschen und alle Löschpfade auf ausgewertete OSStatus-Fehler umgestellt.
- Application-, Runtime-, Source- und Architekturtests ergänzt.
- Fehler-/Loggingdokumentation, ADR-0004 und fortlaufendes OFFEN-Audit erstellt.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusInfrastructure/UnifiedDiagnosticLogger.swift`
- `Sources/NewEdenNexus/NexusAppRuntime.swift`
- `Sources/NewEdenNexus/ErrorPresentation.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `Documentation/ERROR_HANDLING_AND_LOGGING.md`
- `Documentation/OFFEN.md`
- `Documentation/Architecture/ADRs/ADR-0004_Zentrale-Fehler-und-Diagnosegrenze.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Sources/NewEdenNexus/ProjectsView.swift`
- `Sources/NewEdenNexus/AccountsView.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Sources/NewEdenNexus/KeychainStore.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- `AGENTS.md`
- Architektur-, ADR-, Status-, Roadmap-, Feature-, Prompt-, Tagebuch-, Problem- und Testdokumentation.

## Gelöschte oder verschobene Dateien

Keine.

## Fehlertaxonomie

| Operation | Code | Kategorie |
|---|---|---|
| App-Start | `NEN-PER-001` | lifecycle |
| Projekt speichern | `NEN-PER-002` | projects |
| Charakter speichern | `NEN-PER-003` | persistence |
| Charakter löschen | `NEN-PER-004` | persistence |
| Synchronisationsstatus speichern | `NEN-PER-005` | synchronization |
| Authentifizierung | `NEN-AUTH-001` | authentication |
| Keychain-Löschung | `NEN-AUTH-002` | authentication |
| unerwartet | `NEN-GEN-001` | general |

`NexusFailureMapper` erzeugt sichere Titel, Beschreibungen und Handlungsempfehlungen. Der ursprüngliche Fehlertext wird nicht übernommen. Der technische Typname dient als einzige automatische Fehlermetadatenquelle.

## Loggingstruktur und Redaction

`DiagnosticEvent` enthält Level, Kategorie, Ereignisname, Code, Operation, Korrelations-ID und sortierte Metadaten.

`DiagnosticValue` unterscheidet:

- `.publicValue` für bewusst sichere technische Werte,
- `.privateValue` für Inhalte, die ausschließlich als `<redacted>` gerendert werden.

`UnifiedDiagnosticLogger` verwendet:

- Subsystem `de.newedennexus.app`,
- die Ereigniskategorie als OSLog-Kategorie,
- `.info`, `.warning` oder `.error`,
- ausschließlich `redactedDescription` als öffentliche OSLog-Zeile.

Nicht protokolliert werden Tokens, Passwörter, Secrets, Authorization Codes, PKCE-Verifier, Serverantworten, Namen, Notizen, freie Texte, vollständige Pfade oder `localizedDescription`.

## Startfehler und Retry

`NexusAppRuntime` besitzt `loading`, `ready(ModelContainer)` und `failed(NexusFailure)`. Die Containerfactory ist injiziert.

Bei einem Startfehler:

1. wird ein sicherer `NexusFailure` erzeugt,
2. genau ein Diagnoseereignis ausgegeben,
3. die Startfehleransicht gezeigt,
4. ein erneuter Öffnungsversuch angeboten.

Der Retry-Test lässt die Factory einmal fehlschlagen und danach einen In-Memory-Container liefern. Es gibt keinen `fatalError`, keinen Store-Reset und keinen Leerstore-Fallback.

## Korrigierte Fehlerpfade

- Projektanlage: Rollback und Alert; Sheet schließt nur nach erfolgreichem Save.
- Charakteranlage/-änderung: Rollback und sicherer Alert.
- Charakterlöschung: Keychainfehler und SwiftDatafehler werden getrennt gemeldet; SwiftData rollt zurück.
- Synchronisationsstatus: Rollback und sicherer Alert.
- Accountverbindung: keine direkte Anzeige von `localizedDescription`.
- Keychain: vorhandene Werte werden atomar mit `SecItemUpdate` ersetzt; `errSecItemNotFound` ist beim Löschen idempotenter Erfolg, andere Statuswerte werden geworfen.

Ein statischer Regressionstest scannt das produktive App-Target und verbietet `fatalError(` sowie `try? modelContext.save()`.

## Architekturentscheidungen

ADR-0004 entscheidet:

- sichere Fehler- und Diagnosetypen in Application,
- OSLog nur im Infrastructure-Adapter,
- zentrale injizierte App-Runtime,
- kein globaler Logger,
- keine Rohfehler in UI oder Logs,
- keine Store-Reparatur durch Löschen oder Ersatz.

## Datenmodelländerungen

Keine. Schema v1 und der Migrationsplan bleiben unverändert. Alle acht P03-Persistenztests sind weiterhin erfolgreich.

## Build-Ergebnis

Abschlussbefehle:

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Ergebnis:

- Targetgraph bestätigt,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen in den erfolgreichen Abschlussläufen.

Ein vorangestellter Sandboxversuch von `swift package describe` scheiterte am gesperrten Swift-/Clang-Cache. Derselbe Befehl wurde mit freigegebenem Cachezugriff erfolgreich ausgeführt; der Umgebungsfehler wurde nicht als Projektfehler verschleiert.

## Testergebnis

**34 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler.**

- 5 Architekturtests,
- 3 Application-Fehler-/Redaction-Tests,
- 12 Domain-/Berechnungstests,
- 8 Persistenz-/Migrations-/Repositorytests,
- 6 App-/Runtime-/Integrationsregressionstests.

Der Secret-Sentinel `SECRET-SENTINEL-DO-NOT-EXPOSE` erscheint weder in sicheren UI-Texten noch in der gerenderten Diagnose. Private Metadaten werden nachweislich als `<redacted>` ausgegeben.

## Manuelle Prüfungen

- P04-Quellcode und alle veränderten App-Fehlerpfade vollständig gelesen,
- Targetgraph und Abhängigkeitsrichtungen geprüft,
- nach `fatalError`, `try?`, direkter Loggernutzung und ungefilterten UI-Rohfehlern gesucht,
- bestätigt, dass Application OSLog-/UI-frei bleibt,
- bestätigt, dass Infrastructure keine UI-, SwiftData-, Network- oder Security-Imports besitzt,
- bestätigt, dass kein Store gelöscht oder als Fallback ersetzt wird,
- alle aktiven `OFFEN.md`-Einträge gegen Code, Tests oder Dokumentation erneut geprüft,
- Status-, Testzahlen und Markdownverweise gegeneinander geprüft.

## OFFEN-Audit

`Documentation/OFFEN.md` ist angelegt und über `AGENTS.md` für jeden künftigen Implementierungsprompt verpflichtend.

- `OFF-007` ist erledigt: kein Start-`fatalError`, kein aktuelles `try? modelContext.save()`, keine direkte Raw-Fehleranzeige.
- `OFF-001` bis `OFF-006` und `OFF-008` bis `OFF-012` wurden erneut geprüft und bleiben mit aktualisiertem Nachweis offen, teilweise oder verschoben.
- `OFF-013` dokumentiert die fehlende gemeinsame Keychain-/SwiftData-Transaktion.
- `OFF-014` übernimmt die weiterhin offene Xcode-Workspace-Grenze.

Erledigte Punkte bleiben als Historie in der Datei erhalten.

## Bekannte Probleme

- Keychain und SwiftData sind nicht gemeinsam atomar; P38 muss Kompensation definieren.
- vorhandene Views nutzen SwiftData für Fachzugriffe weiterhin direkt.
- vollständige Lokalisierung und manuelle UI-/Accessibility-Prüfung fehlen.
- Backup/Restore fehlt.
- Git-Wurzel und `.gitignore` sind unverändert problematisch.
- der fachliche Produktionsplaner-MVP fehlt weiterhin weitgehend.

## Offene Anforderungen

Alle aktiven Punkte stehen mit Prüfnachweis und Zielprompt in `Documentation/OFFEN.md`. Für den unmittelbaren technischen Ablauf folgen P05 Testfundament und P06 Backup/Restore.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. Projektbuch 20.10 verlangt strukturiertes Logging, 20.11 verständliche Fehlermeldungen und Schutz vor Datenverlust. P04 setzt dafür die lokale Grundlage um. Automatische Wiederholungen temporärer ESI-Fehler bleiben absichtlich in den späteren ESI-Prompts.

## Nicht ausgeführte Prüfungen

- keine manuelle App-GUI- oder UI-Automationsprüfung,
- kein echter SSO-/Netzwerkdurchlauf,
- kein Auslesen des macOS-Unified-Log-Streams,
- kein Performance- oder Accessibility-Test,
- kein Backup-/Restore-Test,
- keine produktive Datenbank und keine realen Tokens.

Diese Prüfungen werden nicht als bestanden dargestellt und blockieren den begrenzten P04-Auftrag nicht.

## Review

### Umfang

Geprüft wurden vollständiger P04-Prompt, aktueller Quellcode, Datenschutzgrenzen, Targetarchitektur, Start- und Schreibfehlerpfade, Build-/Testausgaben, Dokumentation und alle OFFEN-Einträge.

### Befunde

- **Kritisch:** keine.
- **Hoch:** keine.
- **Mittel:** keine offene P04-Mussanforderung.
- **Dokumentierte Folgegrenze:** Keychain/SwiftData nicht gemeinsam atomar; bereits als `OFF-013` P38 zugeordnet.

### Entscheidung

**✅ bestanden.** Alle P04-Musskriterien sind durch Code, Debug-/Release-Build, 34 erfolgreiche Tests, Secret-Sentinel-/Redaction-Nachweis, sichere Runtime-Fehlerführung, aktualisierte Dokumentation und OFFEN-Audit belegt.

## Erfüllte Abnahmekriterien

- P04 vollständig spezifiziert und implementiert,
- zentrale Fehlertypen und Logger-Port,
- Unified-Logging-Adapter,
- automatisiert geprüfte Redaction,
- Startfehler ohne Absturz und getesteter Retry,
- aktuelle SwiftData-Speicherfehler sichtbar mit Rollback,
- keine ungefilterte technische Rohmeldung in der UI,
- Keychain-Löschfehler werden nicht ignoriert,
- `OFFEN.md` angelegt und vollständig auditiert,
- Debug-/Release-Build und 34 Tests erfolgreich,
- Dokumentation, ADR und Abschlussbericht vollständig,
- gesonderter Review bestanden.

## Nicht erfüllte Abnahmekriterien

Keine.

## Nächster empfohlener Prompt

P05 – Testfundament und Referenzdaten zunächst vollständig spezifizieren und anschließend getrennt ausführen.
