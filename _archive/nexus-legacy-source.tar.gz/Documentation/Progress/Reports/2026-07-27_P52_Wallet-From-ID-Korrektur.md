# P52 – Wallet-From-ID-Korrektur

Status: ⚠️ technische Korrektur sowie Wallet-Inspect/Apply/Neustart bestanden; UX-Restbefund offen

## Ziel und Befund

Der reale Wallet-Inspect meldete
`inconsistent_pagination_conflicting_transaction`. Die offizielle
CCP-From-ID-Dokumentation bestätigt, dass die mit `from_id` angeforderte
Transaktion auf der Folgeseite erneut enthalten ist.

Die App verglich bislang auch `sourcePage`. Dieses rein lokale
Nachweisfeld unterscheidet sich bei der erwarteten Cursorwiederholung und
erzeugte dadurch einen falschen Konflikt.

## Änderungen

- Wiederholte Transaktions-IDs werden anhand aller fachlichen Nutzdaten
  verglichen, jedoch ohne die lokale `sourcePage`.
- Ein identischer Cursor-Datensatz bleibt genau einmal erhalten.
- Ändert sich ein fachliches Feld bei gleicher Transaktions-ID, wird der
  Import weiterhin mit `conflictingTransaction` abgebrochen.
- Keine Schema-, Migrations- oder Bestandsänderung; keine Walletdaten wurden
  übernommen.

Offizielle Grundlage:
<https://developers.eveonline.com/docs/services/esi/pagination/from-id/>

## Prüfung

- fokussiert `ESIWalletClientTests`: **9/9 bestanden**,
- SwiftPM vollständig außerhalb der Dateisandbox: **646/646 bestanden**,
- signierter Xcode Debug, Scheme `NewEdenNexus`, macOS arm64:
  **BUILD SUCCEEDED**,
- `git diff --check`: **bestanden**.

Die Regressionstests prüfen sowohl die erwartete inklusive
Cursorwiederholung als auch eine echte Nutzdatenabweichung bei gleicher ID.

## Review und offene Abnahme

Technischer Review: **✅ bestanden**. Die Korrektur folgt der offiziellen
Paginationsemantik und lockert den Schutz vor echten Datenkonflikten nicht.

P52/OFF-041: Der Projekteigentümer bestätigte den neuen Build und einen
erfolgreichen Klick auf „Wallet prüfen“. Das Vorschaufenster öffnete sich,
ohne dass `NEN-ESI-004` erneut gemeldet wurde. Der Inspect blieb schreibfrei.
OFF-041/KI-044 sind damit **✅ geschlossen**.

Die Übernahme wurde anschließend ausdrücklich freigegeben. Nach vollständigem
App-Neustart bestätigte der Projekteigentümer den Wallet-Snapshot weiterhin
als vorhanden. Apply und Persistenz sind damit **✅ bestanden**; keine
Walletwerte wurden dokumentiert und keine Projektzuordnung ausgeführt.

P52 bleibt **⚠️**: OFF-042/KI-045 hält das fehlende sichtbare
Übernehmen-/Verwerfen-Feedback fest. Verwerfen entfernt technisch korrekt nur
die aktuelle Vorschau, erklärt aber nicht, dass der gespeicherte Snapshot
erhalten bleibt. Die übrigen P52-Betriebsnachweise bleiben getrennt offen.
P53 wurde nicht begonnen.
