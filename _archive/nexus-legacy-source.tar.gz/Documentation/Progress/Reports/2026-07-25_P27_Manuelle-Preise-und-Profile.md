# Abschlussbericht – P27 Manuelle Preise und Preisprofile

Datum: 2026-07-25  
Prompt-ID: P27  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

Lokale manuelle ISK-Preise in wiederverwendbaren Profilen exakt,
kataloggebunden und persistent verwalten. CSV-Import und wirtschaftliche
Projektkennzahlen waren ausdrücklich nicht Bestandteil.

## Ausgangszustand

P37 hatte den Produktions-/Inventionskern abgenommen. Preise existierten nur
als flacher `Double`-Wert in einem Aggregationstest. Es gab keine
Preisprofile, Gültigkeit, Persistenz, UI oder explizite Auflösung fehlender
Preise. Aktuell waren Schema v15 und Backupformat 15.0.0.

## Durchgeführte Änderungen

- `ISKAmount` als exakter positiver `Int64`-Hundertstelwert einschließlich
  sicherer Punkt-/Kommaparsierung,
- Domainmodelle für Profile, manuelle Preise, Quelle und Preisauflösung,
- Application-Service und Repository-Port für CRUD, Aktivierung, Upsert,
  Löschbestätigung und zeitbezogene Auflösung,
- Validierung gegen veröffentlichte Items der aktiven SDE-Version,
- additives Schema v16 mit `PriceProfileRecord` und `ManualPriceRecord`,
- leichte v15→v16-Migration, Backupformat 16.0.0 und Altformatkompatibilität,
- SwiftData-Repository mit normalisierter Eindeutigkeit, atomarem
  Profilwechsel, Kaskadenlöschung und optimistischem Zustandsschutz,
- Navigationsmodul „Preise“, SwiftData-freies ViewModel und SwiftUI-Ansicht
  mit Loading-, Empty-, Error-, Aktiv- und Bestätigungszuständen,
- zentrale Fehlercodes `NEN-PRICE-001` und `NEN-PRICE-002`.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/PriceProfile.swift`
- `Sources/NewEdenNexusApplication/PriceProfileManagement.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV16.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataPriceProfileRepository.swift`
- `Sources/NewEdenNexus/PriceProfileAppComposition.swift`
- `Sources/NewEdenNexus/PriceProfileViewModel.swift`
- `Sources/NewEdenNexus/PriceProfileView.swift`
- fünf P27-Testdateien in Domain, Application, Persistence, App und Architektur
- `Documentation/PRICE_PROFILES.md`
- `Documentation/Architecture/ADRs/ADR-0033_Exakte-ISK-Preisprofile-und-Schema-v16.md`

## Geänderte Dateien

Navigation, RootView, App-Runtime, Fehlerbehandlung, Migrationsplan,
Containerfactory, Backupdienst, Backup-/Fehlertests, Xcode-Projekt sowie die
verpflichtenden Status-, Architektur-, Feature-, Offen-, Test- und
Tagebuchdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidung

Persistente ISK-Werte verwenden keine binäre Gleitkommazahl. Profile und
Preise liegen hinter Application-Ports; SwiftUI kennt SwiftData nicht.
Fehlende oder zeitlich ungültige Preise bleiben explizit fehlend. Details:
[ADR-0033](../../Architecture/ADRs/ADR-0033_Exakte-ISK-Preisprofile-und-Schema-v16.md).

## Datenmodelländerung

Schema v16 ergänzt ausschließlich zwei neue Tabellen. Die Migration erfindet
keine Profile oder Preise und erhält Projekte, Graphen, Lager,
Reservierungen sowie Build-or-Buy-Daten. Der Backupdienst schreibt 16.0.0
und akzeptiert 1.0.0 bis 16.0.0.

## Build-Ergebnis

- `swift build -c debug`: erfolgreich,
- Xcode Debug, macOS arm64, Signing deaktiviert: erfolgreich,
- Projektparität: 15 Targets, sieben Testtargets, zwei Schemes.

Die ersten sandboxinternen SwiftPM-/Xcode-Aufrufe scheiterten nur an
gesperrten Compiler-Cache- beziehungsweise SwiftData-Makrodiensten. Dieselben
Prüfungen bestanden im freigegebenen Buildpfad.

## Testergebnis

- 13 fokussierte P27-Tests bestanden,
- 453/453 SwiftPM-Debugtests bestanden, 0 übersprungen,
- 453/453 Xcode-Debugtests bestanden, 0 übersprungen,
- v15→v16-Migration, Leerstore, Wiederöffnung, Kaskadenlöschung und Backup
  bestanden.

## Manuelle Prüfungen

Das erzeugte App-Bundle wurde mit einem isolierten Store gestartet. Der
Prozess blieb lauffähig, beide neuen Tabellen waren vorhanden und
`PRAGMA integrity_check` meldete `ok`. Ein manueller visueller
GUI-/VoiceOver-Test wurde nicht durchgeführt und wird nicht behauptet.

## Bekannte Probleme und Risiken

Kein durch P27 verursachter kritischer oder hoher Fehler ist offen.
Appweite Accessibility-/Localization-Politur bleibt P35, der vollständige
Recovery-Drill P36. CSV-Daten können erst mit P28 importiert werden.

## Offene Anforderungen

- P28: CSV-Preisimport,
- P29: Kosten, Erlös, Gewinn, Marge, ROI und Break-even,
- P30/P31: erweiterter Einkaufslistenworkflow,
- P33–P36: Härtung vor öffentlicher Freigabe.

## Abweichungen vom Projektbuch

Keine fachliche Regel wurde erfunden. P27 beschränkt sich bewusst auf
manuelle ISK-Preise. Live-Marktpreise, andere Währungen und automatische
Empfehlungen bleiben außerhalb des Auftrags.

## Abnahmekriterien

Alle P27-Kriterien sind erfüllt: Profil-CRUD, ausdrückliche Aktivierung und
Löschung, exakte Beträge, eindeutige Itempreise, Gültigkeit, fehlende Werte,
Schema-/Backupbestandsschutz, UI-Zustände, Build, Tests und Dokumentation.

## Reviewentscheidung

**✅ bestanden.** Der gesonderte Review prüfte Diff, Schichtengrenzen,
Persistenz, Migration, Fehlerbehandlung, Datenwirkung und Dokumentation. Eine
localeabhängige Profilreihenfolge wurde auf die projektweite deterministische
Normalisierung umgestellt und anschließend durch beide Gesamtsuiten erneut
geprüft.

## Nächster empfohlener Prompt

**P28 – CSV-Preisimport vollständig spezifizieren und ausführen.**
