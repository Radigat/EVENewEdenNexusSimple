# Abschlussbericht – P07B: SDE-Download, Archivprüfung und Aktivierung

Datum: 2026-07-23  
Prompt-ID: P07B  
Status: **⚠️ teilweise/blockiert**  
Reviewentscheidung: **⚠️ mit Einschränkungen bestanden**

## Ziel

Den durch P07A erkannten offiziellen JSONL-Build sicher herunterladen, das
ZIP vor und nach Extraktion defensiv prüfen, die vier benötigten Datensätze
isoliert importieren und erst nach Qualitäts-, Wiederöffnungs- und
Backupnachweis atomar aktivieren. Alte aktive Daten müssen bei jedem Fehler
erhalten bleiben.

## Ausgangszustand

- P07A prüfte Build und Schema-Changelog ausschließlich über offizielle
  CCP-Metadatenressourcen.
- P07–P09 validierten lokal entpackte JSONL-Dateien, erstellten ein
  `.nensde`-Paket, mappten einen Katalogsnapshot und aktivierten ihn
  versioniert.
- Der aktive Katalogsave war atomar und ältere Versionen blieben gespeichert.
- Downloadclient, ZIP-Sicherheitsgrenze, isolierter Teststore,
  SDE-Sicherheitsbackup, expliziter Rollback, Crashjournal und
  Wiederherstellungseinstieg fehlten.
- `OFF-019`/`KI-019` waren offen; `OFF-006` teilweise und `OFF-016`
  unverändert P10 zugeordnet.
- Branch `main`; alle Projektdateien waren bereits untracked. Nichts wurde
  gestaged, committed, gepusht, gelöscht oder verworfen.
- Kein `.xcodeproj` oder `.xcworkspace`; SwiftPM ist der verifizierte Weg.

## Compliancegrenze

Die offiziellen Quellen wurden am Ausführungstag erneut geprüft. Besonders
relevant:

- Developer License Agreement:
  `https://developers.eveonline.com/license-agreement`
- Static Data Export:
  `https://developers.eveonline.com/docs/services/static-data/`

Die SDE-Dokumentation bestätigt die versionierte JSONL-Archivform und
HTTP-Validatoren. Das DLA macht die persönliche Zustimmung des Nutzers zur
Voraussetzung und beschreibt bereits Zugriff beziehungsweise Download als
Annahmehandlung. Codex hat diese Entscheidung nicht stellvertretend getroffen.

Folge:

- technischer Downloader und alle Offline-/Stubtests wurden umgesetzt,
- kein aktuelles offizielles Archiv wurde real heruntergeladen,
- produktive Konfiguration verlangt eine reale Kontaktangabe,
- der Installationsrequest verlangt eine ausdrückliche
  Eigentümerbestätigung,
- P07B kann ohne Real-SDE-End-to-End-Nachweis nicht `✅` werden.

Dies ist eine technische Berücksichtigung offizieller Vorgaben, keine
Rechtsberatung und keine Behauptung einer CCP-Genehmigung.

## Durchgeführte Änderungen

### Application

`SDEInstallation.swift` ergänzt:

- Download-, Archiv-, Staging-, Backup-, Rollback- und Journalports,
- sichere Request-/Ergebnis-/Fehlertypen,
- phasenbasiertes, pfadfreies Updateprotokoll,
- Schema- und Eigentümergates,
- vollständige Orchestrierung von Download bis Aktivierung,
- Cleanup bei Erfolg, Fehler und Cancellation,
- Rollbackversuch nach Aktivierungsfehler,
- Erkennung und Aufarbeitung nichtterminaler Journale.

Die zentrale Fehlergrenze ergänzt `sdeInstallation` mit stabilem Code
`NEN-SDE-007` und sicheren, nichtpfadbezogenen Benutzertexten.

### Infrastructure

`CCPSDEArchivePipeline.swift` ergänzt:

- feste offizielle Build-URL ohne benutzerdefinierten Host,
- ephemeren URLSession-Download ohne Redirectfolge,
- User-Agent, Validatoren, Timeouts, begrenzte Retries und Backoff,
- Status-, MIME-, Content-Length-, Istgröße-, Maximalgröße- und
  Speicherprüfung,
- private UUID-Arbeitsverzeichnisse und Dateirechte,
- read-only ZIP-Central-Directory-Parser,
- Abgleich lokaler ZIP-Header,
- Ablehnung von Verschlüsselung, Multipart/ZIP64, Zip-Slip, absoluten oder
  mehrdeutigen Pfaden, Duplikaten, Symlinks/Sonderobjekten, unerwarteten
  Dateien, Übergrößen und Bombenverhältnissen,
- feste injizierbare `/usr/bin/ditto -x -k`-Grenze ohne Shell,
- vollständige Nachprüfung des extrahierten Baums.

`FileSDEInstallationLogStore.swift` speichert je Vorgang eine private atomare
JSON-Datei. Sie enthält keine vollständigen lokalen Pfade, Tokens oder
Charakter-/Accountdaten.

### Persistence

`SwiftDataSDEStagingService`:

- schreibt den validierten Snapshot in einen separaten temporären
  Schema-v4-Store,
- öffnet diesen Store erneut,
- prüft aktiven Build, Hash und Mengen,
- entfernt den isolierten Vorgangsstand kontrolliert.

`SQLiteSDEPromotionSafetyBackup`:

- erzeugt bei vorhandenem aktivem Store vor Promotion ein verifiziertes
  Backup der neuen Art `beforeSDEUpdate`.

`SwiftDataStaticDataCatalogRepository`:

- reaktiviert eine erhaltene Version explizit per Buildnummer,
- behält den bestehenden atomaren Save- und Rollbackpfad bei.

### Datenqualität und OFFEN-Punkte

- P07-/P08-Validierung bleibt unverändert maßgeblich.
- Nicht aufgelöste offizielle Typreferenzen werden unverändert mit
  `typeIsResolved == false` erhalten; keine automatische Reparatur wurde
  eingeführt (`OFF-016`).
- Neue und alte Builddaten werden weiterhin über `dataVersion` getrennt.
- `OFF-006` ist für SDE-Promotion um ein automatisches Backup ergänzt;
  allgemeine Vor-Migrationssicherung und Recovery-UI bleiben P36.
- `OFF-019` ist technisch weitgehend umgesetzt, bleibt aber aufgrund der
  offenen Realabnahme teilweise/blockiert.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/SDEInstallation.swift`
- `Sources/NewEdenNexusInfrastructure/CCPSDEArchivePipeline.swift`
- `Sources/NewEdenNexusInfrastructure/FileSDEInstallationLogStore.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSDEStagingService.swift`
- `Tests/NewEdenNexusApplicationTests/SDEInstallationServiceTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/CCPSDEArchivePipelineTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/FileSDEInstallationLogStoreTests.swift`
- `Documentation/SDE_ARCHIVE_INSTALLATION.md`
- `Documentation/Architecture/ADRs/ADR-0011_Sicherer-SDE-Archivpfad-und-Promotion.md`
- dieser Bericht.

## Geänderte Dateien

- `Sources/NewEdenNexusApplication/LocalBackupManagement.swift`
- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusApplication/StaticDataCatalog.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataStaticDataCatalogRepository.swift`
- `Tests/NewEdenNexusPersistenceTests/StaticDataCatalogRepositoryTests.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `Documentation/ARCHITECTURE.md`
- `Documentation/ARCHITECTURE_CHANGES.md`
- `Documentation/BACKUP_AND_RESTORE.md`
- `Documentation/CCP_COMPLIANCE.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DATA_MODEL.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/FEATURE_MATRIX.md`
- `Documentation/ERROR_HANDLING_AND_LOGGING.md`
- `Documentation/IMPLEMENTATION_ROADMAP.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/Prompts/README.md`
- `Documentation/SDE_UPDATE_CHECK.md`
- `Documentation/TEST_HISTORY.md`

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

ADR-0011 entscheidet:

- ZIP-Metadaten vor Systemextraktion selbst prüfen,
- feste macOS-`ditto`-Grenze ohne Shell statt neuer Paketabhängigkeit,
- vollständige Nachprüfung,
- isolierte SwiftData-Wiederöffnung vor Aktivstore,
- Backup plus erhaltene Katalogversion als getrennte Rückfallgrenzen,
- pfadbereinigtes JSON-Phasenjournal,
- produktiver Download nur nach Eigentümerbestätigung und Kontaktangabe.

## Datenmodelländerungen

Keine neue SwiftData-Schemaversion und keine Migration. `LocalBackupKind`
erhält den zusätzlichen codierbaren Wert `beforeSDEUpdate`. Katalogversionen
werden weiterhin in Schema v4 gespeichert und nicht gelöscht.

## Build-Ergebnis

Erfolgreich:

```bash
env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-VerifiedDebug/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-VerifiedDebug/swiftpm \
  swift test --disable-sandbox -c debug --enable-code-coverage \
  --scratch-path /private/tmp/NewEdenNexus-P07B-VerifiedDebug/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/swiftpm \
  swift build --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-P07B-VerifiedRelease/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/swiftpm \
  swift test --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-P07B-VerifiedRelease/build
```

`swift package --disable-sandbox describe` war ebenfalls erfolgreich.
Globale SwiftPM-Cacheverzeichnisse waren in der eingeschränkten Umgebung
nicht beschreibbar; isolierte Caches lösten das. Es gibt weiterhin
nichtfehlschlagende Core-Data-Hinweise zur
Store-Change-Benachrichtigung.

## Testergebnis

- Debug mit Coverage: **145 Tests, 0 Fehler**,
- Release: **145 Tests, 0 Fehler**,
- keine übersprungenen XCTest-Tests,
- Architekturgrenzen: **5 Tests, 0 Fehler**.

Neue P07B-Nachweise:

- Download nur über offizielle URL und mit User-Agent,
- falscher Status, Redirect, falsche Größe und zu wenig Speicher,
- beschädigtes ZIP, `..`-/absoluter Pfad, Symlink, Duplikat,
  unerwartete Datei und Bombenverhältnis,
- echte kontrollierte `ditto`-Extraktion,
- Journalroundtrip ohne lokalen Pfad,
- Schema-/Eigentümergates,
- erfolgreicher Ablauf,
- Aktivierungsfehler mit Rollback und Cleanup,
- isolierter Store mit Wiederöffnung,
- Reaktivierung der vorherigen Katalogversion.

Coverage:

- alle instrumentierten Zeilen: `12218/14574` = `83,83 %`,
- produktive Sources: `5781/7945` = `72,76 %`,
- `SDEInstallation.swift`: `87,38 %`,
- `CCPSDEArchivePipeline.swift`: `78,01 %`,
- `FileSDEInstallationLogStore.swift`: `85,83 %`,
- `SwiftDataSDEStagingService.swift`: `74,80 %`.

## Manuelle Prüfungen

- feste offizielle URL im Code und in Requests geprüft,
- `/usr/bin/ditto` vorhanden und über ein echtes synthetisches Archiv
  erfolgreich ausgeführt,
- Branch, Git-Wurzel und untracked Benutzerbestand erneut geprüft,
- kein Xcode-Projekt/Workspace gefunden,
- keine Signing-/Team-Einstellung geändert,
- kein aktuelles CCP-Archiv heruntergeladen,
- kein produktiver Store geöffnet.

## Bekannte Probleme und verbleibende Risiken

1. **Blocker – Eigentümerentscheidung:** DLA-/Kontaktangabe offen.
2. **Blocker – Real-SDE:** aktueller offizieller vollständiger Build nicht
   heruntergeladen, importiert, wieder geöffnet oder abgefragt.
3. **Hoch – Speichergrenze:** Das finale Mapping materialisiert einen
   vollständigen `StaticDataCatalogSnapshot`; ein blockweises Mapping oder
   belastbares Real-SDE-Speicherprofil fehlt.
4. **Hoch – Crash-Drill:** Recovery ist implementiert, aber ein echter
   Prozessabbruch nach jeder Phasengrenze mit Neustart fehlt.
5. **Mittel – Verdrahtung:** produktiver App-Start und UI folgen P07C.
6. **Vorhanden:** 21 nicht aufgelöste Referenzen im früheren Build 3424810
   bleiben für P10 sichtbar und unverändert.
7. **Mittel – Wartbarkeit:** Die zwei zentralen neuen P07B-Dateien bündeln
   trotz klarer Protokolle zu viele Zeilen; nach stabiler Realabnahme
   mechanisch nach Verantwortung aufteilen (`OFF-022`/`KI-022`).

## Abweichungen vom Projektbuch

Keine fachliche Erweiterung. Es wurden nur die vier für den MVP benötigten
SDE-Datensätze zugelassen; kein blinder Gesamtimport und keine
ESI-/UI-Funktion wurden vorgezogen.

Die P07B-Spezifikation verlangt blockweises Mapping. Der vorhandene
JSONL-Import ist streamingfähig und die Persistenz ist isoliert, der
abschließende Snapshot wird jedoch vollständig materialisiert. Diese
Abweichung ist offen dokumentiert und verhindert `✅`.

## Abnahmekriterien

| Kriterium | Ergebnis |
|---|---|
| ausschließlich offizielle Download-URL | ✅ Code/Stubtest |
| Status, MIME, Größe, Speicher, Timeout/Retry | ✅ technisch; Timeoutregression aus P07A |
| defensive ZIP-Vor- und Nachprüfung | ✅ |
| kein unkontrollierter Shellaufruf | ✅ fester `Process` ohne Shell |
| P07-Streamingvalidierung | ✅ Regression |
| isolierter nicht aktiver Store und Wiederöffnung | ✅ |
| Backup vor Promotion | ✅ verdrahtet |
| atomare Aktivierung und alter Katalog erhalten | ✅ |
| expliziter Rollback | ✅ |
| persistentes sicheres Updateprotokoll | ✅ |
| vollständiger aktueller offizieller Build | ❌ blockiert |
| blockweises Mapping/gemessene Speichergrenze | ⚠️ offen |
| Crashsimulation jeder Phase mit Neustart | ⚠️ P36 |
| Debug und Release grün | ✅ 145/145 |
| Dokumentation und Bericht | ✅ |

## Reviewentscheidung

**⚠️ mit Einschränkungen bestanden.**

Der technische Kern erfüllt die Sicherheits- und Architekturabsicht. Es
wurde keine durch P07B verursachte kritische Regression gefunden. Die
Definition of Done ist dennoch nicht vollständig erfüllt, weil persönliche
Eigentümervoraussetzungen, aktueller Real-SDE-E2E, Snapshot-Speichernachweis
und vollständiger Prozessabbruch-Drill fehlen. P07B bleibt folgerichtig
`⚠️ teilweise/blockiert`.

## Offene Anforderungen

- Projekteigentümer liest die aktuellen CCP-Bedingungen und entscheidet
  persönlich über die Nutzung.
- Projekteigentümer stellt eine geeignete reale User-Agent-Kontaktangabe.
- Danach P07B-Abnahme mit aktuellem Real-SDE und separatem Teststore
  fortsetzen.
- Speicher und Laufzeit des finalen Mappings messen; bei Bedarf blockweise
  Persistenz implementieren.
- P36 führt den vollständigen Prozessabbruch-/Neustart-/Restore-Drill aus.

## Nächster empfohlener Prompt

**P07B-Abnahme fortsetzen**, sobald die beiden Eigentümerentscheidungen
vorliegen. P07C oder P10 nicht automatisch beginnen.
