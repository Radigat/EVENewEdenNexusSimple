# Abschlussbericht – CFG-001: Öffentliche EVE-Client-ID

Datum: 2026-07-23  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Die vom Projekteigentümer bereitgestellte aktuelle öffentliche
EVE-Anwendungskennung in New Eden Nexus eintragen, ohne ein Client-Secret
anzulegen oder individuelle Benutzerkonfigurationen unkontrolliert zu
überschreiben.

## Ausgangszustand

Accounts-View, Einstellungen und App-Start enthielten mehrfach einen früheren
öffentlichen Client-ID-Standard. Der App-Start setzte ihn nur bei leerem Wert
und konnte einen bereits gespeicherten früheren Projektstandard nicht gezielt
aktualisieren.

## Durchgeführte Änderungen

- `EVEPublicConfiguration` als zentrale Quelle für öffentliche Client-ID und
  Callback-URL angelegt,
- beide SwiftUI-Konfigurationsstellen darauf umgestellt,
- leere Werte und den früheren Projektstandard beim App-Start gezielt
  migriert,
- individuell eingetragene Client-IDs ausdrücklich erhalten,
- zwei automatisierte Regressionstests ergänzt.

## Neu erstellte Dateien

- `Sources/NewEdenNexus/EVEPublicConfiguration.swift`
- dieser Bericht

## Geänderte Dateien

- `Sources/NewEdenNexus/AccountsView.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- Entwickler-Menü, Projektstatus, Feature-Matrix, Tagebuch, offene Aufgaben,
  bekannte Probleme, Testhistorie und Architekturänderungen.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidung

Öffentliche SSO-Anwendungsparameter besitzen eine zentrale Quelle im
Presentation-/Composition-Target. Die Migration überschreibt ausschließlich
den bekannten früheren Projektstandard oder einen leeren Wert. Sie verändert
keine abweichende Benutzerkonfiguration.

## Datenmodelländerungen

Keine SwiftData-, Keychain- oder Datenbankschemaänderung. Betroffen sind nur
die bestehenden `UserDefaults`-Schlüssel `eve.clientID` und
`eve.redirectURI`.

## Build- und Testergebnis

- Debug-Build und Tests: 148 Tests, 0 Fehler,
- Release-Build und Tests: 148 Tests, 0 Fehler,
- keine übersprungenen XCTest-Tests.

SwiftPM meldete nicht beschreibbare Benutzer-Caches im eingeschränkten
Prüfumfeld. SwiftData gab bekannte Store-Notification-Diagnosen aus. Die
Prozesse endeten jeweils erfolgreich.

## Manuelle Prüfungen

- einzige produktive aktuelle Client-ID-Definition per Quellcodesuche
  bestätigt,
- Views greifen auf die zentrale Konfiguration zu,
- Callback-URL unverändert
  `http://localhost:52721/callback`,
- keine Client-Secret-Konfiguration ergänzt.

Ein echter Browser-/SSO-Login wurde nicht durchgeführt.

## Bekannte Probleme und offene Anforderungen

- SSO-End-to-End-Anmeldung bleibt ungetestet,
- SSO-Härtung bleibt P38,
- ESI-Synchronisation bleibt P39/P40,
- die offene P07B-Speichergrenze bleibt unverändert.

## Abweichungen vom Projektbuch

Keine fachliche Erweiterung. Die bereits vorhandene, bewusst verschobene
SSO-Vorarbeit erhielt ausschließlich die ausdrücklich angeforderte aktuelle
öffentliche Anwendungskennung.

## Abnahmekriterien

- [x] aktuelle öffentliche Client-ID zentral eingetragen,
- [x] frühere Projektvorgabe gezielt migriert,
- [x] individuelle Client-ID geschützt,
- [x] Callback-URL beibehalten,
- [x] Debug und Release erfolgreich,
- [x] relevante Tests erfolgreich,
- [x] Pflichtdokumentation aktualisiert,
- [x] gesonderter Diff-/Code-/Test-/Dokumentationsreview bestanden.

## Nächster empfohlener Prompt

P07B-Speichergrenze schließen: Katalogmapping und Persistenz blockweise
ausführen und den offiziellen Build erneut speichervermessen. P38 nicht ohne
ausdrücklichen Auftrag beginnen.
