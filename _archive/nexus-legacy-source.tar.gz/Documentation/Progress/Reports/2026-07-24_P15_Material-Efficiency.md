# Abschlussbericht – P15: Material Efficiency

Datum: 2026-07-24  
Prompt-ID: P15  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

P15 vollständig spezifizieren und anschließend die Blueprint-
Materialeffizienz der vorhandenen Rezeptstufe zentral, deterministisch,
integer- und überlaufsicher berechnen, in Projekt, Graph, Persistenz und UI
integrieren und mit Referenzwerten prüfen. P16 durfte nicht begonnen werden.

## Ausgangszustand

P14 lieferte Graphformat 2 und Schema v7 mit benötigten Runs, tatsächlicher
Ausgabe und Überschuss. Projekte besaßen keinen ME-Wert; Graphkanten trugen
nur Basismengen je Run. Gesamtmaterial, Rundung, Ersparnis und
Formelprovenienz fehlten. Format-1-/2-Bestand musste lesbar bleiben.

Der Arbeitsbaum enthielt umfangreiche uncommittete Änderungen aus früheren
Arbeitspaketen. Sie wurden erhalten. Es wurde weder committed noch gepusht,
gemerged, rebased oder zurückgesetzt.

## Durchgeführte Änderungen

- P15 mit Zweck, Voraussetzungen, offiziellen Quellen, Scope, Formel,
  Invarianten, Fehlern, offenen Punkten, Tests und Definition of Done
  vollständig spezifiziert.
- Offizielle CCP-Regel am 2026-07-24 geprüft: ME auf den gesamten Job
  anwenden, aufrunden und eine Basiseinheit je Run schützen.
- `ProductionMaterialCalculation` mit Formelversion 1 implementiert.
- Rohbedarf, Effektivbedarf und Ersparnis ohne Fließkomma berechnet.
- Material- und Reduktionsmultiplikation auf `Int64`-Überlauf geprüft.
- Reaktionen verbindlich auf Blueprint-ME 0 begrenzt.
- Codable-Werte beim Laden neu berechnet; manipulierte Payloads abgelehnt.
- Produktionsprojekte um validierte ME 0 bis 10 ergänzt; Lebenszyklus,
  Duplikat und Persistenz erhalten den Wert.
- Graphformat 3 mit ME-Provenienz und Materialberechnung je Kante ergänzt.
- Format 1 und 2 bleiben lesbar und gelten als veraltet.
- Schema v8 als additive Stufe mit optionalem Projekt-ME und
  Materialformelmetadatum umgesetzt.
- Backupversion 8.0.0 und Kompatibilität 1.0.0 bis 8.0.0 ergänzt.
- Projekteditor, Projektliste und Graphansicht um verständliche ME- und
  Materialwerte ergänzt.
- Xcode-Projekt reproduzierbar regeneriert und strukturell geprüft.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionMaterialCalculation.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV8.swift`
- `Tests/NewEdenNexusDomainTests/ProductionMaterialCalculationTests.swift`
- `Documentation/MATERIAL_EFFICIENCY.md`
- `Documentation/Architecture/ADRs/ADR-0020_Integer-ME-Graphformat-3-und-Schema-v8.md`
- dieser Abschlussbericht

## Geänderte Dateien

- `Sources/NewEdenNexusDomain/ProductionProject.swift`
- `Sources/NewEdenNexusDomain/ProductionGraph.swift`
- `Sources/NewEdenNexusApplication/ProductionProjectLifecycle.swift`
- `Sources/NewEdenNexusApplication/ProductionGraph.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV5.swift`
- `Sources/NewEdenNexusPersistence/NexusMigrationPlan.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexusPersistence/SQLiteLocalBackupService.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionProjectRepository.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionGraphRepository.swift`
- `Sources/NewEdenNexus/ProjectsView.swift`
- `Sources/NewEdenNexus/ProductionGraphView.swift`
- Domain-, Application-, Persistenz-, ViewModel- und Architekturtests,
- `NewEdenNexus.xcodeproj/project.pbxproj`,
- P15-Prompt, Architektur-, Datenmodell-, Graph-, Status-, Roadmap-,
  Feature-, Tagebuch-, Test-, Aufgaben-, Problem- und ADR-Register.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

1. Blueprint-ME ist ein validierter Projektwert und keine Viewlogik.
2. Die Materialformel arbeitet nur mit Ganzzahlen und rundet einmal je
   Materialposition über den gesamten Job.
3. Basismenge eins je Run bleibt vor ME-Reduktion geschützt.
4. Reaktionen erhalten keinen Blueprint-ME-Wert.
5. Alte Projekte migrieren neutral auf ME 0; alte Graphen werden nicht
   fachlich umgeschrieben.
6. Graphformat, Runformel und Materialformel besitzen getrennte,
   gegeneinander geprüfte Provenienzen.

Siehe
[`ADR-0020`](../../Architecture/ADRs/ADR-0020_Integer-ME-Graphformat-3-und-Schema-v8.md).

## Datenmodelländerungen

Schema v8 führt die v7-Modelle als echte additive Version fort:

- `ProductionProject.materialEfficiency: Int?`,
- `ProductionGraphRecord.materialFormulaVersion: Int?`.

Die v7→v8-Migration ist leichtgewichtig. Fehlendes Projekt-ME wird im
Domainmapping als 0 interpretiert; bestehende Graphpayloads behalten Format
1 oder 2 und `nil` als Materialformelversion. Neue Format-3-Graphen tragen
Formelversion 1. Das Backupmanifest verwendet 8.0.0.

## Build-Ergebnis

Erfolgreich:

```text
env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P15-Debug/module-cache \
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P15-Debug/module-cache \
  swift test --scratch-path /private/tmp/NewEdenNexus-P15-Debug/build -c debug

env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P15-Release/module-cache \
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P15-Release/module-cache \
  swift test --scratch-path /private/tmp/NewEdenNexus-P15-Release/build -c release

Scripts/generate_xcode_project.sh
python3 Scripts/verify_xcode_project.py

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Debug -destination platform=macOS \
  -derivedDataPath /private/tmp/NewEdenNexus-P15-Xcode-Debug \
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Release -destination platform=macOS \
  -derivedDataPath /private/tmp/NewEdenNexus-P15-Xcode-Release \
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
```

Signing- und Teamwerte wurden nicht geändert. Xcode wählte aus zwei
passenden My-Mac-Zielen arm64. Die Projektprüfung meldete 15 Targets, sieben
Testtargets und zwei gemeinsame Schemes.

Die ersten SwiftPM-/Xcode-Aufrufe innerhalb der verschachtelten
Ausführungssandbox scheiterten an `sandbox_apply: Operation not permitted`
beziehungsweise nicht startbaren SwiftData-Makroplugins. Dieselben Befehle
wurden außerhalb dieser äußeren Sandbox erfolgreich wiederholt. Dies war
kein Quellcodefehler.

## Testergebnis

- SwiftPM Debug: 273 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 273 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 273 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Release: 273 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode-Ergebnisse mit `xcresulttool` ausgelesen.
- `git diff --check`: bestanden.
- Xcode-Projektprüfung: bestanden.

Geprüft wurden insbesondere:

- ME 0 und ME 10,
- Aufrundung einmal über den gesamten Job,
- Basismenge eins je Run,
- Fertigung und Reaktion,
- ungültige ME-Werte und unbekannte Formelversion,
- Rohmengen- und Reduktionszählerüberlauf,
- Codable-Roundtrip und Payloadmanipulation,
- deterministische Wiederholung,
- Projektanlage, Bearbeitung, Statuswechsel und Duplikat,
- Graphformat 1/2 sowie Format-3-Invarianten,
- Stale-Erkennung bei geändertem ME,
- Bestandsschutz bei Rechen-, Abbruch- und Persistenzfehlern,
- Projekt-/Graph-Roundtrip und Metadatenwidersprüche,
- v3→v8, v7→v8, zweite Öffnung und leeres aktuelles Schema,
- Backupvorgänger 1.0.0 bis 8.0.0 und Ablehnung 9.0.0,
- UI-Texte, Accessibility-Metadaten und Schichtengrenzen.

## Manuelle Prüfungen

Das gebaute Xcode-Debug-App-Binary lief mehr als fünf Sekunden mit dem
isolierten Store `/private/tmp/NewEdenNexus-P15-Smoke/P15.store`.

- `PRAGMA integrity_check`: `ok`
- `ZPRODUCTIONPROJECT.ZMATERIALEFFICIENCY` vorhanden
- `ZPRODUCTIONGRAPHRECORD.ZMATERIALFORMULAVERSION` vorhanden
- Prozess anschließend kontrolliert beendet

Produktive Benutzerdaten wurden nicht geöffnet oder verändert. Ein neuer
visueller VoiceOver-Lauf wurde nicht durchgeführt und wird nicht behauptet;
UI-Kompilation, Texte, Accessibility-Metadaten und Schichtengrenzen sind
automatisiert geprüft.

## Gefundene und behobene Probleme

1. Der erste fokussierte Migrationstest öffnete den migrierten aktuellen
   Store mit einem historischen Modelltyp und endete nach erfolgreicher
   Migration mit Signal 6. Die Prüfung wurde auf den tatsächlichen
   Schema-v8-Typ korrigiert; fokussierte und vollständige Läufe bestanden.
2. Ein Testargument war während der Erweiterung falsch positioniert und
   wurde vor der vollständigen Abnahme korrigiert.
3. Der Abschlussreview prüfte die Formel-, Graph-, Persistenz- und
   UI-Grenzen sowie alle offenen P15-Anteile. Es blieb kein durch P15
   verursachter kritischer Befund offen.

## Bekannte Probleme und offene Anforderungen

- `OFF-004`/`KI-003`: teilweise; ME ist geschlossen, rekursive T1-/T2-/
  Reaktionsketten und Aggregation folgen P16 bis P19.
- `OFF-009`/`KI-012`: teilweise; P15-Materialmultiplikationen sind
  überlaufgeschützt, Aggregationssummen folgen P19.
- `OFF-006`/`KI-006`/`KI-013`: additive v8-Migration und Backup 8.0.0 sind
  geprüft; automatische Vor-Migrationssicherung und realer Recovery-Drill
  bleiben P36.
- `OFF-021`/`KI-021`: vorhandene SDE-Basismengen reichen für P15; weitere
  Datensätze bleiben bedarfsgesteuert.
- `OFF-027`/`KI-027`: P15 fügt nur eine begrenzte Editorsektion hinzu;
  mechanische Aufteilung des gewachsenen Editors bleibt P34.

Keine dieser Restaufgaben verhindert die vollständige P15-Abnahme.

## Abweichungen vom Projektbuch

Die im Projektbuch noch als prüfbedürftig markierte ME-Regel wurde vor der
Implementierung gegen die aktuellen offiziellen CCP-Hilfeseiten geprüft.
P15 implementiert bewusst nur Blueprint-ME. Weitere Jobmodifikatoren und
Reaktionsboni werden ohne eigene verifizierte Regel nicht vermischt.

## Erfüllte Abnahmekriterien

- vollständige P15-Spezifikation: erfüllt,
- offizielle Fachregel und Quellen: erfüllt,
- zentrale Ganzzahlformel und Invarianten: erfüllt,
- Referenz-, Rundungs-, Grenz- und Überlauftests: erfüllt,
- Projektwert und Lebenszyklus: erfüllt,
- Graphformat 3 und Formelprovenienz: erfüllt,
- Format-1-/2-Bestand lesbar und stale: erfüllt,
- Schema v8 und Backup 8.0.0: erfüllt,
- sichtbare ME- und Materialaufschlüsselung: erfüllt,
- keine vorgezogene P16–P19-Logik: erfüllt,
- offene Punkte erneut geprüft: erfüllt,
- SwiftPM/Xcode Debug/Release: erfüllt,
- isolierter App-/Store-Smoke: erfüllt,
- Pflichtdokumentation und Bericht: erfüllt,
- Review und Kontrollprüfung: erfüllt.

## Nicht erfüllte Abnahmekriterien

Keine für P15.

## Reviewentscheidung

**✅ bestanden.** Der gesonderte Review prüfte tatsächliche Quelltexte,
Formel- und Graphinvarianten, Datenwirkung, Fehlerpfade, vollständige Build-
und Testergebnisse, isolierte Storeprüfung, Dokumentation und offene
Register. P16 wurde nicht begonnen.

## Nächster empfohlener Prompt

P16 – T1-Berechnung zunächst vollständig spezifizieren und erst anschließend
ausführen. Dabei sind alle für P16 notwendigen offenen Punkte verbindlich in
den Scope aufzunehmen.
