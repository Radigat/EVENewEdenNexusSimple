# P50 – P40-Restabnahme persönliche ESI-Daten

Datum: 2026-07-27  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel und Ausgangszustand

P40 besaß sichere, versionierte Offline-Snapshots für persönliche Assets,
Blueprints und Industry Jobs, aber keinen detaillierten Arbeitsfluss und
keine kontrollierte Assetwirkung auf die Produktionsplanung.

## Durchgeführte Änderungen

- drei such-, filter- und sortierbare Detailansichten mit Type-/Location-IDs,
  Mengen, Blueprintqualität, Jobdaten, Herkunft, Revision und Cachezustand,
- deterministische, auf 2.000 Treffer begrenzte Detailprojektion; unbekannte
  Namen bleiben als IDs sichtbar,
- projekt- und charakterbezogene Asset-Vorschau nach gewählten
  EVE-Location-IDs,
- positionsgenaue Doppelzählungsprüfung gegen manuelle/CSV-Bestände und
  ausdrückliche Bestätigung vor Persistenz,
- Stale-Schutz für Snapshotrevision, Lagerzustand, Filter und vorhandene
  Auswahl; Abbruch bleibt als Abbruch erhalten,
- externe ESI-Menge separat in der Build-or-Buy-Verfügbarkeit ausgewiesen;
  Lager-, Schutzbestands- und Reservierungsdaten werden nicht verändert,
- nachträgliche manuelle Überschneidung deaktiviert die Wirkung ohne
  Benutzerdaten zu löschen,
- additive Schema-v23-Entität, v22→v23-Migration, Backup-/Restore- und
  Wiederöffnungsunterstützung,
- Charaktertrennung um kompensierbares Löschen/Wiederherstellen der
  bestätigten Auswahlen ergänzt,
- fehlende oder ungültige persönliche Dateispeichergrenze bricht den
  App-Start sichtbar ab, statt die bestätigte ESI-Auswahl still zu ignorieren,
- Xcode-Projekt regeneriert; keine Signing-/Teamänderung.

## Dateien

Neu:

- `Sources/NewEdenNexus/ESIPersonalDataDetailView.swift`
- `Sources/NewEdenNexusApplication/ESIPersonalDataDetails.swift`
- `Sources/NewEdenNexusApplication/ESIAssetAvailability.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV23.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataESIAssetAvailabilitySelectionRepository.swift`
- zwei P50-Testdateien,
- `Documentation/ESI_ASSET_AVAILABILITY.md`,
- `Documentation/Architecture/ADRs/ADR-0048_Projektbezogene-ESI-Asset-Verfuegbarkeit-und-Schema-v23.md`.

Geändert wurden die betroffenen Composition-, Accounts-, Build-or-Buy-,
Auth-, Verfügbarkeits-, Migrations-, Backup-, Test-, Xcode- und
Steuerdateien. Nichts wurde gelöscht oder verschoben. Vorhandene
Benutzeränderungen blieben erhalten; kein Commit und kein Push.

## Architektur und Datenmodell

P40-Dateisnapshots bleiben von SwiftData getrennt. Schema v23 speichert nur
die ausdrücklich bestätigte projektbezogene Type-/Location-/Mengenwahl samt
P40-Quellrevision. Namen und berechnete Verfügbarkeiten werden nicht
persistiert. Blueprint- und Jobdaten bleiben reine Anzeige.

OFF-021 wurde erneut geprüft: P50 benötigt keinen zusätzlichen SDE- oder
Ortsdatenimport. Nicht auflösbare Werte werden nicht erfunden.

## Build und Tests

- `swift test --disable-sandbox --scratch-path .build-p50 --jobs 2`:
  **619/619 bestanden**, 0 Fehler.
- fokussierte Asset-Verfügbarkeit: **8/8 bestanden**.
- Persistenz/Migration: **2/2 bestanden**.
- P50-UI-Architekturvertrag: **1/1 bestanden**.
- Projektverifier: **16 Targets, 8 Testtargets, 2 gemeinsame Schemes**.
- isolierter unsigned macOS-Debugbuild:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/nen-p50-final.noHm3j/DerivedData
  CODE_SIGNING_ALLOWED=NO build` → **BUILD SUCCEEDED**.

Der direkte Vorlauf am File-Provider-markierten Repositorypfad zeigte den
bekannten Stillstand und wurde kontrolliert abgebrochen. Die isolierte
inhaltsgleiche Kopie bestand. Hinweise zu mehreren passenden
macOS-Architekturen und ausgelassener AppIntents-Metadatenextraktion waren
nicht fehlerhaft.

## Manuelle Prüfungen und Datenschutz

Kein produktiver persönlicher ESI-Abruf und kein Eigentümer-GUI-Lauf wurden
ausgeführt. Automatisiert geprüft sind Dateisnapshot-Rundlauf,
Detailprojektion, Offline-/Frischeanzeige, Migration, Wiederöffnung,
Bestätigung, Stale-/Abbruchpfade und Trennkompensation. Der reale P40–P42-
Betriebslauf bleibt ausschließlich P52.

Keine Tokens, Kontaktangaben, Charakterfixtures oder sonstigen produktiven
personenbezogenen Daten wurden ergänzt.

## Abnahmekriterien

1. Offline-Detailpfad nach Wiederöffnung: erfüllt durch vorhandenen
   P40-Dateirundlauf, Composition-Laden und P50-Projektion.
2. Suche, Filter, Großmenge, unbekannte IDs: erfüllt.
3. Inspektion ohne Fachmutation: erfüllt.
4. Wirkung nur nach Vorschau/Bestätigung: erfüllt.
5. Lager-/CSV-/Schutz-/Reservierungsbestandsschutz und Doppelzählung:
   erfüllt.
6. Stale-, Abbruch- und Fehlerbestandsschutz: erfüllt.
7. Migration, Backup, Wiederöffnung, SwiftPM und Xcode Debug: erfüllt.
8. Review und Dokumentation: erfüllt.

## Reviewentscheidung

Der gesonderte Kontrollschritt prüfte tatsächlichen Diff, Schichtengrenzen,
Zahlenüberlauf, Abbrucherhalt, nachträgliche Doppelzählung, Schema,
Migration, Backup, Tests, Xcode-Projekt, Dokumentation und Geheimnisgrenzen.
Dabei wurde ein stiller `try?`-Fallback in der Produktions-Composition
gefunden und durch den zentralen Startup-Fehlerpfad ersetzt. Nach der
Korrektur bestanden erneut 619/619 Tests und der Xcode-Debugbuild.
Entscheidung: **✅ bestanden**. OFF-035 und KI-038 sind geschlossen.

## Offene Anforderungen und nächster Prompt

- P51: P42-Fehlerrouting, Scope-Transparenz und sichtbarer
  Plan-/Ist-Vergleich.
- P52: produktiver Eigentümerlauf für P40–P42.
- OFF-021 bleibt als allgemeines SDE-Bedarfsgate offen.

Nächster empfohlener Prompt: **P51**, nur auf ausdrücklichen Auftrag.
