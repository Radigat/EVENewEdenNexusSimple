# OFF-006 – Migration-/Recovery-Lebenszyklus

Datum: 2026-07-26

Status: ✅ erledigt

## Ziel und Ausgangszustand

Den vorhandenen technischen Backupdienst vor Migrationen und bei bestätigtem
Restore in den App-Lebenszyklus einbinden. Vorher fehlten automatische
Vor-Migrations-Sicherung, kontrollierte Storefreigabe und Recovery-UI.

## Änderungen

- read-only Erkennung der Nexus-Schemata 1 bis 20 vor SwiftData,
- verpflichtendes `beforeMigration`-Backup für ältere unterstützte Stores,
- Abbruch vor Öffnung bei nicht erkanntem Fremdstore oder Backupfehler,
- Settings-Bereich **Sicherung** mit manuellem Backup,
  read-only Restore-Vorschau, Prüfbestätigung und finaler Bestätigung,
- Freigabe storegebundener Runtime-Zustände, `beforeRestore`, atomarer
  Restore und Wiederöffnung über dieselbe Migrationsgrenze,
- tatsächliche Quellschemaversion im Backupmanifest,
- Vorwärtsmigration älterer Backups; Downgrade ausdrücklich nicht unterstützt.

Neu: `NexusStoreMigrationBackup.swift`, `LocalRecoveryView.swift`,
`NexusMigrationBackupCoordinatorTests.swift`,
`LocalRecoveryRuntimeTests.swift`, `LocalRecoveryArchitectureTests.swift`,
ADR-0041. Geändert wurden App-Runtime/Composition, Backupservice, Settings,
Xcode-Projekt und die betroffene Dokumentation. Keine Dateien wurden gelöscht
oder verschoben. Keine produktiven Benutzerdaten wurden geöffnet.

## Architektur und Datenwirkung

Das Schema bleibt v20; es gibt keine neue Migration. Die Store-Composition
besitzt nun eine explizite Vor-Öffnen- und Vor-Restore-Grenze. Ein
Backupfehler lässt den Altstore unverändert. Der isolierte Drill erhält
Projekt und Einkaufs-Override und erfindet keinen Kauf-Fortschritt.

## Build und Tests

- `swift test --filter 'LocalRecoveryRuntimeTests|NexusMigrationBackupCoordinatorTests|LocalRecoveryArchitectureTests'`:
  **8/8 bestanden**.
- `swift test`: **526/526 bestanden**.
- `xcodebuild build ... NewEdenNexus ... Debug ... macOS arm64`:
  **BUILD SUCCEEDED**.
- `xcodebuild test ... -skip-testing:NewEdenNexusUITests`:
  **526/526 bestanden**.

Der vollständige Xcode-Lauf und ein UI-only-Wiederholungsversuch erreichten
in dieser Sitzung keinen UI-Testbeginn; der Worker blieb bei der
Materialisierung stehen. Der interaktive Kanal konnte das Test-App-Bundle
ebenfalls nicht registrieren. Eine visuelle Einmalprüfung wird nicht
behauptet; OFF-031 dokumentiert den erneuten Infrastrukturtest. Historische
OFF-030-UI-Nachweise werden nicht umgedeutet.

## Review

Diff, Sicherheitsgrenzen, Schemaerkennung, Laufzeitfreigabe, Vorschau-/
Bestätigungsworkflow, automatisierte Nachweise, Dokumentation und
`git diff --check` wurden getrennt geprüft.

Entscheidung: **✅ bestanden**. OFF-006 ist vollständig nachgewiesen. Die
UI-Worker-Störung ist ein separater, vor Testbeginn liegender
Infrastrukturbefund und keine nachgewiesene Produktregression.

## Offen und Abweichungen

- OFF-024: realer externer SDE-Prozessabbruch mit Neustart bleibt
  verpflichtender P36-Restumfang vor öffentlichem Release.
- OFF-031: nativen UI-Worker vor Release erneut prüfen.
- zeitabhängige Release-/CCP-Complianceprüfung bleibt offen.
- keine Fachfunktion und kein Downgrade wurden ergänzt.

## Abnahmekriterien

- automatische Vor-Migrations-Sicherung: erfüllt,
- Store-Lebenszyklus/Restore/Wiederöffnung: erfüllt,
- Recovery-UI mit Vorschau und ausdrücklicher Bestätigung: erfüllt,
- isolierter Integritäts- und Fehlerszenariodrill: erfüllt,
- Build, relevante Tests, Dokumentation und Review: erfüllt,
- externer SDE-Prozess-Kill: nicht Teil von OFF-006, bleibt OFF-024.

Nächster empfohlener Prompt: **P36-Restumfang OFF-024**, ausschließlich nach
ausdrücklichem Auftrag.
