# Abschlussbericht – P30 Einkaufslisten-Aggregation

Prompt-ID: **P30**  
Status: **✅ erledigt**  
Review: **✅ bestanden**  
Datum: 2026-07-26

## Ziel und Ausgangszustand

P26/P32 lieferten bereits positive, kopierbare Nettofehlmengen. Editierbare
Mengen waren nicht persistent; P31-Status und CSV waren verschoben. P29
hatte Schema v18 und 473 bestandene Tests erreicht.

## Durchgeführte Änderungen

- vollständige P30-Spezifikation mit OFF-011-Abgrenzung,
- defensive Type-ID-Aggregation über Fertigungs-, Reaktions-,
  Inventions- und gekaufte Zwischenstufen,
- nichtnegative Zielkaufmengen einschließlich null,
- Speicherung nur echter Abweichungen,
- vollständiger Source-State- und Optimistic-Locking-Schutz,
- sichtbare Bereinigung veralteter Overrides,
- Workspace-Bearbeitung, Rücksetzung, Vorschau, Bestätigung und Textliste,
- additives Schema v19 und Backupformat 19.0.0,
- v18→v19-Migration und Wiederöffnung.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ShoppingList.swift`
- `Sources/NewEdenNexusApplication/ShoppingListManagement.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV19.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataShoppingQuantityOverrideRepository.swift`
- `Tests/NewEdenNexusDomainTests/ShoppingListTests.swift`
- `Tests/NewEdenNexusApplicationTests/ShoppingListManagementServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ShoppingListPersistenceTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ShoppingListArchitectureTests.swift`
- `Documentation/SHOPPING_LIST.md`
- `Documentation/Architecture/ADRs/ADR-0036_Projektbezogene-Einkaufs-Overrides-und-Schema-v19.md`
- dieser Bericht.

## Geänderte Dateien

Workspace-ViewModel/-View, Composition, RootView, Migration, Container,
Backupdienst/-tests, Xcode-Projektmetadaten sowie die verpflichtenden
Status-, Architektur-, Datenmodell- und Testdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architektur- und Datenmodellentscheidungen

Berechnete Listen werden nicht gespeichert. Persistiert werden nur
Abweichungen je Projekt/CCP-Type-ID. Der Apply-Pfad berechnet den bestätigten
P26-Plan erneut und ersetzt Overrides atomar. Schema v19 ist additiv;
Archivierung erhält Daten, Duplikate starten aufgrund neuer Projekt-ID leer.

## Build- und Testergebnis

- `swift build -c debug --quiet`: erfolgreich,
- fokussiert `--filter Shopping`: 14/14 bestanden,
- SwiftPM Debug: 486/486 bestanden, 0 übersprungen,
- Xcode Debug: 486/486 bestanden, 0 übersprungen,
- Xcode-Parität: 15 Targets, sieben Testtargets, zwei Schemes.

Der erste Gesamtlauf hatte genau einen veralteten Architekturtesttext aus
P32. Nach Anpassung an „Einkaufsliste kopieren“ bestand die komplette Suite.
Der finale Xcode-Lauf gab zusätzlich eine DTDeviceKit-Warnung zu einem
gesperrten verbundenen Mobilgerät aus; der ausdrücklich gewählte
macOS-Testlauf und sein `.xcresult` waren vollständig erfolgreich.

## Manuelle und technische Prüfungen

Die Xcode-App lief mit isoliertem P30-Store. `PRAGMA integrity_check`
meldete `ok`; `ZSHOPPINGQUANTITYOVERRIDERECORD` war vorhanden. Schmale und
breite Workspace-Größen wurden reproduzierbar gerendert. Ein manueller
GUI-/VoiceOver-Test wurde nicht behauptet.

## Review

Der gesonderte Review prüfte Diff, Schichtengrenzen, Ganzzahlarithmetik,
Vorschau-vor-Schreiben, Stale State, Abbruch, Migration, Backups und
Dokumentation. Eine nach dem Commit liegende Repository-Verifikation wurde
entfernt, damit ein erfolgreicher Commit niemals anschließend als
mehrdeutig fehlgeschlagen gemeldet wird.

Reviewentscheidung: **✅ bestanden.**

## Bekannte Probleme und offene Anforderungen

Keine kritische P30-Regression ist offen. OFF-011 ist für Aggregation und
persistente Mengen erledigt; Kaufstatus, Teilkäufe, CSV-Export und
projektübergreifender Workflow bleiben P31. P33–P36 und der
Release-/Compliance-Recheck bleiben vor öffentlicher Freigabe offen.

## Abweichungen vom Projektbuch

Keine erfundene Markt-, Gebühren- oder Walletlogik. P30 bleibt bewusst
projektbezogen; projektübergreifende Beschaffung gehört zu P31.

## Abnahmekriterien

Alle P30-Kriterien sind nachgewiesen. P31 wurde nicht begonnen.

## Nächster empfohlener Prompt

**P31 – Einkaufsworkflow und Export vollständig spezifizieren und
anschließend ausführen.**
