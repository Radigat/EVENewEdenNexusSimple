# Abschlussbericht – P28 CSV-Preisimport

Datum: 2026-07-25  
Prompt-ID: P28  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel und Ausgangszustand

CSV-Preislisten sollten erst geprüft und detailliert angezeigt, dann nach
Einzelentscheidungen und Bestätigung atomar übernommen werden. P27 bot
bereits exakte manuelle Preise in Schema v16, aber keinen Massenimport.

## Durchgeführte Änderungen

- Format-/Spaltenvertrag für `type_id`, `price` und optional `item_name`,
- Wiederverwendung des begrenzten P21-CSV-Transports,
- expliziter Dezimalpunkt-/Dezimalkommavertrag,
- aktive SDE-Katalog-, Duplikat- und Namensprüfung,
- Vorschauzustände Hinzufügen, Unverändert, Konflikt und Fehler,
- Einzelentscheidung Ersetzen/Überspringen plus zweite Bestätigung,
- Stale-State-Prüfung von Profil, Preisen und Katalogprovenienz,
- atomarer Preis-/Berichtscommit und Quelle `csv`,
- Schema v17, Migration, Backupformat 17.0.0 und native Import-UI,
- sichere Fehlercodes `NEN-PRICE-003` und `NEN-PRICE-004`.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/PriceCSVImport.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV17.swift`
- `Sources/NewEdenNexus/PriceCSVImportViewModel.swift`
- `Sources/NewEdenNexus/PriceCSVImportView.swift`
- drei P28-Testdateien
- `Documentation/PRICE_CSV_IMPORT.md`
- `Documentation/Architecture/ADRs/ADR-0034_Atomarer-CSV-Preisimport-und-Schema-v17.md`

## Geänderte Dateien

Preis-Domain und Repositoryvertrag, SwiftData-Preisrepository,
Preis-Composition/-Ansicht, Fehlerbehandlung, Migration, Containerfactory,
Backupdienst/-tests, Xcode-Projekt und Pflichtdokumentation.

## Gelöschte oder verschobene Dateien

Keine.

## Architektur- und Datenmodellentscheidung

Preisfachliche Vorschau und Konflikte liegen in Application; UI und
ViewModel bleiben SwiftData-frei. Schema v17 ergänzt nur den versionierten
`PriceImportRecord`. Rohdatei und Pfad werden nicht gespeichert; Berichte
werden beim Löschen ihres Profils entfernt. Details:
[ADR-0034](../../Architecture/ADRs/ADR-0034_Atomarer-CSV-Preisimport-und-Schema-v17.md).

## Build- und Testergebnis

- SwiftPM Debug: erfolgreich,
- Xcode Debug, macOS arm64, Signing deaktiviert: erfolgreich,
- Projektparität: 15 Targets, sieben Testtargets, zwei Schemes,
- 22 fokussierte Prüfungen bestanden,
- 461/461 SwiftPM-Debugtests bestanden, 0 übersprungen,
- 461/461 Xcode-Debugtests bestanden, 0 übersprungen.

Der Sandbox-Erstlauf scheiterte nur am Compilercache. Ein inkonsistenter
lokaler Objektcache wurde mit `swift package clean` bereinigt; danach bestand
derselbe Quellstand. Nach der Reviewhärtung wurden beide vollständigen
Debug-Suiten auf dem finalen Quellstand erneut ausgeführt.

## Manuelle Prüfungen

Das App-Bundle wurde mit isoliertem Store gestartet. Der Prozess blieb
lauffähig, `PRAGMA integrity_check` meldete `ok` und
`ZPRICEIMPORTRECORD` war vorhanden. Ein visueller GUI-/VoiceOver-Test wurde
nicht durchgeführt und wird nicht behauptet.

## Bekannte Probleme und offene Anforderungen

Kein kritischer oder hoher P28-Fehler ist offen. Die große
`PriceCSVImport.swift` ist als KI-029 P34 zugeordnet. P29 übernimmt Kosten
und Wirtschaftlichkeit, P30/P31 den erweiterten Einkauf; P33–P36 bleiben
Release-Härtung.

## Abweichungen vom Projektbuch

Keine unbelegte Regel wurde eingeführt. Gültigkeit gilt einheitlich pro
Import; nicht gelistete Preise werden nicht gelöscht. Live-Markt-/ESI-Daten
bleiben außerhalb des Auftrags.

## Abnahmekriterien und Review

Alle Kriterien zu Datei, Mapping, Vorschau, Konflikten, Bestätigung,
atomarem Bericht, Abbruch-/Stale-Schutz, Schema/Backup, UI, Build, Tests und
Dokumentation sind erfüllt.

Reviewentscheidung: **✅ bestanden.** Der Review ergänzte die
Berichtslöschkaskade und die Ablehnung profilfremder oder doppelter
Batchmutationen. Danach bestanden fokussierte und vollständige Suiten erneut.

## Nächster empfohlener Prompt

**P29 – Kosten, Gewinn und ROI vollständig spezifizieren und ausführen.**
