# PLAN-002 – Tokenarmer Kern-MVP

Datum: 2026-07-25  
Status: ✅ Planung konsistent aktualisiert  
Codeänderung: keine

## Ergebnis

Die unmittelbare Promptfolge wurde von P26–P37 auf **P26 → P32 → P37**
reduziert:

- P26: Lagerbestand, Bauen/Kaufen, Produktions-/Inventionsjobs und
  Fehlmengen,
- P32: integrierter Kernworkspace,
- P37: interne T1-/T2-/Inventionsabnahme ohne Releasebehauptung.

P27–P31 und P33–P36 sind temporär verschoben. Bestehender Code,
Benutzerdaten, Sicherheitsgrenzen und offene Befunde bleiben unverändert.

## Referenz und Abgrenzung

Ravworks wurde als Workflow-Referenz geprüft: Produkt-/Bestandsangabe,
Stückliste, Jobs, Inventionsübersicht und Kaufen-statt-Produzieren für
Zwischenprodukte. Es wurden weder Code noch Gestaltung oder ungeprüfte
Formeln übernommen.

## Tokenreduktion

- gezielte statt vollständiger Wiederholungslektüre,
- kurze ausführbare Prompts statt nachträglicher Langspezifikationen,
- Dokumentationsdeltas statt mehrfacher Historienwiederholung,
- fokussierte Tests plus ein SwiftPM-Debug-Gesamtlauf,
- Xcode Debug nur bei UI/Projektänderungen,
- Release-/Real-SDE-Vollsuiten nur bei betroffener Grenze.

## Geänderte Planung

AGENTS.md, REVIEW_RULES.md, LEAN_MVP_PLAN.md, P26–P37-Drafts,
Entwickler-Menü, Promptregister, Roadmap, Projektbeschreibung,
Projektstatus, Feature-Matrix, offene Aufgaben/Probleme und Tagebuch.

## Prüfung

Keine App-Builds oder Tests: Es wurden weder Swift-Code noch Projektdateien
oder Datenmodelle geändert. `git diff --check` war erfolgreich; die
relativen Markdown-Links der 17 betroffenen Steuer-/Promptdateien und alle
P26–P37-Statuszeilen wurden erfolgreich geprüft.

## Offene Risiken

P36-Recovery, vollständige Accessibility-/Performanceprüfung,
Preis-/Finanzfunktionen und öffentliche Release-/Complianceabnahme bleiben
offen. Der P37-Kernstand darf nicht als Release Candidate bezeichnet
werden.

## Nächster Prompt

P26 – schlanken Produktionsentscheidungsplan ausführen.
