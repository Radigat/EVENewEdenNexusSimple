# Abschlussbericht P02 – Zielarchitektur und Modulgrenzen

Datum: 2026-07-23  
Prompt-ID: P02  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Den gekoppelten Ein-Target-Ist-Stand in eine belastbare, kompilierbare und schrittweise migrierbare Architektur überführen. Domain, Application und Infrastructure sollten durchsetzbare Grenzen erhalten; die Python-Prozessgrenze war zu entscheiden. Neue fachliche MVP-Funktionen und SwiftData-Migrationen waren ausgeschlossen.

## Ausgangszustand

- ein ausführbares Target `NewEdenNexus`,
- ein Testtarget `NewEdenNexusTests`,
- SwiftUI, SwiftData, SSO, Keychain und Python-Adapter gemeinsam im App-Target,
- Materialaggregation über `/usr/bin/env python3`,
- Einstellung `python.executable` ohne Wirkung auf den Prozessaufruf,
- blockierendes `waitUntilExit()` ohne Timeout oder Cancellation,
- zwei erfolgreiche XCTest-Fälle,
- keine expliziten Domain-/Application-/Infrastructure-Grenzen,
- persistente `@Model`-Typen `CharacterRecord` und `ProductionProject`,
- Git-Wurzel `/Users/svenstolze`, keine Commits, Projektdateien untracked.

## Durchgeführte Änderungen

- Baseline-Targetgraph, Quellcode, Git-Zustand, Debug-Build und Ausgangstests verifiziert.
- SwiftPM-Targets für Domain, Application und Infrastructure eingeführt.
- Materialtypen, Validierungsfehler und deterministische Aggregation in Domain verschoben.
- Application-Port `MaterialSummarizing` und `SummarizeMaterialsUseCase` erstellt.
- `NativeMaterialSummaryService` als injizierbaren Swift-Adapter implementiert.
- Python-Prozessadapter, Skriptressource und ungenutzte Einstellung entfernt.
- Architektur-, Domain-/Paritäts- und Integrationsregressionstests ergänzt.
- vollständige Architekturbeschreibung und zwei ADRs erstellt.
- Steuer-, Status-, Feature-, Test- und Fortschrittsdokumentation aktualisiert.

## Architektur vorher und nachher

### Vorher

```text
NewEdenNexus
├── SwiftUI + SwiftData
├── SSO + Keychain + Network
└── PythonEngine ──> externer Python-Prozess

NewEdenNexusTests ──> NewEdenNexus
```

### Nachher

```text
NewEdenNexus
    ├──> NewEdenNexusInfrastructure
    │         ├──> NewEdenNexusApplication
    │         └──> NewEdenNexusDomain
    ├──> NewEdenNexusApplication ──> NewEdenNexusDomain
    └──> NewEdenNexusDomain
```

Testtargets:

```text
NewEdenNexusTests             ──> App + Domain + Application + Infrastructure
NewEdenNexusDomainTests       ──> Domain
NewEdenNexusArchitectureTests ──> Domain + Application
```

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/MaterialAggregation.swift`
- `Sources/NewEdenNexusApplication/SummarizeMaterialsUseCase.swift`
- `Sources/NewEdenNexusInfrastructure/NativeMaterialSummaryService.swift`
- `Tests/NewEdenNexusDomainTests/MaterialSummaryCalculatorTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- `Documentation/ARCHITECTURE.md`
- `Documentation/Architecture/ADRs/README.md`
- `Documentation/Architecture/ADRs/ADR-0001_Modul-und-Schichtenarchitektur.md`
- `Documentation/Architecture/ADRs/ADR-0002_Berechnungsruntime-Python-oder-Swift.md`
- `Documentation/Progress/Reports/2026-07-23_P02_Zielarchitektur-und-Modulgrenzen.md`

## Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- `Documentation/ARCHITECTURE_CHANGES.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/FEATURE_MATRIX.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/IMPLEMENTATION_ROADMAP.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/TEST_HISTORY.md`
- `Documentation/Prompts/README.md`
- `Documentation/Prompts/MVP/P02_Zielarchitektur.md`

## Gelöschte oder verschobene Dateien

- gelöscht: `Sources/NewEdenNexus/PythonEngine.swift`,
- gelöscht: `Sources/NewEdenNexus/Resources/Python/material_engine.py`,
- entfernt: Python-Einstellungsfeld aus `SettingsView`.

Keine Benutzerdaten-, SwiftData-Modell- oder SSO-Datei wurde gelöscht oder verschoben.

## Verschobene Typen und Verantwortungen

Die früher in `PythonEngine.swift` definierten DTOs wurden als öffentliche, `Sendable`-fähige Domain-Typen neu eingeordnet:

- `MaterialLine`,
- `MaterialSummary`.

Die Berechnungsverantwortung liegt nun in `MaterialSummaryCalculator`. Aufruf und Adapter sind über `SummarizeMaterialsUseCase`, `MaterialSummarizing` und `NativeMaterialSummaryService` getrennt.

Persistente Typen wurden bewusst nicht verschoben.

## Architekturentscheidungen

- [ADR-0001](../../Architecture/ADRs/ADR-0001_Modul-und-Schichtenarchitektur.md): inkrementelle SwiftPM-Schichtung.
- [ADR-0002](../../Architecture/ADRs/ADR-0002_Berechnungsruntime-Python-oder-Swift.md): native Swift-Runtime statt externem oder gebündeltem Python.

## Python-Entscheidung und Paritätsnachweis

Python wurde vollständig aus dem produktiven Berechnungspfad entfernt. Die Swift-Implementierung erhält die beobachtete Semantik:

- negative Mengen werden auf null geklemmt,
- Gruppierung erfolgt nach Type-ID,
- Name und Preis des ersten Eintrags bleiben maßgeblich,
- Ausgabe wird deterministisch sortiert,
- Preise und Gesamtkosten werden kaufmännisch auf zwei Stellen gerundet.

Der Paritätstest verwendet feste Eingaben und Erwartungen. Der erste P02-Testlauf fand eine abweichende binäre Double-Repräsentation nach Decimal-Rundung. Die Konvertierung wurde korrigiert und die vollständige Suite erneut erfolgreich ausgeführt.

## SwiftData-Risikoanalyse

`CharacterRecord` und `ProductionProject` bleiben unverändert im ausführbaren Target. Ein Modulwechsel kann die SwiftData-Schemaidentität beeinflussen und wurde ohne Migration nicht riskiert.

Keine Änderungen an:

- Modellfeldern,
- Typnamen,
- Modulzuordnung,
- `ModelContainer`-Typen,
- Storekonfiguration.

P03 muss Schema v1, Storeidentität, Migrationen, Altbestandstest, leere Datenbank und Repository-Grenzen bearbeiten.

## Datenmodelländerungen

Keine persistenten Datenmodelländerungen und keine Migration.

`MaterialLine` und `MaterialSummary` sind flüchtige Domain-Datentransfertypen, keine SwiftData-Modelle.

## Build-Ergebnis

### Baseline

```bash
swift package describe
swift build -c debug
swift test -c debug
```

Ergebnis: ein App-/ein Testtarget, Debug-Build erfolgreich, 2 Tests erfolgreich.

### Abschließende Prüfung

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Ergebnis:

- Targetgraph bestätigt,
- Debug-Build ✅ erfolgreich,
- Release-Build ✅ erfolgreich,
- keine Compilerwarnungen in den erfolgreichen Läufen.

## Testergebnis

Abschließend: **11 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler**.

| Suite | Tests | Ergebnis |
|---|---:|---|
| `ArchitectureBoundaryTests` | 3 | ✅ |
| `MaterialSummaryCalculatorTests` | 6 | ✅ |
| `NewEdenNexusTests` | 2 | ✅ |

Die Swift-Testing-Zeile mit 0 Tests bezieht sich auf das nicht verwendete Swift-Testing-Framework; die 11 XCTest-Tests wurden zuvor vollständig ausgeführt.

## Architekturtests

Nachgewiesen:

- Domain importiert kein SwiftUI, SwiftData, AppKit, Network oder Security.
- Application importiert keine konkreten Infrastructure-Adapter und keine UI-/Persistenz-/Netzwerkframeworks.
- ein Application-Use-Case kann mit einem Stub ohne Infrastructure ausgeführt werden.
- SwiftPM kompiliert den dokumentierten Targetgraphen ohne Zyklen.

Die Importprüfung erkennt auch attributierte Imports wie `@preconcurrency import`.

## Manuelle und strukturelle Prüfungen

- `Package.swift` vollständig gegen den dokumentierten Graph geprüft.
- alle neuen und geänderten Swift-Dateien gelesen.
- keine produktive Referenz auf `PythonEngine`, `python.executable`, `/usr/bin/env` oder `material_engine` mehr vorhanden.
- persistente Modelle und SSO-/Keychain-Dateien blieben unangetastet.
- Domain-/Application-Importgrenzen zusätzlich per `rg` und Tests geprüft.
- lokale Markdown-Verweise geprüft.
- Dokumentationsstatus und Testzahlen gegeneinander abgeglichen.

## Nicht ausgeführte Prüfungen

- kein UI-Test und kein manueller GUI-Durchlauf,
- kein Persistenz-/Migrationstest, da kein Schema geändert wurde,
- kein echter SSO-/Netzwerktest,
- kein Performance- oder Accessibility-Test,
- kein Xcode-Workspace-Build; SwiftPM bleibt der verifizierte CLI-Weg.

## Bekannte Probleme

- Git-Wurzel bleibt `/Users/svenstolze`; keine Commit-Historie und keine `.gitignore`.
- Presentation und Persistence sind im App-Target noch gekoppelt.
- direkter SwiftData-Zugriff aus vorhandenen Views bleibt bestehen.
- `fatalError` und `try?` in vorhandenen Persistenzpfaden bleiben für P04/P33.
- Geldtyp und extreme Mengenüberläufe sind noch nicht abschließend fachlich definiert.
- der Produktionsplaner-MVP fehlt weiterhin weitgehend.

## Offene Anforderungen und Übergangsschulden

- P03: Schema v1, Migrationen, Repositories, Persistenz-/Domänenmapping.
- P04: zentrale Fehlerbehandlung und Logging.
- P05: breiteres Testfundament.
- P11 ff.: produktive Composition und Injection der jeweiligen Use Cases.
- P19: Überlaufstrategie für große aggregierte Mengen.
- P27/P29: fachlicher Geldtyp und vollständige Kostenregeln.

## Abweichungen vom Projektbuch

Das Projektbuch skizziert eine vollständige Schichtenarchitektur einschließlich eigener Persistence-Ebene. P02 setzt diese bewusst inkrementell um, weil ein sofortiges Verschieben der `@Model`-Typen ohne P03-Migration Benutzerdaten gefährden könnte. Die Abweichung ist in ADR-0001 begründet und terminiert.

Die Python-Runtime war kein verbindlicher Produktbuchzwang. Die Swift-native Entscheidung folgt dem nativen, lokalen MVP.

## Abnahmekriterien

| Kriterium | Ergebnis | Nachweis |
|---|---|---|
| Architekturproblem analysiert | ✅ | Ausgangskarte, Architekturdatei, Bericht |
| eindeutige Zielarchitektur | ✅ | `ARCHITECTURE.md`, ADR-0001 |
| Abhängigkeiten abgesichert | ✅ | SwiftPM + 3 Architekturtests |
| kleinster Refactor kompiliert | ✅ | Debug- und Release-Build |
| Materialaggregation mit Parität | ✅ | 6 Domain- plus 1 Integrationstest |
| Python-Entscheidung umgesetzt | ✅ | ADR-0002, Pythonpfad entfernt |
| SwiftData/Benutzerdaten geschützt | ✅ | persistente Typen unverändert |
| Zukunftscode abgegrenzt | ✅ | keine Abhängigkeit in Domain/Application |
| keine neue Fachfunktion | ✅ | nur vorhandene Aggregation refaktoriert |
| Dokumentation vollständig | ✅ | Architektur-, Steuer- und Fortschrittsdateien |
| Abschlussbericht gespeichert | ✅ | dieses Dokument |
| gesonderter Review | ✅ | Reviewentscheidung unten |

Nicht erfüllte Abnahmekriterien: keine.

## Reviewumfang und Befunde

Geprüft wurden Prompt und Abnahmekriterien, vollständiger aktueller Inhalt aller betroffenen Dateien, Targetgraph, Importregeln, SwiftData-Risiko, Python-Parität, Build-/Testausgaben und Dokumentation. Wegen der fehlenden Commit-Historie war kein normaler Git-Diff verfügbar; die Prüfung erfolgte anhand der eng begrenzten Dateiliste und der vollständigen Inhalte.

Während des Reviews wurden zwei niedrige Qualitätsbefunde sofort korrigiert:

1. Importparser erkannte zunächst nur Zeilen, die direkt mit `import` begannen; er erkennt nun auch attributierte Imports.
2. Decimal-Konvertierung enthielt einen theoretisch stillen Null-Fallback; sie verwendet nun den nicht optionalen `Decimal(Double)`-Initialisierer.

Nach beiden Korrekturen wurden Targetbeschreibung, Debug-Build, alle Tests und Release-Build vollständig wiederholt.

Offene kritische oder hohe Reviewbefunde: keine.  
Offene mittlere P02-Befunde: keine.  
Bekannte Übergangsschulden sind terminiert und gehören zu späteren Prompts.

## Reviewentscheidung

**✅ bestanden.** Alle P02-Muss-Kriterien und die zutreffende Definition of Done sind belegt. Build, Tests, Architekturgrenzen, Datenintegrität und Dokumentation sind konsistent. Die nicht ausgeführten UI-/Persistenz-/Netzwerkprüfungen betreffen keine durch P02 geänderte Fach- oder Datenfunktion.

## Nächster empfohlener Prompt

**P03 – Domänenmodell und Migrationen** zunächst vollständig spezifizieren. P03 wurde nicht begonnen.
