# Abschlussbericht – P24 Projektreservierungen

Datum: 2026-07-25  
Prompt-ID: P24  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Projektbezogene Materialreservierungen auf der geprüften P22-/P23-
Verfügbarkeitsbasis vollständig spezifizieren, implementieren, migrieren,
testen, dokumentieren und unabhängig reviewen, ohne die
Konfliktbehandlung aus P25 vorzuziehen.

## Ausgangszustand

P23 stellte globale Sicherheitsbestände und eine berechnete
Verfügbarkeit nach Schutzmenge bereit. Eine Reservierungsentität, ein
Reservierungslebenszyklus, Persistenz, UI und Archivschutz fehlten.
`OFF-005/KI-005` betraf Reservierungen und spätere Konflikterkennung;
`OFF-006/KI-006/KI-013` erforderte bei einer Schemaänderung die Fortführung
der Migrations- und Backupkette.

Das Repository enthielt umfangreiche uncommittete Benutzer- und
Vorgängeränderungen. Sie wurden weder verworfen noch bereinigt. Es wurde
kein Commit erstellt.

## Durchgeführte Änderungen

- P24 vollständig mit Zweck, Voraussetzungen, Formeln, Zustandsautomat,
  Risiken, offenen Punkten und 23 messbaren Abnahmekriterien spezifiziert.
- Deterministischen `ProjectReservationCalculator` und validierte
  Reservierungssnapshots eingeführt.
- Application-Service mit schreibfreier Vorschau, ausdrücklicher
  Bestätigung, vollständigem Quellzustand und typisierten Fehlern ergänzt.
- Reservieren, Erhöhen/Ändern, teilweisen und vollständigen Verbrauch sowie
  Freigabe implementiert.
- Neue Überbuchungen blockiert; eigene und fremde aktive Bindungen korrekt
  getrennt.
- Additives SwiftData-Schema v14, atomaren Repositoryadapter,
  v13→v14-Migration und Backupformat 14.0.0 ergänzt.
- Archivierung von Projekten mit aktiven Reservierungen verhindert.
- Native Reservierungsansicht mit Loading-, Empty-, Fehler-, Warn-,
  Vorschau-, Bestätigungs- und Abbruchzuständen in den Graphworkflow
  integriert.
- Fehlercodes `NEN-RES-001` und `NEN-RES-002` ergänzt.
- Domain-, Application-, Persistenz-, Architektur-, Migrations-, Backup-
  und Fehlerbehandlungstests ergänzt.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProjectReservation.swift`
- `Sources/NewEdenNexusApplication/ProjectReservation.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV14.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProjectReservationRepository.swift`
- `Sources/NewEdenNexus/ProjectReservationView.swift`
- `Sources/NewEdenNexus/ProjectReservationViewModel.swift`
- `Tests/NewEdenNexusDomainTests/ProjectReservationTests.swift`
- `Tests/NewEdenNexusApplicationTests/ProjectReservationServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ProjectReservationPersistenceTests.swift`
- `Documentation/PROJECT_RESERVATIONS.md`
- `Documentation/Architecture/ADRs/ADR-0029_Globale-Projektreservierungen-und-Schema-v14.md`
- dieser Abschlussbericht

## Geänderte Dateien

Geändert wurden die App-Composition und Reservierungsnavigation, Projekt-
und Graphansichten, Projektarchivierung, Fehlerbehandlung, Migrationsplan,
Containerfactory, Backupdienst und zugehörige Tests, die
Xcode-Projektgenerierung sowie die verpflichtenden Architektur-, Datenmodell-,
Test-, Status- und Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

- Globale Projekt-/Type-ID-Bindung ohne erfundene Charakter- oder
  Lagerallokation.
- Reservierungszustände `reserved`, `partiallyConsumed`, `consumed` und
  `released`; nur die ersten beiden binden Restmengen.
- Ablaufdatum bleibt informativ und führt nicht zu automatischer Freigabe.
- Verbrauch verändert keine physische Bestandsposition.
- Vorschau und bestätigter atomarer Schreibvorgang bleiben getrennt.
- Systematische Konflikterkennung und -auflösung bleibt P25.

Details:
`Documentation/Architecture/ADRs/ADR-0029_Globale-Projektreservierungen-und-Schema-v14.md`.

## Datenmodelländerungen

Schema v14 ergänzt additiv `StockReservationRecord` mit UUID, Projekt-ID,
CCP-Type-ID, reservierter und verbrauchter Menge, Priorität, optionalem
Ablaufdatum, Status, Lebenszykluszeitstempeln und Datensatzversion. Die
Migration erfindet keine Reservierungen und verändert keine bestehenden
Projekt-, Bestands-, SDE- oder Graphdaten.

## Build-Ergebnis

Erfolgreich:

- SwiftPM Debug,
- SwiftPM Release,
- Xcode App Debug,
- Xcode App Release,
- Xcode-Projektprüfung mit 15 Targets, sieben Testtargets und zwei
  gemeinsamen Schemes.

Signing und Teamwerte blieben unverändert; die Xcode-Läufe verwendeten
`CODE_SIGNING_ALLOWED=NO`.

Das direkt im Repository liegende Xcode-Projekt wurde während eines
geöffneten Xcode-Prozesses durch `NSFileCoordinator` blockiert. Um mögliche
ungespeicherte Benutzerarbeit nicht zu schließen, wurden die Xcode-Nachweise
mit einer temporären Projektkopie und verlinkten unveränderten Quellen
ausgeführt. Dies änderte keine Projekt- oder Benutzerdaten.

## Testergebnis

- fokussierter P24-Lauf: 20 bestanden, 0 fehlgeschlagen,
- SwiftPM Debug: 408 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- SwiftPM Release: 408 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- Xcode Debug: 408 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- Xcode Release: 408 bestanden, 0 fehlgeschlagen, 0 übersprungen.

Die Suite prüft Normal-, Grenz-, Überlauf-, Bestätigungs-, Abbruch-,
Stale-State-, Parallelitäts-, Historien-, Archiv-, Roundtrip-, Migrations-,
Leerstore-, Wiederöffnungs- und Backupfälle. Übersprungene Tests gab es
nicht.

Xcode meldete nicht fehlschlagende Framework-Analysehinweise für
XCTest-Unterframeworks sowie, dass keine AppIntents-Metadaten zu extrahieren
sind. Der endgültige Zielparameter war eindeutig
`platform=macOS,arch=arm64`.

## Manuelle Prüfungen

Das Debug-App-Binary wurde mit einem isolierten Store unter `/tmp`
gestartet und kontrolliert beendet. Der Store enthielt Projekt-,
Schutzregel- und Reservierungstabellen. `PRAGMA integrity_check` meldete
vor und nach dem Lauf `ok`. Produktive Benutzerdaten wurden nicht geöffnet
oder verändert.

## Gefundene und behobene Probleme

Der unabhängige Review fand vier fehlende explizite Persistenznachweise:
Roundtrip aller vier Statuswerte, leerer v14-Initialstore, unbekanntes
Projekt und Duplikation eines Projekts ohne Übernahme von Reservierungen.
Die Tests wurden ergänzt und bestanden anschließend fokussiert sowie in
allen vier Gesamtläufen.

Der erste SwiftPM-Lauf innerhalb der Dateisandbox scheiterte an einer
Umgebungsbeschränkung von `sandbox-exec`. Die identischen Nachweise wurden
mit isolierten temporären Buildpfaden erfolgreich wiederholt.

## Bekannte Probleme und offene Anforderungen

- `OFF-005/KI-005` bleibt nur für nachträglich entstandene
  Reservierungskonflikte und deren kontrollierte Auflösung in P25 teilweise
  offen.
- Automatische Vor-Migrations-Sicherung und vollständiger Recovery-Drill
  bleiben `OFF-006/KI-006/KI-013` in P36.
- Die produktive SwiftData-Abfrage filtert Reservierungen derzeit nach dem
  Laden im Adapter. Das ist für den aktuellen Stand korrekt; eine
  Performanceaussage oder vorgezogene Optimierung erfolgt ohne Messung
  nicht.

## Abweichungen vom Projektbuch

Keine unbegründete Abweichung. Lager- und Charakterallokationen sowie
automatische Freigabe abgelaufener Bindungen wurden mangels verbindlicher
Fachregel bewusst nicht erfunden. Diese Grenze ist dokumentiert.

## Abnahmekriterien

Alle 23 Kriterien der vollständigen P24-Spezifikation sind erfüllt:
Fachmodell, Formeln, Zustände, Vorschau, Bestätigung, Atomarität,
Überbuchungsschutz, Archivschutz, UI-Zustände, Schema v14, Migration,
Backupkompatibilität, vier Build-/Testwege, manueller isolierter Start,
Dokumentation und unabhängiger Review sind nachgewiesen. P25 wurde nicht
begonnen.

## Reviewentscheidung

`✅ bestanden`. Der tatsächliche Diff, Schichtengrenzen, Domaininvarianten,
Persistenz, Projektlebenszyklus, Datenwirkung, Buildausgaben,
Testergebnisse und Pflichtdokumentation wurden getrennt geprüft. Nach den
ergänzten Regressionstests blieb kein durch P24 verursachter kritischer oder
hoher Befund offen.

## Nächster empfohlener Prompt

P25 – Reservierungskonflikte zunächst vollständig spezifizieren und
anschließend ausführen. P25 wurde nicht begonnen.

