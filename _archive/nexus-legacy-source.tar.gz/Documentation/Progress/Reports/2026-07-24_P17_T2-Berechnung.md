# Abschlussbericht P17 – T2-Berechnung

Datum: 2026-07-24  
Prompt-ID: P17  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Den P16-Manufacturing-Graphen um deterministische T2-Klassifikation,
Blueprintqualität, Invention-/Decryptorregeln und gemischte T1-/T2-Ketten
erweitern, ohne Reaktionen, Stochastik, Kosten oder persönliche ESI-Daten
vorzuziehen.

## Ausgangszustand

P16 speicherte Graphformat 4 mit Runs, Output, Blueprint-ME und rekursiven
Manufacturing-Stufen. Tech-Stufe, Blueprint-Herkunft, T2-BPC-Qualität und
Invention-Provenienz fehlten. Reaktionsprodukte waren bewusst
`reactionDeferred`. SwiftData-Schema v8 und Backupformat 8.0.0 waren aktiv.

Das Projektbuch-DOCX war als nicht lokal geladener macOS-Platzhalter nicht
auslesbar. Die vollständig spezifizierte P17-Promptdatei, die verifizierte
Industrie-Regelgrundlage, Quellcode und bisherige Berichte lieferten die
belastbare Arbeitsgrundlage.

## Durchgeführte Änderungen

- `IndustryRuleSet` Version 1 mit SDE-Bindung, Prüfstatus, Quellen und allen
  acht aktuellen Decryptorregeln samt offiziellen CCP-Type-IDs 34201 bis
  34208 angelegt.
- Blueprint-Herkunft, BPO/BPC-Art, ME, TE, lizenzierte Runs und Decryptor
  als `BlueprintPlanningQuality` modelliert und validiert.
- SDE-Invention-Beziehungen aus dem vorhandenen Katalog gelesen; Grundruns,
  Wahrscheinlichkeit und Materialreferenzen werden produktspezifisch
  übernommen.
- T2 nur bei eindeutiger Invention aus einem selbst fertigbaren
  Ausgangs-Blueprint akzeptiert. Reverse Engineering/T3 wird typisiert
  abgelehnt.
- reguläre Invention ohne Decryptor als sichtbare Standardplanung
  ME 2 / TE 4 implementiert; historische T2-BPOs und daraus kopierte BPCs
  als explizite Überschreibungen getrennt.
- erfolgreiche benötigte BPC-Kopien per ganzzahligem Ceiling und mit
  Überlaufschutz berechnet; keine garantierten oder erwarteten
  Invention-Versuche behauptet.
- Produktionsgraph auf Format 5 und Expansionsrichtlinie 2 erweitert.
- Graphvalidierung gegen manipulierte beziehungsweise fremde
  Katalogprovenienz gehärtet.
- Graphansicht um T1/T2, Herkunft, TE, Runs je Kopie und
  Invention-Grunddaten ergänzt.
- Real-SDE-Abnahmerunner um den konkreten T2-Nachweis erweitert und
  Kontaktübergabe am TTY ohne Echo abgesichert.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/IndustryRules.swift`
- `Sources/NewEdenNexusApplication/T2IndustryData.swift`
- `Tests/NewEdenNexusDomainTests/IndustryRulesTests.swift`
- `Tests/NewEdenNexusApplicationTests/T2IndustryDataTests.swift`
- `Documentation/T2_CALCULATION.md`
- `Documentation/Architecture/ADRs/ADR-0022_T2-Invention-und-Graphformat-5.md`
- dieser Abschlussbericht

## Geänderte Dateien

Fachlich geändert wurden insbesondere Produktionsgraph in Domain,
Application und UI, App-Composition, Real-SDE-Runner, P17-relevante Tests,
das generierte Xcode-Projekt sowie die verpflichtenden Architektur-,
Status-, Prompt-, Feature-, Offen-, Tagebuch- und Testdokumente.

## Gelöschte oder verschobene Dateien

Keine. Vorhandene Benutzeränderungen wurden nicht verworfen. Es wurde
nichts gestaged, committet oder gepusht.

## Architekturentscheidungen

[ADR-0022](../../Architecture/ADRs/ADR-0022_T2-Invention-und-Graphformat-5.md)
legt fest:

- konkrete SDE-Invention-Beziehung statt Namen/ID-Heuristik,
- Manufacturing-Prüfung des Ausgangs-Blueprints als T3-Grenze,
- versionierter und kataloggebundener Regelvertrag,
- Planung erfolgreicher BPCs statt erfundener Zufallsversuche,
- Graphformat 5 im bestehenden Schema-v8-Payload.

## Datenmodelländerungen

Keine SwiftData-Schemaänderung und keine Migration. Graphformat 5 erweitert
die codierte Payload. Formate 1 bis 4 bleiben lesbar und gelten als
veraltet. Backupformat 8.0.0 bleibt unverändert.

## Build-Ergebnis

Erfolgreich:

- SwiftPM Debug und Release mit isolierten Scratch-/Modulcaches,
- Xcode Debug und Release auf My Mac mit `CODE_SIGNING_ALLOWED=NO`,
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Der direkte Xcode-Zugriff auf die geöffnete Repository-Projektdatei hing
vor dem Parsen in `NSFileCoordinator`. Ein Stack-Snapshot bestätigte den
externen Dateikoordinationslock. Xcode wurde deshalb aus einer identischen
Quell-/Projektkopie unter `/private/tmp` mit getrennten Derived Data
ausgeführt. Generator und Paritätsprüfung im Repository bestanden davor.

Nicht fehlschlagende Xcode-Hinweise betrafen fehlende AppIntents-Metadaten,
den im Testhost nicht erreichbaren `linkd.autoShortcut` und bereits von
einem parallelen Testclient abgeschlossene Core-Data-Testmigrationen.

## Testergebnis

- SwiftPM Debug: 292 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 292 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 292 bestanden, 0 fehlgeschlagen.
- Xcode Release: 292 bestanden, 0 fehlgeschlagen.

Abgedeckt sind neun Blueprintqualitäten, reguläre Invention und historische
T2-BPO-Ausnahme, SDE-Grundruns/Wahrscheinlichkeit/Datacores,
fehlende/mehrdeutige/ungelöste Invention, T3-Ablehnung, gemischte
T1-/T2-Ketten, Run-/Material-/Überlaufschutz, Regelpreflight,
Manipulationsschutz, Altgraph-Erhalt, Graphformate 1 bis 5, Schema v8,
Backups, UI-, ViewModel- und Architekturgrenzen.

## Real-SDE- und manuelle Prüfungen

Offizieller Build 3444265:

- Hash
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`,
- 48 Kategorien, 1.609 Gruppen, 52.821 Typen, 5.082 Blueprints,
  19.137 Aktivitäten, 36.499 Materialien und 6.329 Produkte,
- Blueprint 691 → T2-Blueprint 11372,
- Grundrun 1, Basiswahrscheinlichkeit 0,3,
- Datacores 20172 und 20424,
- Manufacturing/Reaktion/T2, Wiederöffnung, Backup, Cleanup und
  Blockierung aller 21 bekannten Referenzlücken erfolgreich.

Die CCP-Type-IDs 34201 bis 34208 und ihre Namen/Modifier wurden zusätzlich
über die offiziellen öffentlichen CCP-ESI-Type-Endpunkte gegengeprüft und
im Regelvertrag als stabile Referenzen gespeichert.

Das Debug-App-Binary lief mit
`/private/tmp/NewEdenNexus-P17-App-Smoke/NewEdenNexus.store`.
`PRAGMA integrity_check` meldete `ok`. Produktive Benutzerdaten wurden
nicht geöffnet. Eine neue visuelle oder VoiceOver-Prüfung wurde nicht
durchgeführt und wird nicht behauptet.

## Bekannte Probleme

- Reaktionsblätter bleiben bis P18 bewusst `reactionDeferred`.
- Materialaggregation bleibt P19.
- Freie Auswahl stufenbezogener T2-Überschreibungen ist fachlich als API,
  aber noch nicht als eigene UI vorhanden.
- Der macOS-Dateikoordinationslock ist ein lokaler Werkzeugbefund.
- Zeitabhängige CCP-/Releasebedingungen werden in P37 erneut geprüft.

## Abweichungen vom Projektbuch

Keine fachliche Scope-Erweiterung. P17 importiert bewusst keine
MetaGroups-, Skill- oder Dogmadaten, weil der konkrete T2-Materialbedarf
vollständig aus bereits gespeicherten SDE-Beziehungen ableitbar ist.
Diese Minimalentscheidung ist in ADR-0022 dokumentiert.

## Abnahmekriterien

Alle 13 Kriterien des vollständig spezifizierten P17-Prompts sind erfüllt.
Preflight, Real-SDE, vier Build-/Testläufe, Bestandsschutz, isolierter
App-Store, Pflichtdokumentation und Review sind nachgewiesen.

## Reviewentscheidung

**✅ bestanden.**

Der Review fand und schloss zwei relevante Lücken:

1. Reverse Engineering/T3 hätte ohne Ausgangsprüfung als T2 erscheinen
   können.
2. Knotenqualitätsprovenienz musste exakt an Build und Inhaltshash des
   Graphen gebunden werden.

Beide Korrekturen sind implementiert und in allen vier Suites geprüft.

## Offene Anforderungen

- P18: Reaktionsstufen und verbleibende Anteile von
  OFF-004/OFF-021/OFF-028.
- P19: Aggregation und Summenüberlauf.
- P34/P36/P37: unabhängige Wartbarkeits-, Recovery- und Release-Gates.

## Nächster empfohlener Prompt

P18 – Reaktionsstufen anhand der vollständigen Spezifikation ausführen.
