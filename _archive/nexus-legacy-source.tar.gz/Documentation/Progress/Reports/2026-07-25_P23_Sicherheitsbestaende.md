# Abschlussbericht – P23 Sicherheitsbestände

Datum: 2026-07-25
Prompt-ID: P23
Status: ✅ erledigt
Review: ✅ bestanden

## Ziel

P23 vollständig spezifizieren und Sicherheitsbestände auf der
projektbezogenen P22-Verfügbarkeit implementieren. Globale Type-ID-Regeln
sollen eine Schutzmenge zurückhalten, Mindest-, Warn- und Zielwerte
erklärbar anzeigen und ohne bestätigte, aktuelle Vorschau keine Daten
verändern.

## Ausgangszustand

P20/P21 lieferten lokale und importierte Bestände, P22 eine erklärbare
physische Verfügbarkeit nach projektbezogenen Ausschlüssen. Schutzregeln,
Schwellen, persistentes Modell und Benutzeroberfläche fehlten. Schema und
Backupformat endeten bei v12. `OFF-005/KI-005` war für Schutz und
Reservierungen teilweise offen.

## Spezifikation und Scope

`Documentation/Prompts/MVP/P23_Sicherheitsbestaende.md` wurde vor der
Ausführung vollständig spezifiziert. Verbindlich festgelegt wurden:

- globale, eindeutige Regeln je positiver CCP-Type-ID,
- Sicherheitsbestand als einzige automatisch geschützte Menge,
- unabhängige optionale Mindest-, Warn- und Zielschwellen,
- vorrangige Schutzdeckung durch aktiven, bereits von P22 ausgeschlossenen
  Bestand,
- Ausschluss archivierter Bestände,
- schreibfreie Vorschau, ausdrückliche Bestätigung und vollständiger
  Source-State-Schutz,
- atomare Mehrfachänderung und Löschung,
- Schema v13, Migration, Backup, UI und 20 Abnahmekriterien.

Lagerbezogene Regeln wurden mangels belegter Allokationsregel nicht
erfunden. Projektreservierungen und Konkurrenzprüfung bleiben P24/P25.

## Durchgeführte Änderungen

### Domain

`SafetyStockPolicySnapshot`, `SafetyStockCalculator`, Ergebniszeilen und
typisierte Schwellenmeldungen wurden ergänzt. Die Berechnung verwendet
`Int64`, validiert P22-Zeilen und doppelte Type-IDs und lässt ohne Regel das
P22-Ergebnis unverändert.

### Application

`SafetyStockService` erzeugt eine schreibfreie Vorschau und speichert nur
nach Bestätigung. Vor dem Commit werden Projekt, Graph, Lager, Bestände,
P22-Konfiguration und alle betroffenen Regelversionen erneut verglichen.
Service- und Repository-Rennen werden einheitlich als veraltete Vorschau
gemeldet. Cancellation vor dem Commit schreibt nichts; ein erfolgreicher
Commit bleibt Erfolg.

### Persistenz und Datenmodell

Schema v13 ergänzt `StockPolicyRecord` mit eindeutiger UUID und Type-ID,
Schutz-/Schwellenwerten, Zeitstempeln und Datensatzversion. Der Adapter
validiert den erwarteten Regelstand und führt Anlage, Änderung und Löschung
mit einem Save aus; Fehler rollen zurück. Migrationsplan, Containerfactory
und Backupformat wurden auf v13 erweitert.

### Benutzeroberfläche

Der Produktionsgraph bietet `Sicherheitsbestände` als separates Sheet. Es
zeigt Eingabewerte, P22-Ausgang, Schutzanteile, verwendbare und ungedeckte
Mengen, prognostizierten Restbestand, Zielauffüllung und sämtliche
Schwellenmeldungen. Vorschau, Bestätigung, Laden, Fehler und Abbruch sind
sichtbar; die UI greift nicht direkt auf SwiftData zu.

### Korrektur im betroffenen Bestandspfad

Die nach erfolgreichem P22-Commit verbliebene Cancellation-Prüfung wurde
entfernt. Damit meldet auch der P22-ViewModel-Pfad einen bereits
gespeicherten Erfolg nicht fälschlich als Abbruch.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/SafetyStock.swift`
- `Sources/NewEdenNexusApplication/SafetyStock.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV13.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSafetyStockPolicyRepository.swift`
- `Sources/NewEdenNexus/SafetyStockView.swift`
- `Sources/NewEdenNexus/SafetyStockViewModel.swift`
- `Tests/NewEdenNexusDomainTests/SafetyStockTests.swift`
- `Tests/NewEdenNexusApplicationTests/SafetyStockServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/SafetyStockPersistenceTests.swift`
- `Documentation/SAFETY_STOCK.md`
- `Documentation/Architecture/ADRs/ADR-0028_Globaler-Sicherheitsbestand-und-Schema-v13.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- Composition Root, Runtime, Root-/Projekt-/Graphansichten,
- `InventoryAvailabilityViewModel.swift`,
- Migrationsplan, Containerfactory und Backupdienst,
- Backup-, Persistenz- und Architekturtests,
- Xcode-Projektkonfiguration,
- verpflichtende Status-, Feature-, Architektur-, Test- und
  Fortschrittsdokumentation.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

ADR-0028 dokumentiert globale Type-ID-Regeln, getrennte harte Schutz- und
Informationsschwellen, Preview-before-write, atomare Persistenz und Schema
v13. Berechnungsergebnisse bleiben abgeleitet und werden nicht gespeichert.

## Datenmodelländerungen

Additive v12→v13-Migration mit `StockPolicyRecord`. Bestehende Projekte,
Graphen, Lager, Bestände, Importberichte und P22-Konfigurationen bleiben
unverändert. Die Migration erfindet keine Regeln.

## Build-Ergebnis

Erfolgreich:

```text
swift test
swift test -c release
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p23-xcode-debug-final
  -resultBundlePath /tmp/new-eden-nexus-p23-xcode-debug-final.xcresult
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p23-xcode-release-final
  -resultBundlePath /tmp/new-eden-nexus-p23-xcode-release-final.xcresult
  CODE_SIGNING_ALLOWED=NO test
```

Signing und Teamwerte wurden nicht geändert. Xcode wählte aus zwei
passenden Architekturen desselben Macs arm64.

## Testergebnis

- fokussiert: 17 P23-Tests bestanden,
- SwiftPM Debug: 388/388 bestanden,
- SwiftPM Release: 388/388 bestanden,
- Xcode Debug: 388/388 bestanden,
- Xcode Release: 388/388 bestanden,
- 0 Fehler und 0 übersprungene Tests in allen vier Gesamtläufen.

Abgedeckt sind Schutzformeln, Archivbestand, unabhängige Schwellen,
Zielauffüllung, Grenzen, ungültige Daten, Vorschau/Bestätigung,
Stale-State an Service- und Repositorygrenze, Abbruch, atomare
Anlage/Änderung/Löschung, Roundtrip, Migration, Leerstore, Wiederöffnung,
Backup und UI-Schicht.

## Manuelle Prüfungen

Das Debug-App-Binary startete mit dem isolierten Store
`/tmp/new-eden-nexus-p23-manual.store` stabil und wurde kontrolliert
beendet. `PRAGMA integrity_check` ergab `ok`; die erwarteten Projekt-,
P22- und P23-Tabellen waren vorhanden. Produktive Benutzerdaten wurden
nicht geöffnet oder verändert.

## Erkannte und behobene Probleme

- Ein Repository-Rennen hätte zunächst einen allgemeinen Persistenzfehler
  geliefert. Ein typisierter Stale-State-Vertrag und Regressionstest
  schließen die Lücke.
- Die P22-UI-Grenze prüfte Cancellation noch nach erfolgreichem Commit.
  Diese Prüfung wurde entfernt und der bestehende Regressionstest bewahrt.
- Der erste SwiftPM-Sandboxlauf scheiterte am nicht beschreibbaren
  Clang-Modulcache. Alle maßgeblichen Läufe wurden mit isolierten
  temporären Pfaden erfolgreich wiederholt.

## Bekannte Probleme und offene Anforderungen

- `OFF-005/KI-005` bleibt nur für Projektreservierungen und
  Konkurrenzprüfung P24/P25 teilweise offen.
- `OFF-006/KI-006/KI-013` bleibt für automatische
  Vor-Migrations-Sicherung, Recovery-UI und End-to-End-Drill P36 offen.
- Lagerbezogene Schutzregeln sind ohne fachlich belegte Allokation nicht
  implementiert.
- Keine Reservierung, automatische Nachbestellung oder
  Einkaufslistenänderung wurde vorgezogen.

## Abweichungen vom Projektbuch

Keine unbelegte Fachregel wurde implementiert. Die im Projektbuch
genannten Materialregeln werden in P23 global je Type-ID umgesetzt.
Lagerbezogene Varianten bleiben bewusst außerhalb des Scopes, bis eine
verbindliche Allokationsregel vorliegt. Schwellen werden mangels
vorgegebener Reihenfolge unabhängig ausgewertet.

## Abnahmekriterien

Alle 20 Kriterien der P23-Spezifikation sind durch Quellcode, Tests,
Migration/Backup, isolierten App-Start und Dokumentation nachgewiesen.
Keine verursachte kritische Regression ist offen.

## Reviewentscheidung

**✅ bestanden.** Der gesonderte Review prüfte Spezifikation und offene
Punkte, Fachformel, Schichtengrenzen, Diff und Quellcode,
Preview-before-write, Bestätigung, Service-/Repository-Stale-State,
Atomarität, Cancellation-Grenzen, Migration, Backup, UI-Vertrag, vier
Gesamtläufe und Pflichtdokumentation. Der während des Reviews gefundene
Stale-State-Befund wurde korrigiert und vollständig erneut getestet.

## Nächster empfohlener Prompt

P24 – Projektreservierungen zunächst vollständig spezifizieren und
anschließend ausführen. P24 wurde nicht begonnen.
