# AUD-SDE-001 – CCP-konforme SDE-Integration: Soll-Ist-Audit

Datum: 2026-07-23  
Status des Audits: **✅ abgeschlossen**  
Status des geprüften Gesamtprompts: **⚠️ teilweise umgesetzt**

## Ziel

Den vorgelegten Gesamtprompt zur CCP-konformen Integration des EVE Online
Static Data Export gegen den tatsächlichen Projektstand prüfen und fehlende,
notwendige Arbeit ohne Produktimplementierung in Roadmap und Prompts
verbindlich einordnen.

## Ausgangszustand

P07 bis P09 hatten einen lokalen, getesteten SDE-Pfad geschaffen:

- blockweise Prüfung lokal entpackter offizieller JSONL-Daten,
- lokale SHA-256-Snapshots und atomare `.nensde`-Stagingpakete,
- fachliches Mapping von Kategorien, Gruppen, Typen und Blueprints,
- normalisierte Aktivitäten, Materialien und Produkte,
- Schema v3, atomare Aktivierung und erhaltene Rückfallstände,
- deterministischer Item- und Blueprintkatalog.

Der zuletzt real geprüfte offizielle Stand war Build `3424810`. Ein
produktiver installierter Datenstand war nicht nachgewiesen.

## Audit und aktuelle offizielle Quellen

Geprüft wurden die aktuellen offiziellen Seiten für:

- Developer License Agreement,
- Static Data und SDE-Automation,
- SDE-Metadaten und Schema-Changelog,
- ESI Best Practices und Rate Limiting,
- Third Party Policies,
- EVE Online EULA und Terms of Service.

Der offizielle Metadatenendpunkt meldete am Prüftag Build `3444265` mit Release
`2026-07-23T11:06:22Z`. Die Antwort enthielt `ETag`, `Last-Modified` und
`Cache-Control: max-age=300`. Build `3444265` wurde weder heruntergeladen noch
importiert.

## Bereits umgesetzt

- offizielle versionierte JSONL-Archiv-URL im Stagingmanifest,
- JSONL-Verarbeitung in festen Blöcken,
- Pflichtdatei-, UTF-8-, JSON-, Schlüssel- und Duplikatprüfung,
- Symlinkschutz für lokale Quelldateien,
- Task-Abbruch und Bereinigung partieller Stagingpakete,
- erneute Hashprüfung vor fachlichem Mapping,
- Referenz- und Wertebereichsvalidierung,
- stabile CCP-IDs und versionierte SDE-Stände,
- atomarer Aktivmarkerwechsel mit Rollback des Schreibkontexts,
- Erhalt alter SDE-Versionen und der Benutzerentitäten,
- Katalogzugriff ohne direkten View-/SwiftData-Zugriff,
- automatisierte lokale Import-, Migrations-, Aktivierungs- und Katalogtests.

## Teilweise umgesetzt

- Rechtsquellen waren teilweise verlinkt, aber noch nicht als aktuelle
  Complianceprüfliste dokumentiert.
- SDE-Buildnummer, internes Persistenzschema und Stagingformat existieren,
  aber Schema-Changelog-Gate und Parser-/Importschema-Version fehlen.
- lokale Fehlerfälle sind abgedeckt, HTTP-, ZIP-, Speicherplatz- und
  Crashzustände nicht.
- SDE und ESI sind architektonisch weitgehend getrennt, aber ESI-Cache-,
  Ratelimit- und Datenschutzregeln müssen vor P39 implementierungsnah
  spezifiziert werden.

## Nicht umgesetzt

- Abfrage von `latest.jsonl` durch die App,
- 24-Stunden-Prüfpolicy und persistierter Prüfstatus,
- HTTP-Cachevalidatoren, 304, Timeout, Retry, Backoff und Jitter,
- zentral konfigurierter User-Agent mit freigegebenem Kontakt,
- offizieller Archivdownload und Größen-/Speicherplatzprüfung,
- sichere ZIP-Extraktion einschließlich Zip-Slip-/Bomben-/Symlinkschutz,
- isolierter streamingfähiger Importstore und Prozess-Crash-Recovery,
- Schema-Changelog-Gate,
- strukturiertes persistentes Updateprotokoll und bereinigter Diagnoseexport,
- SDE-Einstellungs-, Status-, Fortschritts- und Offlineoberfläche,
- automatische Download-/Installationsoptionen und Aufbewahrungssteuerung,
- rechtlicher Drittanbieter-/Eigentumsbereich,
- vollständige HTTP-, ZIP-, Scheduler-, Crash-, UI- und Bestandsschutztests,
- manueller End-to-End-Funktionstest des Onlineupdatepfads.

## Neue beziehungsweise geänderte Planung

Der fehlende Umfang wurde in drei prüfbare Pakete zerlegt:

1. P07A – Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance,
2. P07B – Sicherer SDE-Download, Archivprüfung und crashfeste Aktivierung,
3. P07C – SDE-Einstellungen, Automatisierung und rechtliche Hinweise.

P12, P35–P37 sowie P39–P41 und P44 wurden um die jeweils notwendigen
SDE-/ESI-Abhängigkeiten ergänzt. Zusätzliche Datenbereiche wie Marktgruppen,
Universe, Stationen, Skills, Dogma, Units, Meta und Übersetzungen werden nur
nach dokumentiertem Fachbedarf importiert.

## Dateien

### Neu erstellt

- `Documentation/CCP_COMPLIANCE.md`
- `Documentation/SDE_CCP_INTEGRATION_AUDIT.md`
- `Documentation/Prompts/MVP/P07A_SDE-Metadaten-HTTP-Cache-Compliance.md`
- `Documentation/Prompts/MVP/P07B_SDE-Download-Archiv-Aktivierung.md`
- `Documentation/Prompts/MVP/P07C_SDE-Einstellungen-Automation-Recht.md`
- dieser Bericht

### Geändert

- Entwickler-Menü, Roadmap, Promptregister, Feature-Matrix und Projektstatus,
- offene Aufgaben, offene Punkte und bekannte Probleme,
- SDE-, Architektur-, Tagebuch- und Testdokumentation,
- abhängige MVP- und Zukunftspromptentwürfe.

### Gelöscht oder verschoben

Keine Dateien.

## Architektur- und Datenmodellwirkung

Keine Produktarchitektur und kein Datenmodell wurden geändert. Die in P07A bis
P07C beschriebene Zielaufteilung ist ein Plan; jede konkrete Entscheidung
benötigt im jeweiligen Implementierungsprompt einen ADR, Code- und
Testnachweis.

## Build- und Testergebnis

Nicht erneut ausgeführt, da nur Dokumentation geändert wurde. Letzter
unveränderter P09-Nachweis:

- Debug- und Release-Build erfolgreich,
- je 100 XCTest-Tests ohne Fehler,
- offizieller Build-3424810-E2E-Test erfolgreich.

Diese Nachweise gelten ausdrücklich nicht für die noch fehlenden
Onlineupdatefunktionen.

## Manuelle Prüfungen

- offizielle aktuelle CCP-Seiten geöffnet und abgeglichen,
- aktueller Build- und Schema-Changelog-Endpunkt read-only geprüft,
- Quellcode- und Dokumentationsbefunde gegen alle 18 Promptabschnitte
  klassifiziert,
- neue und abhängige Promptpfade auf Konsistenz geprüft.

Kein manueller App-Funktionstest, da keine SDE-Onlineoberfläche existiert.

## Bekannte Probleme und Risiken

- Der getestete Build `3424810` ist nicht der am Audit-Tag gemeldete Build
  `3444265`.
- Die App kann diese Abweichung noch nicht selbst feststellen.
- Der normalisierte Snapshot wird vor dem Store-Schreiben noch vollständig im
  Speicher gehalten.
- ZIP- und Crash-Sicherheit sind noch nicht implementiert.
- Der produktiv installierte Datenstand ist unbekannt.
- Offizielle Bedingungen können sich ändern und müssen vor Implementierung
  beziehungsweise Release erneut geprüft werden.

## Persönliche Aufgaben des Projekteigentümers

- aktuelle DLA lesen und selbst über deren Annahme entscheiden,
- geeignete Kontaktmöglichkeit für den User-Agent festlegen,
- Entwicklerkonto/-E-Mail und gegebenenfalls Monetarisierung prüfen,
- Eigentums-, Marken- und Unabhängigkeitshinweis vor Release freigeben,
- Logo-/Bildnutzung gesondert prüfen,
- Datenschutzanforderungen vor personenbezogenen ESI-Funktionen freigeben.

Der Audit ist keine Rechtsberatung und behauptet weder rechtliche
Vollständigkeit noch eine Genehmigung durch CCP.

## Erfüllte Abnahmekriterien des Audits

- tatsächlicher Stand quellcode- und testbasiert klassifiziert,
- alle Abschnitte des Gesamtprompts bewertet,
- aktuelle offizielle Quellen und Buildmetadaten dokumentiert,
- notwendige Restarbeit in Plan und Prompts eingetragen,
- keine Produkt- oder Benutzerdaten verändert,
- Abschlussbericht gespeichert.

## Nicht erfüllte Abnahmekriterien des Gesamtprompts

Die Abnahmekriterien 1–4, 6–9, 11–16 und 18 sind vollständig oder teilweise
offen. JSONL-Streaming, lokale Validierung, atomare Aktivierung und
Bestandsschutz bilden nur einen Teilnachweis.

## Reviewentscheidung

**✅ Audit bestanden.**  
**⚠️ Gesamtprompt nicht abgeschlossen.**

## Nächster empfohlener Prompt

P07A – Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance.
