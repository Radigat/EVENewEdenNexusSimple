# KI-060 – Lokale Signierung

Datum: 2026-07-29  
Status: ✅ behoben

## Ziel und Ausgangszustand

Den beim ersten P59-Lauf blockierten normalen lokalen Signingpfad
wiederherstellen, ohne Team-, Projekt- oder Benutzerdaten unnötig zu ändern.

## Ergebnis

- `security find-identity -v -p codesigning` bestätigt eine gültige lokale
  Apple-Development-Identität.
- Deren SHA-1-Auswahl entspricht bereits
  `XcodeSupport/LocalSigning.xcconfig`; das Zertifikats-OU entspricht
  `DEVELOPMENT_TEAM = 99K5WATB4A`.
- Deshalb war keine Änderung an Signingdatei, Team oder Xcode-Projekt nötig.
- Normaler arm64-Debugbuild: `BUILD SUCCEEDED`.
- `codesign --verify --deep --strict --verbose=2` bestätigt App,
  eingebettete Debug-Dylibs und Designated Requirement.
- Der signierte Build wurde nach der notwendigen OFF-061-UI-Verdrahtung
  erneut erfolgreich ausgeführt und strikt verifiziert.

## Betriebsprüfung

Der kanonische Xcode-Build öffnet den produktiven v28-Store. Beim
Steuerungsversuch wurden alte P39-/P40-Buildkopien mit gleicher Bundle-ID von
LaunchServices gestartet und meldeten `NEN-PER-001`. Sie wurden nur aus
LaunchServices ausgetragen, nicht gelöscht. Der aktuelle kanonische Prozess
zeigt diesen Startfehler nicht.

## Tests und Review

Keine Codeänderung. Der bestehende P59-Nachweis bleibt 15/15 fokussiert und
713/713 vollständig. Signing und normaler App-Start sind zusätzlich real
bestanden. Review: ✅ KI-060 bestanden.

## Offen

OFF-061 bleibt bis zur sichtbaren Teilzuordnung, dem schreibfreien Verwerfen,
der Gebührenzuordnung, Vollzuordnung und dem identischen Neustartstand
`teilweise`. P60 beginnt nicht automatisch.
