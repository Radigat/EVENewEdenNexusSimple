# P34 – Performance und große Graphen

Datum: 2026-07-26  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel und Ausgangszustand

P34 wurde ausdrücklich reaktiviert. Katalogsuche und Graphschutz waren
vorhanden, aber ein aktuelles Zeitbudget und eine begrenzte UI-Projektion für
die bestehende 25.000-Knoten-Grenze fehlten. OFF-022/OFF-027 sowie KI-029
ordneten vier große Dateien P34 zur mechanischen Teilung zu.

## Änderungen

- iterative, stabile Großgraphenprojektion:
  - `OutlineGroup` bis 500 Knoten,
  - initial 1.000 sichtbare Knoten bei größeren Graphen,
  - kontrolliertes Nachladen in 1.000er-Schritten,
  - exakte Anzeige ausgelassener Knoten,
- `LazyVStack` für große Graph- und Materiallisten,
- Knotennamenindex einmal je Aggregationsdarstellung statt je Vorkommen,
- festes Katalogbudget für 50.000 Items,
- mechanische Dateiteilung:
  - SDE-Verträge / Installationsorchestrierung,
  - Archivdownload / Archivvorbereitung,
  - Projektliste / Projekteditor,
  - Preis-CSV-Verträge / Importservice,
- Xcode-Projekt regeneriert und auf SwiftPM-Parität geprüft.

Neu erstellt wurden die fünf geteilten beziehungsweise
Projektions-Quelldateien, zwei P34-Testdateien,
`PERFORMANCE_AND_LARGE_GRAPHS.md` und ADR-0039. Gelöscht oder verschoben
wurde keine Benutzerdatei.

## Architektur und Datenwirkung

Die UI projiziert große Graphen lokal und iterativ. Der vollständige
Domänengraph, seine gespeicherte Aggregation und alle Berechnungen bleiben
unverändert. Keine Datenmodelländerung, keine Migration, keine Änderung an
Schema v20, Graphformat 7, Signing oder Team.

## Messungen

| Pfad | Ergebnis | Budget |
|---|---|---|
| 50.000-Item-Katalog, 10 × Limit 50 | voller Lauf 0,288 s SwiftPM / 0,295 s Xcode; finaler Budgetlauf 0,281/0,283 s; 51 Zeilen, 1 Batch | < 2 s |
| 25.000-Knoten-Projektion, 1.000 sichtbar | voller Lauf 0,026/0,026 s; finaler Budgetlauf 0,026/0,025 s | < 3 s |

Messumgebung: arm64, macOS-Debugbuild. Die Zeitwerte sind keine allgemeine
Produktgarantie; Zeilen-, Batch- und Sichtfenstergrenzen sind deterministisch.

## Build und Tests

```bash
swift test
xcodebuild test -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath /private/tmp/new-eden-nexus-p34-xcode-final
```

- 22 fokussierte Vertrags-/Regressionsprüfungen bestanden,
- SwiftPM Debug: 512 Tests, 0 Fehler, 0 übersprungen,
- Xcode Debug: 512 Tests, 0 Fehler, 0 übersprungen,
- finaler Budget-Recheck: vier SwiftPM- und vier Xcode-Tests bestanden,
- Projektprüfung: 15 Targets, sieben Testtargets, zwei Schemes.

Bekannte Core-Data-Migrations-, Test-UserDefaults-, AppIntents- und einmalige
Layout-Testhosthinweise verursachten keinen Fehler. Kein Releasebuild,
Real-SDE-Lauf oder vollständiger manueller Accessibility-Test, da diese
Grenzen nicht verändert wurden beziehungsweise P35/P36 gehören.

## Offene Punkte und Abweichungen

Geschlossen: OFF-017, OFF-022, OFF-027, KI-017, KI-022, KI-027 und KI-029.
Alle übrigen aktiven Einträge in `OFFEN.md` wurden geprüft und bleiben ihren
Zielpaketen zugeordnet. Keine Abweichung vom reduzierten MVP; keine
Benutzerdaten wurden geschrieben.

## Review

Geprüft wurden finaler Quellinhalt, Dateigrenzen, Geheimnissuche,
Xcode-Projektparität, Diff-Whitespace, vollständige Buildausgaben,
Testzahlen, Performancebudgets und Dokumentkonsistenz. Öffentliche Verträge
und fachliches Verhalten der mechanisch geteilten Dateien blieben durch
SDE-, Preis-, Projekt- und Architekturtests geschützt.

Entscheidung: **✅ bestanden**.

## Abnahmekriterien

Alle P34-Musskriterien erfüllt. P34 darf auf `✅ erledigt` stehen.

## Nächster Prompt

P35 – vollständige Accessibility- und UX-Politur, erst nach ausdrücklicher
Reaktivierung.
