# P25 – Reservierungskonflikte

Datum: 2026-07-25  
Status: ✅ erledigt  
Review: ✅ bestanden

## Prompt-ID und Ziel

P25 sollte nachträglich entstandene Reservierungskonflikte vollständig
spezifizieren, deterministisch erkennen, nachvollziehbar darstellen und
ausschließlich nach Vorschau und Bestätigung atomar auflösen.

## Ausgangszustand

P24 stellte globale Projekt-/Type-ID-Reservierungen, Lebenszyklus,
Überbuchungsschutz und Schema v14 bereit. Nachträgliche Konflikte durch
geänderten Bestand, Schutzregeln oder Projektbedarf wurden nicht erkannt.
`OFF-005/KI-005` war deshalb teilweise offen. Vorhandene Benutzer- und
Vorgängeränderungen wurden weder verworfen noch überschrieben; es erfolgte
kein Commit.

## Durchgeführte Änderungen

- P25 mit 27 messbaren Abnahmekriterien vollständig spezifiziert,
- drei berechnete Konfliktarten und stabile Prioritätsvorschläge
  implementiert,
- Application-Service mit Vorschau, Bestätigung und vollständigem
  Source-State ergänzt,
- bestehendes P24-Repository um projektbezogenes Lesen erweitert und für
  atomare Mehrprojekt-Reduktion/-Freigabe wiederverwendet,
- native Konfliktansicht und ViewModel in Projekt- und Graphworkflow
  integriert,
- zentrale Fehleroperationen und stabile Fehlercodes ergänzt,
- Domain-, Service-, Persistence-, UI-Architektur- und
  Fehlerbehandlungstests ergänzt,
- Xcode-Projekt aus der gemeinsamen Projektdefinition regeneriert,
- Pflichtdokumentation, ADR, Testhistorie und Statusregister aktualisiert.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ReservationConflict.swift`
- `Sources/NewEdenNexusApplication/ReservationConflict.swift`
- `Sources/NewEdenNexus/ReservationConflictView.swift`
- `Sources/NewEdenNexus/ReservationConflictViewModel.swift`
- `Tests/NewEdenNexusDomainTests/ReservationConflictTests.swift`
- `Tests/NewEdenNexusApplicationTests/ReservationConflictServiceTests.swift`
- `Documentation/RESERVATION_CONFLICTS.md`
- `Documentation/Architecture/ADRs/ADR-0030_Berechnete-Reservierungskonflikte-und-kontrollierte-Aufloesung.md`
- dieser Abschlussbericht

## Geänderte Dateien

Geändert wurden die P24-Repository-Grenze und ihr SwiftData-Adapter,
Composition Root, Runtime, Projekt-/Graphansichten, Fehlerbehandlung,
Persistenz- und Architekturtests, das generierte Xcode-Projekt sowie die
verpflichtenden Status-, Architektur-, Test- und Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Konflikte sind berechneter Zustand und werden nicht persistiert.
Prioritäten erzeugen nur Vorschläge. Änderungen sind auf bestätigte
Reduktion oder Freigabe beschränkt und werden über die vorhandene atomare
P24-Grenze gespeichert. Details stehen in ADR-0030.

## Datenmodelländerungen

Keine. Schema und Backupformat bleiben v14 beziehungsweise 14.0.0.

## Build-Ergebnis

- `swift build`: erfolgreich,
- SwiftPM Debug: erfolgreich,
- SwiftPM Release: erfolgreich,
- Xcode Debug: `TEST SUCCEEDED`,
- Xcode Release: `TEST SUCCEEDED`,
- 15 Targets, sieben Testtargets und zwei gemeinsame Schemes verifiziert,
- Signing blieb unverändert; die Xcode-Läufe verwendeten
  `CODE_SIGNING_ALLOWED=NO`.

Die Xcode-Läufe erfolgten über eine isolierte Projektkopie mit verlinkten
unveränderten Quellen, weil das in Xcode geöffnete Repositoryprojekt durch
`NSFileCoordinator` blockiert war. Benutzerarbeit wurde nicht geschlossen.

## Testergebnis

- fokussiert: 21 bestanden, 0 fehlgeschlagen,
- SwiftPM Debug: 423 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- SwiftPM Release: 423 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- Xcode Debug: 423 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- Xcode Release: 423 bestanden, 0 fehlgeschlagen, 0 übersprungen.

Die 15 neuen P25-Tests decken Konflikttypen, Priorität, Ablauf,
Überlauf, schreibfreie Vorschau, Bestätigung, ungültige Vorschläge,
Abbruch, veralteten Zustand und atomare Persistenz ab.

## Manuelle Prüfungen

Das isolierte Debug-App-Binary startete zwei Sekunden stabil mit einem
eigenen temporären v14-Store und wurde kontrolliert beendet.
`PRAGMA integrity_check` meldete während und nach dem Lauf `ok`; die
Projekt- und Reservierungstabellen waren vorhanden. Produktive
Benutzerdaten wurden nicht geöffnet.

## Bekannte Probleme

Die physische Verfügbarkeit konkurrierender Projekte wird mangels
belegter Lagerallokationsregel im P22-/P23-Kontext des betrachteten
Projekts bewertet. Diese Grenze ist sichtbar und kein geratener
Datenwert. Recovery-UI und vollständiger Wiederherstellungsdrill bleiben
`OFF-006/KI-006/KI-013` in P36.

## Offene Anforderungen

P26 bis P37 bleiben offen. P26 wurde nicht begonnen. Unabhängige aktive
Punkte in `Documentation/OFFEN.md` wurden erneut geprüft und sind keine
P25-Voraussetzung.

## Abweichungen vom Projektbuch

Keine bekannte fachliche Abweichung. Eine Charakter- oder
Lagerallokation wurde bewusst nicht erfunden, weil dafür keine
verbindliche Regel vorliegt.

## Abnahmekriterien

Alle 27 Kriterien der P25-Spezifikation sind erfüllt. `OFF-005/KI-005`
ist geschlossen. Build, Tests, isolierter Start, Dokumentation und
gesonderter Review sind nachgewiesen.

## Reviewentscheidung

✅ bestanden. Der unabhängige Kontrollschritt prüfte Implementierung,
Persistenzgrenze, Sicherheitsvertrag, Tests, Projektdatei, Dokumentation
und Diff. Es besteht keine durch P25 verursachte kritische Regression.

## Nächster empfohlener Prompt

P26 – Build-or-Buy zunächst vollständig spezifizieren und anschließend
ausführen. P26 wurde nicht begonnen.
