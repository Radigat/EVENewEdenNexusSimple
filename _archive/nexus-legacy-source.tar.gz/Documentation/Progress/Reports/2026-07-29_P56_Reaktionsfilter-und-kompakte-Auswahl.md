# P56 – Reaktionsfilter und kompakte Auswahl

## Ziel und Ausgangszustand

Die erste P56-Fassung fasste Reaktionen gemeinsam zusammen und wiederholte
den Itemnamen in jeder sichtbaren Pickerbeschriftung.

## Änderungen

- Biochemical, Composite und Hybrid Polymer Reactions getrennt,
- unklassifizierte Reaktionen sichtbar und ohne Vermutung erhalten,
- Produktionsart-Filter ergänzt,
- globale Sofortaktionen **Alles bauen** und **Alles kaufen** ergänzt,
- Gruppenaktionen und Einzelabweichungen erhalten,
- Einzelzeilen auf Itemname sowie **Bauen/Kaufen** verdichtet,
- VoiceOver-Kontext weiterhin itembezogen.

Gelöschte oder verschobene Dateien: keine.  
Datenmodell/Migration: nicht betroffen.  
Produktive Benutzerdaten: nicht verändert.

## Prüfung

- `swift test --filter BuildOrBuyWorkspaceViewModelTests`: 7/7 bestanden,
- `swift test --filter ProductionWorkspaceArchitectureTests`: 1/1 bestanden,
- `swift test`: 679/679 bestanden,
- Xcode Debug für macOS arm64: `BUILD SUCCEEDED`,
- Projektsteuerung, Links und Diff-Hygiene: abschließend geprüft.

## Review und Abnahme

Technische Kontrollprüfung bestanden. Kategorien stammen ausschließlich aus
`reactionKind`; ein fehlender Wert bleibt sichtbar unklassifiziert. Filter
schreiben nicht, Auswahländerungen bleiben bis Vorschau und Bestätigung lokal.

`OFF-054` bleibt als Eigentümer-Sichttest offen. P56 bleibt deshalb
`⚠️ technisch bestanden`.

## Nächster Schritt

Im Eigentümerbetrieb die drei Reaktionsfilter, **Alles bauen**, eine
Gruppenwahl, eine Einzelabweichung, Vorschau, Budgetwirkung und Wiederöffnung
prüfen.
