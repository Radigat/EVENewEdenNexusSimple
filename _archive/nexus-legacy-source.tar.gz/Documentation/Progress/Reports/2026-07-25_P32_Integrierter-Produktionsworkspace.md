# P32 – Integrierter Produktionsworkspace

Datum: 2026-07-25  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel

Den vorhandenen Projekt-, Graph-, Lager- und P26-Stand als bedienbaren
lokalen Produktions-/Inventionsworkflow zusammenführen, ohne Preise oder
Marktfunktionen vorzuziehen.

## Ausgangszustand

P11–P26 stellten die erforderlichen Dienste und Einzelansichten bereit. Der
P26-Plan besaß keine produktive UI, positive Fehlmengen waren nicht
kopierbar und das Dashboard verwendete direkte SwiftData-Abfragen.

## Durchgeführte Änderungen

- vollständige P32-Spezifikation mit Voraussetzungen, Risiken und Abnahme,
- produktiver `BuildOrBuyWorkspaceViewModel` am Application-Port,
- `ProductionWorkspaceView` im vorhandenen Projekt-/Graphdialog,
- Bauen/Kaufen mit schreibfreier Vorschau und Bestätigungsdialog,
- Produktions- und Inventionsjobs einschließlich Lagerverwendung,
- Bedarf, verwendbarer Bestand und positive Fehlmenge je Type-ID,
- Konfliktstatus und bestehende Lager-/Schutz-/Reservierungsansichten,
- kopierbare Liste im Format `Name<Tab>Menge`,
- Schutz gegen projektfremde, veraltete und unberechnete Vorschauen,
- persistenzfreies Dashboard über eigenen ViewModel-/Use-Case-Pfad,
- zentrale sichere Fehlerzuordnung `NEN-PLAN-001`,
- Xcode-Projekt regeneriert und Parität geprüft.

## Neu erstellte Dateien

- `Sources/NewEdenNexus/BuildOrBuyWorkspaceViewModel.swift`
- `Sources/NewEdenNexus/ProductionWorkspaceView.swift`
- `Sources/NewEdenNexus/DashboardViewModel.swift`
- `Tests/NewEdenNexusTests/BuildOrBuyWorkspaceViewModelTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ProductionWorkspaceArchitectureTests.swift`
- `Documentation/PRODUCTION_WORKSPACE.md`
- `Documentation/Architecture/ADRs/ADR-0032_Integrierter-Produktionsworkspace.md`
- dieser Abschlussbericht

## Geänderte Dateien

App-Runtime, Root-/Projekt-/Graph-/Dashboard-Views,
`ProjectAppComposition`, zentrale Fehlerbehandlung und ihr Test,
`NewEdenNexus.xcodeproj` sowie verpflichtende Status-, Architektur- und
Testdokumentation.

## Gelöschte oder verschobene Dateien

Keine. Vorhandene Benutzeränderungen und zusätzliche untracked
Xcode-Projektverzeichnisse wurden nicht verändert oder verworfen.

## Architekturentscheidungen

Der Workspace ist eine Presentation-Schicht über dem vorhandenen
`BuildOrBuyPlanning`-Port. Konkrete Repositories bleiben in der Composition
Root. Der Workspace berechnet oder persistiert keinen zweiten Plan.
Siehe ADR-0032.

## Datenmodelländerungen

Keine. Schema und Backupformat bleiben v15/15.0.0.

## Build-Ergebnis

- `swift build -c debug`: erfolgreich,
- Xcode Debug über das App-Scheme: erfolgreich,
- Xcode-Parität: 15 Targets, sieben Testtargets, zwei Schemes,
- keine Signing- oder Teamänderung.

## Testergebnis

- fokussiert: 8/8 bestanden,
- `swift test -c debug`: 439/439, 0 Fehler, 0 übersprungen,
- Xcode Debug: 439/439, 0 Fehler, 0 übersprungen.

Geprüft wurden T1-Bauen/Kaufen, T2-Invention, Lagerabzug,
deterministische positive Textliste, Sperre veralteter Listen,
Projekt-/Graphwechsel, schmale/breite Rendergröße, persistenzfreie
UI-Grenzen, Tastatur-/Accessibility-Verträge und sichere Fehlerzuordnung.

## Manuelle Prüfungen

Eine isolierte App-Instanz wurde mit einem temporären Store gestartet und
kontrolliert beendet. Der native Computer-Use-Kanal schloss jedoch vor einer
auswertbaren Antwort. Daher wird kein manueller Fenster- oder
VoiceOver-Erfolg behauptet. Schmale/breite SwiftUI-Renderprüfungen sowie
statische Tastatur-/Accessibility-Verträge bestanden.

## Bekannte Probleme

- Die vollständige appweite UX-/VoiceOver-Politur bleibt P35.
- Future-SSO-/ESI-Views mit direktem SwiftData-Zugriff bleiben P38.
- Recovery-Drill und öffentlicher Release-Recheck bleiben verschoben.

## Offene Anforderungen

P37 muss den Kern mit realitätsnahen T1- und T2/Inventionsfällen intern
end-to-end abnehmen. Preise, Kosten, persistenter Einkaufsstatus und Export
bleiben P27–P31.

## Abweichungen vom Projektbuch

Der tokenarme Kern liefert nur eine kopierbare Textliste. Preise,
Gewinnkennzahlen, Einkaufsstatus, CSV-Export und Optimierung wurden gemäß
PLAN-002 bewusst nicht vorgezogen.

## Abnahmekriterien

1. T1 mit Teilbestand: erfüllt durch P26-Fach- und P32-ViewModeltest.
2. T2 mit Inventionsjob/Lagerabzug: erfüllt.
3. Bauen/Kaufen ohne Doppelzählung: erfüllt.
4. Projektwechsel/Abbruch ohne falschen Schreibstand: erfüllt.
5. schmal/breit, Tastatur und Accessibility: automatisiert erfüllt;
   manueller Computer-Use-Nachweis nicht behauptet.
6. fokussiert, SwiftPM und Xcode Debug: erfüllt.
7. Dokumentation und Bericht: erfüllt.
8. `OFF-008` im Kern und `OFF-011`-Textliste: erfüllt.

## Reviewentscheidung

Der getrennte Kontrollschritt prüfte Spezifikation, Diff, Ports,
Composition, Fehler-/Abbruchpfade, stale/project-bound State,
Zwischenablage, Tests, Xcode-Projekt und Dokumentation. Er ergänzte den
Schutz gegen projektfremde/veraltete Vorschauen und sperrte das Kopieren
einer alten Liste nach unberechneten Änderungen. Kein kritischer oder hoher
P32-Fehler bleibt offen. Entscheidung: **✅ bestanden**.

## Nächster empfohlener Prompt

P37 – interne Kernabnahme. Kein öffentlicher Release Candidate.
