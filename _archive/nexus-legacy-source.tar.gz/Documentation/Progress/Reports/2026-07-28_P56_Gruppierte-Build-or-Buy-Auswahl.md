# P56 – Gruppierte Build-or-Buy-Auswahl

## Ziel und Ausgangszustand

Die bisher ausschließlich einzelne Build-or-Buy-Auswahl im
Produktionsworkspace wurde für große Produktionsketten zu aufwendig.

## Änderungen

- Zwischenstufen nach Produktion, T2/Invention und Reaktion gruppiert,
- Gruppenaktionen **Alle bauen** und **Alle kaufen** ergänzt,
- Einzelentscheidungen eingeklappt erhalten,
- widersprüchliche Kategorien fail-closed in einer neutralen Restgruppe,
- Type-IDs aus der sichtbaren Entscheidungszeile entfernt,
- Einkaufsliste und Budget weiterhin über den bestehenden P26-Plan abgeleitet.

Neue Dateien: P56-Prompt und ADR-0057.  
Gelöschte oder verschobene Dateien: keine.  
Datenmodell/Migration: nicht betroffen.

## Prüfung

- `swift test --filter BuildOrBuyWorkspaceViewModelTests`: 7/7 bestanden,
- `swift test --filter ProductionWorkspaceArchitectureTests`: 1/1 bestanden,
- `swift test`: 679/679 bestanden,
- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P56-DerivedData build`:
  **BUILD SUCCEEDED**,
- keine produktiven Benutzerdaten geschrieben.

## Review und Abnahme

Technische Kontrollprüfung bestanden. Die Gruppenaktionen verändern nur den
Entwurf; Vorschau und Bestätigung bleiben zwingend. `OFF-054` bleibt für den
sichtbaren Eigentümerlauf offen, daher Status `⚠️ technisch bestanden`.

## Offene Anforderung und nächster Schritt

Im Eigentümerbetrieb **Alle Reaktionen kaufen**, eine einzelne Abweichung,
Vorschau, Übernahme, Einkaufsliste, Budget und Wiederöffnung prüfen.
P54 bleibt unabhängig davon commit-freigabepflichtig.
