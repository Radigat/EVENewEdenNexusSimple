# Abschlussbericht – P22: Verfügbarkeit und Ausschlüsse

Datum: 2026-07-24  
Prompt-ID: P22  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

Die aggregierten Endmaterialbedarfe eines aktuellen Produktionsgraphen mit
lokalen P20/P21-Beständen abgleichen und je Projekt nachvollziehbar
festlegen, welche Lager, Materialien und Mengen grundsätzlich einbezogen
werden dürfen. Sicherheitsbestände, Reservierungen und Build-or-Buy bleiben
außerhalb von P22.

## Ausgangszustand

- Graphformat 7 lieferte Type-ID-basierte Bruttobedarfe.
- Schema v11 enthielt lokale Lager, manuelle/importierte Bestände und
  CSV-Importberichte.
- Projektbezogene Freigaberegeln, physische Verfügbarkeit,
  Preview-before-write und eine passende UI fehlten.
- Der Arbeitsbaum enthielt umfangreiche vorhandene uncommittete Änderungen
  aus P09B bis P21 und weitere Benutzerdateien. Sie wurden nicht verworfen,
  bereinigt, gestaged oder committet.

## Durchgeführte Änderungen

### Domain und Application

- `InventoryAvailabilityMode`, validierte Konfiguration, Obergrenzen,
  Ergebniszeilen und Formelversion ergänzt.
- gespeicherten, aktiven, archivbedingt, lagerbedingt, materialbedingt und
  durch Obergrenze ausgeschlossenen Bestand ohne Doppelzählung berechnet.
- alle Additionen mit `Int64.addingReportingOverflow` geschützt.
- `InventoryAvailabilityService` mit aktuellem Projekt-/Graph-Gate,
  schreibfreier Vorschau, Bestätigung, Stale-State-Schutz und Cancellation
  umgesetzt.
- gespeicherte Regeln für nicht mehr benötigte Materialien bleiben als
  ungenutzte Regeln sichtbar; neue unbekannte Regeln werden abgelehnt.

### Persistenz und Migration

- additives `NexusSchemaV12` mit genau einer
  `InventoryAvailabilityConfigurationRecord` je Projekt ergänzt.
- optimistischen, atomaren SwiftData-Repositoryadapter implementiert.
- leichte v11→v12-Migration, aktuelle Containerfactory und Backupformat
  12.0.0 ergänzt.
- Backups 1.0.0 bis 12.0.0 bleiben akzeptiert; 13.0.0 wird abgelehnt.

### Benutzeroberfläche

- `Bestand abgleichen` aus dem Produktionsgraphen erreichbar gemacht.
- Modus, Lagerauswahl, Materialausschluss, Obergrenze und vollständige
  Detailaufschlüsselung ergänzt.
- Loading-, Empty-, Warn-, Preview-, Save-, Abbruch-, Fehler- und
  Bestätigungsgrenzen verdrahtet.
- P23–P25-Abgrenzung sichtbar gemacht.
- SwiftUI enthält weder SwiftData-Zugriffe noch Berechnungsfachlogik.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/InventoryAvailability.swift`
- `Sources/NewEdenNexusApplication/InventoryAvailability.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV12.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataInventoryAvailabilityRepository.swift`
- `Sources/NewEdenNexus/InventoryAvailabilityView.swift`
- `Sources/NewEdenNexus/InventoryAvailabilityViewModel.swift`
- `Tests/NewEdenNexusDomainTests/InventoryAvailabilityTests.swift`
- `Tests/NewEdenNexusApplicationTests/InventoryAvailabilityServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/InventoryAvailabilityPersistenceTests.swift`
- `Documentation/INVENTORY_AVAILABILITY.md`
- `Documentation/Architecture/ADRs/ADR-0027_Projektbezogene-Verfuegbarkeit-und-Schema-v12.md`
- dieser Bericht.

## Geänderte Dateien

- Composition Root, Runtime sowie Projekt-/Graphansichten,
- Migrationsplan, Containerfactory, Backupdienst und Backuptests,
- zentrale sichere Inventory-Fehlertexte,
- Architekturprüfung und generiertes Xcode-Projekt,
- P22-Spezifikation, Promptregister, Entwickler-Menü, Feature-Matrix,
  Status, Roadmap, Datenmodell, Teststrategie/-historie, Tagebuch,
  OFFEN/OPEN_TASKS/KNOWN_ISSUES und ADR-Register.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

- Nur Benutzerregeln werden persistiert; Ergebniszahlen werden aus dem
  aktuellen Zustand reproduzierbar neu berechnet.
- Ausschlusspriorität: Archiv → Lager/Modus → Material → Obergrenze.
- Physische P22-Verfügbarkeit ist keine endgültig freie Menge.
- Preview und Apply sind getrennte, durch Quellzustand und Bestätigung
  geschützte Phasen.
- Details: `ADR-0027`.

## Datenmodelländerung

Schema v12 ergänzt additiv eine projektbezogene
Verfügbarkeitskonfiguration. Die Migration erfindet keine Regeln. Ohne
Datensatz gilt „alle aktiven Lager“ ohne Materialausschlüsse oder
Obergrenzen.

## Build-Ergebnis

Erfolgreich:

- `swift build` Debug,
- `swift test` Debug,
- `swift test -c release`,
- `xcodebuild ... -configuration Debug ... test`,
- `xcodebuild ... -configuration Release ... test`.

Xcode erkannte 15 Targets, Debug/Release und die benötigten Schemes. Signing
war für CLI-Läufe ausgeschaltet; Team- oder Signing-Einstellungen wurden
nicht geändert. Die Warnung über mehrere passende Architekturen desselben
Mac war nicht testrelevant; arm64 wurde verwendet.

## Testergebnis

| Weg | Konfiguration | Ergebnis |
|---|---|---:|
| SwiftPM | Debug | 371 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| SwiftPM | Release | 371 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| Xcode | Debug | 371 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| Xcode | Release | 371 bestanden, 0 fehlgeschlagen, 0 übersprungen |

18 neue P22-Tests prüfen Domainregeln, Filterpriorität, Surplus,
Überlauf, Servicegates, Vorschau, Bestätigung, Stale-State, Cancellation,
ungenutzte Regeln, Repository-Roundtrip, Migration, zweite Öffnung und
Leerstore. Bestehende Backuptests wurden auf Schema 12 erweitert.

## Manuelle Prüfungen

- Debug-App mit ausschließlich
  `/tmp/new-eden-nexus-p22-manual.store` gestartet und kontrolliert beendet.
- `PRAGMA integrity_check = ok`.
- erwartete Projekt-, Bestands- und
  `InventoryAvailabilityConfigurationRecord`-Tabellen vorhanden.
- keine produktiven Benutzerdaten geöffnet.
- keine neue visuelle VoiceOver-Abnahme; vollständige UX-Abnahme bleibt
  P35/P37.

## Gefundene und behobene Probleme

- Ein Test-Defaultparameter verwendete unzulässig eine Instanzmethode; vor
  der Testausführung korrigiert.
- Ein Stale-Graph-Referenztest änderte anfangs nur einen nichtfachlichen
  Zeitstempel. Er prüft nun korrekt eine Zielmengenänderung.
- Ein gespeicherter nicht mehr verwendeter Materialfilter wurde anfangs wie
  eine neue unbekannte Regel abgelehnt. Die endgültige Logik erhält
  bestehende Benutzerregeln sichtbar, lehnt aber neu erfundene IDs weiter
  ab.
- Der gesonderte Review erkannte ein Abbruchfenster nach bereits
  erfolgreichem Speichern: Eine danach eintreffende Cancellation hätte den
  bestätigten Schreibvorgang fälschlich als Fehler melden können. Der
  Apply-Pfad liefert nun unmittelbar das gespeicherte Ergebnis zurück; ein
  eigener Regressionstest belegt dieses Commit-Point-Verhalten.

## Bekannte Probleme und offene Anforderungen

- `OFF-005/KI-005` bleibt teilweise für P23–P25:
  Sicherheitsbestände und Reservierungen.
- `OFF-006/KI-006/KI-013` ist bis Schema/Backup v12 belegt; automatische
  Vor-Migrationssicherung und realer Recovery-Drill bleiben P36.
- vollständige VoiceOver-/Fensterbreiten-Abnahme bleibt P35/P37.
- keine fachliche Umsetzung von P23 oder späteren Paketen.

## Abweichungen vom Projektbuch

Keine unbegründete Abweichung. Der Projektbuchbegriff „verfügbar“ wird für
die gestufte MVP-Umsetzung präzisiert: P22 liefert physischen Bestand nach
Ausschlüssen; P23–P25 ziehen Schutzbestand und Reservierungen ab.

## Abnahmekriterien

Alle 18 Kriterien der vollständigen P22-Spezifikation sind erfüllt:
Graphbasis, drei Modi, getrennte Ausschlüsse, Type-ID-Regeln,
Überlaufschutz, Preview/Bestätigung, Stale-State, kanonische atomare
Schema-v12-Persistenz, Migration, Backup, UI, Tests, vier Buildwege,
Pflichtdokumentation und gesonderter Review.

## Gesonderter Review

Der Review prüfte nicht nur die Abschlussaussagen, sondern:

- tatsächlichen P22-Code und die betroffenen Schichtengrenzen,
- Filtergleichungen und Doppelzählung,
- Vorschau-/Apply-/Abbruch-/Parallelitätspfade,
- Schema-v12-Modell, Migration und Backupgrenze,
- fokussierte und vollständige Testausgaben,
- beide Xcode-Ergebnisbundles mit je 371 erfolgreichen Tests,
- isolierten App-/SQLite-Nachweis,
- `git diff --check`, Xcode-Projektkonsistenz und Pflichtdokumentation,
- jeden aktiven OFFEN-/KNOWN_ISSUES-Eintrag.

Es besteht kein durch P22 verursachter kritischer Fehler. Die offenen Punkte
sind klar späteren Paketen zugeordnet und blockieren P22 nicht.

Reviewentscheidung: **✅ bestanden**.

## Nächster empfohlener Prompt

**P23 – Sicherheitsbestände zunächst vollständig spezifizieren und
anschließend ausführen.** P23 wurde nicht begonnen; Reservierungen bleiben
P24/P25.
