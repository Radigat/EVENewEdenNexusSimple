# P12 – Kataloggestützte Zielproduktauswahl

Datum: 2026-07-24  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

Produktionsprojekte an ein reproduzierbares, im aktiven lokalen SDE-Katalog
validiertes Produkt-, Aktivitäts- und Blueprintziel binden und bestehende
Projekte ohne erfundene Namenszuordnung erhalten.

## Ausgangszustand

P09 stellte Suche und Kataloglookups, P10 den deterministischen Resolver und
P11 den Projektlebenszyklus bereit. Projekte speicherten jedoch nur freien
Produkttext. Schema v4 besaß keine Ziel-IDs oder Katalogprovenienz.
OFF-026 war vor Beginn nachweislich erledigt. P13 war und blieb unbegonnen.

## Durchgeführte Änderungen

- validiertes Domain-Ziel für Fertigung und Reaktion,
- lokalisierte positive Ganzzahlprüfung ohne 100-Millionen-Grenze,
- zentraler UI-/SwiftData-freier Such-, Options-, Auswahl- und
  Revalidierungsservice,
- Einzelprüfung mehrerer Blueprintkandidaten über P10,
- additive Schema-v5-Migration mit fünf optionalen Zielfeldern,
- vollständiger Repository-Roundtrip und Zielerhalt bei Status,
  Duplikat, Archiv und Restore,
- kataloggestützter Projekteditor mit verzögerter abbrechbarer Suche,
  Aktivitäts-/Kategorie-/Gruppenfilter, Blueprintauswahl, Zuständen,
  Tastaturaktionen und Accessibility-Labels,
- Revalidierung gespeicherter IDs beim Bearbeiten,
- stabiler Fehlercode `NEN-PROJ-001`,
- Backup-Schemaversion 5.0.0 und Kompatibilität zu 1.0.0–4.0.0,
- Xcode-Projekt regeneriert und Parität geprüft.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ProductionTargetSelection.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV5.swift`
- `Tests/NewEdenNexusDomainTests/ProductionTargetSelectionTests.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionTargetSelectionServiceTests.swift`
- `Documentation/PRODUCT_TARGET_SELECTION.md`
- `Documentation/Architecture/ADRs/ADR-0017_Kataloggebundenes-Produktionsziel-und-Schema-v5.md`
- dieser Bericht

## Geänderte Dateien

Domain-Projektmodell, Projektlebenszyklus, SwiftData-Repository und
Migrationplan, Backupdienst, Projekt-ViewModel, Composition Root,
Projektansicht, Xcode-Projektmetadaten, bestehende Tests und
Pflichtdokumentation.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Siehe ADR-0017. Name ist kein fachlicher Schlüssel. Auswahlvalidierung liegt
in Application; Persistence speichert nur validierte IDs und Provenienz.
Bestandsprojekte werden niemals anhand ihres Namens umgedeutet.

## Datenmodelländerung

Schema v5 ergänzt `ProductionProject` ausschließlich additiv. Der getestete
v4→v5-Pfad erhält aktive, abgeschlossene und archivierte Datensätze,
Statuswerte und Zeitstempel; alle neuen Zielfelder bleiben bei Altprojekten
leer. Die vollständige Legacy→v5-Kette und zweite Storeöffnung sind durch die
bestehenden plus neuen Migrationstests abgedeckt.

## Build-Ergebnis

- SwiftPM Debug: erfolgreich.
- SwiftPM Release: erfolgreich.
- Xcode Debug: erfolgreich, isolierte unveränderte Prüfkopie.
- Xcode Release: erfolgreich, isolierte unveränderte Prüfkopie.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Ein direkter Xcode-Aufruf im File-Provider-Arbeitsordner blockierte in
`NSFileCoordinator` beim Lesen der Projektdatei. Die unveränderten für den
Build erforderlichen Dateien wurden deshalb in ein isoliertes
`/private/tmp`-Verzeichnis kopiert; dort bestanden beide Xcode-Läufe.
SwiftPM meldete im eingeschränkten Prüfumfeld lediglich deaktivierte
Benutzercaches; Xcode meldete keine Compilerwarnung. Temporäre
SwiftData-Tests gaben bekannte Core-Data-Registrierungshinweise auf stderr
aus, ohne Testfehler oder Datenwirkung.

Finale Ergebnisdateien:

- Debug:
  `/private/tmp/NewEdenNexus-P12-xcode-min-debug/Logs/Test/Test-NewEdenNexus-2026.07.24_08-21-28-+0200.xcresult`
- Release:
  `/private/tmp/NewEdenNexus-P12-xcode-min-release/Logs/Test/Test-NewEdenNexus-2026.07.24_08-21-58-+0200.xcresult`

## Testergebnis

- SwiftPM Debug: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- fokussierter P12-Lauf: 27 Tests, 0 Fehler.

Abgedeckt sind Zielvalidierung, Mengenrandfälle, Suche/Filter/Limit,
Eindeutigkeit, explizite Blueprintwahl, falsche Blueprints, unaufgelöste
Referenzen mit gültigem Alternativkandidaten, Versionswechsel, Cancellation,
Lebenszyklus, Repository-Roundtrip, v4→v5, vollständige Migrationskette,
zweite Storeöffnung, Backupversion, ViewModel und UI-Architektur.

## Manuelle Prüfungen

Das Debug-App-Bundle wurde als echter Prozess mit
`--new-eden-nexus-isolated-store` gestartet. Der isolierte Store wurde
angelegt und enthielt die erwarteten Schema-v5-Tabellen sowie alle fünf neuen
Zielspalten. Der Prozess wurde anschließend gezielt beendet.

Die Computer-Use-Accessibility-Verbindung schloss bei der Abfrage des
SwiftUI-Fensters auf Transportebene; der abschließende Wiederholungsversuch
lief ebenfalls in einen Werkzeugtimeout. Daher wird kein neuer visueller
VoiceOver-Screenshot behauptet. Tastatur-, Accessibility- und
Zustandsanforderungen sind durch Quell-/Architekturtests geprüft; der
allgemeine echte Fenster-/VoiceOver-Grundnachweis aus P09B bleibt gültig.
Der finale isolierte App-Prozess legte
`/private/tmp/NewEdenNexus-P12-UIFinal-0822/NewEdenNexus.store` an;
`quick_check` war `ok` und alle fünf Schema-v5-Zielspalten waren vorhanden.

## Bekannte Probleme

Keine durch P12 verursachte kritische Regression. Bestehende offene Punkte
für Produktionsgraph, Bestände, Preise, Wartbarkeit und Recovery bleiben
ihren späteren Prompts zugeordnet. Die File-Provider-Koordination des direkten
Xcode-Aufrufs ist eine Umgebungsgrenze, kein reproduzierter Codefehler.

## Abweichungen vom Projektbuch

Keine fachliche Abweichung. Marktgruppenobjekte wurden bewusst nicht nur für
P12 importiert, weil Kategorie, Gruppe und Aktivität den aktuellen
Auswahlbedarf vollständig decken.

## Abnahmekriterien

Alle P12-Abnahmekriterien sind erfüllt. OFF-026 ist erledigt, die vier
vollständigen Suites sind grün, Schema v5 und Bestandsschutz sind geprüft,
Dokumentation und Review liegen vor. P13 wurde nicht begonnen.

## Reviewentscheidung

Der gesonderte Review prüfte die vollständige P12-Spezifikation, den
tatsächlichen Git-Diff einschließlich untracked Dateien, Schichtengrenzen,
Auswahl- und Fehlerpfade, Migration, Backupkompatibilität,
Repository-Roundtrip, erneute Storeöffnung, die vier finalen Vollsuites,
Projektparität und Pflichtdokumentation.

- kritisch/hoch: keine offenen P12-Befunde,
- mittel: kein offener P12-Befund,
- niedrig: `OFF-027`/`KI-027` dokumentiert die spätere mechanische Teilung
  der gewachsenen Projektview; kein Funktions- oder DoD-Blocker,
- Datenintegrität: v4→v5 additiv, Bestandsprojekte ohne erfundene Zuordnung,
- Scope: P13 und spätere Fachfunktionen nicht begonnen,
- Benutzeränderungen: keine vorhandene Änderung verworfen oder bereinigt.

Entscheidung: **✅ bestanden**.

## Nächster empfohlener Prompt

P13 zunächst vollständig spezifizieren und anschließend den erklärbaren
Produktionsgraphen implementieren. Dabei alle für P13 notwendigen offenen
Punkte gemäß `AGENTS.md` einbeziehen.
