# Abschlussbericht P03 – Domänenmodell, Schema v1 und Migrationen

- **Prompt-ID:** P03
- **Datum:** 2026-07-23
- **Status:** ✅ erledigt
- **Review:** ✅ bestanden

## Ziel

Den unversionierten SwiftData-Ausgangsstand ohne Datenverlust in ein explizites Schema v1 überführen, Persistenz als eigenen Target abgrenzen und einen UI-unabhängigen Domain-/Repository-Pfad für Produktionsprojekte schaffen. Spätere MVP-Fachentitäten und Zukunftsfunktionen waren ausdrücklich ausgeschlossen.

## Ausgangszustand

Nach P02 gab es die Targets Domain, Application, Infrastructure und App. Die SwiftData-Typen `CharacterRecord` und `ProductionProject` sowie die direkte `ModelContainer`-Erzeugung lagen weiterhin im App-Target. Es existierten keine Schemaversion, kein Migrationsplan, keine zentrale Containerfactory, kein Projektdomänenmodell und kein Repository-Port. Debug-/Release-Build und 11 Tests waren grün.

Die Git-Wurzel liegt weiterhin in `/Users/svenstolze`, Branch `main` besitzt keine Commits und das Projekt ist vollständig untracked. Deshalb wurde kein unüberschaubarer Home-Verzeichnis-Diff verändert, verworfen, gestaged oder committed.

## Durchgeführte Änderungen

- P03 vollständig spezifiziert.
- SwiftPM-Target `NewEdenNexusPersistence` eingeführt.
- `NexusLegacySchema` 0.9.0, `NexusSchemaV1` 1.0.0 und `NexusMigrationPlan` angelegt.
- zentrale `NexusModelContainerFactory` für App-, In-Memory- und Dateistores implementiert.
- persistente Modelle aus dem App-Target nach Persistence verschoben.
- immutable, validierbare `ProductionProjectSnapshot`-Domainrepräsentation erstellt.
- asynchronen Application-Port `ProductionProjectRepository` definiert.
- `SwiftDataProductionProjectRepository` als `@ModelActor` mit explizitem Upsert- und Mappingpfad implementiert.
- App auf die versionierte Factory und ausgelagerten Persistenztypen umgestellt.
- Legacy-Fixture, Migration-, Repository-, Mapping-, Domain- und Architekturtests ergänzt.
- Datenmodell-, Architektur-, ADR-, Qualitäts- und Fortschrittsdokumentation aktualisiert.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionProject.swift`
- `Sources/NewEdenNexusApplication/ProductionProjectRepository.swift`
- `Sources/NewEdenNexusPersistence/NexusLegacySchema.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV1.swift`
- `Sources/NewEdenNexusPersistence/NexusMigrationPlan.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionProjectRepository.swift`
- `Tests/Fixtures/NewEdenNexusLegacySchema/LegacyModels.swift`
- `Tests/NewEdenNexusPersistenceTests/NexusPersistenceTests.swift`
- `Tests/NewEdenNexusDomainTests/ProductionProjectSnapshotTests.swift`
- `Documentation/DATA_MODEL.md`
- `Documentation/Architecture/ADRs/ADR-0003_SwiftData-Schema-v1-und-Persistenzgrenze.md`
- dieser Abschlussbericht.

## Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexus/AccountsView.swift`
- `Sources/NewEdenNexus/AppNavigation.swift`
- `Sources/NewEdenNexus/DashboardView.swift`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Sources/NewEdenNexus/ProjectsView.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- `Documentation/ARCHITECTURE.md`
- `Documentation/ARCHITECTURE_CHANGES.md`
- `Documentation/Architecture/ADRs/README.md`
- alle für P03 verpflichtenden Status-, Prompt-, Feature-, Tagebuch-, Problem- und Testübersichten.

## Gelöschte oder verschobene Dateien

`Sources/NewEdenNexus/Models.swift` wurde entfernt, nachdem seine beiden persistenten Modelle feldgleich in den Persistence-Target übertragen und durch Struktur- und Migrationstests abgesichert waren. Sonstige Benutzerdateien wurden weder gelöscht noch verworfen.

## Architekturentscheidungen

ADR-0003 entscheidet:

- exakte Legacybeschreibung als Version 0.9.0,
- additives Schema v1 als Version 1.0.0,
- Lightweight-Migration ohne Reset oder Leerstore-Fallback,
- eigener Persistence-Target,
- SwiftData-freies Domainmodell und Application-Port,
- kontrollierte Beibehaltung direkter SwiftData-Viewzugriffe bis zu den zuständigen Fachprompts.

## Legacy- und v1-Entitystruktur

### Legacy 0.9.0

`CharacterRecord`:

- `characterID: Int64` unique,
- `name`, `accountLabel`, `syncStateRaw: String`,
- `lastSync: Date?`,
- `industrySlots`, `scienceSlots`, `activeJobs: Int`,
- `createdAt: Date`.

`ProductionProject`:

- `id: UUID` unique,
- `name`, `productName`, `statusRaw`, `notes: String`,
- `targetQuantity`, `priority: Int`,
- `targetDate: Date?`,
- `createdAt`, `updatedAt: Date`.

### Schema v1 1.0.0

Alle Legacy-Felder, Typen, Optionalitäten und Unique-Regeln bleiben erhalten. Beide Entitäten erhalten ausschließlich das additive Feld:

`recordVersion: Int = 1`.

Der Strukturtest gleicht Entitynamen, gespeicherte Eigenschaften, Typen, Optionalität, Unique-Flags und Unique-Constraints des früheren Top-Level-Fixtures mit dem deklarierten Legacy-Schema ab.

## Datenmodelländerung und Datenwirkung

Die Migration ist `MigrationStage.lightweight` von 0.9.0 nach 1.0.0. Es gibt keine Umbenennung, Löschung, Zusammenführung oder fachliche Umdeutung eines Legacy-Felds. Vorhandene IDs und Werte bleiben unverändert; neue Datensatzversionen werden mit 1 initialisiert.

Die Produktionsfactory löscht keinen Store und öffnet keinen Ersatzstore. Ein Migrationsfehler wird an den App-Einstieg weitergereicht und führt im aktuellen Übergangsstand zum bereits bekannten `fatalError`.

## Repository-Grenze

Application kennt nur den `Sendable`-fähigen asynchronen Port. Der SwiftData-Adapter lebt in Persistence und:

- lädt nach stabiler UUID,
- führt Insert oder Update ohne Duplikat aus,
- sortiert nach Änderungszeitpunkt, Name und UUID,
- mappt Records explizit in einen validierten Snapshot,
- lehnt unbekannte persistierte Statuswerte typisiert ab,
- gibt Speicher- und Mappingfehler weiter.

## Teststore und Migrationsergebnis

Der Test erstellt ein UUID-basiertes temporäres Verzeichnis und darin einen Legacy-Store. Gespeichert werden ein Charakter und ein Projekt mit festen IDs, Texten, Mengen, Prioritäten, optionalen Zeitpunkten und Statuswerten.

Nach dem Öffnen über Schema v1:

- war je ein Datensatz vorhanden,
- stimmten sämtliche Legacy-Attribute exakt,
- war `recordVersion` bei beiden Datensätzen 1,
- blieb der vollständige Vergleich auch nach einer zweiten Öffnung desselben migrierten Stores erfolgreich.

Das temporäre Verzeichnis wird nach dem Test entfernt. Die Standardpfadprüfung vergleicht nur Konfigurations-URLs; keine produktive Benutzerdatenbank wurde geöffnet, kopiert oder verändert.

## Build-Ergebnis

Ausgeführt:

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Ergebnis:

- Targetgraph vollständig bestätigt,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen in den erfolgreichen Abschlussläufen.

## Testergebnis

**26 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler.**

- 4 Architekturtests,
- 12 Domain-/Berechnungstests,
- 8 Persistenz-, Migrations- und Repositorytests,
- 2 App-/Integrationsregressionstests.

Zwischenzeitliche Compilefehler betrafen die Reihenfolge beim Anlegen des neuen Testtargets, eine unzulässige Snapshot-Erfassung in einem SwiftData-Prädikat und mehrdeutige Fixture-/v1-Typnamen. Alle Ursachen wurden eng begrenzt korrigiert; der vollständige Abschlusslauf ist grün.

## Manuelle Prüfungen

- vollständigen P03-Quellcode und die betroffenen App-Integrationsstellen gelesen,
- Targetgraph und Abhängigkeitsrichtungen geprüft,
- bestätigt, dass Domain und Application SwiftData-frei sind,
- bestätigt, dass Persistence keine SwiftUI-, AppKit-, Network- oder Security-Imports enthält,
- bestätigt, dass die früheren Modelle nicht mehr im App-Target definiert sind,
- nach Store-Löschung, Reset, stillem Fallback und verschluckten Fehlern in neuem P03-Code gesucht,
- Dokumentationsstatus, Testzahlen und Promptverweise gegeneinander geprüft.

## Bekannte Probleme

- Direkte `@Query`-/`modelContext`-Zugriffe bleiben im bestehenden UI.
- Containerfehler verwenden bis P04 `fatalError`; UI-Speicherpfade enthalten bestehende `try?`.
- Backup/Restore fehlt bis P06.
- Ein Downgrade von v1 auf den unversionierten Stand wird nicht unterstützt.
- Git-Wurzel und `.gitignore` bleiben ungeklärt.

## Offene Anforderungen

- P04: zentrale Fehlerbehandlung und strukturiertes Logging,
- P06: Backup/Restore,
- P11: vollständiger Projektlebenszyklus und schrittweise View-Anbindung an Application-Use-Cases,
- P36: Recovery-Drill.

## Abweichungen vom Projektbuch

Keine neue fachliche Abweichung. P03 begrenzt das Schema bewusst auf die zwei bereits vorhandenen Entitäten. Die zahlreichen im Projektbuch vorgesehenen Datenobjekte werden erst in den dafür zuständigen MVP-Prompts versioniert ergänzt.

## Rollback- und Backupgrenzen

Die Änderung ist additiv, aber ein automatischer Downgrade ist nicht vorgesehen. P03 besitzt absichtlich weder Store-Reset noch Backupmechanismus. Bis P06 sind nur additive, vollständig getestete Migrationen zulässig; vor nicht leichtgewichtigen Änderungen muss eine geprüfte Sicherungs- und Wiederherstellungsstrategie bestehen.

## Nicht ausgeführte Prüfungen

- kein UI- oder manueller App-GUI-Test,
- kein echter SSO-/Netzwerkdurchlauf,
- kein Performance- oder Accessibility-Test,
- kein Backup-/Restore- oder Downgrade-Test,
- keine Migration einer produktiven Benutzerdatenbank.

Diese Prüfungen sind für den begrenzten P03-Scope nicht blockierend und werden nicht als bestanden dargestellt.

## Review

### Umfang

Geprüft wurden Prompt und Abnahmekriterien, vollständiger aktueller P03-Quellcode, Targetgraph, Persistenz- und Domainmapping, Tests, Buildausgaben, Datenwirkung, Architektur- und Fortschrittsdokumentation.

### Befunde

- **Kritisch:** keine.
- **Hoch:** keine.
- **Mittel:** keine offene P03-Mussanforderung.
- **Niedrig/Übergangsschuld:** direkte SwiftData-Viewzugriffe sowie fehlende zentrale Fehlerbehandlung und Backups; bereits dem geplanten P04, P06 und P11 zugeordnet.

### Entscheidung

**✅ bestanden.** Alle P03-Musskriterien sind durch Code, Debug-/Release-Build, 26 erfolgreiche Tests, vollständigen Migrationsnachweis, aktualisierte Dokumentation und diesen Bericht belegt. Die verbleibenden Grenzen sind ausdrücklich außerhalb des P03-Scopes und besitzen Folgeprompts.

## Erfüllte Abnahmekriterien

- P03 vollständig spezifiziert und implementiert,
- echter Persistence-Target,
- explizites Legacy-Schema, Schema v1 und Migrationsplan,
- vollständiger Werterhalt und zweite Öffnung nachgewiesen,
- leere In-Memory- und Dateistores geprüft,
- Domain-Invarianten und Mappingfehler typisiert getestet,
- Repository-Speichern, Lesen, Update und Sortierung getestet,
- Persistenzmodelle aus App-Target entfernt,
- Debug-/Release-Build und alle Tests erfolgreich,
- Datenmodell-, Architektur-, Status- und Qualitätsdokumentation aktualisiert,
- gesonderter Review bestanden.

## Nicht erfüllte Abnahmekriterien

Keine.

## Nächster empfohlener Prompt

P04 – Fehlerbehandlung und Logging zunächst vollständig spezifizieren und anschließend getrennt ausführen.
