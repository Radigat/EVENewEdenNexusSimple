# Abschlussbericht – P31 Einkaufsworkflow und Export

Prompt-ID: **P31**  
Datum: **2026-07-26**  
Status: **✅ erledigt**  
Review: **✅ bestanden**

## Ziel

Die P30-Zielkaufmengen sollten projektübergreifend nutzbar werden:
Teilkauf, vollständig gekauft, persistenter Status sowie kopierbarer Text-
und CSV-Export – ohne Lagerbestand oder andere Benutzerdaten
stillschweigend zu verändern.

## Ausgangszustand

P30 aggregierte positive Nettomengen projektbezogen und speicherte bewusste
Zielmengenabweichungen. Kauf-Fortschritt, globaler Workflow und CSV fehlten.
OFF-011 war teilweise offen; Schema v19 und 486 Tests je Debug-Buildweg
waren bestätigt.

## Durchgeführte Änderungen

- P31 vollständig mit Zweck, Regeln, Exportvertrag, Sicherheit, Tests und
  Abnahmekriterien spezifiziert,
- projektübergreifende, deterministische Type-ID-Aggregation ergänzt,
- Projektquellen, Ziel-, angerechnete Kauf- und Restmengen modelliert,
- Teilkäufe und vollständig gekauft je Projekt/Type-ID umgesetzt,
- nicht berechenbare Projekte als sichtbare Warnungen isoliert,
- Vorschau/Bestätigung und vollständige Quellversionsprüfung ergänzt,
- atomaren, scope-begrenzten SwiftData-Ersatz implementiert,
- Klartext und RFC-4180-kompatiblen UTF-8-CSV-Export ergänzt,
- Navigationsplatzhalter durch den zentralen Einkaufsbereich ersetzt,
- zentrale Fehlercodes für Laden, Speichern und Export ergänzt,
- additives Schema v20 und Backupformat 20.0.0 umgesetzt.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/PurchasingWorkflow.swift`
- `Sources/NewEdenNexusApplication/PurchasingWorkflowManagement.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV20.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataPurchaseProgressRepository.swift`
- `Sources/NewEdenNexus/PurchasingViewModel.swift`
- `Sources/NewEdenNexus/PurchasingView.swift`
- fünf P31-Testdateien,
- ADR-0037,
- dieser Abschlussbericht.

## Geänderte Dateien

App-Composition, Runtime, Root-Navigation, zentrale Fehlerbehandlung,
Migration, Container, Backupdienst und -tests, Xcode-Projekt sowie
sämtliche verpflichtenden Status-, Architektur-, Test- und
Fortschrittsdokumente.

## Gelöschte oder verschobene Dateien

Keine. Vorhandene Benutzeränderungen wurden nicht verworfen.

## Architekturentscheidungen

Kauf-Fortschritt ist eine Projektzuordnung und keine physische
Bestandsänderung. Der globale Workflow berechnet P26/P30 jeweils neu und
aggregiert danach. Archivierte, nicht berechenbare und veraltete
Fortschritte bleiben erhalten. CSV ist ausschließlich Export; es gibt
keinen versteckten Reimport-Schreibpfad. Siehe ADR-0037.

## Datenmodelländerungen

Schema v20 ergänzt `PurchaseProgressRecord` mit UUID, Projekt-ID, positiver
Type-ID, positiver Kaufmenge und Zeitstempeln. Null wird nicht gespeichert.
Das Repository erzwingt fachliche Eindeutigkeit Projekt/Type-ID,
Referenzbestand und optimistische Versionen. Migration v19→v20 ist additiv
und erfindet keinen Fortschritt.

## Build-Ergebnis

- SwiftPM Debug: erfolgreich,
- Xcode Debug, Scheme `NewEdenNexus`, Ziel macOS arm64: erfolgreich,
- Projektparität: 15 Targets, sieben Testtargets, zwei Schemes.

## Testergebnis

- 15 fokussierte P31-Tests bestanden,
- SwiftPM Debug: 501/501 bestanden, 0 übersprungen,
- Xcode Debug: 501/501 bestanden, 0 übersprungen,
- v19→v20-Migration und Wiederöffnung bestanden,
- isolierter App-Start: Prozess lauffähig,
  `ZPURCHASEPROGRESSRECORD` vorhanden,
  `PRAGMA integrity_check = ok`.

Der erste vollständige SwiftPM-Lauf fand als einzigen Fehler eine
unvollständige bestehende Fehleroperationsmatrix. Nach Ergänzung der drei
P31-Operationen bestanden alle Tests.

## Manuelle Prüfungen

Die gebaute App wurde mit einem isolierten Store gestartet und die
Datenbank geprüft. Die View wurde automatisiert bei 700×720 und 1200×900
gerendert. Ein interaktiver GUI-/VoiceOver-Test wurde nicht durchgeführt
und nicht behauptet.

## Bekannte Probleme

Keine kritische P31-Regression ist offen. Xcode protokollierte externe
DTDeviceKit-Warnungen zu einem gesperrten verbundenen Mobilgerät; das
explizite macOS-Testziel und das Ergebnis waren nicht betroffen.

## Offene Anforderungen

P33–P36 und die persönliche Release-/Complianceprüfung bleiben vor einer
öffentlichen Freigabe offen. Ein künftiger CSV-Reimport benötigt einen
eigenen Preview-before-write-Vertrag.

## Abweichungen vom Projektbuch

Keine Live-Markt-, Wallet-, ESI- oder Logik zur automatischen Einlagerung
wurde vorgezogen. „Gekauft“ dokumentiert eine Projektzuordnung, nicht den
physischen Wareneingang.

## Abnahmekriterien

Alle P31-Kriterien sind nachgewiesen. OFF-011 ist vollständig geschlossen.
P33–P36 wurden nicht begonnen.

## Reviewentscheidung

**✅ bestanden.** Diff, Schichtengrenzen, Ganzzahlarithmetik,
Vorschau-vor-Schreiben, Datenbestandsschutz, Migration, Export, UI,
Buildausgaben, vollständige Tests und Dokumentation wurden unabhängig
gegen den tatsächlichen Stand geprüft.

## Nächster empfohlener Prompt

**P33 – Appweite Validierung und Fehler-UX vollständig spezifizieren und
ausführen**, sobald dieses temporär verschobene Qualitätspaket ausdrücklich
reaktiviert wird.
