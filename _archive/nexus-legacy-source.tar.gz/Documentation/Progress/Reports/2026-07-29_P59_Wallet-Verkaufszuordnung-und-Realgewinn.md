# P59 – Wallet-Verkaufszuordnung und Realgewinn

Datum: 2026-07-29  
Status: ⚠️ technisch umgesetzt, Eigentümergate OFF-061 offen  
Review: ⚠️ technisch bestanden, Betriebsabnahme ausstehend

## Ziel und Ausgangszustand

P59 sollte reale Verkäufe und Gebühren chargengebunden abbilden, ohne die
zurückgezogene P42-Oberfläche wieder einzublenden oder Walletquellen doppelt
zu verbrauchen. P57-Chargen, P58-Kostensnapshots und bestätigte
P42-Projektzuordnungen waren vorhanden.

## Umsetzung

- `ProductionBatchRealizedCalculator` berechnet verkaufte/offene Units,
  Erlös, Gebühren, realisierten Kostenanteil, Durchschnittspreis, Marge, ROI
  und Realgewinn deterministisch in ISK-Hundertsteln.
- `ProductionBatchSaleManagementService` erzeugt schreibfreie Vorschauen und
  prüft bei Bestätigung Charge, Kostenbindung, Projektkapazität und
  Walletrevision erneut.
- Wallet-Transaktionen und Journalgebühren unterteilen ausschließlich bereits
  bestätigte Projektkapazität. Begründete manuelle Istbelege bleiben getrennt.
- Marktquotes und offene Orders werden nicht als realisierter Erlös behandelt.
- Schema v28 speichert die chargengebundene Zuordnung. Stale Zustand,
  Doppelverwendung, Überbuchung und Überverkauf werden abgewiesen.
- Das Produktionsbuch zeigt gespeicherte Zuordnungen, Restmengen und
  Realgewinn ohne technische Quell-IDs.

## Datenmodell und Architektur

Additive Migration v27→v28; keine Benutzerdaten wurden gelöscht oder
umgeschrieben. Bestätigte Historie bleibt bei fehlendem Walletcache oder
Accounttrennung lesbar. Details: [ADR-0062](../../Architecture/ADRs/ADR-0062_Chargengebundene-Verkaufszuordnung-und-Realgewinn.md)
und [Datenmodell](../../DATA_MODEL.md).

## Build und Tests

- 15/15 fokussierte P59-/Migration-/Recovery-Tests bestanden.
- 713/713 vollständige SwiftPM-Tests außerhalb der Security-Sandbox bestanden.
- Unsigned Xcode Debug nach finaler v28-Korrektur: `BUILD SUCCEEDED`.
- Der normale signierte Xcode-Build scheitert an einer veralteten lokalen
  Zertifikatsauswahl in `XcodeSupport/LocalSigning.xcconfig` (KI-060).
  Signing-/Teamdaten wurden nicht verändert.
- Projektgenerator und Verifier: 16 Targets, 8 Testtargets, 2 gemeinsame
  Schemes.

Der Volltest deckte zunächst eine v27-Restannahme im Store-Inspector auf.
Nach der Korrektur erkennen Backup und Recovery Schema v28; die betroffenen
15 Tests sowie die gesamte Suite sind grün.

## Abnahmekriterien

- ✅ Domain-, Application-, Persistence- und UI-Verträge umgesetzt.
- ✅ Vorschau vor Schreiben, Stale-/Quell-/Doppel-/Überverkaufsschutz.
- ✅ Migration, Wiederöffnung, Backup- und Recoverygrenze automatisiert.
- ✅ fokussierte und vollständige Tests.
- ✅ unsigned Xcode-Debugbuild.
- ⚠️ normaler lokaler signierter Build wegen KI-060.
- ⚠️ reale Teil- und Vollzuordnung sowie Neustartnachweis fehlen.

## Offene Punkte und nächste Handlung

OFF-037 und OFF-053 werden nicht mehr über den zurückgezogenen P42-Dialog,
sondern über OFF-061 im neuen P59-Chargenablauf abgenommen. OFF-056 bleibt bis
zur P60-Analyse teilweise.

Nächste Handlung: lokale Signing-Auswahl getrennt reparieren und danach
OFF-061 mit Teilzuordnung, Verwerfen, Gebühr, Vollzuordnung und Neustart
durchführen. P60 beginnt erst anschließend und nur auf ausdrücklichen Auftrag.

Es erfolgte kein Commit und kein Push.
