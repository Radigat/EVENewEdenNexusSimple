# KI-064 – Vereinfachte Chargenerfassung

Stand: 2026-07-30

## Ziel und Ausgangszustand

Die neue OFF-061-Charge wurde ohne technische Sonnensystem-ID blockiert.
Gleichzeitig standen optionale Ort-, ESI-, Charakter- und ID-Felder im
Hauptablauf, obwohl das Chargenmodell diese Werte nicht zwingend benötigt.

## Änderungen

- Projekt, Datum, Status, Runs, ME, TE und Ausgabemenge bilden den sichtbaren
  Hauptablauf.
- Produktionsort ist optional; ein Name kann ohne technische ID gespeichert
  werden.
- ESI-Job und technische Zuordnungen sind eingeklappt.
- Fehlende optionale Werte erscheinen informativ und blockieren die
  bestätigte Speicherung nicht.
- Nicht angegebene Orte heißen `Nicht angegeben`; nur eine vorhandene ID ohne
  Namen erscheint als `Name nicht aufgelöst`.
- Vorschau, explizite Bestätigung, Stale-Schutz und unveränderliche
  Projekt-/Graph-/SDE-Provenienz bleiben erhalten.

Keine Dateien wurden gelöscht oder verschoben. Datenmodell, Schema,
Migrationen und vorhandene Benutzerdaten wurden nicht geändert.

## Prüfung

- 5/5 `ProductionBatchManagementTests`: bestanden.
- 1/1 Produktionsbuch-UI-Vertrag: bestanden.
- Vollsuite: 706/716 bestanden. Die zehn Fehler sind nicht durch KI-064
  verursacht: sieben veraltete Erwartungen an die zurückgezogene
  P51-Projektfinanzoberfläche und drei lokale SSO-`SecKey`-Fixturefehler.
- Apple-Development-signierter arm64-Xcode-Debugbuild:
  `BUILD SUCCEEDED`.

## Review

**✅ bestanden.** Der ursprüngliche Pflichtfeldwiderspruch ist beseitigt,
ohne Werte zu erfinden oder den Bestätigungsschutz abzuschwächen.

## Eigentümer-Sichttest

Der Projekteigentümer bestätigt im aktuellen App-Lauf, dass die
Chargenerfassung funktioniert und durch die Verschlankung deutlich besser
nutzbar ist. KI-064 ist damit vollständig geschlossen.

## Offen und nächster Schritt

OFF-061 wird mit Kostenbasis, Teilzuordnung, Vorschau-Verwerfen, Gebühr,
Vollzuordnung und Neustart fortgesetzt. P60 beginnt nicht automatisch.
