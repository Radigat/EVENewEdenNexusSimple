# P56 – Deutsche Zahlenformatierung

## Ziel und Ergebnis

Alle sichtbaren Mengen, Zählwerte und ISK-Beträge wurden auf eine zentrale
deutsche UI-Darstellung umgestellt: `1.234.567` beziehungsweise
`1.234.567,89 ISK`.

Betroffen sind insbesondere Dashboard, Projekte, Produktionsgraph und
-workspace, Lager, Sicherheitsbestände, Reservierungen, Einkauf, Preise,
Wallet, persönliche ESI-Daten sowie CSV-/Marktvorschauen. Technische IDs,
Eingaben, gespeicherte Werte, Berechnungen und maschinenlesbare Exporte
wurden nicht verändert.

## Technik und Datenwirkung

- `NexusNumberFormat` bündelt Mengen- und ISK-Darstellung im UI-Target.
- Domänen- und Persistenzmodelle blieben unverändert.
- Keine Migration und kein produktiver Schreibvorgang.
- ADR-0059 dokumentiert die Darstellungsgrenze.

## Prüfung

- fokussiert: 2/2 neue Zahlenformat-Referenztests bestanden,
- vollständig: 681/681 SwiftPM-Tests bestanden,
- Xcode: Scheme `NewEdenNexus`, Debug, macOS arm64,
  Apple-Development-signiert, `BUILD SUCCEEDED`,
- nicht blockierende Xcode-Warnung: mehrere passende macOS-Ziele; arm64
  wurde als erstes Ziel verwendet.

Der erste SwiftPM-Versuch innerhalb der Dateisandbox scheiterte vor der
Testausführung am gesperrten Modulcache beziehungsweise `sandbox_apply`.
Der unveränderte Lauf wurde mit temporären Modulcaches außerhalb dieser
Grenze erfolgreich wiederholt.

## Review und offene Punkte

Technische Kontrollprüfung: **bestanden**. Der Diff beschränkt die Änderung
auf Präsentationsformatierung und Tests; keine Werte oder Datenverträge
wurden verändert.

`OFF-054` bleibt offen und prüft zusätzlich sichtbar mindestens eine
vierstellige Menge sowie einen ISK-Millionenbetrag. P54 beginnt weiterhin
nur nach gesonderter Commit-Freigabe.
