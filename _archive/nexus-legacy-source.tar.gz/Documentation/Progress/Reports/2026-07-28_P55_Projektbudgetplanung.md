# P55 – Projektbudgetplanung

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden, Eigentümer-Sichttest offen  
Review: ✅ technische Kontrollprüfung bestanden

## Ziel und Ausgangszustand

Die sichtbare P42-Projektfinanzansicht sollte entfernt und die
Projektplanung auf ein benötigtes Budget aus Materialeinkauf, Logistik und
Produktion umgestellt werden.

## Änderungen

- `Projektfinanzen` aus der Accountoberfläche entfernt; vorhandene Wallet-
  Snapshots, Zuordnungen und Dienste nicht gelöscht,
- Produktionsworkspace-Bereich `Kosten & ROI` durch `Budget` ersetzt,
- Materialbudget an die wirksame Einkaufsliste und damit an die einzelnen
  Build-or-Buy-Entscheidungen gebunden,
- Logistik- und Produktionskosten getrennt ergänzt,
- deterministischen, überlaufgeprüften Budgetrechner und schreibfreien
  Preview-/Bestätigungsdienst ergänzt,
- persistente Projektbudgetbasis sowie additive Migration v24→v25 ergänzt,
- Backup-/Schemaerkennung auf v25 aktualisiert.

Neu: `ProjectBudget.swift`, `ProjectBudgetPlanning.swift`,
`NexusSchemaV25.swift`, `SwiftDataProjectBudgetRepository.swift`,
`PROJECT_BUDGET.md`, ADR-0056 und P55-Prompt. Kein Commit oder Push.

## Build und Tests

- Projektbudget Domain/Application/Persistenz: 5/5 bestanden,
- Budget-/Workspace-Architektur: 2/2 bestanden,
- SwiftPM Debug vollständig: 678/678 bestanden,
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64, isoliertes Derived Data:
  Apple-Development-signiert, `BUILD SUCCEEDED`,
- v24→v25-Migration erhält bestehendes Projekt und erfindet keine
  Budgetkonfiguration.

## Review und offene Abnahme

Diff, Schichtentrennung, Vorschau-vor-Schreiben, fehlende Preise,
Überlaufschutz, Migration, Backupversion und vollständige Regression wurden
geprüft. Technisch bestanden.

`OFF-054` bleibt für einen kurzen Eigentümer-Sichttest offen:

1. Projekt öffnen und Bereich `Budget` wählen,
2. eine Zwischenstufe zwischen `Bauen` und `Kaufen` umschalten,
3. Einkaufsliste und Budget neu berechnen,
4. getrennte Material-, Logistik-, Produktions- und Gesamtsumme prüfen,
5. Budgetbasis speichern und nach Neustart wieder öffnen.

P42-1/P42-2 werden nicht fortgesetzt, solange die alte sichtbare
Projektfinanzoberfläche bewusst zurückgezogen ist. Nächster Schritt:
`OFF-054`-Eigentümertest; P54 bleibt ein getrennt freizugebender lokaler
Commit.
