# P39 – ESI-Infrastruktur und Charaktere

- Datum: 2026-07-26
- Status: ✅ erledigt
- Review: ✅ bestanden

## Ziel und Ausgangszustand

Auf der in P38 gehärteten lokalen SSO-/Accountbasis sollte eine
ressourcenschonende, offlinefähige Infrastruktur für öffentliche
Charakterprofile entstehen. Vor P39 fehlten ESI-Client, Cachevertrag,
Synchronisationsservice und Status-UI.

## Durchgeführte Änderungen

- transportneutrale Application-Modelle und Ports für Abruf, Cache und
  Synchronisation,
- offizieller unversionierter Charakterendpunkt mit `User-Agent`,
  `Accept` und `X-Compatibility-Date`,
- kein Bearer-Token und keine privaten Scopes für die öffentliche Route,
- ETag/Last-Modified, 304, Cachefrische, Retry-After, 420/429,
  Error-Limit und höchstens ein 5xx-Retry,
- typisierte Offline-, Timeout-, Schema-, Limit- und Protokollfehler,
- begrenzter, versionierter und atomarer Application-Support-Dateicache
  mit restriktiven Rechten und Symlinkschutz,
- Accountansicht mit öffentlichem Profil, Aktualität, Fortschritt,
  Offlineanzeige, Retry und manueller Aktualisierung,
- kompensierbares Entfernen von Account, Refresh-Token und Profilcache,
- zentrale Diagnose `NEN-ESI-001`,
- Xcode-Projekt, Tests und Dokumentationssteuerung aktualisiert.

## Dateien

Neu erstellt wurden insbesondere:

- `Sources/NewEdenNexusApplication/ESICharacterSynchronization.swift`,
- `Sources/NewEdenNexusInfrastructure/ESICharacterClient.swift`,
- `Sources/NewEdenNexusInfrastructure/FileESICharacterProfileCache.swift`,
- die drei zugehörigen fokussierten Testsuiten,
- `Documentation/ESI_ARCHITECTURE.md`,
- `Documentation/Architecture/ADRs/ADR-0044_Oeffentliche-ESI-Charakterbasis-und-Dateicache.md`.

Geändert wurden die Account-/SSO-Applicationgrenze, App-Composition,
Account-ViewModel und -View, Fehlerbehandlung, User-Agent-Konfiguration,
Supportansicht, Xcode-Projekt sowie die betroffenen Steuer-, Test- und
Statusdokumente. Dateien wurden weder gelöscht noch verschoben.

## Architektur und Daten

ESI-Rohantwort, normalisiertes öffentliches Profil, lokales Charakterkonto,
Token und SDE bleiben getrennte Lebenszyklen. P39 ändert weder
SwiftData-Schema noch Benutzerdatenmigration. Der Cache kann verworfen und
aus ESI neu aufgebaut werden.

Die offiziellen CCP-Quellen wurden am 2026-07-26 geprüft: ESI Overview,
Best Practices, Rate Limiting, SSO und die Guidance zu unversionierten
Routen und Kompatibilitätsdatum. Es wird keine rechtliche Freigabe oder
CCP-Genehmigung behauptet.

## Build und Tests

```bash
CLANG_MODULE_CACHE_PATH=.build-p39-tests/clang-cache \
SWIFTPM_MODULECACHE_OVERRIDE=.build-p39-tests/swift-cache \
swift test --disable-sandbox --scratch-path .build-p39-tests --jobs 2
```

Ergebnis: **565/565 Tests bestanden**, 0 Fehler.

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build-p39-xcode \
  CODE_SIGNING_ALLOWED=NO build
```

Ergebnis: **BUILD SUCCEEDED**. Signing- und Team-Einstellungen blieben
unverändert.

Ein realer offizieller ESI-Abruf ergab HTTP 200; der konditionale Abruf mit
dem gelieferten ETag ergab HTTP 304. Es wurde kein Token gesendet. Erste
eingeschränkte Läufe trafen bekannte Security-/Makro-Sandboxgrenzen; die
identischen Prüfungen bestanden außerhalb der Restriktion.

Nach der letzten reinen UI-Textpräzisierung bestanden 4/4
`AppSourceArchitectureTests` und der Xcode-Debugbuild auf dem finalen
Quellstand erneut.

## Manuelle Prüfungen

- offizieller Requestpfad und Header kontrolliert,
- realer 200-/304-Zyklus ausgeführt,
- Projektdatei mit `plutil -lint` geprüft,
- Kontaktangabe und Tokenwerte nicht in Quellen oder Dokumentation
  übernommen.

## Offene Anforderungen und bekannte Probleme

Keine kritische P39-Regression ist offen. `OFF-010` / `KI-010` bleibt nur
für den privaten P40-Anteil teilweise offen. Assets, Blueprints, Industry
Jobs und private Scopes wurden nicht begonnen. Der bereits stark geänderte
Arbeitsbaum und vorhandene Benutzeränderungen wurden erhalten. Es erfolgte
kein Commit oder Push.

## Abnahmekriterien

Alle P39-Kriterien sind erfüllt: offizieller tokenfreier Request,
Cache-/Validatorverhalten, Rate-Limit, Offline, Abbruch, Daten- und
Dateigrenzen, Trennkompensation, Build, vollständige Tests, Realprobe,
Dokumentation und gesonderter Review.

## Reviewentscheidung

Der tatsächliche Quellstand, Schichtengrenzen, HTTP-/Cacheverträge,
Fehlerpfade, Testausgaben, Xcode-Projekt und Dokumentationsdelta wurden
kontrolliert. Entscheidung: **✅ bestanden**.

## Nächster empfohlener Prompt

P40 – Live-Assets, Blueprints und Industry Jobs nur nach Nutzenreview und
auf ausdrücklichen Auftrag. P40 wurde nicht begonnen.
