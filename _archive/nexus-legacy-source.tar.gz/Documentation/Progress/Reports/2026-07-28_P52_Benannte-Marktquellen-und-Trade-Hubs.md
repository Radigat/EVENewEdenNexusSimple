# P52/P41-1 – Benannte Marktquellen und Trade Hubs

Datum: 2026-07-28  
Status: **⚠️ technisch bestanden, Eigentümer-Sichttest offen**  
Review: **⚠️ mit Einschränkung bestanden**

## Ziel und Ausgangszustand

Die öffentliche Materialpreisvorschau sollte ohne Kenntnis technischer
Region- und Location-IDs bedienbar werden. Gewünscht waren alle benannten
Regionen, fünf Trade-Hub-Schnellwahlen und namentlich sichtbare bekannte
Stationen beziehungsweise Spielerstrukturen einschließlich Home-Hubs.

## Änderungen

- öffentliches ESI-Universe-Verzeichnis für Regionen,
  Stations-/System-/Regionshierarchie und öffentliche Marktstrukturen,
- benannte Application-Modelle und Zusammenführung mit persönlichen
  Snapshots sowie dem vorhandenen Ortsnamenscache,
- Schnellwahlen für Jita, Amarr, Dodixie, Rens und Hek,
- Regions- und Marktstandort-Dropdowns statt sichtbarer ID-Eingaben,
- öffentliche bekannte Strukturen auswählbar; private bekannte Strukturen
  benannt und fail-closed gesperrt,
- Struktur-Namenscache um die rückwärtskompatible optionale
  Sonnensystem-ID ergänzt,
- Architektur-, Fach-, Client- und ViewModel-Regressionstests,
- ADR-0054 sowie Markt-, ESI-, Status- und Testdokumentation aktualisiert.

Es wurden keine Dateien gelöscht oder verschoben. Schema, Migrationen und
Benutzerdaten blieben unverändert.

## Architekturentscheidung

Der bestehende P41-Preisvertrag bleibt ein öffentlicher regionaler
Sell-Order-Abruf. Private Strukturorders werden nicht vorgetäuscht: Sie
benötigen später einen eigenen authentifizierten Vertrag mit Scope,
Kontoauswahl, Cache und Vorschau. Details:
[ADR-0054](../../Architecture/ADRs/ADR-0054_Benannte-Marktquellen-und-oeffentliche-Strukturen.md).

## Build und Tests

```text
swift test --scratch-path .build-p52 --filter
  'ESIMarketOrderClientTests|MarketPriceImportServiceTests|
   BuildOrBuyWorkspaceViewModelTests|ESILocationName' --jobs 1
```

Ergebnis: **26/26 bestanden**.

```text
swift test --scratch-path .build-p52 --jobs 1
```

Ergebnis: **667/667 bestanden**, 0 Fehler.

```text
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination 'platform=macOS,arch=arm64'
  -derivedDataPath /private/tmp/NewEdenNexus-P52-MarketLocations-Xcode
  COMPILER_INDEX_STORE_ENABLE=NO build
```

Ergebnis: Apple-Development-signiert, **BUILD SUCCEEDED**.
`git diff --check` bestand.

## Review und offene Punkte

Code, Tests, Datenwirkung und Dokumentation wurden gegen den tatsächlichen
Diff kontrolliert. Die technische Abnahme ist bestanden. P52 bleibt
insgesamt teilweise, weil der Eigentümer-Sichttest OFF-050 und weitere
P41-/P42-Gates offen sind.

- OFF-050: benannte Regionsliste, einen Trade Hub und einen bekannten
  Home-Hub im echten Build prüfen; Vorschau schließen, nicht übernehmen.
- Private Strukturmarktorders: späterer eigener Nutzenreview, nur auf
  ausdrücklichen Auftrag.
- OFF-049: optionale PLEX-Anzeige bleibt getrennt verschoben.

Offizielle Quellen, geprüft am 2026-07-28: CCP
[API Explorer](https://developers.eveonline.com/api-explorer),
[Map Data](https://developers.eveonline.com/docs/guides/map-data/) und
[ESI Rate Limiting](https://developers.eveonline.com/docs/services/esi/rate-limiting/).

Nächster Schritt: P41-1 im Bereich **Kosten & ROI** mit der benannten
Marktquellenauswahl schreibfrei testen.
