# P52 – Spielerstrukturen und Typnamen

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden; Eigentümer-Livetest offen  
Review: ⚠️ mit Einschränkung bestanden

## Ziel und Ausgangszustand

Die Auswahlrücknahme und Anzeige der aktiven Projektauswahl waren live
bestanden. Spielerstrukturen blieben generisch benannt. Daneben erschienen
vorhandene Gegenstände vereinzelt als unbekannt, weil nur Type-IDs der ersten
2.000 Rohdatensätze für die Namensauflösung gesammelt wurden.

## Änderungen

- optionalen, separat erklärten SSO-Scope
  `esi-universe.read_structures.v1` ergänzt,
- vorhandene Produktions- und Walletscopes bei der Erweiterung erhalten,
- referenzierte private Strukturen über den offiziellen ESI-Endpunkt mit
  Bearer-Token, HTTP-Validatoren, 304-Behandlung und Offlinecache aufgelöst,
- ohne Scope oder Zugriff eine fachliche generische Bezeichnung statt einer
  technischen ID verwendet,
- alle referenzierten Snapshot-Type-IDs gebündelt aus dem aktiven lokalen
  SDE geladen; 2.000-Rohzeilen-Grenze entfernt,
- Ladezustand, noch nicht geladener Name und tatsächlich im aktiven SDE
  fehlender Typ in der UI getrennt,
- ADR-0051 und betroffene Steuer-/Testdokumente aktualisiert.

## Datenwirkung und Sicherheit

Die Implementierung hat keine produktiven Konten, Tokens, Scopes, Snapshots,
Projektauswahlen oder Bestände verändert. Die reale SSO-Erweiterung startet
erst nach ausdrücklicher Bestätigung im sichtbaren App-Dialog. Ein Abbruch
bewahrt den vorhandenen Stand. Struktur- und Typnamen sind abgeleitete
Anzeigedaten; unbekannte Werte werden nicht erfunden.

## Build und Tests

- fokussiert: **42/42 bestanden**,
- vollständig: **662/662 SwiftPM-Tests bestanden**,
- Xcode Debug, Scheme `NewEdenNexus`, Ziel macOS,
  Apple-Development-signiert: **BUILD SUCCEEDED**,
- erster SwiftPM-Lauf war ausschließlich wegen des nicht beschreibbaren
  Sandbox-Modulcaches nicht ausführbar; Wiederholung mit isoliertem
  `/private/tmp`-Cache bestand.

Offizielle technische Grundlagen:

- [ESI Overview](https://developers.eveonline.com/docs/services/esi/overview/)
- [EVE SSO](https://developers.eveonline.com/docs/services/sso/)
- [offizielle ESI-OpenAPI-Spezifikation](https://esi.evetech.net/meta/openapi.json)

## Review und offene Abnahme

Diff, Schichtengrenzen, Scope-Bestandsschutz, Cacheverhalten,
Katalogauflösung, Tests, Build und Dokumentationsdelta wurden getrennt
geprüft. Technisch besteht keine kritische Regression.

Die Reviewentscheidung bleibt `⚠️ mit Einschränkung bestanden`, bis der
Eigentümer:

1. im neuen Build `Strukturnamen freigeben` bewusst bestätigt,
2. einen zugänglichen Spielerstrukturnamen ohne sichtbare Roh-ID prüft,
3. vollständige Typnamen beziehungsweise einen klar bezeichneten echten
   SDE-Fehlbestand prüft.

P40-4 sowie P41/P42-Restgates beginnen nicht automatisch.
