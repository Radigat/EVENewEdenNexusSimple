# P42 – Nutzenreview Wallet und reale Projektfinanzen

Status: **✅ Nutzenreview abgeschlossen; P42 nicht begonnen**  
Datum: 2026-07-27

## Ergebnis

Das Review erteilt ein **bedingtes Go** für einen begrenzten lokalen
P42-Umfang. Tatsächliche Käufe, Verkäufe und eindeutig belegte Gebühren
ergänzen P29/P40/P41 sinnvoll. Eine automatische Projektzuordnung wäre wegen
fungibler Materialien, Mehrprojektverbrauch und uneinheitlicher
Journal-Kontexte nicht belastbar und bleibt ausgeschlossen.

## Empfohlener Umfang

- persönlicher Read-Scope `esi-wallet.read_character_wallet.v1`,
- Kontostand, Journal und Transaktionen als getrennte lokale Snapshots,
- Wiederverwendung der P39/P40-Cache-, Rate-Limit-, Refresh- und
  Abbruchgrenzen,
- Vorschau und ausdrückliche Bestätigung vor jeder Projektzuordnung,
- vollständige, teilweise oder abgelehnte Zuordnung durch den Benutzer,
- getrennte Darstellung erwarteter und tatsächlicher Kosten/Erlöse,
- keine Corporation-Wallets, automatische Buchhaltung oder erfundene
  Gebühren.

Die offizielle OpenAPI-Spezifikation weist drei passende
Charakterendpunkte, den einen Read-Scope sowie die Rate-Limit-Gruppe
`char-wallet` mit 150 Tokens je 15 Minuten aus. Das Journal ist laut
Endpunktbeschreibung auf 30 Tage rückwirkend begrenzt; Transaktionen
verwenden `from_id`.

## Risiken und Voraussetzungen

Vor einer Ausführung sind Snapshotformat, additives Zuordnungsschema,
deterministische ISK-Normalisierung, Deduplizierung, Teilmengenregeln,
Charaktertrennung und Datenlöschung vollständig umzusetzen und zu testen.
Die erneute SSO-Zustimmung ist eine bewusste Benutzerhandlung. Walletdaten
dürfen weder in Logs noch Diagnoseberichte gelangen.

`OFF-021` wurde geprüft: Der erste Umfang benötigt keinen zusätzlichen
SDE-Import. Autoritative Orts- oder Parteinamen bleiben bedarfsgesteuert.

## Prüfung

Quellcode und vorhandene Projektwirtschaftlichkeit, P40-Snapshots,
SSO-Scopegrenzen sowie aktuelle offizielle ESI-Dokumentation wurden geprüft.
Kein App-Code, Datenmodell oder Benutzerbestand wurde verändert. Build und
Laufzeittests wurden für dieses reine Review nicht ausgeführt. Kein Commit
oder Push.

Reviewentscheidung: **✅ Nutzenreview bestanden**. P42 bleibt
`⏸️ nicht begonnen` und darf nur auf ausdrücklichen Ausführungsauftrag
starten.
