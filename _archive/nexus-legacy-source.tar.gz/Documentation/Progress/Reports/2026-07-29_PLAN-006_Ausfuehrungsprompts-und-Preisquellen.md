# PLAN-006 – Ausführungsprompts und Preisquellen

Datum: 2026-07-29  
Status: **✅ Spezifikationsnachkorrektur bestanden**

## Ziel und Ausgangszustand

P57 bis P61 waren fachlich geordnet, aber noch zu knapp für eine
eigenständige Ausführung. Der Eigentümer verlangt bevorzugt Live-ESI-Preise
aus Jita oder einer änderbaren benannten Marktquelle.

## Änderungen

- P57–P61 auf 96 bis 117 Zeilen ausführbar erweitert,
- Zweck, Voraussetzungen, Ergebnis, Datenwirkung, Nicht-Ziele, offene Punkte,
  Tests, Eigentümernachweis und messbare Abnahme ergänzt,
- verbindliche Preispriorität festgelegt:
  Live-ESI, Cache derselben Quelle, sichtbarer stale Cache, ausdrücklich
  gewählter manueller/CSV-Fallback, sonst `nicht verfügbar`,
- Jita als änderbare Standardquelle; Regionen, Trade Hubs und bekannte
  öffentliche Stationen/Strukturen bleiben benannt auswählbar,
- Prognosequote, realer Walletbeleg sowie Buy-/Sell-Rolle strikt getrennt,
- vorhandene P41-/ADR-0054-Verträge wiederverwendet.

## Daten- und Architekturwirkung

Keine Swift-, Schema- oder produktive Datenänderung. Der Marktbereich liefert
belegte Quotes; Industrie entscheidet über deren Verwendung. P57 lädt keine
Preise, P58 bindet Prognosen, P59 bindet reale Belege, P60 liest Snapshots und
P61 verwendet dieselbe Marktquellenpolitik.

## Prüfung

- Promptlängen: 96/111/99/102/117 Zeilen,
- `verify_project_governance.py`: bestanden,
- `verify_xcode_project.py`: bestanden,
- `git diff --check`: bestanden.

Ein Swift-/Xcode-Lauf war für die reine Dokumentationsänderung nicht
erforderlich. Private Arbeitsmappendaten wurden nicht übernommen.

## Review

**✅ bestanden.** Keine Doppelimplementierung geplant; Herkunft, Freshness,
Fallback und Benutzerbestätigung sind in allen betroffenen Paketen sichtbar.

## Offene Punkte und Folge

OFF-054 bleibt das nächste Gate. Danach beginnt P57 nur auf ausdrücklichen
Auftrag; anschließend P58, P59, P60 und P61. P54 bleibt separat
commit-freigabepflichtig.
