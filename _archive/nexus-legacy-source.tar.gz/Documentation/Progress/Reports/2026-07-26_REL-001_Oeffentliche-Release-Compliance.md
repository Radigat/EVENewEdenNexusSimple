# REL-001 – Öffentliche Release-/Complianceprüfung

Datum: 2026-07-26  
Prüfstatus: ✅ vollständig ausgeführt  
Öffentliche Freigabe: ⚠️ nicht bereit  
Review: ⚠️ mit Einschränkungen bestanden

## Ziel und Ausgangszustand

Nach P36/P37 sollten die aktuelle öffentliche Release- und
Compliancebereitschaft sowie OFF-031 geprüft werden. Der Produktionsplaner
war funktional und recoveryseitig abgenommen; der native UI-Testworker und
die zeitabhängige Releaseprüfung waren offen. P38 war und blieb ausdrücklich
außerhalb des Auftrags.

## Durchgeführte Arbeiten

- aktuelle offizielle CCP-/EVE-Quellen und Apple-Verteilungsanforderungen
  read-only geprüft,
- offiziellen SDE-Metadaten- und Schema-Endpunkt am 2026-07-26 erneut
  abgerufen,
- Rechtsansicht, Drittanbieterkennzeichnung, Markenhinweis und Repository auf
  CCP-Logos/-Bilder geprüft,
- Xcode-Projektparität, SwiftPM Release, Xcode Release und vollständige
  SwiftPM-Release-Suite geprüft,
- OFF-031 außerhalb der Sandbox mit dem nativen Xcode-UI-Testworker
  ausgeführt,
- Release-App auf Bundle-ID, Versionsfelder, Signatur und Gatekeeperstatus
  geprüft,
- offene Eigentümer- und Apple-Distributionsschritte getrennt dokumentiert.

## Offizielle Quellen

- https://developers.eveonline.com/license-agreement
- https://developers.eveonline.com/docs/services/static-data/
- https://developers.eveonline.com/docs/services/esi/best-practices/
- https://developers.eveonline.com/docs/services/esi/rate-limiting/
- https://support.eveonline.com/hc/en-us/articles/8564030965660-Third-Party-Policies
- https://support.eveonline.com/hc/en-us/articles/8413329735580-EVE-Online-End-User-License-Agreement
- https://support.eveonline.com/hc/en-us/articles/8414770561948-EVE-Online-Terms-of-Service
- https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution
- https://developer.apple.com/help/account/certificates/create-developer-id-certificates/
- https://developer.apple.com/documentation/xcode/preparing-your-app-for-distribution

## CCP-/SDE-Befund

- `latest.jsonl`: Build `3444265`, Release
  `2026-07-23T11:06:22Z`, HTTP 200, `max-age=300`, ETag und Last-Modified.
- Schema-Changelog: HTTP 200, `max-age=300`, ETag; höchster Eintrag
  `afterBuildNumber: 3407448`.
- Der real getestete lokale SDE-Stand entspricht damit weiterhin dem
  aktuellen offiziellen Build.
- Die App weist sich als unabhängige Drittanbieteranwendung aus, enthält den
  auf der aktuellen DLA-Seite geforderten CCP-Hinweis und verlinkt offizielle
  Bedingungen. Im geprüften Repositoryumfang wurden keine CCP-Logos oder
  Image-Export-Dateien gefunden.
- Keine Aussage über rechtliche Abschlussprüfung oder CCP-Genehmigung.

## Build und Tests

```text
python3 Scripts/verify_xcode_project.py
→ 16 Targets, 8 Testtargets, 2 gemeinsame Schemes

swift build -c release --disable-sandbox
→ erfolgreich

swift test -c release --disable-sandbox
→ 527/527 bestanden, 0 Fehler, 0 übersprungen

xcodebuild ... -scheme NewEdenNexus -configuration Release
  CODE_SIGNING_ALLOWED=NO build
→ BUILD SUCCEEDED; Universal-App für arm64 und x86_64

xcodebuild ... test
  -only-testing:NewEdenNexusUITests/P35AccessibilityUITests
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=-
→ 2/2 bestanden, 0 Fehler; echter App- und UI-Testworker
```

OFF-031 ist damit geschlossen. Die temporäre Ad-hoc-Signierung galt nur für
den UI-Testbefehl und änderte keine Projekt- oder Teamwerte.

## Öffentliche macOS-Verteilung

Das unsigned Release-Build ist ein technischer Build, kein
Distributionsartefakt:

- Bundle-ID: `com.newedennexus.local.NewEdenNexus`,
- `CFBundleShortVersionString` und `CFBundleVersion` fehlen,
- `CODE_SIGNING_ALLOWED=NO`; kein Development Team konfiguriert,
- keine Developer-ID-Signatur,
- Hardened Runtime und Notarisierung sind nicht eingerichtet,
- `codesign --verify --deep --strict` meldet „code object is not signed at
  all“; eine Gatekeeper-Freigabe ist deshalb nicht möglich.

Apple verlangt für eine direkte öffentliche macOS-Verteilung einen
Developer-ID-signierten Build und für die Notarisierung unter anderem
Hardened Runtime und gültige Signaturen. Diese Eigentümer-/Accountschritte
wurden nicht vorweggenommen.

## Dateien

Neu:

- `Documentation/Prompts/MVP/REL-001_Oeffentliche-Release-Compliance.md`
- dieser Bericht

Geändert:

- CCP-Compliance, Entwickler-Menü, Projektstatus, Feature-Matrix,
  Tagebuch, offene Aufgaben/Punkte, bekannte Probleme, Testhistorie und
  Promptregister.

Code, Datenmodell und Benutzerdaten: nicht geändert.  
Gelöschte oder verschobene Dateien: keine.

## Offene Anforderungen

- OFF-020: Eigentümer-Sign-off zu aktuellem DLA-/Markenhinweis,
  Monetarisierungsmodell und Datenschutz vor Veröffentlichung.
- OFF-032: endgültige Bundle-ID, Version/Build, Apple-Team und
  Distributionsweg festlegen; Developer-ID-Signierung, Hardened Runtime,
  Archiv, Notarisierung, Stapling und Gatekeeper-Test durchführen.
- P38 bleibt verschoben und darf nur auf ausdrücklichen Auftrag beginnen.

## Reviewentscheidung

Die Prüfung ist vollständig und OFF-031 bestanden. Die technischen
Releasebuilds und Tests sind grün. Die App darf dennoch nicht als
öffentlich freigabefähig bezeichnet werden, solange OFF-020 und OFF-032
offen sind. Entscheidung: **⚠️ mit Einschränkungen bestanden**.

## Nächste empfohlene Aufgabe

**OFF-032 – öffentliche macOS-Distributionskonfiguration**, erst nach
Eigentümerentscheidung zu Bundle-ID, Version, Apple-Team und
Verteilungsweg. P38 nicht automatisch beginnen.
