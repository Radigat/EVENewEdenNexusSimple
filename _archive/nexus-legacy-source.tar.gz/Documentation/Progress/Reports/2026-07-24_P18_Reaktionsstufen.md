# Abschlussbericht P18 – Reaktionsstufen

Datum: 2026-07-24

Status: ✅ erledigt

Review: ✅ bestanden

## Prompt-ID und Ziel

P18 integriert notwendige Reaktionen einschließlich Reaction→Reaction als
deterministische, erklärbare und SDE-gebundene Produktionsstufen. Der Scope
umfasst neutrale und modifizierte Kontexte, nicht jedoch das vollständige
Reaktionsmanagement aus P43.

## Ausgangszustand

P17 stellte Graphformat 5 für rekursive T1-/T2-Manufacturing-Ketten,
Blueprintqualität und den gemeinsamen Industrie-Regelvertrag bereit. Der
P10-Resolver konnte Reaktionsrezepte auflösen; der Graph behandelte sie noch
als zurückgestellte Blätter. Facility-, Reactor-, Rig-, Security- und
Skillwerte waren nicht als kataloggebundenes Reaktionsprofil persistiert.

Der Arbeitsbaum enthielt umfangreiche uncommittete Benutzer- und
Vorpromptänderungen. Sie wurden erhalten. Es erfolgten weder Commit, Push,
Reset, Signing- noch Teamänderungen.

## Durchgeführte Änderungen

- `ReactionRuleProfile`, Preflight und typisierte Fehler implementiert,
- neutrale und vollständig modifizierte `ReactionPlanningContext`-Werte
  implementiert,
- Material- und Zeitformel Version 1 ganzzahlig, gerundet,
  überlaufgeprüft und gegen manipulierte Persistenzwerte abgesichert,
- SDE-Import um `typeDogma`, `dogmaAttributes` und `dogmaEffects` erweitert,
- Import auf 20 relevante Typ-Dogma-, sechs Attribut- und acht
  Effektdefinitionen begrenzt,
- Composite-, Hybrid-, Biochemical- und Molecular-Forged-Formeln ihren
  Reaktoren zugeordnet,
- `ReactionIndustryDataReading` und SwiftData-Adapter eingeführt,
- reine Reaktionsaktivität, aktiver Katalog und Profilprovenienz erzwungen,
- Manufacturing→Reaction, Reaction→Manufacturing und Reaction→Reaction in
  den Graphservice integriert,
- Graphformat 6 und Expansionsrichtlinie 3 mit Zeit-/Materialtrace,
  Context- und Regelprovenienz eingeführt,
- Formate 1 bis 5 lesbar und veraltet erhalten,
- Schema v9 additiv um `ReactionRuleRecord` erweitert,
- v8→v9-, Legacy→v9-, Leerstore-, Wiederöffnungs- und Backuptests ergänzt,
- Reaktionsdarstellung in der Graphansicht ergänzt,
- synthetische Fixtures und Real-SDE-Abnahmerunner erweitert.

## Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ReactionCalculation.swift`
- `Sources/NewEdenNexusApplication/ReactionIndustryData.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataReactionIndustryData.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV9.swift`
- `Tests/NewEdenNexusDomainTests/ReactionCalculationTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ReactionIndustryDataPersistenceTests.swift`
- `Documentation/REACTION_CALCULATION.md`
- `Documentation/Architecture/ADRs/ADR-0023_Reaktionskontext-und-Graphformat-6.md`
- dieser Bericht

## Wesentlich geänderte Dateien

- Domain-/Application-Produktionsgraph,
- `JSONLinesSDECatalogMapper`,
- statische Katalogverträge und SDE-Importmanagement,
- SwiftData-Katalogpersistenz, Retention, Migration und Backup,
- App-Composition und `ProductionGraphView`,
- Real-SDE-Abnahmerunner,
- Referenzfixtures und Tests,
- Xcode-Projektmetadaten,
- verpflichtende Status-, Architektur-, Test- und Offen-Dokumentation.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Das Reaktionsregelprofil ist an SDE-Build und Inhaltshash gebunden. Ein
neutraler Kontext ist ein ausdrücklich unbeeinflusstes Basisszenario. Ein
modifizierter Kontext wird nur mit vollständiger Facility-, Reactor-, Rig-,
Security- und Skillbelegung akzeptiert. Fehlende beziehungsweise
`needsReview`-Regeln schlagen geschlossen fehl.

Reaktionskontexte werden in der versionierten Graphpayload gespeichert.
Nur das aktive kataloggebundene Regelprofil benötigt eine neue
SwiftData-Entität. Details stehen in ADR-0023.

## Datenmodelländerungen

Schema v9 ergänzt additiv `ReactionRuleRecord`. Bestehende Projekt-,
Graph-, SDE- und Benutzerdaten werden nicht fachlich umgeschrieben.
Backupformat 9.0.0 und Vorgänger 1.0.0 bis 8.0.0 bleiben lesbar.

Die Spezifikation erwartete vorsorglich Schema v10, falls P17 bereits v9
belegt hätte. Der tatsächliche P17-Stand war Schema v8. Entsprechend der
Spezifikationsregel „ohne Überspringen“ verwendet P18 nachweisbar v9.

## Offizielle SDE-Grundlage

Geprüft wurden ausschließlich offizielle CCP-Quellen:

- CCP-SDE-Dokumentation und offizieller JSONL-Download,
- CCP-Supportartikel „Reactions“,
- aktueller Build-Endpunkt.

Der geprüfte Build war `3444265`, Veröffentlichung
`2026-07-23T11:06:22Z`. Der reale Import ergab:

- 48 Kategorien,
- 1.609 Gruppen,
- 52.821 Typen,
- 5.082 Blueprints,
- 19.137 Aktivitäten,
- 36.499 Materialzeilen,
- 6.329 Produktzeilen,
- 21 bekannte nicht aufgelöste offizielle Typreferenzen, weiterhin
  itemgenau blockiert.

Composite, Hybrid und Biochemical wurden real aufgelöst. Eine
Composite-Formel wurde zusätzlich als Blueprint mit ausschließlich
Reaktionsaktivität, passendem Reactor und verifiziertem Regelprofil geprüft.

## Build-Ergebnis

Erfolgreich:

```text
swift test --scratch-path /private/tmp/NewEdenNexus-P18-SwiftPM
swift test -c release --scratch-path /private/tmp/NewEdenNexus-P18-SwiftPM-Release
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P18-Final-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P18-Final-Xcode-Release
  CODE_SIGNING_ALLOWED=NO test
```

Ergebnis:

- SwiftPM Debug und Release erfolgreich,
- Xcode Debug und Release erfolgreich,
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes,
- keine Signing- oder Teameinstellung geändert.

Xcode lief aus einer identischen temporären Quellkopie, weil die
SwiftData-Makro-Plugins in der CLI-Sandbox keine stabile Pluginverbindung
aufbauen konnten. Der statische Paritätscheck bestand in Repository und
Prüfkopie.

## Testergebnis

- SwiftPM Debug: 310 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 310 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 310 bestanden, 0 fehlgeschlagen.
- Xcode Release: 310 bestanden, 0 fehlgeschlagen.
- Real-SDE-Persistenztest Build 3444265: bestanden.
- Vollständiger offizieller SDE-Runner: Download, Import, Aktivierung,
  Wiederöffnung, Fertigung, T2 und alle drei Reaktionsarten bestanden;
  temporäre Artefakte wurden entfernt.

Nicht fehlschlagende Umgebungsdiagnosen:

- SwiftPM konnte Benutzer-Caches in der Sandbox nicht schreiben,
- Core Data meldete im Testhost wiederholt fehlende
  Store-Change-Notification-Registrierung,
- Xcode meldete fehlende AppIntents-Abhängigkeit und nicht erreichbare
  Testhost-Systemdienste.

## Manuelle Prüfungen

Das finale Debug-App-Binary startete mit
`/private/tmp/NewEdenNexus-P18-Final-App.3JxBnM/P18.store`.
Der Store enthielt `ProductionProject`, `ProductionGraphRecord` und
`ReactionRuleRecord`; `PRAGMA integrity_check` meldete während und nach dem
Lauf `ok`. Der Prozess wurde kontrolliert beendet. Produktive
Benutzerdaten wurden nicht geöffnet. Es wird keine neue visuelle oder
VoiceOver-Prüfung behauptet.

## Gefundene und behobene Probleme

1. Der erste finale Debuglauf fand eine ungültige mehrzeilige
   Guard-Formatierung. Die Closures wurden eindeutig geklammert; alle
   Abschlussläufe bestanden danach.
2. Die reale Formelprüfung suchte zunächst irrtümlich nach der
   Reaktionsgruppe am Produkt statt an der Formel. Die Suche wurde auf
   Formeln und deren Reaktionsprodukte korrigiert.
3. Der Realtest verlangt nun zusätzlich, dass die gewählte Formel
   ausschließlich eine Reaktionsaktivität besitzt.

## Bekannte Probleme und offene Anforderungen

- P19: gleiche Materialtypen aggregieren und Summenüberlauf definieren
  (`OFF-004`, `OFF-009`, `KI-003`, `KI-012`).
- OFF-021 bleibt als Bedarfsgate für spätere SDE-Erweiterungen.
- P34/P36/P37 bleiben unabhängige Wartbarkeits-, Recovery- und
  Release-Gates.
- P43 bleibt für Strukturzustand, Fuel, Kosten, Slots, Kalender und
  vollständiges Reaktionsmanagement zuständig.

## Abweichungen vom Projektbuch

Keine fachliche Scope-Abweichung. P18 erfüllt die Reaktionsstufe des
reduzierten MVP und zieht P43 nicht vor. Die Schemaversion wurde an den
tatsächlich belegten Vorgänger angepasst, ohne eine Nummer zu überspringen.

## Abnahmekriterien

1. Reaction→Reaction: erfüllt.
2. Kein Blueprint-ME/TE: erfüllt.
3. neutrale/modifizierte Kennzeichnung: erfüllt.
4. verifizierte Facility-/Reactor-/Rig-/Security-/Skillregeln: erfüllt.
5. Fail-closed bei unbekannt/needsReview: erfüllt.
6. maschinenlesbarer Preflight: erfüllt.
7. Migration, Backup, Altgraph- und Benutzerdatenschutz: erfüllt.
8. SwiftPM/Xcode Debug/Release: erfüllt.
9. relevante Tests ohne Überspringen: erfüllt.
10. isolierter App-/Store-Smoke: erfüllt.
11. Pflichtdokumentation und Bericht: erfüllt.
12. gesonderter Review: erfüllt.

## Reviewentscheidung

**✅ bestanden.** Der Review prüfte den tatsächlichen Diff, zentrale
Quelltexte, SDE-Minimalumfang, Schichtengrenzen, Formeln, Rundung,
Katalog-/Regelprovenienz, Graph- und Persistenzinvarianten, Tests,
Buildausgaben, Real-SDE, isolierten Store und Dokumentation. Die gefundenen
Punkte wurden vor dieser Entscheidung korrigiert und erneut geprüft.

## Nächster empfohlener Prompt

P19 – Aggregation und Graphschutz zunächst vollständig spezifizieren und
anschließend ausführen.
