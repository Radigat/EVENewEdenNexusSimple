# PLAN-004 – Folgeplanung für den lokalen Ausbau

Datum: 2026-07-26  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel und Ergebnis

Die vorhandenen Zukunftsprompts wurden ohne neue Parallelpakete verbindlich
geordnet:

1. P38–P40 persönliche EVE-Anbindung,
2. P41–P42 Märkte und Ist-Finanzen,
3. P43–P44 erweiterte Industrie,
4. P45–P47 Zusammenarbeit und Optimierung,
5. P48 zuletzt optional für öffentliche Apple-Distribution.

P38 ist der nächste offene, aber noch nicht begonnene Prompt und wurde
ausführbar spezifiziert.

## Änderungen

- PLAN-004 und diesen Bericht ergänzt,
- P38 um Architekturgrenzen, Sicherheitsanforderungen, Restbefunde,
  Nicht-Ziele, Risiken und messbare Abnahme erweitert,
- Entwickler-Menü, Roadmap, Promptregister, Status, offene Aufgaben,
  Feature-Matrix, Tagebuch und AGENTS.md auf die Reihenfolge abgestimmt.

App-Code, Datenmodell, Xcode-Projekt, Signing und Benutzerdaten wurden nicht
geändert. Kein Prompt P38–P48 wurde ausgeführt.

## Prüfungen

- `git diff --check`: erfolgreich,
- Dokumentpfade und Promptreihenfolge: erfolgreich,
- `Scripts/verify_xcode_project.py`: erfolgreich.

Kein App-Build und keine App-Tests wurden erneut ausgeführt, weil nur
Planungs- und Promptdokumentation geändert wurde. Der letzte verifizierte
Stand bleibt SwiftPM Release 527/527, Xcode-UI 2/2 und erfolgreicher lokaler
Xcode-Universal-Build.

## Offene Punkte

P38 übernimmt OFF-008, OFF-010 und OFF-013. OFF-021 bleibt ein
bedarfsgesteuertes SDE-Gate für P39–P44. OFF-020 und OFF-032 bleiben
ausschließlich P48 zugeordnet.

## Nächster Prompt

P38 – SSO-Härtung ausführen. Kein automatischer Beginn.
