# P38 – Keychain-Dialogkorrektur

## Ziel und Ausgangszustand

Beim realen Trennen erschienen mehrere Keychain-Freigaben und anschließend
`NEN-AUTH-002`. Eine neue Verbindung endete mit dem nicht weiter
differenzierten `NEN-AUTH-001`.

## Änderungen

- Verbinden liest einen vorhandenen Token nicht mehr vor dem Ersetzen.
- Trennen löscht zuerst den lokalen Charakterdatensatz und danach den Token;
  schlägt der Vault-Zugriff fehl, wird der Charakterdatensatz
  wiederhergestellt.
- Token-Save- und Repository-Fehler besitzen getestete Kompensation ohne
  zusätzlichen Token-Lesezugriff.
- Xcode-Logs enthalten künftig einen festen `error_reason`, aber keine
  Tokens, Autorisierungscodes, Scope-Namen oder Charakterdaten.
- Das lokale, git-ignorierte Signing-Profil wird vom vorhandenen
  Konfigurationsskript nun mit der Team-ID aus dem Zertifikat-OU erzeugt.
- Keine Datenbank-, Portal- oder Keychain-Datenänderung.

Die PKCE- und JWT-Regeln bleiben entsprechend der aktuellen offiziellen
[CCP-SSO-Dokumentation](https://developers.eveonline.com/docs/services/sso/)
unverändert.

## Build und Tests

- 13/13 fokussierte SSO-/Diagnosetests bestanden.
- 544/544 SwiftPM-Debugtests bestanden.
- Isolierter Xcode-Debugbuild für macOS arm64 ohne Signierung und Index:
  `BUILD SUCCEEDED`.
- Isolierter Xcode-Debugbuild desselben Quellstands mit der lokalen
  Apple-Development-Konfiguration: CodeSign und `BUILD SUCCEEDED`.
- `zsh -n Scripts/configure_local_signing.sh`: erfolgreich.
- `codesign --verify --deep --strict` für das erzeugte App-Bundle:
  erfolgreich.
- Ein Root-Xcode-Versuch wurde nach einem externen Buildcache-Konflikt
  abgebrochen; die isolierte Quellkopie beseitigte den Prüfkonflikt.

## Ergänzte Xcode-Meldungen

- `NEN-SDE-006`, `level=info`, `status=update_available`: regulärer
  SDE-Status, kein Buildfehler.
- `DetachedSignatures` und bereits abgebrochene Network-Listener:
  macOS-Laufzeitdiagnostik, kein Nachweis eines App-Buildfehlers.
- `NEN-AUTH-001` und `NEN-AUTH-002`: relevante Appfehler. Der historische
  OAuth-Untergrund ist aus der alten Zeile nicht rekonstruierbar; der neue
  Build ergänzt dafür `error_reason`.

## Review

Diff, Schichtengrenze, Fehlerkompensation, Redaction und Dokumentation
geprüft. Keine Tokens oder personenbezogenen Rohwerte wurden in Quellen,
Fixtures, Logs oder Bericht aufgenommen.

Entscheidung: **⚠️ mit Einschränkungen bestanden**. Die technische
Korrektur ist gebaut und getestet. P38 bleibt offen, bis Verbinden,
Neustart, Refresh und Trennen mit dem aktuellen stabil signierten Build real
erfolgreich geprüft wurden.

## Offener Punkt und nächster Schritt

`OFF-033`: aktuellen Apple-Development-Build starten und den manuellen
End-to-End-Lauf wiederholen. Bei erneutem `NEN-AUTH-001` ist die redigierte
Logzeile einschließlich `error_reason` der nächste eindeutige Prüfnachweis.
P39 wurde nicht begonnen.
