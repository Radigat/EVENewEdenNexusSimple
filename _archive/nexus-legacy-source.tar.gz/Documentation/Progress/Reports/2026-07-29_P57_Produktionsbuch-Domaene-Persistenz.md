# P57 – Produktionsbuch-Domäne und Persistenz

Datum: 2026-07-29

Status: ⚠️ technisch umgesetzt; Eigentümer-Neustarttest OFF-059 offen

Review: ⚠️ mit Einschränkung bestanden

## Ziel und Ausgangszustand

Tatsächlich ausgeführte Produktionschargen sollten getrennt vom veränderbaren
Projektplan nachvollziehbar werden. Vor P57 existierten Projekte, Graphen und
ESI-Industry-Jobs, aber kein persistentes Produktionsbuch.

## Änderungen

- unveränderlicher `ProductionBatchSnapshot` mit Jahresnummer, Projekt-,
  Graph-, Regel- und SDE-Bindung, Produkt, Runs, ME/TE, Output, Status sowie
  optionalen Charakter-, Blueprint-, Job- und Ortsbezügen,
- Managementservice mit manueller und ESI-Job-Vorbelegung,
  Schreibvorschau, ausdrücklicher Bestätigung und Stale-Prüfung,
- Schema v26 mit `ProductionBatchRecord` und transaktionalem Jahreszähler;
  additive v25→v26-Migration ohne erfundene Historie,
- native Navigation **Produktionsbuch** mit Tabelle, Details, Empty-/Fehler-
  zuständen und Filtern nach Jahr, Status, Projekt, Charakter, Produkt und Ort,
- Backup-/Restore-, Wiederöffnungs-, Migrations-, Parallelitäts-,
  Abbruch-, Filter-, Architektur- und Accessibility-Prüfungen,
- Xcode-Projekt aus dem Kanon neu generiert; vorhandene Benutzeränderungen
  weder verworfen noch committed.

Preis-, Kosten-, Wallet-, Verkaufs-, Analyse- und Metenoxfunktionen wurden
nicht begonnen. Es gab keine produktive Datenänderung.

## Architektur und Datenmodell

ADR-0060 ist akzeptiert. Projektplan und Charge bleiben getrennte Zustände.
Eine spätere Planänderung überschreibt keine Charge. Unaufgelöste Namen
bleiben explizit unbekannt. Schema v26 ist backupkompatibel zu 1–26.

## Build und Tests

- fokussiert: 27/27 bestanden,
- vollständige SwiftPM-Suite: 695/695 bestanden,
- Xcode Debug, Scheme `NewEdenNexus`, Ziel macOS:
  Apple-Development-signiert, `BUILD SUCCEEDED`,
- Projektgenerator/Projektkanon: 16 Targets, 8 Testtargets, 2 gemeinsame
  Schemes.

Informative CoreData-Meldungen zur Store-Changed-Registrierung traten in
isolierten Persistenztests auf; sie verursachten keinen Fehler.

## Review und Abnahmekriterien

Diff, Schichtgrenzen, Source-State-Prüfung, atomarer Schreibpfad,
Migration, Backup/Restore, Tests und Dokumentation wurden gesondert geprüft.
Der Review hat dabei die fehlenden sichtbaren Projekt-/Charakterfilter
gefunden; beide wurden vor Abschluss ergänzt und erneut getestet.

Technische Kriterien sind erfüllt. Nicht erfüllt ist ausschließlich der reale
Eigentümertest: Charge speichern, App vollständig beenden, neu starten und
mit unveränderter Jahresnummer wieder öffnen. Deshalb bleibt P57
definition-of-done-konform `⚠️`; OFF-059 dokumentiert den Restnachweis.

## Offene Punkte und nächster Schritt

- OFF-059 im aktuellen Xcode-Build durchführen.
- OFF-056 ist durch P57 nur teilweise erfüllt; Kosten, Verkauf und Analyse
  bleiben P58–P60.
- OFF-058/KI-059 bleibt ausschließlich P58 zugeordnet.
- P58 beginnt erst nach OFF-059 und nur auf ausdrücklichen Auftrag.
