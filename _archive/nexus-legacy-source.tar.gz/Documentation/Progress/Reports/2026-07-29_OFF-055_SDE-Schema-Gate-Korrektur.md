# OFF-055 – SDE-Schema-Gate-Korrektur

Datum: 2026-07-29  
Status: **⚠️ technisch bestanden; Eigentümer-Livetest offen**

## Ziel und Ausgangszustand

Der offizielle Build `3.448.696` war heruntergeladen und vorbereitet, wurde
aber gegenüber dem aktiven Build `3.444.265` mit
`NEN-SDE-007-SCHEMA` abgelehnt. Der offizielle CCP-Schema-Changelog meldete
weiterhin als höchsten Eintrag `afterBuildNumber: 3.407.448`.

Ursache war ein widersprüchliches Gate: Der Metadatencheck verglich korrekt
den Changelogstand mit dem verstandenen Parserstand, während der Installer
fälschlich die neue Daten-Buildnummer mit dem Parserstand verglich.

## Änderungen

- `SDEInstallationRequest` trennt:
  - Ziel-Datenbuild,
  - höchsten geprüften Changelog-Eintrag,
  - verstandenen Parserstand.
- `SDEInstallationService` blockiert nur einen fehlenden oder unverstandenen
  Schemawechsel.
- `SDEAppComposition` verlangt einen gespeicherten offiziellen Metadatenstand,
  dessen Build exakt zum Installationsziel passt.
- P36- und Real-SDE-Abnahmerunner verwenden den erweiterten Vertrag; der
  Realrunner erwartet den höchsten Changelogwert getrennt über
  `NEN_SDE_SCHEMA_CHANGE_AFTER_BUILD`.
- Ein Regressionstest beweist, dass Datenbuild 101 bei verstandenem
  Schemawechsel 99 und Parserstand 100 installiert werden darf.

Stagingstore, Streamingimport, Backup, atomare Aktivierung, Rollback,
Aufbewahrung und Benutzerbestände wurden nicht verändert.

## Geänderte Dateien

- `Sources/NewEdenNexusApplication/SDEInstallationContracts.swift`
- `Sources/NewEdenNexusApplication/SDEInstallation.swift`
- `Sources/NewEdenNexus/SDEAppComposition.swift`
- `Sources/NewEdenNexusSDEAcceptance/SDEAcceptanceRunner.swift`
- `Sources/NewEdenNexusSDEAcceptance/P36RecoveryAcceptance.swift`
- `Tests/NewEdenNexusApplicationTests/SDEInstallationServiceTests.swift`
- betroffene SDE-, Architektur-, Test- und Steuerdokumentation

Gelöscht oder verschoben: keine Dateien.  
Datenmodell/Migration: nicht betroffen.  
Produktive Daten: nicht verändert.

## Offizielle Prüfung

- CCP-Schema-Changelog am 2026-07-29 gelesen:
  höchster `afterBuildNumber` `3.407.448`.
- CCP-Änderungsdatei für Build `3.448.696` gelesen:
  `lastBuildNumber` `3.444.265`.
- Die Änderungsliste enthält IDs, nicht die vollständigen Ersatzdatensätze.
  Der sichere vollständige Archivpfad bleibt deshalb erhalten; eine
  inkrementelle Netzwerkaktualisierung wurde nicht behauptet oder ergänzt.

## Build und Tests

- fokussiert: **7/7 SDE-Installationstests bestanden**,
- vollständig: **682/682 SwiftPM-Tests bestanden**,
- drei RSA/JWT-Tests scheiterten nur innerhalb der Dateisandbox an
  `SecKeyCreateRandomKey` und bestanden einzeln sowie in der Vollsuite
  außerhalb dieser Grenze,
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64:
  Apple-Development-signiert, **BUILD SUCCEEDED**,
- `git diff --check`: bestanden.

Ein aktueller Real-SDE-Import wurde nicht automatisch gegen die produktive
Benutzerdatenbank ausgeführt.

## Review

**✅ technische Kontrollprüfung bestanden**

- Fehlerursache und Regressionstest stimmen überein.
- Fehlende, fremde oder unverstandene Metadaten bleiben fail-closed.
- Der bekannte aktive Katalog wird vor vollständiger Kandidatenprüfung nicht
  verändert.
- Vorhandene Benutzeränderungen und uncommittete Dateien wurden nicht
  verworfen.

## Offene Abnahme

`OFF-055` bleibt bis zum Eigentümerlauf teilweise:

1. App aus dem neuen Xcode-Build starten.
2. Build `3.448.696` installieren.
3. erfolgreiche Aktivierung prüfen.
4. App neu starten und installierten Build erneut prüfen.
5. Bei Fehler muss Build `3.444.265` aktiv bleiben und der neue Diagnosecode
   gemeldet werden.

Danach folgt unabhängig `OFF-054`. P54 bleibt gesondert
commit-freigabepflichtig; kein Commit oder Push wurde ausgeführt.
