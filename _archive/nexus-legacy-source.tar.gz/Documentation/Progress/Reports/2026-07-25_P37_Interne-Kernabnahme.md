# P37 – Interne Kernabnahme

**Datum:** 2026-07-25  
**Prompt-ID:** P37  
**Status:** ✅ erledigt  
**Review:** ✅ bestanden

## Ziel

Der reduzierte lokale Produktionskern wird mit persistenten, reproduzierbaren
T1- und T2-/Inventionsszenarien intern abgenommen. P37 ist ausdrücklich kein
Release Candidate und keine öffentliche Freigabe.

## Ausgangszustand

P26 stellte den bestätigten Build-or-Buy-Plan bereit. P32 verband Projekte,
Produktionsgraph, Lager, Schutzmengen, Reservierungen, Konflikte,
Build-or-Buy, Produktions-/Inventionsjobs und Fehlmengen in einem
Workspace. Ein einzelner persistenter Nachweis über diesen Kernfluss
einschließlich Schließen und Wiederöffnen fehlte.

## Durchgeführte Änderungen

- P37 vollständig und messbar spezifiziert,
- neuen persistenten Schema-v15-Kernabnahmetest ergänzt,
- T1-Kette mit Zwischenprodukt, vorhandenem Bestand, Runs und
  Rohstofffehlmenge geprüft,
- T2-Kette mit Invention, Datacores, gekauftem Zwischenprodukt und
  Lagerabzug geprüft,
- gespeicherte Build-or-Buy-Entscheidung durch den produktiven
  `BuildOrBuyPlanningService` angewendet,
- Projekte, Graphen, Bestände und Entscheidung nach Wiederöffnung desselben
  isolierten Stores geprüft,
- Reservierungskonfliktanzeige, Vorschaugrenzen und Workspace-Architektur
  in die fokussierte Kontrollmatrix aufgenommen,
- veralteten Rechtshinweis zur angeblichen Veröffentlichung in P37
  korrigiert und regressionsgeprüft,
- Xcode-Projekt regeneriert und gegen SwiftPM auf Parität geprüft,
- isoliertes App-Bundle gestartet und neu erzeugten Store geprüft,
- Status-, Test- und Fortschrittsdokumentation aktualisiert.

## Neu erstellte Dateien

- `Tests/NewEdenNexusPersistenceTests/P37CoreAcceptanceTests.swift`
- `Documentation/Progress/Reports/2026-07-25_P37_Interne-Kernabnahme.md`

## Geänderte Dateien

- `Sources/NewEdenNexus/SDELegalNoticesView.swift`
- `Tests/NewEdenNexusArchitectureTests/AppSourceArchitectureTests.swift`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- `Documentation/Prompts/MVP/P37_MVP-Abnahme-Release.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/Prompts/README.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/IMPLEMENTATION_ROADMAP.md`
- `Documentation/LEAN_MVP_PLAN.md`
- `Documentation/FEATURE_MATRIX.md`
- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/TEST_HISTORY.md`
- `Documentation/DEVELOPER_DIARY.md`

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Keine neue Produktarchitektur. Der Abnahmetest verwendet die vorhandene
Schema-v15-Persistenz, die bestehenden Produktions- und
Build-or-Buy-Services sowie synthetische Repository-Stubs. Er dupliziert
keine Fachberechnung.

## Datenmodelländerungen

Keine. Es wurde keine Migration angelegt und kein produktiver Store geöffnet.

## Fachliche Referenzfälle

### T1

- Zielmenge: 1
- Zwischenprodukt: Bedarf 10, Output 2 je Run
- Lagerbestand Zwischenprodukt: 4
- Ergebnis: 3 Runs, 6 produzierte Einheiten
- Rohstoffbedarf nach Lagerabzug: 9
- Rohstoffbestand: 5
- Fehlmenge: 4

### T2 mit Invention

- Zielmenge: 10
- erforderliche erfolgreiche Inventionskopien: 2
- Datacorebedarf: 2 je Invention, Gesamtbedarf 4
- Datacorebestand: 1, Fehlmenge: 3
- zugekauftes Zwischenprodukt: Bedarf 10
- Zwischenproduktbestand: 1, Fehlmenge: 9
- Rohstoffstufe unterhalb der Kaufentscheidung: nicht eingeplant

Nach dem Schließen und Wiederöffnen des Stores waren beide berechneten Pläne
und die gespeicherte Entscheidung exakt identisch reproduzierbar.

## Build-Ergebnis

| Prüfung | Ergebnis |
|---|---|
| `swift build -c debug` | erfolgreich |
| Xcode Debug, Scheme `NewEdenNexus`, macOS arm64, Signing deaktiviert | erfolgreich |
| Xcode-Projektprüfung | 15 Targets, 7 Testtargets, 2 gemeinsame Schemes |

## Testergebnis

| Prüfung | Ergebnis |
|---|---|
| fokussierte P37-Kontrollmatrix | 29/29 bestanden |
| vollständige SwiftPM-Debugsuite | 440/440 bestanden |
| vollständige Xcode-Debugsuite | 440/440 bestanden |
| übersprungene Tests | 0 |

Der erste SwiftPM-Aufruf war in der Dateisandbox nur wegen eines gesperrten
Compiler-Modulcaches nicht ausführbar. Derselbe Quellstand bestand im
freigegebenen Buildpfad. Während der Erstellung des neuen Tests wurden ein
Swift-XCTest-Autoclosure-Compilefehler und eine falsche Testannahme zur
Bedeutung von `requestedQuantity` korrigiert. Dafür war keine Änderung an der
Produktionslogik erforderlich.

## Manuelle Prüfungen

- erzeugtes App-Bundle mit isoliertem Storepfad gestartet,
- Prozess blieb nach dem Start lauffähig,
- Schema-v15-Store wurde angelegt,
- `PRAGMA integrity_check` meldete `ok`,
- Prozess anschließend kontrolliert beendet.

Es wird kein manueller GUI-/VoiceOver-Nachweis behauptet.

## Bekannte Probleme

Keine durch P37 verursachte kritische oder hohe Regression. Der Review fand
einen veralteten Rechtshinweis mit falschem P37-Zeitbezug; dieser wurde vor
Abschluss korrigiert und regressionsgeprüft.

## Offene Anforderungen

- P27–P31: verschobene fachliche Erweiterungen, beginnend mit manuellen
  Preisen und Preisprofilen,
- P33–P36: Fehler-UX, Performance-/Wartbarkeitsarbeiten, Backup-/Recovery-
  Bedienung und reale Prozessabbruch-/Neustartprüfung vor öffentlichem
  Release,
- zeitabhängiger CCP-/Compliance-Recheck vor einer öffentlichen Freigabe.

## Abweichungen vom Projektbuch

Keine neue Abweichung. Gemäß reduziertem Kernumfang wurden Preise, Kosten,
erweiterte Einkaufslisten und Release-Härtung nicht in P37 vorgezogen.

## Abnahmekriterien

- [x] persistenter T1-Referenzfall mit exakten Mengen,
- [x] persistenter T2-/Inventionsreferenzfall mit exakten Mengen,
- [x] Lagerabzug und Build-or-Buy nachgewiesen,
- [x] Wiederöffnung ohne Ergebnisdrift,
- [x] Reservierungskonflikt- und Workspace-Grenzen kontrolliert,
- [x] SwiftPM- und Xcode-Build erfolgreich,
- [x] alle relevanten Tests erfolgreich, keine übersprungen,
- [x] isolierter App-Start und Storeintegrität geprüft,
- [x] Dokumentation und Abschlussbericht aktualisiert,
- [x] gesonderter Review bestanden.

## Reviewentscheidung

**✅ bestanden.** Der tatsächliche Quellcode, die neue Persistenzprüfung, die
vollständigen SwiftPM-/Xcode-Ergebnisse, der isolierte App-Start und die
Dokumentationszuordnung wurden kontrolliert. P37 bestätigt den internen
Kernstand, aber keinen Release Candidate.

## Nächster empfohlener Prompt

**P27 – Manuelle Preise und Preisprofile reaktivieren.**
