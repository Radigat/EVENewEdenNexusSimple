# P52/P41-1 – ISK-Preissätze und schreibfreie Marktvorschau

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden, Eigentümer-Sichttest offen

## Ziel und Ausgangszustand

„Preisprofil“ wirkte in der UI wie eine überflüssige Währungswahl. Die
schreibfreie P41-1-Marktpreisvorschau war zudem ohne vorhandenes Profil
gesperrt.

## Änderungen

- sichtbare Terminologie auf **Preissatz** umgestellt; ein Preissatz trennt
  ISK-Preisstände beziehungsweise Szenarien,
- feste Rechen- und Speicherwährung ISK beibehalten,
- Marktpreisvorschau ohne Ziel-Preissatz ermöglicht,
- vorhandene Preise werden in diesem Pfad nicht gelesen,
- Übernahme ohne Ziel-Preissatz fail-closed gesperrt,
- PLEX-Umrechnung als späterer, abgeleiteter Buy-/Sell-Anzeigewert OFF-049
  dokumentiert.

Betroffen sind Domain-/Application-Vertrag der P41-Vorschau,
Workspace-/Markt-/Preis-UI, Regressionstests und Dokumentation. Persistenz,
Schema, Migrationen und vorhandene Benutzerdaten sind nicht betroffen.

## Build und Tests

- 12/12 fokussierte Markt-/Workspace-Tests bestanden,
- 664/664 vollständige SwiftPM-Tests bestanden,
- erster Xcode-Debugbuild im Repository-Derived-Data scheiterte ausschließlich
  an erneut übernommenen File-Provider/Finder-Metadaten beim finalen CodeSign,
- identischer Apple-Development-signierter Xcode-Debugbuild für macOS arm64
  mit isoliertem Derived Data: `BUILD SUCCEEDED`,
- `git diff --check`: bestanden.

## Review

Entscheidung: **⚠️ mit Einschränkungen bestanden**.

Der Diff erhält bestehende Preissätze und Daten, trennt Vorschau und
Schreibziel eindeutig und besitzt einen negativen Schreibtest. Es gibt keine
Migration und keine automatische Profilerzeugung. Offen ist ausschließlich
die reale Bedienprüfung; die optionale PLEX-Anzeige ist bewusst kein Teil
dieser Korrektur.

## Offene Punkte und nächster Schritt

- OFF-048: neuen Build öffnen; unter **Kosten & ROI → ESI-Materialpreise**
  „Keiner – nur Vorschau“ verwenden, Region eingeben, Vorschau abrufen,
  gesperrte Übernahme prüfen und über **Schließen** beenden.
- P41-2 bleibt bis zu einer neuen ausdrücklichen Bestätigung nicht
  autorisiert.
- OFF-049: PLEX-Anzeige nur nach eigenem Nutzenreview und getrenntem
  Buy-/Sell-Quotevertrag.
