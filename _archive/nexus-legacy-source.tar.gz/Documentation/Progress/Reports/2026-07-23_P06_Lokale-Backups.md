# Abschlussbericht – P06: Lokale Backups

## Prompt-ID und Ziel

**P06 – Lokale Backups**

Ziel war eine sichere, versionierte und testbare technische Backup-/Restore-Grenze für den lokalen SwiftData-Store. Fachliche MVP-Funktionen und eine fertige Recovery-Oberfläche waren nicht Bestandteil.

## Ausgangszustand

- Schema v1, Lightweight-Migration und zentrale Containerfactory vorhanden.
- Temporäre Storehelfer und Debug-/Release-Prüfeinstieg vorhanden.
- Kein Backupvertrag, Paketformat, Snapshot, Restore oder Integritätsnachweis.
- SwiftData-Store kann WAL-/SHM-Dateien verwenden.
- P06-Prompt war noch nicht ausführungsreif spezifiziert.

## Durchgeführte Änderungen

- Projektbuchanforderungen zu Sicherung, Integrität, Wiederherstellung und Aufbewahrung ausgewertet.
- P06 vollständig mit Format, Fehlerfällen, Referenzfällen und Abnahmekriterien spezifiziert.
- `LocalBackupManaging` und UI-unabhängige Application-Typen eingeführt.
- SQLite-Online-Backup mit BUSY-/LOCKED-Wiederholung umgesetzt.
- `.nenbackup`-Paketformat Version 1 mit Manifest und `database.sqlite` umgesetzt.
- SHA-256, Dateigröße, immutable `quick_check` und restriktive Rechte ergänzt.
- atomare Veröffentlichung aus `.partial` im Zielverzeichnis umgesetzt.
- Paketprüfung und read-only Restore-Vorschau umgesetzt.
- Ziel-Fingerabdruck aus Hauptdatei, WAL und SHM ergänzt.
- Restore mit Bestätigung, Closed-Store-Gate, Sicherheitsbackup, vorbereiteter Ersatzdatei und Sidecar-Quarantäne umgesetzt.
- drei zentrale Fehleroperationen und Codes `NEN-BACKUP-001` bis `NEN-BACKUP-003` ergänzt.
- acht Integrationstests mit temporären SwiftData-Stores ergänzt.

## Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/LocalBackupManagement.swift`
- `Sources/NewEdenNexusPersistence/SQLiteDatabaseSnapshot.swift`
- `Sources/NewEdenNexusPersistence/SQLiteLocalBackupService.swift`
- `Tests/NewEdenNexusPersistenceTests/SQLiteLocalBackupServiceTests.swift`
- `Documentation/BACKUP_AND_RESTORE.md`
- `Documentation/Architecture/ADRs/ADR-0006_Versioniertes-lokales-Backupformat.md`
- dieser Bericht

## Geänderte Dateien

- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- `Documentation/Prompts/MVP/P06_Backups.md`
- `Documentation/Architecture/ADRs/README.md`
- `Documentation/ARCHITECTURE_CHANGES.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/FEATURE_MATRIX.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/TEST_HISTORY.md`
- `Documentation/IMPLEMENTATION_ROADMAP.md`
- `Documentation/Prompts/README.md`

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

ADR-0006 legt fest:

- SQLite-Online-Backup statt Dateikopie,
- versioniertes, unkomprimiertes Verzeichnispaket,
- Manifestbindung an Schema, Größe und SHA-256,
- atomare Veröffentlichung,
- keine anwendungseigene Verschlüsselung in Formatversion 1,
- Keychain-Ausschluss,
- `keep all`,
- zwingendes Sicherheitsbackup vor Überschreiben eines vorhandenen Ziels.

Application bleibt SwiftData-, SQLite3- und CryptoKit-frei. Der konkrete Adapter liegt in Persistence.

## Datenmodelländerungen

Keine. `NexusSchemaV1` bleibt 1.0.0; Migrationsplan und persistente Entitäten wurden nicht verändert.

## Build-Ergebnis

Ausgeführt:

```bash
./Scripts/ci-verify.sh
```

Enthalten:

```bash
swift package describe
swift build -c debug
swift build -c release
swift test -c debug --enable-code-coverage
swift test -c release
```

Ergebnis: Targetgraph bestätigt, Debug- und Release-Build erfolgreich, keine Compilerwarnungen im erfolgreichen Abschlusslauf.

## Testergebnis

Abschluss:

- Debug: **48 Tests, 0 Fehler, 0 unerwartete Fehler**.
- Release: **48 Tests, 0 Fehler, 0 unerwartete Fehler**.
- 8 neue Backup-/Restore-Integrationstests.
- keine übersprungenen XCTest-Tests.

Coverage:

- alle instrumentierten Dateien: `2852/4241`, `67,25 %`,
- produktive Sources: `1061/2415`, `43,93 %`,
- Domain/Application: `336/338`, `99,41 %`,
- SQLite-Backupadapter: `549/682`, `80,50 %`.

Der erste vollständige Lauf baute erfolgreich, meldete aber 6 Backup-Testfehler mit SQLite-Code 14. Ursache war die read-only Integritätsprüfung eines WAL-markierten Snapshots. Die Prüfung wurde auf SQLite `immutable=1` korrigiert. Kein Test wurde entfernt oder abgeschwächt.

## Manuelle und strukturelle Prüfungen

- Quellcode-Review von Snapshot, Veröffentlichung, Restore und Fehlerpfaden.
- Application-Importgrenze um SQLite3 und CryptoKit erweitert.
- Dateirechte `0700`/`0600` automatisiert geprüft.
- keine `.partial`-Reste nach Fehlern.
- keine temporären P06-Testverzeichnisse nach dem Lauf.
- sichere Fehlercodes und Raw-Error-/Redaction-Regressionen grün.
- Git-Wurzel weiterhin Projektordner; nichts gestaged, committed oder gepusht.
- OFFEN-Audit vollständig aktualisiert.

## Bekannte Probleme

- Der Dienst ist technisch, aber noch nicht über eine fertige UI erreichbar.
- Closed-Store-Zustand muss vom App-Lebenszyklus garantiert werden.
- automatische `beforeMigration`-Auslösung fehlt bis zum nächsten Schemwechsel/P36.
- kein Crash-Injection-Test exakt während atomarer Veröffentlichung oder Ersetzung.
- keine Komprimierung, Rotation oder anwendungseigene Verschlüsselung.

## Offene Anforderungen

- P36: Restore-UI, Container-Lebenszyklus, App-Neustart und Recovery-Drill.
- spätere Einstellungen: Speicherort, Intervall und Rotation.
- SDE und der fachliche Produktionsplaner bleiben ab P07 offen.

## Abweichungen vom Projektbuch

- Projektbuchoptionen Komprimierung und Verschlüsselung sind für Formatversion 1 bewusst nicht umgesetzt.
- vollständige 3-2-1-Strategie kann die App ohne einen vom Benutzer gewählten externen Speicherort nicht erzwingen.
- automatische Vor-Migrations-Sicherung wird erst bei einem tatsächlichen Schemwechsel beziehungsweise P36 verdrahtet.

Diese Abgrenzungen sind in ADR-0006 dokumentiert und widersprechen dem reduzierten P06-MVP nicht.

## Erfüllte Abnahmekriterien

- [x] Paketformat und Sicherheitsgrenzen dokumentiert.
- [x] Online-Backup bei geöffnetem Quellcontainer.
- [x] finale Veröffentlichung erst nach Prüfung.
- [x] read-only Vorschau.
- [x] manipulierte und inkompatible Pakete abgelehnt.
- [x] Restore nur mit Bestätigung und Closed-Store-Erklärung.
- [x] verifiziertes Sicherheitsbackup vor Überschreiben.
- [x] Backup und Sicherheitsbackup vollständig wieder geöffnet.
- [x] keine Schema- oder produktive Benutzerdatenänderung.
- [x] zentrale Fehlercodes und Redaction-Regressionsnachweis.
- [x] Debug-/Release-Build und Tests erfolgreich.
- [x] OFFEN-Audit, Pflichtdokumentation und gesonderter Review abgeschlossen.

## Nicht erfüllte Abnahmekriterien

Keine innerhalb des verbindlichen P06-Umfangs.

## Reviewentscheidung

Im gesonderten Review wurde zunächst ein fehlender Schutz gegen Zieländerungen nach der Vorschau erkannt. Der Ziel-Fingerabdruck und ein Regressionstest wurden ergänzt. Anschließend wurden gezielte Tests und der vollständige Debug-/Release-Prüfweg erneut erfolgreich ausgeführt.

Entscheidung: **✅ bestanden**.

Es bestehen keine offenen kritischen oder hohen P06-Befunde.

## Nächster empfohlener Prompt

**P07 – SDE-Importpipeline vollständig spezifizieren.** P07 wurde nicht begonnen.
