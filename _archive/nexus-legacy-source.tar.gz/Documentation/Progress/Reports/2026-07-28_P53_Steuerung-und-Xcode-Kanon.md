# P53 – Steuerung und Xcode-Kanon

Datum: 2026-07-28  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel und Ausgangszustand

Aktuelle Steuerquellen sollten vereinheitlicht und genau ein aktiver
Xcode-Projektkanon hergestellt werden. Neun historische Projektkopien und
ein alter P21-Entwurf waren einzeln inventarisiert; ihre recoverbare
Verschiebung wartete auf Eigentümerbestätigung.

## Änderungen

- Eigentümerbestätigung für die dokumentierte Vorschau erhalten.
- `NewEdenNexus 2.xcodeproj` bis `NewEdenNexus 10.xcodeproj` unverändert
  nach `Documentation/Archive/XcodeProjects/` verschoben.
- alten P21-Entwurf nach
  `Documentation/Prompts/Archive/P21_CSV-Bestandsimport_Entwurf.md`
  verschoben; kanonischen P21-Prompt unverändert erhalten.
- `Scripts/verify_project_governance.py` für einen Root-Projektkanon,
  Archivvollständigkeit, Prompt-IDs und aktuelle Steuerlinks ergänzt.
- Governance- und Xcode-Projektprüfer in `Scripts/ci-verify.sh` eingebunden.
- Status-, Roadmap-, Feature-, Prompt- und offene-Punkte-Steuerung
  widerspruchsfrei auf P53 abgeschlossen aktualisiert.
- OFF-051-Nachtrag erhalten: Stationsgruppen lassen sich über die gesamte
  benannte Zeile auf- und zuklappen.

Es wurde nichts gelöscht, committed oder gepusht. App-Daten,
Schlüsselbund, Signing-Konfiguration und Datenmodell blieben unverändert.
Alle Archiv-Prüfsummen entsprechen der Einzelvorschau.

## Build und Tests

- SwiftPM Debug: erfolgreich; 668/668 Tests bestanden.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64: `BUILD SUCCEEDED`,
  unverändert Apple-Development-signiert.
- Projektverifier: 16 Targets, acht Testtargets, zwei gemeinsame Schemes.
- `plutil -lint`, `xcodebuild -list`, Governance-/Linkprüfung und
  `git diff --check`: bestanden.
- Nicht blockierend: `xcodebuild -list` meldete in der eingeschränkten
  CLI-Umgebung CoreSimulator-/Logstore-Warnungen. Die macOS-Auflistung
  endete mit Exitcode 0.

## Review

Der tatsächliche Dateistand, die Archivanzahl, Prüfsummen, der aktive
Projektkanon, Buildausgabe, Tests und Steuerdokumente wurden getrennt
kontrolliert. Keine P53-Regression oder unbeabsichtigte Datenänderung ist
offen. Entscheidung: ✅ bestanden.

## Offene Anforderungen und nächster Prompt

OFF-037 mit verbleibenden P42-Projektzuordnungs-/Endgates sowie die
unabhängigen Namens-Livetests bleiben offen und wurden nicht als bestanden
umgedeutet. OFF-039/P54 ist der nächste Steuerungsschritt, darf aber nur nach
einer neuen ausdrücklichen Commit-Freigabe ausgeführt werden; kein Push.
