# P52/OFF-051 – Gruppierte ESI-Detailansichten

Datum: 2026-07-28  
Status: ⚠️ technisch bestanden, Eigentümer-Sichttest offen  
Review: ⚠️ mit Einschränkungen bestanden

## Ziel und Ausgangszustand

Accountdetails sollten Assets, Blueprints und Industry Jobs verständlich und
schnell nach Station erschließen. Zuvor wurden bis zu 2.000 Einzelzeilen
sofort erzeugt, der Asset-Baum wiederholt je Ort aufgelöst und bei Jobs auch
ausgelieferte Historie angezeigt.

## Änderungen

- einmaliger, memo-isierter Ortsindex für alle referenzierten ESI-Orte,
- vollständige Application-Projektionen mit alphabetischen Stationsgruppen,
- globale Suche über den gesamten Snapshot; Treffergruppen öffnen sich,
- Assets und Blueprints zunächst geschlossen, sichtbare Zeilen in
  100er-Schritten,
- Industry Jobs auf den Darstellungsstatus `active` begrenzt,
- Suche und Sortierung entprellt und außerhalb des Main Threads; veraltete
  Ergebnisse werden nicht veröffentlicht,
- Snapshot-, Persistenz-, Scope- und Datenmodelle unverändert,
- ADR-0055 sowie betroffene Status-, Test- und ESI-Dokumentation ergänzt.

Geänderte Quellen:

- `Sources/NewEdenNexus/ESIPersonalDataDetailView.swift`
- `Sources/NewEdenNexusApplication/ESIPersonalDataDetails.swift`
- `Sources/NewEdenNexusApplication/ESILocationNames.swift`
- drei betroffene Testdateien.

Gelöschte oder verschobene Dateien: keine.  
Datenmodell/Migration: nicht betroffen.  
Benutzerdaten: nicht gelesen oder geändert.

## Build und Tests

- fokussiert: 17/17 bestanden,
- vollständiger SwiftPM-Debuglauf: 668/668 bestanden,
- 5.001-Asset-Fall: globaler Treffer hinter Zeile 5.000 gefunden,
  Gruppierung rund 0,064 s,
- Xcode Debug macOS arm64 unsigned: `BUILD SUCCEEDED`,
- Xcode Debug macOS arm64 Apple-Development-signiert mit aktuell gültigem
  Team-Override: `BUILD SUCCEEDED`,
- unveränderter Standard-Signinglauf: vor Kompilierung fehlgeschlagen, weil
  die Projekt-Team-ID nicht zur aktuell gültigen Identität passt,
- `git diff --check`: bestanden.

Der erste SwiftPM-Lauf innerhalb der Dateisandbox scheiterte an
`sandbox_apply`; der erste unsigned Xcode-Lauf innerhalb der Sandbox am
SwiftData-Makroserver. Beide Prüfungen wurden mit isolierten Pfaden außerhalb
dieser Sandbox erfolgreich wiederholt.

## Review

Der tatsächliche Quellstand, die neue Projektionsgrenze, Snapshot-
Bestandsschutz, fokussierte Regressionen, Vollsuite, Xcode-Builds und
Dokumentationsdelta wurden geprüft.

Entscheidung: **⚠️ mit Einschränkungen bestanden**.

Technisch sind die Abnahmekriterien erfüllt. Offen bleiben:

- `OFF-051`: Eigentümer prüft alphabetische Gruppen, Auf-/Zuklappen, globale
  Suche und ausschließlich aktive Jobs im echten Datenbestand.
- `OFF-052`: bestehende Xcode-Teamabweichung erst in P53 nach Vorschau und
  ausdrücklicher Bestätigung angleichen.

## Nächster Schritt

OFF-051 im aktuellen Build sichtbar prüfen. Danach P42-1 wie geplant nur als
Wallet-Projektzuordnungsvorschau ausführen und verwerfen; P42-2 nicht
vorziehen.
