# P51 – P42-Korrektur Scope, Fehler und Plan/Ist

Datum: 2026-07-27  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel und Ausgangszustand

P42-Fehlerrouting, Scope-Aufklärung und Plan-/Ist-Darstellung vollständig
korrigieren. Vorher waren persönliche und Walletoperationen in der View
vertauscht, der P40-Basislogin verlangte unnötig den Walletscope und die
Finanzansicht zeigte die getrennten P29-/P42-Werte nicht vollständig
nebeneinander.

## Durchgeführte Änderungen

- alle vier P40-/P42-Viewoperationen ihren korrekten stabilen Fehleroperationen
  zugeordnet und den tatsächlichen Viewpfad regressionsgetestet,
- zentrale Zweckkonfiguration eingeführt: exakt drei P40-Scopes; der vierte
  Walletscope erst nach Erklärung und ausdrücklicher Neuautorisierung,
- Abbruch/Ablehnung vor jeder Mutation; erfolgreiche Neuautorisierung muss
  denselben Charakter liefern,
- nicht geheime angeforderte Scopemetadaten additiv in Schema v24 gespeichert;
  Migrationen erfinden keine Zustimmung und Snapshots aktivieren keinen Scope,
- Settings, Accounts und Synchronisation um Zweck, lokale Speicherung,
  Berechtigungsstand sowie Trenn-/Löschwirkung ergänzt,
- P29-Plan und bestätigtes P42-Ist je Projekt in einer gemeinsamen Tabelle
  dargestellt; fehlende, veraltete und archivierte Zustände explizit,
- neue Walletzuordnungen zu archivierten Projekten gesperrt; keine
  automatische Zuordnung und keine Überschreibung von Planwerten.

Neu erstellt wurden die Scope-/Zweckverträge, der Application-
Finanzvergleich, Schema v24, zugehörige Tests und ADR-0049. Geändert wurden
SSO-Use-Case, Accountrepository, Composition/ViewModel/UI,
Migrations-/Backupgrenzen, Xcode-Projekt und betroffene Dokumentation.
Gelöscht oder verschoben wurde nichts.

## Architektur und Datenmodell

Scopedefinitionen liegen einmalig in Application. SwiftData speichert
`EVEAccountAuthorizationRecord(characterID, scopesJSON, authorizedAt,
recordVersion)`; Tokens bleiben ausschließlich im Keychain. Die leichte
v23→v24-Migration erhält alle Daten und erzeugt keinen Scopebeleg.
`ProjectFinanceComparisonService` liest Plan und Ist getrennt und schreibt
nichts. Details: [ADR-0049](../../Architecture/ADRs/ADR-0049_Zweckgebundene-ESI-Scopes-und-Plan-Ist-Vergleich.md).

## Build, Tests und manuelle Prüfungen

- SwiftPM Debug: erfolgreich.
- Zwei fokussierte Läufe: **29/29 + 29/29** Tests bestanden.
- Vollsuite außerhalb der Sandbox: **631/631**, 0 Fehler.
- Projektverifier: **16 Targets, 8 Testtargets, 2 gemeinsame Schemes**.
- isolierter unsigned Xcode Debug, macOS, `CODE_SIGNING_ALLOWED=NO`:
  **BUILD SUCCEEDED**.
- `git diff --check` und Konfliktmarkersuche: ohne Befund. Die
  Geheimnismustersuche fand nur die beabsichtigte öffentliche Client-ID,
  eine Negativassertion zu `client_secret` und historische redigierte
  Keychain-Dienstbezeichner; kein neues Geheimnis oder Token.

Der erste sandboxed Xcode-Versuch konnte den SwiftData-Makroprozess nicht
starten; derselbe isolierte Build bestand außerhalb der Sandbox. Ein erster
sandboxed Gesamttestlauf betraf nur Security-Framework-SSO-Tests; 8/8
fokussiert und anschließend 631/631 vollständig bestanden außerhalb der
Sandbox. Ein produktiver persönlicher ESI-/Walletlauf wurde entsprechend der
P51-Grenze nicht ausgeführt.

## Abnahme und Review

Alle acht P51-Abnahmekriterien sind durch Quellcode, View-/Architekturtests,
Scope-/Abbruchtests, Plan-/Ist-Referenztests, Schema-v24-Migration,
Wiederöffnung, Backup/Restore, Trennkompensation sowie beide Buildwege
nachgewiesen. Reviewentscheidung: **✅ bestanden**. OFF-036, KI-039 und
KI-040 sind geschlossen. Keine kritische Regression oder Abweichung vom
Projektbuch festgestellt.

## Offene Anforderungen und nächster Prompt

OFF-037 bleibt unverändert: P40–P42 müssen mit den realen Eigentümerdaten,
Preview/Bestätigung, Offlinefall und Neustart kontrolliert geprüft werden.
Das ist ausschließlich **P52**, nur auf ausdrücklichen Auftrag. P53/P54 und
die verschobenen P43–P48 wurden nicht vorgezogen. Kein Commit oder Push.
