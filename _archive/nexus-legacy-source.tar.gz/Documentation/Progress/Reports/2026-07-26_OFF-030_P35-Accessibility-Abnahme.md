# OFF-030 / P35 – Native Accessibility-Abnahme

Datum: 2026-07-26

Status: **✅ erledigt**

Review: **✅ bestanden**

## Ziel und Ausgangszustand

OFF-030 verlangte die abschließende Prüfung des aktuellen P35-Builds bei
1.280 × 800 und 780 × 560 über einen nativen Accessibility-Kanal sowie einen
Tastaturfokusnachweis. Der interaktive Computer-Use-Kanal schloss seine Pipe
bei jedem App-Zugriff und lieferte keinen belastbaren Baum.

## Änderungen

- dauerhaftes macOS-XCUITest-Target `NewEdenNexusUITests` im Xcode-Projekt,
- zwei UI-Tests mit isoliertem App-Store:
  - reales Standard- und Mindestfenster,
  - Dashboard, Kernstatus und Sidebar-Suche,
  - nativer `sufficientElementDescription`-Audit,
  - Tab-Fokusbewegung zwischen zwei Steuerelementen,
- zugängliche Dashboard-Metriken als Textrepräsentationen und benannter
  Projektübersichtscontainer,
- App-Inhaltshöhe auf 500 Punkte korrigiert, damit das reale Fenster
  einschließlich macOS-Fensterleiste tatsächlich 780 × 560 erreicht,
- Xcode-Paritätsprüfung auf das Xcode-only-UI-Testtarget erweitert.

Keine Fachlogik, Daten, Schema-, Backup- oder Graphversion wurde geändert.
P36 wurde nicht begonnen.

## Dateien

Neu:

- `Tests/NewEdenNexusUITests/P35AccessibilityUITests.swift`
- dieser Abschlussbericht

Geändert:

- `project.yml`, generiertes `NewEdenNexus.xcodeproj`
- `Scripts/verify_xcode_project.py`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Sources/NewEdenNexus/RootView.swift`
- `Sources/NewEdenNexus/DashboardView.swift`
- `Sources/NewEdenNexus/Theme.swift`
- `Tests/NewEdenNexusArchitectureTests/P35AccessibilityArchitectureTests.swift`
- P35-/Status-/Test-/Architekturdokumentation

Gelöscht oder verschoben: nicht betroffen.

## Build und Tests

```text
env CLANG_MODULE_CACHE_PATH=/private/tmp/new-eden-nexus-off030-swift-cache \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/new-eden-nexus-off030-swift-cache \
  swift test --disable-sandbox

xcodebuild test -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath /private/tmp/new-eden-nexus-off030-xcode-full \
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=-

python3 Scripts/verify_xcode_project.py
git diff --check
```

- SwiftPM Debug: **518/518 bestanden**, 0 übersprungen.
- Xcode Debug: **520/520 bestanden**, 0 übersprungen; davon zwei native
  UI-Tests.
- Xcode-Metadaten: **16 Targets, acht Testtargets, zwei Schemes**.
- Signierung nur als temporäre Befehlszeilen-Ad-hoc-Signierung; keine
  Signing- oder Team-Einstellung im Projekt geändert.
- Bekannte Core-Data-/Cachehinweise und eine fehlende LLDB-Versionsmeldung
  im Testhost hatten keine Testwirkung.

Explorative Vorläufe fanden nacheinander die reale Mindestfensterabweichung,
eine unbenannte Dashboard-Rasterrolle und einen deaktivierten macOS-
Touch-Bar-Strukturcontainer. Die Produktbefunde wurden korrigiert; die
Systemcontainer-Ausnahme ist eng auf deaktivierte Gruppen und Touch Bar
begrenzt. Ein Architekturtest erwartete anschließend noch die ersetzte alte
Metriksemantik und wurde passend aktualisiert. Nur die oben genannten finalen
Läufe gelten als Abnahme.

## Datenwirkung und manuelle Prüfung

Alle UI-Tests verwenden einen eindeutigen temporären Store. Produktive
Benutzerdaten wurden nicht geöffnet oder verändert. Der native Test bedient
das echte App-Fenster durch Größenänderung und Tab-Tasten. Ein manueller
VoiceOver-Erfolg wird wegen des ausgefallenen interaktiven Kanals nicht
behauptet.

## Abnahmekriterien

- Standard- und Mindestfenster real geprüft: **erfüllt**
- zugänglicher Kernstatus und Suche: **erfüllt**
- nativer Accessibility-Audit: **erfüllt**
- Tastaturfokusbewegung: **erfüllt**
- vollständige Builds und Tests: **erfüllt**
- Dokumentation, Matrix, Tagebuch und Bericht: **erfüllt**
- kritische Regressionen: **keine festgestellt**

## Offene Anforderungen und Abweichungen

OFF-030/KI-030 sind geschlossen. P36, OFF-024 und die persönliche
zeitabhängige Release-/Complianceprüfung bleiben unabhängig offen. Keine
Abweichung vom reduzierten MVP; keine fachliche Erweiterung.

## Nächster empfohlener Prompt

P36 – Migration und Recovery-Drill, ausschließlich nach ausdrücklichem
Auftrag. P36 wurde in diesem Paket nicht begonnen.
