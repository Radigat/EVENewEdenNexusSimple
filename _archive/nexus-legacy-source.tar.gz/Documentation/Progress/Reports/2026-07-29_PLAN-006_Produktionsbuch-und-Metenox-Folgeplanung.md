# PLAN-006 – Produktionsbuch und Metenox-Folgeplanung

## Ziel und Ausgangszustand

Die private Eigentümer-Arbeitsmappe wurde schreibfrei analysiert. Nexus besitzt
bereits Projekt-, Graph-, Budget-, Markt-, Industry-Job- und Walletgrundlagen,
aber kein Chargenbuch, keine sichtbare neue Istfinanz und keinen
Metenox-Rechner.

## Durchgeführte Arbeiten

- zehn Tabellenblätter, Formeln und Layouts analysiert,
- Produktionsübersicht, Wallet, Markt und Metenox fachlich extrahiert,
- vorhandene Nexus-Dienste gegen Doppelimplementierung geprüft,
- authoritative Spezifikation und ADR-0060 erstellt,
- P57–P61 mit Abhängigkeiten, Grenzen und Abnahme definiert,
- OFF-056/OFF-057 als notwendige Restbefunde zugeordnet.

Die Arbeitsmappe wurde nicht verändert oder ins Repository kopiert. Private
ESI-Werte und technische IDs wurden nicht dokumentiert.

## Zentrale Entscheidungen

Plan, Charge, Beleg und Verkauf bleiben getrennt. Kosten pro Unit verwenden
tatsächliche Units. ESI-Zuordnungen bleiben Preview-before-write. Metenox-Regeln
werden versioniert und vor Implementierung aktuell verifiziert.

## Build und Tests

Nicht betroffen: keine Swift-, Projekt- oder Datenmodelländerung. Workbook-
Inspektion und visuelle Prüfung aller zehn Blätter waren erfolgreich.
`verify_project_governance.py` bestand mit 66 Prompt-IDs und 255 geprüften
Links. `verify_xcode_project.py` bestätigte 16 Targets, 8 Testtargets und
2 gemeinsame Schemes. `git diff --check` bestand. Ein erneuter Swift-/Xcode-
Lauf war für dieses reine Dokumentationspaket nicht erforderlich.

## Offene Punkte

- OFF-055 realer SDE-Update-/Neustartnachweis,
- OFF-054 sichtbare P55/P56-Abnahme,
- OFF-056 Umsetzung P57–P60,
- OFF-057 Regelverifikation in P61,
- P54 weiterhin nur nach gesonderter Commit-Freigabe.

## Reviewentscheidung

✅ bestanden als Spezifikations- und Planungspaket. Keine Implementierungs-
oder Laufzeitabnahme behauptet.

## Nächster Prompt

Nach OFF-055 und OFF-054: P57. P57 beginnt nur auf ausdrücklichen Auftrag.
