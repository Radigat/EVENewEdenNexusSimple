# P26 – Build-or-Buy

Datum: 2026-07-25  
Status: ✅ erledigt  
Review: ✅ bestanden

## Ziel und Ausgangszustand

P26 sollte den vorhandenen Produktionsgraphen und die P22–P25-Bestandsregeln
zu einem schlanken Produktions-/Inventionsplan verbinden. Vorher existierten
Graph, Lager, Schutz und Reservierungen nur als getrennte Bausteine.

## Durchgeführte Änderungen

- typisierte projektbezogene Entscheidungen **Bauen**/**Kaufen**,
- deterministischer Graphschnitt an gekauften Zwischenprodukten,
- stufenweiser Verbrauch eines gemeinsamen Type-ID-Bestandspools,
- Neuberechnung reduzierter Runs und Unterketten bei Zwischenbestand,
- Produktions-, Inventions-, Bestands- und Fehlmengenlisten,
- SDE-gebundene Inventionsmaterialmengen ohne Schätzung von Fehlversuchen,
- Wiederverwendung der P22–P24-Rechner für Filter, Schutz und Reservierung,
- schreibfreie Vorschau, ausdrückliche Bestätigung und Stale-State-Schutz,
- additive SwiftData-Persistenz in Schema v15,
- Backupformat 15.0.0 und Kompatibilität 1.0.0 bis 15.0.0,
- XcodeGen-Regeneration und Projektparitätsprüfung.

## Dateien

Neu:

- `Sources/NewEdenNexusDomain/BuildOrBuyPlan.swift`
- `Sources/NewEdenNexusApplication/BuildOrBuyPlanning.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV15.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataBuildOrBuyDecisionRepository.swift`
- drei P26-Testdateien
- `Documentation/BUILD_OR_BUY_PLANNING.md`
- `Documentation/Architecture/ADRs/ADR-0031_Build-or-Buy-und-Schema-v15.md`

Geändert wurden Migrations-/Container-/Backupverdrahtung,
Backupregressionstests, das generierte Xcode-Projekt und die verpflichtenden
Statusdokumente. Es wurden keine Dateien gelöscht oder verschoben und keine
Benutzeränderungen verworfen.

## Architektur- und Datenmodellentscheidungen

Nur **Kaufen** wird als Abweichung vom Standard **Bauen** gespeichert.
Entscheidungen sind projekt- und Type-ID-gebunden. Duplikate starten bewusst
ohne übernommene Entscheidung. Berechnungsergebnisse werden nicht
persistiert, sondern aus aktuellem Graph-, Lager-, Schutz-, Reservierungs-
und Entscheidungszustand reproduziert.

Schema v15 ergänzt ausschließlich `BuildOrBuyDecisionRecord`; die Migration
v14→v15 ist leichtgewichtig und erhält vorhandene Daten.

## Build und Tests

- `swift test -c debug --filter BuildOrBuy`: 11/11 bestanden,
- `swift test -c debug`: 434/434 bestanden, 0 übersprungen,
- Xcode Debug: 434/434 bestanden, 0 übersprungen,
- Xcode-Projektprüfung: 15 Targets, sieben Testtargets, zwei Schemes.

Der erste SwiftPM-Start wurde nur durch den gesperrten Modulcache der
Dateisandbox verhindert und außerhalb dieser Einschränkung erfolgreich
wiederholt. Ein inkonsistenter generierter `.build`-Cache wurde sicher
bereinigt. Signing- und Teamwerte wurden nicht geändert.

## Manuelle Prüfungen

Kein UI-/App-Smoke erforderlich: P26 ändert keine sichtbare Oberfläche.
Diff, Schema, Migration, Wiederöffnung, Backup, Xcode-/SwiftPM-Parität und
Projektstatus wurden kontrolliert.

## Bekannte Probleme und offene Anforderungen

- P32 muss den vorhandenen Plan sichtbar bedienen und Fehlmengen kopierbar
  machen.
- Preise, Kosten, Gewinn, Einkaufsstatus und CSV-Export bleiben gemäß
  PLAN-002 in P27–P31 verschoben.
- P36-Recovery und öffentlicher Release-Sign-off bleiben unverändert offen.
- Standardmäßig wird Invention ohne Decryptor geplant; keine
  Erfolgs-/Fehlversuchssimulation ist enthalten.

## Abweichungen vom Projektbuch

Der breite Build-or-Buy-Umfang wurde gemäß PLAN-002 auf manuelle
Bauen/Kaufen-Entscheidungen und berechnete Fehlmengen reduziert. Es wurden
keine Empfehlungen, Preise oder Optimierungen vorgezogen.

## Abnahmekriterien

Alle zehn P26-Kriterien sind erfüllt. T1/T2/Invention, exakter Kaufschnitt,
Bestands-/Schutz-/Reservierungsnetting, Persistenz, Duplikatstandard,
Migration, Leerstore, Wiederöffnung, Backup, Fehlerpfade, Builds, Tests und
Dokumentation sind nachgewiesen.

## Reviewentscheidung

Der getrennte Kontrollschritt fand zunächst Xcode-Projektdrift für die neuen
Quellen. Nach XcodeGen-Regeneration, erneuter Paritätsprüfung und grünem
Xcode-Debuglauf lautet die Entscheidung **✅ bestanden**. Kein durch P26
verursachter kritischer oder hoher Befund bleibt offen.

## Nächster Prompt

P32 – integrierten Kernworkspace ausführen. P37 bleibt danach die interne
Kernabnahme.
