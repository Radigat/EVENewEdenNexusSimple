# P51 – OAuth- und Keychain-Nachkorrektur

Status: ✅ einschließlich Eigentümer-Livenachweis bestanden

## Ziel und Ausgangszustand

Der P52-Eigentümerlauf zeigte HTTP 400 beim Token-Refresh, fehlenden
Owner-Contact und anschließend eine irreführende grüne Löschmeldung beim
Speichern eines leeren Kontaktfelds. Es waren keine Fachdaten übernommen
worden.

## Änderungen

- OAuth-Formwerte schützen reservierte Tokenzeichen einschließlich `+`, `/`
  und `=`.
- Sichere Fehlergründe bleiben auf einer nicht geheimen Allowlist.
- Fehlende und nicht lesbare Keychain-Einträge werden unterschieden.
- Owner-Contact-Schreiben und -Löschen werden durch unmittelbares Zurücklesen
  verifiziert.
- Kontakt-Erfolg oder -Fehler erscheint direkt an den Bedienelementen.
- Leere Eingaben lösen keine Löschung mehr aus; Entfernen besitzt eine eigene
  destruktive Aktion mit Bestätigung.
- Das Eingabefeld besitzt eine sichtbare Beschriftung, einen großen
  abgerundeten Rahmen und einen Beispielhinweis.
- Regressions- und Architekturtests wurden ergänzt.

## Daten- und Sicherheitswirkung

Keine Schemaänderung und keine Fachdatenübernahme. Kontakt- und Tokenwerte
wurden weder protokolliert noch dokumentiert. Vorhandene Benutzeränderungen
blieben erhalten; kein Commit oder Push.

## Prüfung

- SwiftPM Debug vor der visuellen Ergänzung: **639/639 Tests bestanden**.
- Fokussierte Kontakt-UX: **4/4 bestanden**.
- Ergänzter Architekturtest: **1/1 bestanden**.
- Eingeschränkter Vollauf nach der visuellen Ergänzung: **636/639**; die drei
  allein an Security.framework gescheiterten RSA-Schlüsseltests bestanden
  anschließend im vollständigen **10/10**-SSO-Lauf außerhalb der Sandbox.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64: **BUILD SUCCEEDED**,
  signierter lokaler Build.
- `git diff --check`: bestanden.

## Review

Technische Entscheidung: **✅ bestanden**. Die Korrektur ist eng auf den
nachgewiesenen Fehler begrenzt, verhindert implizites Löschen und verifiziert
den Keychain-Schreibpfad.

Gesamtentscheidung: **✅ bestanden**. Der Projekteigentümer bestätigte
Speichern, Wiedererkennen nach vollständigem Neustart, öffentlichen
Charakterabruf und sichtbaren fehlerfreien Refresh. OFF-040/KI-043 sind
geschlossen. Persönlicher Apply und Wallet-Inspect gehören getrennt zu
OFF-041/KI-044 in P52.

## Nächster Schritt

P52 ab dem manuellen Owner-Contact-Neustartnachweis fortsetzen. Weitere
private Vorschau- oder Schreibschritte benötigen weiterhin die im P52-Prompt
vorgesehenen unmittelbaren Eigentümerbestätigungen.
