# KI-063 – Budgetkosten-Beschriftungen

## Ziel und Ausgangszustand

Die beiden manuellen Felder im Projektbudget waren nur über verschwindende
Textfeld-Platzhalter als Logistik- und Produktionskosten erkennbar.

## Änderungen

- dauerhaft sichtbares Label `Logistikkosten` direkt vor dem ersten Betrag,
- dauerhaft sichtbares Label `Produktionskosten` direkt vor dem zweiten Betrag,
- eigene `ISK`-Einheit unmittelbar nach jedem Feld,
- Architekturregression schützt beide sichtbaren Labels,
- keine Datenmodell-, Persistenz- oder Berechnungsänderung.

Geändert wurden:

- `Sources/NewEdenNexus/ProductionWorkspaceView.swift`,
- `Tests/NewEdenNexusArchitectureTests/ProjectEconomicsArchitectureTests.swift`,
- betroffene kompakte Steuer- und Nachweisdokumentation.

## Build und Tests

- fokussierter Architekturtest: **1/1 bestanden**,
- SwiftPM Debug: **erfolgreich**,
- Apple-Development-signierter arm64-Xcode-Debugbuild: **BUILD SUCCEEDED**.

Der erste sandboxierte Xcode-Versuch konnte SwiftData-Makros und Signing nicht
korrekt verwenden. Der reguläre lokale Lauf außerhalb der Sandbox bestand;
Projekt-, Signing- und Teamkonfiguration wurden nicht verändert.

## Review und offene Punkte

Review: **✅ technisch bestanden**. Labels, Einheit und Accessibility sind
vorhanden; Budgetlogik und Datenwirkung bleiben unverändert.

Die sichtbare Bestätigung erfolgt im nächsten Eigentümerlauf. OFF-061 bleibt
als getrenntes P59-Eigentümergate in Bearbeitung; P60 beginnt nicht
automatisch.
