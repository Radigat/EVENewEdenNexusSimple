# Abschlussbericht – P07C: SDE-Einstellungen, Automation und Recht

Datum: 2026-07-23  
Prompt-ID: P07C  
Status: ⚠️ teilweise/blockiert  
Review: ⚠️ mit einer konkreten Einschränkung bestanden

## Ziel

P07A-Updatecheck und P07B-Installation produktiv in die App verdrahten,
benutzerkontrollierte Einstellungen und Automation, sichtbare Zustände,
Updatehistorie, bereinigten Diagnoseexport, sichere Retention und aktuelle
unabhängige Drittanbieterhinweise bereitstellen.

## Ausgangszustand

Metadatencheck, 24-Stunden-Policy, sicherer Realdownload, blockweiser Import,
Backup, Aktivierung, Rollback und Phasenjournal waren vorhanden. Es fehlten
produktive App-Composition, Startautomation, Bedienung, Kontaktablage,
Verlauf/Export, Retention-UI und Rechtshinweise. Das Repository besitzt
weiterhin keinen Commit und kein eigenständiges Xcode-Projekt; die parallel
eingetragenen P09A-/P09B-Planungsänderungen wurden erhalten.

## Durchgeführte Änderungen

- `SDEAppComposition` als einzige produktive Verdrahtungsgrenze ergänzt;
  das ViewModel importiert keine konkreten Netzwerk-, SwiftData- oder
  Dateiadapter.
- Nicht blockierenden Startcheck, langfristigen Scheduler, 24-Stunden-
  Mindestintervall und Schutz gegen doppelte Aufgaben ergänzt.
- Kontaktfreie Start-Recovery vor dem ersten Metadatencheck ergänzt;
  Recoveryfehler verhindern einen neuen Updatevorgang und bleiben
  diagnostizierbar.
- Sichere Automation mit getrennten Opt-ins für Download und Installation
  umgesetzt.
- User-Agent-Kontakt validiert und ausschließlich im Schlüsselbund
  gespeichert; kein realer Kontaktwert wurde in Code, Tests oder
  Dokumentation übernommen.
- Geprüften Archivcache mit Größe, SHA-256, privaten Rechten und
  Wiederverwendung ohne zweiten Download ergänzt.
- Phasenfortschritt und kontrollierten Abbruch bis zum
  Installationsservice weitergereicht.
- SDE-Status-, Einstellungs-, Log-, Export- und Retentionoberfläche sowie
  zentrale Navigation ergänzt.
- Diagnoseexport auf sichere strukturierte Felder begrenzt und vor dem
  Speichern als Vorschau dargestellt.
- Retentionvorschau mit exakten Buildnummern, veralteter-Bestätigung-Schutz
  und Erhalt von aktivem plus Rollbackstand umgesetzt.
- Rechtliche Ansicht mit unabhängiger Drittanbieterkennzeichnung,
  Eigentumshinweis, aktivem Build/Format und offiziellen Links ergänzt.
- Adapterbau beim Review aus dem ViewModel in die Composition Root
  verschoben.
- Fehler im Archivcache behoben: SHA-256 wird vor dem atomaren Verschieben
  der temporären Datei berechnet.

## Neu erstellte Dateien

- `Sources/NewEdenNexus/SDEAppComposition.swift`
- `Sources/NewEdenNexus/SDEAppConfiguration.swift`
- `Sources/NewEdenNexus/SDEDataManagementView.swift`
- `Sources/NewEdenNexus/SDELegalNoticesView.swift`
- `Sources/NewEdenNexus/SDEManagementViewModel.swift`
- `Sources/NewEdenNexusApplication/SDEManagement.swift`
- `Sources/NewEdenNexusInfrastructure/CachedSDEArchiveDownloader.swift`
- `Sources/NewEdenNexusInfrastructure/SDEArchiveRecoveryBoundary.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSDECatalogRetentionRepository.swift`
- `Tests/NewEdenNexusInfrastructureTests/SDEArchiveRecoveryBoundaryTests.swift`
- `Documentation/SDE_SETTINGS_AND_DIAGNOSTICS.md`
- `Documentation/Architecture/ADRs/ADR-0012_SDE-App-Composition-Automation-und-Retention.md`
- dieser Bericht

## Geänderte Dateien

- App-Navigation, App-Start, Runtime, Root- und Settings-Views,
- P07B-Installationsfortschritt und Dateijournal-Lesezugriff,
- Application-, Infrastructure-, Persistence- und App-Tests,
- alle verpflichtenden Status-, Test-, Architektur- und
  Compliance-Dokumente.

## Gelöschte oder verschobene Dateien

Keine.

## Architekturentscheidungen

Konkrete Adapter werden ausschließlich in `SDEAppComposition` erzeugt.
Das ViewModel kennt nur injizierte Operationen. Cache und Retention sind
eigene austauschbare Grenzen. Die UI dokumentiert eine persönliche
Bedingungsprüfung, akzeptiert jedoch keine Vereinbarung.

## Datenmodelländerungen

Keine neue SwiftData-Schemaversion. Automationseinstellungen liegen in
UserDefaults; der Kontakt liegt im Schlüsselbund. Das P07B-Dateijournal bleibt
unverändert. Retention löscht ausschließlich bestätigte statische
Katalogzeilen und zugehörige Versionen.

## Build-Ergebnis

- Debug-Build: erfolgreich,
- Release-Build: erfolgreich,
- keine Signing- oder Team-Einstellung geändert.

Die erste nicht eskalierte Ausführung scheiterte ausschließlich am nicht
beschreibbaren globalen Swift-Modulcache der Werkzeug-Sandbox. Die finalen
Prüfungen liefen mit freigegebenem Compilerzugriff und getrennten
Scratch-Verzeichnissen.

## Testergebnis

- Debug mit Coverage: 167 Tests, 0 Fehler,
- Release: 167 Tests, 0 Fehler,
- fünf Architekturgrenztests erfolgreich,
- keine übersprungenen XCTest-Tests,
- produktive Source-Zeilenabdeckung einschließlich SwiftUI:
  7509/11801 Zeilen, 63,63 %.

Ein Zwischenlauf fand einen echten Fehler im neuen Archivcache: Nach dem
Verschieben wurde noch die nicht mehr vorhandene temporäre Datei gehasht.
Nach der Korrektur bestanden zunächst beide Regressionstests und anschließend
die vollständigen Debug-/Release-Läufe.

Der Abschlussreview fand außerdem, dass die vorhandene
Installationswiederherstellung beim App-Start noch nicht verdrahtet war.
`SDEArchiveRecoveryBoundary` bereinigt nun vor dem ersten Check abgebrochene
Download-/Cacheartefakte, während der Installationsservice Journal, Import und
Staging konsistent bereinigt. Erfolgs- und Fehlerpfad sind getestet.

## Manuelle Prüfungen

Ein isoliertes temporäres Profil und ein temporäres App-Bundle wurden
erstellt. Der Prozess startete und erzeugte ausschließlich seinen temporären
SwiftData-Store. Im aktuellen SwiftPM-Stand stellte er jedoch kein über die
Desktop-Steuerung erreichbares Fenster bereit; Accessibility-Baum,
Tastaturbedienung, VoiceOver und datenschutzneutrale Screenshots konnten
deshalb nicht belastbar abgenommen werden.

Ein angezeigter Desktop-Screenshot enthielt private Dateinamen und wurde
bewusst nicht als Projektartefakt gespeichert. Produktive Benutzerdaten und
der reale Kontakt wurden nicht verwendet.

## Bekannte Probleme und offene Anforderungen

- `OFF-025` / `KI-025`: P09B muss nach Erstellung eines echten
  Xcode-App-Bundles den P07C-Fenster-/Tastatur-/VoiceOver-Smoke-Test mit
  datenschutzneutralen Screenshots wiederholen.
- Release-/Markenpflichten werden in P37 erneut gegen die dann aktuellen
  CCP-Bedingungen persönlich geprüft.
- Prozess-Kill-Recovery bleibt P36; große P07B-Dateien bleiben P34.

## Abweichungen vom Projektbuch

Keine fachliche Scope-Erweiterung. WLAN-only wurde sichtbar begründet nicht
angeboten, weil die Zielplattform dafür keine verlässliche Sicherheitsgrenze
liefert. Die App importiert weiterhin nur fachlich benötigte SDE-Datensätze.

## Abnahmekriterien

Erfüllt:

- produktive P07A-/P07B-Composition,
- Startautomation, sichere Defaults, Drossel und Parallelitätsschutz,
- Status, Fortschritt, Abbruch, Verlauf und bereinigter Export,
- Keychain-Kontakt und Bedingungen-Gate,
- bestätigte Retention mit Bestandsschutz,
- aktuelle Rechtshinweise und offizielle Links,
- Debug-/Release-Build und alle Tests.

Nicht erfüllt:

- dokumentierter manueller Funktions- und Accessibility-Smoke-Test mit
  datenschutzneutralen Screenshots.

P07C wird deshalb nicht auf `✅` gesetzt.

## Reviewentscheidung

⚠️ mit Einschränkung bestanden. Quellcode, Schichtengrenzen,
Sicherheitsdefaults, Cache, Retention, Redaction, Builds, Tests und
Dokumentation sind konsistent. Der manuelle GUI-Nachweis bleibt ein
konkretes Gate für P09B und anschließend für den endgültigen P07C-/P37-
Status.

## Nächster empfohlener Prompt

P09A – Repository-Baseline und Git-Nachvollziehbarkeit. Danach P09B mit
verbindlicher Wiederholung des offenen P07C-UI-Smoke-Tests; erst anschließend
P10.
