# OFF-061 – Vorbereitung Wallet-Nachweise

Datum: 2026-07-29  
Status: ⚠️ teilweise

## Ziel und Ausgangszustand

Nach Schließung von KI-060 den sichtbaren Eigentümerlauf für Teilzuordnung,
Verwerfen, Gebühr, Vollzuordnung und Neustart vorbereiten.

Die produktive Datenbank wurde ausschließlich lesend geprüft:

- 1 Produktionscharge,
- 0 bestätigte Chargenkostenbasen,
- 0 Wallet-Projektzuordnungen,
- 0 Verkaufszuordnungen.

Die vorhandene Charge besitzt nur 1 Output-Unit. Damit wäre weder eine echte
Teilzuordnung noch die vollständige OFF-061-Folge ohne vorherige bestätigte
Ausgangsdaten möglich.

## Ergänzende Diagnose vom 2026-07-30

Die vorhandene Charge `2026-0001` ist an den Rhea-Projektstand vom
29.07.2026 um 19:22 und den Graphstand um 19:25 gebunden. Der aktuelle
Rhea-Projektstand stammt von 21:45, der aktuelle Graph von 21:37. Die
Stale-Sperre verhindert daher korrekt, dass die historische Charge mit
nachträglich geänderten Materialien und Mengen bewertet wird.

Für OFF-061 ist folglich zuerst ein aktueller Projekt-/Graphstand mit
Zielmenge 2, anschließend eine neue Charge mit 2 Output-Units und erst danach
die Kostenbasis zu bestätigen. Die historische Charge wird nicht verändert.

Die App erklärt diesen Fall im aktuellen Build nun ausdrücklich und verweist
auf die neue Charge aus aktuellem Projekt, Graph und Budget. Die
Stale-Sperre selbst wurde nicht gelockert.

## Ergänzende Graphkorrektur vom 2026-07-30

Beim Erzeugen des aktuellen Graphstands trat `NEN-GRAPH-001` auf. Die
Reproduktion auf einer temporären Kopie des Xcode-Laufstores zeigte keine
Projekt- oder SDE-Versionsabweichung, sondern einen unveröffentlichten
Test-Blueprint neben der eindeutigen veröffentlichten Reaktionsformel.
KI-062 korrigiert die implizite Resolverauswahl, ohne echte Mehrdeutigkeiten
oder explizite Blueprint-Prüfungen zu lockern.

Der reale kopierte Datenstand erzeugt danach 566 Knoten und 565 Kanten.
44/44 fokussierte Tests und der Apple-Development-signierte
arm64-Xcode-Debugbuild bestehen. Vor Fortsetzung von OFF-061 bleibt nur der
sichtbare Graph-Retest im neu gestarteten Xcode-Lauf.

## Eigentümernachweis vom 2026-07-30

Der Projekteigentümer hat eine Wallet-Verkaufstransaktion nach sichtbarer
Prüfung bereits verbindlich dem Projekt `Module für DOC`
(`Multispectrum Shield Hardener II`) zugeordnet. Der aktuelle Xcode-Lauf
verwendet dabei wie vorgesehen das isolierte
`.build/P09BXcodeRunHome`-Profil.

Die anschließende rein lesende Kontrolle bestätigt:

- eine Projekt-Walletzuordnung der Richtung `revenue`,
- bestätigte Menge `1`,
- noch keine Produktionscharge in diesem Laufprofil,
- noch keine Chargenkostenbasis,
- noch keine chargengebundene Verkaufs- oder Gebührenzuordnung.

Die versehentlich vorgezogene Bestätigung ist daher ein verwertbarer
OFF-061-Quellnachweis, aber weder eine Chargenbuchung noch ein vollständiger
Verkaufsnachweis. Sie darf nicht erneut bestätigt und nicht ohne passende
aktuelle Charge verwendet werden.

## Durchgeführte Änderungen

- In **Accounts & Charaktere** erscheint bei vorhandenem Wallet-Snapshot die
  Aktion **Wallet-Nachweise zuordnen**.
- Der Dialog verwendet den vorhandenen P42-Vorschau-/Bestätigungsvertrag für
  Wallettransaktionen und zuordenbare Journalgebühren.
- Die durch P55 zurückgezogene alte Projektfinanzen-/Plan-Ist-Oberfläche wurde
  nicht wieder eingeführt.
- Ein Architekturtest schützt diese Oberflächengrenze.

## Build und Tests

- 19/19 fokussierte Architektur-, Walletzuordnungs- und
  P59-Verkaufszuordnungstests bestanden.
- Apple-Development-signierter arm64-Xcode-Debugbuild: `BUILD SUCCEEDED`.
- `codesign --verify --deep --strict --verbose=2`: gültig; Identifier
  `com.newedennexus.local.NewEdenNexus`, Team `99K5WATB4A`.
- Die vollständige 713er-Suite wurde für diese kleine UI-Verdrahtung nicht
  erneut ausgeführt; ihr unveränderter P59-Nachweis bleibt gültig.
- Ergänzende Stale-Diagnose: 2/2 fokussierte Kosten-/Architekturtests und
  erneut Apple-Development-signierter Xcode-Debugbuild bestanden.

## Review

Technische Vorbereitung: ✅ bestanden.  
OFF-061 insgesamt: ⚠️ teilweise, weil die folgenden Eigentümerhandlungen noch
ausstehen:

1. Projekt duplizieren oder bewusst auf Zielmenge 2 bringen, aktuellen Graph
   und Budgetstand erzeugen und daraus eine neue Charge mit 2 Output-Units
   sowie bestätigter P58-Kostenbasis vorbereiten.
2. Wallet-Verkaufstransaktion ist bestätigt; eine zuordenbare
   Gebührenbuchung nach sichtbarer Vorschau einem Projekt bestätigen.
3. Verkauf teilweise speichern.
4. zweite Verkaufsvorschau verwerfen und unveränderten Stand prüfen.
5. Gebühr speichern und anschließend vollständig zuordnen.
6. App vollständig beenden, neu starten und Restmengen sowie Realgewinn
   unverändert prüfen.

Es wurden keine produktiven Wallet-, Kosten- oder Verkaufswerte erfunden oder
automatisch bestätigt. Kein Commit und kein Push wurden ausgeführt.

## Nächster Schritt

OFF-061 mit dem Projekteigentümer im sichtbaren aktuellen Build durchführen.
P60 beginnt anschließend nur auf ausdrücklichen Auftrag.
