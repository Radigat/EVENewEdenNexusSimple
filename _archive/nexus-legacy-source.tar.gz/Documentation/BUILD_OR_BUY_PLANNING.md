# Build-or-Buy-Planung

Stand: 2026-07-29 · P26/P56

## Zweck und Grenze

P26 verbindet den validierten Produktionsgraphen mit Lager,
Sicherheitsbeständen und Projektreservierungen. Jede produzierbare
Zwischenstufe verwendet standardmäßig **Bauen**; projektbezogen gespeicherte
**Kaufen**-Entscheidungen schneiden genau deren Unterbaum ab.

Nicht enthalten sind Empfehlungen, Preise, Kosten, Gewinn, Einkaufsstatus,
CSV-Export, Slots oder Optimierung.

## Berechnungsfolge

1. Projekt und aktueller Graph werden geladen und auf Frische geprüft.
2. Inventionsmaterialmengen werden aus dem versionsgleichen SDE-Rezept
   gelesen; unbekannte oder widersprüchliche Daten blockieren.
3. P22-Lagerfilter, P23-Sicherheitsbestand und fremde P24-Reservierungen
   bestimmen je Type-ID den verfügbaren Pool.
4. Der Graph wird stabil nach Kantenreihenfolge durchlaufen. Bestand wird je
   Type-ID genau einmal verbraucht.
5. Voll oder teilweise vorhandene Zwischenprodukte reduzieren Runs und
   damit ihre Unterkette.
6. **Kaufen** beendet die verbleibende Unterkette; **Bauen** berechnet Runs
   und Materialien mit den vorhandenen T1-/T2-/Reaktionsregeln neu.
7. Produktionsjobs, Inventionsjobs, Bestandsverwendung und Fehlmengen
   werden getrennt ausgegeben.

Die Inventionsplanung multipliziert SDE-Materialmengen mit den benötigten
erfolgreichen BPCs. Sie simuliert keine Fehlversuche und behauptet keine
garantierte Erfolgswahrscheinlichkeit.

## Entscheidungen und Datenintegrität

- Der Workspace projiziert herstellbare Stufen nach den bereits gespeicherten
  Rezeptmerkmalen als **Produktion**, **T2 und Invention**,
  **Biochemical Reactions**, **Composite Reactions** oder
  **Hybrid Polymer Reactions**.
- Reaktionsuntergruppen stammen ausschließlich aus `reactionKind`. Fehlt der
  Wert, bleibt die Stufe als **Unklassifizierte Reaktionen** sichtbar.
- Die Produktionsart kann gefiltert werden, ohne den Entwurf zu verändern.
- **Alles bauen** und **Alles kaufen** ändern den vollständigen Entwurf.
- **Alle bauen** und **Alle kaufen** ändern jeweils den Entwurf der ganzen
  Gruppe. Einzelne Abweichungen bleiben aufklappbar.
- Widersprüchliche Zuordnungen derselben Type-ID werden nicht geraten,
  sondern als **Weitere Produktionsstufen** sichtbar gehalten.
- Gespeichert werden nur Abweichungen vom Standard **Bauen**.
- Schlüssel sind Projekt-ID und stabile CCP-Type-ID; Namen sind keine
  Schlüssel.
- Vorschau und gespeicherter Source-State umfassen Projekt, Graph,
  Lagerkonfiguration, Lagerstände, Schutzregeln, Reservierungen und
  Entscheidungen.
- Schreiben erfordert ausdrückliche Bestätigung und eine unveränderte
  Versionsbasis.
- Veraltete Type-IDs bleiben sichtbar und blockieren, bis der Benutzer eine
  bereinigte vollständige Vorschau erzeugt.
- Ein dupliziertes Projekt startet bewusst ohne übernommene Entscheidungen
  mit Standard **Bauen**.

## Persistenz

Schema v15 ergänzt additiv `BuildOrBuyDecisionRecord`. Die Migration
v14→v15 erhält Projekte, Graphen, Lager, Regeln und Reservierungen.
Backupformat 15.0.0 akzeptiert weiterhin die Formate 1.0.0 bis 14.0.0 zur
kontrollierten Migrationswiederherstellung.

## UI-Grenze

P26 stellt Domain-, Application- und Persistenz-APIs bereit. P32 ergänzt die
sichtbare Bedienung, Joblisten und kopierbare Fehlmengenliste. P56 ergänzt
ausschließlich eine gefilterte, gruppierte Präsentations- und
Entwurfssteuerung; der zentrale Plan, Vorschau, Bestätigung und
Persistenzvertrag bleiben unverändert.
