# Architektur

Stand: 2026-07-25 · P28 abgeschlossen und reviewed

## 1. Zweck und Scope

Diese Datei beschreibt die tatsächlich implementierte Architekturgrundlage des
reduzierten Produktionsplaner-MVP. Sie ist kein Nachweis für fachliche
Funktionen, die erst in P10 bis P37 entstehen.

Verbindlich bleiben:

- Local First und Offline First,
- deterministischer, UI-unabhängiger Fachkern,
- Abhängigkeiten von außen nach innen,
- konkrete Adapter hinter Application-Ports,
- versionierte Persistenzänderungen,
- keine MVP-Abhängigkeit von SSO, ESI oder Live-Daten.

## 2. Ausgangsarchitektur vor P02

Vor P02 bestand das Package aus einem ausführbaren Target und einem Testtarget:

```text
NewEdenNexus
├── SwiftUI
├── SwiftData-Modelle und direkte View-Zugriffe
├── SSO / Network / Keychain
└── PythonEngine ──> /usr/bin/env python3 ──> material_engine.py

NewEdenNexusTests ──> NewEdenNexus
```

Fachtypen, Prozessadapter, UI und Persistenz waren im selben Target gekoppelt. Die Materialaggregation war nur über einen externen Python-Prozess erreichbar.

## 3. Implementierter Targetgraph

```text
NewEdenNexus (Executable; Presentation und Composition Root)
    ├──> NewEdenNexusInfrastructure
    │         ├──> NewEdenNexusApplication
    │         └──> NewEdenNexusDomain
    ├──> NewEdenNexusPersistence
    │         ├──> NewEdenNexusApplication
    │         └──> NewEdenNexusDomain
    ├──> NewEdenNexusApplication ──> NewEdenNexusDomain
    └──> NewEdenNexusDomain

NewEdenNexusTests
    └──> App + Domain + Application + Infrastructure + Persistence

NewEdenNexusTestSupport
    └──> Domain; nur für Testtargets, kein Produkt

NewEdenNexusTestSupportTests
    └──> TestSupport + Domain

NewEdenNexusDomainTests
    └──> Domain + TestSupport

NewEdenNexusApplicationTests
    └──> Application

NewEdenNexusInfrastructureTests
    └──> Application + Infrastructure + TestSupport

NewEdenNexusArchitectureTests
    └──> Domain + Application + Persistence

NewEdenNexusPersistenceTests
    └──> Domain + Application + Infrastructure + Persistence + Legacy-Testfixture + TestSupport
```

SwiftPM verhindert nicht deklarierte Targetabhängigkeiten bereits beim Kompilieren. Zusätzliche Architekturtests prüfen verbotene Frameworkimporte in Domain und Application.

Seit P09B beschreibt `project.yml` dieselben 15 Targets für das
eigenständige, eingecheckte `NewEdenNexus.xcodeproj`. Zwei gemeinsame Schemes
stellen App und opt-in SDE-Abnahmerunner bereit; das App-Scheme enthält alle
sieben Testtargets. `Scripts/verify_xcode_project.py` prüft Target-, Quellen-,
Fixture- und Scheme-Parität sowie den Ausschluss persönlicher Xcode- und
Signing-Metadaten. Details und Folgen stehen in
[ADR-0013](Architecture/ADRs/ADR-0013_Xcode-Projekt-und-SwiftPM-Paritaet.md).

## 4. Targets und Verantwortungen

| Target | Pfad | Verantwortung | Erlaubte interne Abhängigkeiten |
|---|---|---|---|
| `NewEdenNexusDomain` | `Sources/NewEdenNexusDomain` | reine Typen, Regeln und deterministische Berechnungen | keine |
| `NewEdenNexusApplication` | `Sources/NewEdenNexusApplication` | Use Cases und Ports | Domain |
| `NewEdenNexusInfrastructure` | `Sources/NewEdenNexusInfrastructure` | konkrete technische Adapter | Application, Domain |
| `NewEdenNexusPersistence` | `Sources/NewEdenNexusPersistence` | SwiftData-Modelle, Versionen, Migration, Container und Repositories | Application, Domain |
| `NewEdenNexus` | `Sources/NewEdenNexus` | SwiftUI, Future-Code und konkrete Composition Root | Domain, Application, Infrastructure, Persistence |
| `NewEdenNexusSDEAcceptance` | `Sources/NewEdenNexusSDEAcceptance` | ausschließlich opt-in: isolierter offizieller SDE-End-to-End-Abnahmerunner ohne App-Startverdrahtung | Application, Infrastructure, Persistence |
| `NewEdenNexusTestSupport` | `Tests/NewEdenNexusTestSupport` | versionierte synthetische Fixtures, Builder und temporäre Testpfade; kein Produkt | Domain |

### Domain

Aktuell enthalten:

- `MaterialLine`,
- `MaterialSummary`,
- `MaterialAggregationError`,
- `MaterialSummaryCalculator`,
- `ProjectStatus`,
- `ProductionProjectSnapshot`,
- `ProductionProjectValidationError`.

Die Domain importiert ausschließlich Foundation. SwiftUI, SwiftData, AppKit, Network und Security sind verboten.

### Application

Aktuell enthalten:

- Port `MaterialSummarizing`,
- Use Case `SummarizeMaterialsUseCase`,
- Port `ProductionProjectRepository`,
- Port `LocalBackupManaging` mit Backup-/Restore-Vertrag,
- Port `SDEImporting` mit Vorschau-, Snapshot-, Fortschritts- und Stagingtypen,
- Ports `StaticDataCatalogMapping` und `StaticDataCatalogStoring`,
- `ImportStaticDataUseCase` und validierte statische Snapshots,
- `SDEUpdateService` sowie Ports für Metadatenprüfung, aktive Version,
  Prüfstatus, Zeit, HTTP-Transport, Backoff und Jitter,
- `SDEInstallationService`, Automationspolicy, Fortschritts-, Cache-,
  Loglese-, Diagnoseexport- und Retentionverträge,
- `NexusFailure`, `NexusFailureMapper` und sichere Fehlercodes,
- `DiagnosticEvent`, Redaktionswerte und `DiagnosticLogging`,
- `ProductionProjectLifecycleService`, Statuspolicy, Draft, Listenscope und
  typisierte Lebenszyklusfehler,
- `PriceProfileManagementService` und `PriceProfileRepository` für exakte
  manuelle ISK-Preise, Gültigkeit und fehlende Werte,
- `PriceCSVImportService` für schreibfreie Vorschau, Konfliktentscheidungen
  und atomaren Preis-/Berichtscommit.

Application kennt nur Domain. Konkrete Adapter und UI-Typen sind verboten.

### P32-Workspace-Grenze

Der integrierte Produktionsworkspace bleibt eine reine
Presentation-/Composition-Erweiterung:

```text
ProductionWorkspaceView
        │
        ▼
BuildOrBuyWorkspaceViewModel
        │ BuildOrBuyPlanning
        ▼
BuildOrBuyPlanningService
        │ Ports
        ▼
SwiftData-Repositories in ProjectAppComposition
```

Der Workspace berechnet keine Mengen neu. Er stellt den reproduzierbaren
P26-Snapshot dar, verwaltet schreibfreie Entwürfe und ruft die bestätigte
Application-Operation auf. Dashboard, Projekt-, Graph- und Workspace-UI sind
ohne `@Query` und `modelContext`; die Character-/SSO-Views wurden in P38
über Application-Ports und ViewModels entkoppelt. Siehe
[ADR-0032](Architecture/ADRs/ADR-0032_Integrierter-Produktionsworkspace.md).

### P27-Preisgrenze

`PriceProfileView` und `PriceProfileViewModel` hängen ausschließlich an
`PriceProfileManaging`. Die Composition Root verdrahtet den
`SwiftDataPriceProfileRepository`; Views importieren kein SwiftData.
Preisprofile sind von Projekten und Build-or-Buy getrennt. Kostenberechnung
bleibt P29.

P28 verwendet dieselbe geprüfte CSV-Transportgrenze wie P21. Das
preisfachliche Mapping und die Validierung liegen in Application; die
SwiftUI-Ansicht kennt weder SwiftData noch Dateipfade. Ein Importbericht
wird nur zusammen mit den bestätigten Mutationen gespeichert.

### Infrastructure

Aktuell enthalten:

- `NativeMaterialSummaryService` als Swift-nativer Adapter des Application-Ports,
- `UnifiedDiagnosticLogger` als Adapter auf Apples Unified Logging,
- `JSONLinesSDEImportService` für blockweise SDE-Prüfung, SHA-256 und atomare `.nensde`-Veröffentlichung.
- `JSONLinesSDECatalogMapper` für Manifestprüfung, Feldmapping und Referenzklassifizierung.
- `CCPSDEMetadataClient` und `URLSessionSDEHTTPTransport` für feste offizielle
  Metadatenressourcen, Validatoren, Cache-Control, Timeout und begrenzte
  Retries.
- `CachedSDEArchiveDownloader` für privaten, größen- und
  SHA-256-geprüften Vorabdownload.
- `SDEArchiveRecoveryBoundary` für kontaktfreies, auf die konkrete
  Vorgangs-ID begrenztes Cleanup beim App-Start.

Die Adapter sind `Sendable`; der SDE-Dateiadapter ist als Actor isoliert. Infrastructure enthält weder SwiftUI noch SwiftData, AppKit, Network oder Security.

### Persistence

Aktuell enthalten:

- `NexusLegacySchema` 0.9.0,
- `NexusSchemaV1` 1.0.0,
- `NexusSchemaV2` 2.0.0 mit versioniertem statischem Katalog,
- `NexusSchemaV3` 3.0.0 mit persistentem normalisiertem Item-Suchschlüssel,
- `NexusSchemaV4` 4.0.0 mit persistentem SDE-Prüfstatus,
- additive Schemata bis `NexusSchemaV17` mit Produktions-, Bestands-,
  Build-or-Buy-, Preisprofil- und Preisimportdaten,
- `NexusMigrationPlan`,
- `NexusModelContainerFactory`,
- `SwiftDataProductionProjectRepository`,
- `SwiftDataStaticDataCatalogRepository`,
- `SwiftDataItemBlueprintCatalog`,
- `SwiftDataSDEUpdateStateRepository`,
- `SwiftDataSDECatalogRetentionRepository`,
- `SQLiteLocalBackupService` und technische SQLite-Snapshotprüfung.

Persistence importiert SwiftData, aber kein SwiftUI, AppKit, Network oder
Security. Details stehen in [DATA_MODEL.md](DATA_MODEL.md),
[ADR-0003](Architecture/ADRs/ADR-0003_SwiftData-Schema-v1-und-Persistenzgrenze.md)
und [ADR-0034](Architecture/ADRs/ADR-0034_Atomarer-CSV-Preisimport-und-Schema-v17.md).

### Presentation und Composition Root

Der ausführbare Target enthält die vorhandenen SwiftUI-Views.
`NexusAppRuntime` erhält den konkreten Logger und die
SwiftData-Containerfactory am App-Einstieg. Sie bildet Startzustand und
zentrale Laufzeitfehler ab. Der `ModelContainer` wird nur nach erfolgreichem
Öffnen an die Views übergeben.

`SDEAppComposition` erzeugt danach Metadatenclient, Update- und
Installationsservice, Cache, Logstore und SwiftData-Repositories.
`SDEManagementViewModel` erhält ausschließlich injizierte Operationen und
importiert weder SwiftData noch konkrete Infrastructure-/Persistence-Typen.
Die App bereinigt zuerst abgebrochene Installationsartefakte und startet nur
bei erfolgreicher Recovery den mindestens 24-stündig gedrosselten Check
nicht blockierend.

`ProjectAppComposition` erzeugt
`SwiftDataProductionProjectRepository`,
`ProductionProjectLifecycleService` und `ProjectLifecycleViewModel`.
`ProjectsView` kennt dadurch weder SwiftData noch `@Query` oder
`modelContext`. Status-, Duplikat-, Archiv- und Restorefachregeln bleiben in
Application; das `@MainActor`-ViewModel koordiniert UI-Zustand und
asynchrone Aktionen.

`NexusModelContainerFactory` verwendet seit OFF-026 den app-spezifischen
Standardpfad
`~/Library/Application Support/NewEdenNexus/NewEdenNexus.store`. Einen
vorhandenen generischen `default.store` klassifiziert sie ausschließlich
lesend. Nur die vollständige New-Eden-Nexus-Signatur wird am bisherigen Ort
weiterverwendet; fremde Stores bleiben unangetastet, unlesbare Stores
scheitern weiterhin sicher. Für echte Smoke-Tests kann der Composition Root
über ein ausschließlich testbestimmtes Startargument eine absolute
Store-URL erhalten. Details:
[ADR-0016](Architecture/ADRs/ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md).

Die Materialaggregation besitzt noch keinen produktiven UI-Aufrufer; deshalb wird kein ungenutzter Environment-Wert oder Scheindependency-Container angelegt. Der Integrations-Regressionstest bildet die Composition des vorhandenen Pfads nach.

Backup besitzt noch keine produktive View-Anbindung. SDE-Updatecheck,
Installation, Status, Verlauf, Diagnoseexport, Retention und Rechtsansicht
sind seit P07C produktiv verdrahtet. P09B hat den tatsächlichen App-Bundle-
Start, SDE- und Rechtsansicht, den Tastaturkurzbefehl und VoiceOver mit
isoliertem Profil manuell geprüft. P09 stellt den read-only Katalogport
bereit, P10 die fachliche Rezeptauflösung und P12 die sichtbare,
kataloggebundene Produktauswahl.

## 5. Buildbeschreibungen und gemeinsame Schemes

`Package.swift` und `NewEdenNexus.xcodeproj` referenzieren dieselben Quellen
unter `Sources/` und `Tests/`. Es existiert keine zweite Implementierung.

- `Package.swift` bleibt der providerneutrale SwiftPM-Weg.
- `project.yml` ist die reproduzierbare XcodeGen-Beschreibung.
- `NewEdenNexus.xcodeproj` ist die versionierte Xcode-Baseline.
- `NewEdenNexus` ist das gemeinsame App- und Test-Scheme.
- `NewEdenNexusSDEAcceptance` baut nur den opt-in Runner; ein realer
  SDE-Download wird dadurch nicht gestartet.
- explizite temporäre Storepfade schützen produktive Benutzerdaten bei
  Teststarts; File-Provider-/Workspacepfade sind dafür nicht vorgesehen.
- CLI-Builds verwenden `CODE_SIGNING_ALLOWED=NO`; Team- und Releasewerte
  bleiben ungesetzt.
- lokale interaktive SSO-Builds binden
  `XcodeSupport/AppSigning.xcconfig` ein; persönliche Apple-Development-
  Werte liegen ausschließlich in der git-ignorierten
  `LocalSigning.xcconfig`.

Die Fixture-Ressourcen liegen weiterhin ausschließlich unter
`Tests/NewEdenNexusTestSupport/Fixtures`. SwiftPM erzeugt dafür
`Bundle.module`; Xcode erhält denselben Zugriff durch einen eng begrenzten,
nur außerhalb von SwiftPM kompilierten Bundle-Marker unter `XcodeSupport/`.

## 6. Verbindliche Abhängigkeitsregeln

1. Domain hängt von keinem anderen Projekttarget ab.
2. Domain enthält keine UI-, Persistenz-, Netzwerk-, Security- oder Prozesszugriffe.
3. Application hängt nur von Domain ab.
4. Infrastructure implementiert Application-Ports und darf keine SwiftUI-Views enthalten.
5. Presentation ruft Fachlogik nur über Application-Use-Cases auf.
6. Konkrete Adapter werden am äußeren Rand zusammengesetzt.
7. Zukunftscode darf keine Abhängigkeit des MVP-Fachkerns werden.
8. Neue Targets benötigen echten verwendeten Inhalt; leere Architekturmarker sind unzulässig.
9. Persistente Modelle werden nicht ungeprüft als Domänenmodelle verwendet.
10. Abweichungen benötigen ein ADR.

## 7. Materialaggregationsfluss

```text
Aufrufer
  └──> SummarizeMaterialsUseCase
          └──> MaterialSummarizing
                  └──> NativeMaterialSummaryService
                          └──> MaterialSummaryCalculator
```

Der Calculator:

- validiert Type-ID, Namen und endliche Preise,
- klemmt negative Mengen wie der vorherige Python-Pfad auf null,
- gruppiert nach Type-ID,
- übernimmt Name und Preis des ersten Eintrags einer Type-ID,
- sortiert deterministisch nach normalisiertem Namen und Type-ID,
- rundet Preise und Gesamtkosten kaufmännisch auf zwei Stellen.

Der P02-Paritätstest schützt die beobachtete Semantik des vorherigen Python-Skripts. Vollständige Produktions-, Preis- und Kostenregeln entstehen erst in späteren Fachprompts.

## 8. Python-Entscheidung

Die Python-Prozessgrenze wurde durch eine native Swift-Implementierung ersetzt. Entfernt wurden:

- `Sources/NewEdenNexus/PythonEngine.swift`,
- `Sources/NewEdenNexus/Resources/Python/material_engine.py`,
- die ungenutzte Einstellung `python.executable`.

Gründe und Alternativen stehen in [ADR-0002](Architecture/ADRs/ADR-0002_Berechnungsruntime-Python-oder-Swift.md). Der Ersatz ist durch Paritäts-, Leer-, Fehler-, Determinismus- und Integrationstests abgesichert.

## 9. SwiftData und Repository-Grenze

`CharacterRecord` und `ProductionProject` leben seit P03 in
`NewEdenNexusPersistence`. Der aktuelle Stand ist `NexusSchemaV3` 3.0.0;
Migrationen 0.9.0 → 1.0.0 → 2.0.0 → 3.0.0 sind registriert und getestet.

Der Übergang ist durch einen dateibasierten Legacy-Migrationstest mit vollständigem Wertevergleich und zweiter Öffnung belegt.

Der statische Katalog wird unter dem SDE-Inhalts-SHA unveränderlich
versioniert. Eindeutige zusammengesetzte Schlüssel unterstützen exakte
Lookups. Die Aktivierung speichert alle neuen Datensätze und den Aktivmarker
mit einem Save; frühere Stände bleiben als Rückfallversion erhalten.

Der P09-Katalog liest ausschließlich die aktive Version über einen
Application-Port. `searchName` wird in Schema v3 persistent normalisiert;
exakte und begrenzte Abfragen bleiben im Persistence-Adapter.

Für Produktionsprojekte existieren:

- `ProductionProjectSnapshot` in Domain,
- `ProductionProjectRepository` in Application,
- `SwiftDataProductionProjectRepository` in Persistence.

Die P38-Kontogrenze verwendet `EVECharacterAccount` als Application-Modell.
Views kennen weder SwiftData-Modelle noch Keychain-APIs. Da SwiftData und
Keychain keine gemeinsame Transaktion bilden können, stellt
`EVEAccountConnectionService` bei Teilfehlern den vorherigen Stand
kompensierend wieder her.

## 10. Zukunftscode

P38 teilt den SSO-Zukunftscode physisch:

- Application definiert Auth-, Callback-, Browser-, Token-Vault-,
  Account-Repository- und Account-Management-Ports,
- Infrastructure implementiert URLSession/OIDC, Network-Loopback,
  Security/JWT und Keychain,
- Persistence implementiert den `CharacterRecord`-Adapter,
- das App-Target verdrahtet diese Adapter und stellt ausschließlich
  ViewModels dar.

Domain und Application importieren weiterhin weder SwiftUI, AppKit, Network
noch Security. ESI-Fachdaten bleiben P39/P40. Details:
[SSO-Architektur](SSO_ARCHITECTURE.md) und
[ADR-0043](Architecture/ADRs/ADR-0043_SSO-Ports-JWT-und-Kompensation.md).

## 11. Persistenz-Zielbereich

Der Persistence-Target ist implementiert:

```text
NewEdenNexusPersistence ──> NewEdenNexusApplication + NewEdenNexusDomain
NewEdenNexus ─────────────> NewEdenNexusPersistence
```

Neue Persistenzzugriffe müssen über Application-Ports erfolgen. Bestehende direkte SwiftData-Zugriffe werden in den jeweils zuständigen Fachprompts migriert; P03 verändert ihren sichtbaren Workflow nicht.

## 12. Architekturprüfungen

`NewEdenNexusArchitectureTests` prüft:

- keine verbotenen Frameworkimporte in Domain,
- keine UI- oder konkreten Adapterimporte in Application,
- keine UI- oder Persistenzframeworkimporte in Infrastructure,
- keine UI-, Netzwerk- oder Security-Importe in Persistence,
- Application-Vertrag ist mit einem Stub ohne Infrastructure verwendbar.

Die Testpfade werden aus `#filePath` zur Laufzeit abgeleitet und enthalten keine benutzerspezifischen absoluten Pfade.

## 13. Fehler- und Diagnosegrenze

```text
Fehler
  └──> NexusFailureMapper
          ├──> NexusFailure ──> NexusAppRuntime ──> sichere SwiftUI-Darstellung
          └──> DiagnosticEvent ──> DiagnosticLogging
                                      └──> UnifiedDiagnosticLogger ──> OSLog
```

Application kennt weder SwiftUI noch OSLog. Infrastructure rendert ausschließlich die bereits redigierte Ereignisdarstellung. App-Startfehler erzeugen keinen Ersatzstore; die Runtime bietet einen erneuten Versuch über dieselbe Factory.

P33 ergänzt UI-unabhängige Validierungsprobleme mit stabilen Codes und eine
geschlossene Positivliste für benutzerinitiierte Retries. Nur idempotente
Lese-/Inspect-/Previewoperationen dürfen eine Retry-Closure an die Runtime
übergeben; sie wird vor einmaliger Ausführung entfernt. Schreiboperationen
bleiben ausgeschlossen.

Details: [Fehlerbehandlung und Logging](ERROR_HANDLING_AND_LOGGING.md), [ADR-0004](Architecture/ADRs/ADR-0004_Zentrale-Fehler-und-Diagnosegrenze.md), [ADR-0038](Architecture/ADRs/ADR-0038_Sichere-Validierung-und-kontrollierter-UI-Retry.md).

## 14. Testfundament

`NewEdenNexusTestSupport` ist ein eigenständiger, nicht als Produkt exportierter SwiftPM-Target. Nur Testtargets deklarieren ihn als Abhängigkeit. Das eingebettete Referenzpaket wird offline aus `Bundle.module` geladen und gegen Datensatz- und Schemaversion geprüft.

Die eingecheckten Fixture-Versionen sind ausdrücklich synthetisch. P08
erweitert sie um Manufacturing, Invention und Reaktion. Ein zusätzlich
konfigurierbarer Integrationstest wurde mit dem offiziellen Build 3424810
ausgeführt; dessen Daten lagen nur temporär außerhalb des Repositorys.
Temporäre SwiftData-Stores und SDE-Arbeitsverzeichnisse werden entfernt.

Details: [Teststrategie](TEST_STRATEGY.md), [ADR-0005](Architecture/ADRs/ADR-0005_Testfundament-und-versionierte-Referenzdaten.md).

## 15. Backup- und SDE-Dateigrenzen

`LocalBackupManaging` wird in Persistence durch `SQLiteLocalBackupService` umgesetzt. Das versionierte `.nenbackup`-Paket, Vorschau-, Bestätigungs- und Sicherheitsbackup-Gates sind in [BACKUP_AND_RESTORE.md](BACKUP_AND_RESTORE.md) und [ADR-0006](Architecture/ADRs/ADR-0006_Versioniertes-lokales-Backupformat.md) beschrieben.

`SDEImporting` wird in Infrastructure durch `JSONLinesSDEImportService` umgesetzt:

```text
lokales JSONL-Verzeichnis
    └──> read-only SDEImportPreview
            └──> privates, erneut validiertes .partial
                    └──> atomar veröffentlichtes .nensde
```

Application kennt weder CryptoKit noch den konkreten Dateiadapter. P08 ergänzt:

```text
.nensde
  └──> StaticDataCatalogMapping
          └──> validierter StaticDataCatalogSnapshot
                  └──> StaticDataCatalogStoring
                          └──> Schema-v2-Version + atomarer Aktivmarker
```

Details: [SDE_IMPORT.md](SDE_IMPORT.md),
[ADR-0007](Architecture/ADRs/ADR-0007_JSONL-SDE-Stagingpaket.md) und
[ADR-0008](Architecture/ADRs/ADR-0008_Versionierter-SDE-Stammdatenkatalog.md).

P09 ergänzt:

```text
Search/Get-Use-Cases
  └──> ItemBlueprintCatalogReading
          └──> SwiftDataItemBlueprintCatalog
                  └──> genau eine aktive Schema-v3-SDE-Version
```

Suche und exakte Lookups sind begrenzt, deterministisch und UI-frei.
Blueprintdetails erhalten die rohen Produktionsbezüge einschließlich
`typeIsResolved`. P10 ergänzt darauf:

```text
ResolveRecipeUseCase
  └──> RecipeCandidateReading
          └──> SwiftDataItemBlueprintCatalog
                  └──> genau eine aktive SDE-Version

RecipeReferenceAuditing
  └──> itemgenaue Referenzlücken des aktiven Builds
```

Auswahl, Mehrdeutigkeitsregel, Publikationsregel und vollständige
Referenzablehnung liegen in Application. Der Persistenzadapter liefert nur
versionsisolierte Kandidaten. Details:
[Item- und Blueprintkatalog](ITEM_BLUEPRINT_CATALOG.md) und
[Rezeptauflösung](RECIPE_RESOLUTION.md),
[ADR-0009](Architecture/ADRs/ADR-0009_Deterministischer-Item-und-Blueprintkatalog.md)
und
[ADR-0014](Architecture/ADRs/ADR-0014_Deterministischer-Rezeptresolver.md).

P11 und P12 ergänzen den Projektworkflow:

```text
ProjectEditorSheet
  └──> ProjectLifecycleViewModel
          ├──> ProductionTargetSelectionManaging
          │      ├──> ItemBlueprintCatalogReading
          │      └──> ResolveRecipeUseCase
          └──> ProductionProjectLifecycleManaging
                  └──> ProductionProjectRepository
                          └──> Schema-v5-Projekt
```

Views greifen für Projekte weder direkt auf SwiftData noch auf den
ModelContext zu. Das Ziel entsteht erst nach versionsgleicher
Produkt-/Aktivitäts-/Blueprintprüfung. Die additive v4→v5-Migration lässt
alle fünf Zielfelder historischer Projekte leer; Namen werden nicht in IDs
umgedeutet. Details:
[Projektlebenszyklus](PROJECT_LIFECYCLE.md),
[Zielauswahl](PRODUCT_TARGET_SELECTION.md),
[ADR-0015](Architecture/ADRs/ADR-0015_Projektlebenszyklus-und-reversible-Archivierung.md)
und
[ADR-0017](Architecture/ADRs/ADR-0017_Kataloggebundenes-Produktionsziel-und-Schema-v5.md).

P07A ergänzt:

```text
SDEUpdateService
  ├──> aktive lokale Buildnummer aus Schema v4
  ├──> CCPSDEMetadataClient
  │      ├──> latest.jsonl + ETag/Last-Modified
  │      └──> schema-changelog.yaml + Schema-Gate
  └──> persistierter Prüfstatus in Schema v4
```

Die 24-Stunden-Policy, Servercachefrist und Retryentscheidung sind
deterministisch und injizierbar. Ein Fehler verändert den aktiven Katalog
nicht. Details: [SDE-Aktualitätsprüfung](SDE_UPDATE_CHECK.md) und
[ADR-0010](Architecture/ADRs/ADR-0010_SDE-Metadaten-HTTP-Cache-und-Schema-Gate.md).

P07B ergänzt:

```text
SDEInstallationService
  ├──> offizieller CCPSDEArchiveDownloader
  ├──> SecureSDEArchivePreparer
  ├──> P07/P08 JSONL-Streamingmapping in begrenzten Batches
  ├──> isolierter blockweiser SwiftDataSDEStagingService
  ├──> SQLite-Sicherheitsbackup
  ├──> atomare Aktivierung oder Rollback
  └──> pfadbereinigtes Phasenjournal
```

Die ZIP-Vorprüfung liest Central Directory und lokale Header. Erst danach
läuft die feste, injizierbare macOS-Systemgrenze `/usr/bin/ditto` ohne Shell;
der reale Dateibaum wird anschließend erneut validiert. Der aktive Store wird
erst nach erfolgreicher Staging-Wiederöffnung berührt. Die Promotion schreibt
begrenzte Batches und setzt den Aktivmarker erst nach vollständigem
Mengenabgleich; zwei Realimporte von Build 3444265 lagen mit identischem
Inhalt bei 948–952 MB maximalem RSS. Details:
[SDE-Archivinstallation](SDE_ARCHIVE_INSTALLATION.md) und
[ADR-0011](Architecture/ADRs/ADR-0011_Sicherer-SDE-Archivpfad-und-Promotion.md).

P07C ergänzt:

```text
NexusAppRuntime
  └──> SDEAppComposition
          ├──> P07A-Check + P07B-Installation
          ├──> kontaktfreie Start-Recovery
          ├──> privater geprüfter Archivcache
          ├──> Keychain-Kontakt
          ├──> Logleser + redigierter Export
          └──> bestätigte Katalog-Retention
                  └──> SDEManagementViewModel
                          └──> Status-/Settings-/Rechtsansicht
```

Details:
[SDE-Einstellungen und Diagnose](SDE_SETTINGS_AND_DIAGNOSTICS.md) und
[ADR-0012](Architecture/ADRs/ADR-0012_SDE-App-Composition-Automation-und-Retention.md).

## 16. P13 – Erklärbarer Produktionsgraph

```text
ProductionGraphView
  └──> ProductionGraphViewModel
        └──> ProductionGraphService
              ├──> ResolveRecipeUseCase
              └──> ProductionGraphRepository
                    └──> Schema-v6-Graphsnapshot
```

Der Domain-Snapshot verwendet Vorkommens-IDs für Knoten und stabile CCP-IDs
als fachliche Referenzen. Kanten enthalten in P13 ausschließlich rohe
Rezeptmengen. Vollständige Validierung prüft unter anderem Endpunkte,
Erreichbarkeit, Zyklen und Tiefen. SwiftData speichert genau einen
kanonischen Snapshot je Projekt; Views kennen weder SwiftData noch
`ModelContext`. Details:
[Produktionsgraph](PRODUCTION_GRAPH.md) und
[ADR-0018](Architecture/ADRs/ADR-0018_Erklaerbarer-Produktionsgraph-und-Schema-v6.md).

## 17. P14 – Runs, Graphformat 2 und Schema v7

```text
ProductionGraphService
  └──> ProductionRunCalculation (Formelversion 1)
        ├──> ganzzahlige Ceiling-Division
        ├──> geprüfte Outputmultiplikation
        └──> Graphformat 2
              └──> NexusSchemaV7.ProductionGraphRecord
                    └──> calculationFormulaVersion
```

Die Runberechnung liegt vollständig in der Domain. Application, Persistenz
und SwiftUI konsumieren denselben unveränderlichen Wert. Format-1-Graphen
bleiben lesbar und werden nicht stillschweigend fachlich verändert; ihre
fehlende Berechnung macht sie veraltet. Schema v7 speichert die
Formelprovenienz additiv und prüft sie gegen die Payload. Details:
[Runs und Ausgabemengen](RUNS_AND_OUTPUTS.md) und
[ADR-0019](Architecture/ADRs/ADR-0019_Integer-Runs-Graphformat-2-und-Schema-v7.md).

## 18. P15 – Material Efficiency, Graphformat 3 und Schema v8

```text
ProductionGraphService
  └──> ProductionMaterialCalculation (Formelversion 1)
        ├──> ganzzahlige Jobrundung
        ├──> Ein-Stück-je-Run-Schutz
        ├──> geprüfte Materialmultiplikationen
        └──> Graphformat 3
              └──> NexusSchemaV8
                    ├──> ProductionProject.materialEfficiency
                    └──> ProductionGraphRecord.materialFormulaVersion
```

Blueprint-ME ist ein validierter Projektwert. Domain und Graph prüfen
Basismenge, Runs, Aktivität, ME und alle abgeleiteten Werte; SwiftUI stellt
die Werte nur dar. Graphformat 1/2 und Schema-v7-Bestand bleiben lesbar,
werden aber nicht still fachlich aktualisiert. Details:
[Material Efficiency](MATERIAL_EFFICIENCY.md) und
[ADR-0020](Architecture/ADRs/ADR-0020_Integer-ME-Graphformat-3-und-Schema-v8.md).

## 19. P16 – Manufacturing-Rekursion und Graphformat 4

```text
ProductionGraphService
├── ResolveRecipeUseCase
├── ItemBlueprintCatalogReading
├── ProductionRunCalculation
├── ProductionMaterialCalculation
├── ProductionGraphExpansionLimits
└── ProductionGraphRepository
        └── SwiftDataProductionGraphRepository
              └── Schema-v8-Payload, Graphformat 4
```

Der Application-Service traversiert Manufacturing-Rezepte, während
Run-/Materialformeln und Graphinvarianten in der Domain bleiben. Die
SwiftUI-Ansicht rendert nur den validierten Snapshot. Rezept- und
Katalogports bleiben injiziert; SwiftData ist auf den Persistence-Adapter
begrenzt.

Jeder Zweig trägt seinen Vorfahrenpfad zur Zykluserkennung. Knoten-IDs
repräsentieren Vorkommen und keine global deduplizierten Typen. Der
vollständige Kandidat wird erst nach Domänenvalidierung gespeichert. Die
Repository-Transaktion ersetzt deshalb bei Resolver-, Berechnungs-, Grenz-,
Abbruch- oder Persistenzfehlern keinen Altgraphen.

Graphformat 4 liegt in der vorhandenen Schema-v8-Payload. Format 1 bis 3
bleiben lesbar und werden über Freshness als veraltet erkannt. Siehe
[ADR-0021](Architecture/ADRs/ADR-0021_Manufacturing-Rekursion-und-Graphformat-4.md).

## 20. P17 – T2-Regelvertrag und Graphformat 5

```text
ProductionGraphService
├── RecipeBackedT2IndustryData
│     ├── RecipeCandidateReading
│     └── ItemBlueprintCatalogReading
├── IndustryRuleSet / IndustryRuleValidator
├── T2StagePlanningPolicy
└── ProductionGraphRepository
      └── Schema-v8-Payload, Graphformat 5
```

Die Application-Schicht liest die konkrete SDE-Invention-Beziehung und
prüft zusätzlich, dass der Ausgangs-Blueprint eine Manufacturing-Aktivität
besitzt. So bleibt Reverse Engineering/T3 außerhalb von P17. Die Domain
berechnet Blueprintqualität, Decryptorwerte und erfolgreiche Kopien
deterministisch und kataloggebunden. SwiftUI zeigt nur die validierte
Provenienz. Siehe [T2-Berechnung](T2_CALCULATION.md) und
[ADR-0022](Architecture/ADRs/ADR-0022_T2-Invention-und-Graphformat-5.md).

P18 ergänzt daneben `ReactionIndustryDataReading`,
`ReactionRuleProfile`, `ReactionStagePlanningPolicy` und die zentrale
ganzzahlige Reaktionsberechnung. Der SwiftData-Adapter liest Profil und
reine Reaktionsformeln ausschließlich aus der aktiven Katalogversion.
Graphformat 6 speichert Kontext und Modifiertrace; siehe
[Reaktionsberechnung](REACTION_CALCULATION.md) und
[ADR-0023](Architecture/ADRs/ADR-0023_Reaktionskontext-und-Graphformat-6.md).

## 21. P19 – Materialaggregation und Graphformat 7

```text
ProductionGraphService
  ├──> vollständiger T1-/T2-/Reaktionsgraph
  ├──> ProductionGraphMaterialAggregator
  │      ├──> Materialblätter nach CCP-Type-ID
  │      ├──> effektive Kantenmengen
  │      ├──> Int64-Überlaufprüfung
  │      └──> Vorkommens- und Wurzelpfade
  └──> ProductionGraphSnapshot (Format 7)
          └──> SwiftDataProductionGraphRepository
                  └──> bestehende Schema-v9-Payload
```

Die Aggregation bleibt eine UI- und Persistenz-unabhängige
Domainberechnung. Der Application-Service erzeugt sie vor der atomaren
Repository-Speicherung. Der Snapshotvalidator berechnet sie beim Laden neu
und vergleicht sie exakt. Die bestehenden Vorkommensknoten bleiben erhalten;
Zwischenprodukte werden nicht als Endmaterial gezählt.

Generierung und geladene Payload verwenden dieselben Grenzen von 64 Ebenen
und 25.000 Knoten. Graphformate 1 bis 6 bleiben lesbar und veraltet. Details:
[Materialaggregation](MATERIAL_AGGREGATION.md) und
[ADR-0024](Architecture/ADRs/ADR-0024_Graphaggregation-und-Graphformat-7.md).

## 22. P20 – Lokale Lager und manuelle Bestände

```text
InventoryView / InventoryEditorViews
  └──> InventoryViewModel
        └──> InventoryManaging
              └──> InventoryManagementService
                    ├──> ItemBlueprintCatalogReading
                    └──> InventoryRepository
                          └──> SwiftDataInventoryRepository
                                └──> NexusSchemaV10
```

Lager und Bestände durchlaufen dieselben Domain-, Application- und
Persistenzgrenzen wie der Produktionskern. SwiftUI kennt keine
SwiftData-Modelle. Der Service validiert veröffentlichte Katalogitems,
Archivschreibschutz und positive Mengen; das Repository erzwingt zusätzlich
die persistent eindeutigen Lagername- und Lager-/Type-ID-Schlüssel.

Schema v10 ist additiv. Manuelle aggregierte Mengen bleiben von späteren
ESI-Assetinstanzen getrennt. Details:
[Lager und manuelle Bestände](INVENTORY_MANAGEMENT.md) und
[ADR-0025](Architecture/ADRs/ADR-0025_Lokale-Lager-und-manuelle-Bestaende.md).

## 23. P21 – Kontrollierter CSV-Bestandsimport

```text
InventoryCSVImportView
  └──> InventoryCSVImportViewModel
        └──> InventoryCSVImporting
              └──> InventoryCSVImportService
                    ├──> InventoryCSVParsing
                    │     └──> DelimitedInventoryCSVParser
                    ├──> ItemBlueprintCatalogReading
                    └──> InventoryRepository
                          └──> SwiftDataInventoryRepository
                                └──> NexusSchemaV11
```

Die Application-Schicht trennt `preview` strikt von `apply`. Die Vorschau
schreibt nicht und klassifiziert jede Datenzeile. Erst bestätigte, vollständig
entschiedene und gegenüber Lager, Bestand sowie Katalog nicht veraltete
Mutationen werden gemeinsam mit einem bereinigten Bericht in einer
SwiftData-Speicherung geschrieben. Der Infrastrukturparser kapselt
Kodierungen, Delimiter, Quotes und harte Ressourcenlimits; die UI kennt
keine SwiftData-Modelle.

Schema v11 ist additiv und speichert nur Metadaten und Ergebniszählungen,
keine CSV-Rohdaten. Details:
[CSV-Bestandsimport](INVENTORY_CSV_IMPORT.md) und
[ADR-0026](Architecture/ADRs/ADR-0026_Sicherer-CSV-Bestandsimport-und-Schema-v11.md).

## 24. P22 – Projektbezogene Verfügbarkeit und Ausschlüsse

```text
InventoryAvailabilitySheet
  └──> InventoryAvailabilityViewModel
        └──> InventoryAvailabilityManaging
              └──> InventoryAvailabilityService
                    ├──> ProductionProjectRepository
                    ├──> ProductionGraphRepository
                    ├──> InventoryAvailabilityRepository
                    │     └──> SwiftDataInventoryAvailabilityRepository
                    │           └──> NexusSchemaV12
                    └──> InventoryAvailabilityCalculator
                          └──> Domain
```

Der Service lädt ausschließlich einen aktuellen Graphformat-7-Bedarf und
erzeugt aus Projekt, Graph, Lager, Beständen und Konfiguration ein
Quellzustand-Token. Die schreibfreie Vorschau berechnet jede Ausschlussstufe
neu. Apply benötigt Bestätigung und exakt denselben Quellzustand. Nur die
kanonische Konfiguration wird gespeichert; Ergebniszahlen bleiben
reproduzierbare Domainwerte.

Schema v12 ist additiv und speichert höchstens eine Konfiguration je Projekt.
Sicherheitsbestände und Reservierungen sind bewusst keine P22-Abhängigkeit.
Details:
[Verfügbarkeit und Ausschlüsse](INVENTORY_AVAILABILITY.md) und
[ADR-0027](Architecture/ADRs/ADR-0027_Projektbezogene-Verfuegbarkeit-und-Schema-v12.md).

## 25. P23 – Globale Sicherheitsbestände

```text
SafetyStockSheet
  └──> SafetyStockViewModel
        └──> SafetyStockManaging
              └──> SafetyStockService
                    ├──> InventoryAvailabilityManaging
                    ├──> SafetyStockPolicyRepository
                    │     └──> SwiftDataSafetyStockPolicyRepository
                    │           └──> NexusSchemaV13
                    └──> SafetyStockCalculator
                          └──> Domain
```

Der Service übernimmt die aktuelle P22-Vorschau und die globalen Regeln der
Graphmaterialien. Die schreibfreie Vorschau schützt Sicherheitsmengen und
wertet weitere Schwellen aus. Apply verlangt Bestätigung und denselben
Projekt-, Graph-, Lager-, Bestands-, P22- und Regelzustand. Nur Regeln werden
persistiert; Ergebniszahlen bleiben reproduzierbare Domainwerte.

Schema v13 ist additiv und speichert höchstens eine Regel je Type-ID.
Reservierungen bleiben eine getrennte P24/P25-Schicht. Details:
[Sicherheitsbestände](SAFETY_STOCK.md) und
[ADR-0028](Architecture/ADRs/ADR-0028_Globaler-Sicherheitsbestand-und-Schema-v13.md).

## 26. P24 – Globale Projektreservierungen

```text
ProjectReservationSheet
  └──> ProjectReservationViewModel
        └──> ProjectReservationManaging
              └──> ProjectReservationService
                    ├──> SafetyStockManaging
                    ├──> ProjectReservationCalculator
                    └──> ProjectReservationRepository
                          └──> SwiftDataProjectReservationRepository
                                └──> NexusSchemaV14
```

P24 setzt ausschließlich auf der aktuellen P22-/P23-Vorschau auf.
Reservierungen binden global eine CCP-Type-ID an ein Projekt. Die Domain
trennt aktive Restbindungen anderer Projekte von der eigenen Bindung,
prüft Ganzzahlsummen und blockiert neue Überbuchungen. Ein expliziter
Zustandsautomat erhält terminale Historie. Verbrauch und Freigabe verändern
keine physischen Bestandspositionen.

Der Application-Service trennt Vorschau und bestätigtes Schreiben. Der
Quellzustand umfasst Projekt, Graph, Lager, Bestände, P22-Konfiguration,
P23-Regeln und alle relevanten Reservierungsversionen. Der SwiftData-Adapter
prüft denselben Zustand erneut und speichert atomar. Schema v14 ist additiv.
Die Projektpersistenz verhindert Archivierung bei aktiven Bindungen.

Nachträglich durch Bestands- oder Regeländerungen entstandene Konflikte
werden durch die P25-Schicht erkannt und aufgelöst. Details:
[Projektreservierungen](PROJECT_RESERVATIONS.md) und
[ADR-0029](Architecture/ADRs/ADR-0029_Globale-Projektreservierungen-und-Schema-v14.md).

## 27. P25 – Berechnete Reservierungskonflikte

```text
ReservationConflictSheet
  └──> ReservationConflictViewModel
        └──> ReservationConflictManaging
              └──> ReservationConflictService
                    ├──> SafetyStockManaging
                    ├──> ProjectReservationRepository
                    ├──> ProductionProjectRepository
                    ├──> StaticDataCatalog
                    └──> ReservationConflictCalculator
```

Die P25-Schicht berechnet Bestandsunterdeckung,
Bedarfsüberschreitung und nicht mehr benötigte aktive Bindungen aus dem
aktuellen P22-/P23-/P24-Zustand. Prioritäten erzeugen nur einen stabilen
Vorschlag. Eine bestätigte Auflösung darf ausschließlich reduzieren oder
freigeben und muss alle sichtbaren Konflikte beseitigen. Der vollständige
Source-State wird vor dem atomaren P24-Repository-Schreibvorgang erneut
geprüft.

Konflikte und Vorschläge werden nicht persistiert; Schema v14 bleibt
unverändert. Details: [Reservierungskonflikte](RESERVATION_CONFLICTS.md)
und [ADR-0030](Architecture/ADRs/ADR-0030_Berechnete-Reservierungskonflikte-und-kontrollierte-Aufloesung.md).

## 28. Offene Architekturarbeiten

- P31: Kaufstatus, CSV und projektübergreifenden Einkauf auf P30 aufsetzen.
- P36: Backup-/Restore-Lebenszyklus und Recovery-Drill.

## 29. P29 – Reproduzierbare Projektwirtschaftlichkeit

```text
ProductionWorkspaceView
  └──> BuildOrBuyWorkspaceViewModel
        └──> ProjectEconomicsManaging
              └──> ProjectEconomicsService
                    ├──> PriceProfileManaging
                    ├──> ProjectEconomicsCalculator
                    └──> ProjectEconomicsRepository
                          └──> SwiftDataProjectEconomicsRepository
                                └──> NexusSchemaV18
```

Die UI bleibt SwiftData-frei. Der Service verbindet den aktuellen P26-Plan
mit einem P27-/P28-Preisprofil, erzeugt eine schreibfreie Vorschau und
speichert nach erneuter Preisprüfung und Bestätigung nur Profilwahl und
manuelle Jobkosten. Die Domain trennt Cash- und wirtschaftliche Kosten und
liefert Gewinn, Marge, ROI sowie Break-even mit geprüfter
Ganzzahlarithmetik. Ergebniszahlen werden nicht persistiert.

Details: [Projektwirtschaftlichkeit](PROJECT_ECONOMICS.md) und
[ADR-0035](Architecture/ADRs/ADR-0035_Reproduzierbare-Projektwirtschaftlichkeit-und-Schema-v18.md).

## 30. P30 – Projektbezogene Einkaufsaggregation

```text
ProductionWorkspaceView
  └──> BuildOrBuyWorkspaceViewModel
        └──> ShoppingListManaging
              └──> ShoppingListManagementService
                    ├──> BuildOrBuyPlanning
                    ├──> ShoppingListAggregator
                    └──> ShoppingQuantityOverrideRepository
                          └──> SwiftDataShoppingQuantityOverrideRepository
                                └──> NexusSchemaV19
```

Die Domain führt positive P26-Fehlmengen defensiv nach Type-ID zusammen.
Der Service erzeugt eine schreibfreie Mengenvorschau und prüft vor dem
bestätigten atomaren Ersatz erneut den kanonischen P26-Plan sowie den
Override-Stand. Persistiert werden nur Abweichungen; die UI bleibt
SwiftData-frei.

Details: [Einkaufsliste](SHOPPING_LIST.md) und
[ADR-0036](Architecture/ADRs/ADR-0036_Projektbezogene-Einkaufs-Overrides-und-Schema-v19.md).

## 31. P31 – Projektübergreifender Einkaufsworkflow

```text
PurchasingView
  └──> PurchasingViewModel
        └──> PurchasingWorkflowManaging
              └──> PurchasingWorkflowManagementService
                    ├──> ProductionProjectLifecycleManaging
                    ├──> BuildOrBuyPlanning
                    ├──> ShoppingListManaging
                    ├──> PurchasingWorkflowAggregator
                    └──> PurchaseProgressRepository
                          └──> SwiftDataPurchaseProgressRepository
                                └──> NexusSchemaV20
```

Der Service berechnet die P30-Listen aller aktuellen Projekte und isoliert
nicht berechenbare Projekte als sichtbare Hinweise. Die Domain aggregiert
Ziel-, angerechnete Kauf- und Restmengen deterministisch nach Type-ID. Der
gespeicherte Fortschritt ist eine Projektzuordnung, kein Lagerbestand.

Vorschau und bestätigter atomarer Ersatz sind an Projekt-, Plan-, Override-
und Fortschrittsversionen gebunden. Archivierte, nicht berechenbare und
veraltete Fortschritte werden nicht stillschweigend gelöscht. Text- und
CSV-Export sind reine Ableitungen der offenen Restmengen.

Details: [Einkaufsliste](SHOPPING_LIST.md) und
[ADR-0037](Architecture/ADRs/ADR-0037_Projektuebergreifender-Einkaufsworkflow-und-Schema-v20.md).
