# P42 – Wallet und reale Projektfinanzen

Status: **✅ umgesetzt und am 2026-07-27 abgenommen**

- **Reihenfolge:** direkt nach erfolgreicher P41-Abnahme; anschließend
  Nutzen-/Stopreview.
- **Zweck:** Wallet, Transaktionen und reale Istkosten Projekten zuordnen.
- **Voraussetzungen:** P40, P41.
- **Erwartetes Ergebnis:** nachvollziehbare reale Kosten und realisierte Gewinne.
- **Nicht Teil des MVP. Ausführung nur auf ausdrücklichen Auftrag.**

## Nutzenreview vom 2026-07-27

Entscheidung: **bedingtes Go für einen begrenzten, lokalen P42-Umfang**.

P40 liefert persönliche Industry Jobs einschließlich gemeldeter Jobkosten,
P41 liefert aktuelle Beschaffungspreise und P29 erwartete Wirtschaftlichkeit.
Der größte verbleibende Finanznutzen ist deshalb nicht ein allgemeines
Wallet-Dashboard, sondern der Vergleich geplanter mit tatsächlich
beobachteten Projektkosten und Verkaufserlösen.

Eine automatische Projektzuordnung ist nicht belastbar: Materialien sind
fungibel, mehrere Projekte können denselben Type verwenden, Käufe können
Vorratsaufbau sein und Journal-Kontexte unterscheiden sich nach `ref_type`.
P42 darf solche Zusammenhänge nur vorschlagen und niemals als Tatsache
speichern.

## Offizielle ESI-Grundlage

Geprüft am 2026-07-27 gegen die offizielle OpenAPI-Spezifikation:

- `/characters/{character_id}/wallet`
- `/characters/{character_id}/wallet/journal`
- `/characters/{character_id}/wallet/transactions`
- Scope: ausschließlich `esi-wallet.read_character_wallet.v1`
- Rate-Limit-Gruppe: `char-wallet`, 150 Tokens je 15 Minuten
- Journal: paginiert und laut offizieller Beschreibung 30 Tage rückwirkend
- Transaktionen: kontrollierte Rückwärtspagination über `from_id`
- alle drei Antworten liefern Cachevalidatoren

Die vorhandene zentrale ESI-Kompatibilitätsversion, Cache-, Rate-Limit-,
Refresh- und Abbruchinfrastruktur aus P39/P40 ist wiederzuverwenden.

Offizielle Quellen:

- https://esi.evetech.net/meta/openapi.json
- https://developers.eveonline.com/docs/services/esi/overview/
- https://developers.eveonline.com/docs/services/esi/best-practices/
- https://developers.eveonline.com/docs/services/esi/rate-limiting/
- https://developers.eveonline.com/docs/services/esi/pagination/from-id/
- https://developers.eveonline.com/docs/services/esi/pagination/x-pages/

## Verbindlicher erster Umfang

- genau einen zusätzlichen Read-Scope erst nach sichtbarer Erklärung und
  erneuter SSO-Zustimmung anfordern,
- Kontostand, Journal und Transaktionen je Charakter in einem getrennten,
  versionierten lokalen Offline-Snapshot speichern,
- Pagination, Cachevalidatoren, 304, Rate-Limits, `Retry-After`, Offline,
  Abbruch und Größenlimits aus P39/P40 übernehmen,
- Geldwerte deterministisch und überlaufgeprüft in ISK-Hundertsteln
  normalisieren; keine binären Gleitkommawerte persistieren,
- Käufe und Verkäufe über stabile Transaktions-/Journal-IDs deduplizieren,
- mögliche Zuordnungen zu genau einem Projekt nur als nicht persistierte
  Vorschau erzeugen,
- Benutzer kann eine Position vollständig, teilweise oder gar nicht einem
  Projekt zuordnen,
- zugeordnete Kaufkosten, Verkaufserlöse und eindeutig über
  `journal_ref_id` beziehungsweise `industry_job_id` belegte Gebühren getrennt
  ausweisen,
- geplante und tatsächliche Werte nebeneinander anzeigen; erwartete
  P29-Kennzahlen niemals überschreiben,
- Zuweisungen erst nach Bestätigung atomar und versionsgebunden speichern,
- bei Trennen eines Charakters Wallet-Snapshot und nicht mehr belegbare
  Vorschläge sicher entfernen; bestätigte Projektbuchungen nur nach
  transparenter Entscheidung löschen oder anonymisiert erhalten.

## Nicht-Ziele

- keine Corporation-Wallets oder Wallet-Divisions,
- kein vollständiges Buchhaltungs-, Steuer- oder Vermögensmodul,
- keine automatische Projektzuordnung,
- keine Rekonstruktion einer vom ESI nicht gelieferten Historie,
- keine erfundenen Broker-, Steuer-, Transport- oder Herstellkosten,
- keine Veränderung von Preisen, Lagern oder Projektplänen durch Walletdaten,
- keine Hintergrundsynchronisation ohne sichtbaren Zustand,
- keine Export-, Cloud-, Mehrbenutzer- oder Corporation-Funktion,
- kein zusätzlicher SDE-Import ohne belegten Bedarf.

## Daten- und Sicherheitsgrenzen

Walletdaten bleiben lokal, charaktergebunden und getrennt von SDE,
öffentlichen Marktpreisen sowie P40-Snapshots. Tokens bleiben ausschließlich
im Schlüsselbund. Beschreibungen, Parteien und IDs dürfen nicht in normale
Logs, Diagnoseberichte oder Testfixtures gelangen.

Vor einer Umsetzung sind ein getrenntes Snapshotformat und ein additives
Schema für bestätigte Projektzuordnungen zu spezifizieren. Migration,
Backup, Wiederöffnung, Abbruch und Charaktertrennung müssen den bisherigen
Datenbestand erhalten.

## Mit zu erledigende offene Punkte

- `OFF-021`: Für den ersten Umfang reichen vorhandene Type-IDs und
  benutzerdefinierte Anzeigenamen. Keine zusätzlichen SDE-Datensätze blind
  importieren; neuen Namens-/Ortsbedarf erneut belegen.
- Scope-Erweiterung: Architekturtest von exakt drei auf exakt vier
  freigegebene persönliche Read-Scopes aktualisieren; keine Corporation- oder
  Schreibscopes zulassen.
- Zuordnungsgrenze: Mehrprojekt-, Teilmengen-, Doppelzuordnungs- und
  Stale-Preview-Fälle vor jeder Persistenz deterministisch prüfen.

## Messbare Abnahme

1. Ohne erneute Scope-Zustimmung wird kein Walletendpunkt aufgerufen.
2. Nur die drei festgelegten Charakterendpunkte und ein neuer Read-Scope
   werden verwendet.
3. Journal- und Transaktionspagination sind begrenzt, dedupliziert,
   cachekonform, abbrechbar und wiederanlauffähig.
4. Erfolg, 304, 401/403, 420/429, 5xx, Offline, beschädigter Cache,
   Größenlimit und Stale-Preview sind automatisiert getestet.
5. Kein Walletwert verändert ohne bestätigte Vorschau ein Projekt.
6. Teilzuordnungen können zusammen niemals die Quellmenge beziehungsweise
   den Quellbetrag überschreiten.
7. Erwartete und tatsächliche Projektkennzahlen bleiben fachlich getrennt
   und reproduzierbar.
8. Migration, Backup, Wiederöffnung und Charaktertrennung erhalten
   bestehende Projekte, Preise, Lager und persönliche P40-Snapshots.
9. SwiftPM-Build, relevante Tests und Xcode-Debugbuild sind erfolgreich.
10. Dokumentation, Review und Abschlussbericht sind vollständig; erst dann
    darf P42 `✅` werden.

## Umsetzungsnachweis vom 2026-07-27

Der begrenzte Umfang ist umgesetzt: genau vier persönliche Read-Scopes,
cachekonformer Abruf der drei Wallet-Endpunkte, privater versionierter
Dateisnapshot, Schema v22 für bestätigte Projektzuordnungen sowie
Vorschau-/Bestätigungsdialoge für vollständige und teilweise Zuordnungen.
Planwerte bleiben von den reproduzierbaren Istwerten getrennt.

Nachweise: SwiftPM-Build erfolgreich, 608 SwiftPM-Tests erfolgreich,
isolierter Xcode-Debugbuild erfolgreich. Der direkte Xcode-Aufruf im
synchronisierten Repository blieb ohne Fortschritt und wurde abgebrochen;
dies ist kein Codefehler. Details stehen im
[Abschlussbericht](../../Progress/Reports/2026-07-27_P42_Wallet-und-reale-Projektfinanzen.md).
