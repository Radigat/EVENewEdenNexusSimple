# P40 – Persönliche Assets, Blueprints und Industry Jobs

Status: **✅ erledigt**

## Nutzenreview

P40 ist für den lokalen Produktions-/Inventionsplaner sinnvoll: persönliche
Bestände und Blueprints reduzieren manuelle Übertragung, laufende Jobs machen
bereits gebundene Produktionsschritte sichtbar. Der Nutzen rechtfertigt genau
drei lesende persönliche Scopes. Corporation-, Wallet-, Markt- und
Schreibzugriffe bleiben ausgeschlossen.

## Ziel

Persönliche Assets, Blueprints und Industry Jobs eines ausdrücklich
verbundenen Charakters kontrolliert abrufen, vor dem lokalen Schreiben als
Differenzvorschau zeigen und nach Bestätigung offlinefähig speichern.

## Voraussetzungen

- P38 und P39 sind abgenommen.
- Der Charakter autorisiert ausdrücklich:
  `esi-assets.read_assets.v1`,
  `esi-characters.read_blueprints.v1` und
  `esi-industry.read_character_jobs.v1`.
- Offizielle CCP-OpenAPI- und ESI-Vorgaben wurden am 2026-07-26 geprüft.
- Kompatibilitätsdatum: `2026-07-26`.

## Umfang

- Access-Token nur flüchtig über den vorhandenen validierten Refresh-Flow
  beziehen; rotierte Refresh-Tokens bleiben ausschließlich im Keychain,
- offizielle unversionierte GET-Routen für Assets, Blueprints und persönliche
  Industry Jobs verwenden,
- Assets und Blueprints vollständig, seitenweise und sequenziell abrufen,
- Jobs einschließlich der offiziell verfügbaren letzten 90 Tage abrufen,
- `User-Agent`, `Authorization`, `X-Compatibility-Date`, Cacheheader,
  `304`, `X-Pages`, `420`, `429`, Error-Limit und Abbruch behandeln,
- Seitenzahl, Datensatzanzahl und Antwortgröße fest begrenzen,
- konsistente `Last-Modified`-Werte über paginierte Antworten verlangen,
- stabile CCP-IDs sowie Datenherkunft, Abrufzeit, Frische und Validatoren
  erhalten; unbekannte SDE-Auflösung verwirft keinen persönlichen Datensatz,
- Abruf zunächst nur als detaillierte Vorschau mit Einfüge-, Änderungs- und
  Löschzahlen sowie nachvollziehbaren Einzeländerungen bereitstellen,
- erst nach ausdrücklichem „Übernehmen“ atomar in einen getrennten,
  versionierten lokalen ESI-Snapshot schreiben,
- veraltete Vorschauen ablehnen; Abbruch oder Fehler verändert keinen
  bestehenden Snapshot,
- aktuellen Snapshot offline anzeigen und beim bestätigten Trennen
  kompensierbar entfernen.

## Bestandsschutz und Konfliktregeln

- Manuelle Lager, CSV-Importe, Sicherheitsbestände, Reservierungen,
  Produktionsprojekte und Preise werden niemals überschrieben.
- ESI-Snapshots sind eine getrennte, schreibgeschützte Datenquelle.
- Derselbe ESI-Schlüssel ersetzt nur seinen eigenen vorherigen Datensatz.
- Fehlende Einträge werden erst nach bestätigter Gesamtvorschau entfernt.
- Ohne vollständige konsistente Pagination findet keine Aktivierung statt.

## Mit zu erledigende offene Punkte

- `OFF-010 / KI-010`: persönlichen Assets-/Blueprint-/Job-Anteil schließen.
- `OFF-021`: kein zusätzlicher SDE-Blindimport; unbekannte Typ- oder
  Standortauflösung bleibt sichtbar und wird bedarfsgesteuert nachgezogen.
- P39-Trennen um den privaten Snapshot mit Rollback ergänzen.

## Nicht-Ziele

- keine Corporation-Daten, Wallets, Märkte, PI oder Skill-Synchronisation,
- keine Asset-Namen-/Positions-POST-Routen,
- kein automatisches Hintergrundpolling,
- kein automatisches Vermischen mit manuellen Lagern,
- keine Änderung an Signing, Team, Cloud oder öffentlicher Distribution,
- kein P41 bis P48, kein Commit und kein Push.

## Risiken

- Scope-Erweiterung verlangt erneute ausdrückliche SSO-Zustimmung.
- Große Assetmengen werden durch Sequenzabruf und harte Grenzen geschützt.
- Token-, Paging- oder Cachefehler dürfen den letzten gültigen Snapshot
  nicht beschädigen.
- Ortsnamen können ohne zusätzlichen SDE-/ESI-Bedarf ungelöst bleiben.

## Messbare Abnahme

- exakt drei dokumentierte Read-Scopes; keine weiteren Scopes,
- Token wird weder persistiert noch protokolliert,
- Pagination 1…`X-Pages`, konsistente Validatoren und feste Grenzen getestet,
- 200/304, 401/403, 420/429, 5xx, Offline, Abbruch und Schemalücken getestet,
- Inspektion schreibt keine Fachdaten; Apply verlangt explizite Bestätigung
  und unveränderte Basisrevision,
- Apply ersetzt alle drei Datensätze atomar; Teilfehler erhält Altbestand,
- Neustart lädt den letzten Snapshot; Trennen entfernt ihn kompensierbar,
- SwiftPM Debug, vollständige Tests und Xcode Debug bestehen,
- Dokumentation, Abschlussbericht und unabhängiger Review sind abgeschlossen.

## Erwartetes Ergebnis

New Eden Nexus hält persönliche Assets, Blueprints und Industry Jobs lokal
nachvollziehbar und offline bereit, ohne manuelle Lager oder andere
Benutzerdaten stillschweigend zu verändern.
