# P53 – Steuerung und Xcode-Kanon bereinigen

Status: ✅ erledigt

Empfohlenes Codex-Modell: `gpt-5.6-sol`, Reasoning `high`

## Ziel

Nach der Betriebsabnahme alle aktuellen Steuerquellen auf denselben Stand
bringen und genau ein kanonisches Xcode-Projekt für Schema und Quellen
ausweisen. Historische Berichte bleiben als Historie erhalten.

## Voraussetzungen

- P52 mit OFF-037/P42-Projektzuordnung als exakt dokumentiertem
  Eigentümer-Restgate beendet,
- OFF-038/KI-041,
- aktueller Quell-, Schema-, Package- und Xcode-Targetstand.

## Verbindlicher Umfang

- `AGENTS.md`, Projektstatus, Entwickler-Menü, Roadmap, Lean-Plan,
  Feature-Matrix, Promptregister, offene Punkte und bekannte Probleme
  widerspruchsfrei auf P50–P54 aktualisieren,
- historische Promptberichte nicht rückwirkend umschreiben; veraltete
  Aussagen in aktuellen Steuerdateien entfernen,
- user-facing Roadmap-, Synchronisations-, Scope- und Dashboardtexte gegen
  den realen Funktionsstand prüfen,
- Feature-Matrix insbesondere Schema v22+, P40/P42, Architekturgrenzen,
  Testzahlen und Betriebsabnahme korrigieren,
- alle `NewEdenNexus*.xcodeproj` und doppelten Promptdateien einzeln
  inventarisieren, Inhalt, Alter, Referenzen und benötigte Quellen vergleichen,
- `NewEdenNexus.xcodeproj` als einzigen Kanon regenerieren/verifizieren,
- andere Kopien erst nach detaillierter Vorschau und ausdrücklicher
  Bestätigung recoverbar verschieben; keine pauschale Löschung,
- Links, Prompt-IDs, Targetzahlen und Schemes maschinell prüfen.
- gespeicherte Projekt-Team-ID und aktuell gültige lokale
  Apple-Development-Identität als konkrete Vorschau vergleichen; eine
  Signing-Änderung nur nach ausdrücklicher Eigentümerbestätigung ausführen.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-038/KI-041 | widersprüchliche Statusquellen und Projektkopien bereinigen. | Dokumentmatrix, Einzelinventar, Hashvergleich, Projektverifier und Linkcheck |
| OFF-052/KI-054 | sichtbare Zertifikatsbezeichnung, Zertifikats-OU und lokale Teamkonfiguration unterscheiden und prüfen. | unveränderter Standardbuild; keine Änderung, weil OU und Team-ID übereinstimmen |

## Nicht-Ziele

- keine neue Fachfunktion,
- keine Änderung produktiver Stores oder persönlicher Daten,
- kein Commit oder Push,
- keine öffentliche Signierung oder Distribution,
- keine Entfernung ohne Vorschau, Bestätigung und Wiederherstellungsweg.

## Abnahme

1. Genau PLAN-005 ist der kanonische Reihenfolgeplan; alle aktuellen
   Steuerdateien referenzieren ihn widerspruchsfrei.
2. P43–P48 bleiben korrekt zurückgestellt beziehungsweise optional.
3. Keine aktuelle Steuerdatei nennt P38/P39 fälschlich als nächsten Prompt.
4. Kanonisches Xcode-Projekt enthält alle aktuellen Sources und Schemata.
5. Projektverifier meldet erwartete Targets, Testtargets und Schemes.
6. Jede entfernte Kopie war einzeln bestätigt und recoverbar verschoben.
7. Markdownlinks und Promptregister sind konsistent.
8. Review und Abschlussbericht sind vollständig.

## Ergebnis

Die Eigentümerbestätigung erfolgte am 2026-07-28. Alle neun historischen
Projektkopien wurden ohne Inhaltsänderung nach
`Documentation/Archive/XcodeProjects/` verschoben. Der alte P21-Entwurf liegt
unter `Documentation/Prompts/Archive/`; die kanonische P21-Datei blieb
unverändert. Der neue Governance-Prüfer sichert Projektkanon, Promptregister
und aktuelle Steuerlinks ab. Build, Tests und Review sind im P53-Bericht
dokumentiert.
