# P41 – Live-Marktpreise

Status: **✅ erledigt**

## Nutzenreview vom 2026-07-26

Entscheidung: **bedingtes Go für einen begrenzten P41-Umfang**.

Livepreise beseitigen die größte verbleibende manuelle Pflege im
Produktionsworkspace: Materialpreise für Build-or-Buy, Einkauf und
Wirtschaftlichkeit. Ein vollständiger Marktclient mit allen Regionen,
Orderbüchern und Historien bringt für die lokale Produktionsplanung dagegen
derzeit zu wenig Zusatznutzen im Verhältnis zu Datenmenge und Komplexität.

## Empfohlener erster Umfang

- ausschließlich öffentliche CCP-ESI-Marktdaten; keine neuen SSO-Scopes,
- nur Type-IDs des ausgewählten Projekts beziehungsweise der Einkaufsliste,
- benutzerdefiniertes Marktprofil mit Region-ID, optionaler Location-ID und
  lokalem Anzeigenamen; keine fest codierten Handelszentren,
- beschaffungsbezogener Preis aus tatsächlich erfüllbarer Verkaufsmenge statt
  eines ungeprüften Einzel-Minimums,
- Vorschau vor jeder Änderung eines lokalen Preisprofils,
- ausdrückliche Bestätigung vor dem Schreiben,
- Herkunft, Abrufzeit, Marktfilter, Menge und Cachealter je Preis,
- Offline-Fallback auf den letzten bestätigten Snapshot sowie manuelle oder
  CSV-Preise,
- Wiederverwendung der P39-Grenzen für ETag, `If-None-Match`,
  `If-Modified-Since`, 304, Rate-Limits, `Retry-After` und Abbruch.

Die vorhandene Projektwirtschaftlichkeit verwendet derzeit ein gemeinsames
Preisprofil für Materialkosten und Zielerlös. Deshalb aktualisiert der erste
P41-Umfang nur Beschaffungspreise. Der Zielerlös bleibt manuell oder per CSV
gesetzt. Eine automatische Erlösbewertung darf erst folgen, wenn Einkaufs-
und Verkaufspreisrollen fachlich getrennt sind.

## Nicht-Ziele

- kein vollständiger regionaler Orderbuchspiegel,
- keine Marktpreis-Historie, Prognose oder Handelsoptimierung,
- keine Wallet-, Auftrags- oder Transaktionsdaten,
- keine automatische Preisüberschreibung im Hintergrund,
- kein Abruf aller veröffentlichten Types,
- kein zusätzlicher SDE-Import ohne nachgewiesenen Bedarf.

`/markets/prices` liefert Durchschnitts- und Adjusted-Preise, aber keinen
belastbaren sofortigen Beschaffungspreis. Dieser Endpunkt ist daher kein
stillschweigender Ersatz für aktuelle Orders.

## Voraussetzungen

- P39 und P40 sind abgeschlossen.
- Der Benutzer beauftragt P41 ausdrücklich.
- Vor Implementierung wird der reduzierte Umfang in messbare Modelle,
  Migration, UI- und Testfälle übersetzt.
- `OFF-021` wird erneut geprüft. Für den ersten Umfang sind keine zusätzlichen
  SDE-Tabellen erforderlich; spätere autoritative Regions-, System- oder
  Stationsnamen benötigen eine neue Bedarfsentscheidung.

## Mit zu erledigende offene Punkte

- `OFF-021`: nur dann teilweise schließen, wenn die tatsächlich benötigten
  statischen Markt-/Ortsdaten belegt und modular importiert wurden; andernfalls
  mit unverändertem Bedarfsgate fortführen.

## Messbare Abnahme

1. Kein neuer SSO-Scope ist erforderlich.
2. Nur die angeforderten Type-IDs werden abgerufen; Pagination und
   Requestgrenzen sind getestet.
3. Preise werden mengenbezogen aus passenden Verkaufsorders ermittelt.
4. Kein lokaler Preis wird ohne Vorschau und Bestätigung verändert.
5. Manuelle/CSV-Werte, Projekte und Lager bleiben bei Abbruch oder Fehler
   unverändert.
6. Cachealter und Herkunft sind sichtbar; Offlinebetrieb nutzt nur
   gekennzeichnete bestätigte Snapshots.
7. Erfolg, 304, fehlende Orders, Teilabdeckung, 429, Offline, Abbruch,
   Neustart und Stale-Preview sind automatisiert getestet.

## Offizielle Prüfgrundlage

Geprüft am 2026-07-26:

- `https://developers.eveonline.com/docs/services/esi/overview/`
- `https://developers.eveonline.com/docs/services/esi/best-practices/`
- `https://developers.eveonline.com/docs/services/esi/rate-limiting/`
- `https://esi.evetech.net/meta/openapi.json`

Der aktuelle OpenAPI-Stand weist regionale Orders als öffentlichen,
Type-ID-filterbaren und paginierten Endpunkt mit fünf Minuten Cachealter und
eigener Markt-Rate-Limit-Gruppe aus.

## Ausführungsstand vom 2026-07-27

Der reduzierte Umfang ist implementiert: tokenloser öffentlicher Marktclient,
begrenzter Validator-/Offlinecache, mengenbezogene Preisbildung,
Vorschau-vor-Schreiben, Schema v21, Preisprovenienz und
Produktionsworkspace-UI. 593/593 SwiftPM-Tests bestanden. Nach vollständigem
Beenden von Xcode wurde der frühere Stillstand als File-Provider-/
`NSFileCoordinator`-Problem am Repositorypfad eingegrenzt. Der hashgleiche,
isolierte Projektstand bestand Projektverifier, `xcodebuild -list` und den
unsigned macOS-arm64-Debugbuild. P41 ist damit abgeschlossen.

Nachweis:
[P41-Abschlussbericht](../../Progress/Reports/2026-07-27_P41_Live-Marktpreise.md) ·
[OFF-034-Xcode-Abnahme](../../Progress/Reports/2026-07-27_OFF-034_P41-Xcode-Abnahme.md)
