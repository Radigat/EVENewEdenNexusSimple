# P51 – P42-Korrektur Scope, Fehler und Plan/Ist

Status: ⚠️ am 2026-07-27 durch P52-Livebefund zur Nachkorrektur geöffnet

Empfohlenes Codex-Modell: `gpt-5.6-sol`, Reasoning `xhigh`

## Ziel

Die nach P42 gefundenen Datenschutz-, Fehler- und Darstellungsabweichungen
beheben: persönliche und Walletoperationen erhalten richtige Fehlercodes,
Scopes werden zweckgebunden erklärt und angefordert, und Plan-/Istwerte stehen
im selben Projektkontext tatsächlich nebeneinander.

## Voraussetzungen

- P50 abgenommen,
- P29-Wirtschaftlichkeit, P38-SSO, P40-Snapshots und P42-Zuordnungen,
- OFF-036/KI-039/KI-040,
- Schema- und Backupstand aus P50.

## Verbindlicher Umfang

- vertauschte Operationszuordnung in `AccountsView` korrigieren:
  persönliche Inspektion/Apply → `esiPersonalData*`,
  Walletinspektion/Apply → `esiWallet*`,
- Regressionstests prüfen den tatsächlichen View-/Runtime-Aufruf, nicht nur
  die allgemeine Error-Mapping-Tabelle,
- SSO-Scopefluss nach minimalem Zweck trennen:
  - P40-Nutzung verlangt nur die drei persönlichen Produktions-Read-Scopes,
  - Walletzugriff ergänzt den vierten Scope erst nach eigener Erklärung und
    ausdrücklicher Neuautorisierung,
  - kein Snapshotvorhandensein darf mit erteiltem Scope gleichgesetzt werden,
- erteilte nicht geheime Scopemetadaten sicher und migrationsfähig abbilden,
  sofern sie für verlässliche UI-Zustände benötigt werden,
- Einstellungen, Accounts und Synchronisationsansicht nennen aktuelle
  Berechtigungen, Zweck, lokale Speicherung, Trennen und Löschwirkung,
- P29-Planwerte und bestätigte P42-Istkosten, Isterlöse und realisierter Saldo
  im selben ausgewählten Projekt nebeneinander anzeigen,
- fehlende Plan- oder Istwerte, veraltete Quellen und archivierte Projekte
  verständlich behandeln; keine automatische Zuordnung oder Überschreibung.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-036/KI-039 | Fehleroperationen und echten Plan-/Istvergleich korrigieren. | ViewModel-/UI-/Errorcode- und Wirtschaftlichkeitsregression |
| OFF-036/KI-040 | Scopeaufklärung und zweckgebundene Autorisierung wahrheitsgemäß machen. | exakt 3/4 Scopes, Neuautorisierung, Abbruch und bestehender Token |

## Nicht-Ziele

- keine neuen ESI-Scopes, Corporation-Wallet oder Buchhaltung,
- keine automatische Wallet- oder Jobzuordnung,
- keine Änderung von P29-Planwerten durch Walletdaten,
- kein produktiver Eigentümerabruf; dieser folgt erst in P52,
- kein Commit, Push, Signing- oder Distributionsumbau.

## Abnahme

1. Alle vier P40-/P42-Fehlerpfade liefern den richtigen stabilen Code.
2. Ein reiner P40-Login fordert keinen Walletscope.
3. Walletaktivierung erklärt den vierten Scope vor der Autorisierung.
4. Abbruch erhält Token, Konto, Snapshots und Zuweisungen.
5. Plan und Ist sind im selben Projekt sichtbar und bleiben fachlich getrennt.
6. Migration, Backup, Wiederöffnung und Trennen sind getestet.
7. SwiftPM Debug, relevante UI-/Architekturtests und Xcode Debug bestehen.
8. Review, Dokumentation und Abschlussbericht sind vollständig.

## Verbindliche Nachkorrektur aus P52

- OAuth-Formulardaten RFC-konform kodieren; insbesondere muss ein literales
  `+` im Refresh-Token als `%2B` übertragen werden.
- Regression mit einem synthetischen Token wie `ab+c/d==` ergänzen und
  Tokenrotation weiterhin atomar speichern.
- Sichere OAuth-Fehlerdiagnose auf standardisierte Fehlerklasse begrenzen;
  weder Token noch Serverbeschreibung protokollieren.
- Owner-Contact im App-Keychainpfad speichern und nach Neustart lesbar
  nachweisen; ein Keychain-Lesefehler darf nicht still wie „nicht
  konfiguriert“ behandelt werden.
- Danach fokussierte Auth-/ESI-Tests, Vollsuite und kanonischen
  Xcode-Debugbuild ausführen. Erst dann darf P52 fortgesetzt werden.
