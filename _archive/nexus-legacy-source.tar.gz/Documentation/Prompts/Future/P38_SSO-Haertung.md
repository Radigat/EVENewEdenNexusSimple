# P38 – SSO-Härtung

Status: **✅ erledigt – technische Härtung und Eigentümerabnahme bestanden**

## Ziel

Den bereits vorhandenen lokalen EVE-SSO-/PKCE-Code sicher in die
Schichtenarchitektur integrieren. Nach P38 kann der Projekteigentümer einen
Charakter lokal verbinden, wieder trennen und den Tokenlebenszyklus
kontrolliert verwalten. P38 führt noch keine ESI-Fachdatenabfragen aus.

## Voraussetzungen

- P37, REL-001, PLAN-003 und PLAN-004 sind abgeschlossen.
- Die im EVE Developer Portal registrierte Callback-URL entspricht exakt
  `http://localhost:52721/callback`.
- Die vorhandene öffentliche Client-ID bleibt zentrale Konfiguration; kein
  Client Secret wird benötigt oder gespeichert.
- Vor Ausführung sind die dann aktuellen offiziellen CCP-SSO-/OAuth-
  Dokumente zu prüfen.
- Vorhandene Benutzeränderungen, lokale Charakterdatensätze und
  Keychain-Einträge bleiben geschützt.
- Lokale App-Läufe mit Keychain-Zugriff verwenden dieselbe stabile
  Apple-Development-Identität; persönliche Team-/Zertifikatswerte bleiben in
  `XcodeSupport/LocalSigning.xcconfig` und damit außerhalb von Git.

## Umfang

- Authentifizierungs-, Browser-, Callback-, Token-Vault- und
  Charakter-Repository-Ports definieren und injizieren,
- `EVESSOService` aus der SwiftUI-/App-Schicht lösen und testbar aufteilen,
- Authorization Code mit PKCE, kryptografischen `state`, einmaligem
  Loopback-Callback, Timeout, Abbruch und Wiederanlauf härten,
- Tokenantworten und Claims vollständig validieren; insbesondere Signatur,
  Aussteller, Zielgruppe, Ablauf, Subject/Character-ID und Scopes nicht nur
  ungeprüft dekodieren,
- Refresh-Token ausschließlich im macOS-Schlüsselspeicher halten,
- Access-Token nur so kurz und eng wie fachlich erforderlich halten,
- Refresh, Ablauf, Widerruf und erneute Anmeldung deterministisch abbilden,
- benötigte Scopes zentral, minimal und für den Benutzer sichtbar
  vorbereiten; fachliche ESI-Nutzung bleibt P39/P40,
- Charakterverknüpfung und -trennung über Application-Use-Cases mit
  Vorschau/Bestätigung und klarer Fehlerkompensation ausführen,
- `AccountsView` und betroffene Future-Views von direkten SwiftData- und
  Keychain-Zugriffen lösen,
- lokale Status-, Fehler-, Abbruch- und Wiederanmelde-UX ergänzen,
- Logs und Diagnoseausgaben auf Token-, Code-, State- und
  personenbezogene Inhalte prüfen und redigieren.

## Mit zu erledigende offene Punkte

- `OFF-008 / KI-011`: `AccountsView` und betroffene Character-/SSO-
  Future-Views auf Application-Use-Cases und injizierte Ports umstellen.
- `OFF-010 / KI-010`: vorhandenen SSO-Zukunftscode innerhalb des
  P38-Umfangs härten; ESI-Synchronisation bleibt P39/P40.
- `OFF-013 / KI-014`: atomare beziehungsweise kompensierende Strategie für
  gekoppelte Keychain-/SwiftData-Änderungen implementieren und testen.
- `OFF-033 / KI-033`: stabile lokale Signierung verifizieren, bestehenden
  ad-hoc-Keychain-Bestand nur kontrolliert bereinigen und den Real-SSO-Lauf
  wiederholen.

## Nicht-Ziele

- keine Asset-, Blueprint-, Industry-Job- oder Markt-Synchronisation,
- keine Corporation-Scopes,
- kein Walletzugriff,
- kein Client Secret,
- keine Cloud- oder Mehrbenutzerfunktion,
- keine App-Store-, Signing- oder öffentliche Distributionsarbeit,
- kein Commit, Push oder Portal-Upload ohne eigenen Auftrag.

## Risiken

- unvalidierte JWT-Claims oder überbreite Scopes,
- Tokenverlust beziehungsweise verwaiste Keychain-Einträge bei
  Teilfehlern,
- hängender oder mehrfach ausgelöster Loopback-Callback,
- personenbezogene Daten oder Tokens in Logs,
- Regression vorhandener lokaler Projekte und Bestände.

## Messbare Abnahme

- Domain/Application bleiben frei von SwiftUI, AppKit, Network und
  Security-Framework,
- Views greifen weder direkt auf SwiftData noch auf den Keychain zu,
- PKCE-, State-, Callback-, Timeout-, Abbruch- und Fehlerpfade sind mit
  injizierten Fakes getestet,
- Signatur-, Issuer-, Audience-, Ablauf-, Subject- und Scopefehler werden
  abgelehnt,
- Verbinden, erneutes Verbinden und bestätigtes Trennen sind einschließlich
  Keychain-/Persistenzkompensation getestet,
- kein Secret oder Token erscheint in Quellcode, Logs, Fixtures oder
  Berichten,
- Migration/Leerstore/Wiederöffnung und relevante Regressionen sind grün,
- SwiftPM Debug, Xcode Debug und ein manueller lokaler SSO-End-to-End-Lauf
  mit dem Eigentümerkonto wurden tatsächlich ausgeführt,
- der signierte App-Build besitzt über Wiederholungsbuilds eine stabile
  Designated Requirement und kann seinen neu angelegten Token nach Neustart
  lesen und löschen,
- Dokumentation, offene Punkte, Feature-Matrix, Tagebuch, Testhistorie und
  Abschlussbericht sind aktualisiert,
- gesonderter Review gemäß `Documentation/REVIEW_RULES.md` ist bestanden.

## Erwartetes Ergebnis

Ein sicherer, testbarer, lokal betriebener SSO-Adapter als Voraussetzung für
P39. Technische Umsetzung, Laufzeitkorrekturen, stabil signierter
Eigentümerlauf und kontrollierte Alt-Token-Bereinigung sind erfolgt. P38 ist
`✅ erledigt`; P39 wurde nicht begonnen.
