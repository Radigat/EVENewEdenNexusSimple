# P50 – P40-Restabnahme persönliche ESI-Daten

Status: ✅ erledigt · 2026-07-27

Empfohlenes Codex-Modell: `gpt-5.6-sol`, Reasoning `xhigh`

## Ziel

Den technisch gespeicherten P40-Snapshot als tatsächlich nutzbare lokale
Funktion vervollständigen: Assets, Blueprints und Industry Jobs müssen
detailliert, offline und nachvollziehbar sichtbar sein. Persönliche Assets
dürfen nur nach Vorschau und Bestätigung als getrennte Planungsquelle wirken.

## Voraussetzungen

- P40 und P42-Quellstand, Schema v22 und aktuelle Tests,
- kanonisches `NewEdenNexus.xcodeproj`,
- OFF-035/KI-038,
- keine produktiven Benutzerwerte als Fixtures.

## Verbindlicher Umfang

- durchsuchbare, filter- und sortierbare Detailansichten für Assets,
  Blueprints und Industry Jobs je Charakter,
- sichtbare Type-/Location-ID, Menge, Blueprintart, ME/TE/Runs, Jobaktivität,
  Status, Start/Ende, Herkunft, Abrufzeit und Cache-/Offlinezustand,
- unbekannte SDE- oder Ortsauflösung sichtbar lassen; keine erfundenen Namen,
- große Snapshots begrenzen oder lazy darstellen; Empty/Loading/Error/Offline,
- ESI-Assets als eigene read-only Verfügbarkeitsquelle anbieten:
  - Benutzer wählt Charakter und zulässige Location-IDs,
  - Vorschau zeigt jede einbezogene Type-ID/Menge und mögliche Doppelzählung,
  - erst ausdrückliche Bestätigung aktiviert die projektbezogene Auswahl,
  - manuelle/CSV-Bestände werden weder kopiert noch überschrieben,
  - Snapshotrevision oder Filteränderung macht die Vorschau veraltet,
- additive Persistenz nur für die bestätigte Auswahl, falls Wiederöffnung dies
  erfordert; Migration, Backup und Restore entsprechend erhöhen,
- bestehende P40-Snapshot-, Trenn- und Kompensationsgrenzen erhalten.

## Blueprint- und Jobgrenze

Blueprints und Jobs werden in P50 detailliert angezeigt. Sie dürfen
Projektannahmen als nicht persistierten Hinweis erklären, aber weder
Blueprintqualität noch Projektstatus automatisch verändern. Eine spätere
bestätigte Projektverknüpfung benötigt einen eigenen belegten Bedarf.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-035/KI-038 | P40-Daten über Zähler hinaus nutzbar machen und kontrollierte Asset-Verfügbarkeit ergänzen. | UI/ViewModel/Application-/Persistenztests, Stale-Preview, Neustart und Offlinefall |
| OFF-021 | keine Orts-/SDE-Daten blind importieren. | ungelöste IDs sichtbar; Importinventar unverändert |

## Nicht-Ziele

- keine automatische Lagerübernahme oder Doppelzählung,
- keine Assetbewegung, ESI-Schreibroute oder Hintergrundautomation,
- keine Corporation-Assets/Blueprints/Jobs,
- keine Kalender-, Slot- oder Kapazitätsplanung,
- kein P43–P48, kein Commit oder Push.

## Abnahme

1. Alle drei Snapshotarten sind nach Neustart detailliert offline lesbar.
2. Suche, Filter, große Datenmenge und unbekannte IDs sind getestet.
3. Reine Inspektion verändert weder Snapshot noch Fachdaten.
4. Assetverfügbarkeit wirkt nur nach Detailvorschau und Bestätigung.
5. Manuelle Lager, CSV-Bestände, Schutzmengen und Reservierungen bleiben
   unverändert und Doppelzählungen werden sichtbar blockiert.
6. Veraltete Vorschau, Abbruch und Fehler erhalten den bisherigen Stand.
7. Relevante Migration/Backup/Wiederöffnung, SwiftPM Debug und Xcode Debug
   bestehen.
8. Review, Dokumentation und Abschlussbericht sind vollständig.
