# P39 – ESI-Infrastruktur und Charaktere

Status: **✅ erledigt**

## Ziel

Eine konservative, offlinefähige ESI-Basis implementieren und für lokal
verbundene Charaktere deren öffentliche CCP-Charakterinformationen
aktualisieren. P39 verwendet keine Asset-, Blueprint-, Job-, Wallet- oder
Corporation-Endpunkte.

## Voraussetzungen

- P38, P07A und P07C sind abgeschlossen.
- Offizielle CCP-Dokumente wurden am 2026-07-26 erneut geprüft.
- ESI-Basis: `https://esi.evetech.net/`.
- Kompatibilitätsdatum: `2026-07-26`, zentral versioniert.
- User-Agent verwendet Appname/Version und den bereits im Schlüsselbund
  hinterlegten Eigentümerkontakt.

## Umfang

- transportneutralen ESI-Charaktervertrag in Application definieren,
- offiziellen unversionierten Pfad
  `GET /characters/{character_id}/` verwenden,
- `User-Agent`, `Accept` und `X-Compatibility-Date` immer senden,
- `Expires`, `ETag`, `Last-Modified`, `If-None-Match`,
  `If-Modified-Since` und `304` korrekt behandeln,
- vor Serverablauf keine erneute Netzabfrage auslösen,
- neue Bucket-Header sowie alte ESI-Error-Limit-Header auswerten,
- `429`/`Retry-After`, `420`, `404`, `5xx`, Timeout, Offline und Abbruch
  typisiert behandeln,
- höchstens einen begrenzten 5xx-Wiederholungsversuch mit injizierbarem
  Backoff ausführen; keine Retry-Schleife bei 420/429,
- Antwortgröße begrenzen und erforderliche Felder validieren,
- öffentliche Charakterprofile samt Herkunft, Abrufzeit,
  Serverfrische und Validatoren lokal atomar cachen,
- frischen Cache ohne Netz verwenden, `304` gegen vorhandenen Cache
  auflösen und bei Offlinebetrieb den letzten Bestand als veraltet anzeigen,
- Accountansicht um Aktualisieren, Fortschritt, Aktualität, Offline- und
  Fehlerzustände ergänzen,
- Charaktercache beim bestätigten Trennen ebenfalls entfernen,
- SSO-Refresh aus P38 erhalten; die öffentliche Charakterroute erhält
  bewusst keinen unnötigen Bearer-Token.

## Mit zu erledigende offene Punkte

- `OFF-010 / KI-010`: ESI-Infrastruktur- und Charakteranteil schließen;
  P40-Synchronisation getrennt lassen.
- `OFF-021`: prüfen, ob zusätzliche SDE-Datensätze nötig sind. Für IDs und
  direkt gelieferte öffentliche Charakterfelder ist kein SDE-Import
  erforderlich; Titel-/Corporation-Namensauflösung bleibt bedarfsgesteuert.

## Nicht-Ziele

- keine Live-Assets, Blueprints oder Industry Jobs (P40),
- keine Marktpreise, Wallets oder Corporation-Daten,
- keine Hintergrund-Pollingschleife oder Cacheumgehung,
- keine neuen SSO-Scopes für die öffentliche Charakterroute,
- keine Tokens in Cache, Persistenz, Logs oder Tests,
- keine Schemaänderung: der ESI-Cache liegt getrennt von Benutzerdaten als
  begrenzte, atomare JSON-Datei,
- kein P40–P48 und kein Commit oder Push.

## Risiken und Schutz

- CCP-Vertragsänderung: Kompatibilitätsdatum ist fest und dokumentiert.
- Cachekorruption: Größenlimit, strikte Dekodierung, atomare Ersetzung und
  verständlicher Fehler; Accountdaten bleiben erhalten.
- Ratelimit: Serverheader haben Vorrang; bei fehlender Frische erfolgt
  keine automatische Abfrage.
- Datenschutz: nur verbundene Character-ID und öffentliche Profilfelder;
  Trennen löscht Profilcache und Token kontrolliert.

## Messbare Abnahme

- Requestpfad, User-Agent und Kompatibilitätsdatum entsprechen offiziellen
  Quellen,
- frischer Cache verursacht 0 HTTP-Aufrufe,
- 200 speichert Profil/Validatoren atomar; unbekannte Zusatzfelder werden
  ignoriert, fehlende Pflichtfelder abgelehnt,
- 304 nutzt vorhandene Daten; 304 ohne Cache wird abgelehnt,
- 420/429 sperren bis zum Serverzeitpunkt und werden nicht sofort erneut
  versucht,
- 5xx wird höchstens einmal wiederholt; Abbruch beendet Backoff und Schreiben,
- Offline mit Cache liefert sichtbar veraltete Daten, ohne Cache einen
  typisierten Fehler,
- Trennen entfernt Account, Refresh-Token und Charaktercache mit
  Kompensation bei Teilfehlern,
- Leerbestand, Neustart/Wiederöffnung, beschädigter Cache und Dateigrenzen
  sind getestet,
- SwiftPM Debug und Xcode Debug bestehen,
- Review und Dokumentation sind abgeschlossen.

## Erwartetes Ergebnis

New Eden Nexus kann öffentliche Informationen verbundener Charaktere
ressourcenschonend aktualisieren und offline weiter anzeigen. P40 wurde
nicht begonnen.
