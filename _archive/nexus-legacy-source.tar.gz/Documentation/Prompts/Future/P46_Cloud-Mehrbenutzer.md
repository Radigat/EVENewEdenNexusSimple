# P46 – Cloud und Mehrbenutzerbetrieb

Status: **Entwurf – ⏸️ verschoben**

- **Reihenfolge:** direkt nach P45, nur bei bestätigtem Mehrgeräte-/
  Mehrbenutzerbedarf.
- **Zweck:** optionale Mehrgeräte-/Mehrbenutzersynchronisation konzipieren.
- **Voraussetzungen:** P45.
- **Erwartetes Ergebnis:** Sicherheits-, Konflikt- und Betriebsmodell mit lokaler Ausfallsicherheit.
- **Nicht Teil des MVP. Vor Ausführung vollständig spezifizieren.**
