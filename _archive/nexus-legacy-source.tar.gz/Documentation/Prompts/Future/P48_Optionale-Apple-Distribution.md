# P48 – Optionale öffentliche macOS-/App-Store-Distribution

Status: ⏸️ optional verschoben · Entwurf

## Einordnung

P48 ist das **letzte optionale Zukunftspaket nach P47**. Es wird nur
ausgeführt, wenn der Projekteigentümer die App später tatsächlich öffentlich
verteilen möchte. P48 blockiert weder lokalen Betrieb noch P38–P47.

## Ziel

Eine dann bewusst gewählte öffentliche Verteilung sicher und nachvollziehbar
vorbereiten:

- bevorzugt Mac App Store oder
- alternativ ausdrücklich gewählte öffentliche Direktverteilung.

## Voraussetzungen bei Reaktivierung

- ausdrücklicher Auftrag des Projekteigentümers,
- gewünschter Verteilungsweg,
- endgültige Bundle-ID, Appname, Version und Buildnummer,
- verfügbares Apple-Developer-Team und passende Rollen,
- aktuelle Apple-, CCP-, Datenschutz- und Markenprüfung,
- geklärtes Monetarisierungs- und Supportmodell,
- aktueller vollständig geprüfter Quellstand.

## Voraussichtlicher Umfang

- Release- und Store-Metadaten,
- Apple-Team, Signing und erforderliche Entitlements,
- Hardened Runtime und App Sandbox nach gewähltem Verteilungsweg,
- Releasearchive und reproduzierbare Exportkonfiguration,
- Developer-ID-/Notarisierungspfad bei Direktverteilung,
- App-Store-Validierung und Einreichungsunterlagen bei Store-Verteilung,
- Datenschutzangaben, Drittanbieter-/CCP-Hinweise und Supportkontakt,
- Gatekeeper-/Installations-/Update-/Rollbacktests,
- finale öffentliche Release-Checkliste.

## Mit zu erledigende offene Punkte

- OFF-020: persönliche Marken-, Monetarisierungs-, Datenschutz- und
  Veröffentlichungsgenehmigung.
- OFF-032: Bundle-ID, Version, Apple-Team, Signing, Hardened Runtime,
  Archivierung, Notarisierung beziehungsweise Store-Einreichung und
  Distributionsabnahme.

## Nicht-Ziele bis zur Reaktivierung

- keine vorbeugende Signing- oder Teamänderung,
- keine Zertifikats- oder Geheimnisspeicherung im Repository,
- kein Upload, keine Einreichung und keine Vertragsannahme durch Codex,
- keine Einschränkung des lokalen Betriebs.

## Abnahmeentwurf

Die endgültigen Kriterien werden erst bei Reaktivierung gegen die dann
aktuellen Apple-/CCP-Vorgaben und den gewählten Verteilungsweg spezifiziert.
Ein lokaler `Release`-Build allein gilt niemals als öffentliche Abnahme.
