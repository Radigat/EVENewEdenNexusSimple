# P43 – Vollständiges Reaktionsmanagement

Status: **⏸️ Nutzenreview abgeschlossen; Umsetzung zurückgestellt**

- **Reihenfolge:** nach P42; Reaktivierung nur auf ausdrücklichen Auftrag.
- **Zweck:** Nutzen eines eigenständigen Reaktionsbetriebs über die bereits
  implementierte Rezept-, Graph- und Lagerplanung hinaus bewerten.
- **Voraussetzungen:** P18, P19, P20–P26, P32, P40 und P42.
- **Ergebnis des Reviews:** vollständiger Umfang derzeit nicht wirtschaftlich.
- **Nicht Teil des MVP. Es wurde kein Code implementiert.**

## Nutzenreview vom 2026-07-27

Entscheidung: **Stop/No-Go für die vollständige P43-Umsetzung zum jetzigen
Zeitpunkt.**

P18 berechnet Composite-, Hybrid-, Biochemical- und Molecular-Forged-
Reaktionen bereits mit Runs, Ausgabemengen, Material- und Zeitfaktoren.
P19 aggregiert die Materialblätter, P20–P25 berücksichtigen Lager,
Schutzmengen und Reservierungen, P26/P32 liefern Produktionsjobs und
Build-or-Buy. P40 enthält persönliche Industry Jobs; P29/P42 trennen
Plan- und bestätigte Istkosten.

Damit beantwortet die App die aktuelle Kernfrage auch für notwendige
Reaktionsstufen. Ein vollständiges Standort-, Fuel-, Slot-, Kalender- und
Auslastungsmodul schließt ohne belegten regelmäßigen Mehrlinienbetrieb keine
aktuelle Kernlücke.

## Aktuelle offizielle Grundlage

Am 2026-07-27 erneut geprüft:

- https://support.eveonline.com/hc/en-us/articles/115005405785-Reactions
- https://support.eveonline.com/hc/en-us/articles/203210272-Activities-and-Job-Types
- https://developers.eveonline.com/docs/services/esi/overview/
- https://developers.eveonline.com/docs/services/esi/best-practices/

CCP bestätigt weiterhin: Reaktionsformeln sind nicht erforsch-, kopier- oder
inventierbar; Reaktionen benötigen eine aktive passende Reactor-/Refinery-
Kombination in Systemen bis Security 0,4. Reaktionsjobs besitzen eigene
skillabhängige Parallelkapazität. Diese Regeln sind in P18 bereits
fachgerecht getrennt modelliert.

## Warum der vollständige Umfang zurückgestellt bleibt

- P18/P26 decken Berechnung und ausführbare Jobliste bereits ab.
- Reaktionspuffer dürfen Lager, Sicherheitsbestände und Reservierungen aus
  P20–P25 nicht duplizieren.
- Ein allgemeiner Kalender und Kapazitätsplan überschneidet sich mit P44.
- Live-Strukturzustände, Fuel und gemeinsame Anlagen würden zusätzliche
  Corporation-/Strukturrechte und neue Datenschutzgrenzen erzeugen.
- Struktur-Fuel ist nicht zuverlässig einem einzelnen Reaktionsjob
  zurechenbar; eine automatische Kostenzuordnung wäre eine Vermutung.
- Ohne belegtes Nutzungsszenario steht der erwartete lokale Nutzen nicht im
  Verhältnis zu Schema-, Migrations-, Recovery-, UI- und Testaufwand.

## Zulässige spätere Reaktivierung

P43 darf erst erneut vorgeschlagen werden, wenn der Projekteigentümer einen
regelmäßigen Bedarf an mehreren parallelen Reaktionslinien oder einer
abhängigen Chargenfolge bestätigt.

Der dann kleinste tragfähige Umfang wäre:

- manuelle lokale Reaktionsstandortprofile auf Basis des vorhandenen
  P18-Kontexts,
- aus vorhandenen Reaktionsjobs abgeleitete Chargen,
- manuelle Startzeit, Reihenfolge, Abhängigkeit, Kapazitätslinie und Status,
- ausschließliche Referenz auf vorhandene Lager-, Schutz- und
  Reservierungswerte,
- optionaler Vorschlag zur Verknüpfung eines P40-Reaktionsjobs, Speicherung
  nur nach ausdrücklicher Bestätigung,
- getrennte geplante Kosten und bestätigte P42-Istwerte.

## Nicht-Ziele einer Reaktivierung

- keine Corporation-Strukturen oder gemeinsame Rollen,
- keine automatische Struktur-, Fuel- oder Servicezustandserkennung,
- keine erfundene Fuel-/Steuer-/Transportkostenverteilung,
- keine automatische Slotoptimierung oder KI,
- keine PI- oder allgemeine Logistikplanung,
- kein zusätzlicher SDE-Import ohne belegten Feldbedarf,
- keine Änderung von Lager oder Projektstatus ohne Vorschau und Bestätigung.

## Mit zu erledigende offene Punkte

- `OFF-021`: Für das Review und den aktuellen Stand ist kein neuer
  SDE-Datensatz erforderlich. Ortsnamen oder weitere Strukturattribute
  benötigen bei Reaktivierung einen erneuten konkreten Bedarfsnachweis.
- Überschneidung P44: Allgemeine Kalender-, Logistik- und
  Kapazitätsfunktionen bleiben dort; P43 darf nur reaktionsspezifische
  Chargen besitzen.
- Bestehende Abdeckung muss wiederverwendet werden; keine parallele Lager-,
  Reservierungs-, Kosten- oder ESI-Jobimplementierung.

## Abnahme einer späteren Umsetzung

Vor einer Reaktivierung müssen mindestens ein reales Mehrlinien-Szenario,
gewünschte manuelle Eingaben, erwartete Zeitersparnis und ein
End-to-End-Referenzfall vorliegen. Erst eine danach vollständig
spezifizierte Implementierung benötigt Migration, Backup, Abbruch-/
Wiederanlauf, relevante Tests, Xcode-Build, Review und Abschlussbericht.

## Nächste Entscheidung

Zunächst den vorhandenen Reaktionsfluss im lokalen Realbetrieb nutzen.
P44-Nutzenreview nur auf ausdrücklichen Auftrag; P43-Implementierung bleibt
zurückgestellt.
