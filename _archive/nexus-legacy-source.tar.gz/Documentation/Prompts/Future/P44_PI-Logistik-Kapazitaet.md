# P44 – PI, Logistik und Kapazität

Status: **⏸️ Nutzenreview abgeschlossen; Gesamtumsetzung zurückgestellt**

- **Reihenfolge:** nach P43-Nutzenreview; Reaktivierung nur auf
  ausdrücklichen Auftrag und für einen belegten Teilbedarf.
- **Zweck:** Zusatznutzen von PI-Monitoring, Transportplanung sowie
  Produktionskalender/-kapazität gegenüber dem vorhandenen lokalen
  Produktionsplaner bewerten.
- **Voraussetzungen:** P18–P26, P32, P40 und P43-Nutzenreview.
- **Ergebnis:** Das gebündelte Gesamtpaket ist derzeit nicht wirtschaftlich.
- **Nicht Teil des MVP. Es wurde kein Code implementiert.**

## Nutzenreview vom 2026-07-27

Entscheidung: **Stop/No-Go für die vollständige P44-Umsetzung zum jetzigen
Zeitpunkt.**

Der bestehende Stand deckt Produktionsgraph und Zeiten, Lagerorte,
Verfügbarkeit, Reservierungen, Einkauf sowie persönliche Assets und Industry
Jobs ab. Nicht vorhanden sind PI-Kolonien/-Layouts, PI-Schematics,
Universums-/Routengraphen, Transportaufträge oder eine geplante
Slotbelegung.

P44 bündelt damit drei eigenständige Fachdomänen mit unterschiedlichen
Daten-, Berechnungs- und Sicherheitsgrenzen. Für die lokale Kernfrage
„produzieren oder kaufen, unter Berücksichtigung des Lagers“ ist keine davon
notwendig.

## Aktuelle offizielle Grundlage

Am 2026-07-27 geprüft:

- https://support.eveonline.com/hc/en-us/articles/203269871-Planetary-Interaction
- https://developers.eveonline.com/docs/guides/pi/
- https://developers.eveonline.com/docs/guides/route-calculation/
- https://esi.evetech.net/meta/openapi.json
- https://support.eveonline.com/hc/en-us/articles/203210292-Manufacturing

Die aktuelle ESI-Spezifikation bietet Kolonieliste und Kolonielayout über
`/characters/{character_id}/planets` und
`/characters/{character_id}/planets/{planet_id}` mit dem zusätzlichen
privaten Scope `esi-planets.manage_planets.v1`. Die Route zwischen zwei
Systemen ist öffentlich abrufbar. Der offizielle PI-Leitfaden zeigt, dass
Ertragsprojektionen zusätzliche zeit- und Dogma-abhängige Berechnungen
benötigen; ESI-Rohwerte allein reichen dafür nicht.

## Nutzen je Teilbereich

- **PI-Monitoring:** mittlerer bis hoher Nutzen nur bei aktiv betriebenen
  Kolonien und regelmäßigem Wartungsbedarf.
- **Manuelle Transportliste:** mittlerer Nutzen erst bei produktionsrelevanten
  Beständen an mehreren realen Standorten.
- **Routenplanung:** geringer Zusatznutzen ohne wiederkehrende Transporte;
  sichere Route, Schiffskapazität, Sonderverbindungen und Risiko sind eigene
  Anforderungen.
- **Jobkalender:** begrenzter Nutzen bei wenigen parallelen Jobs, da P40
  Start-/Endzeiten bereits speichert.
- **Geplante Slot-/Kapazitätssteuerung:** Nutzen erst bei regelmäßig
  konkurrierenden Charakteren, Blueprints oder Fertigungslinien.
- **Automatische Optimierung:** kein aktueller Bedarf und weiterhin P47.

## Warum der Gesamtumfang zurückgestellt bleibt

- Ein neuer privater PI-Scope erfordert bewusste Neuverbindung und
  zusätzliche persönliche Offline-Snapshots.
- PI-Projektionen benötigen verifizierte Schematics-/Dogma-Regeln,
  Versionsprovenienz und Referenztests.
- Transportplanung benötigt erst eine belastbare Zuordnung zwischen
  manuellen Lagern, ESI-Location-IDs und Universe-Daten.
- Kalender und Kapazität dürfen vorhandene P40-Jobs, P18-Zeiten,
  P20-Lager oder P24-Reservierungen nicht duplizieren.
- Das Gesamtpaket würde mehrere Schema-, Migration-, Recovery- und
  UI-Grenzen gleichzeitig öffnen, ohne dass ein reales Nutzungsszenario
  belegt ist.

## Zulässige spätere Reaktivierung

P44 bleibt ein einzelner Prompt. Vor einer Reaktivierung wählt der
Projekteigentümer genau einen belegten Teilbedarf:

1. read-only PI-Monitor mit Vorschau, Bestätigung und Offline-Snapshot,
2. manuelle Transportcheckliste aus vorhandenen Lager-/Projektinformationen,
3. read-only Zeitleiste vorhandener P40-Industry-Jobs.

Erst nach praktischer Abnahme eines solchen kleinen Schritts darf der nächste
Teil erneut bewertet werden. P43-Implementierung ist keine Voraussetzung,
solange keine reaktionsspezifische Chargenplanung benötigt wird.

## Nicht-Ziele einer Reaktivierung

- kein vollständiger PI-Layouteditor oder Kolonie-Simulator,
- keine erfundenen Erträge, Exportsteuern oder zukünftigen Lagerstände,
- keine automatische Bestandsbewegung oder Projektstatusänderung,
- keine Jump-Freighter-, Cyno-, Wormhole- oder Risikoplanung,
- keine automatische Slotplanung, Optimierung oder KI,
- keine Corporation-Daten oder gemeinsamen Transporte,
- kein neuer SDE-Import ohne konkretes Feldmapping und `OFF-021`-Freigabe.

## Mit zu erledigende offene Punkte

- `OFF-021`: PI-Schematics/Dogma oder Universe-/Stargate-Daten erst nach
  gewähltem Teilbedarf, vollständigem Mapping und Datenherkunft ergänzen.
- Ein zusätzlicher SSO-Scope darf nur für tatsächlich aktiviertes
  PI-Monitoring angefordert werden.
- Manuelle Lager-UUIDs und ESI-Location-IDs dürfen nicht stillschweigend
  gleichgesetzt werden.
- Schreibende Übernahmen benötigen Prüfung, Detailvorschau und ausdrückliche
  Bestätigung; unvollständige Werte bleiben sichtbar offen.

## Abnahme einer späteren Umsetzung

Vor Implementierung müssen reales Nutzungsszenario, Häufigkeit,
Eingabedaten, erwartete Zeitersparnis und ein End-to-End-Referenzfall
vorliegen. Erst danach folgen vollständige Spezifikation, Datenvorschau,
Migration/Backup, Offline-/Abbruch-/Neustarttests, Xcode-Build, Review und
Abschlussbericht.

## Nächste Entscheidung

Vorhandenen Produktions-, Lager- und Industry-Job-Fluss lokal nutzen.
P45-Nutzenreview nur auf ausdrücklichen Auftrag; P44-Implementierung bleibt
zurückgestellt.
