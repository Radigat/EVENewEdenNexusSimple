# P54 – Geprüfter lokaler Git-Sicherungspunkt

Status: ⏸️ wartet auf P53 und separate Commitfreigabe

Empfohlenes Codex-Modell: `gpt-5.6-sol`, Reasoning `xhigh`

## Ziel

Den nach P53 bereinigten, funktions- und betriebsgeprüften lokalen Stand als
reviewbaren Git-Sicherungspunkt erhalten. P54 ist kein Push- oder
Veröffentlichungspaket.

## Autorisierungsgate

Die Erstellung dieser Promptdatei und ein späterer Auftrag „P54 ausführen“
reichen nicht als Commitfreigabe. Nach vollständiger Vorschau von Status,
Diff, Ausschlüssen und Commitinhalt muss der Projekteigentümer unmittelbar
vor `git commit` noch einmal ausdrücklich zustimmen.

## Voraussetzungen

- P50–P53 abgeschlossen,
- eigene Projekt-Git-Wurzel und Branch `main` gezielt bestätigt,
- Home-Repository und andere Repositories außerhalb des Scopes,
- OFF-039/KI-042,
- vollständige Tests und kanonischer Xcode-Build auf finalem Quellstand.

## Verbindlicher Ablauf

1. Branch, HEAD, Status, untracked Dateien und Ausschlüsse inventarisieren.
2. Geheimnis-, Token-, Kontakt-, persönliche Daten-, Store-, SDE-, Cache-,
   Log-, Screenshot- und Buildartefaktscan durchführen.
3. Jede zu sichernde Datei nach Fachcode, Tests, Dokumentation, Xcode und
   Skripten gruppiert anzeigen; nichts mit pauschalem `git add .` aufnehmen.
4. Gelöschte/verschobene Dateien und kanonische Projektbereinigung separat
   erklären.
5. SwiftPM Debug, relevante fokussierte Tests, Xcode Debug,
   Projektverifier und Dokumentlinkcheck auf exakt diesem Stand ausführen.
6. Vorgeschlagene Commitnachricht und vollständige Stagingvorschau zeigen.
7. Eigentümerfreigabe abwarten.
8. Erst danach gezielt stagen, staged Diff erneut prüfen und genau einen
   lokalen Commit erstellen.
9. Post-Commit-Status, Commit-ID und verbleibende untracked/modified Dateien
   berichten.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-039/KI-042 | aktuellen Ausbau gegen unbeabsichtigten Verlust absichern. | Secret-/Ignoreprüfung, geprüfter staged Diff, lokale Commit-ID und Poststatus |

## Nicht-Ziele

- kein Push, Remote, Tag, Rebase, Merge oder Branchwechsel,
- kein Eingriff in `/Users/svenstolze/.git`,
- keine Aufnahme persönlicher oder generierter Daten,
- kein Reset, Clean oder destruktives Entfernen,
- keine öffentliche Distribution.

## Abnahme

1. Commitumfang ist vollständig, aber frei von Geheimnissen und Artefakten.
2. Finale Builds/Tests und Dokumentprüfungen sind erfolgreich.
3. Unmittelbare ausdrückliche Commitfreigabe ist dokumentiert.
4. Genau ein lokaler Commit wurde erstellt; kein Push erfolgte.
5. Poststatus und verbleibende Dateien sind einzeln nachvollziehbar.
6. Review und Abschlussbericht sind vollständig.
