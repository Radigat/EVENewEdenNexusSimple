# P52 – P40–P42 Eigentümer-Betriebsabnahme

Status: ⚠️ P42-1 nach OFF-053-Technikkorrektur im Eigentümer-Retest

Empfohlenes Codex-Modell: `gpt-5.6-sol`, Reasoning `high`

## Ziel

Die bislang nur automatisiert belegten persönlichen P40-/P42-Pfade und den
öffentlichen P41-Marktpfad im echten lokalen Eigentümerbetrieb kontrolliert
abnehmen. P52 ist eine Betriebsabnahme, kein neues Featurepaket.

## Voraussetzungen

- P50 und P51 vollständig abgenommen,
- erfolgreicher SwiftPM-Debuglauf und kanonischer Xcode-Debugbuild,
- aktuelles verifiziertes lokales Backup,
- Eigentümer ist anwesend und bestätigt jeden externen oder schreibenden Gate,
- OFF-037.

## Verbindlicher Ablauf

1. Vorprüfung ohne Datenänderung: Build, Apppfad, Store-/Backupstand,
   Keychain-Dienstname, SSO-Redirect, Owner-Contact und Diagnose-Redaction.
2. P40-Autorisierung mit genau drei Scopes sichtbar erklären; erst nach
   Bestätigung verbinden beziehungsweise neu autorisieren.
3. Persönliche Daten nur inspizieren; Einzeländerungen, Herkunft und Grenzen
   prüfen. Übernahme erst nach gesonderter ausdrücklicher Bestätigung.
4. Assets, Blueprints und Jobs nach Neustart online und anschließend über
   gespeicherten Offlinezustand detailliert prüfen.
5. Kontrollierte P50-Assetverfügbarkeit an einem nicht produktionskritischen
   Referenzprojekt zuerst als Vorschau, danach nur auf Bestätigung aktivieren.
6. P41 mit vom Eigentümer gewählter Region/Location und aktueller
   Einkaufsliste abrufen; Preisprofil erst nach Vorschau bestätigen.
7. Walletscope getrennt erklären und nur auf Bestätigung ergänzen.
8. Wallet zunächst nur inspizieren. Höchstens eine bewusst gewählte
   Testzuordnung nach Detailvorschau bestätigen; Plan/Ist gemeinsam prüfen.
9. Neustart, Offlinefallback, Abbruch sowie bestätigtes Trennen oder
   ausdrückliches Beibehalten prüfen.

## Sicherheitsgrenzen

- Keine SSO-, Wallet-, Markt- oder Datenübernahme ohne unmittelbare
  Eigentümerbestätigung.
- Tokens, Kontakte, Walletwerte, Parteien und Rohantworten nicht in Bericht,
  Screenshots oder Logs aufnehmen.
- Kein Löschen vorhandener Daten zur Vereinfachung der Abnahme.
- Bei Abweichung stoppen, Altstand erhalten und Korrektur dem Eigentümerprompt
  P50 oder P51 zuordnen; P52 bleibt dann `⚠️`.

## Laufzeitbefund 2026-07-27

Die bestätigte Eigentümerprüfung wurde nach erfolgreichem Build und
631/631 automatisierten Tests begonnen, aber vor jeder Fachdatenübernahme
angehalten:

- der erste PKCE-Login funktioniert,
- Refresh und private Inspect-Pfade erhalten am CCP-Tokenendpunkt HTTP 400,
- der verwendete Formular-Encoder schützt `+` in Refresh-Tokens nicht als
  `%2B`; damit kann der Token beim Server verändert ankommen,
- öffentliche ESI-Aufrufe melden `owner_contact_missing`, weil die außerhalb
  der App vorbereitete Keychain-Kontaktangabe für den Appprozess nicht
  verwendbar nachgewiesen ist.

Die Refresh-Korrektur wird ohne Parallelprompt P51 zugeordnet. P52 wird erst
nach grünem Regressionstest, neuem Build und erneuter ausdrücklicher
Eigentümerfreigabe fortgesetzt. Es wurden keine persönlichen ESI- oder
Walletvorschauen übernommen.

### Livefortsetzung

Owner-Contact, Refresh sowie persönlicher Inspect/Apply sind real bestanden.
Nach Korrektur des inklusiven CCP-`from_id`-Cursors öffnet auch „Wallet
prüfen“ die Vorschau ohne `NEN-ESI-004`. Der Inspect schrieb keine
Walletdaten. Übernahme oder Verwerfen der Vorschau bleibt ein separates
Eigentümer-Gate.

Die Übernahme wurde anschließend ausdrücklich freigegeben und der gespeicherte
Wallet-Snapshot nach vollständigem App-Neustart bestätigt. OFF-042 hält als
Restbefund fest, dass Übernehmen und Verwerfen noch kein eindeutiges sichtbares
Feedback liefern; Verwerfen darf weiterhin keinen gespeicherten Snapshot
löschen.

OFF-042 ergänzt flüchtiges, charakterbezogenes Feedback für Apply-Erfolg,
Apply-Fehler und Verwerfen mit oder ohne bereits gespeicherten Snapshot.
650/650 Tests und der signierte Xcode-Debugbuild bestanden. Der neue Build
wurde zunächst mit einem schreibfreien Verwerfen live bestätigt; ein weiterer
Apply verlangt ein neues ausdrückliches Eigentümer-Gate.

Am 2026-07-28 bestätigte der Projekteigentümer die sichtbare
Verwerfen-Erhaltmeldung im neuen Build. Der Apply-Feedback-Livetest bleibt
bis zu einem neuen ausdrücklichen Eigentümer-Gate offen.

Nach ausdrücklicher Freigabe bestätigte der Projekteigentümer anschließend
auch „Wallet-Snapshot wurde gespeichert.“ OFF-042/KI-045 sind damit
vollständig geschlossen.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-037 | realen P40-, P41- und P42-Eigentümerpfad einschließlich Neustart/Offline prüfen. | redigiertes Schrittprotokoll mit Gate, Ergebnis und Rücknahmezustand |
| OFF-045 | optionalen Spielerstrukturnamenscope separat erklären und nur auf unmittelbare Bestätigung freigeben; zugänglichen Namen und Offlinecache prüfen. | Scopeanzeige, Abbruchschutz und sichtbarer Name ohne Roh-ID |
| OFF-046 | alle Snapshot-Typnamen gegen den aktiven SDE-Katalog prüfen. | keine falsche Unbekannt-Anzeige; echter SDE-Fehlbestand klar benannt |
| OFF-047 | Produktionsworkspace vor P41-1 verbreitern und in direkt anwählbare Bereiche gliedern. | sechs horizontale Bereiche, keine lange Gesamtseite, unveränderte Fach- und Datenpfade |
| OFF-048 | P41-1 von einer vermeintlichen Währungsprofilpflicht lösen und Preissätze als getrennte ISK-Preisstände erklären. | Vorschau ohne Preissatz, gesperrte Übernahme, 664/664 Tests und Eigentümer-Sichttest |
| OFF-049 | Optionale PLEX-Anzeige nicht aus dem vorhandenen reinen Sell-Order-Vertrag raten. | späterer ausdrücklicher Nutzenreview mit getrennten Buy-/Sell-Quotes |
| OFF-050 | Technische Markt-IDs durch benannte Regionen, Trade Hubs und bekannte Marktstandorte ersetzen. | 26 fokussierte und 667 vollständige Tests; Eigentümer-Sichttest und erfolgte Preisübernahme |
| OFF-051 | Persönliche Assets, Blueprints und aktive Jobs alphabetisch nach Station gruppiert und gestaffelt prüfen. | Auf-/Zuklappen, globale Suche, nur aktive Jobs; 17 fokussierte und 668 vollständige Tests |

## Restgate-Inventur 2026-07-28

Bereits live bestanden sind Owner-Contact, Refresh, öffentlicher
Charakterabruf, persönlicher Inspect/Apply sowie Wallet-Autorisierung,
Inspect/Apply, Aktionsfeedback und Persistenz nach Neustart.

| Gate | Noch auszuführender Nachweis | Datenwirkung | Status |
|---|---|---|---|
| P40-1 | Detailansicht für Assets, Blueprints und Industry Jobs online prüfen. | keine | einschließlich OFF-043-Schließen-Button live bestanden |
| P40-2 | Detailansicht nach Neustart und ohne Netz aus lokalem Snapshot prüfen. | keine | live bestanden |
| P40-3 | Projekt und EVE-Lagerorte wählen; Assetverfügbarkeitsvorschau einschließlich Doppelzählungsschutz prüfen und zunächst verwerfen. | keine | live bestanden; ein späterer unbeabsichtigter Apply zählt nicht als P40-4-Abnahme |
| OFF-044 | Semantische Darstellung, Auswahlrücknahme und aktive Auswahl prüfen. | entfernt nur die projektbezogene Quellenauswahl; ESI-Snapshot und Bestände bleiben erhalten | Auswahlrücknahme und aktive Auswahl live bestanden; Namensrestbefunde in OFF-045/OFF-046 |
| OFF-045 | Optional `esi-universe.read_structures.v1` erklären und nur nach Bestätigung ergänzen; zugänglichen Spielerstrukturnamen online und anschließend aus Cache prüfen. | nur SSO-Scope-/Tokenerneuerung; keine Fachdatenübernahme | nächstes separates Eigentümer-Gate |
| OFF-046 | Asset-, Blueprint- und Jobtypnamen im neuen Build prüfen, einschließlich Zeilen außerhalb des früheren Rohdatenpräfixes. | keine | technisch bestanden, Eigentümer-Sichttest offen |
| P40-4 | eine bewusst neu gewählte Auswahl nach gesonderter Bestätigung übernehmen und nach Neustart/offline prüfen. | schreibt nur die projektbezogene Quellenauswahl | live bestanden |
| OFF-047 | breiten Produktionsworkspace sowie alle sechs horizontalen Bereiche im neuen Build prüfen. | keine | technisch bestanden; Eigentümer-Sichttest vor P41-1 offen |
| OFF-048 | Preissatzterminologie und profilfreie Vorschau im neuen Build prüfen. | Cacheabruf, keine Preisänderung | technisch bestanden; Eigentümer-Sichttest offen |
| OFF-050 | benannte Regionsliste, fünf Trade Hubs und einen bekannten öffentlichen Home-Hub prüfen; private Strukturmärkte müssen gesperrt bleiben. | Vorschau wurde in den gewählten Preissatz übernommen | technisch und live bestanden |
| OFF-051 | Assets und Blueprints nach Station gruppiert auf-/zuklappen, global suchen und in der Jobansicht nur aktive Jobs bestätigen. | keine | live bestanden; vollständige Stationszeile anschließend als Klickfläche ergänzt |
| P41-1 | aktuelle Einkaufsliste und Eigentümer-Region/Location wählen; Marktpreisvorschau abrufen. | Cacheabruf; anschließend erfolgte Preisübernahme | live bestanden |
| P41-2 | bereits übernommene Preise auf Herkunft, Region/Standort und Cachealter prüfen. | gewählter Preissatz wurde geändert | live bestanden |
| P41-3 | denselben Preissatz nach Neustart beziehungsweise ohne Netz prüfen. | keine Preisänderung | live bestanden |
| P42-1 | im OFF-053-Build eine Quelle mit sichtbarer Restkapazität und ein Testprojekt wählen; Zuordnungsvorschau prüfen und zunächst abbrechen. | keine | technisch korrigiert; Eigentümer-Retest offen |
| P42-2 | genau eine Zuordnung nach gesonderter Bestätigung speichern; Plan/Ist und Neustart prüfen. | schreibt eine Projektzuordnung, keine Planwerte | gesondertes Eigentümer-Gate |
| Ende | Offline-/Abbruchzustände dokumentieren und Trennen oder Beibehalten ausdrücklich wählen. | abhängig von Eigentümerwahl | offen |

Am Inventurtag bestanden zusätzlich 45/45 fokussierte Regressionen. Ein
neuer Xcode-Build war nicht erforderlich, weil seit dem bereits bestandenen
signierten OFF-042-Build kein Quellcode geändert wurde.

### OFF-053 – P42-1-Restkapazität und Abbruch

Der erste P42-1-Lauf endete mit `NEN-FIN-001`, bevor eine belastbare
schreibfreie Abnahme möglich war. Der Abbruch selbst kann keinen
Persistenzfehler erzeugen. Die UI bot jedoch bereits ausgeschöpfte Quellen an
und leitete die erwartbare Überbuchung an den generischen Speicherdialog.

Die Korrektur projiziert Restmengen und Restbeträge zentral und
deterministisch, blendet erschöpfte Quellen aus, validiert Eingaben gegen den
Rest und zeigt erwartbare Fehler inline. Beide Quellpicker besitzen jetzt
einen gültigen leeren Zustand. Ein Regressionstest verwirft die Vorschau und
beweist anschließend einen leeren Zuordnungsspeicher. 9/9 Wallet-Fachtests,
1/1 UI-Vertrag, 673/673 Gesamttests und der Apple-Development-signierte
Xcode Debug bestanden. Es wurde keine produktive Zuordnung geschrieben.
P42-1 bleibt bis zur Eigentümerbestätigung offen; P42-2 wurde nicht begonnen.

### P40-1-Livebefund

Der Projekteigentümer bestätigte Assets, Blueprints und Industry Jobs im
Online-Detailfenster. Dabei fehlte ein sichtbarer Schließen-Button.
OFF-043/KI-046 ergänzt im Kopf der Ansicht einen beschrifteten Button mit
Escape-Kurzbefehl. 1/1 fokussierter Architekturtest, 650/650 vollständige
Tests und der Apple-Development-signierte Xcode-Debugbuild bestanden. Vor
P40-2 blieb nur der sichtbare Button-Retest im neuen Build offen.

Der Projekteigentümer bestätigte anschließend auch den sichtbaren
Schließen-Button im neuen Build. OFF-043/KI-046 sind damit technisch und
live geschlossen. P40-2 folgte als ausschließlich lesender
Neustart-/Offline-Nachweis.

P40-2 wurde nach vollständigem App-Neustart ohne Netzverbindung bestanden:
Der lokale persönliche Snapshot blieb mit Assets, Blueprints und Industry
Jobs lesbar. Es wurde kein Refresh, Inspect oder Apply ausgelöst und keine
Benutzerdaten wurden verändert. Nächstes Gate ist P40-3, zunächst
ausschließlich als Assetverfügbarkeitsvorschau mit anschließendem Verwerfen.

### P40-3-Livebefund und OFF-044

Der Projekteigentümer legte das notwendige Projekt an, prüfte die
Assetverfügbarkeitsvorschau und bestätigte, dass Verwerfen funktioniert.
P40-3 ist damit bestanden. Eine weitere Auswahl wurde anschließend
unbeabsichtigt übernommen; dies ist keine belastbare P40-4-Abnahme.

OFF-044 ersetzt in den persönlichen Ansichten sichtbare technische IDs durch
SDE-Itemnamen, verständliche Aktivitäts-/Statusbezeichnungen und scopefrei
auflösbare offizielle Stations-/Systemnamen. Eine gespeicherte
Projekt-Asset-Auswahl kann nur über eine Rücknahmevorschau, unveränderten
Quellstand und ausdrückliche Bestätigung entfernt werden. Die Korrektur
verändert den vorhandenen Stand nicht automatisch. Private Spielerstrukturen
bleiben ohne zusätzlichen, noch nicht autorisierten Lesescope transparent
unbenannt. Der Eigentümer-Sicht- und Rücknahmetest ist das nächste Gate.

### OFF-045/OFF-046-Nachkorrektur

Der Eigentümer bestätigte anschließend Auswahlrücknahme und sichtbare aktive
Auswahl. Die verbleibenden Namensbefunde wurden getrennt behoben:

- `esi-universe.read_structures.v1` kann über einen eigenen erklärten
  Bestätigungsdialog optional ergänzt werden; Abbruch lässt den Stand
  unverändert,
- private Namen werden nur für tatsächlich referenzierte und für den
  Charakter zugängliche Strukturen geladen und validiert gecacht,
- die frühere Begrenzung der Typnamen auf die ersten 2.000 Rohdatensätze ist
  entfernt; alle referenzierten Typen werden aus dem aktiven SDE aufgelöst,
- ein Ladezustand wird nicht mehr als unbekannter Typ dargestellt.

42/42 fokussierte und 662/662 vollständige SwiftPM-Tests sowie der signierte
Xcode-Debugbuild bestanden. Reale Scope-Zustimmung und Sichtprüfung sind
noch nicht erfolgt und bleiben deshalb das nächste Eigentümer-Gate.

### P40-4-Eigentümernachweis

Der Eigentümer bestätigte eine neue, korrekte Assetverfügbarkeitsvorschau
und erteilte danach separat die ausdrückliche Freigabe zum Speichern. Die
Auswahl wurde als aktive projektbezogene ESI-Quelle angezeigt. Nach
vollständigem App-Neustart ohne Netz blieb sie beim gleichen Projekt
lesbar. Kein Refresh und keine weitere Vorschau wurden dabei ausgelöst.
P40-4 ist live bestanden; OFF-045/OFF-046 und die P41-/P42-Gates bleiben
unverändert offen.

### OFF-047-Produktionsworkspace vor P41-1

Der Eigentümer konnte P41-1 im bisherigen schmalen, durchgehend vertikalen
Produktionsworkspace nicht sinnvoll prüfen. Das Graphfenster wurde deshalb
auf 1.080 pt Mindest- und 1.360 pt Idealbreite erweitert. Eine horizontale
segmentierte Navigation zeigt jeweils genau einen der sechs Bereiche
Übersicht, Bauen/Kaufen, Lager/Einkauf, Kosten/ROI, Materialsumme und
Produktionsstufen. Fachlogik, Vorschau-/Bestätigungsgates und Persistenz
blieben unverändert. 9/9 fokussierte Prüfungen, 662/662 SwiftPM-Tests,
`git diff --check` und der signierte Xcode-Debugbuild bestanden. P41-1 bleibt
bis zum sichtbaren Eigentümernachweis offen und beginnt danach über
**Kosten & ROI** neu.

### OFF-048 – ISK-Preissätze und profilfreie P41-1-Vorschau

Preisstände heißen in der UI jetzt Preissätze und sind keine
Währungsprofile. Alle Werte bleiben ISK. Der Application-Vertrag erlaubt die
Marktpreisvorschau ohne Ziel-Preissatz; in diesem Zustand werden keine
vorhandenen Preise gelesen und die Übernahme bleibt fail-closed gesperrt.
12/12 fokussierte und 664/664 vollständige SwiftPM-Tests sowie der
Apple-Development-signierte Xcode-Debugbuild mit isoliertem Derived Data
bestanden. Der Eigentümer-Sichttest bleibt offen.

Die gewünschte optionale PLEX-Umrechnung wird nicht in P41-1 vorgezogen.
OFF-049 verlangt dafür später getrennte Buy-/Sell-Quotes samt Region,
Zeitpunkt und Frische; ISK bleibt die Rechen- und Speicherwährung.

### OFF-050 – Benannte Regionen, Trade Hubs und Home-Hubs

Die sichtbaren technischen Region- und Location-IDs wurden durch ein
benanntes Verzeichnis ersetzt. Alle öffentlichen ESI-Regionen stehen im
Dropdown; Jita, Amarr, Dodixie, Rens und Hek sind direkte Schnellwahlen.
Lokal bekannte Stationen und Spielerstrukturen werden aus persönlichen
Snapshots, Namenscache und öffentlicher Universe-Hierarchie regional
zugeordnet. Eine bekannte Struktur ist nur auswählbar, wenn CCP sie im
öffentlichen Marktstrukturverzeichnis führt. Private Strukturmärkte bleiben
benannt und fail-closed gesperrt; ihr Abruf benötigt später einen eigenen
authentifizierten Auftrag.

26/26 fokussierte und 667/667 vollständige SwiftPM-Tests,
`git diff --check` sowie der Apple-Development-signierte Xcode-Debugbuild
bestanden. Es gab keine Schema- oder Benutzerdatenänderung. Der
Eigentümer-Sichttest bleibt offen.

## Abnahme

1. Scopes entsprechen je Zweck exakt drei beziehungsweise vier.
2. Kein Inspect-Schritt schreibt Fachdaten.
3. Jede Übernahme besitzt Einzelvorschau und bestätigtes Gate.
4. P40-Details und P50-Verfügbarkeit funktionieren nach Neustart/offline.
5. P41-Preisquelle zeigt Herkunft, Menge und Cachealter.
6. P42 zeigt bestätigte Zuordnung sowie Plan/Ist ohne Überschreibung.
7. Trennen oder Beibehalten endet in einem dokumentierten konsistenten Stand.
8. Datenschutzprüfung, Review und Abschlussbericht sind bestanden.
