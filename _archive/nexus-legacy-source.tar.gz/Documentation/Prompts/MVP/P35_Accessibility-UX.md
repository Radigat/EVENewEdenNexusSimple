# P35 – Accessibility und UX-Politur

Status: **✅ erledigt**

## Zweck

Den vorhandenen Produktionsplaner-MVP auf macOS tastaturfreundlich,
VoiceOver-vermittelbar, kontrastadaptiv und bei schmalen sowie breiten
Fenstern nutzbar machen.

## Voraussetzungen

- P32 Kernworkspace, P33 Fehler-UX und P34 Großgraphen sind abgenommen.
- P07C/P09B liefern SDE-Status, Rechtstext und einen früheren manuellen
  VoiceOver-Smoke-Test.
- Keine Persistenz- oder Datenmigration ist erforderlich.

## Sprach- und Datenumfang

- Die MVP-Oberfläche bleibt deutschsprachig; EVE-Fachbegriffe bleiben
  erhalten.
- Eine weitere UI-Sprache ist nicht beauftragt.
- SDE-Namen bleiben in der vorhandenen Sprache des aktiven Katalogs.
- Es wird kein Übersetzungsdatensatz ohne bestätigten Featurebedarf
  importiert.

## Umfang

- funktionale, diakritik-unabhängige Bereichssuche in der Sidebar,
- verständlicher leerer Suchzustand und Tastaturabbruch,
- minimale Hauptfenstergröße 780 × 560 statt 1.100 × 700,
- adaptive Dashboard-, Produktionsworkspace-, Einkaufs- und SDE-Layouts,
- systemseitig kontrastadaptive Akzent-, Teal- und Warnfarben,
- Text- beziehungsweise Symbolstatus statt Farbe als alleiniger Bedeutung,
- zusammengefasste VoiceOver-Texte für Metriken, Status und Projektzeilen,
- Fokusreihenfolge Projektname → Zielsuche → Zielmenge,
- vollständige SDE-Statusansage sowie Hinweise für Installation, Abbruch,
  Kontakt und Diagnosefilter.

## Nicht-Ziele

- keine neue Fachfunktion,
- keine Änderung an Schema v20, Graphformat 7 oder Benutzerdaten,
- keine neue Sprache oder vollständige String-Catalog-Migration,
- kein neuer SDE-Datensatz,
- kein öffentlicher Release- oder CCP-Compliance-Sign-off.

## Mit zu erledigende offene Punkte

- Der frühere Entwurf ordnete `OFF-020` und `OFF-021` P35 falsch zu.
  Maßgeblich ist `Documentation/OFFEN.md`: `OFF-020` bleibt die spätere
  Release-/Complianceprüfung, `OFF-021` das bedarfsgesteuerte SDE-Datengate.
- `OFF-030`: aktuellen Build über einen funktionierenden nativen
  Accessibility-Kanal bei 780 × 560 und 1.280 × 800 prüfen. Erledigt durch
  ein dauerhaftes Xcode-UI-Testtarget mit Accessibility-Audit und
  Tab-Fokusnachweis.

## Messbare Abnahme

1. Sidebar-Suche findet deutsche Begriffe und EVE-Terminologie.
2. Leere Suche zeigt einen rücksetzbaren Empty State.
3. Hauptfenster und Kernlayouts besitzen schmale/breite Pfade.
4. Projekteditor besitzt eine nachvollziehbare Fokusreihenfolge.
5. Metriken und SDE-Status sind ohne Farbinformation verständlich.
6. SwiftPM- und Xcode-Debugbuild bestehen vollständig.
7. Alle Tests sind bestanden und nicht übersprungen.
8. Der aktuelle App-Build ist über einen nativen Accessibility-Kanal
   reproduzierbar geprüft.

## Tatsächliches Ergebnis

- Kriterien 1–8 sind umgesetzt und nachgewiesen.
- SwiftPM Debug bestand 518 Tests; Xcode Debug bestand 520 Tests.
- Zwei Xcode-UI-Tests starten das echte App-Bundle mit isoliertem Store und
  prüfen 1.280 × 800, 780 × 560, Kernstatus, Suche, Accessibility-Audit und
  Tab-Fokusfolge.
- Der interaktive Computer-Use-Kanal blieb technisch unbrauchbar. Daher wird
  kein unbelegter manueller VoiceOver-Einmaltest behauptet; das native
  XCUITest-Gate ist dauerhaft und reproduzierbar.

[Technikbericht](../../Progress/Reports/2026-07-26_P35_Accessibility-und-UX-Politur.md) ·
[abschließende OFF-030-Abnahme](../../Progress/Reports/2026-07-26_OFF-030_P35-Accessibility-Abnahme.md)
