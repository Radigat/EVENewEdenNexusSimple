# P03 – Domänenmodell, Schema v1 und Migrationen

Status: **✅ erledigt und reviewed**

## Projekt

Arbeite im geöffneten lokalen Repository für:

**New Eden Nexus – Assets, Industry, Markets**

P03 schafft die versionierte Persistenzgrundlage und die erste echte Repository-Grenze. Implementiere keine Produktionsgraph-, SDE-, Bestands-, Preis- oder andere spätere Fachfunktion.

## Zweck

Der P02-Stand besitzt getrennte Domain-, Application- und Infrastructure-Targets, hält die bestehenden SwiftData-Modelle aber aus Sicherheitsgründen noch im App-Target. P03 muss:

- den bisherigen unversionierten Store exakt erfassen,
- ein explizites SwiftData-Schema v1 einführen,
- den Übergang aus dem bisherigen Store automatisiert testen,
- persistente Modelle in einen eigenen Persistence-Target verschieben,
- ein UI-unabhängiges Domänenmodell für Produktionsprojekte definieren,
- einen Application-Repository-Port und einen SwiftData-Adapter implementieren,
- bestehende App-Funktionalität und Benutzerdaten erhalten.

## Voraussetzungen

- P00 bis P02 sind abgeschlossen und reviewed.
- `AGENTS.md` und `Documentation/REVIEW_RULES.md` gelten vollständig.
- [ADR-0001](../../Architecture/ADRs/ADR-0001_Modul-und-Schichtenarchitektur.md) ist akzeptiert.
- Debug-/Release-Build und 11 P02-Tests sind erfolgreich.
- P04 und spätere Fachprompts wurden nicht begonnen.

## Verbindliche Informationsquellen

Lies vor Änderungen:

1. aktuellen Quellcode, `Package.swift` und alle Tests,
2. Git-Status und vorhandene Benutzeränderungen,
3. `AGENTS.md`,
4. `Documentation/PROJECT_DESCRIPTION.md`,
5. `Documentation/CURRENT_PROJECT_STATUS.md`,
6. `Documentation/ARCHITECTURE.md`,
7. `Documentation/FEATURE_MATRIX.md`,
8. `Documentation/KNOWN_ISSUES.md`,
9. vorhandene ADRs und Abschlussberichte,
10. Projektbuch Kapitel 20.7, 20.16, 31, 32 und 33 sowie Anhang H und I,
11. die im installierten macOS-SDK tatsächlich verfügbaren SwiftData-APIs.

## 1. Ausgangsschema erfassen

Dokumentiere für `CharacterRecord` und `ProductionProject`:

- Modell- und Entitynamen,
- alle gespeicherten Attribute und Typen,
- Unique-Constraints,
- Standardwerte,
- optionale Werte,
- aktuelle Initialisierungs- und Normalisierungsregeln,
- App- und View-Zugriffe,
- aktuellen `ModelContainer`-Aufbau.

Computed Properties und UI-Enums sind von persistenten Attributen zu unterscheiden. Stelle geplante Schemafelder nicht als bereits vorhanden dar.

## 2. Begrenztes Schema v1

Schema v1 umfasst ausschließlich die beiden bereits vorhandenen persistenten Modelle:

- `CharacterRecord` zur Kompatibilität des vorhandenen Zukunftscodes,
- `ProductionProject` als vorhandene MVP-Basis.

Neue SDE-, Bestands-, Reservierungs-, Preis-, Einkaufslisten- oder Graphentitäten sind ausdrücklich nicht Bestandteil von P03.

Schema v1 muss:

- eine explizite `Schema.Version(1, 0, 0)` besitzen,
- unveränderte IDs und Felder des Legacy-Stands erhalten,
- eine additive Datensatzversion mit sicherem Standardwert einführen,
- eindeutige IDs beibehalten,
- keine Beziehung oder Pflichtinformation erfinden,
- als aktuelles Schema zentral referenziert werden.

## 3. Legacy-Schema und Migrationsplan

Definiere ein internes Legacy-Schema, das den bisherigen unversionierten Stand feldgenau repräsentiert. Definiere anschließend einen `SchemaMigrationPlan` vom Legacy-Schema zu Schema v1.

Die Migration muss:

- leichtgewichtig und additiv sein,
- alle vorhandenen Attributwerte erhalten,
- neue Versionsfelder sicher initialisieren,
- wiederholbar öffnen können,
- bei Fehlern abbrechen statt einen leeren Ersatzstore zu erzeugen.

Keine destruktive Migration, kein Löschen des Stores und kein stiller Fallback auf eine neue Datenbank.

## 4. Persistence-Target

Ergänze einen SwiftPM-Target:

`NewEdenNexusPersistence`

Abhängigkeiten:

```text
NewEdenNexusPersistence ──> NewEdenNexusApplication ──> NewEdenNexusDomain
NewEdenNexusPersistence ──────────────────────────────> NewEdenNexusDomain
NewEdenNexus ─────────────> NewEdenNexusPersistence
```

Persistence enthält:

- SwiftData-Modelle,
- Versioned Schemas,
- Migration Plan,
- zentrale `ModelContainer`-Factory,
- konkrete Repository-Implementierungen,
- Mapping zwischen Persistenz und Domain.

Persistence darf keine SwiftUI-Views, SSO-, Network- oder Keychain-Logik enthalten.

## 5. Domänenmodell

Definiere in `NewEdenNexusDomain` einen unveränderlichen, `Sendable`-fähigen Produktionsprojekt-Snapshot mit mindestens:

- ID,
- Name,
- Produktname,
- Zielmenge,
- Status,
- Priorität,
- optionalem Zieldatum,
- Notizen,
- Erstellungs- und Änderungszeitpunkt.

Invarianten:

- nichtleerer Projektname,
- nichtleerer Produktname,
- Zielmenge größer null,
- typisierter Projektstatus,
- stabile ID,
- Erstellungszeitpunkt nicht nach Änderungszeitpunkt.

Ungültige Werte führen zu typisierten Fehlern. Persistenztypen dürfen nicht ungeprüft als Domänenmodelle ausgegeben werden.

Der vorhandene UI-Workflow darf weiterhin seine bisherige Mengen-Normalisierung verwenden; P03 erweitert ihn fachlich nicht.

## 6. Repository-Port und Adapter

Definiere in Application einen `Sendable`-fähigen, asynchronen Port für Produktionsprojekte. Der P03-Mindestumfang ist:

- Projekt speichern beziehungsweise aktualisieren,
- Projekt nach ID laden,
- Projekte sortiert laden.

Der konkrete SwiftData-Adapter:

- lebt in Persistence,
- mappt explizit zwischen Record und Domain-Snapshot,
- verwendet keine produktiven Benutzerdaten in Tests,
- verschluckt keine Fehler,
- erzeugt bei Mappingfehlern keinen scheinbar gültigen Ersatzwert,
- speichert atomar über einen `ModelContext`.

Löschen, Duplizieren, Archiv-Workflow und weitere Projektfunktionen bleiben P11.

## 7. App-Integration

- Ersetze die direkte, unversionierte `ModelContainer`-Erzeugung durch die zentrale Factory.
- Erhalte die vorhandenen `@Query`- und `modelContext`-Workflows funktional.
- Verschiebe nur die persistenten Modelltypen in Persistence.
- Halte Navigation und UI-spezifische Enums im App-/Presentation-Bereich.
- Verändere kein Signing und keine Team-Einstellung.
- Erweitere SSO/ESI nicht.

Der bestehende `fatalError` bei Containerfehlern wird dokumentiert und erst in P04 behandelt. P03 darf den Fehler nicht durch einen leeren Ersatzstore kaschieren.

## 8. Migrationstests

Erstelle ein testseitiges Legacy-Schema-Fixture mit denselben Top-Level-Modellnamen und gespeicherten Feldern wie vor P03.

Prüfe mindestens:

1. Legacy-Store mit Charakter und Projekt erzeugen.
2. Store schließen.
3. Mit Schema v1 und Migrationsplan erneut öffnen.
4. Anzahl und sämtliche Legacy-Werte vergleichen.
5. neue Datensatzversion prüfen.
6. Store ein zweites Mal mit Schema v1 öffnen.

Der Test nutzt ausschließlich ein eindeutig erzeugtes temporäres Verzeichnis und räumt es nach Abschluss auf. Keine produktive Datenbank darf geöffnet, kopiert oder verändert werden.

## 9. Weitere Persistenztests

Prüfe zusätzlich:

- neue leere In-Memory-Datenbank,
- neue leere dateibasierte Datenbank,
- Repository-Speichern und -Lesen,
- Repository-Update ohne Duplikat,
- deterministische Sortierung,
- Domain-Invarianten und Fehlerfälle,
- Mapping eines ungültigen persistierten Datensatzes,
- unveränderte vorhandene App-Regressionstests,
- Architekturgrenzen für Persistence.

Übersprungene Tests gelten nicht als bestanden.

## 10. Integrität und Rückfallgrenze

Dokumentiere:

- aktuelle Schemaversion,
- Legacy- und Zielchecksum beziehungsweise Entitystruktur, soweit SwiftData zugänglich,
- welche Änderung leichtgewichtig migriert wird,
- warum keine destruktive Migration vorliegt,
- Verhalten bei Migrationsfehlern,
- Grenzen eines Rollbacks.

P06 liefert Backups und Restore. Bis dahin sind nur additive, vollständig getestete Migrationen zulässig. P03 darf keinen automatischen Datenbank-Reset implementieren.

## 11. Architekturdokumentation

Aktualisiere:

- `Documentation/ARCHITECTURE.md`,
- `Documentation/ARCHITECTURE_CHANGES.md`,
- `Documentation/Architecture/ADRs/README.md`.

Erstelle:

`Documentation/Architecture/ADRs/ADR-0003_SwiftData-Schema-v1-und-Persistenzgrenze.md`

Das ADR enthält Kontext, Alternativen, Entscheidung, Datenwirkung, Migration, Rückfallgrenze, positive/negative Folgen und Folgeprompts.

Erstelle zusätzlich:

`Documentation/DATA_MODEL.md`

Die Datei enthält Legacy-Schema, Schema v1, Domainmodell, Mapping, Invarianten, Repository-Port und explizit verschobene MVP-Entitäten.

## 12. Build- und Prüfkommandos

Ermittle Targetgraph und Buildweg erneut. Führe mindestens aus:

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Dokumentiere echte Ausgaben, Warnungen, Fehler und nicht ausgeführte Prüfungen.

## 13. Dokumentationspflicht

Aktualisiere:

- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- `Documentation/IMPLEMENTATION_ROADMAP.md`,
- `Documentation/Prompts/README.md`,
- Architektur- und Datenmodelldokumentation.

## 14. Abschlussbericht

Erstelle:

`Documentation/Progress/Reports/YYYY-MM-DD_P03_Domaenenmodell-Schema-v1-und-Migrationen.md`

Der Bericht enthält zusätzlich:

- Legacy- und v1-Entitystruktur,
- Migrationsstufe,
- Datenwirkung,
- Repository-Grenze,
- Teststore-Aufbau,
- genaue Migrations- und Wiederöffnungsergebnisse,
- verbleibende direkte SwiftData-Zugriffe,
- Rollback- und Backupgrenzen.

## 15. Gesonderter Review

Führe nach Implementierung einen unabhängigen Review gemäß `Documentation/REVIEW_RULES.md` aus.

Der Review prüft besonders:

- vollständigen Targetgraphen,
- Feldgleichheit des Legacy-Schemas,
- Erhalt aller Legacy-Werte,
- keine produktive Datenbanknutzung in Tests,
- keine Store-Löschung oder leeren Fallback,
- Domain-/Persistence-Mapping,
- Repository-Upsert ohne Duplikate,
- keine vorgezogenen Fachentitäten,
- Build-, Test- und Dokumentationsnachweise.

## 16. Abnahmekriterien

P03 ist nur `✅ erledigt`, wenn:

- P03 vollständig spezifiziert und implementiert ist,
- Persistence als echter SwiftPM-Target existiert,
- Schema v1 und Migrationsplan explizit sind,
- Legacy-Store-Migration alle Werte nachweislich erhält,
- zweite Öffnung des migrierten Stores erfolgreich ist,
- leere In-Memory- und Dateidatenbanken getestet sind,
- Domain-Invarianten typisiert geprüft werden,
- Repository-Speichern, Lesen, Update und Sortierung getestet sind,
- persistente Modelle nicht mehr im App-Target definiert sind,
- App weiterhin baut,
- Debug- und Release-Build erfolgreich sind,
- alle relevanten Tests erfolgreich sind,
- Datenmodell-, Architektur- und Fortschrittsdokumentation vollständig sind,
- Abschlussbericht gespeichert ist,
- Review `✅ bestanden` meldet.

Andernfalls Status `⚠️ teilweise oder blockiert` oder `❌ fehlgeschlagen`.

## 17. Grenzen des Auftrags

Nicht Bestandteil:

- SDE-, Blueprint- oder Rezeptmodelle,
- Produktionsgraph und Berechnungsstufen,
- Lager, Bestand, Sicherheitsbestand und Reservierungen,
- Build-or-Buy,
- Preisprofile, Finanzkennzahlen und Einkaufsliste,
- Backup/Restore,
- zentrale Fehler-UI und Logging,
- Ausbau von SSO/ESI,
- UI-Redesign,
- Git-Reparatur oder Commit.

## 18. Abschlussausgabe

Gib kompakt aus:

- Prompt-ID und Status,
- Schema- und Persistence-Ergebnis,
- Migrationsnachweis,
- Repository-Ergebnis,
- Build und Tests,
- Reviewstatus,
- Abschlussbericht,
- offene Datenrisiken,
- nächsten empfohlenen Prompt.

## Erwartetes Ergebnis

Nach P03 besitzt New Eden Nexus ein explizites, versioniertes Schema v1, eine nachgewiesene Migration des bisherigen Stores, eine getrennte Persistence-Schicht und einen Domain-/Repository-Pfad für Produktionsprojekte. Spätere Entitäten können in eigenen Prompts über neue versionierte Schemata ergänzt werden.
