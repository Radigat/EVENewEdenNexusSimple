# P36 – Migration und Recovery-Drill

Status: **✅ erledigt – OFF-006 und OFF-024 abgenommen**

Der technische Backup-/Restore-Stand bleibt aktiv. Der vollständige
Prozessabbruch- und Recovery-Nachweis ist nicht Voraussetzung für den
internen Kernstand, aber weiterhin Voraussetzung vor einem öffentlichen
Release.

- **Zweck:** Upgrade, Backup, Restore und Fehlerwiederherstellung real prüfen.
- **Voraussetzungen:** P03, P06, P07B, P07C, P32.
- **Erwartetes Ergebnis:** dokumentierter End-to-End-Drill mit Integritätsvergleich.
- **SDE-Recoveryumfang:** Prozessabbruch beziehungsweise Fehler an den
  Übergängen Download, Entpacken, Stagingimport, Validierung und atomare
  Aktivierung prüfen. Zusätzlich zu injizierten Fehlern und den bereits
  vorhandenen Phasengrenzentests muss ein externer Abnahmeharness den
  tatsächlich laufenden Prozess an jeder persistenten Grenze abrupt beenden
  und danach dieselbe App-Composition mit demselben isolierten Store neu
  starten. Ein normaler Task-Abbruch, ein geworfener Testfehler oder nur der
  Neustart eines In-Process-Service erfüllt diesen Nachweis nicht. Nach jedem
  Szenario müssen der vorherige aktive SDE-Stand und sämtliche Benutzerdaten
  unverändert nutzbar sein; temporäre Artefakte und Rollbackversionen müssen
  einer dokumentierten Aufbewahrungsregel folgen.
- **Vor Ausführung ergänzen:** Alt-Schema-Fixture, SDE-Crashpunkte,
  Speicherplatz-/Schreibfehler, Integritätsvergleich, Cleanup- und
  Akzeptanzschwellen.

## Mit zu erledigende offene Punkte

- `OFF-006 / KI-006 / KI-013`: **✅ erledigt** – automatische
  Vor-Migrations-Sicherung, Store-Lebenszyklus, Restore-UI sowie
  Backup→Migration→Restore→Wiederöffnung mit Integritätsvergleich sind
  nachgewiesen. Downgrade bleibt nicht unterstützt.
- `OFF-024 / KI-024`: tatsächlichen Prozessabbruch/App-Neustart als
  verbliebenen Realnachweis des
  P07B-Recoverynachweises: isolierten App-/Store-Prozess von außen beenden,
  erneut starten und aktiven Build, Benutzerdaten, Journalabschluss,
  Rollbackfähigkeit und Cleanup prüfen.

## Nicht verhandelbarer Realabnahmenachweis

- Produktive Benutzerdaten und der normale Benutzerstore sind tabu.
- Crashpunkte sind nur in einem klar abgegrenzten Acceptance-/Debugpfad
  aktivierbar und dürfen nicht versehentlich im Releasebetrieb auslösbar sein.
- Der externe Koordinator protokolliert Prozess-ID, erreichte persistente
  Phase, Art des harten Abbruchs, Exitstatus und Neustartergebnis.
- Mindestens Download, vorbereitetes Archiv, laufendes Staging, validiertes
  Staging und Promotion werden mit echter Prozessbeendigung geprüft.
- Nach jedem Neustart werden Projekt-/Charakterfixtures, vorheriger Aktivbuild,
  Katalogabfrage, Journalzustand, Kandidatenreste, Backup und temporäre Dateien
  gegen feste Sollwerte verglichen.
- P36 darf bei ausschließlich simulierten In-Process-Fehlern nicht `✅`
  werden.

Der verbleibende Realabnahmenachweis betrifft ausschließlich `OFF-024`.
Die Erledigung von `OFF-006` ist kein Ersatz für den externen Prozess-Kill.

## Ausführungsspezifikation OFF-024

### Voraussetzungen und Sicherheitsgrenzen

- Verwendet werden nur der aktuelle Debug-Build, die versionierte synthetische
  SDE-Fixture und je Szenario ein neu angelegter temporärer Store.
- Der normale App-Store, produktive Backups, Netzwerk und CCP-Endpunkte werden
  nicht verwendet.
- Der Acceptance-Pfad ist ein expliziter Unterbefehl des getrennten
  `NewEdenNexusSDEAcceptance`-Executables. Die produktive App verdrahtet keinen
  Crashschalter.
- Der Koordinator beendet ausschließlich die von ihm gestartete und
  protokollierte Kindprozess-ID mit `SIGKILL`; kein `killall` oder `pkill`.

### Persistente Abbruchgrenzen

| Szenario | persistierte Phase | fachliche Grenze |
|---|---|---|
| 1 | `downloading` | Download begonnen |
| 2 | `validatingSource` | Archiv sicher vorbereitet |
| 3 | `validatingStagingStore` | isolierter Stagingimport begonnen |
| 4 | `creatingSafetyBackup` | Stagingstore validiert und erneut geöffnet |
| 5 | `promoting` | Sicherheitsbackup erstellt, Promotion steht bevor |

Ein nur für das Acceptance-Executable injizierter Beobachter signalisiert die
bereits atomar gespeicherte Phase und wartet. Der externe Koordinator prüft
Marker und PID, sendet `SIGKILL`, wartet den Signal-Exit ab und startet eine
frische Recovery-Composition mit demselben Szenariostore.

### Sollzustand nach jedem Neustart

- genau ein unterbrochenes Journal wird als `recovered` abgeschlossen,
- der vorherige SDE-Build bleibt der einzige aktive Build,
- eine feste Katalogabfrage des Altstands funktioniert,
- Charakter- und Projektfixture sind wertgleich vorhanden,
- Kandidatenzeilen sind verworfen und ein Rollback auf den Altbuild bleibt
  möglich,
- Download-, Handoff- und Staging-Artefakte der Operation sind entfernt,
- veröffentlichte unveränderliche `.nensde`-Pakete dürfen als diagnostischer
  Importbeleg verbleiben; `.partial`-Pakete sind unzulässig,
- vor `promoting` existiert kein SDE-Sicherheitsbackup; an `promoting` bleibt
  genau das zuvor erfolgreich erstellte und prüfbare Backup erhalten,
- der Koordinator entfernt nach erfolgreicher Prüfung sein gesamtes
  temporäres Szenarioverzeichnis.

### Fehler-, Abbruch- und Wiederholungsfälle

- fehlende/ungültige Argumente, fremde Fixture-Dateien, falsche Markerphase,
  vorzeitig beendeter Kindprozess und Timeout führen zu einem roten
  Abnahmeergebnis,
- Recovery ist anschließend idempotent: ein zweiter Neustart findet keinen
  weiteren offenen Vorgang und verändert keine Fixture,
- jeder der fünf Fälle beginnt mit einem neuen Store, sodass kein Ergebnis
  eines vorherigen Szenarios wiederverwendet wird.

### Messbare Abnahme

- fokussierte Tests beweisen, dass der Acceptance-Beobachter erst nach
  erfolgreicher Journalpersistenz aufgerufen wird,
- der externe Drill meldet fünf verschiedene PIDs, fünf `SIGKILL`-Exits und
  fünf erfolgreiche Neustart-/Integritätsprüfungen,
- SwiftPM-Debugbuild, vollständige SwiftPM-Tests, Xcode-Debugbuild und die
  relevanten Xcode-kompilierten Tests sind erfolgreich,
- Diff-, Sicherheits-, Datenintegritäts- und Dokumentationsreview bestehen,
- erst danach werden `OFF-024`, `KI-024` und P36 auf `✅` gesetzt.

## Ausführungsergebnis

Am 2026-07-26 wurden alle fünf Phasengrenzen mit fünf verschiedenen
Kindprozessen erreicht. Der Koordinator beendete ausschließlich die jeweils
protokollierte PID durch `SIGKILL` (Signalstatus 9) und startete danach eine
neue Recovery-Composition auf demselben isolierten Store.

Alle fünf Neustarts erhielten Altbuild, Katalogabfrage, Charakter- und
Projektfixture, terminalisierten genau ein Journal, verwarfen
Kandidatenreste, bestätigten Rollback und Aufbewahrungsregeln und waren beim
zweiten Recoverylauf idempotent. Sämtliche temporären P36-Wurzeln wurden
entfernt. Der Debug-App-Build und das Acceptance-Executable bauten mit Xcode;
SwiftPM bestand 527 Tests und der Xcode-kompilierte fokussierte Testbund
bestand 6 Tests. Die Scheme-Testorchestrierung konnte in der Codex-Sandbox
`testmanagerd` nicht erreichen; der direkte native Testbundlauf ist
erfolgreich dokumentiert.
