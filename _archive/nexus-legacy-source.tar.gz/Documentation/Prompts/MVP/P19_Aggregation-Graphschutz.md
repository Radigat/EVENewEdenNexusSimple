# P19 – Aggregation und Graphschutz

Status: **✅ erledigt**

## Zweck

Die in P13 bis P18 bewusst als einzelne Vorkommen gespeicherten
Materialblätter werden zu einer reproduzierbaren Materialübersicht
zusammengeführt. Gleichzeitig wird die bestehende Graphgrenze so gehärtet,
dass fehlerhafte, zu große oder manipulierte Graphen und überlaufende Summen
niemals gespeichert oder als gültige Berechnung angezeigt werden.

## Voraussetzungen

- P10: katalog- und versionsgebundener Rezeptresolver,
- P13: persistierter, erklärbarer Produktionsgraph,
- P14/P15: ganzzahlige Run-, Output-, ME- und Materialberechnung,
- P16/P17/P18: rekursive T1-, T2- und Reaktionsstufen,
- Graphformat 6 und Expansionsrichtlinie 3,
- additive SwiftData-Schemaversion 9,
- erfolgreicher P18-Build und dessen Testbasis.

## Erwartetes Ergebnis

- gleiche tatsächliche Endmaterialien werden ausschließlich nach stabiler
  CCP-Type-ID zusammengeführt,
- jede Summe bleibt über ihre einzelnen Graphvorkommen und den vollständigen
  Wurzelpfad erklärbar,
- Manufacturing- und Reaktionsmengen verwenden jeweils den bereits
  berechneten effektiven Kantenbedarf,
- Zwischenprodukte werden nicht zusätzlich als Endmaterial doppelt gezählt,
- Summenüberlauf bricht die Neuberechnung vor der Persistenz ab,
- Zyklen, fehlende oder doppelte Kanten, nicht erreichbare Knoten,
  unzulässige Tiefe, zu viele Knoten und inkonsistente Aggregationen werden
  sicher abgelehnt,
- das Ergebnis wird mit Formelversion in Graphformat 7 reproduzierbar
  gespeichert und in der Graphansicht dargestellt,
- Graphformate 1 bis 6 bleiben lesbar, gelten aber als veraltet.

## Risiken

- Doppelzählung von Zwischenprodukten zusätzlich zu ihren Rohmaterialien,
- Zusammenführung nach Name statt nach stabiler Type-ID,
- Vermischung unterschiedlicher Type-IDs mit gleichem Namen,
- stiller `Int64`-Überlauf bei großen Zweigsummen,
- Verlust der Erklärbarkeit durch eine reine, quellenlose Gesamtsumme,
- Akzeptanz manipulierter Aggregationspayloads,
- Stack- oder Speicherüberlastung durch unbeschränkte persistierte Graphen,
- unbeabsichtigte Änderungen an Projekten, SDE-Daten oder Schema 9.

## Verbindliche Fachregeln

### Aggregationsmenge

Aggregiert werden ausschließlich Knoten mit `kind == material`. Ein solcher
Knoten ist im aktuellen Graphformat ein tatsächliches Endmaterial und besitzt
genau eine eingehende Kante. Rezepttragende Ziel- und Zwischenproduktknoten
werden nicht in die Endmaterialsumme aufgenommen.

Die Vorkommensmenge ist:

1. bei einer Reaktionskante
   `reactionMaterialCalculation.effectiveQuantity`,
2. andernfalls
   `materialCalculation.effectiveQuantity`.

Es findet in P19 kein Bestandsabzug, kein Build-or-Buy-Netting, keine
Preisberechnung und keine Verrechnung von Produktionsüberschüssen zwischen
verschiedenen Vorkommen statt.

### Aggregationsschlüssel und Namen

Einziger fachlicher Aggregationsschlüssel ist die positive CCP-Type-ID.
Namen dienen nur Anzeige und Sortierung. Unterschiedliche normalisierte Namen
für dieselbe Type-ID gelten als inkonsistenter Graph und werden abgelehnt.
Gleiche Namen mit unterschiedlichen Type-IDs bleiben getrennte Positionen.

### Erklärbarkeit und Reihenfolge

Jede aggregierte Position speichert:

- Type-ID und kanonischen Namen,
- effektive Gesamtmenge,
- alle beitragenden Blattknoten,
- effektive Einzelmenge je Vorkommen,
- vollständigen Knotenpfad von der Wurzel bis zum Blatt.

Vorkommen werden nach stabiler Knoten-ID sortiert. Positionen werden
deterministisch nach einem POSIX-fallunabhängigen Namensschlüssel und
anschließend nach Type-ID sortiert.

### Überlaufregel

Alle Mengen sind positive `Int64`-Werte. Jede Addition verwendet
`addingReportingOverflow`. Bereits der erste deterministisch ermittelte
Überlauf bricht mit Type-ID und beteiligtem Blattknoten ab. Es wird weder
geklemmt noch auf Gleitkommazahlen ausgewichen. Ein zuvor gespeicherter Graph
bleibt unverändert.

### Graphschutz

Die bisherige Generierungsgrenze bleibt verbindlich:

- maximale Tiefe: 64,
- maximale Knotenanzahl: 25.000.

Dieselben Grenzen gelten nun auch beim Validieren geladener Payloads.
Zusätzlich bleiben zwingend:

- genau eine Wurzel und genau ein Zielknoten,
- keine eingehende Wurzelkante,
- genau eine eingehende Kante je Nichtwurzel,
- keine Selbstkante,
- gültige Kantenendpunkte,
- eindeutige Geschwister-Sortierreihenfolge,
- Tiefe des Kindes gleich Elterntiefe plus eins,
- vollständige Erreichbarkeit von der Wurzel,
- Zyklusfreiheit,
- begründete Materialblätter,
- typisierte Diagnosepfade für rekursive Rezeptzyklen und Materialblätter.

Die gespeicherte Aggregation wird bei jedem Laden aus dem validierten Graphen
neu berechnet und exakt mit dem Payload verglichen. Abweichungen gelten als
Manipulation oder inkompatible Berechnung.

## Architektur und Datenhaltung

- neue reine Domänenkomponente `ProductionGraphMaterialAggregator`,
- keine UI-, Repository- oder SwiftData-Abhängigkeit in der Berechnung,
- Graphformat 7 mit Aggregationsformel Version 1,
- Aggregation als Teil der bestehenden kanonischen Graphpayload,
- keine neue SwiftData-Spalte und keine Schemamigration,
- Schema 9 und Backupformat 9.0.0 bleiben unverändert,
- alte Payloads bleiben unverändert lesbar und werden nicht still
  nachberechnet.

## Benutzeroberfläche

Die Graphansicht zeigt zusätzlich:

- Anzahl zusammengeführter Materialtypen und Vorkommen,
- Name, Type-ID, Gesamtmenge und Vorkommenszahl je Position,
- aufklappbare Einzelvorkommen mit Menge und vollständigem Erklärpfad,
- einen verständlichen Hinweis bei alten Graphformaten ohne Aggregation.

Loading-, Empty-, Error-, Veraltet- und Abbruchzustände bleiben erhalten.
Die neue Übersicht ist per Tastatur und VoiceOver verständlich.

## Fehler- und Bestandsschutz

Die Neuberechnung darf nicht gespeichert werden bei:

- Summenüberlauf,
- inkonsistentem Namen derselben Type-ID,
- fehlender effektiver Vorkommensmenge,
- unvollständigem Erklärpfad,
- Zyklus oder fehlerhafter Kantenstruktur,
- Überschreitung von Tiefe oder Knotenlimit,
- manipuliertem Aggregationssnapshot,
- Cancellation oder Persistenzfehler.

Die Repository-Operation bleibt atomar. P19 verändert keine SDE-,
Projekt-, Bestands- oder Preisdaten.

## Mit zu erledigende offene Punkte

| ID | Konkrete Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | Materialblätter über T1-, T2- und Reaktionszweige nach Type-ID aggregieren und mit Erklärpfaden speichern/anzeigen. | gemischter Mehrzweig-Referenztest, deterministischer Roundtrip und UI-/Architekturtest |
| OFF-009 / KI-012 | `Int64`-Überlauf jeder Aggregationssumme typisiert erkennen; bestehenden Graphen bei Fehler erhalten. | Domain-Grenztest sowie Application-Bestandsschutztest |

Alle anderen aktiven Punkte aus `OFFEN.md` sind unabhängig oder späteren
Prompts zugeordnet und werden nicht vorgezogen.

## Testmatrix

### Domain

- leerer Graph ohne Materialblätter ergibt leere Aggregation,
- ein Materialvorkommen,
- gleiche Type-ID über Manufacturing-, T2- und Reaktionszweige,
- gleicher Name bei unterschiedlichen Type-IDs bleibt getrennt,
- gleiche Type-ID mit abweichendem Namen wird abgelehnt,
- Zwischenprodukte werden nicht doppelt gezählt,
- Pfade und Sortierung sind unabhängig von Eingabereihenfolge,
- Summe bis einschließlich `Int64.max`,
- Summenüberlauf oberhalb `Int64.max`,
- fehlende Kante, fehlende Menge und unvollständiger Pfad,
- Zyklus, Selbstkante, unerreichbarer Knoten, doppelte eingehende Kante,
  doppelte Geschwisterreihenfolge, Tiefe 65 und mehr als 25.000 Knoten.

### Application und Persistenz

- neu erzeugter Graph enthält Formelversion 1 und Aggregation,
- Aggregationsfehler speichert keinen Teilstand und erhält den Altgraphen,
- Graphformat-7-Roundtrip,
- manipulierte Aggregation wird beim Laden abgelehnt,
- Formate 1 bis 6 bleiben lesbar und veraltet,
- Cancellation vor Persistenz erhält den Altgraphen.

### UI und Regression

- Aggregationsübersicht und Erklärpfade werden dargestellt,
- alter Graph zeigt den Neu-erzeugen-Hinweis,
- VoiceOver-Beschriftungen und Tastaturfluss bleiben nutzbar,
- vollständige SwiftPM- und Xcode-Suites in Debug und Release,
- isolierter App-/Store-Smoke-Test mit Integritätsprüfung.

## Messbare Abnahmekriterien

P19 ist nur `✅ erledigt`, wenn:

1. die obigen Fachregeln zentral und deterministisch implementiert sind,
2. OFF-004/KI-003 und OFF-009/KI-012 nachweislich geschlossen sind,
3. gleiche Material-Type-IDs in einer Position zusammengeführt werden,
4. Zwischenprodukte nicht zusätzlich als Rohmaterial erscheinen,
5. jedes Vorkommen mit vollständigem Wurzelpfad erklärbar bleibt,
6. ein Summenüberlauf typisiert vor dem Speichern abbricht,
7. der bisherige Graph bei jedem Fehler unverändert bleibt,
8. gespeicherte Aggregationen beim Laden neu verifiziert werden,
9. Graphformat 7 und Formelversion 1 reproduzierbar persistieren,
10. Formate 1 bis 6 lesbar und als veraltet erhalten bleiben,
11. persistierte Tiefe und Knotenanzahl dieselben Grenzen wie die
    Generierung einhalten,
12. relevante Domain-, Application-, Persistenz-, UI- und
    Architekturtests erfolgreich sind,
13. SwiftPM und Xcode in Debug und Release tatsächlich erfolgreich sind,
14. ein isolierter App-/Store-Integritätstest erfolgreich ist,
15. Pflichtdokumentation, Review und Abschlussbericht aktualisiert sind.

## Nicht Bestandteil von P19

- lokale Bestände und Lager (P20–P22),
- Sicherheitsbestände und Reservierungen (P23–P25),
- Build-or-Buy (P26),
- Preise, Kosten und Einkaufsliste (P27–P31),
- Performanceoptimierung über die Schutzgrenzen hinaus (P34),
- spätere ESI-, Markt-, PI-, Corporation- oder Optimierungsfunktionen.

## Nächster geplanter Prompt

P20 – Lager und manuelle Bestände. P20 wird erst nach vollständiger
P19-Abnahme begonnen.
