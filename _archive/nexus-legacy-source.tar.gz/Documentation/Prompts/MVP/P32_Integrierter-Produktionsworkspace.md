# P32 – Integrierter Kernworkspace

Status: **✅ erledigt · 2026-07-25**

## Ziel

Die bereits vorhandenen Projekt-, Produktionsgraph-, Lager- und
P26-Dienste in einem kurzen End-to-End-Ablauf nutzbar machen.

## Voraussetzungen

- P11–P26 sind umgesetzt und reviewed.
- Der Projektgraph ist die einzige Quelle für Produktionsstufen.
- P26 liefert Produktions-/Inventionsjobs, Lagerabzug und Fehlmengen.
- Bestehende Benutzeränderungen und Future-Views bleiben unangetastet.

## Erwartetes Ergebnis

Ein projektbezogener, persistenzfreier SwiftUI-Workspace lädt oder erzeugt
den Graphen, zeigt Lager-/Schutz-/Reservierungswirkung, erlaubt Bauen/Kaufen
mit Vorschau und Bestätigung und kopiert ausschließlich positive Fehlmengen.

## Ablauf

1. Produkt und Menge wählen oder gespeichertes Projekt öffnen.
2. Produktionsgraph erzeugen/aktualisieren.
3. verwendbaren Lagerbestand samt Schutz, Reservierungen und Konflikten
   anzeigen.
4. Zwischenstufen auf Bauen oder Kaufen setzen.
5. Produktionsjobs, Inventionsjobs und fehlende Kaufmengen anzeigen.
6. Fehlmengen als einfache Textliste kopieren.

## Grenzen

Keine Preise, Kosten, Gewinne, Marktintegration, persistenter Einkaufsstatus,
CSV-Ausgabe, Optimierung oder UI-Neugestaltung. Vorhandene Komponenten und
Design Tokens werden wiederverwendet.

## Mit zu erledigende offene Punkte

- `OFF-008/KI-011`: nur produktive Views dieses Kernablaufs von direkten
  SwiftData-Zugriffen lösen; eingefrorene Future-Views bleiben P38.
- `OFF-011`: berechnete P26-Fehlmengen als einfache, deterministische
  Textliste kopierbar machen.
- Fehlende Loading-, Empty-, Error- und Konfliktzustände nur für diesen
  Ablauf ergänzen.

## Risiken und Schutz

- Projektwechsel, Abbruch oder veraltete Vorschau dürfen keine Entscheidung
  speichern; Schreibvorgänge bleiben Vorschau plus ausdrückliche Bestätigung.
- Lager, Sicherheitsbestände und Reservierungen dürfen nicht doppelt
  abgezogen werden; P26 bleibt alleinige Berechnungsquelle.
- Fehlende oder veraltete Graphen werden nicht durch Schätzwerte ersetzt.
- Direkte SwiftData-Nutzung wird nur aus produktiven P32-Views entfernt;
  SSO-/ESI-Zukunftscode bleibt P38.

## Abnahme

1. T1-Projekt mit Teilbestand zeigt korrekte Jobs und Fehlmengen.
2. T2-Projekt zeigt Fertigungs- und Inventionsjobs sowie Lagerabzug.
3. Bauen/Kaufen aktualisiert den Plan ohne Doppelzählung.
4. Projektwechsel oder Abbruch schreibt keinen falschen Zwischenstand.
5. schmale/breite Fenster, Tastaturpfad und wesentliche VoiceOver-Labels
   sind im geänderten Workflow geprüft.
6. fokussierte UI-/Integrationstests, `swift test` Debug und
   `xcodebuild test` Debug bestehen.
7. kurzer Abschlussbericht und Statusdeltas sind gespeichert.
8. `OFF-008` ist für Dashboard/Workspace und `OFF-011` für die einfache
   Textliste nachweisbar geschlossen; verschobene Anteile bleiben sichtbar.

P37 wird nicht begonnen.
