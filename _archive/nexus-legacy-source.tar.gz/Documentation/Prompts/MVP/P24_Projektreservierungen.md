# P24 – Projektreservierungen

Status: **✅ erledigt**

## 1. Zweck

P24 bindet vorhandene, nach P22 und P23 verwendbare Materialmengen
transaktional an ein Produktionsprojekt. Eine aktive Reservierung steht
anderen Projekten nicht mehr zur Verfügung. Der Benutzer kann eine
Reservierung anlegen, ihre gebundene Restmenge ändern, Material als
verbraucht verbuchen oder die Bindung ausdrücklich freigeben.

P24 beantwortet je Endmaterial:

- wie viel nach Sicherheitsbestand grundsätzlich reservierbar ist,
- wie viel andere Projekte bereits aktiv gebunden haben,
- wie viel das aktuelle Projekt bindet,
- wie viel danach frei bleibt,
- welcher Projektbedarf noch nicht reserviert ist.

## 2. Verbindliche Grundlagen

- aktueller Quellcode und P23-Abnahme,
- `AGENTS.md`,
- `Documentation/OFFEN.md`, insbesondere `OFF-005`,
- `Documentation/KNOWN_ISSUES.md`, insbesondere `KI-005`,
- `Documentation/INVENTORY_AVAILABILITY.md`,
- `Documentation/SAFETY_STOCK.md`,
- Projektbuch 8.7–8.8, 10.10–10.12, 11.24, A.9.2,
  A.13.1–A.13.2, A.34–A.36, C.37–C.39, Anhang E.9 sowie G.14,
- ADR-0025 bis ADR-0028.

## 3. Voraussetzungen

- P11: vorhandenes, nicht archiviertes Produktionsprojekt,
- P19: aktueller Graphformat-7-Endmaterialbedarf,
- P20/P21: lokaler aktiver Bestand,
- P22: aktuelle projektbezogene Bestandsfreigaben,
- P23: aktuelle globale Sicherheitsbestandsregeln.

Fehlt eine Voraussetzung, wird keine Reservation erzeugt oder verändert.

## 4. Scope

P24 umfasst:

- globale Type-ID-Reservierungen für ein konkretes Projekt,
- mehrere historische Reservierungen, aber höchstens eine aktiv bindende
  Reservierung je Projekt und Type-ID,
- positive Reservierungsmenge,
- Priorität 1 bis 3 und optionales Ablaufdatum,
- Status `reserviert`, `teilweise verwendet`, `verbraucht` und
  `freigegeben`,
- Anlage und Änderung einer aktiven Restmenge,
- teilweise und vollständige Verbrauchsbuchung,
- bestätigte Freigabe ohne automatische Bestandsänderung,
- Abzug aktiver Restmengen anderer Projekte,
- schreibfreie Vorschau, ausdrückliche Bestätigung und vollständigen
  Source-State-Schutz,
- atomare Mehrfachänderung,
- additives SwiftData-Schema v14 und Backupkompatibilität,
- native SwiftUI-Bedienung,
- deterministische Domain-, Application-, Persistenz-, Migrations- und
  UI-Prüfungen.

## 5. Abgrenzung

Nicht Teil von P24:

- automatische oder lagergenaue StockAllocation,
- Charakterzuordnung ohne vorhandene persönliche EVE-Daten,
- automatische Freigabe bei Ablauf,
- Reservierung von Zwischenprodukten außerhalb der Graphformat-7-
  Endmaterialaggregation,
- Überbuchung oder „trotzdem reservieren“,
- Erkennung und manuelle Auflösung bereits entstandener Konkurrenzkonflikte
  (P25),
- automatische Bestandskorrektur beim Verbrauch,
- Build-or-Buy und Einkaufsliste (P26/P30/P31),
- ESI-/Corporation-Bestände.

Die Reservierung ist global je Type-ID. P22-Lagerfilter dienen als
Validierungsbasis, werden aber mangels belegter Allokation nicht als
Lagerzuweisung gespeichert. Charakterwerte werden nicht mit Platzhaltern
gefüllt.

## 6. Fachmodell

### 6.1 StockReservation

Eine Reservierung besitzt:

- stabile UUID,
- `projectID`,
- positive `typeID`,
- `reservedQuantity` als ursprünglich beziehungsweise aktuell zugesagte
  Gesamtmenge,
- `consumedQuantity` zwischen null und `reservedQuantity`,
- Priorität 1 bis 3,
- optional `expiresAt`,
- Status,
- `createdAt` und `updatedAt`,
- optional `releasedAt` oder `consumedAt`.

```text
aktive Restmenge = reservedQuantity − consumedQuantity
```

Nur `reserviert` und `teilweise verwendet` binden eine positive Restmenge.
`verbraucht` und `freigegeben` sind terminal und binden null.

Zulässige Übergänge:

```text
reserviert → teilweise verwendet → verbraucht
reserviert → verbraucht
reserviert → freigegeben
teilweise verwendet → freigegeben
```

Eine Mengenänderung an einer aktiven Reservierung darf die bereits
verbrauchte Menge nicht unterschreiten. Nach einem terminalen Datensatz
kann eine neue Reservierung mit neuer UUID entstehen; Historie wird nicht
reaktiviert oder überschrieben.

Das Ablaufdatum ist informativ. Eine abgelaufene aktive Reservierung bleibt
gebunden und wird deutlich markiert, bis der Benutzer sie freigibt oder
verbraucht.

### 6.2 Reservierbare Menge

Für eine aktuelle P23-Materialzeile:

```text
andere aktive Reservierungen
  = Summe aktiver Restmengen derselben Type-ID
    ohne aktive Reservierung des aktuellen Projekts

freie Menge vor aktueller Projektreservierung
  = max(0, nach P23 verfügbare Menge − andere aktive Reservierungen)

maximal für aktuelles Projekt reservierbar
  = min(Projektbedarf, freie Menge vor aktueller Projektreservierung)

freie Menge nach Vorschlag
  = freie Menge vor aktueller Projektreservierung
    − vorgeschlagene aktive Restmenge

noch nicht reservierter Projektbedarf
  = Projektbedarf − vorgeschlagene aktive Restmenge
```

Alle Summen verwenden `Int64` und brechen bei Überlauf typisiert ab.
Eine neue oder erhöhte Reservierung oberhalb des Maximums wird nicht
automatisch gekürzt und nicht gespeichert.

P24 erzeugt noch keinen persistenten Konfliktstatus. Sinkt Bestand oder
ändert sich eine andere Quelle nach dem Commit, bleibt die vorhandene
Reservierung unverändert; die systematische Konflikterkennung und Auflösung
folgt P25.

## 7. Änderungsarten

Eine Vorschau enthält pro Type-ID höchstens eine Änderung:

- `reservieren(restmenge, priorität, ablaufdatum)`:
  aktive Reservierung anlegen oder ihre Restmenge ändern,
- `verbrauchen(menge)`:
  positive Teilmenge einer aktiven Reservierung verbuchen,
- `freigeben`:
  aktive Restmenge auf null setzen und Status terminal ändern.

Verbrauch und Freigabe ändern keine physischen P20/P21-Bestände. Ohne
lagergenaue Allocation wäre eine automatische Bestandskorrektur nicht
nachvollziehbar.

## 8. Anwendungs- und Schreibvertrag

### Vorschau

- liest die aktuelle P23-Vorschau,
- liest alle Reservierungen der betroffenen Type-IDs,
- validiert Projekt, Material, Status und Änderung,
- berechnet den vollständigen Stand,
- schreibt nichts.

### Bestätigtes Speichern

- verlangt ausdrückliche Bestätigung,
- liest P23 und alle betroffenen Reservierungen erneut,
- vergleicht Projekt, Graph, Lager, Bestände, P22-Konfiguration,
  Sicherheitsregeln und Reservierungsversionen,
- verwirft eine veraltete Vorschau ohne Teiländerung,
- validiert die Reservierbarkeit erneut,
- speichert alle vorgeschlagenen Änderungen atomar,
- gibt den bestätigten Stand zurück.

Cancellation vor dem Commit schreibt nichts. Nach erfolgreichem Commit wird
der Erfolg nicht fälschlich als Abbruch gemeldet.

## 9. Projektlebenszyklus

Ein archiviertes Projekt darf keine neue Reservierung anlegen oder erhöhen.
Das produktive Repository blockiert die Archivierung eines Projekts, solange
es eine aktive Restreservierung besitzt. Der Benutzer muss diese vorher
bestätigt freigeben oder verbrauchen. Historische terminale Reservierungen
bleiben erhalten.

Duplizieren eines Projekts dupliziert keine Reservierungen.

## 10. Persistenz und Migration

Schema v14 ergänzt `StockReservationRecord`. Eindeutige UUIDs sichern die
Historie; der Repositoryadapter erzwingt höchstens eine aktive Reservierung
je Projekt und Type-ID.

Nachweise:

- leichte Migration v13→v14,
- vollständige Legacy→v14-Kette,
- neue leere v14-Datenbank,
- zweite Öffnung,
- Roundtrip aller Status,
- optimistischer Konflikt,
- atomare Mehrfachänderung und Rollback,
- Archivschutz,
- Backups 1.0.0 bis 14.0.0 lesbar; 15.0.0 wird abgelehnt.

## 11. Benutzeroberfläche

Im Produktionsgraphen steht `Projektreservierungen` bereit.

Die Ansicht zeigt je Material:

- Bedarf,
- nach P23 verfügbare Menge,
- aktive Reservierungen anderer Projekte,
- aktuelle Projektreservierung,
- maximal reservierbare Menge,
- frei nach Vorschlag,
- noch nicht reservierten Bedarf,
- Priorität, Ablaufdatum und Ablaufwarnung,
- Status und bisher verbrauchte Menge.

Der Benutzer wählt pro Material `Reservieren/Ändern`, `Verbrauchen` oder
`Freigeben`. Erst eine aktuelle Detailvorschau erlaubt den konkret
beschriebenen Bestätigungsdialog. Leere, Loading-, Fehler-, geänderte
Vorschau-, Bestätigungs-, Abbruch- und Ablaufzustände sowie Tastatur- und
VoiceOver-Beschriftungen sind vorzusehen.

## 12. Mit zu erledigende offene Punkte

| ID | Restarbeit in P24 | Prüfnachweis |
|---|---|---|
| OFF-005 / KI-005 | Projektreservierungsanteil schließen: globale Projekt-/Type-ID-Bindung, Lebenszyklus, Abzug und Integrität. | Domainreferenztests, Application-Stale-/Abbruchtests, Persistenz-/Migrationstest, Archivschutz, UI-Architekturprüfung und vier Gesamtläufe. |
| OFF-006 / KI-006 / KI-013 | Additive v13→v14-Migration und Backupgrenze aktualisieren. | Altstore, Leerstore, zweite Öffnung und Backupversionsprüfung. |

`OFF-005/KI-005` bleibt nach P24 nur für die P25-Konflikterkennung und
-auflösung teilweise offen. Der Recovery-Drill aus `OFF-006` bleibt
unabhängig P36.

## 13. Tests

Mindestens:

- keine Reservierung: P23-Ergebnis bleibt unverändert,
- Anlage und Änderung einer aktiven Reservierung,
- andere Projekte reduzieren die reservierbare Menge,
- eigene aktive Reservierung wird beim Ändern nicht doppelt abgezogen,
- Überbuchung wird ohne automatische Kürzung abgelehnt,
- Prioritäts- und Ablaufvalidierung,
- Ablauf bindet weiter und erzeugt einen Hinweis,
- Teilverbrauch und vollständiger Verbrauch,
- Freigabe,
- terminale Historie wird nicht reaktiviert,
- doppelte aktive Reservierung wird abgelehnt,
- unbekanntes Material, Projekt und ungültiger Status,
- `Int64`-Summenüberlauf,
- Vorschau schreibt nicht,
- Bestätigung erforderlich,
- geänderter P23- oder Reservierungsstand,
- Repository-Rennen,
- Abbruch vor und nach Commit,
- atomare Mehrfachänderung und Rollback,
- Archivierung mit aktiver Reservierung blockiert,
- Projektduplikat erhält keine Reservierung,
- v13→v14, Leerstore und zweite Öffnung,
- Backupkompatibilität,
- UI-Schicht ohne SwiftData-Zugriff.

## 14. Risiken

- Globale Reservierungen können ohne StockAllocation keinen konkreten
  Lagerbestand benennen; P24 weist diese Grenze sichtbar aus.
- Bestandsänderungen nach einem Commit können eine bestehende Reservierung
  faktisch überbuchen; P25 erkennt und behandelt diesen Zustand.
- Verbrauch ohne automatische Bestandskorrektur verlangt eine separate
  manuelle Bestandsaktualisierung; andernfalls kann der physische Bestand
  vorübergehend zu hoch erscheinen.
- Ein Ablaufdatum darf niemals stillschweigend Material freigeben.

## 15. Abnahmekriterien

P24 ist nur `✅ erledigt`, wenn:

1. jede Reservierung Projekt und positive Type-ID eindeutig referenziert,
2. höchstens eine aktive Reservierung je Projekt/Type-ID existiert,
3. aktive Restmengen deterministisch berechnet werden,
4. Reservierungen anderer Projekte die freie Menge reduzieren,
5. eigene Reservierungen beim Ändern nicht doppelt abgezogen werden,
6. neue Überbuchung abgelehnt und nie automatisch gekürzt wird,
7. Anlage, Änderung, Teil-/Vollverbrauch und Freigabe funktionieren,
8. terminale Historie erhalten bleibt,
9. Priorität und Ablaufdatum validiert werden,
10. Ablauf keine automatische Freigabe auslöst,
11. Verbrauch keine unbelegte physische Bestandsmutation auslöst,
12. Vorschau keine Daten schreibt,
13. Speichern Bestätigung und aktuellen Source-State verlangt,
14. Mehrfachänderungen atomar erfolgen,
15. Cancellation vor Commit keinen Teilstand erzeugt,
16. ein erfolgreicher Commit als Erfolg zurückgegeben wird,
17. Archivierung bei aktiver Restreservierung blockiert ist,
18. Schema v14, Migration, Leerstore und zweite Öffnung bestanden sind,
19. Backups bis 14.0.0 kompatibel sind,
20. native UI den Reservierungsstand nachvollziehbar darstellt,
21. relevante neue und bestehende Tests bestanden sind,
22. SwiftPM und Xcode Debug/Release erfolgreich sind,
23. Pflichtdokumentation, Abschlussbericht und gesonderter Review
    abgeschlossen sind.

## 16. Prüfbefehle

```sh
swift build
swift test --filter ProjectReservation
swift test
swift test -c release
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Debug -destination platform=macOS \
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Release -destination platform=macOS \
  CODE_SIGNING_ALLOWED=NO test
git diff --check
```

## 17. Ergebnisgrenze

P24 endet nach Implementierung, Migration, vier grünen Build-/Testwegen,
Dokumentation und Review. P25 wird nicht begonnen.
