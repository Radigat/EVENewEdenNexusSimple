# P18 – Reaktionsstufen

Status: **✅ erledigt und reviewed am 2026-07-24**

## Zweck

P18 ersetzt die durch P16/P17 bewusst zurückgestellten Reaktionsblätter
durch rekursive, deterministische Reaktionsstufen. Reaktionsformeln werden
fachlich von Blueprints getrennt, erhalten keine Blueprint-ME oder
Blueprint-TE und verwenden einen expliziten, versionierten
Produktionskontext für neutrale oder durch Facility, Reactor, Rig,
Securitybereich und Skill modifizierte Planung.

P18 erweitert den in P17 angelegten gemeinsamen `IndustryRuleSet`. Die
fachliche Grundlage ist
[`INDUSTRY_RULES_FOUNDATION.md`](../../INDUSTRY_RULES_FOUNDATION.md).

## Voraussetzungen

- P10: deterministischer Resolver für `manufacturing` und `reaction`,
- P13–P16: Graphbasis, Runs, Materialberechnung und Rekursion,
- P17 vollständig implementiert und reviewed:
  - Tech-Klassifikation,
  - Blueprintqualität,
  - Industry-Regelbasis,
  - Graphformat 5,
  - SwiftData-Schema v8 und Graphformat 5,
- aktiver SDE-Katalog und dazu passendes `IndustryRuleSet`,
- aktuelle Verifikation der zeitabhängigen Reaction-, Facility-, Rig-,
  Security- und Skillregeln,
- vollständiger Audit von `OFF-004`, `OFF-021`, `OFF-028`, `KI-003`,
  `KI-021` und `KI-028`.

## Erwartetes Ergebnis

- Manufacturing-Materialien mit eindeutigem Reaktionsrezept werden zu
  Reaktionsknoten erweitert,
- Reaktion → Reaktion wird rekursiv aufgelöst,
- jede Reaktionsstufe besitzt Runs, tatsächliche Ausgabe und Überschuss,
- Material- und Zeitwerte tragen vollständige Kontext- und Regelprovenienz,
- Reaktionsformeln besitzen fachlich keine Blueprint-ME/TE,
- neutrales Basisszenario und modifizierter Reaktionskontext sind klar
  unterscheidbar,
- Facility, Reactor, Rig, Securitybereich und Reaktionsskill werden
  validiert,
- unbekannte oder nicht aktuell verifizierte Modifier blockieren eine
  scheinbar exakte Berechnung,
- alte Projekte und Graphformate bleiben lesbar und eindeutig veraltet,
- P18 bleibt klar vom vollständigen Reaktionsmanagement P43 abgegrenzt.

## Fachlicher Scope

### Enthalten

1. Aktivität `reaction` rekursiv in den Produktionsgraph integrieren.
2. Reaktionsformel, Manufacturing-Blueprint und Blueprintinstanz fachlich
   unterscheiden.
3. Reaktionsformel-Runs, Ausgabemenge und Überschuss mit der vorhandenen
   ganzzahligen P14-Logik berechnen.
4. Reaktionsmaterialien über alle notwendigen Reaktionsstufen auflösen.
5. Manufacturing → Reaction und Reaction → Reaction unterstützen.
6. Reaktionsart und benötigten Reactor deterministisch zuordnen.
7. Reaktionskontext modellieren:
   - neutrales Basisszenario,
   - Facility,
   - Reactor,
   - Rig beziehungsweise Rigs,
   - Securitybereich,
   - Reaktionsskill.
8. Material- und Zeitfaktoren zentral, versioniert und nachvollziehbar
   berechnen.
9. Stufenbezogene Kontextüberschreibungen ermöglichen; automatisch
   entdeckte Reaktionsstufen verwenden einen sichtbaren Projektstandard.
10. Bei fehlender verifizierter Modifierregel fail-closed oder ausdrücklich
    `needsReview`.

### Nicht enthalten

- Besitz, Standort oder Onlinezustand realer Spielerstrukturen,
- Fuelverbrauch und Service-Lifecycle,
- Jobslots, Warteschlangen, Kalender oder Kapazitätsplanung,
- System Cost Index, Steuern oder Jobkosten,
- Reaktionsbestände und Materialreservierungen,
- persönliche ESI-Industry-Jobs,
- Reaktorzugriffslisten oder Corporation-Rollen,
- vollständiges eigenständiges Reaktionsmanagement P43,
- Build-or-Buy P26,
- Aggregation gleicher Materialien P19,
- PI oder T3.

## Verbindliche Reaktionsregeln

### Formelart

- Reaktionsformeln besitzen unbeschränkte Runs.
- Sie können nicht erforscht, kopiert oder inventiert werden.
- Blueprint-ME und Blueprint-TE sind nicht anwendbar.
- Internes ME 0 / TE 0 ist nur technische Normalisierung und darf nicht als
  Forschungsstand angezeigt werden.

### Ausführungsbedingungen

- Reaktionen benötigen eine Refinery.
- Der zur Reaktionsart passende Reactor muss vorhanden und aktiv planbar
  sein.
- Reaktionen dürfen nur für Security `0.4` oder niedriger als ausführbar
  gelten.
- Mindestens Composite, Biochemical und Hybrid unterscheiden.
- Weitere aktuelle SDE-Reaktionsgruppen, insbesondere
  Molecular-Forged-Reaktionen, müssen vor Zuordnung gegen SDE und aktuelle
  CCP-/Clientdarstellung verifiziert werden.

### Basismaterial

```text
Rohbedarf = Basismenge je Run × benötigte Runs
```

Ohne Materialmodifier:

```text
Effektivbedarf = Rohbedarf
```

Mit verifiziertem Rigmodifier:

```text
Effektivbedarf =
    offizielle Rundungsregel(
        Rohbedarf
        × Rig-Materialfaktor
        × weitere verifizierte Reaktionsmaterialfaktoren
    )
```

Die exakte Reihenfolge und Rundung kombinierter Faktoren muss vor
Implementierung anhand einer aktuellen belastbaren CCP-/Clientgrundlage und
Golden Fixtures bestätigt werden. Die P15-Blueprint-ME-Formel darf nicht
als Reaktionsrigformel wiederverwendet werden, nur weil beide Materialien
reduzieren.

### Basiszeit

```text
Reaktionszeit =
    SDE-Basiszeit
    × Runs
    × Reactions-Skillfaktor
    × Facility-Zeitfaktor
    × Rig-Zeitfaktor
    × weitere verifizierte Faktoren
```

Der Skill `Reactions` reduziert die Dauer um vier Prozent je Stufe.

Im verifizierten SDE-Build `3444265`:

- Athanor: Facility-Zeitfaktor `1.0`,
- Tatara: Facility-Zeitfaktor `0.75`,
- T1-Reaktionsrig: Basis `−20 %` Zeit oder `−2 %` Material,
- T2-Reaktionsrig: Basis `−24 %` Zeit oder `−2.4 %` Material.

Diese Werte werden aus der SDE gelesen, nicht als ewige Konstante im
Fachcode dupliziert.

### Security-Modifikator

Der SDE-Dogma-Effekt `6976` modifiziert Reaktionsrigwerte über
`securityModifier`. Die konkreten Security-Bandwerte werden vor P18 gegen
eine aktuelle belastbare Quelle beziehungsweise den aktuellen Client
verifiziert. Historische Werte dürfen nicht ungeprüft fest codiert werden.

Kann die Regel nicht eindeutig verifiziert werden:

- modifizierter Kontext bleibt `needsReview`,
- nur das ausdrücklich gekennzeichnete neutrale Basisszenario darf
  berechnet werden,
- P18 darf nicht als vollständig genaue modifizierte
  Reaktionsberechnung `✅ erledigt` werden.

## SDE-Erweiterung

P18 ergänzt bedarfsgesteuert:

- relevante Refinery-Typen,
- Reactor-Service-Module,
- Reaktionsrigs,
- deren benötigte `typeDogma`-Werte,
- zugehörige `dogmaAttributes`,
- zugehörige `dogmaEffects`,
- Reaktionsgruppen- und Reactorzuordnung.

Mindestens benötigte Attribute beziehungsweise Wirkungen werden im
Implementierungsbericht itemgenau dokumentiert. Unbekannte oder entfernte
Attribute führen nicht zu Defaultwerten, die eine exakte Berechnung
vortäuschen.

Die P07-/P08-Sicherheits-, Speicher-, Aktivierungs- und
Referenzintegritätsgrenzen gelten unverändert. Kein Blindimport aller
Dogma- oder Universe-Daten.

## Fachmodelle

### `ReactionPlanningContext`

Mindestens:

- Modus `neutralBase` oder `modified`,
- Facility-Type-ID,
- Reactor-Type-ID,
- Rig-Type-IDs,
- Securityklassifikation,
- Reactions-Skillstufe,
- SDE- und Regelprovenienz.

### `ReactionMaterialCalculation`

Mindestens:

- Formelversion,
- Basismenge je Run,
- Runs,
- Rohbedarf,
- einzelne Materialfaktoren,
- Rundungsschritte,
- Effektivbedarf,
- Ersparnis,
- Regel- und Kontextprovenienz.

### `ReactionTimeCalculation`

Mindestens:

- Formelversion,
- SDE-Basiszeit,
- Runs,
- Skillfaktor,
- Facility-Faktor,
- Rig-Faktor,
- weitere Faktoren,
- Rundung,
- Effektivdauer in Sekunden,
- Regel- und Kontextprovenienz.

## Graph, Persistenz und Migration

- Neues Graphformat 6 für Reaktionsstufen und Produktionskontext.
- Expansionsrichtlinie erhält eine neue Version.
- Jeder Reaktionsknoten speichert:
  - Reaction-Formula-Type-ID,
  - Reaktionsart,
  - Reactorart,
  - Runs, Ausgabe und Überschuss,
  - Kontextreferenz,
  - Material- und Zeitformelversion,
  - vollständige Regel- und SDE-Provenienz.
- `reactionDeferred` wird nur ersetzt, wenn ein vollständiges gültiges
  Reaktionsrezept und ein gültiger Kontext vorliegen.
- Graphformate 1 bis 5 bleiben lesbar und gelten gegenüber Format 6 als
  veraltet.
- Das kataloggebundene Reaktionsregelprofil über eine additive
  Schema-v9-Migration speichern. Reaktionskontexte bleiben Bestandteil der
  bereits versionierten Graphpayload.
- v8→v9, vollständige Legacy→v9-Kette, zweite Öffnung und leeren v9-Store
  testen.
- Backupmanifest auf 9.0.0 anheben und Vorgänger 1.0.0 bis 9.0.0 prüfen.
- Existiert nach P17 eine andere tatsächlich belegte additive
  Schemaversion, ist die P18-Nummer vor Implementierung ohne Überspringen
  anzupassen und zu dokumentieren.

## Rekursion und Schutz

- Manufacturing → Reaction und Reaction → Reaction erzeugen
  vorkommensbezogene Knoten.
- Die P16-Zyklusprüfung arbeitet aktivitätsübergreifend auf dem vollständigen
  Vorfahrenpfad.
- Tiefe und globales Knotenbudget bleiben technische Schutzgrenzen.
- Gleiche Reaktionsmaterialien bleiben bis P19 getrennte Vorkommen.
- Katalog- oder Regelwechsel während der Traversierung bricht vor dem
  Speichern ab.
- Task-Cancellation wird an denselben Grenzen wie P16 respektiert.
- Run-, Material- und Zeitmultiplikationen sind überlaufgeschützt.

## Fehlerfälle

Mindestens typisiert behandeln:

- Reaktionsformel als BPO/BPC behandelt,
- Blueprint-ME oder Blueprint-TE für Reaktion ungleich neutral,
- fehlende oder mehrdeutige Reaktionsart,
- fehlender oder falscher Reactor,
- nicht zulässiger Securitybereich,
- ungültige Reactions-Skillstufe,
- fehlende Facility-/Rig-/Dogmawerte,
- unverifizierter Security-Modifikator,
- unvollständige Reaktionsreferenz,
- Reaction-/Manufacturing-Zyklus,
- SDE-/Regelwechsel,
- Run-, Material- oder Zeitüberlauf,
- Tiefe, Knotenbudget, Abbruch oder Persistenzfehler.

Ein Fehler erhält Projekt, vorhandenen Graphen und aktive SDE-Version.

## Agent-Preflight

P18 erweitert den P17-Preflight mindestens um:

1. Reaktionsformel besitzt ausschließlich zulässige Aktivität,
2. keine Blueprint-ME/TE wird angewendet,
3. Reaktionsart und Reactor sind eindeutig,
4. Facility-/Rig-/Security-/Skillwerte stammen aus passender Regel- und
   SDE-Version,
5. modifizierter Kontext enthält keine `needsReview`-Regel,
6. neutrale Ergebnisse sind ausdrücklich als Basiswerte markiert,
7. Material- und Zeit-Golden-Fixtures bestehen,
8. alle verbliebenen `reactionDeferred`-Blätter sind begründet.

`fail` oder `needsReview` verhindert den Status `✅ erledigt`.

## Referenzfälle

### RX-R1 – neutrale Einzelreaktion

- eine vollständige Reaktionsformel,
- mehrere Inputs,
- Basisruns und Output aus SDE,
- kein Blueprint-ME/TE,
- Rohbedarf gleich Effektivbedarf,
- neutrale Kontextkennzeichnung.

### RX-R2 – mehrstufige Reaktionskette

Manufacturing-Ziel → Reaktion A → Reaktion B → Rohmaterialien; Runs,
Outputs, Überschüsse und Tiefen stimmen je Vorkommen.

### RX-R3 – Tatara-Zeit

Gegenüber neutraler Facility wird der aus der aktuellen SDE gelesene
Tatara-Zeitfaktor angewendet und einzeln im Trace ausgewiesen.

### RX-R4 – Materialrig

T1- und T2-Materialrig verwenden die aktuellen SDE-Basiswerte und die
verifizierte Securityregel; Rundung wird durch festen Golden-Wert geprüft.

### RX-R5 – Zeitrig und Skill

Reactions-Skill `0...5`, Facility und Zeitrig werden multiplikativ und in
verifizierter Reihenfolge angewendet.

### RX-R6 – ungültige Ausführung

Highsec-Kontext, falscher Reactor oder unbekannter Modifier wird abgelehnt,
ohne vorhandenen Graphen zu ersetzen.

### RX-R7 – Formelgrenze

Forschungs-, Kopier- oder Inventionversuch sowie Blueprint-ME/TE für eine
Reaktionsformel wird fachlich abgelehnt.

### RX-R8 – aktiver Buildwechsel

Wechsel von SDE- oder Regelversion während der Traversierung bricht atomar
ab und erhält den Altgraphen.

## Abgrenzung zu P43

P18 liefert ausschließlich die für den Produktionsplaner notwendigen
Reaktionsstufen und Berechnungsprofile. P43 bleibt zuständig für:

- eigenständige Reaktionsprojekte und Bedienoberflächen,
- reale Strukturen und Standorte,
- Reactor-Servicezustand und Fuel,
- Slots, Kalender und Kapazitäten,
- Steuern, Kostenindex und Jobkosten,
- ESI-Jobabgleich,
- Corporation- und Zugriffsfragen.

P18 darf diese Funktionen nicht vorziehen; P43 darf umgekehrt die in P18
zentral implementierten Reaktionsformeln nicht duplizieren.

## Mit zu erledigende offene Punkte

| ID | Restarbeit in P18 | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | Reaktionsstufen auf der P17-T2-Graphbasis vollständig integrieren; Aggregation sichtbar P19 überlassen. | RX-R1 bis RX-R8, Graphformat-6- und Bestandsschutztests |
| OFF-021 / KI-021 | Minimale Facility-, Reactor-, Rig- und Reaction-Dogmadaten importieren und aktivieren. | Mapping-, Referenz-, Migration-, Speicher- und Real-SDE-Nachweis |
| OFF-028 / KI-028 | Gemeinsamen IndustryRuleSet und Preflight um verifizierte Reaktionskontexte erweitern. | Quellenstatus, Modifiertrace, Preflight- und Golden-Fixture-Nachweis |
| OFF-009 / KI-012 | Überlaufschutz für neue Reaktionsmaterial- und Zeitberechnungen nachweisen; Aggregationssumme bleibt P19. | Grenz- und Altgraph-Erhaltstests |

`OFF-006`/`KI-006`/`KI-013` werden nur für die additive Schema-v9-Migration
und Backup 9.0.0 bearbeitet. Der vollständige Recovery-Drill bleibt P36.
`OFF-027`/`KI-027` bleibt P34. P43-Funktionen bleiben bewusst verschoben.

## Automatisierte Tests

Zusätzlich zu RX-R1 bis RX-R8 mindestens:

- alle importierten Reaktionsgruppen und Reactorzuordnungen,
- unbekannte Molecular-Forged- oder neue Gruppen fail-closed,
- neutrale und modifizierte Kontext-Codable-Fälle,
- Rundungs-, Grenz- und Überlaufwerte,
- stufenbezogene Kontextstandards und Überschreibungen,
- Manufacturing-/Reaction-Mischzyklen,
- deterministische Wiederholung,
- P16-/P17-Limit-, Cancellation- und Resolverregressionen,
- Graphformat-1- bis -5-Kompatibilität und Format-6-Manipulationsschutz,
- Format-6-Persistenz und Stale-Erkennung,
- v8→v9, Legacy→v9, zweite Öffnung und leerer v9-Store,
- Backupkompatibilität 1.0.0 bis 9.0.0,
- UI-/ViewModel-/Accessibility- und Architekturgrenzen,
- offizieller Real-SDE-Lauf für Composite, Biochemical und Hybrid.

## Build und manuelle Prüfung

- SwiftPM Debug und Release,
- Xcode Debug und Release ohne Signingänderung,
- Xcode-Projektparität,
- isoliertes App-Binary mit eigenem Schema-v9-Store,
- `PRAGMA integrity_check`,
- keine produktiven Benutzerdaten öffnen oder verändern,
- visuelle oder VoiceOver-Prüfungen nur behaupten, wenn tatsächlich
  ausgeführt.

## Dokumentation

Mindestens aktualisieren beziehungsweise neu erstellen:

- `Documentation/INDUSTRY_RULES_FOUNDATION.md`,
- produktive Reaktionsregeldokumentation,
- SDE-Import, Datenmodell, Architektur und Produktionsgraph,
- ADR für Reaktionskontext, Formeln und Graphformat 6,
- Entwickler-Menü, Projektstatus, Feature-Matrix, Roadmap und Tagebuch,
- `OFFEN.md`, `OPEN_TASKS.md`, `KNOWN_ISSUES.md`, `TEST_HISTORY.md`,
- Promptregister,
- Abschlussbericht
  `Documentation/Progress/Reports/2026-07-24_P18_Reaktionsstufen.md`.

## Abnahmekriterien

P18 darf nur `✅ erledigt` werden, wenn:

1. Reaktionsstufen einschließlich Reaction → Reaction korrekt aufgelöst
   werden,
2. keine Reaktionsformel Blueprint-ME oder Blueprint-TE verwendet,
3. neutrale und modifizierte Ergebnisse eindeutig gekennzeichnet sind,
4. Facility-, Reactor-, Rig-, Security- und Skillregeln aktuell verifiziert
   und versioniert sind,
5. unbekannte oder `needsReview`-Modifier kein exaktes Ergebnis vortäuschen,
6. Industry-Preflight `pass` meldet,
7. Migration, Backup, Altgraphen und Benutzerdaten geschützt sind,
8. SwiftPM und Xcode Debug/Release erfolgreich sind,
9. alle relevanten Tests ohne Überspringen bestanden sind,
10. isolierter App-/Store-Smoke bestanden ist,
11. Pflichtdokumentation und Abschlussbericht gespeichert sind,
12. der gesonderte Review bestanden ist.

Andernfalls bleibt P18 `⚠️ teilweise oder blockiert`, `❌ fehlgeschlagen`
oder `⬜ offen`. P19 wird in diesem Arbeitspaket nicht implementiert.
