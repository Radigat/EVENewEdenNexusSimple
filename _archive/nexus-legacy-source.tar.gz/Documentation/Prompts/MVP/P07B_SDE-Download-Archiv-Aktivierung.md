# P07B – Sicherer SDE-Download, Archivprüfung und crashfeste Aktivierung

Status: **✅ erledigt – Real-SDE- und Low-Memory-Abnahme 2026-07-23 erfolgreich**

## 1. Zweck

Erweitere P07A um den vollständigen, offiziellen JSONL-Downloadpfad:
Download, sichere ZIP-Prüfung und -Extraktion, Streamingimport in eine
isolierte Staginggrenze, Qualitätsprüfung und atomare Aktivierung. Die bisher
aktive Version muss bei jedem Fehler nutzbar bleiben.

## 2. Voraussetzungen

- P06 bis P09 und P07A abgeschlossen,
- Updateverfügbarkeit und Schema-Gate sind grün,
- Projekteigentümer hat die in `CCP_COMPLIANCE.md` blockierenden persönlichen
  Entscheidungen getroffen,
- Git-/OFFEN-/Problemstatus und vorhandene Benutzeränderungen geprüft.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-019 / KI-019 | offiziellen Download, ZIP-Sicherheit, isolierten Streaming-Stagingstore, Promotion, Crash-Recovery und Updateprotokoll implementieren | Adapter-/Integrations-/Crash- und Real-SDE-Tests |
| OFF-006 / KI-013 | automatische Vor-Import-/Migrationssicherung nur soweit für sichere SDE-Promotion nötig verdrahten | Backup-, Wiederöffnungs- und Rollbacktest |
| OFF-016 / KI-016 | nicht aufgelöste Referenzen unverändert erhalten; keine automatische Reparatur | Qualitäts- und Regressionstest |

## 4. Offizielle Downloadgrenze

- URL ausschließlich aus validierter Buildnummer bilden:
  `https://developers.eveonline.com/static-data/tranquility/eve-online-static-data-<build>-jsonl.zip`
- keine Spiegel oder benutzerdefinierten Downloadhosts,
- URLSession-Download in ein eindeutiges privates temporäres Verzeichnis,
- HTTP-Status, erwartete MIME-Typen, Content-Length und tatsächlich geladene
  Größe prüfen,
- freien Speicher vor Download und Extraktion konservativ prüfen,
- Timeouts, Cachevalidatoren, Retryregeln und User-Agent aus P07A wiederverwenden,
- Abbruch löscht partielle Dateien kontrolliert.

## 5. ZIP-Sicherheit

Vor Extraktion jede Archivzeile prüfen:

- keine absoluten Pfade, `..`, leere oder normalisierungsmehrdeutige Pfade,
- keine symbolischen/harten Links oder Geräteobjekte,
- keine Pfade außerhalb des isolierten Zielverzeichnisses,
- erlaubte Endungen/Verzeichnisstruktur,
- begrenzte Eintragszahl, Einzelgröße, Gesamtgröße und Kompressionsrate,
- doppelte normalisierte Zielpfade ablehnen,
- verschlüsselte oder mehrteilige Archive ablehnen, sofern nicht ausdrücklich
  offiziell dokumentiert,
- nach Extraktion Dateityp und realen Pfad erneut prüfen.

Die gewählte Archivbibliothek beziehungsweise Systemgrenze wird begründet,
lizenzgeprüft, injizierbar und mit bösartigen Fixtures getestet. Kein
unkontrollierter Shell-Aufruf.

## 6. Isolierter Import und Promotion

1. Download und Extraktion bleiben außerhalb des aktiven Stores.
2. P07-Prüfung läuft auf dem isolierten Verzeichnis.
3. Mapping schreibt blockweise in einen eigenen temporären Stagingstore oder
   eine gleichwertig isolierte, nicht aktive Datenbank.
4. Parser-/Importschema-Version wird gespeichert.
5. Vollständige Referenz-, Mindestmengen- und Plausibilitätsprüfung erfolgt im
   Stagingstand.
6. Nur ein vollständig verstandener Stand darf `ready` werden.
7. Promotion in den lokalen Katalog ist wiederaufnehmbar oder atomar; der
   Aktivmarker wechselt erst nach vollständiger finaler Prüfung.
8. Bei Fehler/Abbruch/Crash bleibt die alte aktive Version unverändert.
9. Unvollständige Staging-/Promotionsstände werden beim nächsten Start erkannt
   und sicher bereinigt oder fortgesetzt.
10. Mindestens die unmittelbar vorherige aktive Version bleibt als Rollback.

Das vorhandene v3-Verhalten wird nicht unkontrolliert ersetzt. Eine notwendige
Schemaänderung benötigt Migration, Backup und Datenwirkungstest.

## 7. Datenqualität

Mindestens prüfen:

- Kategorien, Gruppen, Typen und Blueprints nicht leer,
- Mengen im erwartbaren Verhältnis zum zuletzt erfolgreichen offiziellen
  Stand; Schwellen müssen begründet und konfigurierbar sein,
- Gruppen/Kategorien konsistent,
- Blueprinttyp vorhanden,
- Material-/Produkttypen vorhanden oder ausdrücklich als offizielle
  Referenzlücke klassifiziert,
- Aktivitätsart, Zeit, Menge und Wahrscheinlichkeit gültig,
- Build, Archiv-URL, Dateihashes, Parser- und Importschema-Version konsistent,
- keine Vermischung unterschiedlicher Builds.

## 8. Updateprotokoll

Persistiere strukturiert:

- Start/Ende und Phasen,
- lokale und angefragte Buildnummer,
- offizielle URL,
- HTTP-/Cacheentscheidung,
- Downloadgröße,
- Archiv-/Schema-/Datenqualitätsbefunde,
- Datensatzanzahlen,
- Import- und Aktivierungsdauer,
- Abbruch/Fehlercode,
- Cleanup-/Rollbackergebnis,
- aktivierte Buildnummer.

Kein Token, Secret, Charakter-/Accountname oder vollständiger lokaler Pfad.

## 9. Tests

Mindestens:

- erfolgreicher offizieller-URL-Download über Stub,
- Abbruch, Timeout, falscher Status, falsche Größe, zu wenig Speicher,
- beschädigtes ZIP, Zip-Slip, absolute Pfade, Symlink, Duplikat,
  Bombenverhältnis und unerwartete Datei,
- gültige große JSONL-Datei ohne Gesamtmaterialisierung,
- unbekanntes Zusatzfeld,
- fehlendes Pflichtfeld/veränderter Typ,
- Staging-Transaktionsabbruch,
- Crashsimulation nach jeder Phasengrenze,
- Aktivierungsfehler und Wiederöffnung,
- alter Katalog bleibt abfragbar,
- Charaktere, Projekte und sonstige vorhandene Benutzerdaten bleiben
  byte-/wertgleich,
- Rückfall auf vorherige Version,
- Temp- und Teilartefakte kontrolliert bereinigt,
- vollständiger aktueller offizieller Build einmal manuell/opt-in außerhalb
  des normalen Tests importiert und erneut geöffnet.

## 10. Nicht Bestandteil

- inkrementeller Import als alleiniger Pfad,
- ESI-Aufrufe,
- blinder Import aller SDE-Dateien,
- Einstellungs-/Rechts-UI aus P07C,
- Löschung der letzten Rollback-Version.

`changes/<build>.jsonl` darf als Optimierung vorbereitet werden; ein
vollständiger Neuimport bleibt immer verfügbar und getestet.

## 11. Dokumentation

Aktualisiere SDE-Architektur, Datenquellen, Import-/Updateablauf,
Datenmodell/Feldmapping, Fehler-/Rollbackkonzept, Testbericht,
Entwickleranleitung für neue Datensätze und alle Pflichtstatusdateien.
Erstelle ADR und Abschlussbericht
`YYYY-MM-DD_P07B_SDE-Download-Archiv-Aktivierung.md`.

## 12. Definition of Done

P07B ist nur `✅`, wenn Download ausschließlich offiziell, ZIP-Verarbeitung
defensiv, Import isoliert und streamingfähig, Promotion crashfest,
Rollback/Wiederöffnung nachgewiesen, Benutzerbestand unverändert,
Updateprotokoll vollständig, aktueller Realstand geprüft, Debug/Release grün
und Review bestanden ist.

P07C oder P10 dürfen nicht automatisch begonnen werden.

## Abschlussnachweis 2026-07-23

Status: `✅ erledigt`.

Mapping, isoliertes Staging und Promotion arbeiten zeilen- beziehungsweise
batchweise. Debug und Release bestanden jeweils 153 Tests. Zwei vollständige
Importe des offiziellen Builds 3444265 ergaben identische Fachdaten und
identischen Inhaltshash bei 952.057.856 beziehungsweise 948.125.696 Bytes
maximalem RSS. Abschlussbericht:
[P07B-Speichergrenze](../../Progress/Reports/2026-07-23_P07B_Speichergrenze.md).
