# P57 – Produktionsbuch-Domäne und Persistenz

Status: ✅ einschließlich Eigentümer-Neustarttest OFF-059 erledigt

## Ziel

Tatsächlich ausgeführte Produktionschargen getrennt vom veränderbaren
Projektplan erfassen. Jede Charge bleibt nach späteren Planneuberechnungen
reproduzierbar und kann anschließend Kosten, Verkäufe und Analysen tragen.

## Voraussetzungen

- OFF-055 und OFF-054 abgeschlossen,
- P11–P19, P40 und P55 unverändert nutzbar,
- aktuelles Schema, Migration, Backup- und Restorepfad geprüft,
- vorhandene Benutzeränderungen und OFF-056 erneut kontrolliert.

## Erwartetes Ergebnis

Eine lokale, versionierte `ProductionBatch`-Domäne mit Repository,
Anwendungsservice, Vorschau-vor-Schreiben und nativer Tabellen-/Detailansicht.

## Domänenumfang

Eine Charge enthält mindestens:

- UUID und pro Kalenderjahr eindeutige fortlaufende Anzeigenummer,
- Projekt-ID sowie gebundene Plan-, Graph-, Regel- und SDE-Version,
- Produktions-/Abschlussdatum und Status,
- Produkt-Type-ID, Namenssnapshot und Aktivitätsart,
- Runs, ME, TE und tatsächliche Output-Units,
- optional Charakter, Blueprintinstanz und ESI-Industry-Job,
- System sowie optional Station, Facility oder Struktur,
- Quellenidentitäten, Erstellungs- und Änderungszeit.

Statuswerte: `geplant`, `produziert`, `imVerkauf`, `abgeschlossen`,
`archiviert`. Unbekannte Namen und Quellen bleiben aufgelöst/unaufgelöst
unterscheidbar; Werte werden nicht erfunden.

## Anwendungs- und UI-Ablauf

1. Projekt oder bestehenden ESI-Industry-Job auswählen.
2. Vorschau mit übernommenen und fehlenden Feldern anzeigen.
3. Benutzer ergänzt oder korrigiert Datum, ME/TE, Output und Ort.
4. Stale Projekt-/Job-/Katalogversion vor dem Schreiben ablehnen.
5. Erst nach ausdrücklicher Bestätigung atomar speichern.
6. Tabelle nach Jahr, Produkt, Projekt, Charakter, Ort und Status filtern.

Namen stehen im Vordergrund; technische IDs erscheinen nur in Details und
Diagnose. Zeilen müssen per Tastatur und VoiceOver bedienbar sein.

## Persistenz und Migration

- additive neue SwiftData-Schemaversion,
- transaktionale Jahresnummer ohne Doppelvergabe,
- keine rückwirkend erfundenen Chargen aus alten Projekten oder Jobs,
- Altbestand, leere Datenbank, Backup/Restore und Neustart testen,
- produktive Migration erst nach geprüfter Vorschau und Sicherheitsbackup,
- Abbruch oder Fehler lässt das alte Schema weiterhin nutzbar.

## Preisgrenze

P57 berechnet und lädt keine Preise. Eine Charge darf nur Quellenidentitäten
und den gebundenen Planstand vorbereiten. Preisquotes und Kosten gehören P58;
realisierte Walletwerte gehören P59.

## Nicht-Ziele

- keine Kosten- oder Gewinnberechnung,
- keine Wallet-/Transaktionszuordnung,
- keine Diagramme oder Metenox-Berechnung,
- keine automatische Erzeugung aus jedem historischen ESI-Job.

## Mit zu erledigende offene Punkte

- OFF-056: neue Produktionsbuchbasis schaffen, ohne die zurückgezogene
  P42-Oberfläche wieder einzublenden.

## Tests

- eindeutige Jahresnummer bei parallelen Schreibversuchen,
- ungültige/überlaufende Runs, Units, ME und TE,
- stale Projekt-, Job- und SDE-Version,
- manuelle und ESI-vorbelegte Charge,
- Vorschau verwerfen, Abbruch, Neustart und Recovery,
- Altbestandmigration, leere Datenbank und Backup/Restore,
- Sortierung, Filter, Empty-/Error-State und Accessibility.

## Messbare Abnahme

- fokussierte Domänen-, Service-, Persistenz- und UI-Tests grün,
- vollständiger SwiftPM-Testlauf und Xcode-Debugbuild grün,
- bestehende Projekte, Budgets, Wallets und SDE-Daten nach Migration erhalten,
- realer Eigentümertest: Charge anlegen, App neu starten, unverändert öffnen,
- Dokumentation, Feature-Matrix, OFFEN, Testhistorie und Bericht aktualisiert,
- gesonderter Review entscheidet abschließend über den Status.

## Abschlussnachweis

OFF-059 wurde am 2026-07-29 real bestanden: Charge `2026-0001` für Rhea in
UALX-3 wurde nach Vorschau und Bestätigung gespeichert, der App-Prozess
vollständig beendet und dieselbe Charge nach Neustart unverändert wieder
geöffnet. 24/24 fokussierte und 695/695 vollständige Tests sowie der signierte
Xcode-Debugbuild bestanden. P58 wurde nicht begonnen.
