# P37 – Interne Kernabnahme

Status: **✅ erledigt · 2026-07-25**

## Zweck

Den reduzierten Produktions-/Inventionskern mit festen synthetischen Daten
als intern nutzbaren Stand nachweisen. P37 ergänzt keine neue Fachfunktion
und erzeugt ausdrücklich keinen öffentlichen Release Candidate.

## Voraussetzungen

- P11–P26 und P32 sind umgesetzt und reviewed.
- Schema/Backupformat v15/15.0.0 sowie die vorhandenen Repository-Ports
  bleiben unverändert.
- Projekt, Graph, Lager, Schutz, Reservierungen und Bauen/Kaufen werden über
  die vorhandenen produktiven Dienste geprüft.
- Die Prüfung verwendet ausschließlich isolierte temporäre Stores.

## Erwartetes Ergebnis

Ein reproduzierbarer Abnahmenachweis belegt:

1. eine mehrstufige T1-Kette mit Teilbestand,
2. eine T2-Kette mit Invention, Komponente und Bauen/Kaufen,
3. identische Projekte, Graphen, Entscheidungen und Planmengen nach
   Wiederöffnung desselben isolierten Stores,
4. positive Fehlmengen und erklärbare Reservierungskonflikte.

## Nicht-Ziele

Keine Preise, Gewinne, Markt-/ESI-Daten, CSV-Einkaufsexporte,
Performanceprogramme, Recovery-Drills, Signing-, Distributions- oder
Releasearbeiten. Keine produktiven Benutzerdaten und keine realen SDE- oder
Netzwerkzugriffe.

## Mit zu erledigende offene Punkte

- `OFF-011`: den vorhandenen Kernanteil mit T1/T2, Lager, Bauen/Kaufen und
  positiven Fehlmengen end-to-end nachweisen; P27–P31 bleiben verschoben.
- Alle aktiven Einträge aus `OFFEN.md` erneut prüfen. Unabhängige
  Release-, Recovery-, Performance-, Future- und Compliancepunkte dürfen
  nicht als durch P37 erledigt gelten.
- Keine weitere offene Aufgabe blockiert die interne Kernabnahme. Entsteht
  ein Kernblocker, bleibt P37 `⚠️` oder `❌`.

## Pflichtszenarien und Sollwerte

### A – T1

- Zielmenge 1, Zwischenproduktbedarf 10, Zwischenproduktausgabe 2 pro Run.
- Lager: 4 Zwischenprodukte und 5 Rohmaterialien.
- Erwartet: Ziel- und Zwischenjob, drei Zwischenruns, Rohbedarf 9,
  Lagerverwendung 5, Fehlmenge 4.

### B – T2/Invention

- Zielmenge 10, zwei erfolgreiche Inventionskopien mit je zwei Datacores.
- Eine baubare Komponente wird ausdrücklich auf **Kaufen** gesetzt.
- Lager: 1 Komponente und 1 Datacore.
- Erwartet: Zieljob, ein Inventionsjob, gespeicherte Kaufentscheidung,
  Komponentenfehlmenge 9 und Datacore-Fehlmenge 3; der gekaufte Unterbaum
  erzeugt keinen zusätzlichen Produktionsjob.

### C – Wiederöffnung

- Beide Projekte, Graphen, Lagerwerte und die T2-Kaufentscheidung werden in
  einem temporären Schema-v15-Store gespeichert.
- Nach Schließen und erneutem Öffnen liefern beide Planungen exakt dieselben
  Jobs, Mengen, Entscheidungen und Fehlmengen.

### D – Fehler-/Konfliktpfad

- Fehlmengen bleiben positive, deterministische Bedarfspositionen.
- Ein Bestandskonflikt nennt Grund, beteiligte Projekte, Prioritäten,
  notwendige Reduktion und Vorschläge; eine Vorschau schreibt nichts.

## Daten- und Abbruchschutz

- Temporäre Stores werden nach Erfolg oder Fehler kontrolliert entfernt.
- Keine Arbeit am Standardstore und keine Änderung an produktiven Daten.
- Kein Commit, Push, Signing oder Upload.
- Ein fehlgeschlagener Test, Build, App-Start oder eine nicht reproduzierbare
  Menge verhindert `✅`.

## Prüfplan

1. persistente P37-Integrationsabnahme für A–C,
2. fokussierte Workspace-, Build-or-Buy- und Konflikttests für A–D,
3. vollständiges `swift test -c debug`,
4. Xcode-Debug-Testlauf über das App-Scheme,
5. isolierter App-Start mit absolutem temporärem Store,
6. Xcode-Projektparität und `git diff --check`,
7. separater Review von Tests, Ergebnissen und Dokumentation.

## Messbare Abnahme

- alle Sollwerte A–D sind automatisiert belegt,
- Wiederöffnung liefert für beide Projekte identische Pläne,
- SwiftPM- und Xcode-Debug-Testläufe bestehen ohne übersprungene Tests,
- isolierter App-Prozess startet und wird kontrolliert beendet,
- keine durch P37 verursachte kritische oder hohe Regression bleibt offen,
- verschobene Punkte bleiben sichtbar und unverändert zugeordnet,
- Abschlussbericht bezeichnet das Ergebnis ausschließlich als
  **interner Kernstand**.

Scheitert ein Kriterium, bleibt P37 `⚠️` oder `❌`.
