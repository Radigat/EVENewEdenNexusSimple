# P29 – Kosten, Gewinn und ROI

Status: **✅ erledigt · 2026-07-26**

## Zweck

Den gespeicherten Produktions-/Inventionsplan mit einem lokalen Preisprofil
zu einer deterministischen, erklärbaren Projektwirtschaftlichkeit verbinden.
P29 berechnet Cash- und wirtschaftliche Materialkosten, manuelle Jobkosten,
Gesamtkosten, erwarteten Erlös, Gewinn, Marge, ROI und Break-even.

## Voraussetzungen

- P26/P32: reproduzierbarer Build-or-Buy-Plan mit Lagerabzug,
- P27/P28: exakte manuelle oder importierte ISK-Preise,
- Schema v17, Migrationen und Backupformat 17.0.0,
- aktive Produktionsgraph- und Preisprofil-Provenienz.

## Verbindlicher Umfang

1. Ein Projekt kann ein Preisprofil und nichtnegative manuelle Jobkosten
   speichern.
2. Die Berechnung verwendet ausschließlich den aktuellen
   Build-or-Buy-Plan:
   - `requiredQuantity` bewertet den vollständigen wirtschaftlichen
     Materialeinsatz einschließlich Lagerbestand,
   - `missingQuantity` bewertet nur den neuen Cash-Materialbedarf,
   - gekaufte Zwischenprodukte und Inventionsmaterialien werden wie andere
     Bedarfszeilen über ihre Type-ID bewertet,
   - Überschussausgabe wird nicht als zusätzlicher Verkaufserlös erfunden.
3. Der Profilpreis des Zielprodukts ist der erwartete Verkaufspreis je
   Zieleinheit.
4. Manuelle Jobkosten umfassen in P29 alle zusätzlich eingegebenen
   Produktions-, Reaktions-, Inventions- und sonstigen Jobkosten als eine
   nachvollziehbare Sammelposition. Automatische ESI-/SCI-/Gebührenwerte
   bleiben verschoben.
5. Fehlende oder zum Stichtag ungültige Material- beziehungsweise
   Zielproduktpreise werden einzeln angezeigt und blockieren vollständige
   Kennzahlen. Sie gelten niemals stillschweigend als 0 ISK.
6. Änderungen werden zuerst als Vorschau berechnet und erst nach
   ausdrücklicher Bestätigung gespeichert.
7. Gespeichert wird nur die Projektkonfiguration, nicht eine veraltbare
   Ergebniszahl. Die Kennzahlen werden aus aktuellem Plan und aktuellen
   Profilpreisen reproduzierbar neu berechnet.

## Formeln und Rundung

Alle Geldwerte werden als ganzzahlige ISK-Hundertstel mit geprüfter
Überlaufarithmetik berechnet.

```text
Cash-Materialkosten =
  Σ(missingQuantity × unitPrice)

Wirtschaftliche Materialkosten =
  Σ(requiredQuantity × unitPrice)

Cash-Gesamtkosten =
  Cash-Materialkosten + manuelle Jobkosten

Wirtschaftliche Gesamtkosten / eingesetztes Kapital =
  wirtschaftliche Materialkosten + manuelle Jobkosten

Erwarteter Verkaufserlös =
  Zielmenge × Zielproduktpreis je Einheit

Erwarteter Gewinn =
  erwarteter Verkaufserlös − wirtschaftliche Gesamtkosten

Marge =
  erwarteter Gewinn ÷ erwarteter Verkaufserlös × 100

ROI =
  erwarteter Gewinn ÷ eingesetztes Kapital × 100

Break-even gesamt =
  wirtschaftliche Gesamtkosten

Break-even je Zieleinheit =
  ceil(wirtschaftliche Gesamtkosten ÷ Zielmenge)
```

Marge und ROI werden deterministisch auf einen Basispunkt
(0,01 Prozentpunkte) gerundet. ROI ist bei 0 ISK eingesetztem Kapital
`nicht definiert`, nicht 0 %. Negative Gewinne und Kennzahlen bleiben
sichtbar. Die Break-even-Einheit wird auf das nächste ISK-Hundertstel
aufgerundet, damit die Zielmenge die Gesamtkosten mindestens deckt.

## Datenmodell und Architektur

- neue reine Domainberechnung ohne SwiftUI-/SwiftData-Abhängigkeit,
- Application-Service verbindet Plan, Preisauflösung und bestätigte
  Konfiguration,
- neues Schema v18 mit höchstens einem Economics-Datensatz je Projekt,
- v17→v18-Lightweight-Migration und Backupformat 18.0.0,
- Optimistic Locking schützt vor veralteten Konfigurationsständen,
- UI bleibt SwiftData-frei und wird in den Produktionsworkspace integriert.

## Mit zu erledigende offene Punkte

- `OFF-011`/`FIN-001`/`FIN-002`: ausschließlich Kosten, Erlös, Gewinn,
  Marge, ROI und Break-even schließen; P30/P31 bleiben für den erweiterten
  Einkaufsworkflow offen.
- Referenztests für vollständige, fehlende, negative, Null- und
  Überlauffälle ergänzen.
- Schema-, Backup-, Architektur- und Recovery-Dokumentation auf v18/18.0.0
  aktualisieren.

## Nicht Bestandteil

- Live-Marktpreise, ESI, Wallet oder reale Transaktionen,
- Brokergebühren, Verkaufssteuern, Transportkosten und System Cost Index,
- Budgetierung, historische oder realisierte Gewinne,
- Gewinn pro Slot-Stunde/Tag,
- automatische Inventionsfehlversuche oder Erfolgswahrscheinlichkeitskosten,
- persistente Einkaufslisten, Mengenänderungen und CSV-Export aus P30/P31.

## Tests

Mindestens:

- T1- und T2-/Inventionsplan mit Lager- und Kaufanteil,
- Cash- gegenüber wirtschaftlicher Bewertung,
- Gewinn- und Verlustfall,
- Marge/ROI und Rundungsgrenzen,
- ROI bei 0 ISK Kapital,
- fehlender Material- und Zielproduktpreis,
- leere Bedarfsmenge und ungültige Planzeile,
- arithmetischer Überlauf,
- Vorschau ohne Schreibvorgang, Bestätigung und Abbruch,
- veraltete Konfiguration beziehungsweise gelöschtes Preisprofil,
- v17→v18-Migration, Leerstore, Wiederöffnung und Backup 18.0.0,
- UI-Zustände für vollständig, unvollständig, Laden, Fehler und Verlust.

## Messbare Abnahmekriterien

- sämtliche Formeln sind zentral, versioniert und referenzgetestet,
- jede Materialkostenzeile nennt Menge, Einheitspreis, Cash- und
  wirtschaftliche Kosten,
- fehlende Preise sind vollständig sichtbar und blockieren Kennzahlen,
- Speicherung erfolgt erst nach Vorschau und Bestätigung,
- bestehende Projekt-, Lager-, Reservierungs-, Build-or-Buy- und
  Preisdaten bleiben bei Migration und Wiederöffnung erhalten,
- SwiftPM- und Xcode-Debug-Build sowie alle relevanten Tests bestehen,
- Pflichtdokumentation, Feature-Matrix, Tagebuch und Abschlussbericht sind
  aktualisiert,
- der gesonderte Review entscheidet abschließend über P29.

Scheitert ein Kriterium, bleibt P29 `⚠️` oder `❌`. P30 wird nicht
automatisch begonnen.
