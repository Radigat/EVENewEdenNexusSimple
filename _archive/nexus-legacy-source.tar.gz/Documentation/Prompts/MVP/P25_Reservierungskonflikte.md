# P25 – Reservierungskonflikte

Status: **✅ erledigt**

Abnahme: 2026-07-25 · SwiftPM/Xcode Debug und Release jeweils 423 Tests ·
Review bestanden · [Abschlussbericht](../../Progress/Reports/2026-07-25_P25_Reservierungskonflikte.md)

## 1. Zweck

P25 erkennt Reservierungskonflikte auf der in P22 bis P24 geprüften
Bestands- und Reservierungsbasis, erklärt ihre Ursachen und ermöglicht eine
kontrollierte manuelle Auflösung.

P25 beantwortet für ein Produktionsprojekt:

- Welche Materialreservierungen übersteigen den aktuell verwendbaren
  Bestand?
- Welche Projekte und aktiven Bindungen konkurrieren um dieselbe Type-ID?
- Welche Prioritäten und Restmengen sind betroffen?
- Welche aktive Bindung gehört nicht mehr zum aktuellen Projektbedarf?
- Welche Reduktionen oder Freigaben lösen alle sichtbaren Konflikte?
- Ist die geprüfte Vorschau beim Schreiben noch aktuell?

## 2. Fachliche Grundlage

Verbindliche Quellen:

- Projektbuch 10.10 bis 10.12,
- Projektbuch 28.4.12,
- Projektbuch A.13.1, A.35.4, A.36 und A.47,
- `Documentation/PROJECT_RESERVATIONS.md`,
- `Documentation/SAFETY_STOCK.md`,
- `Documentation/INVENTORY_AVAILABILITY.md`,
- ADR-0027 bis ADR-0029,
- tatsächlicher P24-Quellcode.

Das Projektbuch fordert:

- aktive Reservierungen dürfen den verwendbaren Bestand nicht
  überschreiten,
- bei Überschreitung darf kein Datensatz stillschweigend angepasst werden,
- konkurrierende Projekte, jeweilige Bindung, Projektpriorität und mögliche
  Restmenge müssen sichtbar sein,
- Reservierungsänderungen müssen atomar erfolgen.

## 3. Voraussetzungen

P25 setzt voraus:

- P11-Projekte und Projektprioritäten,
- P19-Type-ID-Aggregation,
- P22-Projektverfügbarkeit und Ausschlüsse,
- P23-Sicherheitsbestände,
- P24-Reservierungen, Lebenszyklus und Schema v14,
- zentrale Fehlerbehandlung, Tests und Dokumentationsstruktur.

P24 ist vollständig abgenommen. P26 wird nicht begonnen.

## 4. Umfang

P25 umfasst:

- deterministische Konfliktanalyse je aktuellem Projekt,
- Bestandskonflikte bei Überschreitung der P23-Restmenge,
- verwaiste Bindungen für nicht mehr benötigte Projektmaterialien,
- Anzeige aller aktiven beteiligten Reservierungen,
- Anzeige von Projekt- und Reservierungspriorität,
- stabile Sortierung und erklärbare Restmengenvorschläge,
- schreibfreie Auflösungsvorschau,
- manuelle Reduktion oder Freigabe beteiligter Bindungen,
- atomare Mehrprojektauflösung,
- ausdrückliche Bestätigung,
- vollständigen Source-State- und Repository-Stale-State-Schutz,
- Abbruch und sichere Fehlerbehandlung,
- native macOS-UI im Produktionsgraphworkflow,
- Tests, Dokumentation und gesonderten Review.

## 5. Ausdrücklich nicht Teil von P25

- automatische Kürzung oder Freigabe,
- Erhöhung einer Reservierung,
- lager- oder assetgenaue Allokation,
- Charakter- oder Corporation-Zuordnung,
- automatische Prioritätsentscheidung,
- automatische Konfliktauflösung beim App-Start,
- Hintergrundbenachrichtigungen,
- Build-or-Buy,
- Einkaufsliste,
- ESI- oder Marktintegration,
- Schemaänderung oder neues Persistenzmodell.

## 6. Konfliktbegriffe

### 6.1 Aktive Bindung

Eine Reservierung bindet Bestand, wenn ihr P24-Status `reserved` oder
`partiallyConsumed` ist. Maßgeblich ist ihre positive Restmenge:

```text
Restbindung = reservierte Gesamtmenge − verbrauchte Menge
```

Terminale Einträge `consumed` und `released` sind Historie und nehmen nicht
an der Konfliktanalyse teil.

### 6.2 Bestandskonflikt

Für eine Type-ID im aktuellen P22-/P23-Scope:

```text
Aktive Gesamtbindung =
  Summe aller aktiven Restbindungen derselben Type-ID

Konfliktfehlmenge =
  max(0, Aktive Gesamtbindung − Verfügbar nach Sicherheitsbestand)
```

Ist die Konfliktfehlmenge positiv, sind alle aktiven Reservierungen dieser
Type-ID beteiligte Bindungen. Die Bewertung gilt ausdrücklich im aktuellen
P22-Lager-/Material-/Mengen-Scope des geöffneten Projekts.

### 6.3 Nicht mehr benötigte Bindung

Besitzt das aktuelle Projekt eine aktive Reservierung für eine Type-ID, die
im aktuellen Graphformat-7-Endmaterialbedarf nicht mehr vorkommt, entsteht
ein Konflikt `nicht mehr benötigt`.

Diese Bindung darf nicht unsichtbar weiter Bestand blockieren. Sie wird
angezeigt und kann reduziert oder freigegeben werden.

### 6.4 Bedarfsüberschuss

Übersteigt die aktive eigene Restbindung den aktuellen Projektbedarf, wird
der Überschuss ebenfalls als Konflikt ausgewiesen. Dadurch bleiben
Zielmengen- oder Graphänderungen nachvollziehbar.

### 6.5 Ablauf

Ein abgelaufenes P24-Ablaufdatum bleibt eine Warnung, aber ist allein kein
Reservierungskonflikt. Die Bindung bleibt aktiv, bis der Benutzer sie
reduziert, verbraucht oder freigibt.

## 7. Priorität und Restmengenvorschlag

P25 trifft keine automatische fachliche Entscheidung. Es erzeugt nur einen
deterministischen, erklärbaren Vorschlag.

Beteiligte Bindungen werden sortiert nach:

1. Reservierungspriorität aufsteigend (`1` ist hoch),
2. Projektpriorität aufsteigend,
3. Erstellungszeitpunkt,
4. Projekt-UUID,
5. Reservierungs-UUID.

Die im aktuellen Projektscope verfügbare Menge wird in dieser Reihenfolge
rein für den Vorschlag verteilt. Jede Bindung erhält:

```text
Vorgeschlagene Restmenge =
  min(aktuelle Restbindung, noch nicht vorgeschlagene verfügbare Menge)
```

Der Vorschlag:

- verändert keine Daten,
- darf vom Benutzer abgelehnt oder angepasst werden,
- darf eine Bindung nie erhöhen,
- ist keine Optimierungsentscheidung,
- wird in der UI als Vorschlag gekennzeichnet.

Für eine nicht mehr benötigte eigene Bindung ist der Vorschlag `0`, also
Freigabe.

## 8. Auflösungsaktionen

Zulässig sind ausschließlich:

- `reduce`: aktive Restmenge auf eine positive, kleinere Menge setzen,
- `release`: aktive Restmenge vollständig freigeben.

Nicht zulässig:

- unveränderte oder höhere Menge,
- negative Menge,
- Änderung einer terminalen Bindung,
- Änderung einer nicht am Konflikt beteiligten Bindung,
- zwei Entscheidungen für dieselbe Reservierungs-ID.

Verbrauch bleibt P24 und ist keine P25-Konfliktauflösung.

## 9. Konfliktvorschau

Die erste Vorschau ist vollständig schreibfrei und enthält:

- aktuelles Projekt,
- aktuellen Graph- und P22-/P23-Source-State,
- alle relevanten aktiven Reservierungen,
- beteiligte Projekte mit Name und Priorität,
- Konflikte vor einer Auflösung,
- vorgeschlagene Restmengen,
- optional vom Benutzer gewählte Auflösungen,
- Konflikte nach den gewählten Auflösungen,
- geänderte Reservierungssnapshots,
- vollständiges Quellzustand-Token.

Eine Auflösung darf nur bestätigt werden, wenn nach der Vorschau kein
sichtbarer Konflikt mehr besteht.

## 10. Source-State und Parallelität

Der Source-State umfasst mindestens:

- P22-/P23-Quellzustand,
- Graph-ID,
- alle relevanten Reservierungs-IDs und `updatedAt`-Werte,
- alle beteiligten Projekt-IDs und `updatedAt`-Werte.

Vor dem Schreiben werden alle Quellen erneut geladen. Jede Abweichung führt
zu `stalePreview`. Der Repositoryadapter prüft die Reservierungsversionen
direkt vor dem atomaren Save erneut.

Ein veralteter Vorschlag verändert keine Daten.

## 11. Atomare Datenwirkung

Alle bestätigten Reduktionen und Freigaben eines Auflösungsvorschlags werden
in einem Repository-Schreibvorgang gespeichert.

Bei Fehler, Abbruch vor dem Commit oder Stale-State:

- keine Teilauflösung,
- keine automatische Ersatzentscheidung,
- bestehende Reservierungen bleiben unverändert.

Ein Abbruch nach erfolgreichem Commit darf den gespeicherten Erfolg nicht
als fehlgeschlagen darstellen.

## 12. Persistenz und Schema

P25 ergänzt kein neues SwiftData-Modell und keine Schema-v15-Stufe.

Begründung:

- Der Konfliktzustand ist aus aktuellem Bestand, P22/P23-Regeln und
  Reservierungen abgeleitet.
- Ein persistierter `Conflict`-Marker könnte nach Bestands- oder
  Regeländerungen veralten.
- P24-Status und Historie bleiben die persistente Lebenszyklusquelle.

Schema v14 und Backupformat 14.0.0 bleiben unverändert. Das Projektbuch-
Konzept `Active → Conflict` wird als berechneter Konfliktzustand umgesetzt,
nicht als zweiter persistenter Lebenszyklusstatus.

## 13. Benutzeroberfläche

Im Produktionsgraphworkflow entsteht eine separate Ansicht
`Reservierungskonflikte`.

Sie zeigt mindestens:

- Loading-, Empty-, Fehler- und Abbruchzustand,
- Anzahl Konflikte und betroffene Type-IDs,
- Bewertungsscope des geöffneten Projekts,
- Materialname und Type-ID,
- Konfliktgrund,
- verwendbaren Bestand,
- aktive Gesamtbindung,
- Konfliktfehlmenge,
- beteiligte Projekte,
- Projekt- und Reservierungspriorität,
- aktuelle und vorgeschlagene Restmenge,
- abgelaufene Bindungen als zusätzliche Warnung,
- Aktion `Beibehalten`, `Reduzieren` oder `Freigeben`,
- Schaltfläche `Vorschläge übernehmen`,
- schreibfreie `Auflösung prüfen`,
- bestätigten atomaren Apply,
- sichtbaren Hinweis, dass physische Bestände unverändert bleiben.

Die UI kennt keine SwiftData-Modelle.

## 14. Barrierefreiheit und Bedienung

Berücksichtigt werden:

- Tastaturbedienung,
- VoiceOver-Beschriftungen für Material, Projekt, Priorität und Menge,
- verständliche Einheiten und lokalisierte Zahlen,
- keine reine Farbcodierung,
- lange Projekt- und Materialnamen,
- schmale und breite Fenster,
- große Konfliktlisten über Scrollbereiche,
- deaktivierter Apply bei ungelöstem oder veraltetem Vorschlag.

## 15. Fehlerbehandlung

Neue stabile Operationen:

- Konflikte laden/prüfen,
- Konfliktauflösung speichern.

Mindestens behandelt werden:

- Projekt nicht gefunden oder archiviert,
- fehlender aktueller Graph/P22/P23-Stand,
- ungültige oder doppelte Entscheidung,
- unbekannte oder nicht beteiligte Reservierung,
- Erhöhung statt Reduktion,
- ungelöste Konflikte,
- veraltete Vorschau,
- Repository-Rennen,
- Ganzzahlüberlauf,
- Abbruch,
- Persistenzfehler.

Rohfehler und lokale Pfade gelangen nicht in die UI oder Logs.

## 16. Determinismus und Performance

- Konflikte werden stabil nach normalisiertem Materialnamen und Type-ID
  sortiert.
- Teilnehmer werden nach der Prioritätsregel aus Abschnitt 7 sortiert.
- Alle Mengensummen verwenden geprüfte `Int64`-Addition.
- Große Konfliktlisten werden nicht auf dem Main Thread berechnet.
- Performancebehauptungen erfolgen nur nach Messung.
- P25 führt keinen ungezielten SDE- oder ESI-Zugriff aus.

## 17. Mit zu erledigende offene Punkte

| ID | Restarbeit in P25 | Prüfnachweis |
|---|---|---|
| OFF-005 / KI-005 | Nachträglich entstandene Überbuchungen und verwaiste aktive Bindungen erkennen, konkurrierende Projekte/Prioritäten erklären und ausschließlich kontrolliert auflösen. | Domain-, Service-, Repository-, UI- und End-to-End-Tests; danach OFF-005/KI-005 erneut prüfen. |

`OFF-006/KI-006/KI-013` bleibt unabhängig P36 zugeordnet, weil P25 weder
Schema noch Backupformat ändert. Alle übrigen aktiven Punkte in
`Documentation/OFFEN.md` wurden geprüft und sind keine P25-Voraussetzung.

## 18. Automatisierte Tests

### Domain

- kein Konflikt bei Gesamtbindung gleich verfügbarer Menge,
- Bestandskonflikt mit mehreren Projekten,
- `Int64`-Überlauf,
- deterministische Prioritäts- und UUID-Reihenfolge,
- Projekt- und Reservierungspriorität,
- teilweise mögliche Restmenge,
- nicht mehr benötigte Bindung,
- Bedarfsüberschuss,
- abgelaufen allein ist kein Konflikt,
- terminale Reservierungen werden ignoriert.

### Application

- Laden ist schreibfrei,
- Vorschlag verändert keine Daten,
- Reduktion und Freigabe,
- keine Erhöhung,
- keine nicht beteiligte Reservierung,
- keine doppelte Entscheidung,
- ungelöste Vorschau nicht speicherbar,
- ausdrückliche Bestätigung erforderlich,
- geänderter P22/P23-, Projekt- oder Reservierungszustand,
- Abbruch vor Commit,
- Abbruch nach Commit,
- atomare Mehrprojektauflösung,
- anschließende Vorschau konfliktfrei.

### Persistenz

- projektbezogene Reservierungsabfrage einschließlich verwaister Type-ID,
- atomare Reduktion mehrerer Projekte,
- Repository-Stale-State ohne Teilwirkung,
- unbekanntes oder archiviertes Projekt,
- Historie und verbrauchte Menge bleiben erhalten,
- Schema v14 bleibt aktuelle Version,
- zweite Store-Öffnung.

### UI und Architektur

- Konfliktansicht ohne SwiftData,
- erforderliche Texte und Bedienelemente,
- Loading-, Empty-, Fehler-, Warn- und Bestätigungszustände,
- Apply nur bei konfliktfreier aktueller Vorschau,
- Abbruch laufender Aufgaben.

## 19. Manuelle Prüfung

Mit einem ausschließlich isolierten Store:

1. App starten,
2. Schema-v14-Store und Reservierungstabellen prüfen,
3. Konfliktansicht öffnen, soweit Testdaten vorhanden,
4. leeren Konfliktzustand nachvollziehen,
5. Prozess kontrolliert beenden,
6. `PRAGMA integrity_check` vor und nach dem Lauf prüfen.

Produktive Benutzerdaten dürfen nicht als Testbestand verwendet werden.

## 20. Risiken

- Unterschiedliche P22-Lagerscopes verschiedener Projekte besitzen ohne
  StockAllocation keine gemeinsame physische Zuordnung. P25 kennzeichnet
  deshalb den aktuellen Projektscope sichtbar und erfindet keine
  Lagerallokation.
- Prioritäten begründen nur einen Vorschlag. Sie lösen keinen Konflikt
  automatisch.
- Ziel- oder Graphänderungen können aktive Bindungen verwaisen lassen.
- Eine Bestands- oder Regeländerung kann nach einer Vorschau einen neuen
  Konflikt erzeugen; Source-State-Schutz verhindert dann das Schreiben.

## 21. Dokumentationspflicht

Zu aktualisieren sind mindestens:

- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- `Documentation/TEST_STRATEGY.md`,
- `Documentation/ARCHITECTURE.md`,
- `Documentation/ARCHITECTURE_CHANGES.md`,
- `Documentation/PROJECT_RESERVATIONS.md`,
- ADR-Register und neuer P25-ADR,
- P25-Abschlussbericht.

## 22. Abnahmekriterien

P25 ist nur `✅ erledigt`, wenn:

1. Bestandskonflikte deterministisch erkannt werden,
2. verwaiste eigene Bindungen erkannt werden,
3. Bedarfsüberschüsse erkannt werden,
4. terminale Bindungen nicht als Konflikt zählen,
5. Ablauf allein nur warnt,
6. konkurrierende Projekte, Mengen und Prioritäten sichtbar sind,
7. Restmengenvorschläge reproduzierbar sind,
8. Vorschläge keine Daten verändern,
9. ausschließlich Reduktion und Freigabe zulässig sind,
10. keine automatische Kürzung erfolgt,
11. keine Erhöhung möglich ist,
12. ungelöste Konflikte nicht gespeichert werden,
13. Bestätigung erforderlich ist,
14. Mehrprojektauflösung atomar ist,
15. Stale-State keine Teilwirkung verursacht,
16. Abbruch sicher behandelt wird,
17. Schema v14 und Backupformat unverändert bleiben,
18. UI-Zustände und Accessibility-Grenzen umgesetzt sind,
19. relevante fokussierte Tests bestanden sind,
20. SwiftPM Debug und Release bestanden sind,
21. Xcode Debug und Release bestanden sind,
22. isolierter App-Start und Storeintegrität bestanden sind,
23. Pflichtdokumentation aktualisiert ist,
24. Abschlussbericht gespeichert ist,
25. gesonderter Review bestanden ist,
26. `OFF-005/KI-005` erneut nachweisbasiert bewertet ist,
27. P26 nicht begonnen wurde.

## 23. Abschlussgrenze

P25 endet nach Implementierung, vier grünen Build-/Testwegen, isoliertem
App-Start, Dokumentation und gesondertem Review. P26 wird nicht begonnen.
