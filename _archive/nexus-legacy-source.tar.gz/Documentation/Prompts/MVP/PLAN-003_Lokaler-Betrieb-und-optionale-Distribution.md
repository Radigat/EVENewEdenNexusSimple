# PLAN-003 – Lokaler Betrieb und optionale Distribution

Status: ✅ erledigt

## Ziel

Die gesamte Projekt- und Promptsteuerung auf lokale Eigennutzung als
verbindliches Betriebsziel ausrichten. Öffentliche Apple-Distribution wird
als letztes optionales Zukunftspaket eingeordnet und blockiert den lokalen
Produktionsplaner nicht.

## Voraussetzungen

- P00 bis P37 und REL-001 bleiben als historische Nachweise erhalten.
- Vorhandene Benutzeränderungen werden nicht verworfen.
- Es werden keine Signing-, Team-, Bundle-ID- oder App-Store-Einstellungen
  geändert.
- Keine fachliche App-Funktion und kein P38-Zukunftscode wird implementiert.

## Umfang

- lokale Eigennutzung auf dem Eigentümer-Mac als aktuelles Ziel festlegen,
- `Release`-Buildkonfiguration von öffentlicher Veröffentlichung abgrenzen,
- App Store, öffentliche Direktverteilung, Signing, Hardened Runtime und
  Notarisierung aus MVP-/DoD-Gates entfernen,
- OFF-020 und OFF-032 als optionale P48-Aufgaben verschieben,
- P48 nach P47 als letztes optionales Zukunftspaket ergänzen,
- Projektbeschreibung, Roadmap, Entwickler-Menü, Promptregister,
  Feature-Matrix, Status und offene Punkte konsistent aktualisieren,
- historische Prüfberichte nicht rückwirkend umdeuten.

## Nicht-Ziele

- kein App Store Connect,
- keine Zertifikate oder Provisioning Profiles,
- kein Archive-, Upload- oder Notarisierungsvorgang,
- kein öffentlicher Release,
- kein P38–P48-Implementierungsbeginn,
- keine Code-, Schema- oder Benutzerdatenänderung.

## Messbare Abnahme

- AGENTS.md nennt lokalen Betrieb als verbindliches Ziel,
- Projektbeschreibung und Roadmap enthalten eine optionale letzte Stufe F,
- Entwickler-Menü und Promptregister führen P00 bis P48,
- P48 besitzt eine klar als Entwurf markierte Promptdatei,
- OFF-020/OFF-032 blockieren den lokalen Betrieb nicht,
- lokale Build-/Testnachweise bleiben unverändert wahr,
- `git diff --check` und Dokumentpfadprüfung sind erfolgreich,
- Abschlussbericht ist gespeichert.

## Ergebnis

Der lokale Betriebsmodus ist verbindlich. Öffentliche Apple-Distribution
bleibt als P48 zuletzt optional und wird nur auf ausdrücklichen Auftrag
aktiviert.
