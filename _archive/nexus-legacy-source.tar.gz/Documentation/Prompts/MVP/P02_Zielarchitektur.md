# P02 – Zielarchitektur und Modulgrenzen

Status: **✅ erledigt**

## Projekt

Arbeite im geöffneten lokalen Repository für:

**New Eden Nexus – Assets, Industry, Markets**

Dieser Auftrag schafft die belastbare technische Architektur für den reduzierten Produktionsplaner-MVP. Er darf bestehendes Verhalten kontrolliert refaktorieren, implementiert aber keine neue fachliche App-Funktion.

## Zweck

Der derzeitige Ein-Target-Ist-Stand koppelt SwiftUI, SwiftData, Fachmodelle, SSO, Keychain und eine Python-Prozessgrenze. P02 soll daraus eine nachvollziehbare, kompilierbare und schrittweise erweiterbare Architektur mit durchsetzbaren Abhängigkeitsregeln machen.

Nach P02 müssen spätere Prompts Domänenlogik, Anwendungsfälle, Persistenz und externe Adapter ergänzen können, ohne Fachlogik erneut in Views oder Infrastruktur zu vermischen.

## Voraussetzungen

- P00 und P01 sind mit Abschlussbericht abgeschlossen.
- `AGENTS.md` und `Documentation/REVIEW_RULES.md` gelten vollständig.
- Der reduzierte MVP aus `Documentation/PROJECT_DESCRIPTION.md` bleibt verbindlich.
- Der vorhandene SSO-/ESI-orientierte Zukunftscode bleibt funktional erhalten, wird aber nicht erweitert und nicht als MVP-Fortschritt gewertet.
- P03 und spätere Fachprompts wurden noch nicht begonnen.

## Verbindliche Informationsquellen

Lies vor jeder Änderung vollständig beziehungsweise bei dem Projektbuch alle für P02 relevanten Kapitel:

1. aktuellen Quellcode, `Package.swift` und vorhandene Tests,
2. aktuellen Git-Status und Git-Diff, eng begrenzt auf den Projektordner,
3. `AGENTS.md`,
4. `Documentation/PROJECT_DESCRIPTION.md`,
5. `Documentation/CURRENT_PROJECT_STATUS.md`,
6. `Documentation/DEVELOPER_MENU.md`,
7. `Documentation/FEATURE_MATRIX.md`,
8. `Documentation/KNOWN_ISSUES.md`,
9. `Documentation/ARCHITECTURE_CHANGES.md`,
10. vorhandene Abschlussberichte und Testhistorie,
11. Projektbuch Kapitel 20, 31, 32 und 33 sowie Anhang I.

Für den Implementierungsstand ist der tatsächliche Quellcode maßgeblich. Übernimm keine Architekturannahme aus dem Projektbuch ungeprüft in den reduzierten MVP.

## 1. Ausgangszustand erneut verifizieren

Prüfe und dokumentiere mindestens:

- vorhandene SwiftPM-Produkte und Targets,
- existierende Import- und Abhängigkeitsrichtungen,
- direkte SwiftData-Nutzung in SwiftUI-Views,
- persistente `@Model`-Typen und mögliche Folgen eines Modulwechsels,
- App-Start und Erstellung des `ModelContainer`,
- Python-Ressource, Prozessaufruf und Konfiguration,
- SSO-, Network- und Keychain-Abhängigkeiten,
- aktuelle Tests und ihre importierten Targets,
- Buildkonfigurationen und verifizierten CLI-Buildweg,
- uncommittete und untracked Benutzeränderungen.

Erstelle vor dem Umbau eine konkrete Datei- und Abhängigkeitskarte. Erfinde keine bereits vorhandenen Schichten.

## 2. Zielarchitektur festlegen

Dokumentiere ein Zielbild mit mindestens diesen Verantwortungsbereichen:

- **Domain:** reine fachliche Typen, Regeln und deterministische Berechnungen; keine Abhängigkeit von SwiftUI, SwiftData, AppKit, Network, Security oder Dateisystemzugriffen.
- **Application:** Anwendungsfälle, Orchestrierung sowie Ports beziehungsweise Protokolle für benötigte Daten- und Systemzugriffe; abhängig von Domain, nicht von konkreten Adaptern.
- **Infrastructure:** konkrete Adapter für Betriebssystem, Dateien, Prozesse und spätere externe Datenquellen; abhängig von den benötigten Domain-/Application-Schnittstellen.
- **Persistence:** lokale Speicherabbildung, Migrationen und Repository-Implementierungen; fachliche Persistenzänderungen bleiben P03 vorbehalten.
- **Presentation:** SwiftUI-Zustände, Navigation und Benutzerinteraktion; keine neue Fachlogik und keine neuen direkten Datenquellenzugriffe.
- **Composition Root:** einzige Stelle, an der konkrete Implementierungen zusammengesetzt und injiziert werden.

Das minimale bevorzugte SwiftPM-Zielbild ist:

```text
NewEdenNexus (Presentation + Composition Root im Übergang)
    ├──> NewEdenNexusInfrastructure ──> NewEdenNexusApplication ──> NewEdenNexusDomain
    └─────────────────────────────────> NewEdenNexusApplication ──> NewEdenNexusDomain
```

Persistenz wird als eigener Zielbereich festgelegt. Ein eigener SwiftPM-Target darf in P02 nur angelegt werden, wenn dies ohne Änderung der bestehenden SwiftData-Schemaidentität und ohne leeren Platzhaltercode sicher möglich ist. Andernfalls muss P03 den kontrollierten Übergang übernehmen.

Eine Abweichung vom bevorzugten Zielbild ist nur zulässig, wenn sie in einem ADR mit Alternativen, Begründung, Folgen und späterem Migrationspfad dokumentiert wird.

## 3. Abhängigkeitsregeln verbindlich machen

Definiere und soweit in P02 sicher möglich durch SwiftPM-Targetgrenzen erzwinge:

- Domain importiert keine höhere Schicht und kein UI-/Persistenz-/Netzwerkframework.
- Application kennt keine konkreten Infrastruktur- oder Persistenztypen.
- Infrastructure implementiert Ports, enthält aber keine SwiftUI-Views.
- Presentation darf Anwendungsfälle aufrufen, aber keine neue Fachberechnung enthalten.
- Konkrete Adapter werden ausschließlich im Composition Root erzeugt.
- Zukunftsmodule dürfen den MVP-Fachkern nicht zu SSO, ESI oder Live-Daten zwingen.
- Keine zyklischen Target- oder Modulabhängigkeiten.

Neue Targets benötigen echte Verantwortung und produktiv oder testseitig genutzten Inhalt. Leere Marker, Scheinklassen und ungenutzte Protokolle sind nicht zulässig.

## 4. Begrenzten Migrationspfad implementieren

Führe nur den kleinsten Refactor aus, der die gewählte Architektur im Build tatsächlich verankert.

Verbindlich:

- bestehendes sichtbares App-Verhalten erhalten,
- mindestens den bereits vorhandenen reinen Materialaggregationspfad an die neue Schichtengrenze anpassen,
- fachliche Eingabe- und Ausgabetypen UI- und prozessunabhängig halten,
- benötigte Abstraktionen per Dependency Injection anbinden,
- Tests an die neuen Modulgrenzen anpassen,
- provisorische Kompatibilitätsbrücken klar kennzeichnen und terminieren.

Nicht zulässig:

- neue Produktionsgraph-, Blueprint-, Bestands-, Preis- oder Einkaufslogik,
- neues SwiftData-Fachschema,
- Löschung oder Umbenennung persistenter Modelltypen ohne Migration,
- großflächiges UI-Redesign,
- Ausbau oder fachliche Änderung von SSO/ESI,
- vorsorgliche Abstraktionen ohne aktuellen Anwendungsfall.

## 5. SwiftData-Übergang absichern

Die existierenden Typen `CharacterRecord` und `ProductionProject` sind persistente SwiftData-Modelle. Prüfe vor jedem Verschieben, ob sich dadurch die persistente Schemaidentität oder bestehende Daten ändern können.

Für P02 gilt:

- keine destruktive Migration,
- keine ungeprüfte Neuerstellung des Stores,
- kein Verlust bestehender lokaler Daten,
- keine Behauptung, persistente Modelle seien bereits saubere Domänenmodelle,
- dokumentierter Übergangsplan für P03 zur Trennung von Persistenz- und Domänenmodellen.

Wenn ein sicherer Modulwechsel der persistenten Typen nicht nachgewiesen werden kann, bleiben sie vorerst am bestehenden Ort. Diese Übergangsschuld ist ausdrücklich zu dokumentieren und blockiert P02 nicht, sofern die übrigen Grenzen belastbar geschaffen werden.

## 6. Python-Grenze entscheiden

Bewerte die vorhandene Python-Prozessgrenze anhand von:

- fachlicher Korrektheit und Determinismus,
- Testbarkeit,
- macOS-Auslieferung, Signierung und Sandboxfähigkeit,
- zusätzlicher Laufzeitabhängigkeit,
- Fehler- und Abbruchverhalten,
- Nebenläufigkeit und Main-Thread-Blockierung,
- Wartbarkeit und langfristigem MVP-Nutzen.

Vergleiche mindestens:

1. native Swift-Implementierung,
2. externer Python-Prozess wie im Ist-Stand,
3. gebündelte Python-Laufzeit.

Für den reduzierten nativen MVP ist eine Swift-native Lösung zu bevorzugen, wenn die vorhandene Aggregation ohne Funktionsverlust und mit Paritätstests übernommen werden kann. Wird Python beibehalten, sind ein konkreter Bundle-/Signierungsplan, kontrollierte Konfiguration, Cancellation, Timeouts und reproduzierbare Tests erforderlich.

Dokumentiere die Entscheidung als eigenes ADR. Entferne Python-Ressource oder Einstellung nur, wenn funktionale Parität nachgewiesen ist und keine weitere tatsächliche Nutzung existiert.

## 7. Zukunftscode isolieren

Der vorhandene SSO-, Keychain-, Network- und Synchronisationscode gehört zu einer späteren Entwicklungsstufe.

P02 muss:

- ihn funktional erhalten,
- seine Abhängigkeiten vom MVP-Kern sichtbar machen,
- ihn architektonisch als Future-/External-Adapterbereich einordnen,
- verhindern, dass neue MVP-Domänentypen davon abhängen.

P02 darf diesen Code weder erweitern noch ungeprüft löschen. Sicherheitsfehler, die während der Analyse auffallen, werden dokumentiert und nur bei unmittelbarer Kritikalität im kleinsten notwendigen Umfang behoben.

## 8. Architekturdokumentation und ADRs

Erstelle oder aktualisiere mindestens:

- `Documentation/ARCHITECTURE.md` mit Zielbild, Schichten, Modulverantwortungen, Dependency-Regeln, Composition Root und Übergangsplan,
- `Documentation/Architecture/ADRs/README.md` als Register,
- `Documentation/Architecture/ADRs/ADR-0001_Modul-und-Schichtenarchitektur.md`,
- `Documentation/Architecture/ADRs/ADR-0002_Berechnungsruntime-Python-oder-Swift.md`,
- `Documentation/ARCHITECTURE_CHANGES.md`.

Jedes ADR enthält:

- Status,
- Datum,
- Kontext und Problem,
- Entscheidungstreiber,
- betrachtete Alternativen,
- Entscheidung,
- Begründung,
- positive und negative Folgen,
- Migrations- beziehungsweise Rückfallstrategie,
- betroffene Prompts und bekannte offene Punkte.

## 9. Architekturtests und Regressionstests

Ergänze geeignete automatisierte Prüfungen für die tatsächlich eingeführten Grenzen.

Mindestens nachzuweisen:

- Domain kann unabhängig von SwiftUI, SwiftData, AppKit, Network und Security gebaut und getestet werden.
- Application hängt nur von erlaubten Targets ab.
- der Materialaggregationspfad liefert für die bestehenden Referenzeingaben identische Ergebnisse.
- leere Eingabe wird korrekt behandelt.
- gleiche Type-IDs werden deterministisch zusammengeführt.
- fehlerhafte beziehungsweise ungültige Eingaben werden gemäß der gewählten Typ- und Fehlerstrategie behandelt.
- vorhandene Projekttests bleiben erfolgreich.

Bevorzuge Compile-Time-Grenzen durch SwiftPM. Falls zusätzliche Architekturtests Quelltext oder `Package.swift` prüfen, müssen sie robust, pfadunabhängig und verständlich fehlschlagen.

## 10. Build- und Prüfkommandos

Ermittle vor dem ersten Build erneut Projekt, Workspace, Schemes, Konfigurationen und Targets. Verwende den tatsächlich funktionierenden CLI-Weg.

Führe mindestens aus:

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Dokumentiere jeden Befehl mit Ergebnis, Warnungen und Fehlern. Ein nicht ausführbarer Schritt wird nicht als erfolgreich dargestellt. Signing- oder Team-Einstellungen dürfen nicht geändert werden.

## 11. Dokumentationspflicht

Aktualisiere nach der Implementierung:

- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- `Documentation/ARCHITECTURE_CHANGES.md`,
- `Documentation/Prompts/README.md`,
- alle unter Abschnitt 8 genannten Architekturdokumente.

Featurestatus dürfen nur geändert werden, wenn der tatsächliche Code und passende Tests dies belegen. P02 ist kein Nachweis für noch fehlende MVP-Fachfunktionen.

## 12. Abschlussbericht

Erstelle ohne Überschreiben eines vorhandenen Berichts:

`Documentation/Progress/Reports/YYYY-MM-DD_P02_Zielarchitektur-und-Modulgrenzen.md`

Der Bericht muss zusätzlich zu den Vorgaben aus `AGENTS.md` enthalten:

- Architektur vorher und nachher,
- endgültigen Target- und Abhängigkeitsgraphen,
- verschobene Typen und Dateien,
- bewusst verbliebene Übergangsschulden,
- SwiftData-Risikoanalyse,
- Python-Entscheidung und Paritätsnachweis,
- Ergebnis der Architekturtests,
- alle nicht ausgeführten Prüfungen.

## 13. Gesonderter Review

Führe nach Implementierung und Dokumentation einen unabhängigen Kontrollschritt gemäß `Documentation/REVIEW_RULES.md` aus.

Der Review prüft besonders:

- tatsächlichen Targetgraphen gegen das dokumentierte Zielbild,
- verbotene Imports und Abhängigkeitszyklen,
- ungewollte Änderungen an persistenten Modellen,
- Verhaltensparität der Materialaggregation,
- fortbestehende direkte SwiftData-Zugriffe und deren dokumentierten Übergangsstatus,
- vollständige ADRs,
- Build- und Testnachweise,
- unveränderten fachlichen Scope.

Bei `⚠️` oder `❌` müssen konkrete Korrekturaufgaben dokumentiert werden. P02 darf dann nicht auf `✅` gesetzt werden.

## 14. Abnahmekriterien

P02 ist nur dann `✅ erledigt`, wenn:

- das aktuelle Architekturproblem vollständig analysiert und belegt ist,
- eine verständliche Zielarchitektur mit eindeutigen Verantwortungen dokumentiert ist,
- die zulässigen Abhängigkeitsrichtungen technisch oder durch robuste Tests abgesichert sind,
- der kleinste notwendige Refactor tatsächlich kompiliert,
- der vorhandene Materialaggregationspfad an der neuen Grenze mit Paritätstests funktioniert,
- die Python-Entscheidung als ADR nachvollziehbar getroffen und umgesetzt beziehungsweise belastbar terminiert ist,
- persistente SwiftData-Modelle und Benutzerdaten nicht ungeprüft verändert wurden,
- Zukunftscode erhalten und vom MVP-Kern abgegrenzt ist,
- keine neue fachliche App-Funktion eingeführt wurde,
- Debug- und Release-Build erfolgreich sind,
- alle relevanten Tests erfolgreich sind,
- Architekturdokumentation, ADRs und Fortschrittsdokumente aktualisiert sind,
- Abschlussbericht gespeichert ist,
- der gesonderte Review `✅ bestanden` meldet.

Ist eines dieser Kriterien nicht erfüllt, setze P02 auf `⚠️ teilweise oder blockiert` oder `❌ fehlgeschlagen` und dokumentiere den konkreten Grund.

## 15. Grenzen des Auftrags

Beginne nicht mit P03 oder einem fachlichen Folgeprompt. Insbesondere nicht Bestandteil von P02 sind:

- neues SwiftData-Schema und versionierte Fachmigrationen,
- zentrale Fehlerbehandlung oder Logging-Implementierung,
- Backups,
- SDE-Import,
- Produktionsgraphen und T1-/T2-/Reaktionsberechnung,
- Bestände, Reservierungen oder Build-or-Buy,
- neue Preis-, Kosten- oder Einkaufslistenfunktionen,
- Live-ESI-, Markt- oder Walletfunktionen,
- UI-Neugestaltung.

## 16. Abschlussausgabe im Chat

Gib nach Ausführung von P02 kompakt aus:

- Prompt-ID und Status,
- neue Modul- und Targetstruktur,
- Python-Entscheidung,
- SwiftData-Übergangsstatus,
- Build-Ergebnis,
- Testergebnis,
- Reviewstatus,
- Pfad zum Abschlussbericht,
- offene Architekturpunkte,
- nächsten empfohlenen Prompt.

## Erwartetes Ergebnis

New Eden Nexus besitzt nach P02 eine belegte, kompilierbare und schrittweise migrierbare Architekturgrundlage. Der MVP-Fachkern kann in den folgenden Prompts unabhängig von UI, SwiftData, SSO/ESI und konkreten Prozessadaptern entstehen. P02 schafft Grenzen und verifiziert bestehendes Verhalten; es nimmt keine Fachfunktion späterer Prompts vorweg.
