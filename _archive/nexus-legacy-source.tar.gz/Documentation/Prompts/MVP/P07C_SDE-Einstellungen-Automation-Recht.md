# P07C – SDE-Einstellungen, Automatisierung und rechtliche Hinweise

Status: **✅ erledigt – manueller UI-/Accessibility-Smoke-Test in P09B nachgeholt**

Ausführungsnachweis:
[P07C-Abschlussbericht](../../Progress/Reports/2026-07-23_P07C_SDE-Einstellungen-Automation-Recht.md)
· [abschließende P09B-GUI-Abnahme](../../Progress/Reports/2026-07-23_P09B_Xcode-Projekt-Schemes.md)

## 1. Zweck

Mache den P07A/P07B-Updatepfad transparent und benutzerkontrolliert:
nicht blockierende Aktualitätsprüfung, sichere Automationsoptionen,
Fortschritt/Fehler, Updateprotokoll und aktuelle unabhängige
Drittanbieterkennzeichnung.

## 2. Voraussetzungen

- P07A und P07B abgeschlossen,
- DLA-Entscheidung und User-Agent-Kontakt für die technische Abnahme liegen
  vor,
- Marken-/Release- und Rechtstextfreigabe werden vor einem positiven
  P07C-Abschluss persönlich durch den Projekteigentümer erteilt,
- keine Zustimmung wird von der App vorgetäuscht oder automatisch erteilt.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-020 / KI-020 | P07A-Updatecheck und P07B-Installationsservice produktiv am App-Start und in der manuellen Bedienung verdrahten; SDE-Settings, 24-h-Automation, Offline-/Fortschrittszustände, Protokollansicht und Rechtsbereich ergänzen. | Composition-Root-, ViewModel-/UI-/Scheduler-/Accessibility-, App-Start- und manueller End-to-End-Test |
| OFF-019 / KI-019 | alte Versionen sicher aufbewahren und nur nach Policy löschen | Retention-/Rollback-/Bestätigungstest |

## 4. Produktive Composition und Lebenszyklus

- Konkrete P07A-/P07B-Adapter werden am App-Rand in `NexusAppRuntime` oder
  einer klar abgegrenzten Composition Root erzeugt.
- Views und ViewModels konstruieren keine SwiftData-Repositories,
  Netzwerktransporte oder Archivadapter.
- Der persistente Benutzerstore wird erst nach erfolgreicher Öffnung
  übergeben; Startprüfung und Recovery laufen danach strukturiert,
  abbrechbar und nicht blockierend.
- Der automatische Startcheck verwendet produktiv dieselbe
  `SDEUpdateService`-Policy wie die getestete Application-Grenze.
- Die manuelle Installation verwendet produktiv den vollständigen
  `SDEInstallationService` einschließlich Download-, Archiv-, Staging-,
  Backup-, Promotion-, Journal-, Rollback- und Cleanup-Gates.
- Doppelte Start-/Manuell-/Installationsaufgaben werden verhindert.
- App-Beenden, Fensterlebenszyklus und Abbruch beenden Tasks kontrolliert;
  tatsächlicher harter Prozessabbruch bleibt als gesonderter P36-Nachweis
  erhalten.
- Ein manueller End-to-End-Smoke-Test startet die echte App-Verdrahtung mit
  einem isolierten Testprofil. Produktive Benutzerdaten dürfen nicht als
  Teststore dienen.

## 5. Application-Zustandsmodell

UI-freie Zustände mindestens:

- aktuell,
- Update verfügbar,
- Prüfung läuft,
- Download läuft,
- Archivprüfung läuft,
- Import läuft,
- Aktivierung läuft,
- Offline – lokaler Stand aktiv,
- Update fehlgeschlagen – alter Stand aktiv,
- Schemaänderung – Prüfung erforderlich,
- Abbruch,
- Neustart/Storewechsel erforderlich, falls technisch wirklich nötig.

Fortschritt ist phasen- und datensatzbezogen, abbrechbar und reproduzierbar.

## 6. Zeit- und Automationsregeln

- automatische Aktualitätsprüfung standardmäßig aktiv,
- beim Start nur nicht blockierend und nur, wenn letzte erfolgreiche oder
  versuchte zulässige Prüfung mindestens 24 Stunden zurückliegt,
- bei langer Laufzeit höchstens eine Prüfung pro 24 Stunden,
- manuelle Prüfung erlaubt, aber gegen parallele/doppelte Requests geschützt,
- automatischer Download und automatische Installation nur nach expliziter
  Benutzereinstellung,
- Installation nur nach vollständig grünen P07A/P07B-Gates,
- kein konfigurierbares Intervall unter 24 Stunden,
- Zeit und Scheduler injizierbar und getestet,
- WLAN-only nur anbieten, wenn die Zielplattform die Anforderung zuverlässig
  feststellt; sonst sichtbar begründet weglassen,
- keine unnötige ESI-Abfrage als Folge eines SDE-Updates.

## 7. Einstellungen „EVE-Daten und SDE“

Mindestens anzeigen:

- aktive lokale Buildnummer,
- Release-/Abrufdatum,
- letzte erfolgreiche Prüfung,
- letzter erfolgreicher Import,
- verfügbare Buildnummer,
- Daten-/Schema-/Offlinezustand,
- Format,
- lokale Storegröße mit klarer Definition,
- letzte sichere Fehlermeldung und Diagnosecode,
- Fortschritt und Abbruch,
- „Nach Update suchen“,
- „Update installieren“,
- „Updateprotokoll anzeigen“.

Optionen:

- automatische Prüfung,
- automatischer Download,
- automatische Installation,
- zulässiges Prüfintervall ab 24 Stunden,
- Rollbackaufbewahrung,
- alte Versionen nach erfolgreichem Update löschen.

Löschen alter Versionen ist eine gesonderte bestätigungspflichtige,
recoverable Operation. Mindestens aktive und letzte funktionierende Version
bleiben erhalten.

## 8. Rechtliche Hinweise / Über

- New Eden Nexus klar als unabhängige Drittanbieteranwendung kennzeichnen,
- keine Unterstützung, Billigung oder offizielle Verbindung mit CCP behaupten,
- den am Ausführungstag aktuellen DLA-Eigentums-/Markenhinweis nach
  Eigentümerprüfung verwenden,
- aktive SDE-Buildnummer und Format nennen,
- offizielle DLA-, SDE-, EULA-, ToS- und Policy-Links anzeigen,
- keine Logos/Bilder hinzufügen, ohne deren separate Bedingungen zu prüfen,
- keine Rechtsfreigabe oder CCP-Genehmigung behaupten.

Der Rechtstext wird versioniert dokumentiert; vor P37 erneut geprüft.

## 9. Updateprotokoll und Diagnoseexport

- filter-/sortierbare Updateversuche,
- Details je Phase, Counts, Cacheentscheidung, Fehler und Rollback,
- Export nur nach Benutzeraktion,
- bereinigtes, dokumentiertes Format,
- keine Tokens, Secrets, privaten Pfade oder Spieler-/Accountdaten,
- Exportvorschau und sichere Zielauswahl.

## 10. UX und Accessibility

- klare Hierarchie, Empty/Loading/Error/Offline/Warning States,
- Tastaturbedienung, VoiceOver, Kontrast und große Schrift,
- lange Fehlertexte und schmale/breite Fenster,
- Schaltflächen während unzulässiger paralleler Phase deaktiviert,
- destruktive Retentionaktion mit genauer Ziel-/Folgenanzeige.

## 11. Tests und manuelle Prüfung

Mindestens:

- alle Zustandsübergänge,
- Startcheck fällig/nicht fällig,
- produktive Composition ohne Repository-/Netzwerkbau im ViewModel,
- 24-h-Drossel und lange Laufzeit,
- manuelle Prüfung und Parallelitätsschutz,
- automatische Optionen und sichere Defaults,
- Offline-/Fehler-/Schemaänderungsanzeige,
- Fortschritt und Abbruch,
- erfolgreiche Installation/alter Stand aktiv bei Fehler,
- echter App-Start mit isoliertem Testprofil und produktiver
  P07A-/P07B-Verdrahtung,
- Updateprotokoll und redigierter Export,
- Retention/Rollback/Bestätigung,
- UI-Zustände, Accessibility-Labels und Tastaturaktionen.

Zusätzlich einen dokumentierten manuellen Funktions- und Accessibility-Smoke-
Test mit Screenshots ohne personenbezogene Daten durchführen.

## 12. Dokumentation

Aktualisiere Benutzeranleitung, Compliance, SDE-Updateablauf, Datenschutz,
Diagnoseexport, Retention, alle Pflichtstatusdateien und Abschlussbericht
`YYYY-MM-DD_P07C_SDE-Einstellungen-Automation-Recht.md`.

## 13. Definition of Done

P07C ist nur `✅`, wenn die UI alle geforderten Zustände und Aktionen
verständlich abbildet, 24-h-Policy und Offlineverhalten getestet sind,
Updatecheck und Installation über die produktive Composition der echten App
nachgewiesen sind, Automatisierung benutzerkontrolliert ist,
Rechts-/Eigentumshinweise aktuell und vom Eigentümer freigegeben sind,
Diagnoseexport redigiert ist, manueller Test dokumentiert,
SwiftPM-Nachweise in Debug und Release grün und Review bestanden ist.

P10 darf nicht automatisch begonnen werden.
