# P04 – Fehlerbehandlung und Logging

Status: **✅ erledigt und reviewed**

## Projekt

Arbeite im geöffneten lokalen Repository für:

**New Eden Nexus – Assets, Industry, Markets**

P04 schafft die zentrale Fehler- und Diagnosegrundlage. Implementiere keine neue Produktions-, SDE-, Bestands-, Preis-, Markt-, SSO- oder andere Fachfunktion.

## Zweck

Der P03-Stand kompiliert und besitzt eine sichere additive Migration, behandelt technische Fehler aber noch uneinheitlich:

- ein Fehler beim Öffnen der lokalen Datenbank beendet die App mit `fatalError`,
- mehrere SwiftData-Speicherpfade verwenden `try?`,
- SSO-Fehler werden als ungefiltertes `localizedDescription` angezeigt,
- ein zentraler strukturierter Logger fehlt,
- offene technische Punkte werden nicht in einer eigenen wiederkehrenden Prüfliste auditiert.

P04 muss Fehler typisieren, benutzerverständlich darstellen, datenschutzgerecht protokollieren und bestehende Schreibfehler sichtbar machen, ohne Datenbankreset oder stille Ersatzwerte.

## Voraussetzungen

- P00 bis P03 sind abgeschlossen und reviewed.
- `AGENTS.md` und `Documentation/REVIEW_RULES.md` gelten vollständig.
- Schema v1 und `NexusModelContainerFactory` bleiben unverändert.
- Baseline: Debug-Build und 26 Tests erfolgreich.

## Verbindliche Informationsquellen

Lies vor Änderungen:

1. aktuellen Quellcode, Package und Tests,
2. Git-Status und vorhandene Benutzeränderungen,
3. `AGENTS.md`,
4. `Documentation/CURRENT_PROJECT_STATUS.md`,
5. `Documentation/DEVELOPER_MENU.md`,
6. `Documentation/FEATURE_MATRIX.md`,
7. `Documentation/OPEN_TASKS.md`,
8. `Documentation/KNOWN_ISSUES.md`,
9. Architektur, ADRs und P03-Abschlussbericht,
10. Projektbuch Kapitel 3.8, 20.9, 20.10 und 20.11,
11. die im installierten macOS-SDK verfügbaren Swift-, SwiftUI- und OSLog-APIs.

## 1. Zentrale Fehlertaxonomie

Definiere in `NewEdenNexusApplication` UI- und Adapter-unabhängige Typen für:

- betroffene Operation,
- Fehlercode,
- Fehlerkategorie,
- Schweregrad,
- benutzerverständlichen Titel,
- sichere Kurzbeschreibung,
- konkrete Wiederherstellungsempfehlung,
- technische Korrelation ohne sensible Nutzdaten.

Mindestens abzubilden:

- lokale Datenbank kann beim App-Start nicht geöffnet werden,
- Projekt kann nicht gespeichert werden,
- Charakteränderung kann nicht gespeichert werden,
- Charakter kann nicht gelöscht werden,
- Synchronisationsstatus kann nicht gespeichert werden,
- Authentifizierung oder Schlüsselbundoperation schlägt fehl,
- unerwarteter Fehler.

Technische Rohmeldungen und `localizedDescription` dürfen nicht ungeprüft als UI-Text ausgegeben werden. Das Mapping muss deterministisch und testbar sein.

## 2. Strukturierte Diagnosen

Definiere in Application:

- Log-Level `info`, `warning`, `error`,
- Kategorien mindestens `lifecycle`, `persistence`, `projects`, `authentication`, `synchronization`, `general`,
- ein strukturiertes Diagnoseereignis,
- typisierte Metadaten mit ausdrücklicher Sichtbarkeit,
- einen `Sendable`-fähigen Logger-Port.

Ein Diagnoseereignis enthält mindestens:

- Ereignisname,
- Fehlercode,
- Operation,
- Kategorie,
- Level,
- Korrelations-ID,
- sortierte Metadaten.

Private Metadaten dürfen den Klartextwert zu keinem Zeitpunkt in der gerenderten Logzeile enthalten.

## 3. Datenschutz- und Redaktionsregeln

Nie protokollieren:

- Access- oder Refresh-Tokens,
- Passwörter oder Client Secrets,
- Authorization Codes oder PKCE-Verifier,
- vollständige Serverantworten,
- Benutzernamen, Charakter- oder Projektnamen,
- frei eingegebene Notizen,
- vollständige lokale Dateipfade,
- ungefilterte `localizedDescription`-Texte.

Öffentlich zulässig sind nur stabile technische Werte wie:

- eigener Fehlercode,
- feste Operation und Kategorie,
- Boolesche Zustände,
- Anzahlwerte ohne Personenbezug,
- Typname eines Fehlers.

Private Felder werden als `<redacted>` ausgegeben. Neue öffentliche Metadaten müssen bewusst als sicher eingestuft werden.

## 4. Konkreter Logger

Implementiere in `NewEdenNexusInfrastructure` einen Adapter auf Apples Unified Logging (`OSLog.Logger`).

Der Adapter:

- implementiert den Application-Port,
- verwendet ein festes App-Subsystem und strukturierte Kategorien,
- mappt die definierten Level,
- protokolliert ausschließlich die bereits redigierte Darstellung,
- besitzt keine SwiftUI-, SwiftData-, Netzwerk- oder Keychain-Abhängigkeit,
- führt keine Dateilogdatei und keine Cloudübertragung ein.

## 5. Zentraler App-Fehlerfluss

Implementiere im App-Target eine injizierbare, `@MainActor`-gebundene Runtime beziehungsweise Fehlerzentrale.

Sie muss:

- den Logger erhalten statt einen globalen Singleton zu verwenden,
- die lokale Datenbank über die vorhandene Factory öffnen,
- Startzustände `loading`, `ready` und `failed` abbilden,
- Startfehler ohne App-Absturz als eigene Ansicht darstellen,
- einen erneuten Öffnungsversuch ermöglichen,
- gemeldete Laufzeitfehler zentral als Alert präsentieren,
- beim Melden genau ein strukturiertes Diagnoseereignis erzeugen,
- das Schließen eines Alerts kontrolliert behandeln.

Ein fehlgeschlagener Datenbankstart darf weder den Store löschen noch eine leere Ersatzdatenbank erzeugen.

## 6. Bestehende Fehlerpfade korrigieren

Entferne im produktiven App-Code:

- den Datenbank-`fatalError`,
- `try? modelContext.save()` bei Projektanlage,
- `try? modelContext.save()` beim Löschen eines Charakters,
- `try? modelContext.save()` beim simulierten Synchronisationsstatus.

Bei SwiftData-Speicherfehlern:

- Fehler zentral melden,
- den ModelContext zurückrollen,
- einen Formular- oder Arbeitsdialog nicht fälschlich als erfolgreich schließen.

Die bestehende Account-Anmeldung verwendet denselben sicheren Fehlerfluss. Raw-Servertexte werden nicht in Alerts oder Logs übernommen.

Keychain-Löschfehler dürfen nicht mehr stillschweigend ignoriert werden. `errSecItemNotFound` gilt als idempotenter Erfolg; andere Statuswerte werden geworfen und zentral behandelt.

## 7. Fehler-UI

Die Startfehleransicht und globale Alertdarstellung müssen:

- verständlichen Titel, Beschreibung und Handlungsempfehlung zeigen,
- keine technischen Rohdaten offenlegen,
- einen klaren Wiederholen- beziehungsweise Schließenpfad besitzen,
- mit Tastatur und VoiceOver erfassbare Standard-SwiftUI-Komponenten verwenden,
- schmale und breite Fenster unterstützen.

Ein Diagnosecode darf angezeigt werden, damit Supportfälle korreliert werden können. Sensible Inhalte dürfen nicht erscheinen.

## 8. Tests

Prüfe mindestens:

1. deterministisches Mapping jeder P04-Operation,
2. keine Übernahme eines Secret-Sentinels aus einem Fehler in UI-Texte,
3. korrektes Level und korrekte Kategorie,
4. stabile Diagnosecodes,
5. private Metadaten werden vollständig redigiert,
6. öffentliche Metadaten und sortierte Ausgabe bleiben erhalten,
7. Runtime meldet Startfehler statt abzustürzen,
8. Runtime kann nach einem Startfehler erfolgreich erneut öffnen,
9. Laufzeitfehler werden präsentiert und genau einmal protokolliert,
10. produktiver App-Code enthält keinen `fatalError` und kein `try? modelContext.save()`,
11. vorhandene 26 Regressionstests bleiben erfolgreich,
12. Architekturgrenzen bleiben gültig.

Tests verwenden keine Produktivdaten, echten Tokens, Netzwerkzugriffe oder produktiven Storepfade.

## 9. Offene-Punkte-Audit

Erstelle:

`Documentation/OFFEN.md`

Die Datei ist ab P04 die verbindliche fortlaufende Auditliste für noch offene Punkte. Jeder Eintrag enthält:

- ID,
- Status `offen`, `teilweise`, `erledigt` oder `verschoben`,
- Priorität,
- Ursprung,
- konkrete Restarbeit,
- letzten Prüfnachweis mit Datum,
- Zielprompt.

Vor Abschluss jedes künftigen Prompts muss jeder aktive Eintrag gegen Quellcode, Tests oder Dokumentation neu geprüft werden. Erledigte Einträge bleiben als Historie erhalten und nennen ihren Nachweis.

`Documentation/OPEN_TASKS.md` bleibt die kompakte Arbeitsliste und verweist auf `OFFEN.md`. Ergänze die Aktualisierungspflicht außerdem in `AGENTS.md`.

## 10. Dokumentation

Erstelle:

- `Documentation/ERROR_HANDLING_AND_LOGGING.md`,
- `Documentation/Architecture/ADRs/ADR-0004_Zentrale-Fehler-und-Diagnosegrenze.md`,
- `Documentation/OFFEN.md`.

Aktualisiere:

- `Documentation/ARCHITECTURE.md`,
- `Documentation/ARCHITECTURE_CHANGES.md`,
- `Documentation/Architecture/ADRs/README.md`,
- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- `Documentation/IMPLEMENTATION_ROADMAP.md`,
- `Documentation/Prompts/README.md`,
- `AGENTS.md`.

## 11. Build- und Prüfkommandos

Führe mindestens aus:

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Dokumentiere echte Ausgaben, Warnungen, Fehler und nicht ausgeführte Prüfungen.

## 12. Abschlussbericht

Erstelle:

`Documentation/Progress/Reports/YYYY-MM-DD_P04_Fehlerbehandlung-und-Logging.md`

Der Bericht enthält zusätzlich:

- Fehlertaxonomie und Mapping,
- Loggingstruktur und Redaktionsregeln,
- korrigierte Fehlerpfade,
- Startfehler- und Wiederholungsverhalten,
- auditierte offene Punkte,
- nachgewiesene Abwesenheit von `fatalError` und verschluckten SwiftData-Speicherfehlern.

## 13. Gesonderter Review

Der Review gemäß `Documentation/REVIEW_RULES.md` prüft besonders:

- keine sensiblen Werte in Logs, UI, Tests oder Bericht,
- keine ungefilterten Rohfehler in der UI,
- kein Datenbankreset oder Leerstore-Fallback,
- genau ein Logereignis je gemeldetem Fehler,
- Rollback nach SwiftData-Speicherfehlern,
- kein `fatalError` und kein `try? modelContext.save()` im produktiven App-Code,
- Runtime-Retry ohne Produktivdaten,
- vollständiges `OFFEN.md`-Audit,
- Build-, Test- und Dokumentationsnachweise.

## 14. Abnahmekriterien

P04 ist nur `✅ erledigt`, wenn:

- der Prompt vollständig spezifiziert und umgesetzt ist,
- zentrale Fehlertypen und Logger-Port existieren,
- Unified-Logging-Adapter implementiert ist,
- Redaktionsregeln automatisiert geprüft sind,
- App-Start ohne `fatalError` fehlschlagen kann,
- Start-Retry getestet ist,
- aktuelle SwiftData-Speicherfehler sichtbar behandelt und zurückgerollt werden,
- keine technische Rohmeldung ungeprüft in der UI landet,
- Keychain-Löschfehler nicht ignoriert werden,
- `OFFEN.md` angelegt und gegen den aktuellen Code auditiert ist,
- Debug- und Release-Build erfolgreich sind,
- alle relevanten Tests erfolgreich sind,
- Dokumentation und Abschlussbericht vollständig sind,
- Review `✅ bestanden` meldet.

Andernfalls bleibt P04 `⚠️ teilweise oder blockiert` oder wird `❌ fehlgeschlagen`.

## 15. Grenzen

Nicht Bestandteil:

- neue Produktions-, SDE-, Bestands-, Preis- oder Einkaufslistenlogik,
- Retry-/Backoff-Engine für ESI,
- Logdateiexport oder Supportpaket,
- Telemetrie oder Cloudlogging,
- vollständige Lokalisierungsinfrastruktur,
- Backup/Restore,
- Datenbankschemaänderung,
- UI-Redesign,
- Git-Reparatur, Commit oder Signing-Änderung.

## Erwartetes Ergebnis

Nach P04 beendet ein lokaler Datenbankfehler die App nicht mehr. Relevante Schreibfehler werden sichtbar, sicher und zentral behandelt. Diagnoseereignisse sind strukturiert, redigiert und über Apples Unified Logging ausgegeben. `Documentation/OFFEN.md` hält alle Restpunkte mit wiederholbarer Statusprüfung nach.
