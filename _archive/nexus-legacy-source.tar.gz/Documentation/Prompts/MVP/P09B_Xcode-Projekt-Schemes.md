# P09B – Eigenständiges Xcode-Projekt und gemeinsame Schemes

Status: **✅ erledigt – Review bestanden**

Ausführungsnachweis:
[P09B-Abschlussbericht](../../Progress/Reports/2026-07-23_P09B_Xcode-Projekt-Schemes.md)

## 1. Zweck

Ergänze ein dauerhaft versioniertes, eigenständiges Xcode-Projekt für die
native macOS-App. App, Module, Tests und der opt-in SDE-Abnahmerunner müssen in
Xcode auffindbar und per `xcodebuild` reproduzierbar sein, ohne den weiterhin
gültigen SwiftPM-Weg zu beschädigen.

## 2. Voraussetzungen

- P09A ist abgeschlossen und liefert eine reviewbare Git-Baseline.
- SwiftPM Debug/Release und alle Tests sind vor der Änderung grün.
- Es existiert noch kein funktionierendes `.xcodeproj` oder
  `.xcworkspace`.
- Keine Signing-, Team-, Distribution-, Notarisierungs- oder
  Release-Bundle-ID-Entscheidung wird vorweggenommen.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-014 / KI-009 | Eigenständiges Xcode-Projekt mit erkennbaren gemeinsamen Schemes und reproduzierbarem macOS-Build erzeugen. | `xcodebuild -list`, Debug-/Release-Build, Testlauf, SwiftPM-Regression und manueller App-Start |
| OFF-025 / KI-025 | Nach Erzeugung des echten App-Bundles den offenen P07C-Fenster-/Tastatur-/VoiceOver-Smoke-Test mit isoliertem Profil wiederholen. | SDE-Navigation, Status-/Offline-/Warnzustände, Settings- und Rechtstab, Tastatur und VoiceOver manuell prüfen; ausschließlich datenschutzneutrale Screenshots speichern und im P09B-Bericht referenzieren |

## 4. Projektstruktur

- Erzeuge `NewEdenNexus.xcodeproj` in der Projektwurzel.
- Referenziere die vorhandenen Dateien unter `Sources/` und `Tests/`; keine
  Quellcodeduplikate anlegen.
- Spiegele die fachlichen Targetgrenzen aus `Package.swift`:
  `NewEdenNexusDomain`, `NewEdenNexusApplication`,
  `NewEdenNexusInfrastructure`, `NewEdenNexusPersistence`, App,
  `NewEdenNexusSDEAcceptance`, TestSupport, Legacy-Fixture und Testtargets.
- Dependency-Richtung und macOS-Mindestziel bleiben unverändert.
- Ressourcenzuordnung für die versionierten Test-Fixtures muss in SwiftPM und
  Xcode identisch funktionieren.
- Gemeinsame Schemes mindestens für `NewEdenNexus` und
  `NewEdenNexusSDEAcceptance` versionieren. Das App-Scheme muss die relevanten
  Testtargets ausführen können.
- Keine persönlichen `.xcuserstate`-, `xcuserdata`- oder
  DerivedData-Artefakte versionieren.

`Package.swift` und das Xcode-Projekt sind zwei Buildbeschreibungen derselben
Quellen. Ergänze einen kleinen statischen Konsistenztest oder ein
Prüfskript, das fehlende produktive Dateien und unbeabsichtigte
Targetabweichungen sichtbar macht.

## 5. Build- und Signingregeln

- Keine Apple-Team-ID eintragen oder Automatic Signing aktivieren.
- Für CLI-Nachweise `CODE_SIGNING_ALLOWED=NO` verwenden.
- Eine gegebenenfalls notwendige lokale Entwicklungs-Bundle-ID ist klar als
  nicht freigegebener Platzhalter zu dokumentieren und darf keine
  Marken-/Releasefreigabe vortäuschen.
- Debug und Release für Ziel `platform=macOS` bauen.
- Warnungen vollständig erfassen; keine Warnung pauschal unterdrücken.
- Der bisher verifizierte SwiftPM-Weg bleibt erhalten und muss danach
  weiterhin Debug/Release sowie alle Tests bestehen.

## 6. Verbindliche Prüfungen

Mindestens:

1. `xcodebuild -list -project NewEdenNexus.xcodeproj`,
2. App-Scheme Debug ohne Signing bauen,
3. App-Scheme Release ohne Signing bauen,
4. alle im App-Scheme hinterlegten Tests ausführen,
5. SDE-Abnahmerunner-Scheme bauen, aber keinen offiziellen Download ohne
   dessen separate Gates starten,
6. SwiftPM Debug/Release und vollständige Tests erneut ausführen,
7. App über das gemeinsame Scheme auf `My Mac` manuell starten,
8. Navigation und leeren Startzustand als Smoke-Test prüfen,
9. P07C-Bereich und Rechtstab mit isoliertem Store manuell prüfen,
   Tastatur-/VoiceOver-Nachweis und datenschutzneutrale Screenshots erzeugen,
10. Projektdatei auf absolute Benutzerpfade, Team-IDs und persönliche
   Xcode-Metadaten prüfen.

Erzeugt Xcode beim Öffnen notwendige Metadaten, dürfen nur reproduzierbare
gemeinsame Projekt-/Scheme-Dateien in den Projektumfang gelangen.

## 7. Architektur und Dokumentation

Eine Xcode-Projektbeschreibung darf keine neue Fachlogik oder zweite
Implementierung erzeugen. Aktualisiere:

- Build-/Startanleitung,
- Architektur- und Builddokumentation,
- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- Abschlussbericht
  `YYYY-MM-DD_P09B_Xcode-Projekt-Schemes.md`.

Eine grundlegende Änderung der Buildarchitektur benötigt zusätzlich eine
ADR-Ergänzung.

## 8. Definition of Done

P09B ist nur `✅`, wenn das eigenständige Projekt eingecheckt werden kann,
`xcodebuild` alle gemeinsamen Schemes erkennt, Debug/Release und Tests
erfolgreich sind, der SwiftPM-Weg unverändert grün bleibt, die App auf einem
Mac manuell startet, keine persönlichen/Signing-Daten enthalten sind und der
gesonderte Review bestanden ist.

P10 darf nicht automatisch begonnen werden.
