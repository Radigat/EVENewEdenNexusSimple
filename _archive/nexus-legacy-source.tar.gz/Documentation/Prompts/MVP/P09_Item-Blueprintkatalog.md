# P09 – Item- und Blueprintkatalog vollständig spezifizieren und ausführen

Status: **✅ erledigt**

## 1. Zweck

Stelle auf Basis des in P08 aktivierten SDE-Datenstands einen lokalen,
deterministischen und begrenzten Lesezugriff auf Items und Blueprints bereit.
Nach P09 können nachgelagerte Use-Cases Items per externer ID laden,
Itemnamen durchsuchen, den Katalog fachlich filtern und vorhandene
Blueprint-/Produktbezüge ohne direkten SwiftData-Zugriff abfragen.

P09 implementiert die Katalog- und Abfragegrenze. Eine sichtbare
Zielproduktauswahl gehört zu P12, die fachliche Rezeptauflösung zu P10 und der
Produktionsgraph zu P13.

## 2. Voraussetzungen

- P01 bis P08 sind abgeschlossen.
- `NexusSchemaV2` und die aktive `StaticDataVersion` sind die maßgebliche
  Datenquelle.
- Der P08-Realtest mit dem offiziellen Build 3424810 ist dokumentiert.
- Vorhandene Benutzeränderungen und produktive Stores werden nicht als
  Testdaten verwendet.
- Vor der Implementierung werden Git-Status, betroffene Targets, bestehende
  Tests sowie alle aktiven Einträge in `OFFEN.md`, `OPEN_TASKS.md` und
  `KNOWN_ISSUES.md` erneut geprüft.

## 3. Mit zu erledigende offene Punkte

| ID | Verbindliche Restarbeit in P09 | Prüfnachweis |
|---|---|---|
| OFF-003 / KI-004 | Den Item-/Blueprintkatalog auf dem aktiven Schema-v2-Stand implementieren: aktive Version, exakte ID-Lookups, Namenssuche, Filter, Begrenzung und Blueprint-/Produktbezug. | Unit- und Persistenztests sowie mindestens ein Test nach Wechsel der aktiven Datenversion. |

`OFF-003` darf nach P09 nur noch für den ausdrücklich P10 zugeordneten
Rezeptresolver teilweise offen bleiben. `OFFEN.md` und `KNOWN_ISSUES.md`
müssen diese Trennung nach Abschluss eindeutig ausweisen.

Folgende Punkte werden geprüft, aber nicht vorgezogen:

- `OFF-016`/`KI-016` bleibt P10 zugeordnet. P09 muss die in P08 gespeicherten
  Auflösungsmerkmale unverändert erhalten und darf unvollständige Rezepte nicht
  fälschlich als sicher auflösbar kennzeichnen.
- `OFF-008` wird nur insoweit berührt, wie neue Katalogzugriffe ausschließlich
  über Application-Ports und Use-Cases erfolgen. Die Umstellung bestehender
  Projekt-Views bleibt P11 ff.
- `OFF-014` blockiert P09 nicht, solange der verifizierte SwiftPM-Prüfweg
  funktioniert.

Werden bei der P09-Analyse weitere unmittelbar notwendige offene Punkte
gefunden, sind sie vor der Implementierung mit eigener ID aufzunehmen und im
selben Arbeitspaket zu bearbeiten. Unabhängige oder später zugeordnete Punkte
bleiben mit Begründung offen.

## 4. Verbindliche Katalogmodelle

Definiere unveränderliche, `Sendable` Application-Modelle für:

- kompaktes Item-Suchergebnis,
- vollständige Item-Katalogdetails,
- Blueprint-Kurzbeschreibung,
- Produktionsbezug zwischen Produkt, Blueprint und Aktivitätsart,
- Katalogfilter und begrenzte Suchanfrage,
- begrenztes Suchergebnis einschließlich Hinweis, ob weitere Treffer
  vorhanden sind,
- Kennzeichnung der zugrunde liegenden aktiven SDE-Version.

Die Modelle verwenden externe EVE-IDs und keine SwiftData-Objekte. Mindestens
enthalten sind:

- Item-ID, Name, Gruppe, Kategorie und Veröffentlichungsstatus,
- optionale Marktgruppe sowie vorhandene Volumen-/Preisbasisdaten,
- Blueprint-Typ-ID und unterstützte Aktivitätsarten,
- Produktmenge und optionale Wahrscheinlichkeit nur als Rohdaten,
- Hinweis auf nicht aufgelöste Material-/Produktreferenzen, sofern für den
  angezeigten Bezug relevant,
- Buildnummer und Inhalts-SHA-256 der aktiven Version.

## 5. Abfrage- und Suchregeln

Implementiere Application-Ports und Use-Cases sowie einen SwiftData-Adapter
mit folgenden Regeln:

1. Alle Abfragen verwenden ausschließlich die aktive `StaticDataVersion`.
2. Exakte Lookups unterstützen Item-ID und Blueprint-Typ-ID.
3. Produktsuche liefert Items mit mindestens einem gespeicherten
   Blueprint-Produktbezug und kann nach Aktivitätsart filtern.
4. Allgemeine Itemsuche kann zusätzlich nicht produzierbare Items liefern.
5. Standardmäßig werden nur veröffentlichte Items zurückgegeben;
   unveröffentlichte Items sind über einen ausdrücklichen Filter abrufbar.
6. Filter für Kategorie, Gruppe und Aktivitätsart sind kombinierbar.
7. Suchtext wird an den Rändern bereinigt und für eine
   groß-/kleinschreibungs- sowie diakritikunabhängige Suche normalisiert.
8. Leerer Suchtext ist nur zusammen mit mindestens einem fachlichen Filter
   zulässig; eine unbegrenzte Vollabfrage ist verboten.
9. Ergebnisgrenzen liegen zwischen 1 und 100, Standard ist 50.
10. Sortierung ist stabil: normalisierter Itemname, danach externe Item-ID.
11. Mehrere Blueprintbezüge erzeugen kein doppeltes Item-Suchergebnis.
12. Das Ergebnis meldet, ob hinter der gewählten Grenze weitere Treffer
    existieren.
13. Ein Wechsel der aktiven Datenversion wird bei der nächsten Abfrage
    sichtbar; Ergebnisse verschiedener Versionen dürfen nicht vermischt
    werden.

Falls die bestehende Persistenz für die normalisierte Suche erweitert werden
muss, ist eine additive, versionierte Migration mit Altbestandstest und Test
einer leeren Datenbank anzulegen. Ohne notwendige Schemaänderung darf keine
neue Schemaversion erzeugt werden.

## 6. Fehler- und Konsistenzregeln

Behandle mindestens:

- keine aktive SDE-Version,
- ungültige Ergebnisgrenze,
- leerer Suchtext ohne Filter,
- nicht vorhandene Item- oder Blueprint-ID,
- widersprüchliche aktive Versionsmarker,
- gespeicherte Beziehungen zu einer anderen Datenversion,
- Cancellation während größerer Abfragen,
- Persistenzfehler ohne Ausgabe interner Rohfehler.

„Nicht gefunden“ ist ein typisiertes fachliches Ergebnis und kein Absturz.
Inkonsistente Versionen oder Beziehungen verwenden die zentrale
Fehlerbehandlung und werden datenschutzgerecht protokolliert.

## 7. Architekturgrenzen

- Domain und Application importieren weder SwiftData noch SwiftUI.
- Application definiert Abfragemodelle, Ports und Use-Cases.
- Persistence implementiert die Abfragen und das Mapping von SwiftData in
  Application-Modelle.
- Neue Views sind nicht Bestandteil von P09.
- Es gibt keine Datenbankabfrage direkt aus einer View.
- Der Katalog ist read-only; P09 verändert weder SDE-Import noch Aktivierung.
- P09 trifft keine fachliche Auswahl zwischen konkurrierenden Rezepten.

## 8. Tests und Performanceprüfung

Ergänze mindestens Tests für:

- exakten Item- und Blueprint-Lookup,
- Suche unabhängig von Groß-/Kleinschreibung und Diakritika,
- leeren Suchtext mit und ohne zulässigen Filter,
- veröffentlichte und unveröffentlichte Items,
- Kategorie-, Gruppen- und Aktivitätsfilter sowie Kombinationen,
- stabile Sortierung, Ergebnisgrenze und `hasMore`,
- Deduplizierung bei mehreren Blueprintbezügen,
- ausschließlich aktive Version und Wechsel des aktiven Datenstands,
- nicht vorhandene IDs,
- fehlende oder widersprüchliche aktive Version,
- Erhalt der P08-Kennzeichnung nicht aufgelöster Referenzen,
- Cancellation und relevante Persistenzfehler,
- Migration, falls das Schema geändert wird,
- Architekturgrenzen.

Ergänze einen reproduzierbaren Performancetest oder Benchmark mit einer
realistischen Größenordnung von mindestens 50.000 Itemtypen. Dokumentiere
Hardware, Buildkonfiguration, Datensatz, Abfragearten, Wiederholungszahl und
gemessene Werte. Der Test muss außerdem nachweisen, dass die Ergebnisgrenze
nicht erst nach unbeschränkter Materialisierung des vollständigen Katalogs
angewendet wird. Eine Leistungsbehauptung ohne Messung ist unzulässig.

## 9. Nicht Bestandteil

- sichtbare Itemauswahl oder neue Katalogansicht,
- Rezeptpriorisierung und vollständiger Aktivitätsresolver,
- T1-/T2-/Reaktionsberechnung,
- Produktionsgraph,
- Live-ESI- oder Marktdaten,
- Marktgruppenstammtabelle oder Skillanforderungen,
- Änderung, Rotation oder Löschung alter SDE-Versionen,
- automatische Reparatur der 21 offiziellen Referenzlücken.

## 10. Dokumentation

Aktualisiere nach der Implementierung mindestens:

- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- relevante Architektur- und Datenmodelldokumentation,
- gegebenenfalls Migration und ADR,
- `Documentation/Progress/Reports/YYYY-MM-DD_P09_Item-Blueprintkatalog.md`
  mit dem tatsächlichen Ausführungsdatum.

Prüfe in `OFFEN.md` jeden aktiven Eintrag erneut. Dokumentiere für notwendige,
in P09 übernommene Punkte den konkreten Erledigungsnachweis. Nicht betroffene
Punkte erhalten einen aktuellen Prüfvermerk, werden aber nicht künstlich als
erledigt markiert.

## 11. Build, Tests und Review

Führe mindestens aus:

```bash
./Scripts/ci-verify.sh
```

Falls ein zusätzlicher Performance- oder Real-SDE-Test nicht Bestandteil des
Skripts ist, führe und dokumentiere ihn separat. Notiere jeden tatsächlich
verwendeten Befehl, Produkt, Konfiguration, Ergebnis, Warnung und Fehler.

Führe anschließend einen gesonderten Review gemäß `REVIEW_RULES.md` durch. Der
Review prüft insbesondere aktive Versionsbindung, Abfragebegrenzung,
Schichtengrenzen, deterministische Sortierung, die P08-Referenzkennzeichnung
und die Bearbeitung aller für P09 notwendigen offenen Punkte.

## 12. Definition of Done

P09 darf nur `✅ erledigt` sein, wenn:

1. alle in Abschnitt 3 genannten und neu erkannten notwendigen offenen Punkte
   bearbeitet oder nachweisbar als Blocker ausgewiesen sind,
2. aktive Versionsabfragen, ID-Lookups, Suche, Filter und Begrenzung
   implementiert sind,
3. Blueprint-/Produktbezüge ohne Rezeptpriorisierung verfügbar sind,
4. keine unbeschränkte Vollmaterialisierung im normalen Suchpfad erfolgt,
5. relevante Normal-, Rand-, Fehler-, Versions- und Regressionstests
   erfolgreich sind,
6. Debug- und Release-Prüfung erfolgreich sind,
7. die Performanceprüfung tatsächlich ausgeführt und dokumentiert wurde,
8. keine durch P09 verursachte kritische oder hohe Regression offen ist,
9. Pflichtdokumentation, OFFEN-Audit und Abschlussbericht vollständig sind,
10. der gesonderte Review bestanden wurde.

Fehlt eine Voraussetzung, erhält P09 `⚠️ teilweise oder blockiert` oder
`❌ fehlgeschlagen`. P10 darf nicht automatisch begonnen werden.

## 13. Ausführungsergebnis

Ausgeführt und reviewed am 2026-07-23.

- Application-Port, drei Use-Cases und typisierte Ergebnisse implementiert.
- Exakte Item-/Blueprint-Lookups, normalisierte Suche, Filter,
  Aktivversionsbindung, stabile Sortierung, Limit und `hasMore` umgesetzt.
- Rohe Produktionsbezüge einschließlich zusammengefasstem Auflösungsstatus
  verfügbar.
- Schema v3 mit persistentem `searchName` und getestetem v2→v3-Backfill
  eingeführt.
- 50.000-Item-Messnachweis: zehn Suchen in 0,300 s Debug und 0,296 s Release,
  je höchstens 51 geladene Itemzeilen.
- Debug und Release jeweils 100 Tests, 0 Fehler.
- offizieller Build 3424810 im finalen Schema-v3-Stand gespeichert, erneut
  geöffnet und über den Katalog geprüft.
- `OFF-003` enthält nur noch den P10-Resolver; `OFF-016` bleibt bewusst P10.
- Reviewentscheidung: **✅ bestanden**.

Abschlussbericht:
[2026-07-23_P09_Item-Blueprintkatalog](../../Progress/Reports/2026-07-23_P09_Item-Blueprintkatalog.md).
