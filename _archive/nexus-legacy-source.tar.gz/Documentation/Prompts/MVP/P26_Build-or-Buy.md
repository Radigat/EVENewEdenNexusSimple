# P26 – Schlanker Produktionsentscheidungsplan

Status: **✅ erledigt**

## Ziel

Aus dem vorhandenen P19-Graphen und P22–P25-Lagerstand einen
reproduzierbaren Arbeitsplan erzeugen: Bestand verwenden, geeignete
Zwischenstufen bauen oder kaufen sowie Produktions-, Inventions- und
Fehlmengenlisten ausgeben.

## Voraussetzungen

P17–P25 sind erledigt. Vor Änderungen aktuellen Code, Git-Status sowie
P26-relevante Einträge in `OFFEN.md` prüfen.

## Umfang

- Bestand wird automatisch nach P22–P25 berücksichtigt.
- Für jede produzierbare Zwischenstufe gibt es nur **Bauen** oder
  **Kaufen**.
- **Bauen** behält die vorhandene Unterkette; **Kaufen** beendet sie an
  dieser Type-ID und erzeugt Kaufbedarf.
- T2-Inventionsknoten aus P17 bleiben sichtbar und liefern eine getrennte
  Inventionsjobliste. Die je erfolgreicher Kopie verbrauchten
  Inventionsmaterialien werden aus dem versionsgleichen SDE-Rezept gelesen
  und mit der Zahl benötigter erfolgreicher Kopien multipliziert; es werden
  keine Fehlversuche erfunden.
- Produktions- und Inventionsjobs behalten stabile Graphknoten-IDs;
  Bedarfe und fehlende Kaufmengen werden deterministisch nach Type-ID
  aggregiert.
- Entscheidungen werden projektbezogen lokal gespeichert und nach
  Neuberechnung wieder angewendet, sofern die Type-ID noch existiert.
- Ungültige/veraltete Entscheidungen bleiben sichtbar und blockieren die
  Speicherung statt stillschweigend geraten zu werden.

## Nicht enthalten

`Ignorieren`, automatische Empfehlung, Preise, Kosten, Gewinn, ROI,
Marktdaten, Netzwerk-/ESI-Zugriffe, Einkaufsstatus, CSV-Export, Slotplanung
und Optimierung.

## Mit zu erledigende offene Punkte

- `OFF-011`: nur der für den Kern notwendige Fehlmengenanteil; Preise,
  Kosten und erweiterter Einkauf bleiben verschoben.
- P17-Restbefund: Die Graphreferenz enthält Inventionsmaterial-Type-IDs,
  aber keine Mengen. P26 löst die Mengen versionsgebunden aus dem
  vorhandenen SDE-Rezept und blockiert bei fehlenden oder widersprüchlichen
  Daten.
- Weitere aktive Punkte nur übernehmen, wenn sie Build, Datenintegrität
  oder die folgenden Kriterien tatsächlich blockieren.

## Abnahme

1. T1- und T2-/Inventionsgraph liefern stabile Bauen/Kaufen-Ergebnisse.
2. Bestand, Sicherheitsbestand und Reservierungen werden nicht doppelt
   verrechnet.
3. Kaufentscheidung schneidet genau die gewählte Unterkette ab.
4. Inventionsjobs bleiben bei T2 sichtbar und korrekt zugeordnet.
   Datacore-/Inventionsmaterialbedarf wird ohne erwartete Fehlversuche in
   den Lagerabgleich einbezogen.
5. Entscheidungen überleben Store-Wiederöffnung und Projektduplikation ist
   ausdrücklich definiert.
6. Eine nötige neue Persistenzstufe ist additiv; Migration, Leerstore,
   Wiederöffnung und Backupkompatibilität sind geprüft.
7. Leere, veraltete, zyklische und überlaufende Eingaben schreiben nichts.
8. Domain-, Service- und Persistenztests bestehen.
9. `swift test` Debug besteht; Xcode ist nur bei Projekt-/UI-Änderung
   zusätzlich erforderlich.
10. Statusdokumente und ein kurzer Abschlussbericht sind aktualisiert.

## Umsetzung und Prüfungen

- Domain: typisierte Entscheidungen, Arbeitsplan, Jobs, Bedarfe und
  deterministischer Graphschnitt.
- Application: aktuelle Graph-/SDE-/Lager-/Schutz-/Reservierungsdaten
  lesen, Vorschau erzeugen und erst nach Bestätigung speichern.
- Persistence: additive Schema-v15-Entscheidungen; Duplikate starten
  bewusst mit Standard **Bauen**.
- Tests: T1, T2/Invention, Kauf-Schnitt, Lager/Schutz/Reservierungen,
  veraltete Daten, Überlauf, Bestätigung, Wiederöffnung, Migration,
  Leerstore und Backup.
- Befehle: fokussierte P26-Tests, danach einmal `swift test -c debug`.

P32 und P37 werden nicht begonnen.
