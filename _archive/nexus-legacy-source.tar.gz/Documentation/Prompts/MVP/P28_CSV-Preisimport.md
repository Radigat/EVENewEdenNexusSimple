# P28 – CSV-Preisimport

Status: **✅ erledigt · 2026-07-25**

## Zweck

Externe Preislisten kontrolliert in ein vorhandenes P27-Preisprofil
übernehmen. Vor jedem Schreibvorgang werden Quelle, Format, Spalten,
Itemreferenzen und Konflikte zeilengenau geprüft und als Vorschau angezeigt.

## Voraussetzungen

- P05: Test- und Referenzdatenfundament,
- P09: veröffentlichter lokaler Itemkatalog,
- P27: exakte ISK-Preise, Profile, Gültigkeit und Schema v16,
- bestehender sicherer CSV-Transport aus P21.

## Nicht-Ziele

- keine Kosten-, Gewinn-, ROI- oder Break-even-Rechnung (P29),
- keine Einkaufslistenänderung (P30/P31),
- keine Live-Marktpreise oder ESI,
- keine automatische Profilanlage oder Profilaktivierung,
- keine Löschung von Preisen, die nicht in der Datei vorkommen,
- keine Tausendertrennzeichen oder Währungsumrechnung.

## CSV- und Formatvertrag

- maximale Dateigröße 16 MiB, maximal 100.000 Datenzeilen und 64 Spalten,
- UTF-8, UTF-16, Windows-1252 und ISO-8859-1 wie im geprüften P21-Parser,
- Komma, Semikolon oder Tabulator; automatische Erkennung ist zulässig,
- Pflichtspalten: positive `type_id` und `price`,
- optionale Spalte: `item_name` zur Gegenprüfung,
- Spalten werden sichtbar zugeordnet; eindeutige Standardnamen werden
  vorbelegt,
- Preisformat wird ausdrücklich als Dezimalpunkt oder Dezimalkomma gewählt,
- ganze Werte und höchstens zwei Nachkommastellen; null, Vorzeichen,
  Gruppierung, Überlauf und ein falsches Dezimalzeichen sind ungültig,
- Gültigkeitsbeginn und optionales exklusives Gültigkeitsende gelten
  einheitlich für den gesamten Import,
- rohe Datei und lokaler Dateipfad werden nicht persistiert.

## Vorschau und Konflikte

- nur veröffentlichte Items der aktiven lokalen SDE-Version sind zulässig,
- ein optionaler Itemname muss normalisiert mit dem Katalog übereinstimmen,
- doppelte Type-IDs machen alle betroffenen Zeilen ungültig,
- neue Preise werden als `Hinzufügen` markiert,
- identische Beträge und Gültigkeiten als `Unverändert`,
- abweichende vorhandene Preise verlangen je Zeile `Ersetzen` oder
  `Überspringen`,
- ungültige Zeilen werden erklärt und nie geschrieben,
- ein Profil- oder Preiswechsel nach der Vorschau macht diese veraltet,
- Abbruch oder fehlende Bestätigung schreibt nichts.

## Import und Protokoll

- nur ausdrücklich bestätigte Einfügungen und Ersetzungen werden atomar
  zusammen mit einem zeilengenauen Bericht gespeichert,
- importierte Preise erhalten Quelle `csv`,
- jede Mutation prüft den in der Vorschau gesehenen Profil-/Preiszustand,
- der Bericht enthält Profil, Zeit, bereinigten Dateinamen, SHA-256,
  Kodierung, Trennzeichen, Preisformat, Summen und jede Zeilenentscheidung,
- Importberichte sind lokal abrufbar; Geheimnisse, Dateipfade und Rohdaten
  werden nicht gespeichert,
- Schema v17 ergänzt ausschließlich den Importbericht; Preis- und
  Benutzerdaten bleiben erhalten,
- Backupformat steigt auf 17.0.0.

## Mit zu erledigende offene Punkte

- `OFF-011`/`PRC-002`: ausschließlich den CSV-Preisimport schließen;
  P29–P31 bleiben offen.
- `OFF-021`: keine neuen SDE-Datensätze importieren; der P09-Katalog genügt.
- Schema-/Backup-/Recovery-Dokumentation auf v17/17.0.0 aktualisieren.
- Unabhängige Release-, Performance-, Recovery- und Future-Punkte prüfen,
  aber nicht vorziehen.

## Prüfplan

1. Preisformat-, Mapping- und Vorschautests,
2. ungültige, doppelte, unbekannte, unveröffentlichte und namensfalsche Items,
3. Einfügung, unverändert, Ersetzen, Überspringen und fehlende Entscheidung,
4. Abbruch, fehlende Bestätigung und veraltete Vorschau,
5. atomarer Commit und persistenter Detailbericht,
6. v16→v17-Migration, Leerstore, Wiederöffnung und Backup 17.0.0,
7. ViewModel-/UI-/Architekturtests,
8. vollständige SwiftPM- und Xcode-Debugtests,
9. gesonderter Review von Diff, Datenwirkung, Tests und Dokumentation.

## Messbare Abnahme

- CSV-Datei kann geprüft, zugeordnet und ohne Schreibwirkung angezeigt werden.
- Jede Zeile besitzt einen nachvollziehbaren Zustand und konkrete Fehler.
- Konflikte erfordern Einzelentscheidungen und eine abschließende Bestätigung.
- Import und Bericht sind atomar; Abbruch und Stale State erhalten Altbestand.
- importierte Beträge bleiben exakt und tragen Quelle `csv`.
- Schema v17 und Backupformat 17.0.0 sind bestandsschützend geprüft.
- UI besitzt Datei-, Format-, Mapping-, Vorschau-, Bestätigungs-, Fortschritts-
  und Berichtszustände.
- relevante und vollständige Tests bestehen ohne Überspringen.
- Abschlussdokumentation und Review sind vollständig.

Scheitert ein Kriterium, bleibt P28 `⚠️` oder `❌`.
