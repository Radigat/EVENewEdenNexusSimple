# P58 – Produktionskosten und Preisvorschläge

Status: ⚠️ technisch umgesetzt · Eigentümer-Sichttest OFF-060 offen

## Ziel

Erwartete Kosten einer Produktionscharge vollständig aufschlüsseln und daraus
Stückkosten, Preisvorschläge sowie Marktvergleiche in ISK ableiten.

## Voraussetzungen

- P57 abgeschlossen,
- P27–P29, P41 und P55 gezielt wiederverwenden,
- ADR-0054, `MARKET_PRICES.md`, OFF-056 und OFF-058 erneut prüfen,
- keine zweite ESI-, Cache- oder Preissatzimplementierung anlegen.

## Erwartetes Ergebnis

Versionierte `ProductionBatchCostSnapshot`- und `PriceQuoteBinding`-Verträge,
die jede Kosten- und Preiszahl bis zu Regel, Quote oder manueller Quelle
erklären.

## Kostenarten

- Material,
- System-Cost-Index und Industry-Job,
- Facility-/SCC-Abgabe und Produktionssteuer,
- BPO/BPC, Kopie, Invention und Decryptor,
- Logistik,
- Markt-/Broker-/Transaktionsgebühr,
- sonstige ausdrücklich manuelle Kosten.

Jede Zeile enthält Betrag, Art, Quelle, Zeitstand, Zuordnungsart und Warnungen.
Unbekannte Steuer-/Gebührenwerte bleiben unbekannt und werden nicht als Null
gerechnet. BPO-Anschaffungskosten werden nie automatisch voll amortisiert.

## Verbindlicher Preisquellenvertrag

Priorität für erwartete Material- und Verkaufspreise:

1. öffentliche Live-ESI-Orders am ausgewählten benannten Markt,
2. gültiger ESI-Cache derselben Quelle,
3. sichtbar veralteter Offline-/Limit-Cache derselben Quelle,
4. ausdrücklich gewählter manueller oder CSV-Preissatz,
5. `nicht verfügbar`; niemals stillschweigend 0 ISK.

Standardmarkt ist Jita IV – Moon 4. Der Benutzer kann stattdessen jede
benannte ESI-Region, einen der fünf Trade Hubs oder eine bekannte, öffentlich
abrufbare Station/Struktur als Marktquelle wählen und diese Vorgabe später
ändern. Nur private Strukturen bleiben gesperrt, bis ein eigener
authentifizierter Marktvertrag existiert.

Materialbeschaffung verwendet den mengenbezogenen Preis der günstigsten
vollständig erfüllbaren Sell-Orders. Der Zielproduktvergleich verwendet eine
separat bezeichnete öffentliche Sell-Quote für Jita und den gewählten
Home-/Alternativmarkt. Buy, Sell, Cache und manuelle Werte dürfen nicht
vertauscht oder verdeckt ersetzt werden.

Jeder Quote bindet Type-ID, Region, Location, Seitenrolle, Menge,
Orderanzahl, Beobachtungszeit, Ablauf, Snapshot-ID, Policy-Version und
Fallbackstatus. Eine Neuberechnung erzeugt einen neuen Snapshot; historische
Chargenkosten bleiben unverändert.

## Berechnung

```text
Gesamtkosten = Summe aller erwarteten Kostenzeilen
Kosten je Unit = Gesamtkosten / tatsächliche Output-Units
Vorschlag 5 % = Kosten je Unit × 1,05
Vorschlag 10 % = Kosten je Unit × 1,10
Prognoseerlös = gewählter Verkaufspreis je Unit × Output-Units
Prognosegewinn = Prognoseerlös − Gesamtkosten
Marge = Prognosegewinn / Prognoseerlös
ROI = Prognosegewinn / Gesamtkosten
Break-even = Gesamtkosten / Output-Units
```

Aufschlag und Zielmarge bleiben begrifflich getrennt. Ganzzahlige
ISK-Hundertstel und dokumentierte Rundungsstufen verwenden.

## UI-Ablauf

- Charge und Marktquelle auswählen,
- Quotes schreibfrei abrufen und Datenstand anzeigen,
- im eingebetteten Ablauf einen Ziel-Preissatz verständlich anlegen oder
  auswählen und nach bestätigter Übernahme das Budget aktualisieren,
- fehlende/stale/illiquide Positionen einzeln ausweisen,
- Preissatz-Fallback nur ausdrücklich auswählen,
- Kostenbasis und Marktquelle als Vorschau bestätigen,
- erneutes Laden ersetzt keinen bestätigten historischen Snapshot.

## Nicht-Ziele

- keine automatische BPO-Amortisation,
- keine erfundenen Steuern oder private Strukturorders,
- kein Realgewinn ohne bestätigte Transaktionen,
- keine Marktprognose oder automatische Verkaufsentscheidung.

## Mit zu erledigende offene Punkte

- OFF-056: P29-Rechner nur über den neuen Chargenvertrag anbinden.
- OFF-058: sicheren, aber derzeit unvollständigen Übergang von
  ESI-Preisvorschau zu Ziel-Preissatz und Budget ohne parallele
  Preisimplementierung schließen.
- OFF-048/ADR-0054-Abdeckung wiederverwenden; keine ID-zentrierte Bedienung.

## Tests und Abnahme

- Mehrfachoutput, Rundung, Overflow und Division durch null,
- Jita, anderer Trade Hub, benannter Home-Markt und Region ohne Location,
- kein vorhandener Ziel-Preissatz, Neuanlage/Auswahl, bestätigte Übernahme
  und anschließende Budgetneuberechnung,
- unvollständiges Orderbuch, keine Orders, stale/offline Cache und Fallback,
- manuell/CSV nur nach Auswahl, Quellwechsel und deterministischer Replay,
- vollständige fokussierte Tests, SwiftPM-Gesamtlauf und Xcode-Debugbuild,
- Eigentümertest mit Jita und einer geänderten Marktquelle,
- Dokumentation und Review vollständig; keine produktive Preisübernahme ohne
  bestätigte Vorschau.
