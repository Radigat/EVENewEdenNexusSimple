# P17 – T2-Berechnung

Status: **✅ erledigt und reviewed am 2026-07-24**

## Zweck

P17 erweitert den durch P16 geschaffenen rekursiven Manufacturing-Graphen
um eine fachlich belastbare T2-Klassifikation und T2-Blueprintqualität.
T2-Ziele und T2-Zwischenprodukte werden als solche erkannt, verwenden keine
pauschal erfundene Zwischenprodukt-ME und werden einschließlich ihrer
Manufacturing-, T1- und Komponentenabhängigkeiten deterministisch
aufgelöst. Notwendige Reaktionsprodukte bleiben bis P18 ausdrücklich
begründete Grenzen.

P17 legt zugleich die gemeinsame versionierte Industrie-Regelbasis an, die
P18 erweitert. Die Spezifikationsgrundlage ist
[`INDUSTRY_RULES_FOUNDATION.md`](../../INDUSTRY_RULES_FOUNDATION.md).

## Voraussetzungen

- P10: deterministischer Rezept- und Aktivitätsresolver,
- P12: kataloggebundenes Zielprodukt,
- P13–P16: validierter Graph, Runs, Blueprint-ME und rekursive
  Manufacturing-Auflösung,
- aktiver SDE-Katalog mit konsistenter Buildnummer und Prüfsumme,
- aktuelle Prüfung der in `INDUSTRY_RULES_FOUNDATION.md` genannten
  offiziellen Quellen,
- vollständiger Audit von `OFF-004`, `OFF-021`, `OFF-028`, `KI-003`,
  `KI-021` und `KI-028`.

## Erwartetes Ergebnis

- T1 und T2 werden über die konkrete SDE-Invention-Beziehung des
  Fertigungs-Blueprints klassifiziert,
- Blueprintdefinition und konkrete beziehungsweise geplante
  Blueprintqualität sind getrennt,
- T2-BPC-Qualität wird herkunftsgerecht validiert,
- reguläre Invention-Ergebnisse verwenden die verifizierten
  ME-/TE-/Run-/Decryptorregeln,
- historische T2-BPOs und daraus kopierte BPCs bleiben als explizite
  Ausnahme darstellbar,
- T2-Manufacturing-Ketten werden rekursiv über alle Manufacturing-Stufen
  aufgelöst,
- notwendige Reaktionen bleiben bis P18 begründete Blätter,
- jedes Ergebnis trägt SDE-, Regel- und Blueprintqualitätsprovenienz,
- unvollständige oder nicht verifizierbare T2-Daten scheitern sichtbar und
  erhalten einen vorhandenen Graphen,
- alte Projekte und Graphformate bleiben lesbar und eindeutig veraltet,
- Laufzeitcode, Tests und Dokumentation verwenden dieselbe versionierte
  Industrie-Regelbasis.

## Verbindliche Inventionsabgrenzung des MVP

### Enthalten

1. Tech-II über ein eindeutiges
   `activities.invention.products[]`-Ergebnis für den verwendeten
   Fertigungs-Blueprint bestimmen; ohne solchen Treffer bleibt die Stufe
   Tech I.
2. T2-Manufacturing-Rezepte und deren T1-/T2-Komponenten rekursiv
   auflösen.
3. Blueprint-Herkunft, BPO/BPC-Art, ME, TE und lizenzierte Runs als
   deterministisches Planungsszenario modellieren.
4. Reguläre T2-Invention-Ergebnisse aus Basis ME 2 / TE 4 und
   Decryptorwerten validieren.
5. Grundruns und Basiswahrscheinlichkeit aus dem konkreten
   `activities.invention.products[]`-SDE-Produkt beziehen.
6. Invention-Ausgangs-BPC, Datacores und optionalen Decryptor als
   nachvollziehbare Referenzdaten erfassen.
7. Fehlende oder `nil` Basiswahrscheinlichkeit fail-closed behandeln.
8. Historische T2-BPOs und daraus erstellte BPCs von regulär erfundenen
   BPCs unterscheiden.
9. Für automatisch entdeckte T2-Zwischenprodukte eine sichtbare,
   deterministische Standardplanung „reguläre Invention ohne Decryptor“
   verwenden, sofern keine explizite stufenbezogene Planungsqualität
   vorliegt.
10. Stufenbezogene T2-Qualitätsüberschreibungen fachlich ermöglichen, ohne
    persönliche ESI-Daten vorwegzunehmen.
11. Nur Invention aus einem selbst fertigbaren Ausgangs-Blueprint als T2
    akzeptieren; Reverse Engineering beziehungsweise T3 wird typisiert
    abgelehnt und nicht als T2 oder T1 umgedeutet.

### Nicht enthalten

- Zufallssimulation einzelner Invention-Versuche,
- Berechnung erwarteter Fehlversuche oder Konfidenzintervalle,
- Datacore-, Decryptor- oder Invention-Jobkosten,
- Optimierung des besten Decryptors,
- vollständiger Kopier- oder Forschungsworkflow,
- persönliche Blueprintbibliothek oder ESI-Blueprintimport,
- Invention-Jobhistorie,
- T3-Invention,
- Reaktionsrekursion; sie folgt P18,
- Facility-, Rig-, Security- oder Skillzeitberechnung für Manufacturing,
- Aggregation gleicher Materialien; sie folgt P19.

Die gespeicherten SDE- und Regelwerte müssen spätere Erweiterungen erlauben,
ohne P17 als vollständiges Invention-Management darzustellen.

## Verbindlicher SDE-Datenumfang

Der Quellcode-Audit hat ergeben, dass der bestehende Katalog die für P17
benötigten Daten bereits vollständig und versioniert speichert:

1. Invention-Ausgangs-Blueprint,
2. konkretes Invention-Produkt als T2-Fertigungs-Blueprint,
3. produktspezifische Grundruns,
4. produktspezifische Basiswahrscheinlichkeit,
5. verbrauchte Invention-Materialien beziehungsweise Datacores,
6. vollständige T2-Manufacturing-Rezepte.

`metaGroups`, Aktivitäts-Skills und Decryptor-Dogmawerte werden für die
deterministische Materialplanung nicht benötigt: Die eindeutige
Invention-Beziehung klassifiziert die tatsächlich herstellbare T2-Stufe,
Skills sind keine verbrauchten Materialien und die aktuellen
Decryptorregeln sind ein versionierter, gegen die offizielle CCP-Hilfeseite
geprüfter Regelvertrag. Diese Datensätze werden deshalb nicht nur zur
Bestätigung einer bereits eindeutigen Entscheidung zusätzlich importiert.
P18 prüft seinen eigenen zusätzlichen Dogma-Bedarf getrennt.

Der offizielle Real-SDE-Abnahmerunner muss mindestens Blueprint `691` →
T2-Blueprint `11372`, Grundrun `1`, Basiswahrscheinlichkeit `0,3` und die
Datacores `20172`/`20424` nach Wiederöffnung nachweisen.

## Fachmodelle

Mindestens modellieren:

### `IndustryRuleSet`

- Regelversion,
- SDE-Buildnummer und Inhaltsprüfsumme,
- Prüfdatum und Quellen,
- unterstützte Tech-Stufen und Aktivitäten,
- Decryptorregeln,
- Rundungs- und Qualitätsregelversionen,
- Status `verified`, `provisional` oder `needsReview`.

### `BlueprintPlanningQuality`

- Blueprint-Type-ID,
- Herkunft,
- BPO/BPC-Art,
- ME,
- TE,
- lizenzierte Runs,
- optional Decryptor-Type-ID,
- Regel- und SDE-Provenienz.

Zulässige Herkunft mindestens:

- `researchedBPO`,
- `copiedFromBPO`,
- `inventedBPC`,
- `legacyT2BPO`,
- `manualPlanningAssumption`.

### `T2StagePlanningPolicy`

- Standardqualität für automatisch entdeckte T2-Stufen,
- stufenbezogene Überschreibung anhand stabiler Blueprint- oder Knoten-ID,
- sichtbare Herkunft jeder Entscheidung,
- keine Verwechslung mit tatsächlich besessenen Blueprints.

## Verbindliche T2-Regeln

### Regulär erfundene T2-BPCs

| Decryptor | CCP-Type-ID | Chance | Runs | ME | TE |
|---|---:|---:|---:|---:|---:|
| keiner | — | ×1,0 | +0 | 2 | 4 |
| Accelerant | 34201 | ×1,2 | +1 | 4 | 14 |
| Attainment | 34202 | ×1,8 | +4 | 1 | 8 |
| Augmentation | 34203 | ×0,6 | +9 | 0 | 6 |
| Parity | 34204 | ×1,5 | +3 | 3 | 2 |
| Process | 34205 | ×1,1 | +0 | 5 | 10 |
| Symmetry | 34206 | ×1,0 | +2 | 3 | 12 |
| Optimized Attainment | 34207 | ×1,9 | +2 | 3 | 2 |
| Optimized Augmentation | 34208 | ×0,9 | +7 | 4 | 4 |

- ME und TE des T1-Ausgangs-BPC werden nicht übertragen.
- Ein T1-BPC-Run wird je Invention-Job-Run verbraucht.
- Grundruns stammen aus dem konkreten SDE-Invention-Produkt.
- Die zwei ME-3-/TE-2-Ergebnisse bleiben über Decryptor, Chance und Runs
  unterscheidbar.
- Ein fehlender SDE-Wahrscheinlichkeitswert ist kein Standardwert.

### Historische T2-BPOs

- Nicht als reguläres Invention-Ergebnis validieren.
- Normale BPO-Forschungsgrenzen ME `0...10`, TE `0...20` unterstützen.
- Kopien übernehmen den BPO-Stand zum Kopierzeitpunkt.
- Herkunft muss sichtbar `legacyT2BPO` oder `copiedFromBPO` sein.

### Materialberechnung

- P15-Formel je Materialposition und gesamten Job wiederverwenden.
- Basismenge eins je Run bleibt auch bei T2 geschützt.
- Die T2-Stufenqualität bestimmt den ME-Wert der jeweiligen Stufe.
- T1- und T2-Zwischenstufen dürfen unterschiedliche Qualitäten besitzen.
- Ein automatisch entdecktes T2-BPC darf nicht pauschal als ME 0
  ausgegeben werden.

## Graph, Persistenz und Migration

- Neues Graphformat 5 für Tech- und Blueprintqualitätsprovenienz.
- Runformelversion 1 und Materialformelversion 1 bleiben unverändert,
  sofern die fachlichen Formeln unverändert bleiben.
- Expansionsrichtlinie erhält eine neue Version.
- Jeder Rezeptknoten speichert:
  - Tech-Stufe,
  - Blueprint-Herkunft,
  - BPO/BPC-Art,
  - ME und TE,
  - lizenzierte Runs beziehungsweise deren Nichtanwendbarkeit,
  - Decryptorreferenz, falls vorhanden,
  - Regel- und SDE-Provenienz.
- Reaktionsblätter bleiben bis P18 ausdrücklich `reactionDeferred`.
- Graphformate 1 bis 4 bleiben lesbar und gelten gegenüber Format 5 als
  veraltet.
- Die neuen Werte liegen im bereits codierten Graphpayload; es entstehen
  keine neuen Projekt- oder Katalogspalten.
- SwiftData-Schema v8 und Backupformat 8.0.0 bleiben unverändert.
- Zweite Öffnung, Format-5-Roundtrip und Graphformate 1 bis 4 werden
  weiterhin geprüft.
- Bestehende Projekte erhalten keine erfundene T2-Herkunft. Fehlt die für
  eine T2-Neuberechnung notwendige Qualität, muss die App eine bewusste
  Auswahl oder ein transparentes Standardszenario verlangen.

## Fehler- und Schutzregeln

Mindestens typisiert behandeln:

- mehrdeutige Invention-Quelle und Katalogversionswechsel,
- T2-Ziel ohne gültige Blueprintqualität,
- ungültige ME-/TE-/Decryptor-Kombination,
- reguläres Invention-Ergebnis ohne Wahrscheinlichkeit,
- fehlende oder ungültige Grundruns,
- T2-BPC mit unzureichenden lizenzierten Runs,
- historische T2-BPO-Herkunft ohne konsistente BPO-Werte,
- SDE-/Regelversionswechsel während der Traversierung,
- vorhandene P16-Resolver-, Zyklus-, Limit-, Overflow- und
  Cancellationfehler.

Ein Fehler darf keinen vorhandenen Graphen, kein Projekt und keine aktive
SDE-Version teilweise überschreiben.

## Agent-Preflight

Vor Berechnung und Abschluss prüft ein zentraler, maschinenlesbarer
Preflight:

1. aktiver SDE-Build und `IndustryRuleSet` stimmen überein,
2. alle Tech-Stufen und Typreferenzen sind aufgelöst,
3. T2-Blueprintqualität passt zur Herkunft,
4. Invention-Produkt besitzt Grundruns und Wahrscheinlichkeit,
5. Decryptorwerte sind vollständig und aktuell,
6. jeder T2-Knoten besitzt sichtbare Qualitätsprovenienz,
7. Reaktionsgrenzen bleiben bis P18 sichtbar,
8. Golden Fixtures und Real-SDE-Prüfung bestehen.

`fail` oder `needsReview` verhindert den Status `✅ erledigt`.

## Referenzfälle

Mindestens:

### T2-R1 – reguläres T2-BPC ohne Decryptor

- Tech-II-Ziel,
- Herkunft `inventedBPC`,
- ME 2 / TE 4,
- Grundruns aus SDE,
- vollständige Manufacturing-Kette,
- Reaktionsmaterial als `reactionDeferred`.

### T2-R2 – alle Decryptoren

Alle acht Decryptoren und der Fall ohne Decryptor liefern exakt die
verbindlichen ME-/TE-/Run-/Chancewerte. Parity und Optimized Attainment
bleiben unterscheidbar.

### T2-R3 – keine Vererbung vom T1-BPC

Zwei T1-Ausgangs-BPCs mit unterschiedlichen ME/TE erzeugen bei identischem
Decryptor dieselbe T2-Blueprintqualität.

### T2-R4 – historisches T2-BPO

ME 10 / TE 20 ist mit Herkunft `legacyT2BPO` zulässig und wird nicht gegen
die Invention-Kombinationen abgelehnt.

### T2-R5 – Einzelelementschutz

Ein T2-Rezept mit einem T1-Eingangsprodukt je Run reduziert dieses Material
bei keiner zulässigen ME-Stufe unter die Runanzahl.

### T2-R6 – SDE-Grundruns

Mindestens ein Produkt, dessen Invention-Grundruns nicht dem vereinfachten
1-/10-Schema entsprechen, verwendet exakt den SDE-Produktwert.

### T2-R7 – fehlende Wahrscheinlichkeit

Ein Invention-Produkt mit `probability == nil` wird sichtbar blockiert und
nicht mit einem Klassenstandard ergänzt.

### T2-R8 – gemischte Kette

T2-Ziel → T2-Komponente → T1-Komponente → Rohmaterial; jede Stufe besitzt
korrekte Runs, Ausgabe, Überschuss, ME und Herkunft.

## Mit zu erledigende offene Punkte

| ID | Restarbeit in P17 | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | T2-Manufacturing-Anteil auf der P16-Graphbasis schließen; Reaktionen und Aggregation sichtbar offen lassen. | T2-R1 bis T2-R8, Graphformat-5- und Bestandsschutztests |
| OFF-021 / KI-021 | P17-Datenbedarf gegen den vorhandenen Katalog prüfen und nur nachgewiesen fehlende Datensätze ergänzen. | Quellcode-Audit und Real-SDE-Nachweis der konkreten Invention-Beziehung |
| OFF-028 / KI-028 | Gemeinsame versionierte Industrie-Regelbasis, Blueprint-Herkunft und Agent-Preflight implementieren. | Regelmanifest, Preflight-Fälle, Quellen- und Versionsprüfung |
| OFF-009 / KI-012 | Vorhandenen Überlaufschutz für alle neuen T2-Stufen wiederverwenden; Aggregationssummen bleiben P19. | T2-Run-/Materialgrenzfälle und Altgraph-Erhalt |

`OFF-006`/`KI-006`/`KI-013` bleiben unberührt, weil P17 weder neue
SwiftData-Spalten noch eine Backupformatänderung benötigt. Der vollständige
Recovery-Drill bleibt P36. `OFF-027`/`KI-027` bleibt P34;
eine notwendige kleine P17-Editorergänzung darf keine mechanische
Großaufteilung vorziehen.

## Automatisierte Tests

Zusätzlich zu T2-R1 bis T2-R8 mindestens:

- eindeutige, fehlende und mehrdeutige Invention-Beziehung,
- Regelmanifest-Codable und unbekannte Regelversion,
- stufenbezogene Standard- und Überschreibungsqualität,
- ungültige Herkunfts-/BPO-/BPC-Kombinationen,
- unzureichende BPC-Runs,
- deterministische Wiederholung,
- SDE-/Regelwechsel während der Traversierung,
- P16-Zyklus-, Tiefen-, Knoten-, Overflow- und Cancellationregressionen,
- Graphformat-1- bis -4-Kompatibilität und Format-5-Manipulationsschutz,
- Format-5-Persistenz und Stale-Erkennung,
- Format-5-Roundtrip im bestehenden Schema v8,
- unveränderte Backupkompatibilität 1.0.0 bis 8.0.0,
- UI-/ViewModel-/Accessibility- und Architekturgrenzen,
- offizieller Real-SDE-Lauf mit Counts, repräsentativem T2-Ziel,
  Decryptoren und `nil`-Wahrscheinlichkeitsfällen.

## Build und manuelle Prüfung

- SwiftPM Debug und Release,
- Xcode Debug und Release auf My Mac ohne Signingänderung,
- Xcode-Projektparität nach notwendigen neuen Dateien/Targets prüfen,
- isoliertes App-Binary mit eigenem Schema-v8-Store starten,
- `PRAGMA integrity_check`,
- keine produktiven Benutzerdaten öffnen oder verändern,
- eine nicht ausgeführte visuelle oder VoiceOver-Prüfung nicht behaupten.

## Dokumentation

Mindestens aktualisieren beziehungsweise neu erstellen:

- `Documentation/INDUSTRY_RULES_FOUNDATION.md`,
- produktive T2-/Industrie-Regeldokumentation,
- SDE-Import, Datenmodell, Architektur und Graphdokumentation,
- ADR für Tech-Klassifikation, Blueprintqualität und Graphformat 5,
- Entwickler-Menü, Projektstatus, Feature-Matrix, Roadmap und Tagebuch,
- `OFFEN.md`, `OPEN_TASKS.md`, `KNOWN_ISSUES.md`, `TEST_HISTORY.md`,
- Promptregister,
- Abschlussbericht
  `Documentation/Progress/Reports/2026-07-24_P17_T2-Berechnung.md`.

## Abnahmekriterien

P17 darf nur `✅ erledigt` werden, wenn:

1. alle verpflichtenden Regeln und Referenzfälle umgesetzt sind,
2. Tech-Stufe und Blueprintqualität nicht geraten werden,
3. reguläre und historische T2-Blueprints korrekt getrennt sind,
4. kein T2-Zwischenprodukt pauschal als neutraler ME-0-Blueprint
   ausgegeben wird,
5. Real-SDE-Grundruns, Wahrscheinlichkeiten und Decryptorwerte geprüft sind,
6. Industry-Preflight `pass` meldet,
7. Reaktionsgrenzen sichtbar bis P18 erhalten bleiben,
8. Migration, Backup, Altgraphen und Benutzerdaten geschützt sind,
9. SwiftPM und Xcode Debug/Release erfolgreich sind,
10. alle relevanten Tests ohne Überspringen bestanden sind,
11. isolierter App-/Store-Smoke bestanden ist,
12. Pflichtdokumentation und Abschlussbericht gespeichert sind,
13. der gesonderte Review bestanden ist.

Alle Kriterien wurden am 2026-07-24 nachgewiesen. P18 wurde in diesem
Arbeitspaket nicht implementiert.
