# P20 – Lager und manuelle Bestände

Status: **✅ erledigt und reviewed am 2026-07-24**

## Zweck

P20 schafft die lokale, offline nutzbare Grundlage für Lagerorte und manuell
gepflegte Materialbestände. Der Benutzer kann logische Lager anlegen, ändern,
archivieren und wiederherstellen sowie kataloggestützte Bestandspositionen je
Lager erfassen, ändern und ausdrücklich löschen.

## Voraussetzungen

- P03: versionierte SwiftData-Persistenz und Migrationen
- P04: zentrale Fehlerbehandlung und Logging
- P05: Testfundament
- P06: lokale Backups
- P09: aktiver Itemkatalog mit stabilen CCP-Type-IDs
- P19: geprüfter Produktionskern; wird durch P20 nicht verändert

## Ausgangszustand

- Schema v9 enthält noch keine Lager- oder Bestandsmodelle.
- Der Navigationspunkt `Assets` zeigt nur einen Platzhalter.
- Es gibt keine Domänenregeln, Repositories, Services oder Ansichten für
  manuelle Bestände.
- OFF-005/KI-005 beschreibt den gesamten Lager-/Bestandsblock P20–P25 und ist
  für P20 auf den Teil „Lagerorte und manuelle Mengen“ zu begrenzen.

## Verbindlicher Umfang

### Lagerorte

- Lager besitzen eine stabile lokale UUID, Namen, Typ, optionale Notiz,
  Archivstatus sowie Erstellungs- und Änderungszeitpunkt.
- Unterstützte Typen: Hauptlager, Produktionslager, Handelslager,
  Zwischenlager, Reaktionslager, Capital-Produktion, Verkaufslager und Sonstig.
- Namen werden getrimmt und normalisiert. Leere Namen und normalisiert doppelte
  Namen sind unzulässig, auch wenn ein Lager archiviert ist.
- Lager werden in P20 nicht hart gelöscht. Archivieren erhält alle
  Bestandspositionen; archivierte Lager sind schreibgeschützt und können
  wiederhergestellt werden.

### Manuelle Bestände

- Eine Position wird durch `(Lager-ID, CCP-Type-ID)` eindeutig bestimmt.
- Mengen sind ganzzahlige `Int64`-Einheiten und müssen größer als null sein.
  Negative, nullwertige, dezimale oder überlaufende Eingaben werden abgelehnt.
- Erneutes Speichern derselben Lager-/Type-ID-Kombination aktualisiert die
  vorhandene Position deterministisch; Mengen werden nicht stillschweigend
  addiert.
- Derselbe Typ darf in verschiedenen Lagern getrennt geführt werden.
- Neue oder geänderte Positionen werden gegen den aktiven, veröffentlichten
  Itemkatalog geprüft. Gespeichert werden stabile CCP-Type-ID, Katalogname und
  Katalogprovenienz (Buildnummer und Inhalts-Hash).
- Das Löschen einer Position erfolgt nur als eigene, bestätigte Aktion. Andere
  Positionen und das Lager bleiben unberührt.
- Ein Katalogwechsel verändert vorhandene Bestandsdaten nicht automatisch.
  Eine spätere Bearbeitung validiert die Position erneut.

### Persistenz und Migration

- Neues additives Schema v10 mit separaten Modellen für Lagerorte und manuelle
  Bestände.
- Leichtgewichtige Migration v9 → v10 ohne Änderung vorhandener Benutzer-,
  SDE-, Projekt- oder Graphdaten.
- Neue leere Datenbank und Migration eines v9-Altbestands werden getestet.
- Backup-Metadaten und Kompatibilitätsprüfung werden auf Schema 10.0.0
  erweitert.

### Anwendung und Oberfläche

- Domäne, Application-Service, Repository-Port und SwiftData-Repository bleiben
  von SwiftUI getrennt.
- Der vorhandene Navigationspunkt `Assets` öffnet „Lager & Bestände“.
- Aktive und archivierte Lager sind filterbar.
- Lager und Bestände zeigen Loading-, Empty-, Error- und Fortschrittszustände.
- Lager können angelegt, bearbeitet, archiviert und wiederhergestellt werden.
- Bestände können über eine kataloggestützte Suche angelegt, bearbeitet und
  nach ausdrücklicher Bestätigung gelöscht werden.
- Tastaturbedienung und aussagekräftige Accessibility-Texte werden vorgesehen.
- Abbrechende Tasks dürfen keinen teilweise gespeicherten Zustand erzeugen.

## Nicht Bestandteil

- CSV-Bestandsimport (P21)
- lagerübergreifende Verfügbarkeit und Ausschlüsse (P22)
- Mindest-, Ziel- und Warnbestände (P23)
- Projektreservierungen und Konflikte (P24/P25)
- Build-or-Buy, Preise und Einkaufslisten (P26 ff.)
- ESI-Assets, Besitzer, Containerhierarchien und Corporation-Daten
- virtuelle Lager, automatische Umlagerung und Logistik

## Mit zu erledigende offene Punkte

| ID | Restarbeit in P20 | Prüfnachweis |
|---|---|---|
| OFF-005 / KI-005 | Lagerorte und manuelle Bestandsmengen implementieren; den Gesamtpunkt anschließend nur als teilweise erledigt markieren, weil P21–P25 ausstehen. | Domänen-, Service-, Persistenz-, Migrations- und UI-Tests; aktualisiertes `OFFEN.md`. |

## Risiken

- Eine fehlerhafte Migration könnte vorhandene lokale Projekte oder SDE-Daten
  gefährden.
- Doppelte Lager-/Type-ID-Zeilen würden spätere Verfügbarkeitsberechnungen
  nondeterministisch machen.
- Eine automatische Mengenaddition oder kaskadierende Löschung könnte
  Benutzerdaten unbemerkt verändern.
- Veraltete Katalognamen müssen lesbar bleiben, ohne fälschlich als aktueller
  SDE-Stand ausgegeben zu werden.

## Messbare Abnahmekriterien

1. Lager können persistent angelegt, geändert, archiviert, gefiltert und
   wiederhergestellt werden.
2. Leere und normalisiert doppelte Lagernamen werden ohne Teilspeicherung
   abgelehnt.
3. Veröffentlichte Katalogitems können mit positiver `Int64`-Menge einem
   aktiven Lager zugeordnet werden.
4. Ungültige Type-IDs, unveröffentlichte Items, Mengen ≤ 0 und Überläufe werden
   abgelehnt.
5. Dieselbe Lager-/Type-ID-Kombination wird aktualisiert statt dupliziert;
   verschiedene Lager bleiben getrennt.
6. Archivierte Lager und ihre Bestände bleiben erhalten und sind bis zur
   Wiederherstellung schreibgeschützt.
7. Das Löschen einer Position entfernt ausschließlich die bestätigte Position.
8. Schema v10 öffnet leer und migriert einen befüllten v9-Bestand ohne Verlust.
9. Backups deklarieren und akzeptieren 10.0.0; eine zukünftige 11.0.0 wird
   weiterhin abgelehnt.
10. SwiftPM- und Xcode-Builds sowie alle relevanten Tests sind tatsächlich
    erfolgreich; kein Test ist übersprungen.
11. Dokumentation, OFFEN-Audit, Feature-Matrix, Tagebuch, Testhistorie,
    Architekturänderungen und Abschlussbericht sind aktualisiert.
12. Ein unabhängiger Review gegen Diff, Tests und Dokumentation ist bestanden.

## Erwartetes Ergebnis

Eine migrationssichere, kataloggestützte und in der nativen macOS-Oberfläche
nutzbare Lager-/Bestandsverwaltung als belastbare Grundlage für P21–P25.
