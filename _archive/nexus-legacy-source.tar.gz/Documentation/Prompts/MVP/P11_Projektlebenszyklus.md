# P11 – Projektlebenszyklus

Status: **✅ erledigt und reviewed**

## 1. Zweck

Produktionsprojekte vollständig lokal anlegen, wieder öffnen, bearbeiten,
nach einem nachvollziehbaren Statusmodell fortschreiben, duplizieren,
archivieren und wiederherstellen. Die bestehende `ProjectsView` wird dabei
von direkten SwiftData-Zugriffen auf Application-Use-Cases und injizierte
Ports umgestellt.

P11 bleibt beim vorhandenen Einzelziel-Projektmodell. Kataloggestützte
Zielproduktauswahl folgt P12; Graph, Runs, ME und Produktionsketten folgen
P13–P19.

## 2. Voraussetzungen und Ausgangsstand

- P03-Domänenmodell, Repository und Migrationen sind vorhanden.
- P09-Katalog und P10-Rezeptresolver sind abgeschlossen, werden in P11 aber
  noch nicht an das Projektziel gebunden.
- Das aktuelle Schema v4 verwendet weiterhin das
  `NexusSchemaV3.ProductionProject`-Modell.
- Vorhandene Projekte enthalten bereits ID, Name, Produktname, Zielmenge,
  Status, Priorität, optionalen Zieltermin, Notizen sowie Erstellungs- und
  Änderungszeitpunkt.
- Die bestehende View greift noch direkt über `@Query` und `modelContext`
  auf SwiftData zu.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-008 / KI-011 | `ProjectsView` vollständig von `@Query`, `modelContext` und konkreten Persistenztypen lösen; Application-Lebenszyklus und Composition Root verwenden. | Architekturregression, Quellcodeprüfung, ViewModel- und App-Integrationstests |

Andere aktive Punkte gehören nicht zum Ergebnis von P11: Produktionsgraph
und Mengenberechnung P13–P19, Bestände P20–P25, Preis-/Einkaufslogik
P27–P31, SDE-Wartbarkeit P34, Recovery P36 und Releaseprüfung P37.

## 4. Verbindlicher Funktionsumfang

P11 implementiert:

- Projektliste aus dem lokalen Repository laden,
- nicht archivierte, archivierte oder alle Projekte filtern,
- ein Projekt mit Status `Planung` anlegen,
- alle bestehenden Projektfelder bearbeiten,
- erlaubte Statuswechsel ausführen,
- Projekt duplizieren,
- Projekt archivieren,
- archiviertes Projekt wiederherstellen,
- gespeicherte Projekte nach erneutem Öffnen desselben Stores unverändert
  laden,
- Loading-, Empty-, Error- und Auswahlzustände in der UI.

## 5. Statusmodell

Erlaubte Übergänge:

| Von | Nach |
|---|---|
| Planung | Beschaffung, Produktionsbereit, Archiviert |
| Beschaffung | Planung, Produktionsbereit, Archiviert |
| Produktionsbereit | Planung, Beschaffung, In Produktion, Archiviert |
| In Produktion | Produktionsbereit, Abgeschlossen, Archiviert |
| Abgeschlossen | In Produktion, Archiviert |
| Archiviert | Planung |

Regeln:

- ein Wechsel auf denselben Status ist ein idempotenter No-op und verändert
  `updatedAt` nicht,
- Archivieren ist aus jedem nicht archivierten Status zulässig,
- Wiederherstellen ist nur aus `Archiviert` zulässig und setzt den Status
  auf `Planung`,
- archivierte Projekte sind schreibgeschützt; sie können nur
  wiederhergestellt oder als neues Planungsprojekt dupliziert werden,
- ein ungültiger Übergang erzeugt einen typisierten Fachfehler und schreibt
  nichts.

Diese reduzierte Statusfolge bildet den bestehenden MVP-Stand ab. Die
feingranularen Projektbuchphasen Materialprüfung, Reservierung, Transport,
Auslieferung und Verkauf folgen erst mit den jeweiligen Fachmodulen und
werden in P11 nicht vorweggenommen.

## 6. Anlegen, Bearbeiten und Duplizieren

### Anlegen

- neue UUID aus einer injizierbaren Quelle,
- `createdAt == updatedAt` aus einer injizierbaren Uhr,
- Status `Planung`,
- vorhandene Domainvalidierung für Name, Produkt, Zielmenge und Priorität.

### Bearbeiten

- ID, `createdAt` und aktueller Status bleiben erhalten,
- `updatedAt` wird auf den injizierten Zeitpunkt gesetzt,
- ein Änderungszeitpunkt vor `createdAt` ist ungültig,
- archivierte Projekte werden nicht bearbeitet.

### Duplizieren

- neue UUID,
- Name erhält den Suffix ` – Kopie`,
- Produkt, Menge, Priorität, Zieltermin und Notizen werden übernommen,
- Status wird unabhängig vom Quellstatus auf `Planung` gesetzt,
- `createdAt == updatedAt` wird neu gesetzt,
- das Quellprojekt bleibt unverändert,
- auch ein archiviertes Projekt darf als neue Planung dupliziert werden.

## 7. Lösch- und Archivierungsregel

P11 führt bewusst **kein dauerhaftes Löschen** ein. Der verbindliche MVP
verlangt Archivierung, nicht Löschung. Damit bleiben Projekte,
Nachvollziehbarkeit und spätere Reservierungs-/Kostenbezüge erhalten.

Archivieren ist reversibel. Eine spätere endgültige Löschfunktion benötigt
einen eigenen Auftrag mit Abhängigkeitsprüfung, ausdrücklicher Bestätigung,
Backup- und Wiederherstellungsregel.

## 8. Architektur und Datenintegrität

- Domain und Application importieren weder SwiftUI noch SwiftData.
- Fachregeln liegen in einem zentralen
  `ProductionProjectLifecycleService`.
- Repositoryzugriff erfolgt ausschließlich über
  `ProductionProjectRepository`.
- UI-Zustand liegt in einem `@MainActor`-ViewModel.
- Der SwiftData-Adapter bleibt die einzige Persistenzimplementierung.
- Composition und konkrete Adaptererzeugung liegen außerhalb der View.
- Cancellation und Persistenzfehler werden nicht verschluckt.
- Mutationen werden erst nach erfolgreichem Repository-Speichern als
  erfolgreich angezeigt.
- Vorhandene Benutzerdaten und Zeitstempel bleiben erhalten.

P11 ergänzt keine persistierten Felder. Deshalb bleibt Schema v4 unverändert
und es ist keine neue Migration zulässig. Die bestehenden
Legacy→v1→v2→v3→v4-Tests bleiben vollständige Regression.

## 9. Benutzeroberfläche

Die Projektansicht enthält mindestens:

- Filter `Nicht archiviert`, `Archiv`, `Alle`,
- Tabelle mit Projekt, Zielprodukt, Menge, Status und Priorität,
- Anlegen-, Bearbeiten-, Duplizieren-, Archivieren- und
  Wiederherstellen-Aktion,
- verfügbare Statuswechsel passend zum ausgewählten Projekt,
- Formular für Name, Zielprodukt, Menge, Priorität, optionalen Zieltermin
  und Notizen,
- Bestätigung vor Archivierung,
- verständliche Zustände für Laden, keine Projekte, kein Filtertreffer und
  Fehler,
- deaktivierte Aktionen ohne passende Auswahl,
- Tastaturkürzel für Anlegen, Bearbeiten, Duplizieren und Aktualisieren,
- Accessibility-Labels für zentrale Aktionen,
- brauchbare Darstellung bei schmalen und breiten Fenstern.

Die UI enthält keine Fach- oder Persistenzlogik und keine
Katalog-/Rezeptauswahl aus P12/P13.

## 10. Tests

Mindestens:

- Anlegen mit festen UUID-/Zeitwerten,
- Domainvalidierung leerer/ungültiger Eingaben,
- Bearbeiten erhält ID, Erstellungszeit und Status,
- Bearbeiten eines Archivs wird abgelehnt,
- jede erlaubte Statuskante,
- repräsentative verbotene Vorwärts-/Rückwärtssprünge,
- idempotenter Statuswechsel,
- Archivieren und Wiederherstellen,
- Duplizieren aktiver und archivierter Projekte,
- fehlende Projekt-ID,
- Repository-/Cancellation-Fehler,
- Filter nicht archiviert/Archiv/alle,
- stabile Repositorysortierung,
- dateibasierter kompletter Lebenszyklus mit zweiter Storeöffnung,
- bestehende Migrationen und leerer Store,
- ViewModel-Loading, Auswahl und Aktualisierung,
- Architekturtest: `ProjectsView` ohne SwiftData, `@Query` und
  `modelContext`,
- UI-Quelltest für Zustände, Aktionen, Tastatur und Accessibility,
- vollständige SwiftPM- und Xcode-Debug-/Release-Suites.

Kein Test verwendet einen produktiven Benutzerstore.

## 11. Dokumentation

Aktualisiere:

- Projektdomänen-/Lebenszyklusdokumentation,
- Architektur und Datenmodell,
- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- ADR/Architekturänderungen,
- Abschlussbericht
  `YYYY-MM-DD_P11_Projektlebenszyklus.md`.

## 12. Definition of Done

P11 ist nur `✅`, wenn:

- alle Lebenszyklusaktionen fachlich und lokal funktionieren,
- bestehende Projekte nach zweiter Storeöffnung unverändert lesbar sind,
- ungültige Übergänge und Archivmutationen sicher blockieren,
- `ProjectsView` keine direkte SwiftData-Abhängigkeit mehr enthält,
- keine Schemaänderung oder Datenlöschung erfolgt ist,
- SwiftPM und Xcode in Debug/Release grün sind,
- relevante UI-Zustände und Bedienpfade geprüft sind,
- Dokumentation, Feature-Matrix, Tagebuch und Abschlussbericht aktuell sind,
- der gesonderte Review `✅ bestanden` entscheidet.

P12 darf nicht automatisch begonnen werden.

## 13. Abschlussnachweis

- Implementiert und reviewed am 2026-07-24.
- SwiftPM Debug/Release: jeweils 198 Tests, 0 Fehler, 0 übersprungen.
- Xcode Debug/Release: jeweils 198 Tests, 0 Fehler, 0 übersprungen.
- Bericht:
  [2026-07-24_P11_Projektlebenszyklus.md](../../Progress/Reports/2026-07-24_P11_Projektlebenszyklus.md)
- Reviewentscheidung: `✅ bestanden`.
