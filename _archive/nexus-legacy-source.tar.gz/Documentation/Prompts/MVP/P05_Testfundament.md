# P05 – Testfundament und Referenzdaten

Status nach Ausführung und Review: **✅ erledigt (2026-07-23)**

## Zweck

Eine reproduzierbare, isolierte Testbasis für Domäne, Application und Persistenz schaffen. P05 führt gemeinsame Testhelfer, versionierte Referenzfixtures, deterministische Builder, temporäre Stores und einen einheitlichen lokalen beziehungsweise CI-fähigen Prüfablauf ein.

## Voraussetzungen

- P01 – dauerhafte Entwicklungs- und Reviewregeln,
- P02 – SwiftPM-Schichten und native Berechnungsruntime,
- P03 – Schema v1, Migration und Persistence-Target,
- P04 – zentrale Fehler- und Diagnosegrenze.

## Ausgangszustand

- SwiftPM ist der verifizierte Build- und Testweg.
- Es existieren fünf Testtargets mit 34 erfolgreichen XCTest-Tests.
- Persistenztests erzeugen temporäre Stores mit lokal duplizierter Hilfslogik.
- Testwerte stehen direkt in einzelnen Tests; ein versioniertes, gemeinsam ladbares Referenzpaket fehlt.
- SDE-, Produktionsgraph-, Bestands-, Preis- und Einkaufslistenlogik sind noch nicht implementiert.

## Verbindlicher Umfang

1. Einen ausschließlich von Testtargets verwendeten SwiftPM-Target `NewEdenNexusTestSupport` anlegen.
2. Ein versioniertes synthetisches Referenzpaket `foundation-reference` in Version `1.0.0` erstellen.
3. Das Manifest enthält mindestens:
   - eindeutige Datensatz-ID,
   - Version,
   - Erstellungsdatum,
   - kompatible Schemaversion,
   - optionale SDE-Version,
   - optionale ESI-Kompatibilitätsversion,
   - Datenklassifikation.
4. Referenzfälle für die bereits implementierten Regeln bereitstellen:
   - leere Materialaggregation,
   - Gruppierung, Sortierung, negative Mengenbegrenzung und Geldrundung,
   - deterministisches Produktionsprojekt mit Normalisierung.
5. Als Referenzprodukt ausschließlich ein klar gekennzeichnetes synthetisches T1-Testprodukt verwenden. P05 friert keine unbestätigten EVE-Rezepte oder Produktionsmengen ein.
6. Einen deterministischen `ProductionProjectSnapshotBuilder` bereitstellen.
7. Einen wiederverwendbaren Helfer für eindeutige temporäre Store-Verzeichnisse bereitstellen.
8. Bestehende Persistenztests auf diesen Store-Helfer umstellen, ohne das produktive Schema zu verändern.
9. Loader, Versionsprüfung, Builder, temporäre Stores und Sollwerte automatisiert testen.
10. Testpyramide, Fixture-Regeln, Test-IDs, Coverage-Ziele und Befehle in `Documentation/TEST_STRATEGY.md` dokumentieren.
11. Einen providerneutralen Prüfskript-Einstieg unter `Scripts/ci-verify.sh` bereitstellen.

## Ausdrücklich nicht Bestandteil

- neue fachliche App-Funktionen,
- SDE-Import oder echte Blueprintrezepte,
- Produktionsgraph, T1-/T2-/Reaktionsberechnung,
- neue SwiftData-Entitäten oder Migrationen,
- produktive EVE-, ESI-, Account- oder Tokendaten,
- UI-, Screenshot-, Last- oder Netzwerkfixtures,
- GitHub-Actions- oder andere providerspezifische Pipelinekonfiguration.

## Referenzfälle und Sollwerte

| Test-ID | Fall | Verbindliches Ergebnis |
|---|---|---|
| MAT-REF-001 | synthetisches T1-Testprodukt mit doppelten Materialzeilen und negativer Menge | Gesamtmenge `12`, Gesamtkosten `66.66`, zwei alphabetisch sortierte Ergebniszeilen, negative Menge wird `0`, Preise werden auf zwei Stellen gerundet |
| MAT-REF-002 | leere Materialliste | leere Ergebnisliste, Menge `0`, Kosten `0` |
| PROJECT-REF-001 | Produktionsprojekt mit umgebenden Leerzeichen | normalisierter Projektname `Foundation Project`, Produktname `Synthetic T1 Module`, feste UUID und Zeitwerte bleiben erhalten |

## Coverage-Ziele

- Jede zentrale deterministische Berechnung erhält mindestens einen versionierten Referenztest.
- Neue oder geänderte nicht visuelle Fachlogik muss Normalfall, leere Eingabe, ungültige Eingabe und relevanten Fehlerpfad abdecken.
- Jeder Repository-Schreib-/Leseweg und jede Migration erhält mindestens einen Integrations- beziehungsweise Migrationstest.
- P05 misst eine Coverage-Baseline mit SwiftPM. Die numerische Coverage ist ein Trendindikator, kein Ersatz für fallbezogene Abdeckung.
- Ab P05 gilt für neu hinzugefügte Domain- und Applicationlogik ein Ziel von mindestens 80 % Line Coverage; kritische Berechnungsregeln benötigen unabhängig davon vollständige Referenzfälle.
- SwiftUI-, generierter Makro- und Fixture-Code wird nicht durch künstliche Tests allein zur Erhöhung einer Kennzahl aufgebläht.

## Reproduzierbare Befehle

```bash
swift package describe
swift build -c debug
swift build -c release
swift test -c debug --enable-code-coverage
swift test -c release
swift test --show-codecov-path
./Scripts/ci-verify.sh
```

## Betroffene Dateien

- `Package.swift`
- `Tests/NewEdenNexusTestSupport/`
- `Tests/NewEdenNexusTestSupportTests/`
- `Tests/NewEdenNexusDomainTests/`
- `Tests/NewEdenNexusPersistenceTests/`
- `Scripts/ci-verify.sh`
- `Documentation/TEST_STRATEGY.md`
- verpflichtende Status-, Test-, Tagebuch-, OFFEN- und Abschlussdokumentation

## Abnahmekriterien

- TestSupport-Target und Ressourcen werden von SwiftPM erkannt.
- Referenzdaten sind synthetisch, anonymisiert, versioniert und ohne Netzwerkzugriff ladbar.
- Manifest- und Schemaversionsabweichungen werden sichtbar abgelehnt.
- Alle drei Referenzfälle werden gegen feste Sollwerte ausgeführt.
- Builder erzeugt wiederholbare Snapshots.
- Temporäre Stores liegen außerhalb produktiver Datenpfade und werden nach Tests entfernt.
- Das produktive SwiftData-Schema bleibt unverändert.
- Debug- und Release-Build sind erfolgreich.
- Debug-Testlauf mit Coverage und Release-Testlauf sind erfolgreich; kein Test ist übersprungen.
- Prüfskript läuft erfolgreich.
- Dokumentation, Feature-Matrix, Tagebuch, OFFEN-Audit und Abschlussbericht sind aktualisiert.
- Gesonderter Review von Diff, Tests, Ressourcen und Dokumentation ist bestanden.

## Abschluss

P05 darf nur auf `✅ erledigt` gesetzt werden, wenn alle Abnahmekriterien tatsächlich nachgewiesen wurden. Anschließend nicht automatisch mit P06 beginnen.
