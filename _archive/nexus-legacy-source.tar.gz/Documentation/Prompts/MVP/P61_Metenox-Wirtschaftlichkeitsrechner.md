# P61 – Metenox-Wirtschaftlichkeitsrechner

Status: vollständig spezifiziert · noch nicht begonnen

## Ziel

Aus Mondzusammensetzung, versionierten CCP-/SDE-Regeln, Marktpreisen, Miete
und Betriebskosten Monatsgewinn sowie Break-even eines Metenox Moon Drill
berechnen.

## Voraussetzungen

- P41-Preisquotes und P57–P60-Muster wiederverwenden,
- OFF-021 und OFF-057 vor Code aktuell prüfen,
- aktive SDE-Buildnummer und offizielle CCP-Quellen dokumentieren,
- keine unbestätigten Arbeitsmappenkonstanten übernehmen.

## Erwartetes Ergebnis

Ein eigenständiger, deterministischer `MetenoxScenarioSnapshot` mit
versionierten Regeln, benannten Marktquellen, Vorschau-vor-Schreiben und
vergleichbarer Monats-/Jahresauswertung.

## Eingaben

- Szenarioname, Notiz sowie optional System und Mond,
- Moon-Ore-Anteile; Summe exakt 100 %,
- Fördervolumen oder Betriebsstunden pro Monat,
- versionierte Ore-/Material-/Reprocessingzuordnung aus dem aktiven SDE,
- Metenox-Ausbeute und Verbrauchsregeln mit Quelle/Gültigkeitsdatum,
- Fuel Blocks, Magmatic Gas, Miete, Logistik und laufende Nebenkosten,
- einmalige Anschaffungskosten und gewünschter Abschreibungszeitraum,
- Preisquelle und Preisrolle für jeden Input und Output.

## Verbindliche Preisquellen

Standard ist öffentliche Live-ESI-Bewertung in Jita. Der Benutzer kann einen
anderen Trade Hub, eine benannte Region oder eine bekannte öffentlich
abrufbare Station/Struktur als Vorgabe wählen und später ändern.

Priorität:

1. aktuelle öffentliche ESI-Quote der gewählten Quelle,
2. gültiger Cache derselben Quelle,
3. sichtbar stale Offline-/Limit-Cache,
4. ausdrücklich gewählter manueller/CSV-Preissatz,
5. `nicht verfügbar`.

Fuel/Gas-Kaufkosten verwenden mengenbezogene Sell-Orders. Für Outputs werden
mindestens zwei getrennte Szenarien angeboten:

- `Verkauf anbieten`: öffentliche Sell-Referenz,
- `sofort verkaufen`: höchste vollständig erfüllbare Buy-Nachfrage, erst wenn
  der Marktvertrag diese Seite ausdrücklich implementiert.

Solange Buy-Orders nicht implementiert sind, bleibt dieses Szenario
`nicht verfügbar`; Sell-Werte dürfen es nicht ersetzen. Jeder Wert trägt Ort,
Seite, Menge, Zeitpunkt, Snapshot, Policy und Warnungen.

## Berechnung

```text
Gefördertes Ore = Monatsvolumen × Anteil × Metenox-Ausbeute
Materialoutput = gefördertes Ore × versionierte Reprocessingregel
Outputwert = Summe(Materialmenge × gewählter Outputpreis)
Betriebskosten = Fuel + Gas + Miete + Logistik + Nebenkosten
Monatskosten = Betriebskosten + gewählte Investitionsabschreibung
Monatsgewinn = Outputwert − Monatskosten
Marge = Monatsgewinn / Outputwert
Break-even-Miete = Outputwert − alle Kosten außer Miete
Amortisationsdauer = Anschaffungskosten / Gewinn vor Abschreibung
```

Rundungsstufen, Schaltmonat und Monatsstunden werden als benannte
Regelversionen geführt und nicht versteckt.

## UI-Ablauf

1. Mondzusammensetzung und Kosten erfassen.
2. Regel- und SDE-Stand prüfen.
3. Jita oder andere benannte Marktquelle auswählen.
4. Quotes laden und fehlende/stale Werte anzeigen.
5. Buy-/Sell-/Fallbackszenario vergleichen.
6. Vorschau ausdrücklich bestätigen und Szenario speichern.
7. Mehrere Monde monatlich und jährlich vergleichen.

## Nicht-Ziele

- keine Corporation-Struktur- oder Moon-Scan-Synchronisation,
- keine versteckten Konstanten oder automatische Mietentscheidung,
- keine erfundene Buy-Quote,
- keine automatische Überschreibung gespeicherter Szenarien.

## Mit zu erledigende offene Punkte

- OFF-021: nur tatsächlich benötigte SDE-Felder modular ergänzen.
- OFF-057: Fuel-, Start-, Reprocessing- und Zeitregeln vor Code offiziell/SDE-
  seitig bestätigen, versionieren und mit Referenztests belegen.

## Tests

- 0/100 %, gemischte Monde und ungültige Summen,
- 40-%-Ausbeute, 150 Gas/Stunde und jede weitere bestätigte Regel,
- Schaltmonat, Monatsstunden, Preis-/Regelwechsel und Overflow,
- Jita, andere Quelle, keine Orders, stale/offline und manueller Fallback,
- Break-even, negative Wirtschaftlichkeit, Abschreibung und Neustart,
- Vorschau verwerfen, stale Bestätigung, Abbruch und Recovery.

## Messbare Abnahme

- aktuelle offizielle Regelquellen mit Prüfdatum dokumentiert,
- fokussierte Regel-/Preis-/Persistenz-/UI-Tests grün,
- vollständiger SwiftPM-Testlauf und Xcode-Debugbuild grün,
- realer Eigentümertest mit Jita und einer geänderten Marktquelle,
- keine produktiven Daten ohne bestätigte Vorschau,
- Dokumentation, OFFEN, Testhistorie und Bericht vollständig,
- unabhängiger Review bestanden.
