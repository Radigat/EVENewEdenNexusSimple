# P22 – Verfügbarkeit und Ausschlüsse

Status: **✅ erledigt**

## 1. Zweck

P22 verbindet die zusammengeführten Endmaterialbedarfe eines aktuellen
Produktionsgraphen mit den lokalen Beständen aus P20/P21. Für genau ein
Projekt wird nachvollziehbar berechnet:

- welcher physische Bestand gespeichert ist,
- welcher Anteil wegen archivierter oder nicht freigegebener Lager entfällt,
- welche Materialien vollständig ausgeschlossen sind,
- welche maximale Menge je Material verwendet werden darf,
- welche Menge nach diesen P22-Regeln einbeziehbar ist,
- welcher Anteil den Bruttobedarf deckt und welcher ungedeckt bleibt.

P22 trifft keine Build-or-Buy-Entscheidung und erzeugt keine Einkaufsliste.

## 2. Verbindliche Grundlagen

- aktueller Quellcode nach P21,
- `AGENTS.md`,
- `Documentation/OFFEN.md`, insbesondere `OFF-005`,
- `Documentation/KNOWN_ISSUES.md`, insbesondere `KI-005`,
- `Documentation/MATERIAL_AGGREGATION.md`,
- `Documentation/INVENTORY_MANAGEMENT.md`,
- `Documentation/INVENTORY_CSV_IMPORT.md`,
- Projektbuch 10.8–10.10, 28.4.10, 28.6, 28.7, 30.10–30.11,
- P19 bis P21 und ADR-0024 bis ADR-0026.

## 3. Voraussetzungen

- P19: Graphformat 7 mit Type-ID-basierter Endmaterialaggregation,
- P20: eindeutige Lager-/Type-ID-Bestände,
- P21: kontrollierter CSV-Import und Schema v11,
- ein vorhandenes, nicht veraltetes Produktionsprojekt mit aktuellem
  Produktionsgraphen.

Fehlt der Graph oder ist er gegenüber dem Projekt veraltet, wird keine
scheinbar aktuelle Verfügbarkeit berechnet.

## 4. Scope

P22 umfasst:

- projektbezogene persistente Bestandsfreigaben,
- Modus `alle aktiven Lager`, `ausgewählte aktive Lager` oder
  `Bestand vollständig ignorieren`,
- vollständige Materialausschlüsse nach positiver CCP-Type-ID,
- optionale nichtnegative maximale Verwendungsmenge je Material,
- schreibfreie Vorschau vor jeder Änderung der Freigaben,
- ausdrückliche Bestätigung vor dem Speichern,
- Schutz vor veralteter Vorschau,
- deterministische ganzzahlige Berechnung mit Erklärpositionen,
- native SwiftUI-Darstellung im Produktionsgraph-Workflow,
- additives Schema v12, Migration und Backupkompatibilität,
- automatisierte Referenz-, Fehler-, Persistenz- und UI-Tests.

## 5. Abgrenzung

Nicht Teil von P22:

- Mindest-, Ziel-, Warn- oder Sicherheitsbestand (P23),
- Projektreservierungen (P24),
- Reservierungskonflikte (P25),
- Build-or-Buy (P26),
- Nettomaterialbedarf als endgültige Beschaffungsgrundlage (P26/P30),
- Einkaufsliste (P30/P31),
- ESI-Assets, Besitzer-, Charakter- oder Corporation-Filter,
- virtuelle oder rekursive reale EVE-Lager,
- automatische Lagerauswahl oder Optimierung.

Der P22-Wert `einbeziehbare Menge` ist ausdrücklich der physische Bestand
nach P22-Ausschlüssen und vor Schutzbestand und Reservierungen. Er darf in
späteren Prompts nicht als endgültig frei verfügbar missverstanden werden.

## 6. Fachmodell

### 6.1 Freigabemodus

Jede Projektkonfiguration besitzt genau einen Modus:

1. `allActiveLocations`: alle nicht archivierten Lager einbeziehen,
2. `selectedLocations`: nur die gespeicherten Lager-IDs einbeziehen, sofern
   sie zum Berechnungszeitpunkt weiterhin aktiv sind,
3. `ignoreInventory`: keinen Bestand einbeziehen.

Archivierte Lager sind in jedem Modus ausgeschlossen. Ein nachträglich
archiviertes ausgewähltes Lager bleibt in der Konfiguration sichtbar, trägt
aber bis zur Wiederherstellung keine einbeziehbare Menge bei.

### 6.2 Materialregeln

- Ausgeschlossene Type-IDs tragen unabhängig vom Lager null einbeziehbare
  Menge bei.
- Eine Mengenobergrenze wird erst nach Lager- und Materialfilter angewendet.
- Die Obergrenze null ist zulässig und nachvollziehbar von einem
  vollständigen Materialausschluss unterscheidbar.
- Eine Type-ID darf nicht gleichzeitig vollständig ausgeschlossen und mit
  einer Obergrenze versehen sein.
- Type-IDs und Lager-IDs sind innerhalb ihrer Listen eindeutig und werden
  kanonisch sortiert gespeichert.

### 6.3 Filterpriorität

Für jede Materialposition gilt genau diese Reihenfolge:

1. gespeicherten physischen Bestand über alle Lager überlaufgeprüft summieren,
2. Bestände archivierter Lager ausweisen und ausschließen,
3. Freigabemodus und Lagerauswahl anwenden,
4. vollständigen Materialausschluss anwenden,
5. optionale Mengenobergrenze anwenden,
6. einbeziehbare Menge auf den Bruttobedarf begrenzen,
7. ungedeckte Menge als `Bruttobedarf − verwendbare Menge` berechnen.

Jede Menge wird nur der ersten zutreffenden Ausschlussstufe zugerechnet.
Dadurch sind gespeicherter Bestand, Ausschlussgründe und Ergebnis ohne
Doppelzählung additiv nachvollziehbar.

### 6.4 Ganzzahligkeit und Überlauf

Alle Mengen sind `Int64`. Additionen und Subtraktionen werden auf Überlauf
geprüft. Negative Mengen, Clamping außer dem fachlich definierten
`min(Bedarf, einbeziehbar)` und Gleitkommarechnung sind unzulässig.

## 7. Ergebnisvertrag

Eine Vorschau enthält:

- Projekt- und Graphbezug,
- Formelversion,
- Zeitpunkt und Quellzustand-Token,
- gespeicherte und vorgeschlagene Konfiguration,
- aktive, archivierte, ausgewählte und nicht ausgewählte Lager,
- je Material:
  - Type-ID und Graphname,
  - Bruttobedarf,
  - gespeicherter physischer Bestand,
  - Ausschluss wegen Archiv,
  - Ausschluss wegen Freigabemodus/Lager,
  - Ausschluss wegen Materialregel,
  - Ausschluss wegen Obergrenze,
  - nach P22 einbeziehbare Menge,
  - für den aktuellen Bedarf verwendbare Menge,
  - ungedeckte Menge,
- ungenutzte Regeln, deren Lager oder Material im aktuellen Graphen nicht
  mehr vorkommen.

Summen unterschiedlicher Itemtypen werden nicht fachlich miteinander
addiert. Die Übersicht summiert nur Anzahlen von Materialpositionen und
Statusgruppen.

## 8. Vorschau, Bestätigung und Stale-State-Schutz

Das Ändern von UI-Filtern verändert zunächst nur einen Entwurf.
`Vorschau berechnen` liest Projekt, Graph, Lager und Bestände neu und
schreibt nichts.

`Ausschlüsse übernehmen` verlangt eine ausdrückliche Bestätigung. Vor dem
Schreiben werden erneut geprüft:

- Projekt und Graph unverändert und aktuell,
- Lager- und Bestandszustand unverändert,
- persistierte Konfiguration nicht parallel verändert,
- Vorschau gehört exakt zum bestätigten Entwurf.

Bei Abweichung wird der Schreibvorgang abgelehnt und eine neue Vorschau
verlangt. Das Speichern der Konfiguration ist atomar. Die berechnete
Verfügbarkeit wird nicht als potenziell veralteter Cache persistiert,
sondern aus Konfiguration, Graph und Beständen reproduzierbar neu erzeugt.

## 9. Persistenz und Migration

Schema v12 ergänzt additiv genau eine projektbezogene
`InventoryAvailabilityConfigurationRecord` mit:

- stabiler UUID,
- eindeutiger Projekt-ID,
- Modus,
- kanonisch codierten Lager-IDs,
- kanonisch codierten Materialausschlüssen,
- kanonisch codierten Mengenobergrenzen,
- Erstellungs- und Änderungszeitpunkt,
- Recordversion.

Die Migration v11→v12 erfindet keine Konfiguration. Ohne gespeicherten
Datensatz gilt der explizit dokumentierte Standard `alle aktiven Lager`,
keine Materialausschlüsse und keine Obergrenzen.

Backupformat 12.0.0 akzeptiert die bestehenden Formate 1.0.0 bis 12.0.0;
zukünftiges 13.0.0 wird abgelehnt.

## 10. Benutzeroberfläche

Vom aktuellen Produktionsgraphen ist ein Bereich `Bestand abgleichen`
erreichbar. Er zeigt:

- Loading-, Empty-, Fehler-, Vorschau-, Speichern- und Abbruchzustand,
- den aktuellen Freigabemodus,
- aktive und archivierte Lager mit eindeutiger Auswahlwirkung,
- Materialzeilen mit Ausschluss und optionaler Obergrenze,
- die vollständige Mengenaufschlüsselung der Vorschau,
- Hinweise, dass P23–P25 noch nicht abgezogen sind,
- eine Bestätigungsgrenze vor dem Speichern.

Die Oberfläche verwendet vorhandene Design Tokens, ist per Tastatur und
VoiceOver beschriftet und führt weder Fachlogik noch SwiftData-Zugriffe aus.

## 11. Fehlerfälle

Mindestens typisiert behandeln:

- Projekt fehlt oder ist archiviert,
- Produktionsgraph fehlt, ist alt oder besitzt keine Aggregation,
- ungültiger Modus oder beschädigte persistierte Payload,
- unbekannte Lager-ID beim neuen Entwurf,
- doppelte Lager-/Material-/Cap-Regeln,
- ungültige Type-ID oder negative Obergrenze,
- Material gleichzeitig ausgeschlossen und begrenzt,
- Mengenüberlauf,
- veraltete Vorschau oder parallele Konfigurationsänderung,
- Persistenzfehler,
- Cancellation vor Vorschau oder Speicherung.

Bei jedem Fehler bleiben bisherige Konfiguration und Bestände unverändert.

## 12. Mit zu erledigende offene Punkte

| ID | Restarbeit in P22 | Prüfnachweis |
|---|---|---|
| OFF-005 / KI-005 | Verfügbarkeit und Ausschlüsse auf P20/P21-Beständen implementieren; Rest Schutzbestand/Reservierungen klar P23–P25 zuordnen | Domain-, Service-, Persistenz-, UI- und Dokumentationsreview |
| OFF-006 / KI-006 / KI-013 | additive v11→v12-Migration und Backupkompatibilität prüfen; automatische Vor-Migrationssicherung bleibt P36 | befüllter v11-Store, zweite Öffnung, leerer v12-Store, Backup 1–12 und Ablehnung 13 |

Unabhängige OFF- und KI-Einträge bleiben ihren bestehenden Zielprompts
zugeordnet.

## 13. Risiken

- Eine Bezeichnung als endgültig `frei verfügbar` könnte P23–P25
  fälschlich vorwegnehmen.
- Nicht kanonische Filter oder wechselnde Lagerzustände könnten identische
  Eingaben unterschiedlich auswerten.
- Ungeprüfte Summen könnten bei großen Beständen überlaufen.
- Eine persistierte Ergebniszahl würde nach Bestandsänderungen veralten.
- Stille Standardannahmen könnten Benutzerbestand unbeabsichtigt verwenden.

Die explizite Stufenbezeichnung, kanonische Konfiguration,
Preview-before-write-Grenze und reine Neuberechnung begrenzen diese Risiken.

## 14. Tests

Mindestens:

- alle aktiven Lager,
- ausgewählte Lager und archiviertes ausgewähltes Lager,
- vollständiges Ignorieren,
- Materialausschluss und Mengenobergrenze,
- Filterpriorität ohne Doppelzählung,
- keine Bestände und kein Bedarf,
- `Int64.max` und Summenüberlauf,
- deterministische Sortierung,
- ungültige/doppelte Regeln,
- fehlender/veralteter Graph,
- Vorschau schreibt nicht,
- ausdrückliche Bestätigung,
- Stale-State und parallele Änderung,
- Cancellation und atomarer Altzustand,
- Repository-Roundtrip,
- v11→v12-Migration, zweite Öffnung und v12-Leerstore,
- Backup 1.0.0 bis 12.0.0 und Ablehnung 13.0.0,
- UI-/Schichtengrenzen.

## 15. Messbare Abnahmekriterien

P22 gilt nur als `✅ erledigt`, wenn:

1. die Spezifikation vor der Umsetzung vollständig ist,
2. ein aktueller Graphformat-7-Bedarf projektbezogen geladen wird,
3. alle drei Freigabemodi deterministisch funktionieren,
4. archivierte und nicht ausgewählte Lager getrennt ausgewiesen werden,
5. Materialausschlüsse und Mengenobergrenzen korrekt priorisiert werden,
6. jede Materialzeile vollständig und ohne Doppelzählung erklärt ist,
7. `Int64`-Überläufe vor einem Ergebnis abbrechen,
8. Vorschau und Apply getrennt sind,
9. ohne ausdrückliche Bestätigung nichts gespeichert wird,
10. veraltete Vorschauen und Paralleländerungen blockieren,
11. Konfigurationen atomar und kanonisch in Schema v12 gespeichert werden,
12. v11→v12-Migration, zweite Öffnung und leerer v12-Store bestehen,
13. Backups 1.0.0 bis 12.0.0 funktionieren und 13.0.0 abgelehnt wird,
14. die native UI alle Pflichtzustände und die P23–P25-Abgrenzung zeigt,
15. relevante Normal-, Grenz-, Fehler-, Abbruch- und Wiederanlauftests
    bestehen,
16. SwiftPM und Xcode Debug/Release erfolgreich sind,
17. Pflichtdokumentation, Feature-Matrix, Tagebuch, OFFEN-Audit, ADR und
    Abschlussbericht aktualisiert sind,
18. der gesonderte Review `✅ bestanden` entscheidet.

## 16. Erwartetes Ergebnis

Nach P22 kann der Benutzer je Projekt kontrolliert und reproduzierbar
festlegen, welche physischen lokalen Bestände grundsätzlich einbezogen
werden dürfen. Die Anwendung zeigt Bruttobedarf, jede Ausschlussstufe,
einbeziehbare Menge und ungedeckten Bedarf. P23 kann darauf anschließend
Sicherheits- und Warnbestände aufsetzen, ohne die P22-Berechnung
umzudeuten.
