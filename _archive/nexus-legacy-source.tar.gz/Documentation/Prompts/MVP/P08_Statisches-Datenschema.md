# P08 – Statisches Datenschema vollständig spezifizieren und ausführen

Status: **✅ erledigt**

## 1. Zweck

Das validierte `.nensde`-Paket aus P07 wird fachlich gelesen, gegen feste
Invarianten geprüft und als versionierter, aktivierbarer Stammdatenkatalog in
SwiftData gespeichert.

P08 führt noch keine Katalog-UI, Produktsuche, Rezeptauswahl oder
Produktionsberechnung ein. Diese Aufgaben bleiben P09 bis P19 zugeordnet.

## 2. Voraussetzungen

- P01 bis P07 sind abgeschlossen.
- Eingabe ist ein P07-Stagingpaket der Formatversion 1.
- Schema v1 und die Migration 0.9.0 → 1.0.0 bleiben erhalten.
- Vorhandene Benutzeränderungen und produktive Stores werden nicht als
  Testquelle verwendet.

## 3. Verbindliches Feldmapping

| JSONL | Quelle | Ziel |
|---|---|---|
| Kategorien | `_key`, `name.en`, `published` | `ItemCategory` |
| Gruppen | `_key`, `categoryID`, `name.en`, `published` | `ItemGroup` |
| Typen | `_key`, `groupID`, `marketGroupID`, `name.en`, `description.en`, `volume`, `packagedVolume`, `basePrice`, `portionSize`, `published`, `iconID` | `ItemType` |
| Blueprints | `_key`, `blueprintTypeID`, `maxProductionLimit` | `BlueprintDefinition` |
| Aktivitäten | Aktivitätsschlüssel, `time` | `BlueprintActivity` |
| Materialien | `typeID`, `quantity`, Reihenfolge | `BlueprintMaterial` |
| Produkte | `typeID`, `quantity`, `probability`, Reihenfolge | `BlueprintProduct` |

Unterstützte Aktivitäten sind `copying`, `invention`, `manufacturing`,
`reaction`, `research_material` und `research_time`.

Externe IDs sind nichtnegative `Int64`, weil der offizielle Datenstand gültige
Systemdatensätze mit ID `0` enthält. Zeiten dürfen ebenfalls `0` sein.
Mengen sind strikt positiv. Wahrscheinlichkeiten liegen, sofern vorhanden, in
`(0, 1]`.

## 4. Schema und Indexplan

`NexusSchemaV2` hat Version 2.0.0 und ergänzt:

- `StaticDataVersion`,
- `ItemCategory`,
- `ItemGroup`,
- `ItemType`,
- `BlueprintDefinition`,
- `BlueprintActivity`,
- `BlueprintMaterial`,
- `BlueprintProduct`.

Alle versionierten Stammdatensätze besitzen einen eindeutigen,
deterministischen `identityKey` aus Datenversionshash, Entitätsart und externen
Schlüsseln. SwiftData erzeugt dafür Unique-Indizes. `StaticDataVersion`
indiziert Buildnummer und Inhalts-SHA-256 ebenfalls eindeutig. Diese Schlüssel
sind die verbindlichen exakten Lookup-Pfade. Ein zusätzlicher Suchindex für
Namen gehört zu P09.

## 5. Referenzintegrität

Vor jedem Schreibzugriff werden geprüft:

- Gruppen referenzieren vorhandene Kategorien.
- Typen referenzieren vorhandene Gruppen und deren abgeleitete Kategorie.
- Blueprintdefinitionen referenzieren einen vorhandenen Blueprint-Typ.
- Aktivitäten sind je Blueprint eindeutig.
- Materialien und Produkte sind je Aktivität und Typ eindeutig.
- Menge, Zeit und Wahrscheinlichkeit erfüllen die Feldregeln.

Der aktuelle offizielle SDE-Stand enthält 21 Typreferenzen in
`blueprints.jsonl`, deren Typ in `types.jsonl` fehlt. Diese Quellinkonsistenz
wird nicht durch erfundene Itemdaten verdeckt und verwirft nicht den übrigen
Datenstand. Material- und Produktzeilen speichern deshalb
`typeIsResolved`; `StaticDataVersion` speichert die Anzahl nicht aufgelöster
Referenzen. P10 muss nicht aufgelöste Rezepte ablehnen oder sichtbar
diagnostizieren.

## 6. Versionierung und Aktivierung

- Schema v1 → v2 ist eine additive Lightweight-Migration.
- Migrationen 0.9.0 → 1.0.0 → 2.0.0 bleiben in Reihenfolge registriert.
- Mapping und vollständige fachliche Validierung erfolgen vor dem ersten
  Store-Schreibzugriff.
- Eine neue Version wird mit allen Datensätzen und dem Aktivmarker in einem
  `ModelContext.save()` veröffentlicht.
- Bei Fehler oder Abbruch wird der Context zurückgerollt.
- Frühere Stammdatenversionen bleiben als Rückfallstand erhalten.
- Wiederholter Import desselben Hashes ist idempotent.
- Gleiche Buildnummer mit abweichendem Inhalt wird abgelehnt.

Backups werden ab P08 als Schema 2.0.0 erstellt. Pakete der Version 1.0.0
bleiben für Restore mit anschließender Migration lesbar. Automatische
Vor-Migrations-Sicherung und der vollständige Recovery-Drill bleiben P36.

## 7. Schichtengrenzen

- Application definiert unveränderliche Snapshots, Validierung, Mapper- und
  Repository-Ports sowie den Import-Use-Case.
- Infrastructure liest und verifiziert JSONL/Manifest und führt das
  Feldmapping aus.
- Persistence enthält ausschließlich SwiftData-Schema, Migration und die
  transaktionale Aktivierung.
- SwiftUI ist nicht Teil von P08.

## 8. Referenz- und Realtests

Das synthetische Testpaket enthält T1-artige Herstellung, Invention und
Reaktion. Geprüft werden:

- vollständiges Feldmapping,
- T1-/Invention-/Reaktionsaktivitäten,
- Quellenänderung nach Staging,
- fehlende Pflichtfelder,
- fehlende Blueprint-Typen,
- aufgelöste und nicht aufgelöste Typreferenzen,
- gültige ID `0` und gültige Aktivitätszeit `0`,
- Schema-v1-zu-v2-Migration,
- atomare Aktivierung, Idempotenz und Versionswechsel,
- Buildkonflikt ohne Änderung des aktiven Stands,
- Backupkompatibilität 1.0.0/2.0.0.

Zusätzlich wird der offizielle Tranquility-JSONL-Build `3424810` lokal und
nicht eingecheckt end-to-end geprüft:

- 48 Kategorien,
- 1.605 Gruppen,
- 52.743 Typen,
- 5.082 Blueprints,
- 19.137 Aktivitäten,
- 36.499 Materialien,
- 6.329 Produkte,
- 21 explizit markierte nicht aufgelöste Typreferenzen.

## 9. Nicht Bestandteil

- Download-, Cache- oder ZIP-UI,
- Marktgruppenstammtabelle,
- Skillanforderungen aus Blueprintaktivitäten,
- Item-/Blueprintsuche und Katalogansichten,
- fachliche Rezeptpriorisierung,
- Produktionsgraph oder Mengenberechnung,
- Löschung oder Rotation alter SDE-Versionen,
- automatische Vor-Migrations-Sicherung.

## 10. Abnahmekriterien

P08 ist nur erledigt, wenn:

1. Schema v2 und additive Migration implementiert sind.
2. Mapping und Invarianten vollständig getestet sind.
3. Aktivierung atomar, idempotent und rückfallfähig ist.
4. ein Schema-v1-Store nach v2 migriert und erneut geöffnet wurde.
5. synthetische Debug-/Release-Gesamttests erfolgreich sind.
6. der aktuelle offizielle Realstand erfolgreich gemappt, gespeichert und
   erneut geöffnet wurde.
7. Pflichtdokumentation, ADR, OFFEN-Audit und Abschlussbericht vorliegen.
8. der gesonderte Review keine offene kritische oder hohe Regression findet.

## 11. Verwendete Prüfwege

```bash
env NEN_REAL_SDE_DIRECTORY=<temporäres-Verzeichnis> \
  NEN_REAL_SDE_BUILD=3424810 \
  swift test -c debug --filter OfficialSDEPersistenceIntegrationTests

./Scripts/ci-verify.sh
```

Der Realtest benötigt lokal entpackte, nicht eingecheckte offizielle Daten.
