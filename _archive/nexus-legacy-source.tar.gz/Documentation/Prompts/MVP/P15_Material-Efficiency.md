# P15 – Material Efficiency

Status: **✅ erledigt – am 2026-07-24 vollständig spezifiziert, umgesetzt und reviewed**

## 1. Zweck

P15 ergänzt die vorhandene, deterministische Runberechnung um den
EVE-konformen Materialbedarf einer einzelnen bereits aufgelösten
Produktionsstufe. Für jede Materialposition müssen Rohbedarf, angewendete
Blueprint-Materialeffizienz, gerundeter effektiver Bedarf und Einsparung
nachvollziehbar ausgewiesen werden.

P15 implementiert keine rekursive Produktionskette. T1-, T2- und
Reaktionsauflösung folgen weiterhin P16 bis P18; die stufenübergreifende
Aggregation folgt P19.

## 2. Voraussetzungen

- P14 ist vollständig spezifiziert, umgesetzt und reviewed.
- Graphformat 2 enthält überlaufgeprüfte Runs und Outputs.
- Schema v7 und Backupformat 7.0.0 sind nachgewiesen.
- Der aktive SDE-Katalog liefert ganzzahlige Basismengen je Material und
  Rezept.
- Persönliche Blueprint- und ESI-Synchronisation bleiben verschoben.

## 3. Verbindliche Informationsquellen

Geprüft am 2026-07-24:

- aktueller Quellcode und Git-Diff,
- `AGENTS.md`,
- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/RUNS_AND_OUTPUTS.md`,
- Projektbuch Kapitel 12, Kapitel 30.1 bis 30.6 und 30.26 bis 30.29,
- Projektbuch Anhang E.1 bis E.5 und E.27 bis E.30,
- Projektbuch Anhang F.8, F.9 und F.17,
- CCP Help Center:
  `https://support.eveonline.com/hc/en-us/articles/203210542-Material-Efficiency-Research`,
- CCP Blueprintübersicht:
  `https://support.eveonline.com/hc/en-us/articles/203269951-Blueprints`,
- offizielle SDE-Dokumentation:
  `https://developers.eveonline.com/docs/services/static-data/`.

Die CCP-Regelquelle hat Vorrang vor der im Projektbuch ausdrücklich als
prüfbedürftig markierten allgemeinen ME-Beschreibung.

## 4. Verbindliche fachliche Regeln

### 4.1 Wertebereich

- Blueprint-ME ist für den P15-MVP eine ganze Prozentzahl von `0` bis `10`.
- Die Stufe wird lokal und projektbezogen erfasst, weil persönliche
  Blueprint-Synchronisation nicht Bestandteil des MVP ist.
- Fertigungsrezepte akzeptieren ME `0...10`.
- Reaktionsrezepte besitzen in P15 keine Blueprint-ME; für sie ist
  ausschließlich `0` zulässig.
- Ein Projekt ohne bisherigen P15-Wert migriert verlustfrei auf ME `0`.

### 4.2 Reihenfolge

Für jede Materialposition der vorhandenen Rezeptstufe:

1. Runs aus P14 verwenden.
2. Rohbedarf als `Basismenge je Run × Runs` bestimmen.
3. Blueprint-ME auf den gesamten Job anwenden.
4. Das Ergebnis auf die nächste ganze Materialeinheit aufrunden.
5. Eine Basismenge von genau einer Einheit je Run gegen Reduktion schützen.
6. Einsparung als `Rohbedarf − effektiver Bedarf` bestimmen.

ME wird nicht getrennt pro Run gerundet. Sie wird auf den gesamten Job
angewendet.

### 4.3 Exakte Integerformel

Für Fertigung:

```text
raw = baseQuantityPerRun × requiredRuns

if baseQuantityPerRun == 1:
    effective = raw
else:
    numerator = raw × (100 − materialEfficiency)
    effective = ceil(numerator ÷ 100)

savings = raw − effective
```

Die Ceiling-Division ist ausschließlich mit ganzzahligem Quotient und Rest
umzusetzen. Binäre Gleitkommaarithmetik ist für diese Berechnung unzulässig.

Für Reaktionen:

```text
materialEfficiency = 0
effective = raw
savings = 0
```

### 4.4 Referenzwerte

| Fall | Basis/Run | Runs | ME | Aktivität | Roh | Effektiv | Ersparnis |
|---|---:|---:|---:|---|---:|---:|---:|
| keine Forschung | 240 | 15 | 0 | Fertigung | 3.600 | 3.600 | 0 |
| ME 10 | 240 | 15 | 10 | Fertigung | 3.600 | 3.240 | 360 |
| Job-Rundung | 2 | 8 | 10 | Fertigung | 16 | 15 | 1 |
| Einzelteil-Schutz | 1 | 10 | 10 | Fertigung | 10 | 10 | 0 |
| Reaktion | 7 | 3 | 0 | Reaktion | 21 | 21 | 0 |

### 4.5 Überlauf und Fehler

- Basismenge und Runs müssen größer als null sein.
- Rohbedarf und Reduktionszähler werden mit geprüfter
  `Int64`-Multiplikation berechnet.
- Ein Überlauf, ungültiger ME-Wert oder nicht erlaubter Reaktions-ME-Wert
  bricht die Graphgeneration typisiert ab.
- Der zuletzt gespeicherte gültige Graph bleibt bei jedem Fehler unverändert.
- Persistierte Berechnungen werden beim Decodieren neu berechnet und gegen
  die gespeicherten Werte geprüft.

## 5. Mit zu erledigende offene Punkte

| ID | P15-Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | Den ME-Anteil schließen: Materialbedarf der vorhandenen Rezeptstufe aus P14-Runs berechnen und je Position erklären. Rekursion und Aggregation bleiben P16–P19. | Domain-, Service-, Graph-, Persistenz-, ViewModel- und UI-Tests |
| OFF-006 / KI-006 / KI-013 | Additive Schema-v8-Migration für projektbezogene ME und Materialformel-Provenienz, zweite Öffnung und Backupformat 8.0.0 prüfen. | Migrations-, Wiederöffnungs-, Repository- und Backuptests |
| OFF-009 / KI-012 | Den P15-Anteil schließen: Materialmultiplikation und Reduktionszähler überlaufgeprüft berechnen. Aggregationssummen bleiben P19. | `Int64`-Grenz- und Fehlerpfadtests |
| OFF-021 / KI-021 | Prüfen, ob vorhandene SDE-Basismengen für P15 ausreichen; keine Datenbereiche ohne konkreten Bedarf importieren. | Quellcode- und Datenquellenprüfung im Bericht |
| OFF-027 / KI-027 | ME-Eingabe in den bestehenden Projekteditor integrieren, Berechnungsdarstellung aber in der separaten Graphansicht halten. | Architekturtest ohne SwiftData/Fachlogik in Views |

Unabhängige Lager-, Preis-, Recovery-, Performance- und Future-Aufgaben
werden nicht vorgezogen.

## 6. Domänenmodell

Eine zentrale, UI-unabhängige Berechnungskomponente wird eingeführt:

```text
ProductionMaterialCalculation
```

Sie enthält mindestens:

- Formelversion,
- Aktivität,
- Basismenge je Run,
- benötigte Runs,
- verwendete Blueprint-ME,
- Rohbedarf,
- effektiven Materialbedarf,
- eingesparte Menge.

Sie ist:

- unveränderlich,
- `Sendable`,
- `Equatable`,
- `Codable`,
- deterministisch,
- validierend,
- frei von SwiftUI, SwiftData und Netzwerkzugriffen.

Die Formel erhält Version `1`.

## 7. Projektmodell

`ProductionProjectSnapshot` und `ProductionProjectDraft` erhalten eine
ganzzahlige projektbezogene `materialEfficiency`.

- Standardwert für Neuprojekte: `0`.
- Duplizieren erhält den Wert.
- Bearbeiten validiert den Wert.
- Bei Zielwechsel auf Reaktion wird der Wert auf `0` gesetzt.
- Änderungen aktualisieren `updatedAt` und machen einen bestehenden Graphen
  veraltet.
- Archivierte Projekte bleiben unveränderlich.

## 8. Graphformat 3

Das aktuelle Graphformat wird von `2` auf `3` erhöht.

- Format 1 bleibt als historischer Graph ohne Run- und ME-Werte lesbar.
- Format 2 bleibt als Run-/Outputgraph ohne ME-Werte lesbar.
- Format 3 verlangt:
  - P14-Runberechnung auf jedem Rezeptknoten,
  - projektbezogene Blueprint-ME-Provenienz,
  - eine Materialberechnung auf jeder Kante eines Rezeptknotens,
  - Übereinstimmung von Kantenbasis, Eltern-Runs, Elternaktivität und
    verwendeter ME.

Ein Format-1- oder Format-2-Graph wird als veraltet angezeigt und nur nach
bewusster Neuerzeugung ersetzt.

P15 speichert keine aggregierten Materiallisten und erzeugt keine
zusätzlichen Zwischenproduktknoten.

## 9. Persistenz und Schema v8

Schema v8 erweitert additiv:

- `ProductionProject` um optionale persistente Blueprint-ME,
- `ProductionGraphRecord` um optionale Materialformelversion.

Die Graphpayload enthält Graphformat 3 und die validierten
Materialberechnungen. Metadaten und Payload müssen übereinstimmen.

Migration:

- v7-Werte bleiben vollständig erhalten,
- fehlende Projekt-ME wird fachlich als `0` gelesen,
- bestehende Format-1-/2-Graphen bleiben lesbar,
- zweite Öffnung derselben migrierten Datenbank muss erfolgreich sein,
- eine leere neue Datenbank muss funktionieren.

Backup:

- neue Pakete verwenden Schema `8.0.0`,
- Versionen `1.0.0` bis `8.0.0` bleiben als migrierbare Formate zulässig,
- höhere unbekannte Versionen werden abgelehnt.

## 10. Anwendungsschicht

`ProductionGraphService`:

- verwendet ausschließlich die validierte Projekt-ME,
- berechnet jede Kante erst vollständig im Speicher,
- speichert den Graphen erst nach vollständiger erfolgreicher Validierung,
- erhält den bisherigen Graphen bei Überlauf, Abbruch, Katalog- oder
  Persistenzfehler,
- löst keine zusätzlichen SDE- oder ESI-Abfragen aus.

`ProductionGraphFreshness` berücksichtigt zusätzlich:

- Graphformat 3,
- Materialberechnungen,
- projektbezogene ME.

## 11. Benutzeroberfläche

Projekteditor:

- zeigt für Fertigung eine ganzzahlige ME-Auswahl `0...10`,
- erklärt, dass es sich um die lokal verwendete Blueprint-ME handelt,
- zeigt für Reaktionen „nicht anwendbar“ und verwendet `0`,
- unterstützt Tastatur und VoiceOver,
- verhindert ungültige Speicherung.

Projektliste:

- zeigt die verwendete ME kompakt.

Graphansicht:

- zeigt verwendete Blueprint-ME und Materialformelversion,
- zeigt je Material Basis/Run, Runs, Rohbedarf, effektiven Bedarf und
  Einsparung,
- kennzeichnet alte Graphformate ohne erfundene ME-Werte als veraltet,
- erklärt, dass Rekursion und Aggregation erst P16 bis P19 folgen.

## 12. Automatisierte Tests

Mindestens:

### Domain

- ME 0,
- ME 10,
- Aufrundung auf Jobebene,
- Einzelteil-Schutz,
- Reaktion mit ME 0,
- ungültige ME-Werte,
- Reaktion mit ME ungleich 0,
- ungültige Basismenge und Runs,
- Rohbedarfsüberlauf,
- Reduktionszählerüberlauf,
- manipulierte Codable-Werte,
- identische Eingaben liefern identische Ergebnisse.

### Projektlebenszyklus

- Anlegen, Bearbeiten und Duplizieren erhalten ME,
- Zielwechsel auf Reaktion akzeptiert nur ME 0,
- archivierte Projekte bleiben geschützt,
- ME-Änderung macht den Graphen veraltet.

### Graph und Anwendung

- Fertigungskanten erhalten korrekte Materialwerte,
- Reaktionskanten bleiben unreduziert,
- Format 1 und 2 bleiben lesbar,
- Format 3 verlangt konsistente Berechnungen,
- Überlauf und Abbruch ersetzen keinen vorhandenen Graphen,
- Katalogprovenienz bleibt unverändert.

### Persistenz und Migration

- Projekt-ME-Roundtrip,
- Graphformat-3-Roundtrip,
- beschädigte Materialwerte werden abgelehnt,
- Formelmetadaten-Mismatch wird abgelehnt,
- v7→v8 erhält Projekt, Graph und SDE-Version,
- zweite Öffnung,
- leere Datenbank,
- Backupkompatibilität `1.0.0...8.0.0`.

### UI/Architektur

- erforderliche sichtbare Zustände,
- keine Fachlogik oder SwiftData-Zugriffe in Views,
- Tastatur- und Accessibility-Beschriftungen.

## 13. Build und manuelle Prüfung

Auszuführen:

- SwiftPM Debug,
- SwiftPM Release,
- Xcode Debug,
- Xcode Release,
- Projektgenerator und Konsistenzprüfung,
- isolierter App-Start ohne produktive Benutzerdaten,
- Prüfung, dass Schema v8 angelegt und erneut geöffnet werden kann.

Signing- und Team-Einstellungen bleiben unverändert.

## 14. Dokumentationspflicht

Mindestens aktualisieren:

- `Documentation/MATERIAL_EFFICIENCY.md`,
- `Documentation/RUNS_AND_OUTPUTS.md`,
- `Documentation/PRODUCTION_GRAPH.md`,
- `Documentation/DATA_MODEL.md`,
- Architektur und ADR,
- Entwickler-Menü,
- Feature-Matrix,
- Projektstatus,
- Roadmap,
- offene Punkte und bekannte Probleme,
- Entwicklertagebuch,
- Teststrategie und Testhistorie,
- Promptregister,
- P15-Abschlussbericht.

## 15. Abnahmekriterien

P15 darf nur `✅ erledigt` sein, wenn:

- die aktuelle CCP-Regelquelle dokumentiert geprüft ist,
- projektbezogene ME `0...10` validiert und persistent ist,
- Reaktionen nicht fälschlich Blueprint-ME erhalten,
- Rohbedarf, effektiver Bedarf und Einsparung je Materialposition
  deterministisch berechnet werden,
- Jobrundung und Einzelteil-Schutz referenzgetestet sind,
- alle Multiplikationen überlaufgeprüft sind,
- alte Graphen lesbar und veraltet bleiben,
- Graphformat 3 und Schema v8 vollständig validiert sind,
- v7→v8, zweite Öffnung und leere Datenbank geprüft sind,
- Backups `1.0.0...8.0.0` korrekt behandeln,
- vollständige SwiftPM-/Xcode-Suites in Debug und Release bestehen,
- isolierter Smoke-Test erfolgreich ist,
- Pflichtdokumentation und Abschlussbericht vollständig sind,
- der gesonderte Review bestanden ist.

Andernfalls ist P15 auf `⚠️ teilweise oder blockiert` oder `❌
fehlgeschlagen` zu setzen.

## 16. Abschlussbericht

Datei:

`Documentation/Progress/Reports/2026-07-24_P15_Material-Efficiency.md`

Der Bericht enthält insbesondere Quellenprüfung, Formelentscheidung,
Referenzwerte, Datenwirkung, Migration, Build-/Testergebnisse, manuellen
Smoke-Test, Reviewbefunde, offene Restarbeiten und den nächsten empfohlenen
Prompt.

## 17. Grenze des Auftrags

P16 darf nicht automatisch begonnen werden.
