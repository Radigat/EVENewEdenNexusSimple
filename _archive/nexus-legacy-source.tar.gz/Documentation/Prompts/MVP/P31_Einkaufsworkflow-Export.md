# P31 – Einkaufsworkflow und Export

Status: **✅ erledigt · 2026-07-26**

## Zweck

Die in P30 erzeugten projektbezogenen Zielkaufmengen werden zu einem
praktisch nutzbaren, projektübergreifenden Einkaufsworkflow erweitert.
Benutzer können Teilkäufe projektbezogen zuordnen, Positionen vollständig als
gekauft markieren und die verbleibende Einkaufsliste als Klartext oder CSV
exportieren.

## Voraussetzungen

- P26: bestätigter Build-or-Buy-Plan,
- P30: Type-ID-Aggregation und persistente Zielkaufmengen,
- aktuelle Produktionsgraphen, Bestände, Sicherheitsbestände und
  Reservierungen,
- lokaler SwiftData-Store und versionierte Migrationen.

## Erwartetes Ergebnis

- zentraler Einkaufsbereich für alle aktuellen, nicht archivierten Projekte,
- Aggregation gleicher Materialien ausschließlich über stabile CCP-Type-IDs,
- sichtbare Projektquellen je Material,
- persistenter gekaufter beziehungsweise zugeordneter Anteil je
  Projekt/Type-ID,
- Teilkäufe und „vollständig gekauft“,
- verbleibende Menge als `max(Zielkaufmenge - zugeordnet gekauft, 0)`,
- deterministische kopierbare Textliste,
- deterministischer UTF-8-CSV-Export,
- Vorschau und ausdrückliche Bestätigung vor jeder Statusänderung,
- Offline-Funktion ohne ESI, Wallet- oder Markt-API.

## Fachliche Regeln

1. Kauf-Fortschritt ist eine Projektzuordnung und verändert weder Lagerbestand
   noch Sicherheitsbestand oder Reservierungen.
2. Die gespeicherte Kaufmenge ist nicht negativ. Neue Eingaben dürfen die
   aktuelle Zielkaufmenge nicht überschreiten.
3. Sinkt eine Zielkaufmenge nachträglich unter einen bereits gespeicherten
   Fortschritt, wird höchstens die aktuelle Zielmenge angerechnet. Der
   gespeicherte Wert wird nicht stillschweigend gelöscht.
4. Ein Eintrag gilt als gekauft, wenn seine verbleibende Menge null ist.
5. Globale Summen werden aus den Projektzuordnungen gebildet. Bei gleichen
   Type-IDs müssen die Itemnamen übereinstimmen.
6. Sortierung: Itemname, Type-ID; Projektquellen: Projektname, Projekt-ID.
7. Aktuelle Projekte ohne berechenbaren Build-or-Buy-Plan werden mit einem
   Hinweis ausgelassen. Sie dürfen gültige Projekte nicht unbenutzbar machen.
8. Archivierte Projekte werden nicht in den aktuellen Einkauf aufgenommen;
   vorhandener Fortschritt wird dabei nicht gelöscht.

## Exportvertrag

### Klartext

Nur Positionen mit verbleibender Menge größer null:

`<Itemname><Tab><verbleibende Menge>`

### CSV

- UTF-8,
- RFC-4180-kompatible Feldmaskierung,
- stabile Kopfzeile:
  `type_id,item_name,target_quantity,purchased_quantity,remaining_quantity,project_count`,
- eine aggregierte Zeile je Type-ID,
- nur Positionen mit verbleibender Menge größer null,
- deterministische Reihenfolge wie in der UI.

Die Datei ist in P31 ausdrücklich ein Export. Ein CSV-Reimport ist kein
Abnahmekriterium und wird nicht als versteckter Schreibpfad angeboten. Ein
späterer Import benötigt einen eigenen Preview-before-write-Vertrag.

## Datenhaltung und Sicherheit

- additives SwiftData-Schema v20,
- eigener Fortschrittsdatensatz mit UUID, Projekt-ID, Type-ID, Menge und
  Zeitstempeln,
- fachliche Eindeutigkeit Projekt-ID/Type-ID im Repository prüfen,
- optimistische Versionsprüfung,
- atomarer vollständiger Ersatz nur innerhalb der erfolgreich berechneten
  aktuellen Projekte,
- veraltete oder vorübergehend nicht zuordenbare Fortschritte erhalten,
- Migration v19→v20 und neue leere Datenbank testen,
- Backupformat 20.0.0; ältere Formate 1.0.0–19.0.0 lesbar halten.

## UI

- Navigationsmodul „Einkaufsliste“ ersetzt den Platzhalter,
- Empty-, Loading-, Error- und Warnzustände,
- aggregierte Positionen mit Ziel, gekauft und offen,
- Projektquellen mit editierbarer Teilkaufmenge,
- Aktionen pro Material: vollständig gekauft / auf offen zurücksetzen,
- globale Vorschau und Bestätigung,
- Text kopieren und CSV sichern,
- Tastatur- und VoiceOver-Beschriftungen,
- schmale und breite Fenster rendern.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-011 | Kaufstatus, Teilkäufe, CSV und projektübergreifenden Einkaufsworkflow abschließen | Domain-, Service-, Persistenz-, Migrations-, Export- und UI-Tests; vollständige Gesamtsuite |

Unabhängige P33–P36-Aufgaben werden nicht vorgezogen.

## Tests

- Aggregation gleicher Type-IDs aus mehreren Projekten,
- Teilkauf, vollständig gekauft, Zurücksetzen und Übermengen,
- deterministische Sortierung, Klartext und CSV-Feldmaskierung,
- leere Liste und nicht berechenbares Projekt,
- Vorschaupflicht, veralteter Quellstand, Abbruch und Repositoryfehler,
- Persistenz, Wiederöffnung, atomarer Ersatz und Stale-State,
- Migration v19→v20 ohne erfundene Fortschritte,
- Erhalt von Projekt-, Lager-, Preis-, Economics- und P30-Daten,
- UI-Rendering bei schmaler und breiter Fenstergröße,
- vollständiger SwiftPM- und Xcode-Debug-Testlauf.

## Abnahmekriterien

- OFF-011 ist vollständig nachweisbar geschlossen,
- Kauf-Fortschritt bleibt nach Neustart erhalten,
- Teilkäufe ergeben korrekte offene Mengen,
- projektübergreifende Aggregation ist deterministisch und Type-ID-basiert,
- Statusänderungen benötigen Vorschau und Bestätigung,
- Export verändert keine Daten,
- Migration und Backupformat sind geprüft,
- relevante und vollständige Tests bestehen,
- Dokumentation, Feature-Matrix, Tagebuch und Abschlussbericht sind aktuell,
- gesonderter Review ist bestanden.
