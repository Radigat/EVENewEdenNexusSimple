# P07 – SDE-Importpipeline

Status: **✅ erledigt – Review bestanden am 2026-07-23**

## Zweck

Einen lokal vorhandenen EVE Static Data Export reproduzierbar, speicherschonend und ohne Aktivierung unvollständiger Daten prüfen und in ein versioniertes Stagingpaket überführen.

P07 beantwortet die technische Frage, ob ein ausgewählter SDE-Stand vollständig, formal lesbar, unverändert und für das spätere Mapping vorbereitet ist. Das konkrete SwiftData-Stammdatenschema und die fachliche Feldabbildung folgen in P08.

## Voraussetzungen

- P02 – Modul- und Schichtenarchitektur,
- P03 – versionierte Persistenz und Migrationsregeln,
- P04 – zentrale Fehler- und Diagnosegrenze,
- P05 – TestSupport und versionierte Referenzdaten,
- P06 – lokale Sicherungsgrenze.

## Verbindliche Quelle und Lizenz

- Offizielle Quelle: `https://developers.eveonline.com/static-data/`
- Automatisierungsdokumentation: `https://developers.eveonline.com/docs/services/static-data/`
- Developer License Agreement: `https://developers.eveonline.com/license-agreement`
- Server: Tranquility.
- Gewähltes Format: offizielles **JSON Lines**.
- Daten-URL je Build: `https://developers.eveonline.com/static-data/tranquility/eve-online-static-data-<build>-jsonl.zip`.

Die offizielle Dokumentation bietet JSONL und YAML an. JSONL wird gewählt, weil es zeilenweise verarbeitet werden kann und die offizielle Dokumentation für große SDE-Dateien auf Speicher- und Laufzeitnachteile von YAML hinweist.

CCP veröffentlicht über die dokumentierte Automatisierungsseite Buildnummer, Änderungsdaten sowie HTTP-ETag/Last-Modified, aber dort keine verbindliche kryptografische Archivprüfsumme. P07 erfindet deshalb keine „offizielle“ Prüfsumme. Stattdessen werden jede importierte JSONL-Datei und der gesamte benötigte Inhalt lokal mit SHA-256 gebunden. Diese Prüfsummen schützen Vorschau und Staging vor nachträglichen Änderungen, sind jedoch kein Ersatz für eine künftig von CCP bereitgestellte signierte Prüfsumme.

Die Annahme und Einhaltung der jeweils aktuellen CCP Developer License Agreement bleibt Voraussetzung für die Nutzung der SDE-Daten. Das Repository enthält in P07 nur ausdrücklich synthetische, formatkompatible Testdaten.

## Ausgangszustand

- Kein SDE-Importvertrag oder SDE-Dateiadapter vorhanden.
- Keine statischen EVE-Modelle im SwiftData-Schema.
- Referenzpaket P05 enthält bewusst keine SDE-Version.
- P06 kann den produktiven Store sichern, wird aber in P07 nicht benötigt, weil P07 das produktive Schema und den Store nicht verändert.
- Offizielle Archive werden außerhalb der App ausgewählt und entpackt; Download und ZIP-Extraktion sind nicht Teil dieses lokalen Offline-Imports.

## Verbindlicher Umfang

1. Application-Verträge und UI-unabhängige Typen für SDE-Vorschau, Fortschritt, Datensatzbeschreibungen, Stagingergebnis und strukturierte Fehler definieren.
2. In Infrastructure einen austauschbaren dateibasierten JSONL-Adapter implementieren.
3. P07 benötigt aus dem entpackten offiziellen SDE mindestens:
   - `categories.jsonl`,
   - `groups.jsonl`,
   - `types.jsonl`,
   - `blueprints.jsonl`.
4. Jede Datei wird in festen Blöcken gelesen. Die vollständige Datei darf nicht für die JSONL-Verarbeitung in den Arbeitsspeicher geladen werden.
5. Für jede nicht leere Zeile prüfen:
   - gültiges UTF-8,
   - gültiges JSON,
   - JSON-Wurzel ist ein Objekt,
   - `_key` ist eine positive Ganzzahl,
   - `_key` ist innerhalb des Datensatzes eindeutig.
6. Leere Dateien, Leerzeilen, übergroße Einzelzeilen und symbolische Links werden abgelehnt.
7. Die Vorschau ist read-only und enthält:
   - Tranquility-Buildnummer,
   - offizielle Quell-URL,
   - Dateiname je Datensatz,
   - Datensatzanzahl,
   - Byteanzahl,
   - SHA-256 je Datei,
   - kanonischen SHA-256 des vollständigen benötigten Inhalts.
8. Fortschritt wird über klar typisierte Phasen gemeldet, ohne Pfade oder Datensatzinhalte zu protokollieren.
9. Das Staging kopiert ausschließlich die vier benötigten Dateien in ein privates temporäres Paket, validiert die Kopien erneut und vergleicht sie mit der Vorschau.
10. Wurde die Quelle nach der Vorschau verändert, wird kein finales Paket veröffentlicht.
11. Das finale Paket besitzt die Endung `.nensde` und enthält:
    - `manifest.json`,
    - `categories.jsonl`,
    - `groups.jsonl`,
    - `types.jsonl`,
    - `blueprints.jsonl`.
12. Das Manifest enthält mindestens Formatkennung/-version, Paket-ID, Zeitpunkt, Buildnummer, offizielle Quell-URL, Quellenformat, Lizenz-URL, alle Dateibeschreibungen und den Gesamt-SHA-256.
13. Das Paket wird im selben Zielverzeichnis atomar aus `.partial` veröffentlicht.
14. Paketverzeichnis und Dateien erhalten restriktive lokale Rechte.
15. Unvollständige Stagingdaten werden bei Fehlern entfernt.
16. SDE-Vorschau- und Stagingfehler werden in die zentrale sichere Fehlertaxonomie integriert.
17. Vollständige Offline-Tests mit synthetischen, formatkompatiblen JSONL-Fixtures erstellen.

## Paketformat Version 1

```text
NewEdenNexus-SDE-<build>-<UUID>.nensde/
├── manifest.json
├── categories.jsonl
├── groups.jsonl
├── types.jsonl
└── blueprints.jsonl
```

- Formatkennung: `com.newedennexus.sde-staging`
- Formatversion: `1`
- Quellenformat: `jsonl`
- Aufbewahrung: `keep all`; P07 löscht keine erfolgreichen Pakete.
- Das Paket ist ein validierter technischer Zwischenstand, keine aktive Stammdatenbank.

## Fehlerfälle

Mindestens unterscheiden:

- ungültige Buildnummer,
- Quellverzeichnis fehlt oder ist ein symbolischer Link,
- benötigte Datei fehlt, ist kein regulärer Datensatz oder ist ein symbolischer Link,
- leere Datei oder Leerzeile,
- ungültiges UTF-8,
- übergroße Zeile,
- ungültiges JSON oder nicht objektförmige JSON-Wurzel,
- fehlender, nicht ganzzahliger oder nicht positiver `_key`,
- doppelter `_key`,
- Quelle wurde nach Vorschau verändert,
- Zielpaket oder partielle Struktur existiert bereits,
- Zielverzeichnis, Kopie, Manifest, Veröffentlichung oder Bereinigung schlägt fehl.

Sichere Fehler und Logs dürfen keine vollständigen lokalen Pfade, JSON-Zeilen, Itemnamen oder Blueprintinhalte ausgeben.

## Referenzfälle

| Test-ID | Fall | Erwartetes Ergebnis |
|---|---|---|
| SDE-REF-001 | gültiges synthetisches JSONL-Set | Vorschau enthält feste Counts und SHA-256; Stagingpaket und Manifest sind vollständig |
| SDE-REF-002 | identische Quelle zweimal geprüft | Beschreibungen und Gesamt-SHA-256 sind deterministisch |
| SDE-REF-003 | fehlender Pflichtdatensatz | Vorschau wird datensatzgenau abgelehnt |
| SDE-REF-004 | beschädigtes JSON | Fehler enthält Datensatz und Zeilennummer, aber keinen Inhalt |
| SDE-REF-005 | doppelter `_key` | Vorschau wird mit Datensatz und Zeilennummer abgelehnt |
| SDE-REF-006 | Quelle nach Vorschau verändert | kein finales oder partielles Paket bleibt zurück |
| SDE-REF-007 | leere Datei oder Leerzeile | Vorschau wird abgelehnt |
| SDE-REF-008 | symbolische Datensatzdatei | Vorschau wird defensiv abgelehnt |

## Ausdrücklich nicht Bestandteil

- Netzwerkdownload, HTTP-Caching oder automatische Updateprüfung,
- ZIP-Extraktion,
- YAML-Unterstützung,
- Import beliebiger Community-Konvertierungen,
- SwiftData-Entitäten, Schemaversion oder Migration,
- Feldmapping für Items, Gruppen, Kategorien oder Blueprints,
- Referenzintegrität zwischen SDE-Datensätzen,
- Aktivierung, Differenzanalyse oder Rollback einer Stammdatenbank,
- Katalogsuche oder UI,
- SDE-Inhalte im Git-Repository,
- ESI, SSO oder andere Live-Daten.

Diese Punkte folgen P08 bis P10 beziehungsweise späteren Update-/UI-Arbeitspaketen.

## Betroffene Dateien

- `Sources/NewEdenNexusApplication/`
- `Sources/NewEdenNexusInfrastructure/`
- `Tests/NewEdenNexusInfrastructureTests/`
- `Tests/NewEdenNexusTestSupport/`
- `Documentation/SDE_IMPORT.md`
- Architektur-, ADR-, Status-, OFFEN-, Test- und Abschlussdokumentation

## Prüfungen

```bash
swift package describe
swift build -c debug
swift build -c release
swift test -c debug --enable-code-coverage
swift test -c release
./Scripts/ci-verify.sh
```

## Abnahmekriterien

- offizielle Quelle, Formatwahl, Lizenzgrenze und Prüfsummenabgrenzung dokumentiert,
- vollständige Application-/Infrastructure-Trennung,
- zeilenweise Verarbeitung ohne vollständigen JSONL-Datei-Load,
- alle vier Pflichtdatensätze und `_key`-Regeln geprüft,
- deterministische Vorschau und SHA-256,
- nach Vorschau geänderte Quelle wird abgelehnt,
- finales Paket erscheint nur nach erneuter vollständiger Prüfung,
- keine produktive Schema-, Store- oder Benutzerdatenänderung,
- keine echten SDE-Daten im Repository,
- zentrale Fehlercodes und Redaction bleiben wirksam,
- Debug-/Release-Build und relevante Tests erfolgreich,
- OFFEN-Audit, Pflichtdokumentation und gesonderter Review abgeschlossen.

## Abschluss

P07 darf nur bei vollständigem Nachweis auf `✅ erledigt` gesetzt werden. Die Importpipeline kann abgeschlossen sein, während statisches Datenmodell, Aktivierung und Katalog weiterhin P08 bis P10 zugeordnet bleiben. P08 wird nicht automatisch begonnen.
