# P59 – Wallet-/Verkaufszuordnung und Realgewinn

Status: ⚠️ technisch umgesetzt · KI-060 geschlossen · Eigentümergate OFF-061 in Bearbeitung

## Ziel

Bestätigte Wallet-, Journal- und Marktbelege kontrolliert auf
Produktionschargen verteilen und daraus verkaufte Mengen, Durchschnittspreis
und realisierten Gewinn ermitteln.

## Voraussetzungen

- P57 und P58 abgeschlossen,
- bestehende P42-Snapshots und Projektzuordnungen unverändert erhalten,
- ESI-Quellkapazität, Stale-Schutz und OFF-037/OFF-053 erneut prüfen.

## Erwartetes Ergebnis

Ein chargengebundener, revisionssicherer Zuordnungsvertrag mit
Vorschau-vor-Schreiben, Restkapazität und nachvollziehbarer Realgewinnrechnung.

## Quellen und Rollen

- Wallet-Transaktion: tatsächlicher Kauf oder Verkauf,
- Wallet-Journal: Gebühr, Steuer, SCC oder Jobbuchung,
- eigener Marktauftrag: Verkaufsfortschritt, noch kein realisierter Erlös,
- P58-ESI-Quote: ausschließlich Prognose/offene Units,
- manuelle Istbuchung: nur mit explizitem Betrag, Datum und Begründung.

Ein öffentlicher ESI-Marktpreis darf niemals eine fehlende reale
Wallettransaktion ersetzen. Der Marktpreisvergleich bleibt in Jita oder der
vom Benutzer gewählten benannten Marktquelle verfügbar, wird aber klar als
Prognose gekennzeichnet.

## Zuordnungsablauf

1. Charge, Belegart und aktueller Walletsnapshot werden gelesen.
2. Vorschläge entstehen aus Projekt, Type-ID, Zeitraum, Ort und Restmenge.
3. Jede vorgeschlagene Menge und jeder Betrag bleibt einzeln auswählbar.
4. Benutzer bestätigt Teil- oder Vollzuordnung ausdrücklich.
5. Stale Snapshot, Quellkonflikt oder Überschreitung blockiert das Schreiben.
6. Speicherung erfolgt atomar; Verwerfen ändert keine Daten.

Die bestehende Projektzuordnung bleibt Eigentümer der ESI-Quellkapazität.
Chargen dürfen nur bestätigte Projektkapazität unterteilen. Dieselbe
Transaktion oder Journalzeile darf projekt- und chargenübergreifend nie mehr
als einmal verwendet werden.

## Berechnung

```text
Verkaufte Units = Summe bestätigter Verkaufsmengen
Realisierter Erlös = Summe bestätigter Verkaufstransaktionen
Realisierte Kosten = Kostenanteil der verkauften Chargen-Units
Realisierter Gewinn = Erlös − realisierte Kosten − Verkaufsgebühren
Durchschnittspreis = Erlös / verkaufte Units
Offene Units = produzierte Units − verkaufte Units
```

Unverkaufte Units tragen ihren Kostenanteil weiter und erzeugen keinen
Realgewinn. Überverkauf, negative Restkapazität und Division durch null sind
fachliche Fehler.

## Persistenz und Datenschutz

- Quell-ID, Charakter, Snapshotrevision und Zuordnungsrest speichern,
- keine Tokens oder vollständigen privaten Payloads protokollieren,
- Abbruch/Neustart/Recovery ohne Teilzuordnung,
- Löschung oder Trennung eines Accounts löscht keine bestätigte
  Chargenhistorie, sondern markiert die Quelle als nicht mehr abrufbar.

## Nicht-Ziele

- keine automatische Buchhaltung oder erfundene Historie,
- keine Corporation-Wallets,
- keine automatische Zuordnung allein aufgrund ähnlicher Beträge,
- keine automatische Preisaktualisierung historischer Verkäufe.

## Mit zu erledigende offene Punkte

- OFF-037/OFF-053 über den neuen Chargenvertrag erneut real abnehmen.
- OFF-056 vollständig schließen.

## Tests

- Teilverkauf, mehrere Käufe/Verkäufe und mehrere Chargen,
- Gebühren/Steuern, manuelle Istbuchung und Marktauftrag ohne Transaktion,
- Quellkapazität, Doppelzuordnung, Überverkauf und stale Revision,
- Vorschau verwerfen, Abbruch während Schreiben, Neustart und Recovery,
- fehlende Berechtigung, Offlinebetrieb und Accounttrennung.

## Messbare Abnahme

- fokussierte Domain-/Application-/Persistence-/UI-Tests grün,
- vollständiger SwiftPM-Testlauf und Xcode-Debugbuild grün,
- Eigentümer weist mindestens eine Teil- und eine Vollzuordnung real nach,
- Neustart zeigt identische Restmengen und Gewinne,
- Dokumentation, Testhistorie, OFFEN und Abschlussbericht aktualisiert,
- unabhängiger Review bestanden.
