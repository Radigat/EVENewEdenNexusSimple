# P13 – Erklärbarer Produktionsgraph

Status: **✅ erledigt – am 2026-07-24 vollständig spezifiziert, umgesetzt und reviewed**

## 1. Zweck

Ein kataloggebundenes Produktionsprojekt erhält einen reproduzierbaren,
lokal gespeicherten Produktionsgraphen. Der Graph bildet das Zielprodukt,
sein validiertes P10-Rezept und dessen direkte Materialabhängigkeiten als
gerichtete, erklärbare Struktur ab.

Das Graphmodell muss bereits beliebig viele Tiefen unterstützen. P13 erzeugt
automatisch jedoch nur die erste Rezeptstufe. Die rekursive Entscheidung,
welche Materialknoten weiter produziert werden, folgt bewusst erst in
P16–P18.

## 2. Voraussetzungen und Ausgangsstand

- P10 liefert ein vollständiges, versionsgebundenes `ResolvedRecipe`.
- P11 liefert Projektlebenszyklus und Repository-Grenze.
- P12 speichert Produkt-, Aktivitäts-, Blueprint- und Katalogprovenienz.
- Schema v5 ist aktuell.
- Ein Produktionsgraphmodell, Graphrepository und eine Graphansicht fehlen.
- P14 und alle späteren Berechnungsprompts sind nicht begonnen.

## 3. Mit zu erledigende offene Punkte

| ID | Konkrete Restarbeit in P13 | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | Graphbasis mit Knoten, Kanten, Tiefen, Rezept- und Herkunftsbezug implementieren. T1/T2/Reaktionen bleiben P16–P18. | Domain-, Application-, Persistenz-, ViewModel- und UI-Tests; Status danach `teilweise`, Rest P14–P19 |
| OFF-006 / KI-006 / KI-013 | Additive Schema-v6-Migration für Graphsnapshots, leeren v6-Store, v5→v6-Bestandsschutz, zweite Öffnung und Backupformat 6.0.0 prüfen. | Migrations-, Repository-, Wiederöffnungs- und Backuptests |
| OFF-009 / KI-012 | Festlegen, dass P13 nur positive rohe SDE-Mengen `Int64` speichert und weder multipliziert noch aggregiert. | Grenztests; Überlaufentscheidung bleibt nachweislich P19 |
| OFF-021 / KI-021 | Prüfen, ob zusätzliche SDE-Datensätze nötig sind. | Entscheidung und Schemadiff: P09/P10-Daten genügen; kein Mehrimport |
| OFF-027 / KI-027 | Graph-UI nicht zusätzlich in den großen Projekteditor einbauen. | eigene `ProductionGraphView.swift`; bestehende Aufteilung bleibt P34 |

Unabhängig bleiben Bestände P20–P25, Preise P27–P29, Einkauf P30–P31,
SDE-Recovery P36 sowie SSO/ESI ab P38.

## 4. Verbindliche Scope-Grenze

P13 implementiert:

- unveränderliche Graphsnapshots,
- occurrence-basierte Knotenidentität,
- gerichtete Eltern→Material-Abhängigkeiten,
- Tiefen und stabile Sortierung,
- Rohmengen je Rezeptlauf,
- Blueprint-, Aktivitäts-, Zeit- und Katalogherkunft,
- strukturelle Validierung und Zykluserkennung,
- Erzeugung der ersten Rezeptstufe aus P10,
- lokale Speicherung je Projekt,
- Stale-Erkennung bei geändertem Projektziel oder geänderter Zielmenge,
- eine lesbare native Graphansicht.

P13 implementiert ausdrücklich nicht:

- benötigte Runs oder Outputrundung (P14),
- Material Efficiency oder weitere Boni (P15),
- automatische rekursive T1-/T2-Auflösung (P16/P17),
- automatische Reaktionsauflösung (P18),
- Mengenaggregation, globale Tiefenlimits und vollständigen Graphschutz
  während rekursiver Expansion (P19),
- Bestand, Build-or-Buy, Kosten, Zeitplanung oder Optimierung.

## 5. Graphmodell

### 5.1 Snapshot

`ProductionGraphSnapshot` enthält mindestens:

- Graph-ID,
- Projekt-ID,
- Graphformatversion,
- Projektzielmenge,
- Quellzeitpunkt des Projekts,
- Katalog-Buildnummer und Inhaltshash,
- Root-Knoten-ID,
- Knoten,
- Kanten,
- Erstellungs- und Aktualisierungszeit.

### 5.2 Knoten

Ein `ProductionGraphNode` enthält:

- occurrence-basierte `ProductionGraphNodeID`,
- stabile CCP-Type-ID,
- lokalen Namenssnapshot,
- Rolle `target`, `intermediate` oder `material`,
- Tiefe,
- optionalen `ProductionGraphRecipeReference`.

Der gleiche EVE-Typ darf in mehreren Zweigen als eigener Knoten vorkommen.
P13 führt identische Typen nicht zusammen; Aggregation folgt P19.

### 5.3 Rezeptreferenz

Ein produzierter Knoten dokumentiert:

- Blueprint-Type-ID,
- Fertigung oder Reaktion,
- Outputmenge je Lauf,
- Aktivitätszeit in Sekunden,
- optionales Produktionslimit.

Diese Werte sind unveränderte P10-/SDE-Rohwerte und noch keine
Projektberechnung.

### 5.4 Kanten

Eine gerichtete Kante zeigt vom produzierten Elternknoten auf einen dafür
benötigten Materialknoten. Sie enthält:

- Eltern- und Kind-ID,
- positive Basismenge je Rezeptlauf,
- stabilen Rezept-Sortierwert.

Die Richtung entspricht der UI-Erklärung „Produkt benötigt Material“.

## 6. Identität und stabile Reihenfolge

- Root-ID: deterministisch `root:<productTypeID>`.
- Kind-ID: aus Elternpfad, Rezept-Sortierwert, Type-ID und lokalem
  Vorkommensindex.
- Knotenidentität ist nicht allein die Type-ID.
- Root steht zuerst; danach Tiefe, Elternpfad, Sortierwert und Type-ID.
- Regeneration desselben Projekts mit identischer Version und Rezeptdaten
  erzeugt dieselbe Topologie und dieselben Knoten-IDs.
- Graph-ID und Zeitstempel dürfen sich bei einer bewussten Regeneration
  ändern.

## 7. Graphinvarianten

Der Domain-Initializer lehnt mindestens ab:

- leere oder doppelte Knoten-IDs,
- ungültige externe IDs und nicht positive Rohmengen,
- leere Namen oder Kataloghashes,
- fehlenden oder nicht eindeutigen Root,
- Root mit eingehender Kante,
- Nicht-Root ohne genau eine eingehende Kante,
- Kanten mit fehlenden Endpunkten,
- Eigenkanten und doppelte Kindkanten,
- widersprüchliche Tiefen,
- nicht vom Root erreichbare Knoten,
- Zyklen,
- Root ohne Rezept,
- Materialknoten mit Rezept,
- Ziel-/Zwischenknoten ohne Rezept,
- Graph- und Projektziel ohne übereinstimmende Produkt-/Blueprint-/
  Aktivitätsprovenienz.

Fehler sind typisiert und enthalten keine lokalen Pfade oder Rohfehler.

## 8. Erzeugungsservice

`ProductionGraphService` liegt in Application und ist frei von SwiftUI und
SwiftData.

Ablauf:

1. Projekt und kataloggebundenes Ziel validieren.
2. Archivierte Projekte bleiben lesbar; eine neue Graphgeneration ist für
   sie gesperrt.
3. Exakt den in P12 gespeicherten Blueprint über P10 auflösen.
4. Rezeptversion gegen Buildnummer und Hash des Projektziels prüfen.
5. Zielknoten erzeugen.
6. Materialnamen sequenziell und abbrechbar aus derselben aktiven
   Katalogversion lesen.
7. Für jede Rezeptmaterialzeile einen occurrence-basierten Blattknoten und
   eine Kante erzeugen.
8. Domaininvarianten prüfen.
9. Erst dann den vollständigen Snapshot atomar speichern.

Fehler oder Cancellation dürfen einen bestehenden Graphen nicht ersetzen.

## 9. Persistenz und Schema v6

Schema v6 ergänzt additiv `ProductionGraphRecord`:

- eindeutige Projekt-ID,
- Graph-ID,
- Graphformatversion,
- Katalog-Buildnummer und Hash,
- Erstellungs-/Aktualisierungszeit,
- kanonisch codierter Graphpayload.

Die normalisierten SDE-Tabellen und Projekte bleiben unverändert. Das
Repository decodiert nie ungeprüft: Jeder geladene Payload wird erneut durch
die Domaininvarianten validiert.

Migration v5→v6:

- erhält alle Projekte und SDE-Daten,
- erzeugt keine Graphen für Bestandsprojekte,
- ist additiv und nicht destruktiv,
- unterstützt einen leeren neuen v6-Store,
- aktualisiert Backupformat und Kompatibilitätsprüfung auf 6.0.0.

## 10. Stale- und Lebenszyklusregeln

Ein gespeicherter Graph ist veraltet, wenn mindestens eines abweicht:

- Projekt-ID,
- Zielprodukt-ID,
- Zielaktivität,
- Ziel-Blueprint,
- Katalog-Buildnummer oder Inhaltshash,
- Projektzielmenge.

Name, Notizen, Priorität, Status und Zieltermin machen einen Graphen nicht
veraltet. Duplizierte Projekte erhalten wegen ihrer neuen Projekt-ID keinen
Graphen automatisch. Archivierung erhält einen bestehenden Graphen lesbar,
verbietet aber Regeneration.

## 11. Benutzeroberfläche

Die Projekttabelle erhält eine Aktion „Produktionsgraph“. Eine eigene
`ProductionGraphView` zeigt:

- Empty State ohne Graph,
- Erzeugungs- und Ladezustand,
- Fehlerzustand über die zentrale Fehlergrenze,
- Veraltet-Warnung mit bewusster Regeneration,
- Root und eingerückte Materialknoten,
- Knotenrolle, Type-ID und Tiefe,
- Blueprint, Aktivität, Output pro Lauf und Zeit,
- Basismenge pro Lauf an jeder Materialkante,
- Buildnummer und Graphformatversion,
- Hinweis, dass Runs und Gesamtmengen erst P14 folgen.

Tastaturaktion, Accessibility-Labels, lange Namen, schmale Fenster und
scrollbare große erste Stufen sind zu berücksichtigen.

## 12. Fehlerabbildung

Mindestens:

- Projekt oder Ziel fehlt,
- Projekt archiviert,
- Graph fehlt,
- Rezept passt nicht zum gespeicherten Ziel,
- Katalogversion geändert,
- Materialtyp fehlt oder stammt aus anderer Version,
- ungültige Topologie,
- Zyklus,
- beschädigter Payload,
- Persistenzfehler,
- Cancellation.

Neue zentrale Operation: Produktionsgraph laden/erzeugen mit stabilem
Benutzercode `NEN-GRAPH-001`. P10-Codes bleiben unverändert erhalten.

## 13. Tests

### Domain

- gültiger Root mit mehreren Materialien,
- identischer Typ in zwei Zweigen bleibt occurrence-basiert getrennt,
- gültiger synthetischer Mehrstufengraph,
- doppelte IDs/Kanten,
- fehlende Endpunkte und unerreichbare Knoten,
- falsche Tiefen,
- fehlender/falscher Root,
- Zyklus und Eigenkante,
- ungültige IDs, Namen, Mengen, Hash und Rezeptwerte,
- deterministische Reihenfolge.

### Application

- Erzeugung aus Fertigungs- und Reaktionsrezept,
- gespeicherter P12-Blueprint wird zwingend verwendet,
- Namen und Herkunft stammen aus derselben Katalogversion,
- stabile Topologie bei identischer Eingabe,
- Katalogversionswechsel,
- fehlendes Materialitem,
- archiviertes Projekt,
- Cancellation vor Speicherung,
- Repositoryfehler,
- bestehender Graph bleibt bei Fehler unverändert,
- Stale-Regeln.

### Persistenz/Migration

- Graph-Roundtrip einschließlich aller Knoten/Kanten,
- Replacement je Projekt atomar,
- beschädigter Payload wird abgelehnt,
- neuer Schema-v6-Leerstore,
- v5→v6 erhält Projekte/SDE und erzeugt keine Phantomgraphen,
- vollständige Legacy→v6-Kette und zweite Öffnung,
- Backupversionen 1.0.0 bis 6.0.0.

### ViewModel/UI

- Laden, Empty, Erzeugen, Stale und Fehler,
- Erzeugungsaktion nur für gültiges nicht archiviertes Projekt,
- hierarchische Reihenfolge und Rohmengenkennzeichnung,
- Tastatur und Accessibility,
- View/ViewModel ohne SwiftData,
- Graphcode startet keine P14–P19-Berechnung.

### Gesamtprüfung

- SwiftPM Debug/Release,
- Xcode Debug/Release,
- Projektparität,
- echter App-Smoke-Test mit isoliertem Schema-v6-Store.

Kein Test öffnet einen produktiven Benutzerstore.

## 14. Dokumentation

Mindestens aktualisieren:

- `Documentation/PRODUCTION_GRAPH.md`,
- Datenmodell, Architektur und neues ADR,
- `CURRENT_PROJECT_STATUS.md`,
- `DEVELOPER_MENU.md`,
- `FEATURE_MATRIX.md`,
- `DEVELOPER_DIARY.md`,
- `OFFEN.md`,
- `OPEN_TASKS.md`,
- `KNOWN_ISSUES.md`,
- `TEST_HISTORY.md`,
- Promptregister und Roadmap,
- Abschlussbericht `YYYY-MM-DD_P13_Produktionsgraph.md`.

## 15. Definition of Done

P13 ist nur `✅`, wenn:

- Graphmodell und Invarianten implementiert sind,
- erste Rezeptstufe reproduzierbar aus P10 erzeugt wird,
- Graphen projektbezogen lokal gespeichert und erneut validiert geladen
  werden,
- Schema v6 und Bestandsschutz geprüft sind,
- ein erklärbarer Graph in der App sichtbar ist,
- keine Run-, ME-, Rekursions- oder Aggregationslogik vorgezogen wurde,
- notwendige offene Punkte erneut geprüft sind,
- SwiftPM und Xcode in Debug/Release grün sind,
- isolierter App-Smoke-Test, Pflichtdokumentation und Abschlussbericht
  vorliegen,
- der gesonderte Review `✅ bestanden` entscheidet.

P14 darf nicht automatisch begonnen werden.
