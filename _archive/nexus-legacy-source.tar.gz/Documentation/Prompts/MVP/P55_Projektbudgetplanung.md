# P55 – Projektbudgetplanung

## Ziel

Die bisher sichtbare Wallet-Projektfinanzansicht wird aus der Oberfläche
entfernt. Der Produktionsworkspace erhält stattdessen eine
projektbezogene Planbudgetrechnung.

## Voraussetzungen

- gespeicherter Produktionsgraph,
- wirksamer Build-or-Buy-Plan,
- aktuelle Einkaufsliste nach Lager, Schutzbestand und Reservierungen,
- ausgewählter ISK-Preissatz.

## Umfang

- Materialeinkaufsbudget ausschließlich aus wirksamen Einkaufspositionen,
- einzelne Build-or-Buy-Wahl je herstellbarer Zwischenstufe,
- getrennte manuelle Logistik- und Produktionskosten,
- benötigtes Gesamtbudget als Summe dieser drei Blöcke,
- Vorschau vor Speicherung,
- persistente Budgetbasis je Projekt,
- additive Migration auf Schema v25,
- alte Wallet-Snapshots und -Zuordnungen unverändert erhalten.

## Nicht-Ziele

- keine automatische Walletfinanzierung,
- keine Routen-, Fracht- oder Facility-Gebührenberechnung,
- keine automatische Markt-/Gewinnoptimierung,
- keine Löschung bestehender P29-/P42-Daten.

## Mit zu erledigende offene Punkte

- `OFF-054`: neue Budgetoberfläche im Eigentümerbetrieb sichtbar prüfen.

## Abnahme

- Rohstoff-/Komponentenkauf und direkter Zwischenproduktkauf erzeugen
  jeweils nur die dazu passende Einkaufsliste,
- Material, Logistik und Produktion werden getrennt ausgewiesen,
- fehlende Preise blockieren eine vollständige Budgetzahl,
- v24→v25 erhält bestehende Projekte,
- fokussierte Tests, Vollsuite und Xcode-Debugbuild bestehen.
