# P30 – Erweiterte Einkaufslisten-Aggregation

Status: **✅ erledigt · 2026-07-26**

## Zweck

P30 erzeugt aus dem aktuellen P26-Build-or-Buy-Plan eine eindeutige
projektbezogene Einkaufsliste. Bereits über alle Produktions-, Reaktions-
und Inventionsstufen zusammengeführte Nettomengen werden nach CCP-Type-ID
übernommen und können als bewusste Projektabweichung bearbeitet und lokal
gespeichert werden.

## Voraussetzungen

- P19: Type-ID-basierte Graphaggregation und Überlaufschutz,
- P22–P25: Lager, Ausschlüsse, Schutzbestände und Reservierungen,
- P26/P32: bestätigter Build-or-Buy-Plan und integrierter Workspace,
- P29: Projektwirtschaftlichkeit und Schema v18,
- keine offenen kritischen Fehler im betroffenen Kernpfad.

## Verbindlicher Umfang

1. Jede positive `missingQuantity` des aktuellen Plans wird genau eine
   Basiseinkaufsposition.
2. Schlüssel ist ausschließlich die stabile CCP-Type-ID; der Name dient
   nur der Anzeige.
3. Die Basismenge bleibt sichtbar und unverändert nachvollziehbar.
4. Der Benutzer kann je bestehender Basiseinkaufsposition eine
   nichtnegative Zielkaufmenge festlegen.
5. Gespeichert werden nur Mengen, die von der aktuellen Basismenge
   abweichen. Eine Rücksetzung entfernt den Override.
6. Zielmenge null unterdrückt die Position in der wirksamen Textliste,
   löscht aber weder Bedarf noch Lagerdaten.
7. Gleiche Materialien aus Fertigung, Reaktion, Invention oder gekauften
   Zwischenprodukten dürfen nicht doppelt erscheinen.
8. Positionen werden deterministisch nach Name und anschließend Type-ID
   sortiert; Persistenz und Berechnung bleiben jedoch Type-ID-basiert.
9. Änderungen an Projekt, Graph, Lager, Schutzbestand, Reservierungen oder
   Build-or-Buy-Entscheidungen machen die Vorschau veraltet.
10. Speichern erfolgt nur nach detaillierter Vorschau und ausdrücklicher
    Bestätigung. Unbestätigte, abgebrochene oder veraltete Vorgänge
    schreiben nichts.
11. Nicht mehr zum aktuellen Plan passende gespeicherte Overrides werden
    als veraltet angezeigt und können durch einen bestätigten vollständigen
    Ersatz kontrolliert entfernt werden.
12. Ein nicht bestätigter Build-or-Buy-Entwurf darf keine dauerhaft
    gespeicherte Einkaufsliste erzeugen.

## Datenmodell und Migration

- Schema v19 ergänzt additive `ShoppingQuantityOverrideRecord`-Datensätze.
- Felder: ID, Projekt-ID, Type-ID, Zielkaufmenge, Erstellungs- und
  Änderungszeit.
- Pro Projekt und Type-ID ist höchstens ein Override zulässig.
- Archivierung erhält Overrides; eine Projektduplikation übernimmt sie nicht.
- Migration v18→v19 erhält alle bestehenden Projekte, Graphen, Bestände,
  Reservierungen, Entscheidungen, Preise und Wirtschaftlichkeitsdaten.
- Backupformat 19.0.0 bleibt abwärtskompatibel zu 1.0.0–18.0.0.

## Benutzeroberfläche

Der Produktionsworkspace zeigt je Einkaufsposition:

- Name und Type-ID,
- berechnete Fehlmenge,
- editierbare Zielkaufmenge,
- Kennzeichnung einer manuellen Abweichung,
- Rücksetzen auf die berechnete Fehlmenge,
- veraltete gespeicherte Overrides,
- Anzahl und Gesamteinheiten der wirksamen Kaufpositionen,
- neu berechenbare Vorschau und bestätigtes Speichern,
- kopierbare Textliste aus den wirksamen Mengen.

Empty-, Fehler-, veraltete und laufende Zustände sowie Tastatur- und
VoiceOver-Beschriftungen sind erforderlich.

## Nicht Bestandteil

- als gekauft markieren oder Teilkäufe verbuchen,
- CSV-Export und projektübergreifender Einkaufsworkflow,
- Händler, Station, Region, Budget oder Liefertermin,
- Live-Marktpreise, Wallet, Gebühren oder automatische Empfehlungen.

Diese Punkte bleiben P31 beziehungsweise späteren Markt-/Finanzpaketen
zugeordnet.

## Mit zu erledigende offene Punkte

| ID | Restarbeit in P30 | Prüfnachweis |
|---|---|---|
| OFF-011 | Persistente editierbare Einkaufsmengen und nachvollziehbare Aggregation umsetzen; Status/CSV verbleiben P31. | Domain-, Service-, Persistenz-, Migrations-, UI- und Wiederöffnungstests |

## Tests

Mindestens nachweisen:

- Zusammenführung gleicher Type-IDs aus mehreren Quellen,
- Fertigungs-, Reaktions-, Inventions- und Kaufzwischenstufen,
- keine, eine und mehrere Fehlmengen,
- Override kleiner, gleich, größer und null,
- doppelte, negative, unbekannte und überlaufende Eingaben,
- deterministische Reihenfolge und Textausgabe,
- veralteter Plan und konkurrierender Override-Schreibvorgang,
- Abbruch vor dem Schreiben und eindeutiges Ergebnis nach Commit,
- v18→v19, leerer v19-Store, Roundtrip, Wiederöffnung,
  Projektduplikation ohne Override-Übernahme und Backup 1.0.0–19.0.0,
- Workspace-Architektur sowie schmale und breite Darstellung.

## Abnahmekriterien

P30 ist nur `✅ erledigt`, wenn:

- alle obigen Regeln umgesetzt sind,
- keine Doppelzählung oder stillschweigende Nullannahme möglich ist,
- Schema v19 und Backups nachgewiesen sind,
- SwiftPM- und Xcode-Debugbuild mit allen Tests bestehen,
- isolierter App-Start und Storeintegrität geprüft sind,
- Dokumentation, Feature-Matrix, offene Punkte, Tagebuch,
  Testhistorie und Abschlussbericht aktualisiert sind,
- ein gesonderter Review den tatsächlichen Diff und die Nachweise
  mit `✅ bestanden` bewertet.
