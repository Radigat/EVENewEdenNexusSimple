# REL-001 – Öffentliche Release-/Complianceprüfung

Status: ✅ Prüfung ausgeführt · öffentliche Freigabe: ⚠️ nicht bereit

Planungsnachtrag PLAN-003: Dieser Status beschreibt den historischen
technischen Prüfstand. Eine öffentliche Freigabe ist nicht mehr aktuelles
Projektziel. OFF-020 und OFF-032 gehören ausschließlich zu P48, dem letzten
optionalen Zukunftspaket nach P47, und blockieren den lokalen Betrieb nicht.

## Ziel

Den nach P36 erreichten Stand technisch und organisatorisch gegen die
aktuellen öffentlichen Release-Anforderungen prüfen, OFF-031 erneut
ausführen und verbleibende Freigabegates wahrheitsgemäß dokumentieren.

## Voraussetzungen

- P36 und P37 sind abgenommen.
- Der bestehende Quellcode und alle Benutzeränderungen bleiben unverändert.
- Signing-, Team-, Bundle-ID- und Notarisierungseinstellungen werden ohne
  ausdrückliche Eigentümerentscheidung nicht geändert.
- P38 sowie SSO-/ESI-Zukunftscode bleiben außerhalb dieses Auftrags.

## Umfang

- aktuelle offizielle CCP-/EVE-Bedingungen und SDE-Metadaten read-only prüfen,
- Drittanbieter-, Eigentums-, Marken-, Datenschutz- und Datenquellenbefund
  gegen App und Repository prüfen,
- aktuellen Apple-Pfad für öffentliche macOS-Verteilung prüfen,
- SwiftPM-Releasebuild und vollständige Release-Tests ausführen,
- Xcode-Releasebuild und Projektparität prüfen,
- OFF-031 über den nativen Xcode-UI-Testworker erneut ausführen,
- Release-Artefakt auf Bundle-ID, Version, Signatur und Gatekeeper-Status
  prüfen,
- Ergebnis, Owner-Aufgaben und nächste sichere Arbeitseinheit dokumentieren.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-020 | aktuelle technische CCP-/Marken-/Releaseprüfung; persönliche Freigaben getrennt halten | offizielle Quellen, App-/Repositoryscan, Compliance-Dokument |
| OFF-031 | nativen Xcode-UI-Testworker erneut starten | zwei echte UI-Tests gegen das App-Bundle |

## Nicht-Ziele

- keine Veröffentlichung, kein Upload und keine Notarisierung,
- keine Signing-/Team-/Bundle-ID-Änderung,
- keine rechtliche Freigabe im Namen des Eigentümers,
- keine fachliche App-Implementierung,
- kein P38-, SSO- oder ESI-Umfang.

## Messbare Abnahme

- offizielle Quellen mit Prüfdatum dokumentiert,
- aktuelle SDE-Buildnummer und Cacheheader geprüft,
- SwiftPM Release baut und alle Tests laufen tatsächlich,
- Xcode Release baut,
- OFF-031 startet echte UI-Tests und besitzt ein eindeutiges Ergebnis,
- Signatur-, Versions- und Gatekeeperbefund sind belegt,
- verbleibende Owner-/Releasegates sind mit Ziel und Auswirkung erfasst,
- Abschlussbericht und zentrale Statusdokumentation sind aktualisiert.

## Ergebnis

Die Prüfung selbst ist abgeschlossen. OFF-031 ist geschlossen. Sollte später
eine öffentliche Verteilung ausdrücklich aktiviert werden, bleibt sie bis
zur Bearbeitung von OFF-020 und OFF-032 gesperrt. Für die lokale Eigennutzung
entsteht daraus kein Blocker. P38 wurde nicht begonnen.
