# PLAN-006 – Produktionsbuch und Metenox-Folgeplanung

## Ziel

Die Eigentümer-Arbeitsmappe schreibfrei analysieren, vorhandene Nexus-Abdeckung
prüfen und den neuen Umfang ohne Doppelimplementierung als P57–P61 ordnen.

## Voraussetzungen

- aktuelle Steuerdokumentation und Git-Status prüfen,
- private Arbeitsmappe nicht verändern oder in Git übernehmen,
- vorhandene Projektbudget-, Wallet-, Markt- und Industry-Job-Dienste
  wiederverwenden.

## Umfang

- Produktionsbuch/Chargen,
- erwartete und reale Kosten,
- Verkaufspreisvorschläge und Hubvergleich,
- bestätigte Wallet-/Transaktionszuordnung,
- Produktionsstatistik und Gesamtwallet,
- Metenox-Wirtschaftlichkeitsrechnung.

## Nicht-Ziele

- keine fachliche Swift-Implementierung,
- keine Migration,
- keine produktive Datenänderung,
- kein Commit oder Push.

## Mit zu erledigende offene Punkte

- OFF-056: zurückgezogene Istfinanzoberfläche durch einen neuen
  Produktionsbuchvertrag ersetzen.
- OFF-057: Metenox-Regeln vor Implementierung offiziell/SDE-seitig
  versionieren und nicht belegte Werte offenlassen.

## Abnahme

- Referenzstruktur und vorhandene Nexus-Module sind abgeglichen.
- Eine authoritative Spezifikation nennt Felder, Formeln, Quellen und Grenzen.
- P57–P61 besitzen Ziel, Abhängigkeiten, Nicht-Ziele und messbare Abnahme.
- OFFEN, Promptregister, Roadmap, Feature-Matrix und Abschlussbericht sind
  aktualisiert.
