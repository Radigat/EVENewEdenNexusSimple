# P34 – Performance und große Graphen

Status: **✅ erledigt**

## Ziel

Reale Katalogsuche und Produktionsgraphen bis zur bestehenden
25.000-Knoten-Sicherheitsgrenze messbar absichern. Die Optimierung darf
weder Fachberechnung noch Datenmodell verändern.

## Voraussetzungen

- P19, P32 und P33 sind abgenommen.
- Schema v20 und Graphformat 7 bleiben unverändert.
- Aktiver Git-Diff und Benutzeränderungen werden erhalten.

## Umfang

1. 50.000-Item-Katalog mit zehn identischen 50er-Suchen messen.
2. Datenbankabruf auf `limit + 1` und höchstens einen Batch begrenzen.
3. Nur bei verfehltem Budget einen zusätzlichen Index erwägen.
4. Großgraphen nicht vollständig als rekursiven SwiftUI-Baum
   materialisieren:
   - bis 500 Knoten bestehendes `OutlineGroup`,
   - darüber iterative Projektion,
   - initial 1.000 sichtbare Knoten,
   - Erweiterung in 1.000er-Schritten,
   - `LazyVStack` für die großen Listen.
5. Knotenname-Index je Materialaggregation einmal statt je Vorkommen
   erstellen.
6. P34-zugeordnete große Dateien rein mechanisch nach Verantwortung teilen.
7. SwiftPM- und Xcode-Projektparität wiederherstellen.

## Nicht-Ziele

- keine Änderung an Runs, ME, T1/T2, Invention oder Reaktionen,
- keine neue Persistenz oder Migration,
- kein automatischer Build-or-Buy-Entscheid,
- kein unbelegter SwiftData-Index,
- keine Release-, Recovery- oder vollständige Accessibility-Abnahme.

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-017 / KI-017 | reale Katalogsuchlatenz erneut messen; Index nur bei Bedarf | 50.000 Items, zehn Suchen, 51 Zeilen/Batch, Budget < 2 s |
| OFF-022 / KI-022 | SDE-Installation sowie Download/Archiv nach Verträgen und Orchestrierung teilen | fokussierte SDE-Vertragstests plus Architekturgrenzen |
| OFF-027 / KI-027 | Projektliste und Projekteditor mechanisch trennen | bestehende Projekt- und Architekturtests |
| KI-029 | Preis-CSV-Verträge vom Service trennen | bestehende Preis-CSV-Tests plus Dateigrenzentest |

## Messbudgets

| Pfad | Datensatz | Budget |
|---|---|---|
| Katalogsuche | 50.000 Items, 10 × Limit 50 | < 2 Sekunden gesamt; 51 Zeilen, 1 Batch |
| UI-Projektion | 25.000 Knoten, 1.000 sichtbar | < 3 Sekunden im Debugtest |
| UI-Materialisierung | Graph > 500 Knoten | höchstens aktuelles 1.000er-Sichtfenster |

Zeitwerte sind Umgebungswerte dieses Rechners und keine allgemeine
Produktgarantie. Die strukturellen Abruf- und Sichtgrenzen sind
deterministische Regressionstore.

## Abnahme

- gleiche Eingabe erzeugt gleiche Projektreihenfolge,
- ungültiges Sichtlimit wird abgelehnt,
- ausgelassene Knoten werden exakt gezählt und können gestaffelt geladen
  werden,
- die 25.000-Knoten-Projektion bleibt unter dem Debugbudget,
- Katalogmessung bleibt unter Budget; kein unnötiger Index,
- getrennte Dateien bleiben unter den geprüften Verantwortungsgrenzen,
- SDE-, Projekt- und Preisverhalten bleibt durch fokussierte Tests erhalten,
- vollständige SwiftPM- und Xcode-Debug-Suites bestehen ohne Überspringen,
- Dokumentation, offene Punkte, Review und Bericht sind aktualisiert.

## Tatsächliches Ergebnis

- 50.000-Item-Suche: 0,288 s SwiftPM beziehungsweise 0,295 s Xcode für
  zehn Suchen; je 51 Zeilen und ein Batch.
- 25.000-Knoten-Projektion: 0,026 s SwiftPM beziehungsweise 0,026 s Xcode
  für 1.000 sichtbare Zeilen.
- SwiftPM Debug und Xcode Debug: jeweils 512 Tests, 0 Fehler,
  0 übersprungen.
- Review: **✅ bestanden**.
