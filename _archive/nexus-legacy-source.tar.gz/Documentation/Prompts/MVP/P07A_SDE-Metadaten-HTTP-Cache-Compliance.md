# P07A – Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance

Status: **✅ erledigt – 2026-07-23**

## 1. Zweck

Implementiere die sichere, ressourcenschonende Prüfung, ob CCP einen neueren
Tranquility-SDE-Build veröffentlicht hat. Dieser Prompt lädt noch kein
SDE-Archiv und verändert keinen aktiven Katalog.

Nach P07A kann die Anwendung:

- die lokale aktive Buildnummer lesen,
- `latest.jsonl` ausschließlich vom offiziellen CCP-Endpunkt abrufen,
- Buildnummern vergleichen,
- HTTP-Validatoren und 304 korrekt behandeln,
- den offiziellen Schema-Changelog abrufen und versioniert bewerten,
- Prüfzeit, Cachemetadaten und Ergebnis lokal speichern,
- Offline- und Fehlerzustände typisiert melden.

## 2. Voraussetzungen

- P01, P04 sowie P07 bis P09 sind abgeschlossen.
- `CCP_COMPLIANCE.md` und `SDE_CCP_INTEGRATION_AUDIT.md` werden am
  Ausführungstag erneut geprüft.
- Aktiven Git-Status und alle Einträge in `OFFEN.md`, `OPEN_TASKS.md` und
  `KNOWN_ISSUES.md` prüfen.
- Keine Vertragsannahme oder Registrierung im Namen des Projekteigentümers.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-018 / KI-018 | offiziellen Metadatencheck, HTTP-Cache, konservative Retryregeln und gespeicherten Prüfstatus implementieren | Unit-/Adapter-/Persistenztests einschließlich 304, Offline und neuer Version |
| OFF-020 / KI-020 | Compliancequellen und Eigentümerpflichten soweit vorbereiten, wie sie User-Agent und Netzwerkzugriff blockieren | aktualisierte Compliance-Dokumentation und expliziter Owner-Task |

P07A darf keine Archivinstallation, SDE-Einstellungsansicht oder ESI-Funktion
vorziehen.

## 4. Offizielle Quellen

Am tatsächlichen Ausführungstag ausschließlich offizielle Quellen prüfen:

- `https://developers.eveonline.com/license-agreement`
- `https://developers.eveonline.com/docs/services/static-data/`
- `https://developers.eveonline.com/static-data/tranquility/latest.jsonl`
- `https://developers.eveonline.com/static-data/tranquility/schema-changelog.yaml`
- die in `CCP_COMPLIANCE.md` registrierten EULA-/ToS-/Policy-Seiten.

URLs, Prüfdatum, relevante Änderung und technische Konsequenz dokumentieren.
Keine inoffiziellen Spiegel als reguläre Quelle oder Fallback verwenden.

## 5. Application-Verträge

Definiere SwiftData- und UI-freie Typen und Ports mindestens für:

- lokale aktive SDE-Version,
- offizielle Release-Metadaten mit Buildnummer und Releasezeit,
- HTTP-Validatoren `ETag` und `Last-Modified`,
- Cache-/Abrufentscheidung,
- Schema-Changelog-Metadaten und relevante Änderungen seit lokalem Build,
- Ergebnis `current`, `updateAvailable`, `notModified`, `offline`,
  `schemaReviewRequired` oder `failed`,
- Prüfpolicy mit Mindestintervall 24 Stunden,
- gespeicherten Prüfstatus und redigiertes Prüfereignis.

Empfohlene Ports:

- `SDEReleaseChecking`,
- `SDEUpdateStateStoring`,
- `ActiveSDEVersionReading`.

Zeit, Zufall/Jitter, Netzwerk und Persistenz müssen injizierbar sein.

## 6. HTTP-Regeln

Der konkrete URLSession-Adapter:

1. akzeptiert nur HTTPS und die fest konfigurierte offizielle Host-/Pfadgrenze,
2. liest aus `latest.jsonl` genau den eindeutigen Datensatz `_key == "sde"`,
3. validiert positive Buildnummer und gültiges Release-Datum,
4. sendet gespeichertes `If-None-Match` und `If-Modified-Since`,
5. behandelt 304 ohne Body als Erfolg,
6. speichert neue `ETag`-/`Last-Modified`-Werte erst nach gültiger Antwort,
7. respektiert `Cache-Control` und das lokale Mindestintervall,
8. verwendet explizite Verbindungs-/Ressourcentimeouts,
9. wiederholt nur Transportfehler, HTTP 408, 429 und ausgewählte 5xx,
10. begrenzt Wiederholungen, nutzt exponentielles Backoff mit injizierbarem
    Jitter und respektiert `Retry-After`,
11. wiederholt andere 4xx nicht,
12. besitzt keine Polling-Schleife.

Der User-Agent kommt aus zentraler Konfiguration und enthält mindestens
Appname und Version. Eine Kontaktmöglichkeit wird nicht erfunden oder
hartcodiert. Fehlt die vom Projekteigentümer festzulegende Kontaktangabe,
bleibt ein sichtbarer Konfigurationspunkt offen.

## 7. Persistenz und Schema

Speichere mindestens:

- letzten Prüfversuch,
- letzte erfolgreiche Prüfung,
- zuletzt bekannte offizielle Buildnummer,
- Releasezeit,
- ETag/Last-Modified je Ressource,
- Schema-Changelog-Stand,
- sicheren Ergebnis-/Fehlerstatus.

Falls SwiftData erweitert wird:

- neue VersionedSchema-Version und datenerhaltende Migration,
- Leerstore-, Vorgänger- und Wiederöffnungstest,
- Backup-Schemabindung und Restorekompatibilität aktualisieren,
- keine SDE- oder Benutzerdaten überschreiben.

## 8. Schema-Changelog-Gate

- YAML nur für den offiziell ausschließlich so angebotenen Changelog
  verwenden.
- Parser ist auf benötigte Metadaten begrenzt und gegen unbekannte zusätzliche
  Felder tolerant.
- Änderungen nach dem lokal verstandenen Parserstand werden sichtbar.
- Ein unbekannter relevanter Datei-, Pflichtfeld- oder Typwechsel setzt
  `schemaReviewRequired`.
- P07A aktiviert keine neue SDE-Version.

## 9. Fehler und Logging

Mindestens typisieren und sicher abbilden:

- offline/keine Verbindung,
- Timeout und Abbruch,
- 304, 404, 429, 5xx,
- ungültiger Inhaltstyp oder Body,
- fehlender/doppelter `sde`-Datensatz,
- ungültige Buildnummer/Releasezeit,
- beschädigte Cachemetadaten,
- Changelog nicht interpretierbar,
- Persistenzfehler.

Logs enthalten keine vollständigen lokalen Pfade, personenbezogenen Daten oder
Rohantworten. URL darf nur als fest bekannte offizielle Ressource protokolliert
werden.

## 10. Tests

Mindestens:

- lokal gleich offiziell,
- neuere offizielle Version,
- lokale Version fehlt,
- ungültige/doppelte Buildantwort,
- ETag-/Last-Modified-Anfrage,
- 304,
- Cache-Control und 24-h-Drossel,
- Offlinebetrieb mit lokalem Katalog,
- Timeout,
- 429 mit `Retry-After`,
- 5xx mit begrenztem Backoff/Jitter,
- kein Retry bei 404,
- Abbruch,
- unbekanntes zusätzliches JSON-/YAML-Feld,
- fehlendes Pflichtfeld/veränderter Typ,
- Schemaänderung erfordert Prüfung,
- Persistenz/Migration/Backupkompatibilität, sofern betroffen,
- Architekturgrenzen und Secret-/PII-Redaction.

Tests verwenden einen injizierten URLProtocol-/HTTP-Stub. Kein automatisierter
Test belastet den echten CCP-Endpunkt. Ein einzelner manueller read-only
Abrufnachweis wird getrennt dokumentiert.

## 11. Dokumentation

Aktualisiere mindestens:

- `CCP_COMPLIANCE.md`,
- `SDE_CCP_INTEGRATION_AUDIT.md`,
- `SDE_IMPORT.md`,
- Architektur, Datenmodell, Fehlerbehandlung und Teststrategie,
- Entwickler-Menü, Status, Feature-Matrix, OFFEN, Aufgaben, Probleme,
  Tagebuch und Testhistorie,
- ADR für HTTP-/Cache-/Metadatenarchitektur,
- Abschlussbericht `YYYY-MM-DD_P07A_SDE-Metadaten-HTTP-Cache-Compliance.md`.

## 12. Definition of Done

P07A ist nur `✅`, wenn:

- alle notwendigen offenen Punkte bearbeitet sind,
- aktuelle und lokale Buildnummer zuverlässig verglichen werden,
- ETag, Last-Modified, 304, Cache-Control und 24-h-Policy getestet sind,
- Retry/Backoff/Jitter und User-Agent zentral konfiguriert sind,
- Schema-Changelog sicher bewertet wird,
- Offlinebetrieb den aktiven Katalog erhält,
- Debug/Release und alle relevanten Tests grün sind,
- Compliance-/Owner-Aufgaben aktuell dokumentiert sind,
- gesonderter Review bestanden und Bericht gespeichert ist.

P07B oder P10 dürfen nicht automatisch begonnen werden.
