# P23 – Sicherheitsbestände

Status: **✅ erledigt**

## 1. Zweck

P23 ergänzt die physische P22-Verfügbarkeit um globale, Type-ID-basierte
Bestandsregeln. Die Anwendung schützt eine definierte Sicherheitsmenge vor
automatischer Verwendung und zeigt getrennt, ob der nach der geplanten
Materialverwendung verbleibende aktive Bestand eine Mindestmenge,
Warnschwelle oder Zielmenge unterschreitet.

P23 beantwortet damit für jedes Endmaterial:

- wie viel aktiver physischer Bestand die P22-Regeln einbeziehen,
- welcher Teil eines globalen Sicherheitsbestands bereits durch den von P22
  ausgeschlossenen aktiven Bestand geschützt ist,
- welcher zusätzliche Teil aus der P22-Menge zurückgehalten werden muss,
- wie viel danach für das Projekt verwendbar und ungedeckt ist,
- welche Bestandsziele nach der geplanten Verwendung unterschritten wären.

## 2. Verbindliche Grundlagen

- aktueller Quellcode und P22-Abnahme,
- `AGENTS.md`,
- `Documentation/OFFEN.md`, insbesondere `OFF-005`,
- `Documentation/KNOWN_ISSUES.md`, insbesondere `KI-005`,
- `Documentation/INVENTORY_AVAILABILITY.md`,
- Projektbuch 10.6, 10.10, 10.12, A.9.2–A.9.3, C.27, C.37–C.38,
  Anhang E.9–E.11 und G.14/G.16,
- ADR-0025 bis ADR-0027.

## 3. Voraussetzungen

- P19: aktueller Graphformat-7-Endmaterialbedarf,
- P20/P21: lokaler physischer Bestand,
- P22: projektbezogene Lager-, Material- und Mengenfreigaben,
- nicht archiviertes Projekt mit nicht veraltetem Produktionsgraphen.

Fehlt eine Voraussetzung, wird kein scheinbar aktueller P23-Stand erzeugt
oder gespeichert.

## 4. Scope

P23 umfasst:

- höchstens eine globale Sicherheitsbestandsregel je positiver CCP-Type-ID,
- nichtnegative Werte für Sicherheitsbestand, Mindestbestand, Warnschwelle
  und Zielbestand,
- optionale Mindest-, Warn- und Zielwerte; Sicherheitsbestand null ist
  zulässig,
- getrennte, erklärbare Berechnung auf der P22-Ausgabe,
- schreibfreie Vorschau und ausdrückliche Bestätigung,
- optimistischen Schutz vor geänderten Beständen, P22-Regeln, Graphen oder
  Sicherheitsbestandsregeln,
- atomare Anlage, Änderung und Löschung mehrerer Regeln,
- additives SwiftData-Schema v13 und Backupkompatibilität,
- native SwiftUI-Eingabe und Statusdarstellung,
- deterministische Domain-, Application-, Persistenz-, Migrations- und
  UI-Prüfungen.

## 5. Abgrenzung

Nicht Teil von P23:

- lagerbezogene Sicherheitsbestände,
- Zuordnung eines Verbrauchs zu konkreten Lagerpositionen,
- Projektreservierungen oder Produktionsreserven (P24),
- konkurrierende Reservierungen und Überbuchung (P25),
- Build-or-Buy (P26),
- automatische Nachbestellung oder Einkaufslistenänderung (P30/P31),
- verbrauchs- oder zeitbasierte Prognosen,
- ESI-Assets und Corporation-Bestände.

Das Projektbuch definiert Schutzregeln pro Material, aber keine belastbare
Allokationsregel für gleichzeitige globale und lagerbezogene Grenzen.
P23 verwendet deshalb ausschließlich globale Type-ID-Regeln. Eine
lagerbezogene Regel wird nicht durch eine unbelegte Verteilungsannahme
vorweggenommen.

## 6. Fachmodell

### 6.1 StockPolicy

Eine Regel besitzt:

- stabile UUID,
- positive `typeID`,
- `safetyStockQuantity` als nichtnegative Pflichtmenge,
- optional `minimumQuantity`,
- optional `warningQuantity`,
- optional `targetQuantity`,
- `createdAt` und `updatedAt`.

`typeID` ist eindeutig. Namen sind keine Schlüssel. Eine vollständig leere
beziehungsweise auf null zurückgesetzte Regel wird beim bestätigten
Speichern gelöscht.

Zwischen Mindest-, Warn- und Zielmenge wird keine unbelegte
Größenreihenfolge erzwungen. Jede konfigurierte Schwelle wird unabhängig
ausgewertet und sichtbar benannt.

### 6.2 Schutzformel

Für eine P22-Materialzeile gilt:

```text
aktiver, von P22 nicht einbeziehbarer Bestand
  = aktiver physischer Bestand − P22-einbeziehbarer Bestand

noch aus P22 zu schützender Sicherheitsbestand
  = max(0, Sicherheitsbestand − aktiver, nicht einbeziehbarer Bestand)

aus P22 geschützte Menge
  = min(P22-einbeziehbarer Bestand,
        noch aus P22 zu schützender Sicherheitsbestand)

nach Sicherheitsbestand verfügbar
  = P22-einbeziehbarer Bestand − aus P22 geschützte Menge

für das Projekt verwendbar
  = min(Bruttobedarf, nach Sicherheitsbestand verfügbar)

P23-Fehlmenge
  = Bruttobedarf − für das Projekt verwendbar

prognostizierter aktiver Restbestand
  = aktiver physischer Bestand − für das Projekt verwendbar
```

Damit erfüllt bereits durch P22 ausgeschlossener aktiver Bestand zuerst die
globale Schutzmenge. Archivierte Bestände zählen weder als aktiv noch als
Schutzdeckung.

Alle Mengen verwenden `Int64`. Eingaben und Zwischenwerte werden validiert;
Überläufe oder widersprüchliche P22-Zeilen brechen die Berechnung typisiert
ab.

### 6.3 Schwellen und Meldungen

Eine Meldung entsteht unabhängig je konfigurierter Regel, wenn:

- `prognostizierter aktiver Restbestand < Sicherheitsbestand`,
- `prognostizierter aktiver Restbestand < Mindestbestand`,
- `prognostizierter aktiver Restbestand < Warnschwelle`,
- `prognostizierter aktiver Restbestand < Zielbestand`.

Die Unterschreitung ist jeweils
`Schwelle − prognostizierter aktiver Restbestand`.

Priorität für eine kompakte Hauptanzeige:

1. Sicherheitsbestand unterschritten,
2. Mindestbestand unterschritten,
3. Warnschwelle unterschritten,
4. Zielbestand unterschritten,
5. keine Schwelle unterschritten.

Alle gleichzeitig aktiven Meldungen bleiben in der Detaildarstellung
sichtbar. Meldungen blockieren die Berechnung nicht. Der harte automatische
Schutz entsteht ausschließlich durch die Schutzformel.

Die optionale Zielauffüllmenge ist
`max(0, Zielbestand − prognostizierter aktiver Restbestand)`. P23 zeigt sie
nur informativ und verändert keine Einkaufsliste.

## 7. Anwendungs- und Schreibvertrag

### Vorschau

- liest aktuelle P22-Vorschau und betroffene Regeln,
- validiert alle Drafts und Type-IDs,
- berechnet den vollständigen P23-Stand,
- schreibt nichts.

### Bestätigtes Speichern

- verlangt eine ausdrückliche Bestätigung,
- liest P22-Quellen und Regeln erneut,
- vergleicht Graph, Projekt, Lager, Bestände, P22-Konfiguration und jede
  betroffene Regel mit der Vorschau,
- verwirft eine veraltete Vorschau ohne Teiländerung,
- legt Regeln atomar an, ändert oder löscht sie,
- liefert nach dem Commit den bestätigten Stand zurück.

Cancellation vor dem Commit schreibt nichts. Nach erfolgreichem Commit wird
der gespeicherte Erfolg nicht fälschlich als Abbruch gemeldet.

## 8. Persistenz und Migration

Schema v13 ergänzt `StockPolicyRecord` mit eindeutiger UUID und eindeutiger
Type-ID. P22-Daten, Projekte, Lager, Bestände, Importe, Graphen und
Benutzerdaten bleiben unverändert.

Nachweise:

- leichte Migration v12→v13,
- vollständige Legacy→v13-Kette,
- neue leere v13-Datenbank,
- zweite Öffnung,
- Regel-Roundtrip,
- optimistischer Konflikt,
- atomare Mehrfachänderung einschließlich Löschung,
- Backups 1.0.0 bis 13.0.0 lesbar; 14.0.0 wird abgelehnt.

## 9. Benutzeroberfläche

Im Produktionsgraphen steht neben dem P22-Abgleich die Aktion
`Sicherheitsbestände` bereit.

Die Ansicht zeigt je Material:

- Bruttobedarf,
- P22-einbeziehbaren Bestand,
- aktiven physischen Bestand,
- Sicherheits-, Mindest-, Warn- und Zielwerte,
- bereits außerhalb P22 gedeckten Schutz,
- aus P22 geschützte Menge,
- nach Schutz verfügbare und verwendbare Menge,
- P23-Fehlmenge,
- prognostizierten Restbestand,
- Zielauffüllmenge und konkrete Meldungen.

Leere, Loading-, Fehler-, geänderte Vorschau-, Bestätigungs- und
Abbruchzustände sowie Tastatur- und VoiceOver-Beschriftungen sind
vorzusehen. Farben werden immer durch Text und Symbol ergänzt.

## 10. Mit zu erledigende offene Punkte

| ID | Restarbeit in P23 | Prüfnachweis |
|---|---|---|
| OFF-005 / KI-005 | Sicherheitsbestandsanteil vollständig schließen: globale Regeln, Schutzberechnung und Warnungen. | Domainreferenztests, Application-Stale-/Abbruchtests, Persistenz-/Migrationstest, UI-Architekturprüfung und vier Gesamtläufe. |
| OFF-006 / KI-006 / KI-013 | Additive v12→v13-Migration und Backupgrenze aktualisieren. | Altstore, Leerstore, zweite Öffnung und Backupversionsprüfung. |

`OFF-005/KI-005` bleibt nach P23 nur für Reservierungen P24/P25 teilweise
offen. Der Recovery-Drill aus `OFF-006` bleibt unabhängig P36.

## 11. Tests

Mindestens:

- keine Regel: P22-Ergebnis bleibt unverändert,
- Sicherheitsbestand vollständig durch P22-ausgeschlossenen aktiven Bestand
  gedeckt,
- Sicherheitsbestand teilweise und vollständig aus P22 geschützt,
- bereits bestehende Sicherheitsbestandsunterschreitung,
- unabhängige Mindest-, Warn- und Zielmeldungen,
- Zielauffüllmenge,
- null und `Int64.max`,
- ungültige, doppelte oder unbekannte Type-IDs,
- widersprüchliche P22-Eingabe und Überlauf,
- Vorschau schreibt nicht,
- Bestätigung erforderlich,
- geänderter Graph/Bestand/P22-Stand oder geänderte Regel,
- Abbruch vor und nach Commit,
- atomare Anlage, Änderung und Löschung,
- v12→v13, Leerstore und zweite Öffnung,
- Backupkompatibilität,
- UI-Schicht ohne SwiftData-Zugriff.

## 12. Abnahmekriterien

P23 ist nur `✅ erledigt`, wenn:

1. die globale Type-ID-Regel eindeutig und validiert ist,
2. Sicherheitsbestand hart aus der P22-Menge geschützt wird,
3. P22-ausgeschlossener aktiver Bestand zuerst zur Schutzdeckung beiträgt,
4. archivierter Bestand nicht als Schutzdeckung zählt,
5. P23-Verfügbarkeit und Fehlmenge überlaufgeprüft sind,
6. Mindest-, Warn- und Zielwerte unabhängig ausgewertet werden,
7. alle Meldungen konkrete Ist-, Schwellen- und Differenzwerte besitzen,
8. Meldungen die Berechnung nicht blockieren,
9. keine Regel das P22-Ergebnis unverändert lässt,
10. Vorschau keine Daten schreibt,
11. Speichern Bestätigung und aktuellen Source-State verlangt,
12. Mehrfachänderung und Löschung atomar erfolgen,
13. Cancellation vor Commit keinen Teilstand erzeugt,
14. ein erfolgreicher Commit als Erfolg zurückgegeben wird,
15. Schema v13, Migration, Leerstore und zweite Öffnung bestanden sind,
16. Backups bis 13.0.0 kompatibel sind,
17. die native UI alle Schutz- und Warnwerte nachvollziehbar darstellt,
18. relevante neue und bestehende Tests bestanden sind,
19. SwiftPM und Xcode Debug/Release erfolgreich sind,
20. Pflichtdokumentation, Abschlussbericht und gesonderter Review
    abgeschlossen sind.

## 13. Prüfbefehle

```sh
swift build
swift test
swift test -c release
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Debug -destination platform=macOS \
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus \
  -configuration Release -destination platform=macOS \
  CODE_SIGNING_ALLOWED=NO test
git diff --check
```

## 14. Ergebnisgrenze

P23 endet nach Implementierung, Migration, vier grünen Build-/Testwegen,
Dokumentation und Review. P24 wird nicht begonnen.
