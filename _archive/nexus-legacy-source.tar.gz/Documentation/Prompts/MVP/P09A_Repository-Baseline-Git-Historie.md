# P09A – Repository-Baseline und Git-Nachvollziehbarkeit

Status: **✅ erledigt**

Ausführungsnachweis:
[P09A-Abschlussbericht](../../Progress/Reports/2026-07-23_P09A_Repository-Baseline-Git-Historie.md)

## 1. Zweck

Erzeuge in der bereits isolierten Projekt-Git-Wurzel einen ersten,
nachvollziehbaren Baseline-Commit. Künftige Reviews müssen Änderungen gegen
einen belegten Ausgangsstand prüfen können, ohne das weiterhin vorhandene
übergeordnete Home-Repository zu berühren.

## 2. Voraussetzungen und Autorisierungsgrenze

- `OFF-001` und `OFF-002` sind abgeschlossen.
- Das bereits laufende P07C-Arbeitspaket hat einen dokumentierten
  Abschlusszustand (`✅`, `⚠️`, `❌` oder konkret blockiert); es finden keine
  parallelen Dateiänderungen mehr statt. Ein P07C-Blocker wird nicht durch den
  Baseline-Commit als erledigt umgedeutet.
- Die Git-Wurzel ist exakt
  `/Users/svenstolze/Documents/Codex/EVE Nexus`.
- Der aktuelle Branch ist `main` und besitzt noch keinen Commit.
- Die Ausführung dieses Prompts autorisiert genau den hier beschriebenen
  initialen Projekt-Commit. Sie autorisiert keinen Push, Merge, Rebase, Tag,
  Branchwechsel oder Eingriff in ein anderes Repository.
- Sind beim Ausführungsstart neue oder nicht eindeutig zuordenbare
  Benutzeränderungen vorhanden, werden sie nicht stillschweigend aufgenommen.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-023 / KI-023 | Ersten geprüften Projektstand als Baseline committen und Reviewregeln auf die eigene Projektwurzel ausrichten. | Root-/Statusnachweis, Inhalts- und Geheimnisprüfung, gecachter Diff, erfolgreicher Commit und sauberer beziehungsweise erklärter Folgestatus |

## 4. Bestandsaufnahme vor dem Commit

Vor jeder Stage- oder Commitaktion:

1. `git rev-parse --show-toplevel`, Branch und
   `git status --porcelain=v2 --branch` dokumentieren.
2. Nachweisen, dass `main` ein unborn branch ohne Commit ist.
3. Alle vorgesehenen Dateien vollständig inventarisieren.
4. `.gitignore` regelweise gegen SwiftPM-/Xcode-Builds, lokale Stores,
   SDE-Archive, temporäre Abnahmedaten, Umgebungsdateien, macOS- und
   Editorartefakte prüfen.
5. Untracked Dateien auf Tokens, Secrets, reale Kontaktangaben, private
   absolute Pfade, produktive Benutzerdaten, lokale Datenbanken, Keychain-
   Exporte und offizielle SDE-Großartefakte prüfen.
6. Fremde oder zweifelhafte Dateien sichtbar aus dem Commitumfang ausnehmen
   und als Blocker vorlegen.

Die Prüfung darf keine Geheimnisse in Chat, Log oder Abschlussbericht
reproduzieren.

## 5. Verbindlicher Commitumfang

Nur geprüfte Projektquellen und Projektdokumentation dürfen aufgenommen
werden:

- `.gitignore`,
- `AGENTS.md`,
- `Package.swift` und weitere bewusst versionierte Paketmetadaten,
- `Sources/`,
- `Tests/` einschließlich synthetischer Fixtures,
- `Scripts/`,
- `Documentation/`,
- `README.md`,
- Projektbuch und vorhandene Markdown-Auszüge, sofern die Inhaltsprüfung sie
  als projektbezogen und frei von Geheimnissen bestätigt.

Nicht aufnehmen:

- `.build/`, `.swiftpm/`, DerivedData oder Xcode-Benutzerzustände,
- lokale App-/SwiftData-Stores und Backups,
- heruntergeladene oder entpackte offizielle SDE-Dateien,
- Diagnoseexporte und Realabnahmeartefakte,
- `.env`-Dateien, Tokens, Client-Secrets oder reale Kontaktwerte.

## 6. Qualitätsgate vor dem Commit

- SwiftPM-Paketbeschreibung erfolgreich,
- Debug- und Release-Build erfolgreich,
- Debug- und Release-Tests vollständig erfolgreich,
- keine übersprungenen relevanten Tests,
- Dokumentationslinks und Promptregister auf offensichtliche tote lokale
  Ziele geprüft,
- `git diff --cached --stat` und der vollständige gecachte Diff reviewt,
- keine Datei außerhalb der Projekt-Git-Wurzel gestaged.

Die vorhandene öffentliche EVE-Client-ID ist kein Secret. Client-Secrets,
Tokens und reale Kontaktangaben bleiben trotzdem verboten.

## 7. Commit und Nachweis

- Einen einzigen initialen Commit mit einer klaren Baseline-Botschaft
  erstellen.
- Commit-ID, Commitumfang und Testergebnis dokumentieren.
- Danach `git status --porcelain=v2 --branch` erneut prüfen.
- Ein verbleibender Status ist nur zulässig, wenn jede verbleibende Datei
  ausdrücklich erklärt und keiner notwendigen Baseline-Datei versehentlich
  ausgeschlossen wurde.
- Kein Remote anlegen und nichts pushen.

Künftige Implementierungsprompts committen nicht automatisch. Ein weiterer
Commit benötigt weiterhin einen ausdrücklichen Auftrag beziehungsweise eine
entsprechende eindeutige Prompt-Autorisierung.

## 8. Dokumentation

Aktualisiere mindestens:

- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- `Documentation/REVIEW_RULES.md`,
- Abschlussbericht
  `YYYY-MM-DD_P09A_Repository-Baseline-Git-Historie.md`.

## 9. Definition of Done

P09A ist nur `✅`, wenn Root und Scope zweifelsfrei belegt, alle
Baseline-Dateien geprüft, Build und Tests grün, keine Geheimnisse oder lokalen
Artefakte aufgenommen, genau ein Projekt-Commit erfolgreich erstellt, kein
anderes Repository verändert und der gesonderte Review bestanden ist.

P09B darf nicht automatisch begonnen werden.
