# P16 – T1-Berechnung

Status: **✅ erledigt – Review bestanden**

## Zweck

P16 erweitert den bisher einstufigen Produktionsgraphen zu einer
deterministischen, mehrstufigen T1-Fertigungskette. Für jede benötigte
Materialposition wird geprüft, ob genau ein gültiges Herstellungsrezept
vorliegt. In diesem Fall wird die Position als Zwischenprodukt mit eigenen
Runs, tatsächlicher Ausgabe, Überschuss und eigenen Materialkanten
aufgelöst. Andernfalls bleibt sie ein nachvollziehbar begründetes
Endmaterial.

## Voraussetzungen

- P10: deterministischer Rezept- und Aktivitätsresolver,
- P12: kataloggebundenes Zielprodukt,
- P13: validierter, persistierbarer Produktionsgraph,
- P14: ganzzahlige Run- und Ausgabeberechnung,
- P15: ganzzahlige Blueprint-ME-Berechnung,
- aktiver SDE-Katalog mit konsistenter Buildnummer und Prüfsumme.

## Erwartetes Ergebnis

- vollständige rekursive Auflösung aller eindeutig herstellbaren
  Manufacturing-Zwischenprodukte,
- Runs, tatsächliche Ausgabe und Überschuss je Rezeptvorkommen,
- Materialbedarf und ME-Aufschlüsselung je Kante,
- deterministische Tiefen und vorkommensbezogene Knotenidentitäten,
- begründete Blätter für nicht herstellbare beziehungsweise bewusst
  zurückgestellte Materialien,
- persistierter und in der vorhandenen Graphansicht dargestellter
  Mehrstufengraph,
- lesbare Altgraphen und eindeutige Veraltet-Erkennung,
- atomarer Bestandsschutz bei Fehler, Abbruch oder Katalogwechsel.

P16 führt noch **keine** Materialaggregation durch. Gleiche Rohmaterialien
in mehreren Zweigen bleiben als getrennte Vorkommen erhalten; ihre
Zusammenführung gehört zu P19.

## Fachlicher Scope

### Enthalten

1. Ausschließlich Aktivität `manufacturing` rekursiv auflösen.
2. Das ausgewählte Zielrezept weiterhin exakt über seine gespeicherte
   Blueprint-ID bestimmen.
3. Bei jeder Materialposition anhand des Katalogs feststellen, ob eine
   Manufacturing-Aktivität vorhanden ist.
4. Ist genau ein gültiges Manufacturing-Rezept vorhanden:
   - Zwischenproduktknoten erzeugen,
   - benötigte Runs über die effektive Eingangsmenge berechnen,
   - tatsächliche Ausgabe und Überschuss speichern,
   - dessen Materialien weiter auflösen.
5. Ist keine Manufacturing-Aktivität vorhanden:
   - Material als Blatt erhalten,
   - Abbruchgrund speichern.
6. Reaktionsprodukte als Blatt mit dem Grund
   `Reaktion folgt in P18` kennzeichnen.
7. Pro Zweig Zyklen erkennen und den gesamten Neuaufbau abbrechen.
8. Rekursion technisch begrenzen und Grenzüberschreitungen als
   nachvollziehbaren Fehler melden.
9. Identische Eingaben müssen dieselbe Topologie, Reihenfolge und
   Berechnungswerte erzeugen.

### Nicht enthalten

- T2-/Erfindungslogik; sie folgt P17,
- rekursive Reaktionsketten; sie folgen P18,
- Zusammenführung gleicher Materialien; sie folgt P19,
- Bestandsabzug und Sicherheitsbestände; sie folgen P22 bis P25,
- Build-or-Buy-Abbruchentscheidungen; sie folgen P26,
- Preis-, Kosten- oder Einkaufslistenlogik,
- Slot-, Zeit- oder Optimierungsplanung.

Der Begriff `T1-Berechnung` bezeichnet in P16 den verifizierbaren,
Manufacturing-only-Rechenpfad. Aus dem vorhandenen Katalog wird keine nicht
gespeicherte Tech-Stufe geraten. P16 darf daher nicht als vollständige
T2-Unterstützung dargestellt werden.

## Berechnungsregeln

Für jedes Rezeptvorkommen gelten die bereits versionierten Formeln:

```text
requiredRuns = ceil(requestedOutputQuantity / outputQuantityPerRun)
producedOutputQuantity = requiredRuns * outputQuantityPerRun
surplusOutputQuantity = producedOutputQuantity - requestedOutputQuantity
```

Für jede Materialkante:

```text
rawQuantity = baseQuantityPerRun * requiredRuns
effectiveQuantity = P15-ME-Formel(rawQuantity, runs, activity, ME)
```

Die `effectiveQuantity` der eingehenden Kante ist die
`requestedOutputQuantity` des Zwischenproduktknotens.

Das Zielrezept verwendet den im Projekt gespeicherten Blueprint-ME-Wert.
Für automatisch entdeckte Zwischenprodukte ist noch kein konkreter
Benutzer-Blueprint ausgewählt. P16 verwendet deshalb den ausdrücklich
gespeicherten, neutralen Planungswert ME 0 und kennzeichnet dessen Herkunft
als `neutraler Zwischenproduktwert`. Der Wert wird nicht als tatsächlich
besessener Blueprintwert ausgegeben. Eine spätere benutzerdefinierte
Stufenwahl darf diese Provenienz ersetzen.

## Graphformat und Datenintegrität

- Neues Graphformat 4 für rekursive Manufacturing-Auflösung.
- Runformelversion 1 und Materialformelversion 1 bleiben unverändert.
- Graphformat 4 speichert eine Expansionsrichtlinienversion.
- Jeder Rezeptknoten speichert seinen ME-Wert und dessen Herkunft.
- Jeder Materialblattknoten speichert einen Abbruchgrund.
- Format-1-, Format-2- und Format-3-Graphen bleiben lesbar, gelten aber
  gegenüber Format 4 als veraltet.
- Die vorhandene SwiftData-Schema-v8-Spalte für das codierte Graphpayload
  nimmt Format 4 auf. Es wird keine neue persistente Spalte benötigt und
  deshalb keine Schemamigration erfunden.
- Ein Graph wird erst gespeichert, nachdem alle Knoten, Kanten,
  Berechnungen, Referenzen und Grenzen erfolgreich validiert wurden.
- Ein bestehender Graph bleibt bei jedem Fehler oder Abbruch unverändert.

## Determinismus und Abbruchregeln

- Materialien werden nach `sortOrder`, danach `typeID` verarbeitet.
- Knoten-IDs werden aus dem vollständigen Vorkommenspfad abgeleitet.
- Gleiche Typen in verschiedenen Zweigen bleiben getrennte Vorkommen.
- Ein Typ, der im aktuellen Vorfahrenpfad erneut erscheint, ist ein Zyklus.
- Fehlende oder unveröffentlichte Typen sind Fehler.
- Eine angekündigte Manufacturing-Aktivität ohne auflösbares Rezept ist
  ein Katalogfehler und kein stilles Rohmaterial.
- Mehrdeutige, ungültige oder ungelöste Rezepte brechen den Neuaufbau ab.
- Ein Katalogversionswechsel während der Auflösung bricht den Neuaufbau ab.
- Maximale Tiefe: 64 Rezeptstufen.
- Maximale Knotenanzahl: 25.000 Vorkommen.
- Task-Cancellation wird vor und nach Katalogzugriffen sowie vor dem
  Persistieren respektiert.

Die Tiefen- und Knotengrenzen sind technische Schutzgrenzen, keine
EVE-Fachregeln.

## Referenzketten und Sollgraphen

### R1 – dreistufige T1-Kette

```text
Ziel 587, Menge 10, Output 1, ME 10
├─ Zwischenprodukt 100, Basis 2
│  ├─ Zwischenprodukt 200, Basis 3
│  │  └─ Rohmaterial 36, Basis 11
│  └─ Rohmaterial 35, Basis 7
└─ Rohmaterial 34, Basis 5
```

Erwartung:

- Ziel: 10 Runs, Ausgabe 10, Überschuss 0,
- Zwischenprodukt 100: Bedarf 18, Output 4, 5 Runs, Ausgabe 20,
  Überschuss 2, neutraler ME 0,
- Zwischenprodukt 200: Bedarf 15, Output 10, 2 Runs, Ausgabe 20,
  Überschuss 5, neutraler ME 0,
- Rohmaterial 36: Bedarf 22,
- Rohmaterial 35: Bedarf 35,
- Rohmaterial 34: Bedarf 45.

### R2 – gleiches Material in zwei Zweigen

Zwei getrennte Vorkommen desselben `typeID` müssen im Graphen erhalten
bleiben. P16 darf sie weder summieren noch deduplizieren.

### R3 – Reaktionsgrenze

Eine Materialposition ohne Manufacturing-, aber mit Reaktionsaktivität
bleibt Blatt und trägt den Abbruchgrund `Reaktion folgt in P18`.

### R4 – Zyklus

`A → B → A` muss vor dem Speichern mit dem vollständigen Typenpfad
abgelehnt werden. Ein bereits gespeicherter Graph bleibt erhalten.

## Fehlerfälle

Mindestens typisiert behandeln:

- fehlendes oder unveröffentlichtes Materialitem,
- angekündigtes, aber nicht auffindbares Manufacturing-Rezept,
- mehrdeutiges Rezept,
- ungelöste Rezeptreferenz (`typeIsResolved == false`),
- ungültiges Rezept,
- Katalogversionswechsel,
- Zyklus,
- Tiefen- oder Knotengrenze,
- Run- oder Materialberechnungsüberlauf,
- Task-Abbruch,
- Persistenzfehler.

## Mit zu erledigende offene Punkte

| ID | Restarbeit in P16 | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | Manufacturing-only-T1-Anteil der rekursiven Produktionsketten schließen; T2, Reaktionen und Aggregation ausdrücklich offen lassen. | Referenzkette R1, Fehler- und Bestandsschutztests, aktualisierte Register |
| OFF-009 / KI-012 | Überlaufschutz an jeder neu hinzukommenden Run- und Materialberechnung nachweisen; Aggregationssummen bleiben P19. | Grenzwert- und Überlauftests |
| OFF-021 / KI-021 | Prüfen, ob der bestehende SDE-Katalog die für P16 notwendigen Typ-, Blueprint-, Aktivitäts-, Produkt- und Materialdaten vollständig bereitstellt. Keine zusätzlichen Datensätze ohne Bedarf importieren. | Architekturprüfung und dokumentiertes Ergebnis |

`OFF-006`/`KI-006`/`KI-013` bleiben P36 zugeordnet, weil P16 keine
SwiftData-Schemaänderung benötigt. `OFF-027`/`KI-027` bleibt P34 zugeordnet;
die vorhandene rekursive Graphansicht wird nur fachlich ergänzt, nicht
großflächig umgebaut.

## Automatisierte Tests

Mindestens:

- Referenzkette R1 mit allen erwarteten Mengen,
- deterministische Wiederholung,
- getrennte Vorkommen gleicher Materialien,
- Rohmaterial- und Reaktions-Abbruchgründe,
- root-ME und neutraler Zwischenprodukt-ME,
- eingehender Effektivbedarf entspricht Zwischenprodukt-Sollmenge,
- mehrdeutiges, ungelöstes, ungültiges und fehlendes Rezept,
- Katalogversionswechsel während der Traversierung,
- Zykluspfad,
- Tiefen- und Knotengrenze,
- Run- und Materialüberlauf,
- Abbruch vor und während der Traversierung sowie vor Persistenz,
- Persistenzfehler und Erhalt des Altgraphen,
- Format-1-/2-/3-Kompatibilität und Stale-Erkennung,
- Format-4-Codable- und Persistenz-Roundtrip,
- unveränderte Schema-v8-Öffnung, Wiederöffnung und Backupkompatibilität,
- UI-/ViewModel-Darstellung der Mehrstufenwerte und Abbruchgründe,
- Architekturgrenzen und keine Berechnungslogik in SwiftUI.

## Manuelle Prüfung

- isoliertes Debug-App-Binary mit eigenem temporären Store starten,
- Prozesslauf, Storeerzeugung und `PRAGMA integrity_check` prüfen,
- produktive Benutzerdaten nicht öffnen oder verändern,
- eine nicht automatisiert durchgeführte visuelle oder VoiceOver-Prüfung
  ausdrücklich nicht behaupten.

## Dokumentation

Aktualisieren:

- `Documentation/T1_CALCULATION.md`,
- Graph-, Architektur- und Datenmodelldokumentation,
- passendes ADR für Graphformat 4,
- Entwickler-Menü, Projektstatus, Feature-Matrix, Tagebuch,
- `OFFEN.md`, `OPEN_TASKS.md`, `KNOWN_ISSUES.md`, `TEST_HISTORY.md`,
- Promptregister,
- Abschlussbericht
  `Documentation/Progress/Reports/2026-07-24_P16_T1-Berechnung.md`.

## Abnahmekriterien

P16 darf nur `✅ erledigt` werden, wenn:

1. diese Spezifikation vollständig umgesetzt ist,
2. Referenzkette R1 exakt bestanden ist,
3. Graphformat 4 alle beschriebenen Invarianten erzwingt,
4. alte Graphformate lesbar und eindeutig veraltet sind,
5. kein Fehler oder Abbruch einen bestehenden Graphen ersetzt,
6. alle notwendigen offenen Punkte erneut geprüft sind,
7. SwiftPM Debug und Release erfolgreich sind,
8. Xcode Debug und Release erfolgreich sind,
9. alle relevanten Tests ohne Überspringen bestanden sind,
10. isolierter App-/Store-Smoke bestanden ist,
11. Pflichtdokumentation und Abschlussbericht gespeichert sind,
12. der gesonderte Review bestanden ist.

Andernfalls ist P16 auf `⚠️ teilweise oder blockiert` oder `❌
fehlgeschlagen` zu setzen. P17 wird in diesem Arbeitspaket nicht begonnen.
