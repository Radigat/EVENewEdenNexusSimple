# P21 – CSV-Bestandsimport

Status: **✅ erledigt**

## Zweck

P21 ergänzt die manuelle Lagerverwaltung aus P20 um einen kontrollierten
CSV-Import. Der Benutzer prüft zuerst Datei, Format, Spalten und jede
Bestandsänderung. Erst eine ausdrückliche Bestätigung darf die zuvor
angezeigten Änderungen atomar in genau ein ausgewähltes Lager schreiben.

## Voraussetzungen

- P04: zentrale Fehler- und Diagnosegrenze
- P05: versionierte Testfixtures
- P06: lokale Backup- und Bestandsschutzregeln
- P09: aktiver Itemkatalog
- P20: Lager, manuelle Bestände, Schema v10 und Repository-Grenze

## Ausgangszustand

- Lager und manuelle Positionen sind lokal nutzbar.
- Es gibt keinen CSV-Parser, keine Formatprüfung, keine Vorschau und keinen
  Importbericht.
- OFF-005/KI-005 ist nach P20 teilweise offen; P21 besitzt davon
  ausschließlich den CSV-Importanteil.

## Verbindlicher CSV-Vertrag

### Datei- und Ressourcengrenzen

- Importiert wird eine lokale reguläre Datei mit höchstens 16 MiB.
- Maximal 100.000 Datenzeilen und 64 Spalten werden akzeptiert.
- Leere Dateien, fehlende Header, NUL-Zeichen, unvollständige Anführungszeichen
  und überschrittene Grenzen werden vor jeder fachlichen Vorschau abgelehnt.
- Dateipfade und vollständige Rohzeilen werden weder gespeichert noch
  protokolliert.
- Die Quelle wird über SHA-256 gebunden. Eine Vorschau gilt nur für genau
  diese Bytes, Formatoptionen, Spaltenzuordnung, Lager- und Katalogversion.

### Kodierung und Trennzeichen

- Kodierung: automatisch, UTF-8, Windows-1252 oder ISO-8859-1.
- Automatisch erkennt UTF-8-BOM, UTF-16LE-/UTF-16BE-BOM und valides UTF-8;
  wenn UTF-8 scheitert, wird deterministisch Windows-1252 verwendet.
- Trennzeichen: automatisch, Komma, Semikolon oder Tab.
- Die automatische Erkennung wertet die erste logische Datensatzzeile
  außerhalb zitierter Felder aus. Mehrdeutige Ergebnisse werden nicht
  geraten, sondern verlangen eine manuelle Auswahl.
- Doppelte Anführungszeichen innerhalb zitierter Felder sowie CRLF, LF und
  Zeilenumbrüche in zitierten Feldern werden unterstützt.

### Spaltenzuordnung

- Erforderlich sind genau eine Type-ID-Spalte und genau eine Mengenspalte.
- Optional kann eine Itemname-Spalte zugeordnet werden.
- Spalten werden über ihren Index gebunden; gleichlautende oder leere Header
  sind unzulässig.
- Exakte bekannte Header dürfen als editierbare Vorauswahl dienen. Eine
  fehlende oder mehrdeutige Zuordnung wird niemals erfunden.
- Ein Import betrifft genau das bereits ausgewählte aktive Lager. CSV-Zeilen
  dürfen keine Lager anlegen, umbenennen oder wechseln.

### Mengenformat

- Bestände bleiben positive `Int64`-Stückzahlen.
- Unterstützte Formate: reine Ganzzahl, Dezimalkomma oder Dezimalpunkt.
- Dezimalformate sind nur zulässig, wenn der Nachkommateil ausschließlich aus
  Nullen besteht; Bruchteile und Gruppierungszeichen werden abgelehnt.
- Null, negative Werte, Vorzeichen ohne Zahl und Überlauf sind Fehlerzeilen.

## Vorschau und Konflikte

- Die erste Phase liest und analysiert ausschließlich; sie schreibt nichts.
- Jede Datenzeile erhält Zeilennummer, Type-ID, Katalogname, neue Menge,
  vorhandene Menge, Status und verständliche Diagnose.
- Nicht vorhandene oder unveröffentlichte Type-IDs, abweichende optionale
  Itemnamen, falsche Spaltenzahl und ungültige Mengen werden als isolierte
  Fehlerzeilen ausgewiesen.
- Mehrfach vorkommende Type-IDs innerhalb derselben Datei werden vollständig
  als Konflikt markiert. Mengen werden nicht stillschweigend addiert.
- Neue Positionen sind sichtbar als `Hinzufügen` geplant.
- Identische vorhandene Mengen sind `Unverändert` und werden nicht geschrieben.
- Abweichende vorhandene Mengen verlangen je Position eine sichtbare
  Entscheidung `Ersetzen` oder `Überspringen`. Es gibt keine pauschale,
  versteckte Konfliktregel.
- Fehlerzeilen werden nicht geschrieben. Gültige Zeilen dürfen nach sichtbarer
  Zusammenfassung trotzdem bestätigt werden.

## Bestätigung, Atomarität und Wiederanlauf

- `apply` verlangt `confirmed == true`; andernfalls erfolgt kein Schreibzugriff.
- Vor dem Schreiben werden Lagerstatus, Katalogprovenienz und jede
  Bestandsvorbedingung erneut geprüft.
- Wurde Lager, Katalog oder eine betroffene Position seit der Vorschau
  geändert, ist die Vorschau veraltet und muss neu erzeugt werden.
- Alle bestätigten Einfügungen/Ersetzungen und der Importbericht werden in
  genau einer SwiftData-Transaktion gespeichert.
- Fehler oder Cancellation vor `save()` rollen den gesamten Kandidaten zurück.
- Ein Neustart zeigt entweder den vollständigen bestätigten Import samt
  Bericht oder ausschließlich den vorherigen Bestand; kein Teilimport ist
  zulässig.

## Importbericht und Datenmodell

- Additives Schema v11 ergänzt einen `InventoryImportRecord`.
- Der Bericht speichert ohne Rohdatei und Dateipfad:
  - ID, Zeitpunkt, Ziel-Lager,
  - bereinigten Dateinamen und SHA-256,
  - erkannte Kodierung und Trennzeichen,
  - Zeilenanzahlen,
  - Anzahl hinzugefügt, ersetzt, übersprungen, unverändert und fehlerhaft,
  - zeilengenaue bereinigte Ergebnisse als versionierte Payload.
- Bestehende SDE-, Projekt-, Graph-, Reaktions-, Lager- und Bestandsdaten
  werden durch die v10→v11-Migration unverändert erhalten.
- Backupformat und Kompatibilitätsprüfung steigen auf 11.0.0.

## Anwendung und Oberfläche

- Parser/File-Reader liegen in Infrastructure; Importvertrag und Orchestrierung
  in Application; Transaktion und Berichtspersistenz in Persistence.
- SwiftUI und ViewModels führen keine CSV-Fachlogik und keine direkten
  Datenbankzugriffe aus.
- Die Lageransicht erhält `CSV importieren`.
- Der Importdialog zeigt Dateiauswahl, Formatoptionen, Header-Mapping,
  Vorschau, Zeilendiagnosen, Einzelentscheidungen, Bestätigungsdialog,
  Fortschritt, Abbruch und Ergebnisbericht.
- Die Schreibaktion bleibt deaktiviert, solange Konflikte unentschieden sind
  oder keine gültige Änderung vorliegt.
- Nach Erfolg wird der sichtbare Lagerbestand neu geladen; der Bericht bleibt
  im Dialog lesbar.

## Nicht Bestandteil

- automatische Lagerzuordnung oder Lagererstellung aus CSV,
- lagerübergreifende Verfügbarkeit und Ausschlüsse (P22),
- Sicherheitsbestände (P23),
- Reservierungen (P24/P25),
- ESI-Assets oder automatische Synchronisation,
- JSON-, Backup-, Zwischenablage- oder Multibuy-Import,
- CSV-Preisimport (P28),
- Importhistorienverwaltung oder Berichtsexport.

## Mit zu erledigende offene Punkte

| ID | Restarbeit in P21 | Prüfnachweis |
|---|---|---|
| OFF-005 / KI-005 | Sicheren CSV-Bestandsimport implementieren; Gesamtpunkt danach weiterhin teilweise offen für P22–P25. | Parser-, Service-, Transaktions-, Wiederanlauf-, UI- und Fehlergrenztests; aktualisiertes `OFFEN.md`. |
| OFF-006 / KI-006 / KI-013 | Additive v10→v11-Migration und Backupkompatibilität prüfen; das unabhängige automatische Vor-Migrationsbackup/Recovery-Gate bleibt P36. | befüllter v10→v11-Store, zweite Öffnung, Leerstore und Backup 11.0.0. |

## Risiken

- Falsch erkannte Trennzeichen oder Kodierungen könnten Spalten verschieben.
- Stillschweigende Duplikataggregation oder globale Konfliktentscheidungen
  könnten Bestände verfälschen.
- Eine veraltete Vorschau könnte zwischenzeitliche Benutzeränderungen
  überschreiben.
- Große oder bösartige Dateien könnten Speicher und UI blockieren.
- Teiltransaktionen könnten Bestand und Bericht auseinanderlaufen lassen.

## Messbare Abnahmekriterien

1. UTF-8/BOM, UTF-16-BOM, Windows-1252 sowie Komma, Semikolon und Tab werden
   gemäß Vertrag erkannt oder explizit gewählt.
2. Zitate, `""`, CRLF/LF und zitierte Zeilenumbrüche werden korrekt geparst;
   beschädigte oder übergroße Dateien werden ohne Schreibzugriff abgelehnt.
3. Header können sichtbar Type-ID, Menge und optional Itemname zugeordnet
   werden; unvollständige/doppelte Zuordnungen blockieren die Vorschau.
4. Ganzzahlen und exakte Nullbruch-Dezimalwerte werden als positive `Int64`
   gelesen; Bruchteile, Gruppierung, Null, Negativwert und Überlauf werden
   zeilengenau abgelehnt.
5. Type-IDs und optionale Namen werden gegen den aktiven veröffentlichten
   Katalog geprüft.
6. Doppelte Type-IDs, falsche Spaltenzahl und weitere Fehlerzeilen werden
   isoliert und niemals stillschweigend aggregiert.
7. Neue, unveränderte und bestehende abweichende Positionen werden
   itemgenau unterschieden; jeder Bestandskonflikt verlangt `Ersetzen` oder
   `Überspringen`.
8. Vor der ausdrücklichen Bestätigung bleibt der Store byte- beziehungsweise
   datensatzgleich.
9. Bestätigung schreibt alle ausgewählten Änderungen und den Bericht atomar;
   Fehler/Cancellation erhalten den vollständigen Altbestand.
10. Eine seit Vorschau geänderte Position, ein archiviertes Lager oder eine
    gewechselte Katalogversion blockiert das Schreiben als veraltet.
11. Neustart/Wiederöffnung zeigt vollständigen Import und zeilengenaue
    Berichtspayload; es existiert kein Teilimport.
12. Schema v11 öffnet leer und migriert befülltes v10 ohne Verlust; Backups
    1.0.0 bis 11.0.0 werden akzeptiert, 12.0.0 wird abgelehnt.
13. Die native UI bietet Datei, Optionen, Mapping, Vorschau,
    Einzelentscheidungen, Bestätigung, Abbruch und Ergebnisbericht mit
    Accessibility-Beschriftungen.
14. Ein großer synthetischer Import bleibt innerhalb der definierten Grenzen
    deterministisch und abbrechbar.
15. SwiftPM und Xcode Debug/Release sowie alle relevanten Tests sind
    tatsächlich erfolgreich und nicht übersprungen.
16. Pflichtdokumentation, OFFEN-Audit, Feature-Matrix, Tagebuch,
    Testhistorie, ADR und Abschlussbericht sind aktualisiert.
17. Der gesonderte Review gegen Diff, Code, Tests und Dokumentation ist
    bestanden.

## Erwartetes Ergebnis

Ein lokaler, erklärbarer und gegen unbeabsichtigte Überschreibungen
geschützter CSV-Bestandsimport, der P22 eine verlässliche Datenbasis liefert.
