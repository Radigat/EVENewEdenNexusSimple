# P27 – Manuelle Preise und Preisprofile

Status: **✅ erledigt · 2026-07-25**

## Zweck

Lokale, wiederverwendbare Preisprofile und manuelle Itempreise zuverlässig
pflegen. Die Preise bilden eine typisierte, persistente Eingabequelle für
P29; P27 berechnet noch keine Projektkosten oder Gewinne.

## Voraussetzungen

- P03/P04/P05/P06: Schema-, Fehler-, Test- und Backupfundament,
- P09: veröffentlichter lokaler Itemkatalog,
- P26/P32/P37: intern abgenommener Produktionskern,
- Schema und Backupformat v15/15.0.0 als Migrationsausgang.

## Nicht-Ziele

- kein CSV-Preisimport (P28),
- keine Markt-/ESI-Preise,
- keine Kosten-, Erlös-, Gewinn-, Margen-, ROI- oder Break-even-Rechnung
  (P29),
- keine Einkaufslisten- oder Exportänderung (P30/P31),
- keine automatische Empfehlung für Bauen oder Kaufen,
- keine Währungsumrechnung; P27 unterstützt ausschließlich ISK.

## Fachlicher Vertrag

### Preisprofile

- Ein Profil besitzt UUID, eindeutigen normalisierten Namen, Währung ISK,
  Aktivstatus sowie Erstellungs- und Änderungszeit.
- Namen werden getrimmt; leerer Name und case-/diakritikgleiche Duplikate
  sind ungültig.
- Das erste Profil wird automatisch aktiv. Danach existiert höchstens ein
  aktives Profil.
- Profilwechsel erfolgt nur durch eine ausdrückliche Aktivierungsaktion.
- Löschen verlangt eine sichtbare Bestätigung. Wird das aktive Profil
  gelöscht, wird das alphabetisch erste verbleibende Profil aktiv.
- Preise eines gelöschten Profils werden atomar mit entfernt.

### Manuelle Preise

- Fachschlüssel ist `(Profil-ID, CCP-Type-ID)`.
- Es dürfen nur veröffentlichte Items aus der aktiven lokalen SDE-Version
  gespeichert werden.
- Der Betrag wird exakt als positive ganze Zahl in **Hundertstel ISK**
  gespeichert; keine binäre Gleitkommazahl.
- Texteingaben akzeptieren `123`, `123.4`, `123.45`, `123,4` und `123,45`.
  Tausendertrennzeichen, Vorzeichen, Null, mehr als zwei Nachkommastellen
  und Überlauf werden abgelehnt.
- Quelle ist in P27 immer `manual`.
- `gültig ab` ist verpflichtend, `gültig bis` optional und muss danach
  liegen. Die obere Grenze ist exklusiv.
- Eine erneute Speicherung desselben Items ersetzt den Preis im Profil,
  legt kein Duplikat an und erhält die ursprüngliche Erstellungszeit.
- Löschen verlangt eine sichtbare Bestätigung.

### Auflösung und fehlende Preise

- Für einen Zeitpunkt liefert der Application-Service ausschließlich
  aktuell gültige Preise des aktiven beziehungsweise gewählten Profils.
- Das Ergebnis trennt deterministisch `pricesByTypeID` und
  `missingTypeIDs`.
- Fehlende, noch nicht gültige oder abgelaufene Preise werden nicht als
  Nullpreis erfunden.
- Profilwechsel oder Preisänderung verändern keine Projekte, Graphen,
  Lagerbestände, Reservierungen oder Build-or-Buy-Entscheidungen.

## Mit zu erledigende offene Punkte

- `OFF-011`/`PRC-001`: ausschließlich den P27-Anteil „manuelle Preise und
  Profile“ schließen; P28–P31 bleiben offen.
- `OFF-021`: keine neuen SDE-Datensätze importieren. Der vorhandene
  veröffentlichte Itemkatalog deckt P27 vollständig.
- Backup-/Schemahinweise auf v16/16.0.0 aktualisieren.
- Alle übrigen offenen Release-, Recovery-, Performance- und Future-Punkte
  erneut prüfen, aber nicht vorziehen.

## Architektur und Datenmodell

- neue Domainwerte für ISK, Profil, Preisquelle und Gültigkeit,
- Repository-Port und Application-Service ohne SwiftUI-/SwiftData-Abhängigkeit,
- additive Schema-v16-Modelle für Profil und Preis,
- leichte v15→v16-Migration; Altbestand bleibt unverändert, neue Tabellen
  sind leer,
- SwiftData-Repository validiert Eindeutigkeit, aktive Auswahl,
  Fremdschlüssel und optimistische Versionswerte,
- schlanke ViewModel-/SwiftUI-Grenze als eigenes Navigationsmodul „Preise“,
- zentrale Fehlerzuordnung für Laden und Speichern.

## Daten- und Abbruchschutz

- Formulare schreiben erst nach „Speichern“.
- Löschen schreibt erst nach Bestätigung.
- Fehler und Abbruch rollen den ModelContext zurück.
- Tests verwenden ausschließlich In-Memory- oder isolierte temporäre Stores.
- Keine produktiven Benutzerdaten, Netzwerkzugriffe, Geheimnisse, Commits
  oder Pushes.

## Prüfplan

1. Domainreferenztests für exakte ISK-Parsierung und Gültigkeit,
2. Application-Tests für Profilanlage, Duplikate, Aktivierung,
   Itemvalidierung, Upsert, Löschung und fehlende Preise,
3. Persistenztests für Roundtrip, Eindeutigkeit, Kaskadenlöschung,
   Wiederöffnung und v15→v16-Migration,
4. ViewModel-/Architekturtests für Laden, Profilwechsel, Eingabe und
   SwiftData-freie View,
5. Backupformat 16.0.0 und kompatible Altformate,
6. vollständiger SwiftPM-Debug-Test,
7. Xcode-Projektregeneration, Paritätsprüfung und Xcode-Debug-Test,
8. gesonderter Diff-/Code-/Test-/Dokumentationsreview.

## Messbare Abnahme

- Profile können angelegt, umbenannt, aktiviert und bestätigt gelöscht werden.
- Pro Profil und Type-ID existiert höchstens ein Preis.
- Preise sind ohne Rundungsdrift auf zwei ISK-Nachkommastellen reproduzierbar.
- zeitlich ungültige und fehlende Preise bleiben explizit fehlend.
- v15 migriert datenerhaltend nach v16; Leerstore und Wiederöffnung bestehen.
- Backupformat 16.0.0 sowie Altformatkompatibilität sind geprüft.
- UI besitzt Empty-, Loading-, Error-/Bestätigungs- und aktive Zustände.
- relevante fokussierte und vollständige SwiftPM-/Xcode-Tests bestehen ohne
  übersprungene Tests.
- Dokumentation und Abschlussbericht sind aktualisiert.

Scheitert ein Kriterium, bleibt P27 `⚠️` oder `❌`.
