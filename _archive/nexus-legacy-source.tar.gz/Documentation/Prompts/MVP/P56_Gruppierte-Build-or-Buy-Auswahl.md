# P56 – Gruppierte Build-or-Buy-Auswahl

## Ziel

Der Produktionsworkspace soll Zwischenstufen nicht mehr nur als lange
Einzelliste anbieten. Der Benutzer kann eine vollständige Produktionsart
gemeinsam auf **Bauen** oder **Kaufen** setzen und bei Bedarf einzelne
Abweichungen festlegen.

## Voraussetzungen

- gespeichertes Produktionsprojekt mit aktuellem Produktionsgraph,
- vorhandener P26-Build-or-Buy-Plan,
- verifizierte Aktivitäts- und Inventionsmerkmale im Graphen.

## Umfang

- Gruppierung in **Produktion**, **T2 und Invention**,
  **Biochemical Reactions**, **Composite Reactions** und
  **Hybrid Polymer Reactions**,
- sichtbare Restgruppe für Reaktionen ohne belastbare Unterklassifikation,
- segmentierter Filter nach vorhandener Produktionsart,
- globale Sofortaktionen **Alles bauen** und **Alles kaufen**,
- neutrale Restgruppe für widersprüchlich klassifizierte Type-IDs,
- direkte Gruppenaktionen **Alle bauen** und **Alle kaufen**,
- eingeklappte Einzelentscheidungen je Gruppe,
- kompakte Einzelzeilen mit einmaliger Spaltenüberschrift,
- unveränderte Vorschau- und Bestätigungspflicht,
- unveränderte Persistenz einzelner projektbezogener Type-ID-Entscheidungen,
- automatische Wirkung auf Einkaufsliste und Projektbudget.
- sichtbare Mengen mit deutschen Tausenderpunkten und sichtbare ISK-Werte
  mit Tausenderpunkten, Dezimalkomma und zwei Nachkommastellen.

## Nicht-Ziele

- keine automatische Empfehlung oder Preisoptimierung,
- keine neue EVE-Fachregel,
- keine Schema- oder Migrationserweiterung,
- keine Änderung an Lager-, Reservierungs- oder Preisbeständen.

## Mit zu erledigende offene Punkte

- `OFF-054`: Im Eigentümerbetrieb eine Gruppenaktion, eine einzelne
  Abweichung, Vorschau, Übernahme, Budgetwirkung, eine große Menge, einen
  großen ISK-Betrag und Wiederöffnung prüfen.

## Abnahme

- Kategorien werden aus vorhandenen Rezeptaktivitäten, Inventionsreferenzen
  und `reactionKind` deterministisch gebildet,
- Filter verändern keine Entscheidung,
- **Alles bauen** und **Alles kaufen** ändern alle Stufen des Entwurfs,
- eine Gruppenaktion ändert alle und nur die Stufen der gewählten Kategorie,
- einzelne Entscheidungen bleiben möglich,
- keine Änderung wird vor bestätigter Vorschau gespeichert,
- Mengen erscheinen zum Beispiel als `1.234.567`, ISK als
  `1.234.567,89 ISK`; IDs, Eingaben und Exporte bleiben unverändert,
- fokussierte Tests, Vollsuite und Xcode-Debugbuild bestehen.
