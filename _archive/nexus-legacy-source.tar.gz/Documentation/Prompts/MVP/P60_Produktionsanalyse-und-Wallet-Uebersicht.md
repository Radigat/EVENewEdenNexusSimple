# P60 – Produktionsanalyse und Walletübersicht

Status: vollständig spezifiziert · noch nicht begonnen

## Ziel

Produktions- und Verkaufserfolg tabellarisch sowie grafisch auswerten und die
Walletstände aller verbundenen Charaktere mit transparentem Datenstand
zusammenführen.

## Voraussetzungen

- P57–P59 abgeschlossen und real abgenommen,
- vorhandene Dashboard-/Walletkomponenten auf Wiederverwendung geprüft,
- Performancebudgets aus P34 und Accessibilityregeln aus P35 übernommen.

## Erwartetes Ergebnis

Eine read-only Analyseprojektion über unveränderliche Chargen-, Kosten-,
Verkaufs- und Walletsnapshots. Filter und Diagramme verändern keine
Fachdaten.

## Produktionsübersicht

Spalten und Kennzahlen:

- Jahresnummer, Datum, Produkt, Projekt und Status,
- Runs, ME, TE sowie produzierte, verkaufte und offene Units,
- Material-, Produktions-, Logistik- und Verkaufskosten,
- prognostizierter und realisierter Erlös/Gewinn,
- Kosten, Verkaufspreis und Gewinn je Unit,
- Charakter, System und Produktionsort,
- Jita- und gewählter Home-/Alternativmarktvergleich.

Filter: Zeitraum, Produkt, Projekt, Charakter, System, Aktivität und Status.
Sortierung bleibt stabil; Export enthält nur die aktuell gefilterte Ansicht.

## Diagramme

- Umsatz, Kosten und Realgewinn je Monat,
- produzierte und verkaufte Units,
- Gewinn und Durchschnittsverkaufspreis nach Produkt,
- offene Verkaufsmenge,
- Anteil Produkte/Projekte am Gesamtergebnis.

Diagramme und Tabellen müssen dieselbe Aggregationsversion verwenden und
Totalsummen gegeneinander prüfen.

## Walletübersicht

- jeder Charakter separat mit Stand, Snapshotzeit und Status,
- Gesamtsumme nur aus verfügbaren, kompatiblen Snapshots,
- fehlende, stale, verbotene oder fehlerhafte Wallets separat ausweisen,
- unvollständige Gesamtsumme sichtbar kennzeichnen,
- keine Corporation-Wallets und keine verdeckte Nullsetzung.

## Preis- und Quellenvertrag

P60 lädt Preise nicht automatisch neu. Es zeigt die in P58 gebundenen
Preisquotes einschließlich Jita oder benutzergewähltem Markt und deren
Datenstand. Offene Units dürfen über eine ausdrücklich ausgelöste
Neubewertung mit der aktuellen Marktquelle verglichen werden; historische
Prognosen und realisierte P59-Werte bleiben unverändert.

## Performance und UI

- lazy/paginierte Tabellenprojektion,
- begrenzte Diagrammpunkte und Hintergrundaggregation,
- keine vollständige Datenbankabfrage pro UI-Update,
- Empty-, Loading-, Partial-, Offline- und Error-State,
- Tastatur, VoiceOver, Kontrast und breite/schmale Fenster.

## Nicht-Ziele

- keine Corporation-Daten,
- keine Prognose-KI oder automatische Marktstrategie,
- keine Änderung bestätigter Chargen/Zuordnungen aus der Analyse,
- keine PLEX-Umrechnung als Rechenwährung.

## Mit zu erledigende offene Punkte

Keine unabhängigen Altbefunde; P59-Liveabnahme ist Voraussetzung. Neue
Abweichungen werden nicht als Nullwerte kaschiert.

## Tests

- feste Referenzaggregate über mehrere Jahre/Produkte/Charaktere,
- Teilverkäufe, offene Units, negative Gewinne und leere Zeiträume,
- Jita-/Alternativmarkt-Provenienz und stale Quote,
- fehlende/stale/forbidden Wallets und unvollständige Gesamtsumme,
- Filter-, Sortier-, Export- und Diagrammparität,
- große Datenmenge, Cancellation, Accessibility und Neustart.

## Messbare Abnahme

- fokussierte Aggregations-/UI-/Performance-Tests grün,
- vollständiger SwiftPM-Testlauf und Xcode-Debugbuild grün,
- Eigentümer vergleicht mindestens einen Monats- und Produktwert mit den
  zugrunde liegenden Chargen,
- Tabelle und Diagramm liefern identische Totals,
- Dokumentation, Feature-Matrix, Testhistorie und Bericht aktualisiert,
- gesonderter Review bestanden.
