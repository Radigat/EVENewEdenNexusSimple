# P14 – Runs und Ausgabemengen

Status: **✅ erledigt – am 2026-07-24 vollständig spezifiziert, umgesetzt und reviewed**

## 1. Zweck

P14 ergänzt den P13-Produktionsgraphen um eine zentrale, deterministische
Berechnung der benötigten vollständigen Blueprint-Runs, der tatsächlich
erzeugten Produktmenge und des unvermeidbaren Überschusses.

Für eine positive Zielmenge und eine positive Ausgabemenge je Run gilt:

```text
Runs = ceil(Zielmenge / Ausgabemenge je Run)
Tatsächliche Ausgabe = Runs × Ausgabemenge je Run
Überschuss = Tatsächliche Ausgabe − Zielmenge
```

Bruchteile von Runs, Fließkommaarithmetik und stiller Mengenüberlauf sind
unzulässig.

## 2. Voraussetzungen und Ausgangsstand

- P10 liefert ein eindeutiges, versionsgebundenes Rezept mit positiver
  Produktmenge je Run.
- P12 liefert positive Projektzielmenge und kataloggebundene Blueprint-ID.
- P13 liefert einen validierten, persistierten Produktionsgraphen der ersten
  Rezeptstufe in Schema v6 und Payloadformat 1.
- SwiftPM und Xcode bestanden nach P13 in Debug und Release.
- P15 wurde nicht begonnen.

Der P13-Graph speichert Rezeptoutput, berechnet aber noch keine Runs,
Gesamtausgabe oder Überschuss.

## 3. Verbindliche Quellen und fachliche Entscheidung

Verbindliche Projektgrundlage:

- Projektbuch Kapitel 30.3 bis 30.5,
- Projektbuch Anhang E.1 bis E.4 und E.27,
- `Documentation/PRODUCTION_GRAPH.md`,
- `Documentation/RECIPE_RESOLUTION.md`.

Am 2026-07-24 zusätzlich geprüft:

- CCP, [Blueprints](https://support.eveonline.com/hc/articles/203269951):
  BPOs besitzen unbegrenzte, BPCs begrenzte lizenzierte Produktionsruns.
- CCP, [Copying](https://support.eveonline.com/hc/en-us/articles/203210602-Copying):
  die maximale Produktionsrunzahl begrenzt die Runs je erzeugter Kopie.
- CCP, [Static Data](https://developers.eveonline.com/docs/services/static-data/):
  Blueprint- und Outputdaten stammen aus dem versionierten SDE.

`maxProductionLimit` ist deshalb in P14 ausschließlich SDE-Provenienz für die
spätere konkrete BPC-Planung. Es ist weder ein Maximum der Projekt-Runs noch
eine Jobgrößengrenze und darf nicht zur automatischen Aufteilung in erfundene
Jobs oder Batches verwendet werden. Persönliche BPO-/BPC-Bestände und
verbleibende lizenzierte Runs sind verschoben.

Ein P14-„Output-Batch“ ist nur die unteilbare Ausgabe eines vollständigen
Blueprint-Runs. Es wird kein zusätzliches fachlich unbelegtes Batchmodell
persistiert.

## 4. Mit zu erledigende offene Punkte

| ID | Verbindliche P14-Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-004 / KI-003 | Den P14-Anteil schließen: Runs, tatsächliche Ausgabe und Überschuss für jeden in P14 vorhandenen Rezeptknoten berechnen. ME, Rekursion und Aggregation bleiben P15–P19. | Domain-, Application-, Persistenz-, ViewModel- und UI-Tests; Status bleibt danach `teilweise` |
| OFF-009 / KI-012 | Überlauf für Run-Aufrundung und Outputmultiplikation ohne `Int`-Trap typisiert erkennen. Aggregationsüberlauf bleibt P19. | Grenztests bis `Int64.max`, expliziter Overflowtest |
| OFF-006 / KI-006 / KI-013 | Additive Schema-v7-Migration für Payloadformat 2, v6-Bestandsschutz, zweite Öffnung und Backupformat 7.0.0 prüfen. | Migrations-, Repository-, Wiederöffnungs- und Backuptests |
| OFF-021 / KI-021 | Prüfen, ob weitere SDE-Datensätze nötig sind. | dokumentierte Entscheidung: vorhandener Rezeptoutput genügt; kein Mehrimport |
| OFF-027 / KI-027 | Run-/Outputdarstellung in der separaten Graphansicht halten. | Architekturtest; keine Fachlogik und kein SwiftData im Projekteditor |

Andere aktive Punkte werden nicht vorgezogen.

## 5. Umfang

P14 implementiert:

- zentralen Domainwert `ProductionRunCalculation`,
- Formelversion 1,
- reine ganzzahlige Ceiling-Division,
- benötigte Runs,
- tatsächliche Ausgabemenge,
- Überschussmenge,
- typisierte Eingabe- und Überlauffehler,
- Runberechnung für jeden Rezeptknoten eines neu erzeugten Graphen,
- Graph-Payloadformat 2,
- lesbaren Bestandsschutz für Payloadformat 1,
- Stale-Erkennung alter oder unberechneter Graphen,
- Schema v7 und Backupformat 7.0.0,
- sichtbare Run-/Outputaufschlüsselung in der Graphansicht.

P14 implementiert ausdrücklich nicht:

- Material Efficiency oder Materialrundung (P15),
- Rohmaterial-Gesamtmengen,
- T1-/T2-Rekursion (P16/P17),
- zusätzliche Reaktionsstufen (P18),
- Materialaggregation oder deren Überlaufregel (P19),
- BPO-/BPC-Besitz, verbleibende lizenzierte Runs oder Jobaufteilung,
- Zeit-, Slot- oder Kapazitätsplanung,
- Bestände, Build-or-Buy, Preise oder Kosten.

## 6. Domainmodell

`ProductionRunCalculation` enthält:

| Feld | Typ | Regel |
|---|---|---|
| `formulaVersion` | `Int` | aktuell exakt `1` |
| `requestedOutputQuantity` | `Int64` | positiv |
| `outputQuantityPerRun` | `Int64` | positiv |
| `requiredRuns` | `Int64` | exakte Ceiling-Division, mindestens 1 |
| `producedOutputQuantity` | `Int64` | exakt `requiredRuns × outputQuantityPerRun` |
| `surplusOutputQuantity` | `Int64` | exakt Ausgabe minus Ziel, mindestens 0 |

Der öffentliche Initialisierer nimmt nur Zielmenge und Output je Run entgegen.
Abgeleitete Werte werden zentral berechnet, nicht von Aufrufern geliefert.

Die Codable-Decodierung prüft gespeicherte abgeleitete Werte durch
Neuberechnung. Manipulierte oder inkonsistente Payloads werden abgelehnt.

## 7. Rundungs- und Überlaufregeln

Die Ceiling-Division verwendet keine Fließkommazahl und nicht die potenziell
überlaufende Formel `(a + b - 1) / b`.

```text
Quotient = Zielmenge / Output je Run
Rest = Zielmenge % Output je Run
Runs = Quotient + (Rest == 0 ? 0 : 1)
```

Für die Outputmultiplikation wird ein geprüftes Ganzzahlprodukt verwendet.
Bei Überlauf wird ein typisierter Fehler zurückgegeben; kein Wert wird
geklemmt, gewrappt oder still verworfen.

Referenzfälle:

| Ziel | Output/Run | Runs | Ausgabe | Überschuss |
|---:|---:|---:|---:|---:|
| 25 | 10 | 3 | 30 | 5 |
| 20 | 10 | 2 | 20 | 0 |
| 1 | 10 | 1 | 10 | 9 |
| 10 | 1 | 10 | 10 | 0 |
| `Int64.max` | `Int64.max` | 1 | `Int64.max` | 0 |

`Int64.max / (Int64.max − 1)` benötigt zwei Runs und muss wegen
Outputüberlauf typisiert scheitern.

## 8. Graphintegration und Payloadversion

`ProductionGraphNode` erhält optional:

```text
runCalculation: ProductionRunCalculation?
```

Regeln:

- Materialknoten besitzen keine Runberechnung.
- Jeder Rezeptknoten in Payloadformat 2 besitzt genau eine Runberechnung.
- Output je Run muss mit der Rezeptreferenz übereinstimmen.
- Beim Zielknoten muss die angefragte Menge der Projektzielmenge entsprechen.
- Payloadformat 1 bleibt lesbar und enthält keine Runberechnung.
- Neue Graphen verwenden Payloadformat 2.
- Ein Format-1-Graph oder ein Format-2-Graph ohne korrekte Berechnung gilt
  als veraltet und kann bewusst neu erzeugt werden.

P14 erzeugt weiterhin nur die erste Rezeptstufe. Das Modell ist für spätere
Zwischenknoten vorbereitet, P14 erzeugt sie aber nicht.

## 9. Application-Ablauf

Der bestehende `ProductionGraphService`:

1. prüft Projekt, Ziel, Archivstatus und Cancellation,
2. löst exakt das gespeicherte P10-Rezept derselben Katalogversion,
3. berechnet vor dem Aufbau des Zielknotens Runs und Output,
4. erzeugt Payloadformat 2 mit der Runberechnung am Zielknoten,
5. validiert den vollständigen Snapshot,
6. speichert erst danach atomar.

Ein Rechen-, Validierungs-, Abbruch- oder Persistenzfehler darf einen
bestehenden Graphen nicht ersetzen.

## 10. Persistenz und Schema v7

Schema v7:

- verwendet dieselben SwiftData-Tabellen und erweitert keine Benutzerdaten
  destruktiv,
- kennzeichnet die neue fachliche Payloadgeneration,
- migriert v6→v7 leichtgewichtig,
- erhält Projekte, SDE-Daten und Format-1-Graphpayloads unverändert,
- lässt Format-1-Graphen weiterhin lesbar, aber fachlich veraltet,
- erzeugt neue Graphen in Format 2,
- aktualisiert Backupformat und Kompatibilitätsprüfung auf 7.0.0.

Keine Bestands-Payload wird stillschweigend neu berechnet. Dafür wäre die
damals aktive Katalog- und Projektentscheidung erforderlich; der Benutzer
regeneriert bewusst.

## 11. Benutzeroberfläche

Die bestehende `ProductionGraphView` zeigt für Rezeptknoten mindestens:

- gewünschte Ausgabemenge,
- Output je Run,
- benötigte vollständige Runs,
- tatsächliche Ausgabe,
- Überschuss,
- Formelversion beziehungsweise nachvollziehbaren Berechnungsstatus.

Für einen alten Graphen ohne P14-Berechnung:

- bleibt die bisherige Struktur sichtbar,
- erscheint der Status „Veraltet“,
- wird eine bewusste Neuerzeugung angeboten,
- werden keine Runwerte erfunden.

Die UI erklärt, dass Materialmengen weiterhin Basismengen je Run sind und ME
erst P15 folgt.

## 12. Fehlerbehandlung

Mindestens typisiert behandeln:

- Zielmenge 0 oder negativ,
- Output je Run 0 oder negativ,
- nicht unterstützte Formelversion,
- manipulierte abgeleitete Werte beim Decodieren,
- Outputmultiplikationsüberlauf,
- Graphformat-/Rezept-/Berechnungswiderspruch,
- Cancellation,
- Repositoryfehler.

Keine Rohfehler oder internen Payloaddaten gelangen in die UI oder Logs.

## 13. Automatisierte Tests

### Domain

- Projektbuchreferenz 25/10 → 3 Runs, 30 Ausgabe, 5 Überschuss,
- exakte Teilung,
- Output größer als Ziel,
- Output 1,
- Fertigungs- und Reaktionsoutput,
- 0 und negative Eingaben,
- `Int64.max` ohne Überlauf,
- Multiplikationsüberlauf,
- Codable-Roundtrip,
- manipulierte Payload,
- Graphformat 1 bleibt gültig und ohne Berechnung,
- Graphformat 2 verlangt konsistente Berechnung,
- Materialknoten lehnt Runberechnung ab,
- Rezeptoutput und Runberechnung müssen übereinstimmen.

### Application

- Fertigungsprojekt berechnet und persistiert Runs/Output,
- Reaktionsprojekt mit Output größer 1,
- exakte und aufgerundete Menge,
- deterministische Wiederholung,
- alter Graph ist stale,
- Rechenfehler ersetzt bestehenden Graphen nicht,
- Cancellation und Repositoryfehler.

### Persistenz/Migration

- Format-2-Roundtrip,
- Format-1-Payload bleibt lesbar,
- Replacement je Projekt,
- beschädigte Berechnung wird abgelehnt,
- neuer Schema-v7-Leerstore,
- v6→v7 erhält Projekt, SDE und Format-1-Graph,
- vollständige Legacy→v7-Kette und zweite Öffnung,
- Backupversionen 1.0.0 bis 7.0.0.

### ViewModel/UI

- Loading, Empty, Stale und Regeneration,
- sichtbare Runs, Output und Überschuss,
- alte Graphen zeigen keine erfundenen Werte,
- Tastatur und Accessibility,
- View/ViewModel ohne SwiftData,
- keine P15–P19-Logik.

### Gesamtprüfung

- SwiftPM Debug/Release,
- Xcode Debug/Release,
- Xcode-/SwiftPM-Projektparität,
- echter isolierter App-Smoke-Test mit Schema-v7-Store.

Produktive Benutzerdaten werden nicht als Testdaten verwendet.

## 14. Dokumentation

Mindestens aktualisieren:

- `Documentation/RUNS_AND_OUTPUTS.md`,
- `Documentation/PRODUCTION_GRAPH.md`,
- Datenmodell, Architektur und neues ADR,
- `CURRENT_PROJECT_STATUS.md`,
- `DEVELOPER_MENU.md`,
- `FEATURE_MATRIX.md`,
- `DEVELOPER_DIARY.md`,
- `OFFEN.md`,
- `OPEN_TASKS.md`,
- `KNOWN_ISSUES.md`,
- `TEST_HISTORY.md`,
- Promptregister und Roadmap,
- Abschlussbericht `YYYY-MM-DD_P14_Runs-Ausgabemengen.md`.

## 15. Definition of Done

P14 ist nur `✅`, wenn:

- Runformel und Invarianten zentral implementiert sind,
- Projektbuchreferenz und Grenzwerte bestanden sind,
- neue Graphen Format 2 mit nachvollziehbaren Runwerten besitzen,
- alte Format-1-Graphen lesbar und stale bleiben,
- Schema v7, Backup 7.0.0 und Bestandsschutz geprüft sind,
- Runs, Ausgabe und Überschuss in der App sichtbar sind,
- `maxProductionLimit` nicht als unbelegte Projekt-/Jobgrenze verwendet wird,
- keine ME-, Materialgesamt-, Rekursions- oder Aggregationslogik vorgezogen
  wurde,
- notwendige offene Punkte erneut geprüft sind,
- SwiftPM und Xcode in Debug/Release grün sind,
- isolierter App-Smoke-Test, Pflichtdokumentation und Abschlussbericht
  vorliegen,
- der gesonderte Review `✅ bestanden` entscheidet.

P15 darf nicht automatisch begonnen werden.
