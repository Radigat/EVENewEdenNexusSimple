# P06 – Lokale Backups

Status: **✅ erledigt und reviewed am 2026-07-23**

## Zweck

Eine sichere technische Backup- und Restore-Grenze für den lokalen SwiftData-Store schaffen. P06 muss einen konsistenten Datenbank-Snapshot erzeugen, das Paket vor Verwendung prüfen und ein versehentliches Überschreiben aktueller Daten verhindern.

## Voraussetzungen

- P03 – Schema v1, Migration und Persistence-Target,
- P04 – zentrale Fehler- und Diagnosegrenze,
- P05 – TestSupport, temporäre Stores und Referenztestbasis.

## Ausgangszustand

- Der produktive Store ist eine von SwiftData verwaltete SQLite-Datenbank.
- SQLite kann WAL-/SHM-Seitendateien verwenden; einfaches Kopieren der Hauptdatei ist daher kein konsistentes Backup.
- Es gibt noch keinen Backup-Service, kein Paketformat, keine Integritätsprüfung und keinen Restore-Ablauf.
- `NexusModelContainerFactory` ist der einzige produktive Containerweg.
- Schema v1 ist aktuell; P06 führt keine neue Migration ein.

## Verbindlicher Umfang

1. Application-Verträge und UI-unabhängige Typen für Backup, Vorschau, Bestätigung und Restore-Ergebnis definieren.
2. In Persistence einen austauschbaren lokalen Backup-Service implementieren.
3. Ein Backup ist ein Verzeichnispaket mit Endung `.nenbackup`.
4. Paketversion 1 enthält:
   - `manifest.json`,
   - `database.sqlite`.
5. Das Manifest enthält mindestens:
   - Formatkennung und Formatversion,
   - Backup-ID,
   - Erstellungsdatum,
   - Backupart,
   - kompatible Schemaversion,
   - Datenbankdateiname,
   - Dateigröße,
   - SHA-256-Prüfsumme,
   - Verschlüsselungskennzeichnung.
6. Die Datenbankkopie mit der SQLite-Online-Backup-API erzeugen. Hauptdatei, WAL und SHM dürfen nicht unkoordiniert einzeln kopiert werden.
7. Vor Veröffentlichung des Pakets `PRAGMA quick_check` ausführen, Größe und SHA-256 berechnen und das vollständige Paket innerhalb desselben Zielordners atomar von einer Staging-Struktur umbenennen.
8. Unvollständige `.partial`-Pakete bei Fehlern entfernen.
9. Paket, Manifest und Datenbank auf symbolische Links, unterstützte Versionen, Größe, Prüfsumme und SQLite-Integrität prüfen.
10. `previewRestore` muss rein lesend sein und darf den Zielstore nicht verändern.
11. Restore erfordert:
    - eine zuvor erzeugte Vorschau,
    - ausdrückliche Bestätigung,
    - die Erklärung des Aufrufers, dass der Zielstore geschlossen ist.
12. Ein vorhandener Zielstore wird erst nach einem erfolgreichen automatischen Sicherheitsbackup ersetzt.
13. Die Ersatzdatei zunächst im Zielordner aufbauen und anschließend atomar einsetzen.
14. Alte WAL-/SHM-Seitendateien nur im bestätigten Restore-Ablauf und erst nach erfolgreichem Sicherheitsbackup kontrolliert behandeln.
15. Backup-, Inspect- und Restore-Fehler in die zentrale sichere Fehlertaxonomie integrieren.
16. Vollständige Integrationstests mit echten temporären SwiftData-Stores erstellen.

## Formatentscheidungen

- **Komprimierung:** keine in Formatversion 1. Das Paket bleibt prüfbar und ohne zusätzlichen Archivparser wiederherstellbar.
- **Verschlüsselung:** keine anwendungseigene Verschlüsselung in P06. OAuth-Tokens sind ausgeschlossen und verbleiben im Keychain. Paketverzeichnisse erhalten restriktive lokale Dateirechte. Benutzer müssen für externe Datenträger selbst einen geschützten Speicherort wählen.
- **Speicherort:** vom Aufrufer beziehungsweise später von der Benutzeroberfläche als Verzeichnis-URL übergeben; kein fest codierter Benutzerpfad.
- **Aufbewahrung:** `keep all`. P06 löscht keine erfolgreichen Backups automatisch. Eine konfigurierbare Aufbewahrungsrichtlinie folgt erst mit der Einstellungsoberfläche.
- **Backuparten:** manuell, vor Migration, vor Restore. P06 implementiert die technische Fähigkeit; die automatische Auslösung vor einer künftigen Migration wird beim nächsten tatsächlichen Schemasprung beziehungsweise im Recovery-Drill verdrahtet.

## Fehlerfälle

Mindestens unterscheiden:

- Quellstore fehlt oder ist ein symbolischer Link,
- Zielverzeichnis kann nicht erstellt werden,
- Paket existiert bereits,
- Manifest fehlt oder ist ungültig,
- Format- oder Schemaversion wird nicht unterstützt,
- Datenbank fehlt oder ist ein symbolischer Link,
- Größe oder SHA-256 stimmt nicht,
- SQLite-Integritätsprüfung schlägt fehl,
- Restore wurde nicht bestätigt,
- Zielstore ist nicht als geschlossen markiert,
- Backup wurde nach der Vorschau verändert,
- Sicherheitsbackup oder atomischer Ersatz schlägt fehl.

Fehlertexte und Logs dürfen keine vollständigen lokalen Pfade, Notizen oder andere Inhalte des Stores offenlegen.

## Tests und Referenzfälle

| Test-ID | Fall | Erwartetes Ergebnis |
|---|---|---|
| BACKUP-REF-001 | Backup eines geöffneten SwiftData-Stores | konsistentes Paket, gültiges Manifest, SHA-256 und `quick_check` |
| BACKUP-REF-002 | manipulierte Datenbankdatei | Vorschau wird ohne Storeänderung abgelehnt |
| BACKUP-REF-003 | Restore ohne Bestätigung oder mit offen markiertem Store | Restore wird abgelehnt, Zielinhalt bleibt erhalten |
| BACKUP-REF-004 | bestätigter Restore | automatisches Sicherheitsbackup, atomischer Ersatz und vollständige Datenwiederherstellung |
| BACKUP-REF-005 | Backup nach Vorschau verändert | Restore wird vor Zieländerung abgelehnt |
| BACKUP-REF-006 | fehlender Quellstore | kein finales oder partielles Paket bleibt zurück |
| BACKUP-REF-007 | Zielstore nach Vorschau verändert | Restore wird vor Sicherheitsbackup und Zielersatz abgelehnt |
| BACKUP-REF-008 | nicht unterstützte Formatversion | Vorschau wird mit konkretem Kompatibilitätsfehler abgelehnt |

## Ausdrücklich nicht Bestandteil

- neue SwiftData-Entitäten oder Schemaversion,
- Backup von Keychain-Tokens,
- Cloud- oder Netzwerkbackup,
- inkrementelle Backups,
- Komprimierung oder eigene Kryptografie,
- automatische Löschung alter Sicherungen,
- fertige SwiftUI-Einstellungs-/Recovery-Oberfläche,
- vollständiger App-Neustart- und Recovery-Drill aus P36,
- SDE- oder sonstige fachliche MVP-Funktionen.

## Betroffene Dateien

- `Sources/NewEdenNexusApplication/`
- `Sources/NewEdenNexusPersistence/`
- `Tests/NewEdenNexusApplicationTests/`
- `Tests/NewEdenNexusPersistenceTests/`
- `Documentation/BACKUP_AND_RESTORE.md`
- Architektur-, ADR-, Status-, OFFEN-, Test- und Abschlussdokumentation

## Befehle

```bash
swift package describe
swift build -c debug
swift build -c release
swift test -c debug --enable-code-coverage
swift test -c release
./Scripts/ci-verify.sh
```

## Abnahmekriterien

- Paketformat und Sicherheitsgrenzen sind dokumentiert.
- Online-Backup funktioniert auch bei geöffnetem Quellcontainer.
- finale Pakete werden erst nach vollständiger Prüfung sichtbar.
- Vorschau verändert Quelle und Ziel nicht.
- manipulierte oder inkompatible Pakete werden abgelehnt.
- Restore ohne Bestätigung oder bei nicht geschlossenem Zielstore wird abgelehnt.
- Restore erstellt vor dem Überschreiben ein verifiziertes Sicherheitsbackup.
- Daten aus Backup und Sicherheitsbackup können vollständig erneut geöffnet werden.
- keine produktive Schema- oder Benutzerdatenänderung.
- zentrale Fehlercodes und Redaction bleiben wirksam.
- Debug-/Release-Build und relevante Tests sind erfolgreich.
- OFFEN-Audit, Pflichtdokumentation und gesonderter Review sind abgeschlossen.

## Abschluss

P06 darf nur bei vollständigem Nachweis auf `✅ erledigt` gesetzt werden. Die technische Backup-/Restore-Grenze kann abgeschlossen sein, während die Feature-Matrix die noch fehlende UI- und P36-Recovery-Integration weiterhin als teilweise ausweist. P07 wird nicht automatisch begonnen.
