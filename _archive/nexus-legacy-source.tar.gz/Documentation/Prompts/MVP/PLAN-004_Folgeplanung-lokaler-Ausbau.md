# PLAN-004 – Folgeplanung für den lokalen Ausbau

Status: ✅ Planung abgeschlossen

## Ziel

Die vorhandenen Zukunftsprompts ohne Parallelpakete in eine verbindliche,
wertorientierte Reihenfolge bringen. Der lokale Produktionsplaner bleibt
jederzeit nutzbar; jeder Folgeprompt beginnt nur auf ausdrücklichen Auftrag.

## Verbindliche Reihenfolge

| Abschnitt | Prompts | Ergebnis |
|---|---|---|
| Persönliche EVE-Anbindung | P38 → P39 → P40 | sicheres SSO, robuste ESI-Basis, lokale Live-Assets/Blueprints/Jobs |
| Märkte und Ist-Finanzen | P41 → P42 | optionale Live-Preise, Wallet und reale Projektkosten |
| Erweiterte Industrie | P43 → P44 | Reaktionsmanagement, PI, Logistik und Kapazität |
| Zusammenarbeit und Optimierung | P45 → P46 → P47 | Corporation, optionale Cloud/Mehrbenutzer, erklärbare Optimierung |
| Öffentliche Distribution | P48 | zuletzt optional: Mac App Store oder öffentliche Direktverteilung |

## Ausführungsregeln

- P38 ist der nächste offene Prompt, aber noch nicht in Bearbeitung.
- P39 bis P44 bleiben eingeplant und werden jeweils erst nach Abnahme des
  Vorgängers vollständig spezifiziert.
- P45 bis P47 bleiben bedarfsabhängige Zukunftspakete.
- P48 bleibt nach P47 das letzte optionale Paket und wird nur bei späterem
  Veröffentlichungswunsch aktiviert.
- Neue Befunde werden dem vorhandenen fachlichen Eigentümerprompt
  zugeordnet; keine Parallelprompts ohne echte Abdeckungslücke.
- Nach jedem Abschnitt ist ein Stop-/Nutzenreview zulässig. Das Überspringen
  eines Prompts darf keine stillschweigend verletzte Abhängigkeit erzeugen.

## Nächster Prompt

P38 – SSO-Härtung anhand der vollständig geschärften Promptdatei ausführen.

## Nicht-Ziele

- keine fachliche Implementierung,
- kein SSO-/ESI-Livezugriff,
- keine Daten-, Schema-, Signing- oder Portaländerung,
- kein automatischer Beginn von P38,
- keine öffentliche Distribution.

## Abnahme

- Entwickler-Menü, Roadmap und Promptregister zeigen dieselbe Reihenfolge,
- P38 ist als nächster offener und ausführbarer Prompt vollständig
  spezifiziert,
- P39 bis P47 bleiben geordnet und nicht fälschlich als begonnen markiert,
- P48 bleibt zuletzt optional,
- OFF-008, OFF-010 und OFF-013 sind P38 zugeordnet,
- Abschlussbericht und Tagebuch sind aktualisiert,
- Dokumentformat und Xcode-Projektparität sind geprüft.
