# P12 – Kataloggestützte Zielproduktauswahl

Status: **✅ am 2026-07-24 vollständig ausgeführt**
Voraussetzung OFF-026: **✅ am 2026-07-24 erledigt**

## 1. Zweck

Produktionsprojekte erhalten ein reproduzierbares Ziel aus dem aktiven
lokalen EVE-Katalog statt eines nicht auflösbaren Freitexts. Der Benutzer
wählt ein veröffentlichtes, tatsächlich produzierbares Item, eine
unterstützte Aktivität und – wenn mehrere Rezepte existieren – den konkreten
Blueprint. Zusätzlich wird eine positive Zielmenge erfasst.

P12 implementiert noch keinen Produktionsgraphen, keine Runs, keine
Materialberechnung und keine automatische Blueprintoptimierung.

## 2. Voraussetzungen und Ausgangsstand

- P09 stellt begrenzte, normalisierte Itemsuche, Kategorie-/Gruppenfilter,
  `producibleItems`, Aktivitätsfilter und exakte Item-/Blueprint-Lookups aus
  genau einer aktiven SDE-Version bereit.
- P10 löst Fertigungs- und Reaktionsrezepte deterministisch auf und blockiert
  Mehrdeutigkeit, nicht veröffentlichte Ziele sowie unvollständige
  Referenzen.
- P11 stellt den vollständigen lokalen Projektlebenszyklus bereit.
- Projekte speichern derzeit nur `productName`; eine stabile Type-ID,
  Aktivität, Blueprintwahl und Katalogprovenienz fehlen.
- Schema v4 ist aktuell. P12 benötigt deshalb eine additive Schema-v5-
  Migration.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-026 / KI-026 | **Erledigt:** app-spezifischen Standardpfad, sichere Legacy-Signaturprüfung und explizite Testisolation bereitstellen, ohne den fremden globalen `default.store` zu löschen oder zu ersetzen. | Sieben fokussierte Tests, vier vollständige 205-Test-Suites, echter isolierter App-Prozess und unveränderter Fremdstore; [Bericht](../../Progress/Reports/2026-07-24_OFF-026_Isolierter-App-Start.md) |
| OFF-021 / DAT-010 | Entscheiden, ob Marktgruppen für P12 erforderlich sind. | Entscheidung dokumentieren und Quell-/Schemadiff prüfen |
| PRJ-001 | Freitextziel durch eine persistente, kataloggestützte Auswahl ergänzen und vorhandene Projekte erhalten. | Domain-, Migrations-, Repository-, ViewModel- und UI-Tests |

### Entscheidung zu OFF-021

P12 importiert **keine Marktgruppenobjekte**. Der vorhandene Katalog liefert
Kategorie, Gruppe, `marketGroupID`, Produktionsaktivitäten und
veröffentlichte/prodizierbare Items. Für die erste MVP-Auswahl genügen:

- Namenssuche,
- Kategorie,
- Gruppe,
- Fertigung oder Reaktion.

Ein Marktgruppenname oder eine Markthierarchie verbessert die Navigation,
ist aber kein fachliches Gültigkeitskriterium. `OFF-021` bleibt für
P27 beziehungsweise spätere konkret begründete Markt-/Navigationsfunktionen
offen. Es erfolgt kein pauschaler SDE-Mehrimport.

Andere aktive Punkte – Graph/Berechnung P13–P19, Bestände P20–P25,
Preise/Einkauf P27–P31, Wartbarkeit P34, Recovery P36 und Release P37 –
werden nicht vorgezogen.

## 4. Persistentes Zielmodell

Application und Domain erhalten einen sendbaren Werttyp
`ProductionTargetSelection` mit:

- `productTypeID: Int64`,
- `productName: String` als lokaler Anzeigesnapshot,
- `activity: manufacturing | reaction`,
- `blueprintTypeID: Int64`,
- `catalogBuildNumber: Int`,
- `catalogContentSHA256: String`.

Regeln:

- IDs und Buildnummer sind positiv,
- Name und Hash sind nicht leer,
- nur deterministische Fertigung und Reaktion sind zulässig,
- die Blueprint-ID muss durch P10 exakt für Produkt und Aktivität validiert
  worden sein,
- Name ist kein Schlüssel; die CCP-Type-ID ist fachlich maßgeblich,
- Build und Hash dokumentieren die geprüfte Auswahlversion.

`ProductionProjectSnapshot` und `ProductionProjectDraft` erhalten dieses Ziel.
`productName` bleibt im persistenten Modell als denormalisierter
Anzeigesnapshot erhalten, wird aber bei neuen beziehungsweise neu
ausgewählten Zielen ausschließlich aus dem Katalog übernommen.

## 5. Schema v5 und Bestandsprojekte

Schema v5 ergänzt `ProductionProject` additiv um optionale Felder:

- `productTypeID`,
- `productActivityRaw`,
- `productBlueprintTypeID`,
- `productCatalogBuildNumber`,
- `productCatalogContentSHA256`.

Migration v4→v5:

- erhält alle vorhandenen Felder und Datensätze,
- übernimmt keine erfundene Type-ID aus einem Namen,
- lässt die neuen Felder für Bestandsprojekte leer,
- markiert Bestandsprojekte dadurch fachlich als „Ziel erneut auswählen“,
- verändert weder Status noch Zeitstempel,
- löscht oder überschreibt keine Benutzer- oder SDE-Daten.

Bestandsprojekte bleiben lesbar, filterbar, duplizierbar und archivierbar.
Vor Bearbeitung des Zielprodukts oder späterer Graphberechnung muss der
Benutzer ein gültiges Katalogziel auswählen. Eine automatische
Namenszuordnung ist wegen Mehrdeutigkeit verboten.

Zu prüfen sind:

- neuer leerer Schema-v5-Store,
- v4→v5 mit mindestens aktivem, abgeschlossenem und archiviertem Projekt,
- vollständige Kette Legacy→v1→v2→v3→v4→v5,
- zweite Öffnung desselben Stores,
- Backup-/Versionskompatibilität ohne vorgezogene Recovery-UI.

## 6. Auswahl- und Validierungsservice

Application erhält einen zentralen, SwiftUI- und SwiftData-freien Service,
beispielsweise `ProductionTargetSelectionService`.

Er:

1. sucht ausschließlich `publishedOnly` und `producibleItems`,
2. begrenzt Ergebnisse auf höchstens 50 plus `hasMore`,
3. unterstützt Aktivität, Kategorie und Gruppe,
4. lädt Itemdetails aus derselben aktiven Katalogversion,
5. ermittelt Fertigungs-/Reaktionskandidaten,
6. validiert die konkrete Auswahl über `ResolveRecipeUseCase`,
7. erzeugt erst danach `ProductionTargetSelection`.

Rezeptregeln:

- genau ein vollständiges Rezept: Blueprint wird automatisch ausgewählt,
- mehrere vollständige Rezepte: Benutzer muss einen konkreten Blueprint
  wählen,
- kein Rezept: Auswahl nicht speicherbar,
- nicht aufgelöste Referenz: betroffener Kandidat ist nicht speicherbar und
  zeigt den sicheren P10-Diagnosecode,
- ein vollständiger Kandidat darf trotz eines anderen unvollständigen
  Kandidaten gewählt werden,
- kein stiller Fallback auf ein anderes Item, eine andere Aktivität oder
  einen anderen Blueprint.

## 7. Zielmenge

- Fachlich zulässig sind positive ganze Zahlen.
- `0`, negative Werte, Dezimalwerte, Leertext und Überlauf werden
  abgelehnt.
- P12 führt keine willkürliche 100-Millionen-Obergrenze ein.
- Die UI verwendet eine lokalisierte Ganzzahleingabe und prüft gegen den
  darstellbaren `Int`-Bereich.
- Runs, Outputrundung und Materialüberlauf folgen P14/P19.
- Eine Mengenänderung verändert nicht die gewählte Produktidentität oder
  Katalogprovenienz.

## 8. Such- und Auswahloberfläche

Das Projektformular ersetzt das freie Zielprodukt-Textfeld durch:

- Schaltfläche beziehungsweise Suchfeld „Zielprodukt auswählen“,
- abbrechbare, verzögerte Suche während der Eingabe,
- Filter `Alle`, `Fertigung`, `Reaktion`,
- optionale Kategorie-/Gruppenfilter,
- Ergebnisliste mit Itemname, Type-ID, Kategorie, Gruppe und Aktivität,
- Kennzeichnung unvollständiger beziehungsweise mehrdeutiger Rezepte,
- Detailbereich mit ausgewähltem Produkt, Aktivität, Blueprint,
  Outputmenge je Lauf und aktiver SDE-Buildnummer,
- Blueprintauswahl nur bei mehreren gültigen Kandidaten,
- positive Mengeneingabe,
- Aktion zum bewussten erneuten Auswählen eines Bestandsprojektziels.

Zustände:

- kein Suchtext/erste produktive Treffer,
- Suche läuft,
- keine Treffer,
- mehr Treffer vorhanden,
- keine aktive oder mehrere aktive SDE-Versionen,
- Offlinebetrieb mit lokalem Katalog,
- Item nach SDE-Wechsel nicht mehr vorhanden,
- Rezept unvollständig oder mehrdeutig,
- Suche beziehungsweise Auswahl abgebrochen,
- Lade-/Persistenzfehler.

Tastatur, VoiceOver, Fokusführung, Kontrast, schmale/breite Fenster und lange
Itemnamen sind zu prüfen. Keine Fach- oder Persistenzlogik liegt in Views.

## 9. Verhalten bei SDE-Wechsel

- Gespeicherte CCP-IDs bleiben unverändert.
- Beim Öffnen/Bearbeiten wird die Auswahl gegen die aktive Version geprüft.
- Gleiche Buildnummer und gleicher Hash: Auswahl gilt weiterhin als
  verifiziert.
- Andere Version: Name, Aktivität und Blueprint werden erneut geprüft.
- Erfolgreiche Revalidierung aktualisiert Provenienz und Anzeigesnapshot nur
  nach erfolgreichem Speichern.
- Fehlende oder inkompatible Auswahl bleibt sichtbar und blockiert nur die
  Graphberechnung beziehungsweise Zieländerung, nicht das Lesen oder
  Archivieren des Projekts.
- Es erfolgt keine automatische Umdeutung anhand des Namens.

## 10. Architektur

```text
ProjectEditorSheet
  -> ProjectLifecycleViewModel
      -> ProductionTargetSelectionManaging
          -> ItemBlueprintCatalogReading
          -> ResolveRecipeUseCase
      -> ProductionProjectLifecycleManaging
          -> ProductionProjectRepository
```

- Domain/Application importieren weder SwiftUI noch SwiftData.
- Der Katalog bleibt read-only.
- Auswahlvalidierung liegt in Application.
- Persistence speichert ausschließlich geprüfte IDs und Provenienz.
- Composition erfolgt im App-Target.
- P12 startet keine Netzwerk-, ESI- oder SDE-Updateoperation.

## 11. Fehlerabbildung

Typisierte Fälle mindestens:

- ungültige Menge,
- kein/mehr als ein aktiver Katalog,
- Item nicht gefunden,
- Item nicht veröffentlicht,
- keine unterstützte Produktionsaktivität,
- kein vollständiges Rezept,
- Blueprint gehört nicht zu Produkt/Aktivität,
- mehrere Rezepte ohne Auswahl,
- unaufgelöste Referenz,
- SDE-Version während Auswahl geändert,
- Cancellation,
- Persistenzfehler.

Benutzertexte enthalten keine Rohfehler oder lokalen Pfade. Bestehende
P10-Diagnosecodes bleiben erhalten; P12 ergänzt nur notwendige stabile
Auswahlcodes.

## 12. Tests

Mindestens:

### Domain/Application

- gültiges Fertigungs- und Reaktionsziel,
- ungültige IDs, Name, Hash, Build und Aktivität,
- Menge `1`, große gültige Ganzzahl, `0`, negativ und Überlauftext,
- normalisierte Suche und Limit/`hasMore`,
- Filter nach Aktivität, Kategorie und Gruppe,
- exakt ein Rezept,
- mehrere Rezepte mit/ohne Blueprintwahl,
- falscher Blueprint,
- kein Rezept,
- unaufgelöste Referenz und alternativer vollständiger Kandidat,
- keine/mehrere aktive Versionen,
- Versionswechsel vor Bestätigung,
- Cancellation und Repositoryfehler.

### Persistenz/Migration

- Schema-v5-Leerstore,
- v4→v5 erhält alle Bestandsprojektwerte,
- Bestandsprojekt besitzt kein erfundenes Ziel,
- neues Ziel round-tript vollständig,
- Update und Duplikat erhalten Ziel/Provenienz,
- Archiv/Wiederherstellung verändern das Ziel nicht,
- vollständige Migrationskette und zweite Storeöffnung,
- SDE- und Benutzerdaten bleiben getrennt.

### ViewModel/UI

- verzögerte, abbrechbare Suche,
- Loading-, Empty-, Treffer-, Mehrtreffer- und Errorzustände,
- Aktivitäts-/Blueprintauswahl,
- Bestandsprojekt „Ziel erneut auswählen“,
- Speichern erst nach vollständiger Validierung,
- Tastatur und Accessibility-Labels,
- Architekturtest ohne SwiftData in View/ViewModel.

### Gesamtprüfung

- SwiftPM Debug/Release,
- Xcode Debug/Release,
- Projektparität,
- echter App-Smoke-Test mit isoliertem Store aus OFF-026.

Kein Test öffnet einen produktiven Benutzerstore.

## 13. Dokumentation

Zu aktualisieren:

- Produktziel-/Auswahldokumentation,
- Datenmodell und Migration,
- Architektur und ADR,
- `CURRENT_PROJECT_STATUS.md`,
- `DEVELOPER_MENU.md`,
- `FEATURE_MATRIX.md`,
- `DEVELOPER_DIARY.md`,
- `OFFEN.md`,
- `OPEN_TASKS.md`,
- `KNOWN_ISSUES.md`,
- `TEST_HISTORY.md`,
- Abschlussbericht `YYYY-MM-DD_P12_Zielproduktauswahl.md`.

## 14. Definition of Done

P12 ist nur `✅`, wenn:

- Freitext kein fachlicher Produktschlüssel mehr ist,
- jedes neue/geänderte Ziel stabile IDs, Aktivität, Blueprint und
  Katalogprovenienz besitzt,
- Bestandsprojekte ohne erfundene Zuordnung erhalten bleiben,
- Marktgruppen nachweislich nicht unnötig importiert wurden,
- alle Auswahl-, Fehler-, Versions- und Migrationsfälle getestet sind,
- OFF-026 geschlossen und ein isolierter echter App-Start erfolgreich ist,
- SwiftPM und Xcode in Debug/Release grün sind,
- Pflichtdokumentation und Abschlussbericht aktuell sind,
- der gesonderte Review `✅ bestanden` entscheidet.

P13 darf nicht automatisch begonnen werden.
