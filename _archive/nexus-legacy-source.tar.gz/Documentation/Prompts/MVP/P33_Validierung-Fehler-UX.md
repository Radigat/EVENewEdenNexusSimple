# P33 – Appweite Validierung und Fehler-UX

Status: **✅ erledigt · 2026-07-26**

## Ziel

Die sichere P04-Fehlergrenze wird für den aktuellen Produktionsplaner-MVP
vereinheitlicht: ungültige Kerneingaben werden vor einem Schreibversuch
verständlich benannt, wiederholbare Lesevorgänge erhalten einen kontrollierten
Retry und technische Rohfehler bleiben aus UI und Diagnoseausgabe entfernt.

## Voraussetzungen

- P04: zentrale `NexusFailure`-/Logging-Grenze,
- P32: integrierter Produktionsworkspace,
- P27–P31: Preis-, Wirtschaftlichkeits- und Einkaufsworkflow,
- aktueller Schema-v20-Stand; P33 ändert kein Datenmodell.

## Umfang

1. Einen zentralen, UI-unabhängigen Validierungsvertrag mit stabilen Codes,
   Feldbezug, sicherer Meldung und Handlungshinweis ergänzen.
2. Wiederverwendbare SwiftUI-Darstellungen für Validierungszusammenfassungen
   und sichere Fehlerzustände bereitstellen.
3. Die schreibenden Kernformulare Projekt, Lager, manueller Bestand,
   Preisprofil und manueller Preis müssen fehlende oder ungültige Eingaben
   sichtbar erklären und dürfen keinen Schreibversuch starten.
4. Bereits vorhandene tabellarische Preview-before-write-Workflows behalten
   ihre fachlichen Validatoren; deren Fehler werden weiterhin sicher über die
   zentrale Fehlergrenze dargestellt.
5. Die Runtime darf ausschließlich für ausdrücklich als idempotent
   klassifizierte Lese-/Prüfoperationen einen Benutzer-Retry speichern.
6. Der Fehlerdialog zeigt bei vorhandenem sicheren Retry „Erneut versuchen“
   und sonst nur einen Schließpfad. Ein Retry wird vor Ausführung entfernt und
   kann nicht doppelt ausgelöst werden.
7. Ladefehler in den aktuellen Kernmodulen erhalten dort einen Retry, wo der
   Vorgang keine Daten schreibt.
8. Diagnosecode, Redaction und genau ein Logereignis je gemeldetem Fehler
   bleiben erhalten.

## Validierungsregeln

- Leerer Pflichttext: `NEN-VAL-001`,
- fehlende Auswahl: `NEN-VAL-002`,
- ungültige positive Ganzzahl: `NEN-VAL-003`,
- ungültiger Geldbetrag: `NEN-VAL-004`,
- ungültiger Datumsbereich: `NEN-VAL-005`,
- nicht mehr aktuelle Vorschau oder Auswahl: `NEN-VAL-006`.

Validierungstexte enthalten niemals den eingegebenen Rohwert. Fachliche
Services bleiben die letzte Autorität; UI-Validierung ist eine frühzeitige,
seiteneffektfreie Rückmeldung und ersetzt keine Domänenprüfung.

## Retry-Regeln

Erlaubt sind nur idempotente Lese-, Suche-, Inspect- oder Previewvorgänge.
Speichern, Import-Apply, Aktivierung, Restore, Löschung und andere potenziell
schreibende Vorgänge werden nie automatisch wiederholt. Ein Retry beginnt erst
nach einer erneuten Benutzeraktion.

## Nicht-Ziele

- keine Schemaänderung und keine Migration,
- kein automatisches Netzwerk-Retryprogramm,
- keine Änderung an SSO/ESI-Zukunftscode,
- keine vollständige Lokalisierung oder manuelle VoiceOver-Abnahme (P35),
- kein Recovery-/Prozessabbruchdrill (P36),
- keine mechanische Großdateiaufteilung (P34).

## Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| KI-007/P33 | Verbleibende appweite Fehler-UX nach der P04-Grundlage harmonisieren. | Quellcodeaudit, Runtime-/Redaction-/Validierungstests und UI-Architekturtest |

Andere aktive Punkte aus `OFFEN.md` blockieren P33 nicht und bleiben ihren
Zielprompts zugeordnet.

## Tests

- stabile Validierungscodes und keine Rohwerte in Meldungen,
- Pflichttext, Auswahl, positive Ganzzahl, Geldbetrag und Datumsbereich,
- Retry nur für freigegebene Operationen,
- Retry wird genau einmal ausgeführt und vor Ausführung entfernt,
- Schreiboperation verwirft einen übergebenen Retry,
- Cancellation erzeugt keinen zusätzlichen Fehler,
- bestehende Redaction- und Operations-Mappingtests,
- statischer Nachweis der Validierungsdarstellung in den Kernformularen,
- vollständiger SwiftPM-Debuglauf,
- Xcode Debug wegen App-/UI-Änderungen.

## Abnahme

P33 ist nur `✅`, wenn die genannten Kernformulare verständliche
Validierungsgründe zeigen, sichere Lese-Retries funktionieren, Schreib-Retries
blockiert sind, keine Rohfehlermeldung neu exponiert wird, fokussierte und
vollständige Tests bestehen, Xcode/SwiftPM-Parität erhalten bleibt und Review
sowie Abschlussbericht vorliegen.
