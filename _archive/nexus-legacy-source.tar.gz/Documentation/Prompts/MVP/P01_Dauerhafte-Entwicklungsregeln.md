# P01 – Dauerhafte Entwicklungsregeln

Status: **✅ erledigt**

## Zweck

Verbindliche, repositoryweite Regeln für Scope, Arbeitsweise, Architektur, Berechnungen, Datenintegrität, UI, Performance, Sicherheit, Git, Build, Tests, Dokumentation, Definition of Done und Review einrichten. Keine fachliche App-Funktion implementieren.

## Voraussetzungen

- P00 abgeschlossen,
- Projektbuch einschließlich Anhänge analysiert,
- P00-Dokumentation, Quellcode und Git-Zustand geprüft,
- vorhandene `AGENTS.md` kontrolliert zusammengeführt.

## Verbindlicher Arbeitsauftrag

1. `AGENTS.md` im Projektstamm mit den dauerhaften Regeln vollständig erstellen.
2. vorhandene Regeln erhalten oder begründet zusammenführen.
3. `Documentation/REVIEW_RULES.md` als ausführliche, unabhängige Review-Checkliste erstellen.
4. Entwickler-Menü, Projektstatus, Tagebuch und Prompt-Register aktualisieren.
5. Pfade, Widersprüche, Benutzeränderungen, Build und Tests prüfen.
6. separaten Review- und Kontrollschritt durchführen.
7. Abschlussbericht `Documentation/Progress/Reports/2026-07-23_P01_Dauerhafte-Entwicklungsregeln.md` erstellen.

## Abnahmekriterien

- `AGENTS.md` liegt vollständig im Projektstamm,
- `Documentation/REVIEW_RULES.md` ist vollständig,
- bisherige Regeln wurden analysiert und kontrolliert zusammengeführt,
- geforderte Übersichten sind konsistent aktualisiert,
- keine fachliche App-Funktion und keine Benutzeränderung wurde verändert,
- Review, Build und Tests sind mit echtem Ergebnis dokumentiert,
- Abschlussbericht ist gespeichert.

## Erwartetes Ergebnis

Alle Folgeprompts verfügen über einen verbindlichen Arbeits-, Qualitäts- und Reviewrahmen. P01 wird nur bei erfüllten Abnahmekriterien auf `✅ erledigt` gesetzt.
