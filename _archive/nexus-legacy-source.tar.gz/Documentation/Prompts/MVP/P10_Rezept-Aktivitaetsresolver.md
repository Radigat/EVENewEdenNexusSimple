# P10 – Rezept- und Aktivitätsresolver

Status: **✅ erledigt – 2026-07-23**

## 1. Zweck

Löse Fertigungs- und Reaktionsrezepte aus genau einer aktiven SDE-Version
deterministisch über eine UI- und SwiftData-freie Application-Schnittstelle
auf. Fehlende, mehrdeutige oder unvollständige Rezepte müssen als
strukturierte Fachdiagnose sichtbar werden und dürfen niemals stillschweigend
zu einer scheinbar vollständigen Materialliste führen.

## 2. Voraussetzungen

- P07C ist in der verbindlichen Prompt-Reihenfolge abgeschlossen.
- P08/P09-Katalog, Schema v3/v4 und aktive Versionsisolation sind grün.
- Der tatsächliche Quellcode und der dann aktive SDE-Build werden vor
  Implementierung erneut geprüft.
- Es wird keine Graph-, Runs-, ME-, T1-/T2-Ketten- oder
  Inventionswahrscheinlichkeitslogik aus P13–P19 vorgezogen.

## 3. Mit zu erledigende offene Punkte

| ID | Restarbeit | Prüfnachweis |
|---|---|---|
| OFF-003 / KI-004 | Deterministischen Rezept-/Aktivitätsresolver über dem aktiven Katalog implementieren. | Application-Vertrags-, Adapter-, Versions- und Referenztests |
| OFF-016 / KI-016 | Jede nicht aufgelöste Material- oder Produktreferenz itemgenau diagnostizieren und das betroffene Rezept vollständig ablehnen. | synthetische Einzeltests und Real-SDE-Abnahme des aktuellen Builds |

## 4. Verbindlicher Fachumfang

Der Resolver erhält mindestens:

- Produkt-Type-ID,
- gewünschte Produktionsaktivität,
- optional eine ausdrücklich gewählte Blueprint-Type-ID.

Im aktuellen MVP sind `manufacturing` und `reaction` als
materialverbrauchende Produktionsrezepte auflösbar. `copying`,
`research_material` und `research_time` sind keine Produktrezepte.
`invention` bleibt als Katalogaktivität erhalten, wird in P10 aber nicht als
deterministisches Materialproduktionsrezept oder erwarteter
Wahrscheinlichkeitswert interpretiert.

Ein erfolgreiches Ergebnis enthält mindestens:

- aktive SDE-Buildnummer und Inhaltshash,
- Blueprint-Type-ID,
- Aktivität,
- Produkt-Type-ID und Outputmenge je Lauf,
- Aktivitätszeit,
- optionales Produktionslimit,
- vollständig aufgelöste Materialzeilen mit Type-ID, Menge,
  Verbrauchsart und stabiler Reihenfolge.

P10 berechnet noch keine Runs, keine ME-Rundung, keine rekursive Kette und
keine Kosten.

## 5. Auswahl- und Mehrdeutigkeitsregeln

1. Nur die eine aktive SDE-Version darf gelesen werden.
2. Mit expliziter Blueprint-ID muss genau dieses Blueprint zur angefragten
   Produkt-/Aktivitätskombination passen.
3. Ohne Blueprint-ID:
   - genau ein vollständiger Kandidat: auflösen,
   - kein Kandidat: typisiertes `recipeNotFound`,
   - mehrere Kandidaten: typisiertes `ambiguousRecipe` mit stabil sortierten
     Kandidaten-IDs.
4. Der Resolver erfindet keine Prioritätsregel und wählt bei Mehrdeutigkeit
   nicht automatisch den kleinsten, ersten oder veröffentlichten Kandidaten.
5. Unveröffentlichte beziehungsweise fachlich unzulässige Datensätze werden
   nach einer explizit dokumentierten Regel behandelt; die Regel ist vor der
   Implementierung gegen Katalogdaten und Projektbuch zu belegen.

## 6. Nicht aufgelöste Referenzen

Besitzt die ausgewählte Aktivität mindestens eine Material- oder Produktzeile
mit `typeIsResolved == false`, gilt das gesamte Rezept als unvollständig.

Die Diagnose enthält ohne private Daten mindestens:

- SDE-Version,
- Blueprint-Type-ID,
- Aktivität,
- Rolle `material` oder `product`,
- fehlende Type-ID,
- sichere zentrale Diagnosekennung.

Es ist verboten:

- einen Platzhaltertyp zu erfinden,
- die Zeile zu ignorieren,
- eine Menge von null anzunehmen,
- Daten aus einem anderen SDE-Build beizumischen,
- nur eine Warnung auszugeben und trotzdem ein berechenbares Rezept
  zurückzugeben.

Die in Build 3444265 beobachteten 21 Referenzlücken sind eine bekannte
Ausgangsbasis, keine für alle künftigen Builds festgeschriebene Sollzahl. Bei
der P10-Abnahme wird der dann aktuelle offizielle Build erneut gezählt. Jede
Abweichung wird dokumentiert; betroffenes Rezept bleibt blockiert, während
vollständige unabhängige Rezepte weiterhin nutzbar sind.

## 7. Architektur

- Domain/Application importieren weder SwiftUI noch SwiftData.
- Ein klarer Leseport liefert vollständige Rezeptkandidaten aus Persistence.
- Fachliche Auswahl und Fehlerklassifikation liegen zentral in einem
  Application- oder Domainservice, nicht im SwiftData-Adapter und nicht in
  Views.
- DTOs sind `Sendable`, stark typisiert, stabil sortiert und für feste
  Eingaben deterministisch.
- Abbruch wird erhalten; Persistenzfehler werden über die zentrale
  Fehlergrenze ohne Rohpfade abgebildet.

## 8. Tests

Mindestens:

- eindeutiges Fertigungsrezept,
- eindeutiges Reaktionsrezept,
- explizit ausgewähltes passendes Blueprint,
- explizit ausgewähltes falsches Blueprint,
- kein Rezept,
- mehrere Rezepte ohne Auswahl,
- nicht produktive Aktivitätsarten,
- leere Materialien, sofern in den Daten fachlich zulässig beziehungsweise
  unzulässig,
- nicht aufgelöste Materialreferenz,
- nicht aufgelöste Produktreferenz,
- mehrere nicht aufgelöste Referenzen in stabiler Diagnosefolge,
- inaktiver alter Build darf nie beigemischt werden,
- keine, genau eine und mehrere aktive SDE-Versionen,
- Cancellation und Persistenzfehler,
- Wiederholbarkeit und stabile Reihenfolge.

Zusätzlich:

- synthetisches Referenzfixture mit festen Sollwerten,
- aktueller offizieller SDE-Lauf über einen isolierten Store,
- itemgenauer Nachweis, dass alle aktuell vorhandenen Referenzlücken die
  betroffenen Rezepte blockieren,
- Kontrollnachweis mindestens eines vollständigen Fertigungs- und
  Reaktionsrezepts,
- vollständiger SwiftPM- und Xcode-Debug-/Release-Testlauf.

Der offizielle Lauf verwendet keinen produktiven Benutzerstore und speichert
kein SDE-Großartefakt im Repository.

## 9. Dokumentation

Aktualisiere:

- Fachdokumentation für Rezeptauflösung und Diagnose,
- relevante Architektur-/Datenkatalogdokumentation,
- `Documentation/CURRENT_PROJECT_STATUS.md`,
- `Documentation/DEVELOPER_MENU.md`,
- `Documentation/FEATURE_MATRIX.md`,
- `Documentation/DEVELOPER_DIARY.md`,
- `Documentation/OFFEN.md`,
- `Documentation/OPEN_TASKS.md`,
- `Documentation/KNOWN_ISSUES.md`,
- `Documentation/TEST_HISTORY.md`,
- bei einer Architekturentscheidung ADR/Architekturänderungen,
- Abschlussbericht
  `YYYY-MM-DD_P10_Rezept-Aktivitaetsresolver.md`.

## 10. Definition of Done

P10 ist nur `✅`, wenn eindeutige Fertigungs- und Reaktionsrezepte
deterministisch vollständig aufgelöst werden, fehlende/mehrdeutige und jede
unvollständige Referenz sicher blockieren, der aktuelle Real-SDE-Nachweis
itemgenau dokumentiert ist, keine spätere Berechnungslogik vorgezogen wurde,
SwiftPM und Xcode in Debug/Release grün sind und der gesonderte Review
bestanden ist.

P11 darf nicht automatisch begonnen werden.

## 11. Abschlussnachweis

- `ResolveRecipeUseCase` und versionsisolierter SwiftData-Adapter umgesetzt,
- neun Application- und fünf Persistence-Resolvertests bestanden,
- Xcode und SwiftPM jeweils Debug/Release mit 181 Tests bestanden,
- offizieller Build 3444265: Fertigung und Reaktion aufgelöst, alle 21
  Referenzlücken itemgenau blockiert,
- `OFF-003`, `OFF-016`, `KI-004` und `KI-016` geschlossen,
- Reviewentscheidung: `✅ bestanden`,
- [Abschlussbericht](../../Progress/Reports/2026-07-23_P10_Rezept-Aktivitaetsresolver.md).
