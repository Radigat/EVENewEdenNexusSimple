# P21 – CSV-Bestandsimport

Status: **Entwurf – ⬜ offen**

- **Zweck:** Bestände kontrolliert aus CSV übernehmen.
- **Voraussetzungen:** P05, P20.
- **Erwartetes Ergebnis:** Mapping, Vorschau, Validierung, atomare Übernahme und Importbericht.
- **Vor Ausführung ergänzen:** CSV-Schema, Locale/Encoding, Duplikate und Fehlerfixtures.
