# Prompt-Register P00–P61

Stand: 2026-07-29
Statuswerte: ⬜ offen · 🔄 in Bearbeitung · ⚠️ teilweise/blockiert · ✅ erledigt · ⏸️ verschoben · ❌ fehlgeschlagen

P00 bis P22 sowie P07A/P07B/P07C sind vollständig ausgeführt und reviewed.
P09B hat den zuvor fehlenden manuellen P07C-GUI-/Accessibility-Nachweis
geschlossen. Das
Audit AUD-SDE-001 hat die ergänzenden Pflichtpakete P07A bis P07C
aufgenommen. Da P07C bereits ausgeführt wird, ergänzt PLAN-001 direkt danach
die vollständig spezifizierten Zwischenprompts P09A für die erste
Git-Baseline und P09B für das eigenständige Xcode-Projekt. P10 hat die
bekannten offiziellen Referenzlücken sicher behandelt. P11 hat den lokalen
Projektlebenszyklus umgesetzt. P12 hat die kataloggebundene
Zielproduktauswahl einschließlich Schema v5 umgesetzt. P13 ergänzt den
erklärbaren, persistierten Produktionsgraphen und Schema v6. P14 ergänzt
integer-sichere Runs, Graphformat 2 und Schema v7. P15 ergänzt die
referenzgeprüfte Blueprint-ME-Berechnung, Graphformat 3 und Schema v8.
P17 bis P26 sowie P32 und P37 sind vollständig umgesetzt und reviewed. Ihre
gemeinsame fachliche Grundlage steht in
[`INDUSTRY_RULES_FOUNDATION.md`](../INDUSTRY_RULES_FOUNDATION.md). Die frühere
pauschale Entwurfsgrenze P24–P47 ist damit überholt: P27–P31 und P33
wurden nach dem tokenarmen Kern-MVP reaktiviert und erledigt; P34 wurde
anschließend ebenfalls reaktiviert und erledigt. P35 ist einschließlich
OFF-030 abgenommen. P36 ist einschließlich OFF-006 und fünf realen
OFF-024-Prozessabbruch-/Neustarts erledigt. PLAN-002 ist mit der internen
P37-Kernabnahme abgeschlossen. REL-001 hat die aktuelle technische
Release-/Complianceprüfung ausgeführt und OFF-031 geschlossen. PLAN-003
setzt lokale Eigennutzung als verbindliches Betriebsziel. OFF-020/OFF-032
sind keine lokalen Blocker und gehören ausschließlich zu P48, dem letzten
optionalen Zukunftspaket nach P47. Eine vollständige Spezifikation ist noch
kein Implementierungsnachweis. PLAN-004 legt P38 bis P48 in dieser
Reihenfolge fest. P38/P39/P41 sind abgeschlossen; P40 ist technisch
umgesetzt. Die sichtbare P42-Projektfinanzoberfläche wurde mit P55 bewusst
zurückgezogen, während ihre gespeicherten Daten erhalten bleiben. PLAN-005
ordnet deren Korrektur und Betriebsabnahme als
**P50 → P51 → P52 → P53 → P54**. P49 bleibt bewusst unbelegt. P50 und P51
sind abgeschlossen. P52 wurde mit den exakt dokumentierten
P42-Projektzuordnungsgates als Restblocker beendet. P53 ist nach
bestätigter recoverbarer Archivierung, Kanon-, Link-, Build- und
Testprüfung abgeschlossen. P55 und P56 sind technisch umgesetzt; OFF-054 ist
inzwischen im Eigentümerbetrieb bestanden. OFF-058 hält den getrennten
Preisübernahme-/Budgetbefund für P58 fest. PLAN-006 spezifiziert den aus der
Eigentümer-Arbeitsmappe abgeleiteten Ausbau als P57 bis P61, ohne private
Arbeitsmappendaten zu importieren oder Implementierung vorwegzunehmen. P57
beginnt nur auf ausdrücklichen Auftrag. P54 bleibt gesondert
commit-freigabepflichtig. P43–P48 bleiben unverändert zurückgestellt
beziehungsweise optional.

## Grundlagen

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P00 | Entwickler-Cockpit | Dokumentation, Scope und Fortschrittssteuerung einrichten | keine | belegbarer Ist-Stand, Register, Build/Test und Bericht | ✅ erledigt | [P00](MVP/P00_Entwickler-Cockpit.md) |
| P01 | Dauerhafte Entwicklungsregeln | verbindliche Arbeits-, Qualitäts- und Reviewregeln einrichten | P00 | vollständige `AGENTS.md`, Reviewregeln und geprüfte Dokumentationssteuerung | ✅ erledigt | [P01](MVP/P01_Dauerhafte-Entwicklungsregeln.md) |
| P02 | Zielarchitektur und Modulgrenzen | fachlichen Kern von UI, Persistenz und Adaptern trennen | P01 | kompilierbare Modulgrenzen, ADRs, Architektur- und Paritätstests | ✅ erledigt | [P02](MVP/P02_Zielarchitektur.md) |
| P03 | Domänenmodell und Migrationen | versionierbares MVP-Datenmodell festlegen | P02 | Schema v1, Legacy-Migration, Persistence-Target und Repository | ✅ erledigt | [P03](MVP/P03_Domaenenmodell-Migrationen.md) |

## Technisches Fundament

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P04 | Fehlerbehandlung und Logging | zentrale, datenschutzgerechte Diagnose | P02/P03 | Error-Taxonomie, Logger, UI-Fehlerfluss und Offene-Punkte-Audit | ✅ erledigt | [P04](MVP/P04_Fehlerbehandlung-Logging.md) |
| P05 | Testfundament und Referenzdaten | reproduzierbare Unit-/Integrationsprüfungen | P01–P04 | versionierte synthetische Fixtures, Testhelfer und CI-fähige Basis | ✅ erledigt | [P05](MVP/P05_Testfundament.md) |
| P06 | Lokale Backups | Sicherung und Restore definieren | P03–P05 | versioniertes Backupformat und geprüfter Restore | ✅ erledigt | [P06](MVP/P06_Backups.md) |
| P07 | SDE-Importpipeline | statische EVE-Daten offline importieren | P02–P06 | wiederholbarer, validierter JSONL-Stagingimport | ✅ erledigt | [P07](MVP/P07_SDE-Importpipeline.md) |
| P08 | Statisches Datenschema | Items, Gruppen, Kategorien und Aktivitäten speichern | P07 | indizierte, versionierte Stammdaten | ✅ erledigt | [P08](MVP/P08_Statisches-Datenschema.md) |
| P09 | Item- und Blueprintkatalog | Produktauswahl und Rezeptzugriff bereitstellen | P08 | durchsuchbarer lokaler Katalog | ✅ erledigt | [P09](MVP/P09_Item-Blueprintkatalog.md) |
| P09A | Repository-Baseline und Git-Nachvollziehbarkeit | den geprüften Ist-Stand als ersten Projekt-Commit sichern | P07C, P09, P07A–P07B | reviewbare Baseline ohne Push oder Eingriff in andere Repositories | ✅ erledigt | [P09A](MVP/P09A_Repository-Baseline-Git-Historie.md) |
| P09B | Eigenständiges Xcode-Projekt und gemeinsame Schemes | native App, Module, Runner und Tests für Xcode reproduzierbar beschreiben | P09A | versioniertes `.xcodeproj`, gemeinsame Schemes und grüne Xcode-/SwiftPM-Builds | ✅ erledigt | [P09B](MVP/P09B_Xcode-Projekt-Schemes.md) |
| P07A | Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance | lokale und offizielle Buildstände cachekonform vergleichen | P04, P07–P09 | gespeicherter, gedrosselter Updatecheck und Schema-Gate | ✅ erledigt | [P07A](MVP/P07A_SDE-Metadaten-HTTP-Cache-Compliance.md) |
| P07B | Sicherer SDE-Download, Archivprüfung und Aktivierung | offiziellen JSONL-Build crashfest herunterladen und aktivieren | P06–P09, P07A | ZIP-sicherer blockweiser Import, Rollback und Updateprotokoll | ✅ erledigt | [P07B](MVP/P07B_SDE-Download-Archiv-Aktivierung.md) |
| P07C | SDE-Einstellungen, Automatisierung und Recht | Updatepfad produktiv verdrahtet, transparent, gedrosselt und rechtlich gekennzeichnet bedienen | P07A–P07B | produktiver Start-/Installationspfad, SDE-Settings, 24-h-Policy, Protokoll, Diagnoseexport und Rechtsbereich | ✅ erledigt | [P07C](MVP/P07C_SDE-Einstellungen-Automation-Recht.md) |
| P10 | Rezept- und Aktivitätsresolver | Produktion und Reaktionen einheitlich auflösen und unvollständige Referenzen sicher blockieren | P07C, P09B, P08–P09 | deterministische vollständige Rezeptabfrage mit itemgenauer Diagnose | ✅ erledigt | [P10](MVP/P10_Rezept-Aktivitaetsresolver.md) |

## Produktionsplaner MVP

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P11 | Projektlebenszyklus | Projekte anlegen, bearbeiten, duplizieren und archivieren | P03, P09 | vollständiger lokaler Projektworkflow | ✅ erledigt | [P11](MVP/P11_Projektlebenszyklus.md) |
| P12 | Zielproduktauswahl | Kataloggestützte Produkt-, Aktivitäts-, Blueprint- und Mengenauswahl | P09–P11; OFF-026 erledigt | validiertes, versionsgebundenes Produktionsziel und additive v5-Migration | ✅ erledigt | [P12](MVP/P12_Zielproduktauswahl.md) |
| P13 | Produktionsgraph | gerichteten, erklärbaren Graphen modellieren | P10–P12; OFF-004/OFF-006 | persistierbarer Graph mit Knoten/Kanten und Schema v6 | ✅ erledigt | [P13](MVP/P13_Produktionsgraph.md) |
| P14 | Runs und Ausgabemengen | Runs und tatsächliche Outputs ohne unbelegte Job-Batches korrekt berechnen | P10, P13; OFF-004/OFF-006/OFF-009 | getestete Ganzzahl-/Overflowlogik, Graphformat 2 und Schema v7 | ✅ erledigt | [P14](MVP/P14_Runs-Ausgabemengen.md) |
| P15 | Material Efficiency | EVE-ME-Regeln und Rundung abbilden | P14; OFF-004/OFF-006/OFF-009 | referenzgetestete Materialmengen, Graphformat 3 und Schema v8 | ✅ erledigt | [P15](MVP/P15_Material-Efficiency.md) |
| P16 | T1-Berechnung | mehrstufige Manufacturing-only-T1-Ketten rekursiv auflösen | P13–P15; OFF-004/OFF-009/OFF-021 | Graphformat 4 mit Runs, ME-Provenienz, Blattgründen und Bestandsschutz | ✅ erledigt | [P16](MVP/P16_T1-Berechnung.md) |
| P17 | T2-Berechnung | T2 klassifizieren, Blueprintqualität validieren und T2-Manufacturing-Ketten auflösen | P10, P12–P16; OFF-004/OFF-021/OFF-028 | versionierte T2-Kette mit Invention-, Decryptor- und Qualitätsprovenienz; Reaktionsgrenzen bleiben sichtbar | ✅ erledigt | [P17](MVP/P17_T2-Berechnung.md) |
| P18 | Reaktionsstufen | notwendige Reaktionen mit verifiziertem Produktionskontext in den Graph integrieren | P10, P13–P17; OFF-004/OFF-021/OFF-028 | rekursive Reaktionsknoten mit neutraler oder Facility-/Rig-/Security-/Skill-modifizierter Material- und Zeitprovenienz | ✅ erledigt | [P18](MVP/P18_Reaktionsstufen.md) |
| P19 | Aggregation und Graphschutz | gleiche Materialien nach Type-ID vereinen und Graph-/Summengrenzen erzwingen | P16–P18; OFF-004/OFF-009 | Graphformat 7 mit Formelversion 1, Erklärpfaden und typisierten Diagnosen | ✅ erledigt | [P19](MVP/P19_Aggregation-Graphschutz.md) |
| P20 | Lager und manuelle Bestände | Lagerorte und kataloggebundene Mengen lokal verwalten | P03, P04–P06, P09, P19; OFF-005/KI-005 | Schema v10, persistente Lagerbestände, Archivierung und bestätigtes Löschen | ✅ erledigt | [P20](MVP/P20_Lager-Manuelle-Bestaende.md) |
| P21 | CSV-Bestandsimport | Bestände sicher importieren | P05, P20; OFF-005/OFF-006 | Schema v11, validierter Preview-before-write-Import, Einzelkonflikte und atomarer Detailbericht | ✅ erledigt | [P21](MVP/P21_CSV-Bestandsimport.md) |
| P22 | Verfügbarkeit und Ausschlüsse | verfügbare Mengen je Filter berechnen | P19–P21; OFF-005/OFF-006 | Schema v12, projektbezogene Preview-before-write-Regeln und nachvollziehbarer Bestandsabgleich | ✅ erledigt | [P22](MVP/P22_Verfuegbarkeit-Ausschluesse.md) |
| P23 | Sicherheitsbestände | globale Sicherheitsmenge schützen und Mindest-, Warn- und Zielschwellen erklären | P22; OFF-005/OFF-006 | Schema v13, Preview-before-write-Regeln, Schutzberechnung und Warnungen | ✅ erledigt | [P23](MVP/P23_Sicherheitsbestaende.md) |
| P24 | Projektreservierungen | Material projektbezogen reservieren/freigeben | P11, P22–P23; OFF-005/OFF-006 | globale Type-ID-Bindungen, Preview-before-write, Schema v14 und Archivschutz | ✅ erledigt | [P24](MVP/P24_Projektreservierungen.md) |
| P25 | Reservierungskonflikte | konkurrierende und verwaiste Bindungen erkennen und kontrolliert auflösen | P24; OFF-005/KI-005 | berechneter Konfliktstatus, Prioritätsvorschlag und bestätigte atomare Reduktion/Freigabe | ✅ erledigt | [P25](MVP/P25_Reservierungskonflikte.md) |
| P26 | Schlanker Produktionsentscheidungsplan | Bestand, Bauen/Kaufen, Produktions-/Inventionsjobs und Fehlmengen verbinden | P17–P25 | persistente manuelle Entscheidung und reproduzierbarer Kernplan | ✅ erledigt | [P26](MVP/P26_Build-or-Buy.md) |
| P27 | Manuelle Preise und Profile | lokale Preisquellen verwalten | P03, P09, P37 | wiederverwendbare, exakte ISK-Preisprofile | ✅ erledigt | [P27](MVP/P27_Manuelle-Preise-Profile.md) |
| P28 | CSV-Preisimport | Preislisten mit Vorschau importieren | P05, P27 | validierte, bestätigte und protokollierte Preisübernahme | ✅ erledigt | [P28](MVP/P28_CSV-Preisimport.md) |
| P29 | Kosten, Gewinn und ROI | Projektwirtschaftlichkeit berechnen | P26–P28 | Kosten, Erlös, Gewinn, Marge, ROI, Break-even | ✅ erledigt | [P29](MVP/P29_Kosten-Gewinn-ROI.md) |
| P30 | Erweiterte Einkaufslisten-Aggregation | persistente Overrides und erweiterte Fehlmengen behandeln | P26, P29; OFF-011 | Type-ID-Liste, editierbare Zielmenge, Schema v19 | ✅ erledigt | [P30](MVP/P30_Einkaufslisten-Aggregation.md) |
| P31 | Einkaufsworkflow und Export | Teilkäufe, gekauft, Text und CSV ohne Reimport-Schreibpfad | P30; OFF-011 | vollständiger projektübergreifender Beschaffungsworkflow, Schema v20 | ✅ erledigt | [P31](MVP/P31_Einkaufsworkflow-Export.md) |
| P32 | Integrierter Kernworkspace | Produkt, Graph, Lager, Entscheidungen, Jobs und Fehlmengen verbinden | P11–P26 | nutzbarer Produktions-/Inventionskern | ✅ erledigt | [P32](MVP/P32_Integrierter-Produktionsworkspace.md) |

## Qualität und Release

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P33 | Appweite Validierung und Fehler-UX | sichere Kernvalidierung und kontrollierte Lese-Retries | P04, P32 | stabile Codes, Inline-UX und Schreib-Retry-Sperre | ✅ erledigt | [P33](MVP/P33_Validierung-Fehler-UX.md) |
| P34 | Performance und große Graphen | realistische Datenmengen flüssig verarbeiten | P32–P33 | begrenzte Großgraphenprojektion, Benchmarks und definierte Budgets | ✅ erledigt | [P34](MVP/P34_Performance-Grosse-Graphen.md) |
| P35 | Accessibility- und UX-Politur | Kern-App adaptiv und semantisch härten | P32–P34 | Suche, Fokus, Kontrast, responsive Layouts und natives UI-Testgate | ✅ erledigt | [P35](MVP/P35_Accessibility-UX.md) |
| P36 | Migration und Recovery-Drill | Upgrade, Backup, Restore und reale SDE-Prozessgrenzen end-to-end prüfen | P03, P06, P07B, P32 | Release-Recovery-Nachweis | ✅ erledigt | [P36](MVP/P36_Migration-Recovery-Drill.md) |
| P37 | Interne Kernabnahme | T1 und T2/Invention mit Lager end-to-end nachweisen | P26, P32 | intern nutzbarer Kernstand, kein Release Candidate | ✅ erledigt | [P37](MVP/P37_MVP-Abnahme-Release.md) |
| REL-001 | Öffentliche Release-/Complianceprüfung | aktuellen CCP-/Apple-/Build-/UI-Stand prüfen, ohne zu veröffentlichen | P36, P37; OFF-020/OFF-031 | belastbarer technischer Befund und getrennte optionale Distributionspunkte | ✅ Prüfung erledigt | [REL-001](MVP/REL-001_Oeffentliche-Release-Compliance.md) |

## ESI-Erweiterung

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P38 | SSO-Härtung | vorhandenes SSO an Zielarchitektur anpassen | P37, PLAN-004 | sicherer, getesteter lokaler Auth-Adapter | ✅ erledigt | [P38](Future/P38_SSO-Haertung.md) |
| P39 | ESI-Infrastruktur und Charaktere | Caching, Limits, Refresh und Charaktere | P38 | robuste persönliche ESI-Basis | ✅ erledigt | [P39](Future/P39_ESI-Infrastruktur-Charaktere.md) |
| P40 | Live-Assets, Blueprints und Jobs | persönliche Daten nach Differenzvorschau synchronisieren | P39 | getrennte, versionierte Offline-Snapshots | ✅ erledigt | [P40](Future/P40_Live-Assets-Blueprints-Jobs.md) |

## Märkte und Finanzen

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P41 | Live-Marktpreise | öffentliche ESI-Orders als optionale Materialpreisquelle | P40; Nutzenreview und Auftrag ✅ | bestätigungsgebundene, mengenbezogene Beschaffungspreise mit Cache/Offline-Fallback | ✅ erledigt | [P41](Future/P41_Live-Marktpreise.md) |
| P42 | Wallet und reale Projektfinanzen | persönliche Read-Daten nach Vorschau manuell Projekten zuordnen | P40–P41; Nutzenreview und Ausführungsauftrag ✅ | historische Wallet-Snapshots und Zuordnungen bleiben erhalten | ⏸️ sichtbare Projektfinanzoberfläche durch P55 zurückgezogen | [P42](Future/P42_Wallet-Projektfinanzen.md) |

## Erweiterte Industrie

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P43 | Vollständiges Reaktionsmanagement | Slots, Kalender, Puffer und Standorte | P42; Nutzenreview ✅ | derzeit kein eigenständiger Workflow; reduzierte Reaktivierungsgrenze dokumentiert | ⏸️ Review abgeschlossen, Umsetzung zurückgestellt | [P43](Future/P43_Reaktionsmanagement.md) |
| P44 | PI, Logistik und Kapazität | Nutzen von Kolonien, Transporten, Kalender und Slots prüfen | P43-Nutzenreview, P40 | derzeit kein Gesamtworkflow; drei bedarfsgesteuerte Reaktivierungsgrenzen dokumentiert | ⏸️ Review abgeschlossen, Umsetzung zurückgestellt | [P44](Future/P44_PI-Logistik-Kapazitaet.md) |

## Corporation und Zukunft

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P45 | Corporation Edition | gemeinsame Daten, Rollen und Rechte | P40–P44 | abgesicherte Corporation-Arbeitsbereiche | ⏸️ verschoben | [P45](Future/P45_Corporation-Edition.md) |
| P46 | Cloud und Mehrbenutzerbetrieb | optionale Synchronisation/Konfliktlösung | P45 | belastbares Mehrgeräte-/Mehrbenutzermodell | ⏸️ verschoben | [P46](Future/P46_Cloud-Mehrbenutzer.md) |
| P47 | Optimierung, KI und Plattformzukunft | Solver, Assistenz und spätere Erweiterungspunkte | P46; Abweichung nur ausdrücklich | erklärbare, optionale Zukunftsarchitektur | ⏸️ verschoben | [P47](Future/P47_Optimierung-KI-Plattform.md) |
| P48 | Optionale öffentliche macOS-/App-Store-Distribution | erst ganz am Ende einen Verteilungsweg wählen und absichern | P47; ausdrückliche Aktivierung; OFF-020/OFF-032 | optionales Store-/Signing-/Notarisierungs- und Distributionspaket | ⏸️ optional verschoben | [P48](Future/P48_Optionale-Apple-Distribution.md) |

## Korrektur und Betriebsabnahme

| ID | Titel | Ziel | Abhängigkeiten | Erwartetes Ergebnis | Status | Promptdatei |
|---|---|---|---|---|---|---|
| P50 | P40-Restabnahme persönliche ESI-Daten | private Snapshots detailliert nutzbar machen und Assets kontrolliert als optionale Verfügbarkeitsquelle anbinden | P40; OFF-035/KI-038 | prüfbare Asset-/Blueprint-/Job-Ansichten und Preview-before-write ohne automatische Vermischung | ✅ erledigt | [P50](Future/P50_P40-Restabnahme-Persoenliche-ESI-Daten.md) |
| P51 | P42-Korrektur Scope, Fehler, Plan/Ist | Fehlerrouting, Scope-Minimierung und sichtbaren Plan-/Ist-Vergleich korrigieren; P52-Refreshbefund nachkorrigieren | P50; OFF-036/KI-039/KI-040; OFF-040/KI-043 | sichere Operationen, RFC-konformer Refresh, transparente Zustimmungen und vollständiger Seitenvergleich | ✅ einschließlich Eigentümer-Livenachweis erledigt | [P51](Future/P51_P42-Korrektur-Scope-Fehler-Plan-Ist.md) |
| P52 | P40–P42 Eigentümer-Betriebsabnahme | persönliche und öffentliche Livepfade real und kontrolliert prüfen | P51 einschließlich OFF-040; OFF-037 | bestätigte P40/P41/P42-Läufe mit Preview, Offline und Neustart | ⚠️ mit P42-Projektzuordnungs-/Endgates als dokumentiertem Restblocker beendet | [P52](Future/P52_P40-P42-Eigentuemer-Betriebsabnahme.md) |
| P53 | Steuerung und Xcode-Kanon | Status, sichtbare Scope-Texte und Projekt-/Promptkanon widerspruchsfrei machen | P52; OFF-038/KI-041 | geprüfte Links, ein dokumentierter Kanon und bestätigte Dateibehandlung | ✅ erledigt | [P53](Future/P53_Steuerung-und-Xcode-Kanon-Bereinigung.md) |
| P54 | Lokaler Git-Sicherungspunkt | vollständig geprüften Stand lokal versionieren | P53; OFF-039/KI-042; gesonderte Commit-Freigabe | reviewbarer lokaler Commit ohne Push | ⬜ wartet auf gesonderte Commit-Freigabe | [P54](Future/P54_Gepruefter-lokaler-Git-Sicherungspunkt.md) |
| P55 | Projektbudgetplanung | benötigtes Budget aus wirksamer Einkaufsliste, Logistik und Produktion planen | P26/P30/P31/P41; Eigentümer-Neuspezifikation | getrennte, speicherbare Budgetbasis ohne Vermischung mit Wallet-Istdaten | ✅ technisch und sichtbar bestanden; damaliger OFF-058 durch P58 geschlossen | [P55](MVP/P55_Projektbudgetplanung.md) |
| P56 | Gruppierte Build-or-Buy-Auswahl | Produktionsarten einschließlich drei Reaktionsarten filtern, gesammelt wählen und einzeln abweichen | P26/P32/P55; OFF-054 | kompakte Auswahl ohne neue Fach- oder Persistenzlogik | ✅ technisch und sichtbar bestanden | [P56](MVP/P56_Gruppierte-Build-or-Buy-Auswahl.md) |
| P57 | Produktionsbuch-Domäne und Persistenz | tatsächliche Produktionschargen getrennt vom Plan nachvollziehbar speichern | OFF-054/055 ✅; PLAN-006; P11–P19/P40 | versionierte Charge mit Jahresnummer, Produkt, Runs, ME/TE, Output, Ort und Quellenprovenienz | ✅ einschließlich OFF-059 erledigt | [P57](MVP/P57_Produktionsbuch-Domaene-Persistenz.md) |
| P58 | Produktionskosten und Preisvorschläge | Chargenkosten typisiert aufschlüsseln und ISK-Verkaufsvorschläge berechnen | P57; P27–P29/P41; OFF-056/OFF-058 | Kosten je tatsächlicher Unit, +5/+10-Prozent-Vorschläge, Jita-/Home-Hub-Vergleich und geschlossener Preisübergang | ✅ einschließlich OFF-060 erledigt | [P58](MVP/P58_Produktionskosten-und-Preisvorschlaege.md) |
| P59 | Wallet-/Verkaufszuordnung und Realgewinn | bestätigte ESI-Belege und Verkäufe ohne Doppelzählung Chargen zuordnen | P58; P42; OFF-056 | verkaufte Units, Durchschnittspreis und realisierter Gewinn mit Restmengen | ⚠️ technisch umgesetzt; OFF-061 offen | [P59](MVP/P59_Wallet-Verkaufszuordnung-Realgewinn.md) |
| P60 | Produktionsanalyse und Walletübersicht | Chargen, Verkäufe und Charakterwallets tabellarisch und grafisch auswerten | P59; OFF-056 | filterbare Produktionsanalyse, Zeitreihen und vollständigkeitssensible Gesamtwallet | ⬜ offen | [P60](MVP/P60_Produktionsanalyse-und-Wallet-Uebersicht.md) |
| P61 | Metenox-Wirtschaftlichkeitsrechner | Mondzusammensetzung, Betriebskosten und Break-even nachvollziehbar berechnen | P58/P60; OFF-057 | versionierter Monats-/Jahresvergleich mit sichtbaren CCP-/SDE-Regelständen | ⬜ offen | [P61](MVP/P61_Metenox-Wirtschaftlichkeitsrechner.md) |

## Ergänzende Planungsentscheidungen

| ID | Titel | Ziel | Status | Promptdatei |
|---|---|---|---|---|
| PLAN-003 | Lokaler Betrieb und optionale Distribution | lokale Eigennutzung verbindlich machen und P48 zuletzt optional einordnen | ✅ erledigt | [PLAN-003](MVP/PLAN-003_Lokaler-Betrieb-und-optionale-Distribution.md) |
| PLAN-004 | Folgeplanung für den lokalen Ausbau | P38 bis P48 wertorientiert ordnen und P38 ausführbar spezifizieren | ✅ erledigt | [PLAN-004](MVP/PLAN-004_Folgeplanung-lokaler-Ausbau.md) |
| PLAN-005 | Restkorrektur und Betriebsabnahme | echte Funktionslücken ohne Doppelabdeckung P50 bis P54 zuordnen | ✅ erledigt | [PLAN-005](MVP/PLAN-005_P50-P54-Restabnahmefolge.md) |
| PLAN-006 | Produktionsbuch und Metenox-Folgeplanung | Eigentümer-Arbeitsmappe in getrennte, testbare Ausbaupakete P57 bis P61 überführen | ✅ Spezifikation erledigt | [PLAN-006](MVP/PLAN-006_Produktionsbuch-und-Metenox-Folgeplanung.md) |

## Regeln für die Ausführung

1. Vor Start eines Prompts: Datei aus Entwurf in eine vollständige, prüfbare Arbeitsanweisung überführen.
2. Alle für das Prompt-Ergebnis notwendigen Einträge aus `OFFEN.md`, `OPEN_TASKS.md` und `KNOWN_ISSUES.md` mit ID, Restarbeit und Prüfnachweis in den Prompt übernehmen.
3. Im Entwickler-Menü genau einen Prompt auf `🔄 in Bearbeitung` setzen.
4. Benutzeränderungen und Scope-Gates prüfen.
5. Build und relevante Tests tatsächlich ausführen.
6. Tagebuch, Feature-Matrix, Testhistorie, bekannte Probleme und Abschlussbericht aktualisieren.
7. `✅ erledigt` nur bei vollständigem DoD-Nachweis; sonst `⚠️`, `❌` oder weiterhin `⬜`.

PLAN-002 mit P26, P32 und P37 ist abgeschlossen. P27 bis P29 sind
anschließend umgesetzt und abgenommen. P30, P31 und P33 sind ebenfalls
abgenommen. P34 wurde anschließend ausdrücklich reaktiviert und abgenommen.
P35 und OFF-030 sind abgenommen; P36 ist mit OFF-006 und OFF-024 ebenfalls
erledigt. REL-001 hat OFF-031 geschlossen. PLAN-003 macht lokale
Eigennutzung zum aktuellen Ziel. P38 bis P42 sind technisch umgesetzt und
abgenommen. P43 und P44 wurden geprüft und zurückgestellt; P45 bis P47
folgen nur nach jeweiligem Nutzenreview. Jeder Prompt beginnt nur auf
ausdrücklichen Auftrag. OFF-020/OFF-032 bleiben bis P48 optional
verschoben; P48 bleibt zuletzt.

OFF-004/KI-003, OFF-009/KI-012 und OFF-026/KI-026 sind erledigt. P12 importiert keine Marktgruppen nur für
Navigation. P17 konnte seinen konkreten T2-Bedarf aus den bereits
gespeicherten Invention-/Manufacturing-Daten decken. P18 ergänzte
ausschließlich den belegten Reaktions-/Dogmaumfang; OFF-021 bleibt als
Bedarfsgate für spätere Funktionen aktiv.

PLAN-006 verändert die laufende Reihenfolge nicht rückwirkend: OFF-055 und
OFF-054 sind abgeschlossen; P57 und P58 sind einschließlich ihrer
Eigentümergates erledigt. P59 wurde ausdrücklich beauftragt und technisch
umgesetzt; OFF-061 bleibt offen. P60 und P61 folgen jeweils nur auf
ausdrücklichen Auftrag. P54 bleibt davon unabhängig und benötigt weiterhin
eine gesonderte Commit-Freigabe.
