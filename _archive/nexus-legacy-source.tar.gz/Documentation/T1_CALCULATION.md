# T1-Berechnung

Stand: 2026-07-24 · P16 · Graphformat 4

## Zweck und Grenze

Die P16-Berechnung löst eine Produktionskette deterministisch über
Manufacturing-Rezepte auf. Sie startet beim kataloggebundenen Zielrezept und
prüft für jede Materialposition, ob der aktive SDE-Katalog genau ein
vollständig aufgelöstes Herstellungsrezept bereitstellt.

P16 interpretiert `T1` als Manufacturing-only-Rechenpfad. Der derzeitige
Katalog enthält keine belastbare, für diese Entscheidung benötigte
Tech-Stufenklassifikation; die Berechnung erfindet deshalb keine. P17
ergänzt T2/Erfindung, P18 Reaktionen und P19 die Zusammenführung gleicher
Endmaterialien.

## Ablauf

1. Zielrezept über Produkt-, Blueprint- und Aktivitäts-ID auflösen.
2. Zielruns und Zielausgabe mit der P14-Formel berechnen.
3. Materialpositionen nach `sortOrder` und `typeID` abarbeiten.
4. Materialbedarf mit der P15-Formel berechnen.
5. Eindeutig herstellbare Materialien als Zwischenprodukt anlegen.
6. Dessen Sollmenge aus der effektiven Menge der eingehenden Kante
   übernehmen.
7. Runs, Ausgabe und Überschuss des Zwischenprodukts berechnen.
8. Dessen Rezeptmaterialien nach denselben Regeln weiter auflösen.
9. Nicht herstellbare oder zurückgestellte Positionen als begründete
   Materialblätter erhalten.
10. Den vollständig validierten Graphen erst nach erfolgreichem Abschluss
    speichern.

## Mengen und ME

Für jedes Rezeptvorkommen:

```text
requiredRuns = ceil(requestedOutputQuantity / outputQuantityPerRun)
producedOutputQuantity = requiredRuns * outputQuantityPerRun
surplusOutputQuantity = producedOutputQuantity - requestedOutputQuantity
```

Für jede Materialkante gelten Rohmenge, effektive Menge und Ersparnis aus
`ProductionMaterialCalculation` Formelversion 1.

Das Zielrezept verwendet den Projektwert `materialEfficiency`. Für
automatisch entdeckte Zwischenprodukte ist kein konkreter Benutzer-Blueprint
ausgewählt. Sie tragen deshalb ausdrücklich:

```text
materialEfficiency = 0
materialEfficiencySource = neutralIntermediate
```

Dies ist ein neutraler Planungswert und keine Behauptung über einen
besessenen Blueprint. Die Graphansicht kennzeichnet ihn entsprechend.

## Graphformat 4

Graphformat 4 ergänzt das vorhandene codierte Graphpayload um:

- `expansionPolicyVersion = 1`,
- ME-Wert und ME-Herkunft je Rezeptknoten,
- `leafReason` je Materialblatt,
- die Invariante, dass der effektive Bedarf einer eingehenden Kante exakt
  der Sollausgabe des Zwischenproduktknotens entspricht.

Blattgründe:

- `noManufacturingRecipe`: kein Herstellungsrezept im aktiven Katalog,
- `reactionDeferred`: Reaktionsauflösung folgt P18.

Format 1, 2 und 3 bleiben lesbar und gelten als veraltet. Format 4 nutzt die
vorhandene Payloadspalte des SwiftData-Schemas v8. Es wird keine neue
persistente Spalte und keine Datenbankmigration benötigt.

## Determinismus und Schutz

- Vorkommensbezogene IDs enthalten den vollständigen Elternpfad.
- Gleiche Typen in verschiedenen Zweigen bleiben getrennt.
- Ein Typ, der im aktuellen Vorfahrenpfad erneut auftritt, bricht als Zyklus
  mit vollständigem Typenpfad ab.
- Mehrdeutige, ungelöste, ungültige oder versionsfremde Rezepte werden nicht
  geraten.
- Maximale Graphentiefe: 64.
- Maximale Knotenanzahl: 25.000.
- Alle Run- und Materialmultiplikationen verwenden die bestehenden
  Überlaufprüfungen.
- Cancellation wird während Katalogzugriffen, Traversierung und vor dem
  Speichern respektiert.
- Ein Fehler oder Abbruch ersetzt keinen bereits gespeicherten Graphen.

Die beiden Größenlimits sind technische Schutzgrenzen, keine EVE-Fachregeln.

## Referenzfall

Der automatisierte P16-Referenzfall prüft drei Rezeptstufen:

```text
587 (10 Stück, Output 1, ME 10)
├─ 100 (Basis 2, Output 4)
│  ├─ 200 (Basis 3, Output 10)
│  │  └─ 36 (Basis 11)
│  └─ 35 (Basis 7)
└─ 34 (Basis 5)
```

Erwartete Ergebnisse:

| Typ | Soll | Runs | Ausgabe | Überschuss |
|---|---:|---:|---:|---:|
| 587 | 10 | 10 | 10 | 0 |
| 100 | 18 | 5 | 20 | 2 |
| 200 | 15 | 2 | 20 | 5 |
| 34 | 45 | — | — | — |
| 35 | 35 | — | — | — |
| 36 | 22 | — | — | — |

## Datenquellen

P16 benötigt aus dem bereits vorhandenen SDE-Katalog:

- Typen und Veröffentlichungsstatus,
- Blueprintdefinitionen,
- Manufacturing-Aktivitäten,
- Produkte mit Ausgabemengen,
- Materialien mit Basismengen und Reihenfolge,
- aktive Buildnummer und Inhaltsprüfsumme.

Damit ist der P16-Anteil von OFF-021 geprüft. Es war kein weiterer
SDE-Datensatz erforderlich und es wurde kein Blindimport ergänzt.

## Weiterführende Pakete

- P17: T2-/Erfindungsgrenzen und T2-Ketten – erledigt,
- P18: rekursive Reaktionsstufen – erledigt,
- P19: Aggregation gleicher Endmaterialien und Summenüberlauf – erledigt,
- P26: benutzergewählte Build-or-Buy-Abbruchpunkte.
