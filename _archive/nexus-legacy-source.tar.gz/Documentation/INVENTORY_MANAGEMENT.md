# Lager und manuelle Bestände

Stand: 2026-07-24 · P20

## Zweck und Grenze

P20 stellt lokale, offline nutzbare Lagerorte und manuell gepflegte
Bestandsmengen bereit. Es handelt sich um logische Benutzerlager, nicht um
ESI-Assets, EVE-Container oder Corporation-Besitz. CSV-Import,
lagerübergreifende Verfügbarkeit, Ausschlüsse, Schutzbestände und
Reservierungen folgen P21 bis P25.

## Fachregeln

- Lager besitzen stabile lokale UUIDs, getrimmte Namen, einen definierten
  Lagertyp, optionale Notizen und einen reversiblen Archivstatus.
- Lagernamen sind nach der zentralen Katalognormalisierung eindeutig. Diese
  Regel gilt auch für archivierte Lager.
- Archivieren löscht weder Lager noch Bestände. Archivierte Lager sind bis
  zur Wiederherstellung schreibgeschützt.
- Eine Bestandsposition ist durch Lager-ID und positive CCP-Type-ID eindeutig.
- Mengen sind strikt positive `Int64`-Stückzahlen. Null, negative Werte,
  Dezimalwerte und Überläufe werden abgelehnt.
- Das Bearbeiten ersetzt die vorhandene Menge; eine implizite Addition findet
  nicht statt.
- Neue und geänderte Positionen müssen als veröffentlichtes Item im aktiven
  Katalog existieren. Name, SDE-Buildnummer und Inhaltshash werden als
  Provenienz gespeichert.
- Das Löschen betrifft nur die ausdrücklich bestätigte Position.

## Architektur

```text
InventoryView / Editoren
        │
InventoryViewModel
        │
InventoryManaging
        │
InventoryManagementService
   ┌────┴─────────────────┐
InventoryRepository   ItemBlueprintCatalogReading
        │                       │
SwiftDataInventoryRepository   aktiver SDE-Katalog
        │
NexusSchemaV10
```

SwiftUI kennt weder SwiftData-Modelle noch `ModelContext`. Domänenmodelle
validieren unveränderliche fachliche Invarianten. Der Application-Service
koordiniert Katalogprüfung, Schreibschutz und Operationen. Das
SwiftData-Repository erzwingt zusätzlich eindeutige persistente Schlüssel.

## Persistenz und Migration

Schema v10 ergänzt:

- `StorageLocationRecord`,
- `ManualStockRecord`.

Die Migration v9→v10 ist additiv. Vorhandene SDE-, Projekt-, Graph- und
Reaktionsdaten bleiben unverändert. Ein v9-Altbestand, eine zweite Öffnung
des migrierten Stores und ein leerer v10-Store sind automatisiert geprüft.
Das lokale Backupformat ist 10.0.0 und akzeptiert Versionen 1.0.0 bis 10.0.0.

## Bedienablauf

1. In der Sidebar `Assets` und anschließend `Lager & Bestände` öffnen.
2. Mit `Lager anlegen` Name, Typ und optionale Notiz erfassen.
3. Ein aktives Lager auswählen.
4. Mit `Bestand erfassen` den lokalen SDE-Katalog durchsuchen, ein
   veröffentlichtes Item wählen und eine positive Stückzahl speichern.
5. `Menge bearbeiten` ersetzt den gespeicherten Wert.
6. `Position löschen` zeigt vor dem Schreibvorgang eine Bestätigung.
7. Archivierte Lager über den Filter anzeigen und bei Bedarf
   wiederherstellen.

Loading-, Empty-, Fehler- und laufende Schreibzustände werden sichtbar
dargestellt. Laufende UI-Tasks werden beim Verlassen der Ansicht
abgebrochen; ein Speichervorgang wird erst nach vollständiger Validierung an
das Repository übergeben.

## Geprüfte Fälle

- Lager anlegen, ändern, filtern, archivieren und wiederherstellen,
- leere und normalisiert doppelte Namen,
- gültige, fehlende und unveröffentlichte Katalogitems,
- Null-/Negativmengen und `Int64`-Grenzen,
- Update statt Duplikat je Lager/Type-ID,
- identische Type-ID in verschiedenen Lagern,
- Schreibschutz archivierter Lager,
- positionsgenaues Löschen,
- Repository-Roundtrip, v9→v10-Migration und Backupformat,
- UI-/Schichtengrenzen.

