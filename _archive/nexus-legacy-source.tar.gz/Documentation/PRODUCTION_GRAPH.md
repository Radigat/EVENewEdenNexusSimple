# Produktionsgraph

Stand: 2026-07-30 · KI-062

## Zweck und aktueller Umfang

Der Produktionsgraph bildet ein kataloggebundenes Projektziel als
erklärbare, persistierbare Knoten-Kanten-Struktur ab. P16 bis P18 lösen
T1-, T2- und notwendige Reaktionsstufen rekursiv auf. Jede Rezeptstufe
besitzt eigene Runs, Ausgabe, Überschuss, ME-/Tech-/Reaktionsprovenienz und
Materialberechnungen. P19 erhält die einzelnen Vorkommen im Graphen und
ergänzt daraus eine Type-ID-basierte Endmaterialaggregation samt
Wurzelpfaden. Build-or-Buy folgt P26.

## Schichtengrenzen

```text
ProductionGraphView
  -> ProductionGraphViewModel
    -> ProductionGraphManaging
      -> ProductionGraphService
        -> RecipeResolving
        -> ProductionGraphRepository
          -> SwiftDataProductionGraphRepository
            -> ProductionGraphRecord (Schema v9)
```

SwiftUI kennt weder SwiftData-Modelle noch `ModelContext`. Der
Application-Service löst das exakt im Projekt gespeicherte Blueprintrezept
über den P10-Resolver auf, prüft die Katalogprovenienz und speichert erst nach
vollständiger Domänenvalidierung.

## Domänenmodell

`ProductionGraphSnapshot` enthält:

- eine stabile Graph-ID und die Projekt-ID,
- Zielmenge und Katalogprovenienz,
- Erzeugungs- und Aktualisierungszeit,
- Knoten und gerichtete Kanten,
- die versionierte Payloadformatnummer.

Knoten unterscheiden Ziel, Zwischenprodukt und Material. Rezepttragende
Knoten speichern Blueprint, Aktivität, Outputmenge und Produktionszeit.
Graphformat 2 ergänzt eine versionierte Runberechnung mit Zielmenge,
vollständigen Runs, tatsächlicher Ausgabe und Überschuss. Format 1 bleibt
lesbar und enthält keine Runwerte. Graphformat 3 ergänzt den
Blueprint-ME-Projektwert und eine versionierte Materialberechnung je Kante.
Graphformat 4 ergänzt Manufacturing-Rekursion, eine
Expansionsrichtlinienversion, ME-Wert und Herkunft je Rezeptknoten sowie
einen begründeten Abbruchgrund je Materialblatt.
Graphformat 5 ergänzt Tech-Stufe, Blueprint-Herkunft, BPO/BPC-Art,
ME/TE, lizenzierte Runs, Regel-/Katalogprovenienz und bei regulärer
Invention die Ausgangs-Blueprint-, Wahrscheinlichkeits-, Run- und
Materialreferenzen. Expansionsrichtlinie 2 klassifiziert jede
Manufacturing-Stufe unabhängig.
Graphformat 6 ergänzt Reaktionsart, Reactor, neutralen oder verifiziert
modifizierten Kontext sowie Material- und Zeittrace.
Graphformat 7 ergänzt Aggregationsformel 1: Endmaterialien werden nach
stabiler Type-ID summiert; jede Position bewahrt Einzelvorkommen,
effektive Mengen, Blattgründe und vollständige Wurzelpfade.
Kanten speichern Basismenge je Run, Rohbedarf, Effektivbedarf, Ersparnis
und eine deterministische Reihenfolge.

Knoten-IDs sind Vorkommens-IDs. Derselbe CCP-Type kann deshalb an mehreren
Stellen des späteren Graphen vorkommen, ohne fachlich fälschlich
zusammenzufallen. `typeID` bleibt der stabile fachliche Schlüssel.

## Determinismus und Validierung

Vor Speicherung und nach Laden werden unter anderem geprüft:

- unterstützte Payloadformatversion,
- positive Ziel- und Katalogwerte,
- vollständige und eindeutige Knoten-IDs,
- genau ein Zielwurzelknoten,
- gültige Kantenendpunkte und positive Mengen,
- keine Selbstkanten und höchstens eine eingehende Kante je Nichtwurzel,
- Erreichbarkeit aller Knoten,
- Zyklusfreiheit,
- konsistente, aus den Kanten ableitbare Tiefen,
- passendes Elternrezept je Materialkante,
- Runberechnung an jedem Rezeptknoten ab Format 2,
- Übereinstimmung von Rezeptoutput, Runoutput und Projektzielmenge,
- Projekt-ME und Materialberechnung an jeder Kante ab Format 3,
- Übereinstimmung von Basismenge, Elternruns, Aktivität und ME.
- ab Format 4 passender ME-Wert und passende Herkunft je Rezeptstufe,
- ab Format 4 ein Blattgrund je Endmaterial,
- in Format 5 vollständige und kataloggebundene T1-/T2-
  Blueprintqualitätsprovenienz,
- reguläre T2-Invention nur aus einem fertigbaren Ausgangs-Blueprint,
- historische T2-BPOs nur als explizite Stufenüberschreibung,
- effektiver Kantenbedarf gleich Sollmenge des Zwischenprodukts,
- eindeutige Geschwister-Sortierwerte,
- maximal 64 Ebenen und maximal 25.000 Knoten auch für geladene Payloads,
- ab Format 7 eine Aggregation mit Formelversion 1,
- exakte Neuberechnung und Übereinstimmung der gespeicherten Aggregation,
- überlaufgeprüfte `Int64`-Summen ohne Klemmen oder Gleitkommaersatz.

Knoten und Kanten werden kanonisch sortiert. Bei identischem Projekt,
Rezept und Katalog entsteht dieselbe Topologie; Zeitstempel bleiben
Nachweismetadaten.

Bei der impliziten Rezeptwahl werden unveröffentlichte Test- oder
Legacy-Blueprints nicht als Konkurrenz zu einem eindeutig veröffentlichten
Rezept behandelt. Genau ein veröffentlichter Kandidat wird gewählt; mehrere
veröffentlichte Kandidaten bleiben mehrdeutig und werden abgelehnt. Eine
explizit gewählte unveröffentlichte Blueprint-ID bleibt ungültig. Damit wird
keine Priorität erfunden, sondern die vorhandene SDE-Veröffentlichungsangabe
als Nutzbarkeitsgrenze angewendet; siehe ADR-0063.

## Persistenz und Bestandsschutz

Schema v6 ergänzte additiv `ProductionGraphRecord`. Schema v7 führt den
Datensatz mit optionaler `calculationFormulaVersion` fort. Schema v8 ergänzt
optional `materialFormulaVersion`; das Projekt erhält optional
`materialEfficiency`.
Pro Projekt ist höchstens
ein aktiver Snapshot erlaubt. Die kanonisch codierte Domain-Payload liegt
als `Data` vor; redundante Metadaten dienen der frühen Integritätsprüfung.

Die v7→v8-Migration verändert vorhandene Projekte, SDE-Daten oder
Format-1-/2-Payloads nicht. Alte Graphen behalten eine leere
Materialformelversion und gelten als veraltet. Fehlendes Projekt-ME wird
neutral als 0 gelesen. Der Repository-Write
validiert vor dem Speichern und ersetzt den bisherigen Snapshot erst in
derselben SwiftData-Speicheroperation. Cancellation und Savefehler rollen
bereits gesetzte Kontextänderungen explizit zurück. Ein ungültiger oder nicht
auflösbarer Neuentwurf lässt den bestehenden Graphen unverändert.

Backuppakete verwenden seit P18 Schema 9.0.0 und akzeptieren die
migrierbaren Versionen 1.0.0 bis 9.0.0.

P16 bis P19 benötigen keine neue SwiftData-Spalte: Graphformat 4 bis 7
liegt in derselben codierten Payload. P19 verändert Schema v9 nicht.
Graphformate 1 bis 6 bleiben lesbar, enthalten keine P19-Aggregation und
gelten deshalb als veraltet.

## Aktualität

Ein Graph gilt als veraltet, wenn:

- er nicht Graphformat 7 oder keine aktuelle Run-/Materialberechnung und
  Aggregation besitzt,
- das Projektziel oder dessen Menge nicht mehr dem Snapshot entspricht,
- die gespeicherte Katalogbuildnummer oder der Inhaltshash abweicht,
- der gespeicherte Blueprint-ME-Wert bei einem T1-Ziel vom Projekt abweicht.

Reine Änderungen an Name, Notizen, Priorität, Status oder Zieltermin machen
den Graphen nicht veraltet.

Veraltete Graphen bleiben sichtbar und werden erst nach ausdrücklicher
Benutzeraktion neu erzeugt. Archivierte Projekte dürfen gelesen, aber nicht
neu berechnet werden.

## Fehler- und Abbruchverhalten

Produktionsgraphfehler werden zentral der Operation `productionGraph` und
dem stabilen Code `NEN-GRAPH-001` zugeordnet. Fehlende Ziele, nicht
auflösbare Rezepte, Versionsabweichungen, ungültige Graphen und
Persistenzfehler werden typisiert weitergegeben. Cancellation wird vor und
während der Traversierung sowie vor der Persistenz beachtet. Zyklen,
mehrdeutige oder ungelöste Zwischenrezepte, Katalogwechsel sowie Tiefen- und
Knotengrenzen, Aggregationsüberlauf, unvollständige Erklärpfade und
abweichende gespeicherte Summen brechen vor dem Speichern beziehungsweise
beim Laden ab.

## Benutzeroberfläche

Die eigenständige Graphansicht zeigt:

- Loading-, Empty-, Error- und Veraltet-Zustände,
- Ziel, Menge und Katalogbuild,
- Blueprint, Aktivität, Output pro Run und Produktionszeit,
- benötigte Runs, tatsächliche Ausgabe, Überschuss und Formelversion,
- Blueprint-ME, Rohbedarf, Effektivbedarf, Ersparnis und Materialformel,
- Expansionsregel, Stufen-ME und dessen Herkunft,
- Tech-Stufe, Blueprint-Herkunft, TE, Runs je BPC sowie
  Invention-Grunddaten,
- Runs, Ausgabe und Überschuss jedes Zwischenprodukts,
- Blattgründe für tatsächliche Endmaterialien,
- eingerückte Materialvorkommen und Tiefen,
- Erzeugen beziehungsweise bewusstes Neuerzeugen,
- Reaktionsart, Reactor, Kontext sowie Material- und Zeitfaktoren,
- aggregierte Materialtypen und Vorkommenszahl,
- Gesamtmenge je Type-ID,
- aufklappbare Einzelvorkommen mit Menge und vollständigem Wurzelpfad,
- bei alten Graphformaten den Hinweis zur bewussten Neuerzeugung.

Die Ansicht besitzt eigene Tastaturaktionen und Accessibility-Beschriftungen.
`ProjectsView` öffnet sie als separates Sheet und enthält keine
Graphberechnung.

## Bewusst offene Erweiterungen

- P26: Build-or-Buy-Entscheidungen,
- P34: gemessene Performancebudgets für reale große Graphen.
