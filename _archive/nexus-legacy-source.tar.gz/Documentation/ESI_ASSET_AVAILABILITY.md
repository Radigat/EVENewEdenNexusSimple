# Kontrollierte ESI-Asset-Verfügbarkeit

Stand: 2026-07-28 · P50/OFF-044

## Zweck und Datenquellen

P50 macht die bereits lokal gespeicherten persönlichen P40-Snapshots
detailliert nutzbar. Assets, Blueprints und Industry Jobs bleiben
schreibgeschützte ESI-Daten. Nur Assets können zusätzlich als getrennte,
projektbezogene Verfügbarkeitsquelle gewählt werden.

Statische Typnamen stammen ausschließlich aus dem aktiven lokalen
SDE-Katalog. Öffentliche NPC-Stationen und Sonnensysteme werden über den
offiziellen ESI-Namensendpunkt aufgelöst. Technische IDs bleiben interne
Schlüssel und werden in der normalen Oberfläche nicht angezeigt.

## Detailansichten

- Assets, Blueprints und Industry Jobs sind je Charakter über fachliche
  Item-, Orts-, Aktivitäts- und Statusnamen durchsuchbar und sortierbar.
- Die drei Ansichten sind alphabetisch nach Station gruppiert. Gruppen sind
  zunächst geschlossen und laden sichtbare Zeilen in 100er-Schritten.
- Die Suche prüft immer den vollständigen Snapshot und öffnet Gruppen mit
  Treffern automatisch.
- Angezeigt werden Namen, Mengen, Blueprintart, ME/TE/Runs sowie
  Jobaktivität, Status, Station, Produkt und Zeitraum.
- Die Jobansicht zeigt ausschließlich den ESI-Status `active`. Ausgelieferte
  und andere historische Jobs bleiben im lokalen Snapshot erhalten.
- Snapshotrevision, Abrufzeit, Compatibility-Date und aktueller oder
  abgelaufener lokaler Cachezustand bleiben sichtbar.
- Leere, ladende und fehlerhafte Namensauflösungen sind eigene Zustände.
- Gruppierung, Suche und Sortierung laufen außerhalb des Main Threads. Ein
  einmaliger Ortsindex verhindert die wiederholte Auflösung des gesamten
  Asset-Baums.

## Vorschau und Bestätigung

1. Projekt, Charakter und einen oder mehrere im Snapshot vorhandene,
   benannte EVE-Lagerorte wählen.
2. Der Application-Service gruppiert positive Assetmengen nach
   Type-/Location-ID und erzeugt eine ausschließlich flüchtige Vorschau.
3. Jede Vorschau zeigt Menge, Herkunftsort und vorhandene manuelle oder
   CSV-Bestände desselben Typs.
4. Eine Überschneidung blockiert die Bestätigung. Es findet keine
   automatische Zusammenführung statt.
5. `Auswahl ausdrücklich übernehmen` öffnet einen zweiten
   Bestätigungsdialog; erst dessen Bestätigung speichert die Auswahl.

Ändern sich Snapshotrevision, Lagerbestand, bestehende Auswahl oder
Locationfilter, wird die Vorschau verworfen beziehungsweise beim Schreiben
als veraltet abgelehnt. Abbruch und Fehler erhalten den bisherigen Stand.

Eine gespeicherte Auswahl lässt sich nur über eine eigene
Rücknahmevorschau, Stale-Prüfung und ausdrückliche Bestätigung entfernen.
Persönlicher ESI-Snapshot, Assets sowie manuelle und importierte Bestände
bleiben dabei unverändert.

## Wirkung auf die Produktionsplanung

Eine aktuelle bestätigte Auswahl ergänzt die physische Verfügbarkeit erst an
der Application-Grenze des Build-or-Buy-Plans. Die ESI-Menge wird separat als
`externalPhysicalQuantity` ausgewiesen; `storedPhysicalQuantity` und alle
manuellen/CSV-Datensätze bleiben unverändert. Sicherheitsbestände,
Reservierungen und Build-or-Buy werden anschließend über den bereits
vorhandenen deterministischen Ablauf berechnet.

Eine Auswahl wird nicht verrechnet, wenn:

- die P40-Snapshotrevision nicht mehr übereinstimmt oder
- später ein positiver manueller/CSV-Bestand eines gewählten Typs vorhanden
  ist.

Die gespeicherte Auswahl bleibt in diesem Fall für eine nachvollziehbare
Korrektur erhalten, wirkt aber nicht automatisch.

## Persistenz, Migration und Trennen

Schema v23 ergänzt nur
`ESIAssetAvailabilitySelectionRecord`. Gespeichert werden Projekt,
Charakter, P40-Quellrevision, gruppierte Type-/Location-/Mengenzeilen und
Zeitstempel. Die leichte v22→v23-Migration erfindet keine Auswahl.

Backupformat 23 umfasst die neue Entität. Wiederöffnung, Migration,
Löschen/Wiederherstellen und Trennkompensation sind automatisiert geprüft.
Beim bestätigten Trennen eines Charakters werden dessen Auswahlen zusammen
mit den bereits bestehenden persönlichen Daten entfernt; ein Teilfehler wird
kompensiert.

Blueprints und Jobs bleiben reine Anzeige. P50 verändert weder
Blueprintqualität noch Projektstatus und erzeugt keine ESI-Schreibroute.

## Ortsnamengrenze

`POST /universe/names` löst öffentliche NPC-Stationen und Sonnensysteme ohne
weiteren persönlichen Scope auf. Für private Spielerstrukturen ist der
exakte Name nicht öffentlich verfügbar. Bis zu einer gesonderten Nutzen-
und Scope-Entscheidung zeigt die App deshalb „Spielerstruktur – Name nicht
freigegeben“ statt einer technischen ID oder eines erfundenen Namens.
