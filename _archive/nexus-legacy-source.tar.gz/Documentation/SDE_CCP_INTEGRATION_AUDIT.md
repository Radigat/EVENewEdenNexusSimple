# Soll–Ist-Audit: CCP-konforme SDE-Integration

Stand: 2026-07-23  
Audit-ID: AUD-SDE-001

## Gesamturteil

Der vorgelegte Gesamtprompt ist **nicht vollständig umgesetzt**.

P07 bis P09 bilden bereits einen belastbaren Offline-Kern:

- offizielles JSONL-Format und offizielle versionierte Archiv-URL,
- blockweise JSONL-Prüfung,
- lokale SHA-256-Bindung,
- defensives `.nensde`-Staging,
- fachliches Mapping und Referenzprüfung,
- versionierte SwiftData-Stände,
- atomare Aktivierung mit Rollback,
- alter Datenstand bleibt erhalten,
- read-only Item-/Blueprintkatalog.

P07A hat die Online-Metadatenebene, HTTP-Caching, Schema-Gate und technische
Compliancekonfiguration ergänzt. Download, Archivschutz, Aktivierungsworkflow
und Bedienebene fehlen weiterhin. Der Gesamtprompt darf deshalb nicht als
erledigt gelten.

## Datenstand

| Wert | Nachweis |
|---|---|
| zuletzt real getesteter Projektstand | Build `3424810`, temporärer P08/P09-E2E-Test |
| am 2026-07-23 offiziell gemeldeter Stand | Build `3444265`, Release `2026-07-23T11:06:22Z` |
| produktiv installierter Stand | nicht nachgewiesen |
| aktuelles internes Persistenzschema | `NexusSchemaV4` 4.0.0 |
| importierte SDE-Datensätze | Kategorien, Gruppen, Typen, Blueprints |
| normalisierte Daten | Aktivitäten, Materialien, Produkte, Typ-/Gruppen-/Kategoriebezüge |

## Soll–Ist-Matrix

| Abschnitt des Gesamtprompts | Status | Tatsächlicher Stand | Verbindliche Restarbeit |
|---|---|---|---|
| 1 Projektanalyse | ⚠️ teilweise | P00–P09 analysierten Architektur, Datenmodell und SDE-Pfade; aktueller Hardcode-Scan durchgeführt. | Scan und Datenbedarf vor jedem SDE-Erweiterungsprompt wiederholen; Befunde dokumentieren. |
| 2 rechtliche/technische Vorprüfung | ⚠️ teilweise | Aktuelle offizielle Quellen in `CCP_COMPLIANCE.md` geprüft; keine stellvertretende Vertragsannahme; Owner-Aufgaben sichtbar. | Eigentümerpflichten bestätigen und Prüfung vor Release wiederholen. |
| 3 offizielle SDE-Quelle | ⚠️ teilweise | `latest.jsonl` und Schema-Changelog ausschließlich über feste offizielle URLs; versionierte Archiv-URL vorbereitet. | Offiziellen Downloadclient in P07B ergänzen. |
| 4 Aktualitätsprüfung | ✅ technischer Kern | zentraler Updatecheck, aktive lokale Version, 24-h-Policy, Offlinezustand und gespeicherter Prüfstatus. | Start-/manuelle UI-Verdrahtung in P07C. |
| 5 HTTP-Caching | ✅ vorhanden | ETag, Last-Modified, 304, Cache-Control, Timeout, begrenztes Retry/Backoff/Jitter und zentraler User-Agent getestet. | Eigentümerkontakt vor Produktivbetrieb konfigurieren. |
| 6 Download-/Importsicherheit | ⚠️ teilweise | lokaler JSONL-Stream, Dateiprüfung, Symlinkschutz, Abbruch, `.partial`-Cleanup, Mapping und atomare Aktivierung vorhanden. | HTTPS-Download, Größen-/Speicherplatzprüfung, ZIP-Validierung, Zip-Slip-/Bombenschutz, isolierter Importstore und Crash-Recovery. |
| 7 lokales Datenmodell | ⚠️ teilweise | stabile CCP-IDs, getrennte Entitäten, Versionstag und Benutzerentitäten werden nicht überschrieben. | Marktgruppen, Skills, Dogma, Universe, Units, Meta und Lokalisierung nur bedarfsgesteuert ergänzen; Datenherkunft formal klassifizieren. |
| 8 Schemaänderungen | ⚠️ teilweise | Schema-Changelog-Gate und Parser-Version vorhanden; Zusatzfelder toleriert, fehlende oder typveränderte Pflichtfelder abgelehnt; Schema v4 speichert den Stand. | P07B muss das Gate vor Download/Aktivierung verbindlich anwenden. |
| 9 Benutzeroberfläche | ❌ fehlt | Settings enthalten nur SSO/Datenschutz. | Bereich „EVE-Daten und SDE“, Statusmodell, Fortschritt, Fehler, Update- und Protokollaktionen. |
| 10 automatisches/manuelles Verhalten | ⚠️ teilweise | 24-h-Policy und Force-vs.-Servercache semantisch implementiert. | Startprüfung, Einstellungen und Rollback-Aufbewahrung in P07C/P07B. |
| 11 Trennung SDE/ESI | ⚠️ teilweise | fachliche Targets und Ports sind getrennt; SSO/ESI-Zukunftscode wird nicht vom SDE-Import ausgelöst. | verbindliche ESI-Cache-/Ratelimitregeln in P39; Datenherkunft in Modellen/Dokumentation kennzeichnen. |
| 12 Lizenz/Kennzeichnung/Datenschutz | ❌ fehlt | DLA-URL im Manifest; keine CCP-Bilder gefunden. | unabhängiger Drittanbieterhinweis, aktuelle Eigentumsangabe, Links, Buildnummer und Eigentümerfreigabe. |
| 13 Fehlerbehandlung | ⚠️ teilweise | lokale sowie Offline-, Timeout-, Abbruch-, 304/404/429/5xx-, Inhalt-, Cache-, Schema- und Persistenzfehler vorhanden. | ZIP, Speicherplatz und Crashzustände in P07B ergänzen. |
| 14 Updateprotokoll | ❌ fehlt | Manifest, Counts und zentrale Fehlercodes existieren, aber kein Updateversuch-Log. | persistentes strukturiertes Protokoll und bereinigter Diagnoseexport. |
| 15 Tests | ⚠️ teilweise | zusätzlich HTTP-, Redirect-, Cache-, Retry-, Schema-, Status-, Migration- und Backupfälle; 130/130 Debug/Release. | Download-, ZIP-, Crash-, UI-, Scheduler- und vollständige Bestandsschutztests fehlen. |
| 16 Dokumentation | ⚠️ teilweise | Architektur, SDE-Staging, Datenmodell, Tests, ADRs und Berichte vorhanden. | Datenquellen-/Compliance-, Update-, Benutzer-, Diagnose- und Erweiterungsdokumentation vervollständigen. |
| 17 Abnahmekriterien | ❌ nicht erfüllt | JSONL-Streaming, Aktivrollback und Kernstammdaten sind teilweise erfüllt. | Onlinecheck, Download, Caching, Schema-Gate, Kartendaten, UI, Hinweise, vollständige Tests und manueller Test fehlen. |
| 18 Abschlussbericht | ❌ fehlt für Gesamtscope | P07–P09 besitzen Einzelberichte. | gemeinsamer Abschlussbericht erst nach P07A–P07C und betroffenen Datensatzerweiterungen. |

## Bereits erfüllte technische Kerne

1. JSON Lines wird blockweise gelesen; große Quelldateien werden in P07 nicht
   vollständig materialisiert.
2. Pflichtdateien, UTF-8, JSON-Objektform, Schlüssel, Duplikate und
   Zeilengröße werden geprüft.
3. Symbolische Datensatzdateien und nach der Vorschau veränderte Quellen
   werden abgelehnt.
4. `.partial`-Artefakte werden bei Fehlern bereinigt.
5. Mapping prüft Kategorie-/Gruppen-/Typ-/Blueprintbezüge und Wertebereiche.
6. Neue Versionen verwenden stabile CCP-IDs und einen unveränderlichen
   Inhalts-SHA.
7. Aktivmarker und neue normalisierte Daten werden in einem Save
   veröffentlicht; Fehler rollen den ModelContext zurück.
8. Alte SDE-Versionen bleiben als Rückfallstand vorhanden.
9. SDE-Aktivierung verändert keine Charakter- oder Projektentität.
10. Nicht aufgelöste offizielle Typreferenzen werden nicht erfunden oder
    verschwiegen.

## Wesentliche noch offene Risiken

- Build `3424810` ist nicht mehr der am Audit-Tag gemeldete aktuelle Build.
- Der technische Service kann die Abweichung erkennen; produktive
  Start-/UI-Verdrahtung und Behebung fehlen.
- Der Mapper materialisiert den normalisierten Gesamtsnapshot vor dem
  SwiftData-Schreiben; ein isolierter Streaming-Stagingstore fehlt.
- Ein Prozessabsturz zwischen Download, Import und Aktivierung ist nicht
  end-to-end geprüft.
- ZIP-Inhalte und freier Speicherplatz werden nicht geprüft, weil es noch
  keinen Downloader gibt.
- `schema-changelog.yaml` wird ausgewertet; P07B muss das Gate vor einer
  Installation anwenden.
- Es gibt keine dauerhafte Updatehistorie, keinen Diagnoseexport und keine
  SDE-UI.
- Rechtliche Hinweise und User-Agent-Kontakt benötigen eine persönliche
  Entscheidung des Projekteigentümers.

## Datenumfang und bedarfsgesteuerte Erweiterung

Nicht jeder im Gesamtprompt genannte SDE-Datensatz gehört in den reduzierten
Produktionsplaner-MVP.

| Datenbereich | Aktueller Bedarf | Zuordnung |
|---|---|---|
| Typen, Gruppen, Kategorien | unmittelbar | umgesetzt P08/P09 |
| Blueprints, Aktivitäten, Materialien, Produkte, Reaktionen | unmittelbar | gespeichert; Resolver P10 |
| Marktgruppen | nützlich für Auswahl/Marktstruktur | Bedarf in P12/P27/P41 entscheiden |
| benötigte Skills | erst für Skill-/Charakterplanung | P39/P40 oder eigener Fachprompt |
| Regionen, Konstellationen, Systeme, NPC-Stationen | Logistik/Standorte/Märkte | P40/P41/P44 |
| Units, Meta-Gruppen | nur bei konkreter Anzeige/Berechnung | zuständiger Fachprompt |
| Dogma-Attribute/-Effekte | kein pauschaler MVP-Bedarf | nur mit dokumentierter Regelabhängigkeit |
| Übersetzungen | spätere Lokalisierung | P35 oder eigener Datensatzprompt |

Jeder zuständige Prompt muss vor Implementierung die benötigten Dateien und
Felder begründen. Blindes Importieren sämtlicher SDE-Dateien bleibt verboten.

## Neue Arbeitspakete

1. **P07A – Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance – erledigt**
2. **P07B – Sicherer SDE-Download, Archivprüfung und crashfeste Aktivierung**
3. **P07C – SDE-Einstellungen, Automatisierung und rechtliche Hinweise**

Diese Pakete ergänzen P07–P09; sie erklären die bereits erledigten
Offline-Kerne nicht rückwirkend für unvollständig. P07B ist das nächste
empfohlene Arbeitspaket.
