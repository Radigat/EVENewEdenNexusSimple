# Industrie-Regelgrundlage für T2 und Reaktionen

Stand: 2026-07-24  
Status: **verifizierte Spezifikationsgrundlage – noch nicht als Laufzeitmodell implementiert**

## Zweck

Dieses Dokument ist die gemeinsame fachliche Grundlage für P17
„T2-Berechnung“ und P18 „Reaktionsstufen“. Es trennt verifizierte
EVE-Regeln, statische SDE-Daten, konkrete Blueprint- beziehungsweise
Planungswerte und Produktionskontext. P17 und P18 dürfen keine davon
abweichende Parallelregel implementieren.

Die Regeln wurden am 2026-07-24 gegen aktuelle offizielle CCP-Hilfeseiten,
Entwicklerdokumentation, den offiziellen SDE-Build `3444265`, den
ESI-Blueprintvertrag und den aktuellen Projektcode geprüft. Vor einer
späteren Implementierung muss die Aktualität der zeitabhängigen Quellen und
des dann aktiven SDE-Builds erneut bestätigt werden.

## Verbindliche Quellen

- [CCP – Blueprints](https://support.eveonline.com/hc/en-us/articles/203269951-Blueprints)
- [CCP – Material Efficiency Research](https://support.eveonline.com/hc/en-us/articles/203210542-Material-Efficiency-Research)
- [CCP – Time Efficiency Research](https://support.eveonline.com/hc/en-us/articles/203210512-Time-Efficiency-Research)
- [CCP – Copying](https://support.eveonline.com/hc/en-us/articles/203210602-Copying)
- [CCP – Invention](https://support.eveonline.com/hc/en-us/articles/203210642-Invention)
- [CCP – Decryptors](https://support.eveonline.com/hc/en-us/articles/203270631-Decryptors)
- [CCP – Reactions](https://support.eveonline.com/hc/en-us/articles/115005405785-Reactions)
- [CCP – Static Data](https://developers.eveonline.com/docs/services/static-data/)
- [CCP – Invention updates](https://www.eveonline.com/news/view/invention-updates)
- [CCP – Reactions redefined](https://www.eveonline.com/news/view/reactions-redefined-new-industry-opportunities-for-you)

Ältere CCP-Devblogs erklären weiterhin verwendete Grundmechaniken, sind
aber bei Widerspruch mit aktuellen Hilfeseiten, aktuellem SDE oder aktuellem
Client nicht vorrangig.

## Drei getrennte Datenebenen

### 1. Statische Blueprintdefinition

Die SDE beschreibt:

- Blueprint-Type-ID,
- Aktivitäten,
- Basismaterialien,
- Produkte und Ausgabemengen,
- Basiszeiten,
- produktspezifische Invention-Wahrscheinlichkeiten,
- notwendige Skills,
- maximale Produktionslimits.

Eine Blueprintdefinition beweist weder Besitz noch BPO/BPC-Art, ME, TE oder
verbleibende Runs einer konkreten Blueprintinstanz.

### 2. Blueprintinstanz oder Planungsszenario

Eine konkrete beziehungsweise geplante Blueprintverwendung benötigt:

- Blueprint-Type-ID,
- Herkunft,
- BPO/BPC-Art,
- ME,
- TE,
- verbleibende beziehungsweise lizenzierte Runs,
- optional gewählten Decryptor,
- Daten- und Regelprovenienz.

Mindestens zu unterscheiden:

- `researchedBPO`,
- `copiedFromBPO`,
- `inventedBPC`,
- `legacyT2BPO`,
- `manualPlanningAssumption`.

### 3. Produktionskontext

Anlagen-, Rig-, Security- und Skillwerte gehören nicht zur
Blueprintdefinition. Sie werden als eigener, versionierter Job- oder
Planungskontext angewendet.

## T1-, BPO- und BPC-Regeln

- Ein BPO besitzt unbeschränkte lizenzierte Produktionsruns.
- Nur ein BPO kann auf ME und TE erforscht oder kopiert werden.
- ME besitzt zehn Forschungsstufen zu je einem Prozent: `0...10`.
- TE besitzt zehn Forschungsstufen zu je zwei Prozent: `0...20`.
- Eine BPC übernimmt ME und TE des BPO zum Zeitpunkt des Kopierens.
- Spätere BPO-Forschung verändert vorhandene BPCs nicht.
- Eine BPC kann nicht weiter erforscht oder kopiert werden.
- Eine BPC besitzt begrenzte lizenzierte Runs.
- Kopierjob-Runs und lizenzierte Runs je Kopie sind getrennte Größen.

## Material-Efficiency

Für Basismenge `B`, benötigte Runs `R` und Blueprint-ME `M` gilt in der
bereits durch P15 implementierten Blueprint-ME-Schicht:

```text
Rohbedarf = B × R

wenn B == 1:
    Effektivbedarf = Rohbedarf
sonst:
    Effektivbedarf = ceil(Rohbedarf × (100 − M) / 100)
```

Die Rundung erfolgt je Materialposition über den gesamten Job. Eine
Basismenge von einer Einheit je Run wird nicht durch ME reduziert. Das gilt
insbesondere für T1-Eingangsprodukte in T2-Rezepten.

Anlagen- und Rigfaktoren sind getrennte spätere Faktoren. P15s
Blueprint-ME-Formel darf nicht stillschweigend als vollständige
Jobmaterialformel ausgegeben werden.

## T2-Invention

Ein reguläres T2-Invention-Ergebnis beginnt ohne Decryptor bei ME 2 und
TE 4. Die aktuellen Standardkombinationen lauten:

| Decryptor | CCP-Type-ID | Chance | Runs | ME | TE |
|---|---:|---:|---:|---:|---:|
| keiner | — | ×1,0 | +0 | 2 | 4 |
| Accelerant | 34201 | ×1,2 | +1 | 4 | 14 |
| Attainment | 34202 | ×1,8 | +4 | 1 | 8 |
| Augmentation | 34203 | ×0,6 | +9 | 0 | 6 |
| Parity | 34204 | ×1,5 | +3 | 3 | 2 |
| Process | 34205 | ×1,1 | +0 | 5 | 10 |
| Symmetry | 34206 | ×1,0 | +2 | 3 | 12 |
| Optimized Attainment | 34207 | ×1,9 | +2 | 3 | 2 |
| Optimized Augmentation | 34208 | ×0,9 | +7 | 4 | 4 |

Die Kombination ME 3 / TE 2 ist nicht eindeutig: Parity und Optimized
Attainment unterscheiden sich bei Chance und Runs. Deshalb darf
Blueprintqualität nicht allein durch ME und TE identifiziert werden.

Weitere Regeln:

- Das verwendete T1-BPC verbraucht einen lizenzierten Run je
  Invention-Job-Run, unabhängig vom Erfolg.
- ME und TE des T1-BPC werden nicht auf das erfundene T2-BPC übertragen.
- Datacores und ein optionaler Decryptor werden unabhängig vom Erfolg
  verbraucht.
- Basiswahrscheinlichkeit und Grundruns stammen aus dem konkreten
  SDE-Invention-Produkt.
- Die Grundruns werden aus
  `activities.invention.products[].quantity` gelesen und nicht pauschal als
  eins oder zehn fest codiert.
- Ein fehlender SDE-Wahrscheinlichkeitswert darf nicht durch einen
  Klassenstandard ersetzt werden; der Fall ist zu blockieren oder
  ausdrücklich als `needsReview` zu behandeln.
- Historische T2-BPOs und daraus kopierte BPCs sind Ausnahmen von den
  Standard-Invention-Kombinationen. Für sie gelten die normalen
  BPO-Forschungs- und Kopierregeln.

Die vollständige stochastische Beschaffungsplanung mit erwarteten
Fehlversuchen und Kosten gehört nur dann zu P17, wenn sie dort ausdrücklich
aufgenommen wird. P17 muss jedoch die Qualität und Runs eines verwendeten
T2-BPC deterministisch und herkunftsgerecht validieren.

## Reaktionen

- Reaktionsformeln besitzen unbeschränkte Runs.
- Sie können nicht erforscht, kopiert oder inventiert werden.
- Blueprint-ME und Blueprint-TE sind fachlich nicht anwendbar.
- Internes ME 0 / TE 0 ist nur eine technische Normalisierung.
- Reaktionen benötigen eine Refinery mit passendem aktiven Reactor.
- Reaktoren und Formeln unterscheiden Composite, Biochemical und Hybrid.
- Reaktionen sind nur in Systemen mit Security `0.4` oder niedriger
  installierbar.
- Der Skill `Reactions` reduziert die Jobdauer um vier Prozent je Stufe.
- Anlagen und Rigs können Reaktionszeit und Rigs zusätzlich Materialbedarf
  verändern.

Im SDE-Build `3444265` wurden unter anderem geprüft:

- Athanor: Reaktionszeitfaktor `1.0`,
- Tatara: Reaktionszeitfaktor `0.75`,
- T1-Reaktionsrig: Basis `−20 %` Zeit oder `−2 %` Material,
- T2-Reaktionsrig: Basis `−24 %` Zeit oder `−2.4 %` Material.

Der SDE-Dogma-Effekt `6976` wendet einen Security-Modifikator auf die
Reaktionsrigwerte an. P18 liest die konkreten Low-Sec- und
Null-Sec/Wormhole-Werte aus den SDE-Attributen `2356` und `2357` des
jeweiligen Rigs. Nicht verifizierte historische Werte werden nicht
fest codiert.

## Benötigte SDE-Erweiterungen

Der bestehende Katalog importiert Kategorien, Gruppen, Typen,
Blueprintdefinitionen, Aktivitäten, Materialien und Produkte. Für P17 und
P18 werden bedarfsgesteuert zusätzlich benötigt:

### P17 – Ergebnis des Implementierungsaudits

P17 benötigt keine zusätzliche SDE-Tabelle. Der vorhandene Katalog speichert
bereits die eindeutige Invention-Beziehung, produktspezifische Grundruns,
Basiswahrscheinlichkeit, Datacores und alle betroffenen
Manufacturing-Aktivitäten. Der zusätzliche Nachweis, dass der
Ausgangs-Blueprint selbst fertigbar ist, grenzt T2 von Reverse
Engineering/T3 ab.

`metaGroups`, Aktivitäts-Skills und Decryptor-Dogmawerte wären für die
P17-Materialplanung redundant: Skills sind keine Materialien, und die
Decryptorwerte liegen als versionierter, am 2026-07-24 gegen die offizielle
CCP-Regelquelle geprüfter Vertrag vor. Ein Blindimport wurde deshalb
vermieden.

### P18 – Ergebnis des Implementierungsaudits

- die relevanten Facility-, Reactor- und Rigtypen,
- deren benötigte `typeDogma`-Werte,
- zugehörige `dogmaAttributes` und `dogmaEffects`,
- verifizierte Zuordnung von Reaktionsgruppen zu Reactorarten,
- verifizierte Security-Modifikatoren.

P18 verarbeitet genau 20 relevante Typ-Dogma-Einträge, sechs
Attributdefinitionen und acht Effektdefinitionen. Es erfolgt kein
Blindimport sämtlicher Dogma- oder Universe-Daten. Jeder Datensatz und jedes
Attribut ist durch eine konkrete Berechnungs- oder Validierungsanforderung
begründet. Der Realtest gegen Build 3444265 bestätigt alle drei
Reaktionsarten und das verifizierte Profil.

## Versionierter Laufzeitvertrag

P17 legt einen gemeinsamen `IndustryRuleSet` oder semantisch gleichwertigen
Vertrag an. Er enthält mindestens:

- Regelversionsnummer,
- SDE-Buildnummer und Inhaltsprüfsumme,
- Prüfdatum und Quellen,
- unterstützte Aktivitäten,
- Tech-Klassifikation,
- Blueprint-Herkünfte,
- Invention- und Decryptorregeln,
- Rundungsregelversionen,
- Verifikationsstatus je zeitabhängiger Regel.

P18 erweitert denselben Vertrag um:

- Reaktionskategorien,
- Facility-/Reactor-/Rigfaktoren,
- Security-Modifikatoren,
- Skillfaktoren,
- Reaktionsmaterial- und Zeitformelversionen.

## Agent- und Abschlussprüfung

Vor der Berechnung und vor einem Abschlussstatus `✅` muss ein
maschinenlesbarer Preflight mindestens prüfen:

1. Regelversion und aktiver SDE-Build stimmen überein.
2. Alle verwendeten Typ- und Blueprintreferenzen sind aufgelöst.
3. Tech-Stufe und Aktivität sind bekannt.
4. Blueprintqualität passt zur dokumentierten Herkunft.
5. Invention-Produkt besitzt eindeutige Runs und Wahrscheinlichkeit.
6. Reaktionen verwenden keine Blueprint-ME oder Blueprint-TE.
7. Benötigte Produktionskontextfaktoren sind vorhanden oder das Ergebnis
   ist ausdrücklich als neutrales Basisszenario gekennzeichnet.
8. Alle zugehörigen Golden Fixtures bestehen.

Mögliche Ergebnisse:

- `pass`,
- `fail`,
- `needsReview`.

`fail` oder `needsReview` verhindert für den betroffenen Prompt den Status
`✅ erledigt`, solange der Befund nicht geschlossen oder als ausdrücklich
außerhalb des Promptumfangs begründet wurde.

## Scope-Grenzen

Nicht durch P17/P18 vorgezogen werden:

- SSO oder ESI-Synchronisation persönlicher Blueprintinstanzen,
- vollständige Blueprintbibliothek und Forschungswarteschlange,
- stochastische Kostenoptimierung von Invention,
- Fuel-, Steuer-, Kostenindex-, Slot- und Kalenderverwaltung,
- tatsächlicher Reactor-Servicezustand an Spielerstrukturen,
- vollständiges Reaktionsmanagement aus P43,
- T3, PI, Corporation- oder Optimierungsfunktionen.
