# Sicherheitsbestände

Stand: 2026-07-25 · P23

## Zweck und Grenze

P23 ergänzt die projektbezogene physische P22-Verfügbarkeit um globale,
Type-ID-basierte Schutzregeln. Eine Regel kann Sicherheitsbestand sowie
optionale Mindest-, Warn- und Zielmengen enthalten. Projektreservierungen,
konkurrierende Reservierungen und Build-or-Buy bleiben P24 bis P26.

Die Regeln gelten global je positiver CCP-Type-ID. Lagerbezogene Regeln
werden nicht vorweggenommen, weil das Projektbuch keine belastbare
Allokationsregel zwischen globalen und lagerbezogenen Schutzmengen vorgibt.

## Fachliche Berechnung

Für jede Graphformat-7-Endmaterialzeile:

```text
außerhalb P22 geschützt
  = aktiver physischer Bestand - P22-einbeziehbarer Bestand

noch aus P22 zu schützen
  = max(0, Sicherheitsbestand - außerhalb P22 geschützt)

aus P22 geschützte Menge
  = min(P22-einbeziehbarer Bestand, noch aus P22 zu schützen)

nach Schutz verfügbar
  = P22-einbeziehbarer Bestand - aus P22 geschützte Menge

für das Projekt verwendbar
  = min(Bruttobedarf, nach Schutz verfügbar)

P23-Fehlmenge
  = Bruttobedarf - verwendbare Menge
```

Archivierte Bestände zählen nicht. Ein bereits durch P22 ausgeschlossener
aktiver Bestand deckt den globalen Schutz zuerst. Ohne Regel bleibt das
P22-Ergebnis unverändert. Alle Mengen sind `Int64`; ungültige oder
widersprüchliche Eingaben werden abgelehnt.

Der prognostizierte aktive Restbestand wird unabhängig mit Sicherheits-,
Mindest-, Warn- und Zielmenge verglichen. Meldungen enthalten Istwert,
Schwelle und Differenz, blockieren die Berechnung jedoch nicht. Nur der
Sicherheitsbestand wird automatisch zurückgehalten. Die Zielauffüllmenge ist
informativ und verändert keine Einkaufsliste.

## Architektur

- `SafetyStockCalculator` ist deterministisch und frei von UI- und
  Persistenzabhängigkeiten.
- `SafetyStockService` liest die aktuelle P22-Vorschau, erstellt eine
  schreibfreie P23-Vorschau und verlangt vor dem Speichern eine ausdrückliche
  Bestätigung.
- Der Source-State umfasst Projekt, Graph, Lager, Bestände,
  P22-Konfiguration und alle betroffenen Regelversionen. Änderungen
  verwerfen eine alte Vorschau.
- `SwiftDataSafetyStockPolicyRepository` ersetzt die Regeln der aktuellen
  Graphmaterialien in einem atomaren Save. Ausgelassene Regeln werden
  gelöscht; ein Fehler führt zum Rollback.
- Ein erfolgreicher Commit wird nicht durch eine nachgelagerte
  Cancellation-Prüfung fälschlich als Abbruch gemeldet.

## Persistenz

Schema v13 ergänzt genau einen `StockPolicyRecord` je Type-ID:

- UUID und Type-ID,
- Sicherheitsmenge,
- optionale Mindest-, Warn- und Zielmenge,
- Erstellungs- und Änderungszeitpunkt,
- interne Datensatzversion.

Die Migration v12→v13 ist additiv und erfindet keine Regeln. Backups bis
Format 13.0.0 sind lesbar; unbekannte neuere Formate werden abgelehnt.

## Bedienung

Im Produktionsgraphen öffnet `Sicherheitsbestände` eine eigene Ansicht. Sie
zeigt Eingaben, P22-Ausgang, Schutzanteile, verwendbare und ungedeckte
Mengen, prognostizierten Restbestand, Zielauffüllung und alle Warnungen. Eine
geänderte Vorschau muss vor dem atomaren Speichern bestätigt werden.

## Prüfnachweis

17 neue Domain-, Application- und Persistenztests decken Schutzformeln,
Grenzen, Schwellen, Vorschau/Bestätigung, Stale-State einschließlich eines
Repository-Rennens, Abbruch, atomare Änderungen, Löschung, Migration,
Leerstore und Wiederöffnung ab. Die UI-Schicht wird zusätzlich durch den
Architekturtest geprüft. SwiftPM und Xcode bestanden Debug und Release
jeweils mit 388 Tests ohne Fehler oder Übersprünge.
