# Entwicklertagebuch

Beim P00-Ausgangsstand waren keine früheren belastbaren Tagebucheinträge,
Abschlussberichte oder Projektcommits vorhanden; deshalb wurden keine
früheren Arbeiten rekonstruiert oder erfunden. Seit P09A besitzt `main` eine
geprüfte Root-Baseline.

## 2026-07-23 – P00: Entwickler-Cockpit

### Ausgangszustand

Swift-Package mit nativer SwiftUI/SwiftData-Grundversion, Projektbuch und README. Keine `Documentation/`-Struktur, keine Commit-Historie, Git-Wurzel im Benutzerverzeichnis, alle Projektdateien untracked. Vorhanden waren einfache Projekte, SSO/Keychain-Vorarbeiten, Platzhalteransichten, Python-Materialaggregation und zwei Tests.

### Ziel

Belastbare Dokumentations-, Prompt- und Fortschrittsstruktur für den reduzierten Produktionsplaner-MVP einrichten, ohne fachliche App-Funktionen zu implementieren.

### Durchgeführte Arbeiten

- AGENTS.md, Projektbuch, README, Quellcode, Package, Tests, SwiftPM-/Xcode-Metadaten und Git-Zustand analysiert.
- Projektbuch vollständig als Text extrahiert und repräsentative Seiten des 630-seitigen Renderings visuell geprüft.
- reduzierten MVP und verschobene Funktionen verbindlich dokumentiert.
- Dokumentationsbaum, Feature-Matrix, Status, Roadmap, offene Aufgaben, bekannte Probleme, Testhistorie und Architekturänderungen angelegt.
- P00–P47 registriert; P00 vollständig und P01–P47 als klar gekennzeichnete Entwürfe angelegt.
- Debug-Build und vorhandene Tests ausgeführt.

### Zentrale Entscheidungen

- Stufe A – lokaler Produktionsplaner ist der aktuelle Scope; umfassendes Projektbuch bleibt langfristiges Zielbild.
- Vorhandener SSO-/ESI-orientierter Code bleibt unangetastet, wird aber als Zukunftscode bewertet.
- SwiftPM ist der maßgebliche CLI-Buildweg; der generierte Xcode-Workspace war für `xcodebuild -list` nicht verwendbar.
- Kein Feature erhält allein wegen einer sichtbaren UI oder eines erfolgreichen Gesamtbuilds den Status erledigt.

### Neu erstellte Dateien

- alle Dateien unter `Documentation/`, einschließlich 48 Promptdateien und P00-Abschlussbericht.

### Geänderte Dateien

- Keine vorhandene Projekt- oder Quellcodedatei geändert.

### Build-Ergebnis

`swift build -c debug`: erfolgreich.

### Testergebnis

`swift test -c debug`: 2 Tests, 0 Fehler.

### Erkannte Probleme

- Git-Wurzel `/Users/svenstolze` statt Projektordner; keine Commits, keine `.gitignore`.
- MVP-Kernfunktionen fehlen weitgehend.
- fehlende Migrationen/Backups/zentrale Fehlerbehandlung/Logging.
- Python-Laufzeitkonfiguration inkonsistent; SSO-Code liegt außerhalb des aktuellen MVP.

### Nicht erledigte Punkte

- Keine fachliche App-Implementierung.
- Kein Release-Build, kein UI-Test, kein echter SSO-Test.
- Keine Git-Reparatur oder `.gitignore`, da dafür eine gesonderte Benutzerentscheidung sinnvoll ist.

### Aktualisierte Features

Alle Features wurden in `FEATURE_MATRIX.md` erstmalig erfasst und anhand des Codes bewertet; kein noch unbewiesenes Feature wurde auf erledigt gesetzt.

### Nächster Prompt

P01 – MVP-Abnahmekatalog und Scope-Gates.

## 2026-07-23 – P01: Dauerhafte Entwicklungsregeln

### Ausgangszustand

P00 hatte das Entwickler-Cockpit angelegt. Die vorhandene `AGENTS.md` enthielt lediglich eine leere Überschrift für importierte Claude-Cowork-Regeln. P01 war noch als Entwurf für einen MVP-Abnahmekatalog bezeichnet; dauerhafte Arbeits- und Reviewregeln fehlten. Der App-Ausgangsstand war kompilierbar, aber fachlich unverändert unvollständig.

### Ziel

Verbindliche repositoryweite Regeln für Scope, Arbeitsweise, Architektur, Datenintegrität, Berechnungen, Git, Build, Tests, Dokumentation, Definition of Done und unabhängige Reviews einrichten, ohne App-Funktionen zu implementieren.

### Durchgeführte Arbeiten

- Projektbuch einschließlich Anhänge, P00-Dokumentation, Abschlussbericht, Architektur- und Testdokumentation, Quellcode, Package-Metadaten und Git-Zustand geprüft.
- `AGENTS.md` kontrolliert zusammengeführt und mit 20 dauerhaften Regelbereichen vervollständigt.
- ausführliche, eigenständige Review- und Kontrollregeln erstellt.
- P01-Promptdatei an den tatsächlich beauftragten Regelumfang angepasst.
- aktive Steuerdateien, Roadmap, offene Aufgaben und Testhistorie konsistent aktualisiert.
- Debug-Build, vorhandene Tests sowie eine gesonderte Struktur-, Pfad- und Verlinkungsprüfung ausgeführt.

### Zentrale Entscheidungen

- Der reduzierte Stufe-A-MVP bleibt verbindlich; Zukunftsfunktionen werden nicht vorgezogen.
- Tatsächlicher Quellcode ist für Implementierungsstände maßgeblich, Projektbeschreibung und Projektbuch für geplante Anforderungen.
- Ein Implementierungsstatus `✅` setzt nachweisbaren Build, relevante Tests, Dokumentation, Abschlussbericht und unabhängige Kontrollprüfung voraus.
- Wegen der Git-Wurzel `/Users/svenstolze` müssen Git-Prüfungen eng auf den Projektordner begrenzt bleiben.

### Neu erstellte Dateien

- `Documentation/REVIEW_RULES.md`
- `Documentation/Prompts/MVP/P01_Dauerhafte-Entwicklungsregeln.md`
- `Documentation/Progress/Reports/2026-07-23_P01_Dauerhafte-Entwicklungsregeln.md`

### Geänderte Dateien

- `AGENTS.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/Prompts/README.md`
- `Documentation/IMPLEMENTATION_ROADMAP.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/TEST_HISTORY.md`

### Build-Ergebnis

`swift build -c debug`: erfolgreich, keine Warnungen im erfolgreichen Lauf.

### Testergebnis

`swift test -c debug`: 2 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler.

### Erkannte Probleme

- Git-Wurzel bleibt `/Users/svenstolze`; alle Projektdateien sind mangels Commit-Historie untracked.
- Die Testabdeckung ist unverändert schmal.
- Der fachliche Produktionsplaner-MVP fehlt weiterhin weitgehend.

### Nicht erledigte Punkte

- Keine fachliche App-Implementierung, Datenmodelländerung oder Migration.
- Keine Git-Reparatur, `.gitignore`-Einführung oder Änderung an Signing-/Team-Einstellungen.
- P02 wurde nicht begonnen.

### Aktualisierte Features

Keine Featurestatusänderung. `FEATURE_MATRIX.md` wurde gegen den unveränderten Quellcode geprüft; P01 betrifft ausschließlich Entwicklungsgovernance und Dokumentation.

### Nächster Prompt

P02 – Zielarchitektur und Modulgrenzen.

## 2026-07-23 – P02: Zielarchitektur und Modulgrenzen

### Ausgangszustand

Ein ausführbares SwiftPM-Target koppelte SwiftUI, SwiftData, SSO, Keychain und die Python-Prozessgrenze. Die Materialaggregation wurde über `/usr/bin/env python3` ausgeführt. Zwei XCTest-Fälle bestanden; explizite Domain-/Application-/Infrastructure-Grenzen existierten nicht.

### Ziel

Eine kompilierbare, inkrementell migrierbare Schichtenarchitektur schaffen, die bestehenden SwiftData-Store schützen, die Python-Grenze entscheiden und keine neue fachliche MVP-Funktion vorziehen.

### Durchgeführte Arbeiten

- Baseline-Targetgraph, Git-Zustand, Debug-Build und zwei Ausgangstests verifiziert.
- Targets `NewEdenNexusDomain`, `NewEdenNexusApplication` und `NewEdenNexusInfrastructure` eingeführt.
- Materialtypen und deterministische Aggregation in Domain implementiert.
- Application-Port und injizierbaren Use Case erstellt.
- nativen Swift-Adapter implementiert und Python-Prozess/Skript/Einstellung entfernt.
- SwiftData-Modelle unverändert im App-Target belassen.
- Architektur-, Paritäts-, Fehler- und Regressionstests ergänzt.
- Architekturübersicht und zwei ADRs erstellt.

### Zentrale Entscheidungen

- Inkrementelle SwiftPM-Schichtung statt sofortiger Vollmigration.
- Persistence folgt erst in P03 nach Erfassung der SwiftData-Schemaidentität.
- Native Swift-Berechnungsruntime statt externem oder gebündeltem Python.
- Kein ungenutzter Dependency-Container für einen noch nicht produktiv aufgerufenen Use Case.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/MaterialAggregation.swift`
- `Sources/NewEdenNexusApplication/SummarizeMaterialsUseCase.swift`
- `Sources/NewEdenNexusInfrastructure/NativeMaterialSummaryService.swift`
- `Tests/NewEdenNexusDomainTests/MaterialSummaryCalculatorTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- `Documentation/ARCHITECTURE.md`
- `Documentation/Architecture/ADRs/README.md`
- `Documentation/Architecture/ADRs/ADR-0001_Modul-und-Schichtenarchitektur.md`
- `Documentation/Architecture/ADRs/ADR-0002_Berechnungsruntime-Python-oder-Swift.md`

### Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- Architektur- und Fortschrittsdokumentation.

### Build-Ergebnis

- `swift build -c debug`: erfolgreich.
- `swift build -c release`: erfolgreich.
- keine Compilerwarnungen in den erfolgreichen Läufen.

### Testergebnis

`swift test -c debug`: 11 XCTest-Tests, 0 Fehler nach Korrektur der Decimal-zu-Double-Konvertierung. Der erste P02-Lauf hatte genau einen Paritätsfehler (`5.5600000000000005` statt `5.56`) und wurde nicht als Erfolg gewertet.

### Erkannte Probleme

- Presentation und SwiftData-Persistenz bleiben im App-Target gekoppelt.
- SwiftData besitzt noch keine explizite Schemaversion oder Migration.
- theoretisches `Int`-Überlaufverhalten ist noch nicht fachlich definiert.
- Git-Wurzel und `.gitignore` bleiben unverändert problematisch.

### Nicht erledigte Punkte

- keine neue Fachfunktion,
- keine SwiftData-Schemaänderung oder Migration,
- kein UI-, Persistenz-, SSO- oder Performance-Test,
- P03 nicht begonnen,
- P03 wurde nicht begonnen.

### Aktualisierte Features

- `TEC-009` neu: durchsetzbare Domain-/Application-/Infrastructure-Grenzen.
- `TEC-007`: Testnachweis von 2 auf 11 Tests erweitert, insgesamt weiterhin teilweise.
- `CAL-007`: Python-Aggregation durch native Swift-Aggregation mit Paritätsnachweis ersetzt; fachlich weiterhin nur teilweise.

### Nächster Prompt

P03 – Domänenmodell und Migrationen vollständig spezifizieren. Der gesonderte P02-Review wurde mit `✅ bestanden` abgeschlossen.

## 2026-07-23 – P03: Domänenmodell, Schema v1 und Migrationen

### Ausgangszustand

Nach P02 bestanden getrennte Domain-, Application- und Infrastructure-Targets. `CharacterRecord` und `ProductionProject` lagen jedoch weiterhin unversioniert im App-Target; der `ModelContainer` wurde dort direkt erzeugt. Es gab weder einen Migrationsplan noch ein persistenzfreies Projektdomänenmodell oder einen Repository-Port. Die Baseline bestand aus 11 erfolgreichen Tests.

### Ziel

Den bisherigen Store feldgenau versionieren, eine additive Migration auf Schema v1 nachweisen, Persistenz in einen eigenen Target verschieben und einen validierenden Domain-/Repository-Pfad für Produktionsprojekte schaffen, ohne spätere Fachentitäten oder Funktionen vorzuziehen.

### Durchgeführte Arbeiten

- P03 vollständig mit Scope, Abnahmekriterien, Migrations- und Reviewpflicht spezifiziert.
- `NewEdenNexusPersistence` und ein ausschließlich testseitiges Legacy-Fixture als SwiftPM-Targets ergänzt.
- Legacy-Schema 0.9.0, Schema v1 1.0.0 und Lightweight-Migration eingeführt.
- beide vorhandenen Entitäten um `recordVersion = 1` ergänzt.
- zentrale Containerfactory für Standard-, In-Memory- und explizite Dateistores erstellt.
- unveränderlichen `ProductionProjectSnapshot` mit typisierten Invarianten in Domain angelegt.
- asynchronen `ProductionProjectRepository`-Port in Application und `@ModelActor`-SwiftData-Adapter in Persistence implementiert.
- App auf die versionierte Factory und die ausgelagerten Persistenztypen umgestellt.
- Domain-, Architektur-, Leerstore-, Repository-, Mapping- und vollständige Legacy-Migrationstests ergänzt.
- Datenmodell, Architektur, ADR-0003 und Fortschrittsdokumentation aktualisiert.

### Zentrale Entscheidungen

- Das Legacy-Schema wird als Version 0.9.0 explizit und feldgleich erhalten.
- Schema v1 ist ausschließlich additiv; SDE-, Bestands-, Preis- oder Graphentitäten bleiben ihren späteren Prompts vorbehalten.
- Ein Migrationsfehler bricht das Öffnen ab; es gibt keinen Store-Reset oder stillen Leerstore-Fallback.
- Persistenzrecords werden nur über ein validierendes Mapping als Domain-Snapshots ausgegeben.
- Direkte SwiftData-Viewzugriffe bleiben als dokumentierte Übergangsschuld bestehen; ihr sichtbarer Workflow wird in P03 nicht verändert.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionProject.swift`
- `Sources/NewEdenNexusApplication/ProductionProjectRepository.swift`
- `Sources/NewEdenNexusPersistence/NexusLegacySchema.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV1.swift`
- `Sources/NewEdenNexusPersistence/NexusMigrationPlan.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProductionProjectRepository.swift`
- `Tests/Fixtures/NewEdenNexusLegacySchema/LegacyModels.swift`
- `Tests/NewEdenNexusPersistenceTests/NexusPersistenceTests.swift`
- `Tests/NewEdenNexusDomainTests/ProductionProjectSnapshotTests.swift`
- `Documentation/DATA_MODEL.md`
- `Documentation/Architecture/ADRs/ADR-0003_SwiftData-Schema-v1-und-Persistenzgrenze.md`
- `Documentation/Progress/Reports/2026-07-23_P03_Domaenenmodell-Schema-v1-und-Migrationen.md`

### Geänderte Dateien

- `Package.swift`
- App-Imports, Navigation und Composition Root
- Architekturtests und vorhandene App-Regressionstests
- Architektur-, ADR-, Status-, Roadmap-, Feature-, Prompt- und Qualitätsdokumentation
- die frühere App-Datei `Sources/NewEdenNexus/Models.swift` wurde nach kontrollierter Verlagerung der Modelle entfernt.

### Build-Ergebnis

- `swift package describe`: fünf produktive Targets, vier Testtargets und ein Legacy-Fixture-Target bestätigt.
- `swift build -c debug`: erfolgreich.
- `swift build -c release`: erfolgreich.
- keine Compilerwarnungen in den erfolgreichen Abschlussläufen.

### Testergebnis

`swift test -c debug`: **26 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler**. Der Migrationstest erhielt sämtliche festen Werte beider Legacy-Entitäten, setzte die Datensatzversion auf 1 und öffnete denselben migrierten temporären Store ein zweites Mal erfolgreich.

Während der Implementierung wurden zwei Compileprobleme behoben: ein SwiftData-Prädikat durfte keine Snapshot-Keypath-Erfassung enthalten, und gleichnamige Fixture-/v1-Typen mussten in Tests qualifiziert werden. Außerdem wurde das zunächst vor der Testdatei registrierte neue Testtarget anschließend vollständig befüllt. Kein fehlgeschlagener Zwischenlauf wurde als Erfolg gewertet.

### Erkannte Probleme

- Backup und Restore fehlen bis P06; ein Downgrade auf den unversionierten Stand wird nicht unterstützt.
- vorhandene Views greifen weiterhin direkt über `@Query` und `modelContext` zu.
- Containerfehler enden bis P04 weiterhin in `fatalError`; einzelne UI-Speicherpfade verwenden `try?`.
- Git-Wurzel und fehlende `.gitignore` bleiben außerhalb des P03-Scopes.

### Nicht erledigte Punkte

- keine SDE-, Blueprint-, Graph-, Bestands-, Preis- oder Einkaufslistenentität,
- kein Backup/Restore oder Recovery-Drill,
- kein UI-, SSO-/Netzwerk-, Performance- oder Accessibility-Test,
- keine Git-Reparatur, kein Commit und keine Signing-Änderung.

### Aktualisierte Features

- `TEC-004` versionierte Migrationen ist für den aktuellen v1-Pfad nachgewiesen vorhanden.
- `TEC-009` umfasst nun Domain, Application, Infrastructure und Persistence.
- `TEC-003`, `TEC-007`, `PRJ-001` und `PRJ-002` besitzen zusätzliche Persistenz-, Invarianten- und Repositorynachweise, bleiben wegen des begrenzten MVP-Stands teilweise.

### Nächster Prompt

P04 – Fehlerbehandlung und Logging vollständig spezifizieren. Der gesonderte P03-Review wurde mit `✅ bestanden` abgeschlossen.

## 2026-07-23 – P04: Fehlerbehandlung und Logging

### Ausgangszustand

Nach P03 waren Debug-/Release-Build und 26 Tests grün. Ein Fehler beim Öffnen der SwiftData-Datenbank führte jedoch zu `fatalError`. Projektanlage, Charakterlöschung und simulierter Synchronisationsstatus verwarfen Speicherfehler mit `try? modelContext.save()`. Die Accountansicht zeigte ungefiltertes `localizedDescription`; ein Logger-Port, Redaktionsregeln und ein fortlaufendes Offene-Punkte-Audit fehlten.

### Ziel

Eine zentrale, UI-unabhängig testbare Fehlertaxonomie, strukturierte und datenschutzgerechte Unified-Log-Diagnosen sowie einen sicheren Start- und Laufzeitfehlerfluss implementieren. Zusätzlich sollte `Documentation/OFFEN.md` künftig alle Restpunkte wiederkehrend gegen den realen Stand prüfen.

### Durchgeführte Arbeiten

- P04 vollständig mit Fehlerfällen, Redaktionsregeln, Tests und Abnahmekriterien spezifiziert.
- acht Operationen mit stabilen Diagnosecodes, Kategorien, Leveln und sicheren UI-Texten in Application eingeführt.
- strukturierte Diagnoseereignisse, Public-/Private-Metadaten und `DiagnosticLogging`-Port erstellt.
- `UnifiedDiagnosticLogger` mit OSLog-Subsystem und ereignisbasierter Kategorie in Infrastructure implementiert.
- injizierbare `NexusAppRuntime` mit `loading`/`ready`/`failed`, Start-Retry und zentraler Fehlerpräsentation erstellt.
- `fatalError` durch eine sichere Startfehleransicht ersetzt.
- alle drei `try? modelContext.save()`-Pfade auf `do/catch`, Rollback und zentrale Meldung umgestellt.
- Accountfehler von technischen Rohtexten getrennt.
- Keychain-Ersetzen verwendet `SecItemUpdate` ohne vorherigen Datenverlust; echte OSStatus-Löschfehler werden geworfen und `errSecItemNotFound` bleibt idempotent.
- Mapping-, Secret-Sentinel-, Redaction-, Runtime-, Retry-, Quellcode- und zusätzliche Architekturtests ergänzt.
- Fehler-/Loggingdokumentation und ADR-0004 erstellt.
- `OFFEN.md` angelegt, alle aktiven Punkte geprüft und P04-Punkt mit Nachweis erledigt.

### Zentrale Entscheidungen

- Fehlertaxonomie und Logger-Port leben in Application; OSLog bleibt ein Infrastructure-Adapter.
- Rohfehlertexte werden weder in UI noch Diagnoseereignisse übernommen.
- private Metadaten werden als `<redacted>` gerendert.
- die App-Runtime erhält Logger und Containerfactory per Injection statt globaler Singletons.
- ein Datenbankstartfehler erzeugt weder Reset noch Ersatzstore.
- Keychain und SwiftData bleiben technisch getrennte Transaktionen; diese Grenze ist als `OFF-013` bis P38 offen.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusInfrastructure/UnifiedDiagnosticLogger.swift`
- `Sources/NewEdenNexus/NexusAppRuntime.swift`
- `Sources/NewEdenNexus/ErrorPresentation.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `Documentation/ERROR_HANDLING_AND_LOGGING.md`
- `Documentation/OFFEN.md`
- `Documentation/Architecture/ADRs/ADR-0004_Zentrale-Fehler-und-Diagnosegrenze.md`
- `Documentation/Progress/Reports/2026-07-23_P04_Fehlerbehandlung-und-Logging.md`

### Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Sources/NewEdenNexus/ProjectsView.swift`
- `Sources/NewEdenNexus/AccountsView.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Sources/NewEdenNexus/KeychainStore.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- `AGENTS.md`
- Architektur-, ADR-, Status-, Roadmap-, Feature-, Prompt-, Problem- und Testdokumentation.

### Build-Ergebnis

- `swift package describe`: fünf produktive Targets, fünf Testtargets und Legacy-Fixture bestätigt.
- `swift build -c debug`: erfolgreich.
- `swift build -c release`: erfolgreich.
- keine Compilerwarnungen in den erfolgreichen Abschlussläufen.

Der erste nicht eskalierte `swift package describe`-Versuch scheiterte ausschließlich am gesperrten systemweiten Swift-/Clang-Cache. Derselbe Befehl wurde mit erlaubtem Cachezugriff erfolgreich wiederholt; der Sandboxfehler wurde nicht als Projektfehler oder Erfolg ausgegeben.

### Testergebnis

`swift test -c debug`: **34 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler**.

Neu sind drei Application-Tests, vier App-/Runtime-Regressionsprüfungen und ein zusätzlicher Infrastructure-Architekturtest. Alle 26 P03-Tests blieben erfolgreich.

### Erkannte Probleme

- Keychain und SwiftData können nicht in einer gemeinsamen atomaren Transaktion geändert werden.
- direkte SwiftData-Fachzugriffe bleiben in vorhandenen Views.
- vollständige Lokalisierung und manuelle UI-/Accessibility-Prüfung fehlen.
- Git-Wurzel, `.gitignore`, Backups und die fachlichen MVP-Kernbereiche bleiben offen.

### Nicht erledigte Punkte

- keine neue Produktions-, SDE-, Bestands-, Preis- oder Einkaufslistenfunktion,
- keine Telemetrie, Logdatei, Diagnoseexport oder Cloudlogging,
- kein ESI-Retry/Backoff,
- kein Backup/Restore,
- kein UI-, echter SSO-/Netzwerk-, Performance- oder Accessibility-Test,
- keine Git-, Signing- oder Schemamigration.

### Aktualisierte Features

- `TEC-005` zentrale Fehlerbehandlung ist für den aktuellen technischen Stand nachgewiesen vorhanden.
- `TEC-006` strukturiertes Logging ist mit Redaction-Nachweis vorhanden.
- `TEC-007` umfasst jetzt 34 Tests.
- `TEC-003`, `TEC-009` und `PRJ-002` besitzen zusätzliche Start-, Architektur- und Fehlerflussnachweise.

### Nächster Prompt

P05 – Testfundament und Referenzdaten vollständig spezifizieren. Der gesonderte P04-Review wurde mit `✅ bestanden` abgeschlossen.

## 2026-07-23 – OFF-001: Git-Wurzel begrenzen

### Ausgangszustand

Git behandelte `/Users/svenstolze` als Wurzel. Der Projektordner besaß kein eigenes `.git`-Verzeichnis und erschien vollständig untracked innerhalb des Home-Repositories.

### Ziel

Den Projektordner als eigenständige Git-Wurzel einrichten, ohne Dateien oder Git-Metadaten im Benutzerverzeichnis zu löschen, zu verschieben, zu bereinigen, zu stagen oder zu committen.

### Durchgeführte Arbeiten

- Home- und Projektroot, Branch, Commitstand und `.git`-Existenz geprüft.
- Inode, Änderungszeit und Größe von `/Users/svenstolze/.git` vor der Änderung erfasst.
- im Projektordner ein leeres Repository auf Branch `main` initialisiert.
- Projekt- und Home-Root sowie Home-`.git`-Metadaten danach erneut geprüft.
- OFF-001, bekannte Probleme, Projektstatus, Entwickler-Menü, AGENTS-Regel und Abschlussbericht aktualisiert.

### Zentrale Entscheidungen

- Das Home-Repository wird nicht verschoben oder entfernt.
- Eine verschachtelte eigenständige Projektwurzel begrenzt alle Projekt-Git-Befehle sicher.
- `.gitignore` und Erstcommit bleiben getrennte, nicht automatisch ausgeführte Aufgaben.

### Neu erstellte Dateien

- Projektmetadaten `.git/`
- `Documentation/Progress/Reports/2026-07-23_OFF-001_Git-Wurzel.md`

### Geänderte Dateien

- `AGENTS.md`
- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/TEST_HISTORY.md`

### Build-Ergebnis

Nicht erneut ausgeführt; App-Code, Package und Buildkonfiguration wurden nicht geändert.

### Testergebnis

Keine App-Tests erneut ausgeführt. Repositoryprüfungen bestätigten die neue Projektwurzel und identische Home-`.git`-Metadaten.

### Erkannte Probleme

- `.gitignore` fehlt weiterhin.
- Branch `main` besitzt noch keinen Commit; alle Projektdateien sind untracked.

### Nicht erledigte Punkte

- keine Datei gestaged oder committed,
- Home-Repository weder verändert noch entfernt,
- keine `.gitignore` erstellt,
- keine App- oder Fachänderung.

### Aktualisierte Features

Keine Featureänderung. Ausschließlich Repositorysicherheit und Dokumentationsstatus wurden aktualisiert.

### Nächster Prompt

P05 bleibt der nächste Produktprompt. OFF-002 kann separat beauftragt werden.

## 2026-07-23 – OFF-002: Projektbezogene Gitignore

### Ausgangszustand

Die eigenständige Projekt-Git-Wurzel besaß keine `.gitignore`. `.DS_Store`, `.build`, `.swiftpm` und generierte Xcode-Benutzerdaten erschienen als untracked.

### Ziel

Generierte und rein lokale Artefakte gezielt ignorieren, ohne Sources, Tests, Dokumentation oder reproduzierbare Projektdateien auszublenden.

### Durchgeführte Arbeiten

- vorhandene macOS-, SwiftPM- und Xcode-Artefakte inventarisiert.
- `.gitignore` für macOS-Metadaten, SwiftPM-Buildzustand, Xcode-Benutzerdaten/DerivedData, lokale Umgebungsdateien und Editorreste erstellt.
- jede vorhandene und repräsentative Regel mit `git check-ignore -v` geprüft.
- mit Negativprüfungen bestätigt, dass Sources, Dokumentation, `Package.swift`, `Package.resolved` und `.env.example` sichtbar bleiben.
- alle übrigen aktiven OFFEN-Einträge erneut gegen Source-Inventar und Metadaten geprüft.
- Status-, Problem-, Tagebuch-, Test- und Abschlussdokumentation aktualisiert.

### Zentrale Entscheidungen

- `Package.resolved` bleibt versionierbar.
- `.env.example` bleibt trotz `.env.*`-Regel sichtbar.
- der gesamte `.swiftpm`-Workspace gilt als generierter lokaler Zustand.
- keine breite Regel ignoriert Projektbücher, Dokumentation, Sources oder Tests.

### Neu erstellte Dateien

- `.gitignore`
- `Documentation/Progress/Reports/2026-07-23_OFF-002_Gitignore.md`

### Geänderte Dateien

- `Documentation/OFFEN.md`
- `Documentation/OPEN_TASKS.md`
- `Documentation/KNOWN_ISSUES.md`
- `Documentation/DEVELOPER_MENU.md`
- `Documentation/CURRENT_PROJECT_STATUS.md`
- `Documentation/DEVELOPER_DIARY.md`
- `Documentation/TEST_HISTORY.md`

### Build-Ergebnis

Nicht erneut ausgeführt; App-Code, Package und Buildkonfiguration wurden nicht verändert.

### Testergebnis

Keine App-Tests erneut ausgeführt. Alle Ignore- und Nicht-Ignore-Fälle wurden mit Git-Bordmitteln erfolgreich geprüft.

### Erkannte Probleme

- Branch `main` besitzt weiterhin keinen Commit.
- Xcode bietet weiterhin nur den generierten SwiftPM-Workspace; OFF-014 bleibt offen.

### Nicht erledigte Punkte

- nichts gestaged oder committed,
- keine Datei gelöscht oder verschoben,
- keine App- oder Fachänderung,
- kein Xcode-Projekt erzeugt.

### Aktualisierte Features

Keine Featureänderung. Ausschließlich Repository-Hygiene und offene Punkte wurden aktualisiert.

### Nächster Prompt

P05 bleibt der nächste Produktprompt. Ein Erstcommit benötigt einen ausdrücklichen Auftrag.

## 2026-07-23 – P05: Testfundament und Referenzdaten

### Ausgangszustand

P05 lag nur als kurzer Entwurf vor. 34 Tests waren grün, aber es gab kein gemeinsam ladbares Referenzpaket, keinen gemeinsamen Projekt-Builder und die temporäre Storelogik war im Persistenztest dupliziert.

### Ziel

Den Prompt vollständig spezifizieren und eine reproduzierbare, versionierte, synthetische und produktdatenfreie Testbasis schaffen, ohne SDE- oder Produktionsfachlogik vorwegzunehmen.

### Durchgeführte Arbeiten

- Kapitel 32 und Anhang F des vollständigen Projektbuchs gegen reduzierten MVP und Quellcode abgeglichen.
- P05 um Referenzfälle, Sollwerte, Coverage-Ziele, Dateien, Befehle und Abnahmekriterien ergänzt.
- `NewEdenNexusTestSupport` und eigenes Testtarget eingerichtet.
- Fixture `foundation-reference` v1.0.0 mit drei stabilen Test-IDs erstellt.
- Offline-Loader mit Datensatz-/Schemaversionsprüfung und Schutz vor doppelten IDs implementiert.
- deterministischen Projekt-Builder und temporären Store-Helfer implementiert.
- Persistenztests auf den gemeinsamen Store-Helfer umgestellt.
- Domain-Referenztests und TestSupport-Tests ergänzt.
- providerneutralen Prüfskript-Einstieg mit eigenen temporären Modul-Caches erstellt.
- Teststrategie, Architektur und ADR-0005 dokumentiert.
- sämtliche aktiven OFFEN-Punkte erneut geprüft.

### Zentrale Entscheidungen

- Fixture-Daten sind ausdrücklich synthetisch und keine SDE-Wahrheit.
- SDE- und ESI-Version bleiben bis zu den zuständigen Prompts leer.
- TestSupport wird nicht als Produkt exportiert und ist keine produktive Abhängigkeit.
- Coverage dient als Trend- und Risikosignal; fachliche Referenzfälle bleiben maßgeblich.

### Neu erstellte Dateien

- `Tests/NewEdenNexusTestSupport/`
- `Tests/NewEdenNexusTestSupportTests/TestSupportTests.swift`
- `Tests/NewEdenNexusDomainTests/ReferenceDatasetTests.swift`
- `Scripts/ci-verify.sh`
- `Documentation/TEST_STRATEGY.md`
- `Documentation/Architecture/ADRs/ADR-0005_Testfundament-und-versionierte-Referenzdaten.md`
- `Documentation/Progress/Reports/2026-07-23_P05_Testfundament-und-Referenzdaten.md`

### Geänderte Dateien

- `Package.swift`
- `Tests/NewEdenNexusPersistenceTests/NexusPersistenceTests.swift`
- P05-Prompt, Architektur-, Status-, Feature-, OFFEN-, Aufgaben-, Problem-, Tagebuch- und Testdokumentation

### Build-Ergebnis

`swift package describe`, Debug-Build, Release-Build und `./Scripts/ci-verify.sh` erfolgreich. Keine Compilerwarnung im erfolgreichen Gesamtlauf.

### Testergebnis

Debug mit Coverage und Release jeweils 40 Tests, 0 Fehler, 0 unerwartete Fehler, keine übersprungenen XCTest-Tests. Domain/Application-Coverage: 99,31 %.

### Erkannte Probleme

Der erste SwiftPM-Aufruf in der Dateisandbox konnte Benutzer-Modulcaches beziehungsweise den verschachtelten Swift-Sandboxprozess nicht verwenden. Der Prüfeinstieg nutzt nun eigene temporäre Modul-Caches; die eigentlichen SwiftPM-Läufe wurden außerhalb der Dateisandbox erfolgreich wiederholt.

### Nicht erledigte Punkte

- keine echten SDE- oder Produktionsreferenzen,
- keine UI-, E2E-, Last-, Backup- oder Netzwerkfixtures,
- kein produktives Schema geändert,
- nichts gestaged, committed oder gepusht.

### Aktualisierte Features

- TEC-007 – automatisierte Tests,
- TEC-010 – versionierte Referenzdaten und gemeinsame Testhelfer.

### Nächster Prompt

P06 – Lokale Backups zunächst vollständig spezifizieren und anschließend getrennt ausführen.

## 2026-07-23 – P06: Lokale Backups

### Ausgangszustand

P06 lag als kurzer Entwurf vor. Schema v1 und temporäre Storehelfer waren vorhanden, aber es gab keinen Backupvertrag, kein Paketformat, keine Integritätsprüfung und keinen Restore-Ablauf.

### Ziel

Eine sichere, versionierte und UI-unabhängige technische Backup-/Restore-Grenze für den lokalen SwiftData-Store implementieren, ohne Fachfunktionen oder eine vorgezogene Recovery-UI zu ergänzen.

### Durchgeführte Arbeiten

- Projektbuchkapitel zu Backup, Wiederherstellung, Integrität und Aufbewahrung gegen Quellcode und MVP abgeglichen.
- P06 mit Format-, Sicherheits-, Fehler-, Referenz- und Abnahmekriterien vollständig spezifiziert.
- Application-Port, Manifest, Vorschau, Bestätigung, Zielstatus, Ergebnis und Fehlerfälle ergänzt.
- SQLite-Online-Snapshot und immutable Integritätsprüfung implementiert.
- versioniertes `.nenbackup`-Paket mit SHA-256, privaten Dateirechten und atomischer Veröffentlichung implementiert.
- read-only Vorschau und Ziel-Fingerabdruck über Hauptdatei, WAL und SHM implementiert.
- bestätigten Restore mit Sicherheitsbackup, vorbereitetem Zielersatz und kontrolliertem Sidecar-Rollback implementiert.
- drei zentrale Backup-Fehleroperationen und stabile Codes ergänzt.
- acht Integrationstests mit echten temporären SwiftData-Stores erstellt.
- Paketformat, ADR-0006, Architekturänderung und Pflichtdokumentation aktualisiert.
- alle aktiven OFFEN-Punkte erneut geprüft.

### Zentrale Entscheidungen

- SQLite-Online-Backup statt unkoordinierter Kopie von Hauptdatei/WAL/SHM.
- Verzeichnispaket statt Archiv; Formatversion 1 bleibt unkomprimiert.
- keine anwendungseigene Verschlüsselung; Keychain-Tokens sind ausgeschlossen.
- `keep all`, keine automatische Löschung.
- Restore nur nach Vorschau, Bestätigung, Closed-Store-Erklärung und Sicherheitsbackup.
- UI, Zeitplan, automatische Vor-Migrations-Auslösung und End-to-End-Recovery bleiben P36.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/LocalBackupManagement.swift`
- `Sources/NewEdenNexusPersistence/SQLiteDatabaseSnapshot.swift`
- `Sources/NewEdenNexusPersistence/SQLiteLocalBackupService.swift`
- `Tests/NewEdenNexusPersistenceTests/SQLiteLocalBackupServiceTests.swift`
- `Documentation/BACKUP_AND_RESTORE.md`
- `Documentation/Architecture/ADRs/ADR-0006_Versioniertes-lokales-Backupformat.md`
- `Documentation/Progress/Reports/2026-07-23_P06_Lokale-Backups.md`

### Geänderte Dateien

- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ArchitectureBoundaryTests.swift`
- P06-Prompt, ADR-Register, Architektur-, Status-, Feature-, OFFEN-, Aufgaben-, Problem-, Tagebuch- und Testdokumentation

### Build-Ergebnis

`swift package describe`, Debug-Build, Release-Build und der providerneutrale Gesamtlauf erfolgreich. Keine Compilerwarnung im erfolgreichen Abschlusslauf.

### Testergebnis

Debug mit Coverage und Release jeweils 48 Tests, 0 Fehler, 0 unerwartete Fehler. Der erste Lauf deckte einen SQLite-read-only-WAL-Fehler auf; die Integritätsprüfung wurde auf immutable SQLite-Zugriff korrigiert und vollständig erneut geprüft.

### Erkannte Probleme

- Der technische Dienst kann einen geschlossenen SwiftData-Container nicht selbst beweisen.
- automatische Vor-Migrations-Auslösung und Restore-UI fehlen.
- unkomprimiertes `keep all` benötigt später Speicherort- und Rotationsverwaltung.

### Nicht erledigte Punkte

- keine UI und kein App-Neustart-Recovery-Drill,
- keine Cloud-, Netzwerk-, Kompressions- oder Verschlüsselungsfunktion,
- keine produktive Schema- oder Benutzerdatenänderung,
- keine SDE- oder sonstige Fachfunktion,
- nichts gestaged, committed oder gepusht.

### Aktualisierte Features

- `TEC-003` – lokaler Store mit technischer Sicherungsgrenze,
- `TEC-004` – Grundlage für künftige Vor-Migrations-Sicherung,
- `TEC-005` – zentrale Backup-Fehlercodes,
- `TEC-007` – 48 Tests,
- `TEC-008` – Backup/Restore technisch teilweise vorhanden,
- `TEC-009` – Backup-Port wahrt die Schichtengrenze.

### Nächster Prompt

P07 – SDE-Importpipeline vollständig spezifizieren; P07 nicht automatisch implementieren.

## 2026-07-23 – P07: SDE-Importpipeline

### Ausgangszustand

P07 lag nur als Entwurf vor. Es gab weder SDE-Importvertrag noch Dateiadapter, Prüfsummenbindung, Stagingformat oder SDE-spezifische Tests. Das produktive Schema enthielt ausschließlich Charakter- und Projektmodelle.

### Ziel

Einen lokal entpackten offiziellen JSONL-SDE-Stand blockweise und reproduzierbar prüfen und ohne Aktivierung unvollständiger Daten als versioniertes technisches Paket stagen.

### Durchgeführte Arbeiten

- vollständiges Projektbuch zu statischen Daten, Importablauf und Importtests ausgewertet,
- aktuelle offizielle CCP-SDE-Dokumentation, Formatangaben und Lizenzgrenze geprüft,
- P07 mit Quelle, Format, Fehlern, Referenzfällen und Abnahmekriterien vollständig spezifiziert,
- UI- und adapterfreien `SDEImporting`-Port ergänzt,
- blockweisen JSONL-Dateiadapter mit SHA-256 implementiert,
- UTF-8-, JSON-, Objekt-, Zeilengrößen- und vollständige `_key`-Validierung umgesetzt,
- read-only Vorschau mit festen Datensatzbeschreibungen und kanonischem Gesamthash umgesetzt,
- `.nensde`-Paketformat Version 1 mit Manifest und restriktiven Rechten umgesetzt,
- Kopien erneut geprüft und mit der Vorschau verglichen,
- atomare Veröffentlichung und Bereinigung unvollständiger Pakete umgesetzt,
- Task-Abbruch ohne Veröffentlichung abgesichert,
- zentrale sichere SDE-Fehlercodes ergänzt,
- versionierte synthetische JSONL-Fixtures mit festem Referenzhash erstellt,
- 18 SDE-Import-/Validierungstests und einen TestSupport-Test ergänzt,
- SDE-Dokumentation und ADR-0007 erstellt,
- alle aktiven OFFEN-Punkte erneut geprüft.

### Zentrale Entscheidungen

- offizielles JSON Lines statt YAML,
- lokal entpacktes Verzeichnis als P07-Eingabe; Download und ZIP folgen später,
- vier Pflichtdateien: Kategorien, Gruppen, Typen und Blueprints,
- lokale SHA-256-Bindung ohne Behauptung einer offiziellen CCP-Signatur,
- Staging vor Schema/Mapping/Aktivierung,
- `keep all` für erfolgreiche Pakete,
- keine echten SDE-Inhalte im Repository.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/SDEImportManagement.swift`
- `Sources/NewEdenNexusInfrastructure/JSONLinesSDEImportService.swift`
- `Tests/NewEdenNexusInfrastructureTests/JSONLinesSDEImportServiceTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/JSONLinesSDEImportValidationTests.swift`
- `Tests/NewEdenNexusTestSupport/SDEReferenceFixture.swift`
- `Tests/NewEdenNexusTestSupport/Fixtures/SDE/v1/`
- `Documentation/SDE_IMPORT.md`
- `Documentation/Architecture/ADRs/ADR-0007_JSONL-SDE-Stagingpaket.md`
- `Documentation/Progress/Reports/2026-07-23_P07_SDE-Importpipeline.md`

### Geänderte Dateien

- `Package.swift`
- `Sources/NewEdenNexusApplication/ErrorHandling.swift`
- `Tests/NewEdenNexusApplicationTests/ErrorHandlingTests.swift`
- `Tests/NewEdenNexusTestSupportTests/TestSupportTests.swift`
- P07-Prompt, Promptregister, ADR-Register, Architektur-, Status-, Feature-, OFFEN-, Aufgaben-, Problem-, Tagebuch- und Testdokumentation

### Build-Ergebnis

`swift package describe`, Debug-Build und Release-Build über `./Scripts/ci-verify.sh` erfolgreich. Im erfolgreichen Abschlusslauf wurden keine Compilerwarnungen ausgegeben.

### Testergebnis

Debug mit Coverage und Release jeweils 67 Tests, 0 Fehler, 0 unerwartete Fehler. Davon 18 SDE-Import-/Validierungstests. Coverage des Dateiadapters: 90,54 %.

Ein zusätzlicher Review-Test zeigte zunächst, dass Foundation den JSON-Boolean `true` numerisch als `1` brücken konnte. `_key` schließt `CFBoolean` nun ausdrücklich aus. Gezielte Tests und der vollständige Debug-/Release-Pfad wurden danach erfolgreich wiederholt.

### Erkannte Probleme

- kein realer aktueller CCP-SDE-Großdatensatz geprüft,
- Netzwerkdownload, ZIP-Extraktion, Mapping und Aktivierung fehlen,
- keine Performance- oder Lastmessung,
- Projektbranch besitzt weiterhin keine Commit-Historie.

### Nicht erledigte Punkte

- keine SwiftData-SDE-Entitäten oder Migration,
- kein Item-/Blueprintkatalog oder Rezeptresolver,
- keine SDE-UI,
- keine Fachfunktion außerhalb P07,
- nichts gestaged, committed oder gepusht.

### Aktualisierte Features

- `DAT-000` – technische SDE-Validierung und Staging,
- `DAT-001` bis `DAT-005` – technische Eingabegrenze vorhanden, fachlich weiterhin teilweise,
- `TEC-005` – sichere SDE-Fehlercodes,
- `TEC-007` – 67 Tests,
- `TEC-010` – synthetische SDE-Referenzfixture.

### Nächster Prompt

P08 – Statisches Datenschema vollständig spezifizieren und anschließend getrennt ausführen.

## 2026-07-23 – P08: Statisches Datenschema

### Ausgangszustand

P07 lieferte ein technisch validiertes `.nensde`-Paket, aber noch kein
fachliches Mapping, kein statisches SwiftData-Modell, keine Aktivierung und
keinen Realtest. Das aktuelle Schema war v1 mit Charakter und Projekt.

### Ziel

Kategorien, Gruppen, Typen, Blueprints, Aktivitäten, Materialien und Produkte
versioniert, referenzgeprüft und atomar aktivierbar speichern.

### Durchgeführte Arbeiten

- P08 mit Feldmapping, Index-, Migrations-, Referenz- und Aktivierungsregeln
  vollständig spezifiziert,
- offiziellen JSONL-Build 3424810 temporär geprüft,
- Schema v2 mit acht statischen Entitäten ergänzt,
- additive Migration v1 → v2 implementiert,
- UI-freie Katalogsnapshots, Ports und Import-Use-Case ergänzt,
- blockweises Mapping mit erneuter Manifest-/Hashprüfung implementiert,
- Referenz- und Wertebereichsvalidierung vor dem Schreiben umgesetzt,
- versionierte atomare Aktivierung, Rollback, Idempotenz und Rückfallstand
  implementiert,
- Backup-Schemabindung auf 2.0.0 aktualisiert und 1.0.0 kompatibel gehalten,
- synthetische Fixture um Manufacturing, Invention und Reaction erweitert,
- 16 neue Tests sowie P07-/Backupregressionen ergänzt,
- offiziellen Datenstand bis zur Store-Wiederöffnung geprüft,
- Pflichtdokumentation, ADR-0008 und OFFEN-Audit aktualisiert.

### Zentrale Entscheidungen

- eindeutige versionsgebundene `identityKey`s statt Überschreiben,
- alte SDE-Stände bleiben als inaktive Rückfallversion erhalten,
- IDs und Zeiten dürfen gemäß Realstand `0` sein,
- 21 fehlende offizielle Typreferenzen werden erhalten und als nicht aufgelöst
  markiert; keine Platzhalteritems,
- Namenssuche folgt P09, fachliche Ablehnung nicht aufgelöster Rezepte P10.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/StaticDataCatalog.swift`
- `Sources/NewEdenNexusInfrastructure/JSONLinesSDECatalogMapper.swift`
- `Sources/NewEdenNexusInfrastructure/SDEContentHash.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV2.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataStaticDataCatalogRepository.swift`
- `Tests/NewEdenNexusInfrastructureTests/JSONLinesSDECatalogMapperTests.swift`
- `Tests/NewEdenNexusPersistenceTests/StaticDataCatalogRepositoryTests.swift`
- `Tests/NewEdenNexusPersistenceTests/OfficialSDEPersistenceIntegrationTests.swift`
- `Documentation/Architecture/ADRs/ADR-0008_Versionierter-SDE-Stammdatenkatalog.md`
- `Documentation/Progress/Reports/2026-07-23_P08_Statisches-Datenschema.md`

### Geänderte Dateien

- `Package.swift`
- SDE-Import-, Fehler-, Schema-, Migrations-, Container- und Backupcode,
- synthetische SDE-Fixture und zugehörige Tests,
- alle verpflichtenden Status-, Architektur-, Datenmodell-, Test- und
  Fortschrittsdokumente.

### Build-Ergebnis

`./Scripts/ci-verify.sh` bestätigte Packagegraph, Debug-Build und
Release-Build. Im erfolgreichen Abschlusslauf wurden keine Compilerwarnungen
ausgegeben.

### Testergebnis

Debug mit Coverage und Release jeweils 83 Tests, 0 Fehler und 0 unerwartete
Fehler. Der separate offizielle SDE-E2E-Test bestand in 18,765 Sekunden.

Coverage: alle Dateien 77,90 %, produktive Sources 64,14 %, Mapper 82,42 %,
Aktivierungsrepository 93,26 %.

### Erkannte Probleme

- der offizielle Build enthält 21 nicht aufgelöste Typreferenzen,
- automatische Vor-Migrations-Sicherung fehlt weiterhin,
- Namenssuche, Rotation und Performancebudgets fehlen.

### Nicht erledigte Punkte

- keine Katalog-UI oder Suche,
- kein Rezeptresolver und keine Produktionsberechnung,
- kein In-App-Download/ZIP,
- kein produktiver Benutzerstore,
- nichts gestaged, committed oder gepusht.

### Aktualisierte Features

- `TEC-003`, `TEC-004`, `TEC-005`, `TEC-007`, `TEC-008`,
- `DAT-000` bis `DAT-005`,
- `OFF-015` erledigt, `OFF-016` neu für P10.

### Nächster Prompt

P09 – Item- und Blueprintkatalog vollständig spezifizieren und ausführen.

## 2026-07-23 – P09: Item- und Blueprintkatalog

### Ausgangszustand

P08 hatte den statischen SDE-Katalog als Schema v2 versioniert gespeichert und
aktiviert. Es fehlten Application-Verträge, ID-Lookups, Namenssuche, fachliche
Filter, Begrenzung und messbare Abfrageperformance.

### Ziel

Einen lokalen, deterministischen und begrenzten Item-/Blueprintkatalog für
nachgelagerte MVP-Use-Cases bereitstellen, ohne UI oder Rezeptpriorisierung
vorzuziehen.

### Durchgeführte Arbeiten

- UI- und SwiftData-freie Katalogmodelle, Filter, Lookup-Ergebnisse, Port und
  drei Use-Cases implementiert,
- `SwiftDataItemBlueprintCatalog` als `@ModelActor` ergänzt,
- genau eine aktive Version, exakte Lookups, normalisierte Suche,
  Kategorie-/Gruppen-/Publikations-/Produktions-/Aktivitätsfilter umgesetzt,
- stabile Sortierung, Deduplizierung, Limit 1–100 und `hasMore` umgesetzt,
- Item-, Blueprint-, Aktivitäts- und Produktdetails einschließlich eines
  zusammengefassten Auflösungsstatus der beteiligten Referenzen verfügbar
  gemacht,
- Schema v3 mit persistentem `searchName` und v2→v3-Backfillmigration ergänzt,
- Backup-Schemabindung auf 3.0.0 erweitert; 1.0.0 und 2.0.0 kompatibel gehalten,
- zentralen Fehlercode `NEN-SDE-005` ergänzt,
- 16 Katalog-/Use-Case-Fälle, Migration, Backupregression und
  50.000-Item-Performancefall ergänzt,
- offiziellen Build 3424810 im finalen Schema-v3-Stand erneut geprüft,
- Pflichtdokumentation, ADR-0009, Fachbeschreibung und OFFEN-Audit aktualisiert.

### Zentrale Entscheidungen

- Application-Port statt direkter SwiftData-Nutzung,
- persistenter kanonischer Suchschlüssel in Schema v3,
- erwartbares Fehlen als typisiertes `notFound`,
- harte Ergebnisgrenze und messbare geladene Zeilen,
- rohe Produktionsbezüge statt vorgezogener Rezeptentscheidung,
- kein Plattformwechsel auf macOS 15 nur für einen nativen
  nicht-eindeutigen SwiftData-Index.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ItemBlueprintCatalog.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV3.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataItemBlueprintCatalog.swift`
- `Tests/NewEdenNexusApplicationTests/ItemBlueprintCatalogTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ItemBlueprintCatalogPersistenceTests.swift`
- `Documentation/ITEM_BLUEPRINT_CATALOG.md`
- `Documentation/Architecture/ADRs/ADR-0009_Deterministischer-Item-und-Blueprintkatalog.md`
- `Documentation/Progress/Reports/2026-07-23_P09_Item-Blueprintkatalog.md`

### Geänderte Dateien

- Schema-v2-Alias, Migrationsplan, Containerfactory und Backupdienst,
- zentrale Fehlerbehandlung und Mappingtests,
- Persistenz-, Backup- und offizieller SDE-Integrationstest,
- P09-Prompt und alle verpflichtenden Status-, Architektur-, Datenmodell-,
  Test-, Aufgaben-, Problem- und Fortschrittsdokumente.

### Build-Ergebnis

`./Scripts/ci-verify.sh` bestätigte Packagegraph, Debug-Build und
Release-Build. Im erfolgreichen Abschlusslauf wurden keine Compilerwarnungen
ausgegeben. Ein früher Sandboxlauf war ausschließlich durch einen nicht
beschreibbaren globalen Compilercache blockiert; der isolierte Prüflauf
bestand.

### Testergebnis

Debug mit Coverage und Release jeweils 100 Tests, 0 Fehler und 0 unerwartete
Fehler. Der separate offizielle SDE-E2E-Test bestand im finalen Schema-v3-Stand
in 19,407 Sekunden.

Der 50.000-Item-Fall führte zehn Suchen mit Limit 50 in 0,300 Sekunden Debug
und 0,296 Sekunden Release aus; pro Abfrage wurden höchstens 51 Itemzeilen
geladen.

Coverage: alle Dateien 80,63 %, produktive Sources 67,66 %,
Application-Katalog 133/136, Persistence-Adapter 497/527,
Migrationsplan 43/43.

### Erkannte Probleme

- P10 muss 21 nicht aufgelöste offizielle Typreferenzen fachlich ablehnen,
- unter macOS 14 wird kein nativer nicht-eindeutiger SwiftData-Index genutzt;
  der gemessene Pfad erfüllt P09, erneute Bewertung folgt P34,
- automatische Vor-Migrations-Sicherung und Recovery-UI fehlen,
- eigenständiges Xcode-Projekt/Scheme fehlt weiterhin.

### Nicht erledigte Punkte

- kein Rezeptresolver,
- keine sichtbare Produktauswahl,
- kein Produktionsgraph oder Berechnung,
- keine Änderung am eingefrorenen SSO-/ESI-Zukunftscode,
- kein produktiver Benutzerstore,
- nichts gestaged, committed oder gepusht.

### Aktualisierte Features

- `TEC-003`, `TEC-004`, `TEC-005`, `TEC-007`, `TEC-008`,
- `DAT-001` bis `DAT-006`,
- `OFF-003` auf verbleibenden P10-Resolver reduziert,
- `OFF-017` als nicht blockierende P34-Beobachtung ergänzt.

### Nächster Prompt

P10 – Rezept- und Aktivitätsresolver vollständig spezifizieren und ausführen;
notwendige Punkte `OFF-003`, `OFF-016`, `KI-004` und `KI-016` verbindlich
übernehmen.

## 2026-07-23 – AUD-SDE-001: CCP-konforme SDE-Integration – Soll-Ist-Audit

### Ausgangszustand

P07 bis P09 stellten einen getesteten lokalen JSONL-, Staging-, Mapping-,
Aktivierungs- und Katalogpfad bereit. Der umfassende neue SDE-Prompt verlangte
darüber hinaus Onlineaktualisierung, HTTP-Caching, Archivschutz,
Updateautomation, Benutzeroberfläche, Protokollierung und aktuelle
CCP-Compliance.

### Ziel

Ohne fachliche oder technische Produktimplementierung belastbar feststellen,
welche Anforderungen schon nachgewiesen sind, welche fehlen und wie notwendige
Restarbeit in Roadmap und Prompts eingeordnet werden muss.

### Durchgeführte Arbeiten

- Quellcode, Tests, SDE-/Architekturdokumentation, Statusdateien,
  Abschlussberichte und offene Punkte gegen alle 18 Abschnitte geprüft.
- aktuelle offizielle CCP-Quellen zu SDE, DLA, ESI-Caching, Ratelimits,
  Third Party Policies, EULA und Terms of Service geprüft.
- offiziellen Metadaten- und Schema-Changelog-Endpunkt read-only abgerufen.
- vollständige Soll-Ist-Matrix und technische Complianceprüfliste erstellt.
- fehlende Arbeit in P07A, P07B und P07C vollständig spezifiziert.
- Roadmap, Promptregister, Feature-Matrix, Status, offene Punkte und bekannte
  Probleme aktualisiert.
- abhängige Prompts P12, P35–P37 und P39–P41/P44 um notwendige SDE-/ESI-Gates
  ergänzt.

### Zentrale Entscheidungen

- Der Gesamtprompt ist nur teilweise umgesetzt und erhält keinen
  Erledigtstatus.
- P07–P09 bleiben als nachgewiesener Offline-Kern gültig.
- Online-Metadaten/Cache, sicherer Download/Aktivierung und UI/Compliance
  werden getrennt als P07A–P07C vor P10 beziehungsweise spätestens vor P37
  bearbeitet.
- Weitere SDE-Datensätze werden nur bei belegtem Fachbedarf importiert.
- Persönliche DLA-, Kontakt-, Marken- und Datenschutzentscheidungen bleiben
  beim Projekteigentümer.

### Neu erstellte Dateien

- `Documentation/CCP_COMPLIANCE.md`
- `Documentation/SDE_CCP_INTEGRATION_AUDIT.md`
- `Documentation/Prompts/MVP/P07A_SDE-Metadaten-HTTP-Cache-Compliance.md`
- `Documentation/Prompts/MVP/P07B_SDE-Download-Archiv-Aktivierung.md`
- `Documentation/Prompts/MVP/P07C_SDE-Einstellungen-Automation-Recht.md`
- `Documentation/Progress/Reports/2026-07-23_AUD-SDE-001_CCP-SDE-Integration.md`

### Geänderte Dateien

- Roadmap, Entwickler-Menü, Promptregister, Feature-Matrix und Projektstatus,
- `OFFEN.md`, `OPEN_TASKS.md`, `KNOWN_ISSUES.md`,
- SDE-, Architektur-, Tagebuch- und Testdokumentation,
- abhängige MVP- und Zukunftspromptentwürfe.

### Build-Ergebnis

Nicht erneut ausgeführt, da der Audit ausschließlich Markdown-Dokumentation
ändert. Letzter unveränderter Produktnachweis aus P09: Debug- und
Release-Build erfolgreich.

### Testergebnis

Nicht erneut ausgeführt. Letzter unveränderter P09-Nachweis: je 100
XCTest-Tests in Debug und Release ohne Fehler; offizieller Build-3424810-E2E-
Test erfolgreich.

### Erkannte Probleme

- Die App kann den offiziellen Build `3444265` noch nicht selbst erkennen,
  herunterladen oder aktivieren.
- HTTP-Cache, ZIP-Schutz, Schema-Gate, Crash-Recovery, Updateprotokoll,
  Einstellungen und rechtliche Hinweise fehlen.
- Der aktuelle produktiv installierte SDE-Stand ist nicht nachgewiesen.
- Eigentümerentscheidungen zu DLA, User-Agent-Kontakt, Marken und Datenschutz
  sind offen.

### Nicht erledigte Punkte

- keine Produktcode-, Schema- oder UI-Änderung,
- Build `3444265` nicht heruntergeladen oder importiert,
- keine Vertragsannahme und keine rechtliche Freigabe,
- P07A bis P07C nicht implementiert.

### Aktualisierte Features

`DAT-007` bis `DAT-010` und `CMP-001` neu erfasst; `OFF-018` bis `OFF-021`
und `KI-018` bis `KI-021` angelegt.

### Nächster Prompt

P07A – Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance.

## 2026-07-23 – P07A: SDE-Metadaten, HTTP-Cache und CCP-Compliance

### Ausgangszustand

P07–P09 boten lokalen JSONL-Import, versionierten Katalog und
Katalogabfragen. Ein offizieller Metadatencheck, HTTP-Validatoren,
24-Stunden-Drosselung, Schema-Changelog-Gate und persistenter Prüfstatus
fehlten.

### Ziel

Den offiziellen aktuellen SDE-Build sicher und ressourcenschonend erkennen,
mit dem lokal aktiven Build vergleichen und Schemaänderungen vor einer
späteren Installation sichtbar stoppen.

### Durchgeführte Arbeiten

- Application-Verträge und `SDEUpdateService` implementiert,
- festen offiziellen URLSession-Adapter mit ETag, Last-Modified, 304,
  Cache-Control, Timeout und begrenztem Retry/Backoff/Jitter implementiert,
- defensive JSONL-/YAML-Metadatenparser ergänzt,
- zentrale User-Agent-Konfiguration ohne erfundene Kontaktadresse ergänzt,
- `NexusSchemaV4` und SDE-Prüfstatusrepository implementiert,
- v3→v4-Migration und Backupkompatibilität aktualisiert,
- Fehlercode `NEN-SDE-006` ergänzt,
- 30 neue Tests und vollständige Regression ausgeführt,
- offizielle Metadatenressourcen einmal read-only geprüft,
- Architektur-, Compliance-, Status- und Betriebsdokumentation aktualisiert.

### Zentrale Entscheidungen

- Metadatenprüfung bleibt von Download, Import, Aktivierung und UI getrennt.
- Ein Force-Check umgeht nicht die frische Servercachefrist.
- Ein 304 ist nur mit zuvor validierter Cache-Nutzlast erfolgreich.
- Unverstandene Schemaänderungen führen zu `schemaReviewRequired`.
- Eigentümerkontakt und Vertragsentscheidungen bleiben persönliche Aufgaben.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/SDEUpdateChecking.swift`
- `Sources/NewEdenNexusInfrastructure/CCPSDEMetadataClient.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV4.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSDEUpdateStateRepository.swift`
- drei neue Testdateien für Application, Infrastructure und Persistence
- `Documentation/SDE_UPDATE_CHECK.md`
- `Documentation/Architecture/ADRs/ADR-0010_SDE-Metadaten-HTTP-Cache-und-Schema-Gate.md`
- `Documentation/Progress/Reports/2026-07-23_P07A_SDE-Metadaten-HTTP-Cache-Compliance.md`

### Geänderte Dateien

- Fehlerbehandlung, Migration, Container und Backup-Schemabindung,
- Backup-, Fehler-, Architektur-, Datenmodell-, SDE- und Testdokumentation,
- Cockpit, Roadmap, Promptregister, Status, Matrix, Aufgaben und Probleme.

### Build-Ergebnis

SwiftPM-Paketbeschreibung, Debug-Coverage-Build sowie Release-Build
erfolgreich. Die eingeschränkte Umgebung benötigt isolierte Modulcaches und
`--disable-sandbox`; globale Cachewarnungen bleiben ohne Buildfehler.

### Testergebnis

- gezielt: 41 Tests, 0 Fehler,
- Debug mit Coverage: 130 Tests, 0 Fehler,
- Release: 130 Tests, 0 Fehler,
- keine übersprungenen XCTest-Tests.

### Erkannte Probleme

- Ein erster Testcompile verwendete `await` in XCTest-Autoclosures; die
  erwarteten Werte werden nun vor dem Assert aufgelöst.
- Der Header-Injection-Test zeigte, dass CRLF als zusammengesetztes Graphem
  geprüft werden muss; die Validierung arbeitet nun auf Unicode-Scalars.
- Der gesonderte Review fand eine asymmetrische Cachefrist: Jede der beiden
  Ressourcen wird nun einzeln gegen ihre Frische geprüft; nur die abgelaufene
  Ressource wird angefragt. Ein Regressionstest schützt den Fall.
- Der finale Sicherheitsreview erkannte die standardmäßige URLSession-
  Redirectfolge. Redirects werden nun nicht verfolgt und eine abweichende
  finale URL zusätzlich abgelehnt; ein Regressionstest schützt die Grenze.
- Core Data meldet in temporären Tests weiterhin nicht fehlschlagende
  Store-Change-Hinweise.

### Nicht erledigte Punkte

- kein Archivdownload oder ZIP-Schutz,
- keine SDE-Aktivierung oder Rotation,
- keine produktive Start-/UI-Verdrahtung,
- kein Diagnoseexport oder rechtlicher In-App-Bereich,
- keine Kontaktadresse im Namen des Eigentümers festgelegt.

### Aktualisierte Features

- `DAT-007` erledigt,
- `DAT-009` teilweise,
- `CMP-001` teilweise,
- `OFF-018` / `KI-018` erledigt,
- `OFF-020` / `KI-020` teilweise.

### Nächster Prompt

P07B – Sicherer SDE-Download, Archivprüfung und Aktivierung.

## 2026-07-23 – P07B: Sicherer SDE-Download, Archivprüfung und Aktivierung

### Ausgangszustand

P07A konnte den offiziellen Build und Schemaänderungen cachekonform prüfen.
P07–P09 konnten vier bereits lokal entpackte JSONL-Dateien validieren,
stagen, mappen und atomar aktivieren. Downloader, ZIP-Grenze, isolierter
Teststore, SDE-Sicherheitsbackup, expliziter Rollback und dauerhaftes
Phasenjournal fehlten. `OFF-019`/`KI-019` waren offen.

Die persönliche DLA-Entscheidung und reale User-Agent-Kontaktangabe des
Projekteigentümers waren und sind offen. Deshalb wurde kein aktuelles
offizielles Archiv heruntergeladen.

### Ziel

Den technischen P07B-Pfad sicher und injizierbar umsetzen, ohne aktiven
Benutzerstore oder aktuelles CCP-Archiv zu verändern. P07B nur bei
vollständigem Nachweis als erledigt markieren.

### Durchgeführte Arbeiten

- fester offizieller versionierter Archivdownload mit Redirect-, Status-,
  MIME-, Content-Length-, tatsächlicher Größen- und Speicherprüfung,
- ephemerer URLSession-Download, begrenzte Retries, Backoff, User-Agent-
  Kontaktgate und private Vorgangsverzeichnisse,
- eigener ZIP-Central-Directory-/Local-Header-Prüfer,
- Ablehnung von Zip-Slip, absoluten/mehrdeutigen Pfaden, Duplikaten,
  Verschlüsselung, Multipart/ZIP64, Sonderobjekten, unerwarteten Dateien,
  Größen- und Bombengrenzen,
- kontrollierte injizierbare `/usr/bin/ditto`-Extraktion ohne Shell und
  vollständige Nachprüfung,
- phasenbasierte `SDEInstallationService`-Orchestrierung mit P07/P08,
- zentrale Fehleroperation `sdeInstallation` mit `NEN-SDE-007`,
- separater temporärer SwiftData-Stagingstore einschließlich Wiederöffnung,
- `beforeSDEUpdate`-SQLite-Backup vor Promotion,
- expliziter Rollback auf eine erhaltene Buildversion,
- privates, pfadbereinigtes JSON-Phasenjournal und Recovery-Einstieg,
- synthetische, bösartige, Prozessgrenz-, Staging-, Aktivierungs-,
  Rollback- und Journaltests,
- Pflichtdokumentation, ADR und Abschlussbericht aktualisiert.

### Zentrale Entscheidungen

- keine neue ZIP-Abhängigkeit; Metadaten werden selbst read-only geprüft,
  Dekompression erfolgt erst danach über die feste macOS-Systemgrenze,
- kein Shellaufruf und keine benutzerdefinierte ausführbare Datei,
- kein Schreiben in den aktiven Store vor erfolgreicher Wiederöffnung des
  isolierten Teststores,
- bestehender atomarer Katalogsave bleibt erhalten,
- kein Realdownload ohne persönliche Eigentümerentscheidung,
- P07B bleibt wegen fehlendem Real-SDE-/Crash-/Speichernachweis
  `⚠️ teilweise/blockiert`.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/SDEInstallation.swift`
- `Sources/NewEdenNexusInfrastructure/CCPSDEArchivePipeline.swift`
- `Sources/NewEdenNexusInfrastructure/FileSDEInstallationLogStore.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSDEStagingService.swift`
- drei P07B-Testdateien,
- `Documentation/SDE_ARCHIVE_INSTALLATION.md`,
- `Documentation/Architecture/ADRs/ADR-0011_Sicherer-SDE-Archivpfad-und-Promotion.md`,
- `Documentation/Progress/Reports/2026-07-23_P07B_SDE-Download-Archiv-Aktivierung.md`.

### Geänderte Dateien

- zentrale Fehlerbehandlung, Application-Katalog-/Backupverträge und
  SwiftData-Katalogrepository,
- Katalogpersistenztests,
- Architektur-, Backup-, Compliance-, Datenmodell- und
  SDE-Aktualitätsdokumentation,
- Cockpit, Roadmap, Promptregister, Status, Matrix, Aufgaben, offene Punkte,
  bekannte Probleme und Testhistorie.

### Build-Ergebnis

Debug-Coverage-Build und Release-Build erfolgreich. Isolierte Modulcaches,
deaktivierte SwiftPM-Sandbox und getrennte Scratch-Verzeichnisse wurden
verwendet. Globale SwiftPM-Cachewarnungen blieben ohne Buildfehler.

### Testergebnis

- fokussiert: 13 Download-/ZIP-/Journal-/Orchestrierungstests, 0 Fehler,
- Katalogpersistenz: 6 Tests, 0 Fehler,
- Debug mit Coverage: 145 Tests, 0 Fehler,
- Release: 145 Tests, 0 Fehler,
- keine übersprungenen XCTest-Tests.

### Erkannte Probleme

- `JSONLinesSDECatalogMapper` materialisiert den vollständigen finalen
  Snapshot weiterhin im Speicher.
- Die zwei zentralen P07B-Dateien sind trotz klarer Protokollgrenzen für
  einfache Einzelreviews zu groß (`OFF-022`/`KI-022`).
- Ein tatsächlicher Prozessabbruch wurde nicht nach jeder Phasengrenze mit
  App-Neustart simuliert.
- Core Data meldet in temporären Tests weiterhin nicht fehlschlagende
  Store-Change-Hinweise.

### Nicht erledigte Punkte

- persönliche DLA-/Kontaktentscheidung des Eigentümers,
- aktueller offizieller Real-SDE-Download, Import, Wiederöffnung und Abfrage,
- reales Speicher-/Laufzeitprofil oder blockweises Mapping,
- vollständiger Prozessabbruch-/Neustart-Drill,
- produktive Startverdrahtung und UI aus P07C.

### Aktualisierte Features

- `DAT-008` technisch weitgehend umgesetzt, bleibt teilweise/blockiert,
- `DAT-009` um persistentes Phasenjournal ergänzt,
- `TEC-008` um `beforeSDEUpdate`-Backup ergänzt,
- `OFF-019`/`KI-019` auf konkrete Restabnahme reduziert,
- `OFF-006` für den SDE-Promotionsfall teilweise weitergeführt,
- `OFF-016` unverändert erhalten.
- `OFF-022`/`KI-022` für die spätere mechanische Dateiaufteilung erfasst.

### Nächster Prompt

P07B-Abnahme nach ausdrücklicher Eigentümerentscheidung fortsetzen. P07C oder
P10 nicht automatisch beginnen.

## 2026-07-23 – P07B: Aktuelle Real-SDE-Abnahme

### Ausgangszustand

Der technische P07B-Pfad war implementiert und mit 145 Debug-/Release-Tests
grün. Persönliche DLA-Entscheidung, reale User-Agent-Kontaktangabe und
aktueller offizieller End-to-End-Lauf fehlten. Das vollständige
Katalogmapping materialisierte einen Snapshot, war aber noch nicht real
speichervermessen.

### Ziel

Nach ausdrücklicher Eigentümerbestätigung den aktuellen offiziellen
CCP-SDE-Build isoliert herunterladen, sicher verarbeiten, aktivieren, wieder
öffnen, abfragen, speichervermessen und vollständig bereinigen. Keine
fachliche App-Funktion und kein P07C beginnen.

### Durchgeführte Arbeiten

- offizielle DLA-, SDE-, Build- und Schema-Changelog-Quellen erneut geprüft,
- Build 3444265 und Archivkopf ausschließlich über CCP bestätigt,
- opt-in SwiftPM-Executable `NewEdenNexusSDEAcceptance` ergänzt,
- Owner-, Schema- und Kontaktgates ausschließlich zur Laufzeit verdrahtet,
- Build 3444265 zweimal vollständig geladen, geprüft, importiert, aktiviert,
  wieder geöffnet und über Rifter/Blueprint abgefragt,
- Sicherheitsbackup, Terminaljournal und vollständigen Cleanup nachgewiesen,
- Wiederanlauf nach jeder persistenten Installationsphase automatisiert
  getestet,
- Kontakt-/Accountwerte im Repository und in Abnahmeartefakten ausgeschlossen,
- Debug-Coverage, Release-Build und Release-Tests vollständig ausgeführt,
- gesonderten Review und Pflichtdokumentation aktualisiert.

### Zentrale Entscheidungen

- Kontakt- und Accountdaten werden weder fest codiert noch dokumentiert oder
  protokolliert.
- Der Realabnahmerunner bleibt getrennt vom App-Start und verwendet nur
  temporäre Stores.
- Der reproduzierbare Peak-RSS von rund 2,45 GB wird nicht als erfülltes
  blockweises Mapping bewertet.
- P07B bleibt deshalb `⚠️ teilweise/blockiert`; P07C wurde nicht begonnen.

### Neu erstellte Dateien

- `Sources/NewEdenNexusSDEAcceptance/main.swift`
- `Documentation/Progress/Reports/2026-07-23_P07B_Real-SDE-Abnahme.md`

### Geänderte Dateien

- `Package.swift`
- `Tests/NewEdenNexusApplicationTests/SDEInstallationServiceTests.swift`
- P07B-Prompt, Architektur-, Compliance-, SDE-, Status-, Matrix-, Aufgaben-,
  Problem-, Roadmap-, Test- und Steuerdokumentation.

### Build-Ergebnis

Debug-Build im Coverage-Testlauf und vollständiger Release-Build erfolgreich.
Der neue Abnahmerunner wurde separat als Release-Produkt gebaut.

### Testergebnis

- Debug mit Coverage: 146 Tests, 0 Fehler,
- Release: 146 Tests, 0 Fehler,
- zwei aktuelle Real-SDE-Läufe erfolgreich,
- Datensätze: 48 Kategorien, 1.609 Gruppen, 52.821 Typen, 5.082 Blueprints,
  19.137 Aktivitäten, 36.499 Materialien und 6.329 Produkte,
- 21 bereits bekannte Referenzlücken unverändert erhalten,
- Produktquellcode-Coverage 72,98 %.

### Erkannte Probleme

Der Realimport erreichte 2.454.126.592 beziehungsweise 2.448.506.880 Bytes
Peak-RSS. Ursache ist die weiterhin vollständige Snapshot-Materialisierung
zusammen mit den nachgelagerten SwiftData-Persistenzschritten.

### Nicht erledigte Punkte

- blockweises Mapping und blockweise Persistenz,
- erneute Low-Memory-Realabnahme,
- tatsächlicher Prozessabbruch/App-Neustart im P36-Recovery-Drill,
- mechanische Aufteilung der großen P07B-Dateien in P34,
- P07C-Bedienung und rechtliche Ansicht.

### Aktualisierte Features

- `DAT-008`: aktueller Realpfad nachgewiesen, Low-Memory-Grenze offen,
- `TEC-007`: 146 Debug-/Release-Tests und aktueller Real-SDE-E2E,
- `CMP-001`: persönliche Entscheidung und Laufzeitkontakt nachgewiesen,
- `OFF-019`/`KI-019`: auf blockweises Mapping und P36-Drill reduziert,
- `OFF-020`: Kontaktentscheidung erledigt, UI/Startverdrahtung offen.

### Nächster Prompt

P07B-Speichergrenze schließen: blockweises Mapping/Persistieren implementieren
und Build 3444265 erneut speichervermessen. P07C nicht automatisch beginnen.

## 2026-07-23 – CFG-001: Öffentliche EVE-Client-ID aktualisieren

### Ausgangszustand

Accounts- und Einstellungsansicht sowie der App-Start verwendeten mehrfach
einen früheren öffentlichen Client-ID-Standard. Eine zentrale
Konfigurationsquelle und eine gezielte Migration dieses Altstandards fehlten.

### Ziel

Die vom Projekteigentümer angegebene aktuelle öffentliche Client-ID
eintragen, vorhandene Projektinstallationen sicher aktualisieren und
individuelle Benutzerkonfigurationen erhalten.

### Durchgeführte Arbeiten

- öffentliche Client-ID und Callback-URL zentralisiert,
- Accounts- und Einstellungsansicht auf die zentrale Konfiguration umgestellt,
- App-Startmigration für leeren beziehungsweise früheren Projektstandard
  ergänzt,
- Bestandsschutz für individuell eingetragene Client-IDs implementiert,
- zwei Regressionstests ergänzt,
- vollständige Debug- und Release-Tests ausgeführt,
- Status-, Matrix-, Aufgaben-, Problem-, Architektur- und Testdokumentation
  aktualisiert.

### Zentrale Entscheidungen

- Die Client-ID ist eine öffentliche Anwendungskennung, kein Client-Secret.
- Ein abweichender Benutzerwert wird nicht automatisch überschrieben.
- SSO-Login, Scopes, Tokenfluss und ESI bleiben unverändert und bis P38
  fachlich verschoben.

### Neu erstellte Dateien

- `Sources/NewEdenNexus/EVEPublicConfiguration.swift`
- `Documentation/Progress/Reports/2026-07-23_CFG-001_EVE-Client-ID.md`

### Geänderte Dateien

- `Sources/NewEdenNexus/AccountsView.swift`
- `Sources/NewEdenNexus/SupportViews.swift`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- verpflichtende Status- und Qualitätsdokumentation.

### Build-Ergebnis

Debug und Release erfolgreich über SwiftPM gebaut.

### Testergebnis

Debug und Release jeweils 148 Tests, 0 Fehler. Zwei neue Tests prüfen
Neuinstallation, Altstandardmigration und den Erhalt einer eigenen Client-ID.

### Erkannte Probleme

Kein durch CFG-001 verursachter Fehler. SwiftPM meldete im eingeschränkten
Prüfumfeld deaktivierte Benutzer-Caches; SwiftData gab bekannte
Store-Notification-Diagnosen aus. Alle Tests bestanden.

### Nicht erledigte Punkte

- echter EVE-SSO-Login,
- SSO-Härtung und Keychain-/SwiftData-Kompensation,
- ESI-Synchronisation.

### Aktualisierte Features

- `SSO-001`: öffentliche Konfiguration und Migration geprüft; echter Login
  bleibt ungetestet.
- `TEC-007`: Gesamtteststand 148 Debug/Release.
- `OFF-010`/`KI-010`: Zukunftsscope bleibt eingefroren.

### Nächster Prompt

P07B-Speichergrenze schließen. P38 und andere SSO-/ESI-Arbeiten nicht ohne
ausdrücklichen Auftrag beginnen.

## 2026-07-23 – P07B: Speichergrenze schließen

### Ausgangszustand

Der sichere Real-SDE-Pfad war funktional abgenommen, materialisierte beim
Mapping und Persistieren jedoch einen vollständigen Katalogsnapshot. Zwei
Build-3444265-Läufe benötigten maximal rund 2,45 GB RSS. `OFF-019` und
`KI-019` blockierten deshalb den P07B-Abschluss.

### Ziel

Mapping, isoliertes Staging und Promotion ohne vollständige
Gesamtmaterialisierung ausführen, Fehler- und Recoverygrenzen erhalten und
den aktuellen offiziellen SDE mit identischem Inhalt deutlich
speichersparender erneut abnehmen.

### Durchgeführte Arbeiten

- Streamingverträge und begrenzte Katalogbatches ergänzt,
- JSONL-Dateien zeilenweise gemappt und Referenz-/Hashprüfung erhalten,
- isolierten Stagingstore und Hauptstore batchweise beschrieben,
- Aktivmarker erst nach vollständigem Mengenabgleich gesetzt,
- Kandidatenhash und gezielte Orphan-Bereinigung ergänzt,
- Legacy-Vollsnapshotverdrahtung für P07B vor dem Download abgelehnt,
- Abbruch, Fehler mitten im Stream, Wiederanlauf und Bestandsschutz getestet,
- Build 3444265 zweimal real importiert und Speicherverbrauch gemessen.

### Zentrale Entscheidungen

Die aktive Version bleibt bis zum letzten erfolgreichen Prüfschritt
unverändert. Batches sind eine Application-Schnittstelle; SwiftData-Kontexte
werden je Batch begrenzt gehalten. Eine abgeschlossene Version mit demselben
Inhaltshash darf Recovery niemals als Orphan entfernen.

### Neu erstellte Dateien

- `Sources/NewEdenNexusPersistence/SwiftDataStaticDataStreamingRepository.swift`
- `Documentation/Progress/Reports/2026-07-23_P07B_Speichergrenze.md`

### Geänderte Dateien

- Application-, Infrastructure- und Persistence-SDE-Verträge/-Services,
- SDE- und Persistenztests,
- Architektur-, Status-, Matrix-, Aufgaben-, Problem- und Promptdokumentation.

### Build-Ergebnis

Debug-Build im Coverage-Testlauf und separater Release-Build erfolgreich.

### Testergebnis

Debug und Release jeweils 153 Tests, 0 Fehler. Produktive
Source-Coverage 74,43 %. Zwei reale Build-3444265-Läufe ergaben identische
Mengen und identischen Hash bei 952.057.856 beziehungsweise 948.125.696 Bytes
maximalem RSS.

### Erkannte Probleme

- tatsächlicher Prozessabbruch mit App-Neustart bleibt P36,
- große bestehende P07B-Dateien bleiben als Wartungspunkt `OFF-022` für P34,
- 21 offizielle nicht aufgelöste Typreferenzen bleiben P10.

### Nicht erledigte Punkte

- P07C-Einstellungen, Startautomation, Diagnoseexport und Rechtshinweise,
- P36-Prozess-Kill-Recovery-Drill,
- P34-Dateiaufteilung.

### Aktualisierte Features

- `DAT-000`, `DAT-008`, `TEC-007`,
- `OFF-019` und `KI-019` auf erledigt gesetzt.

### Nächster Prompt

P07C – SDE-Einstellungen, Automatisierung und rechtliche Hinweise.

## 2026-07-23 – PLAN-001: Restbefunde in die Promptfolge einordnen

### Ausgangszustand

Nach P07B wurden zehn technische beziehungsweise organisatorische Restbefunde
gemeldet. Ein Teil war bereits in `OFFEN.md`, `KNOWN_ISSUES.md` und späteren
Prompts adressiert; Git-Baseline und Xcode-Projekt besaßen jedoch keinen
verbindlichen Platz in der Ausführungsreihenfolge.

### Ziel

Jeden Befund gegen Quellcode und Planung prüfen, Doppelprompts vermeiden und
nur ungedeckte Arbeiten als vollständig spezifizierte Zwischenprompts
einordnen. Keine Implementierung, kein Staging und kein Commit.

### Durchgeführte Planungsarbeiten

- aktuellen unborn `main`-Branch und vollständig untracked Projektstand
  bestätigt,
- direkte SwiftData-Viewzugriffe und große P07B-Dateien quellseitig
  lokalisiert,
- P07A-/P07B-Technik gegen die noch fehlende produktive App-Composition
  abgegrenzt,
- P09A für die geprüfte initiale Git-Baseline vollständig spezifiziert,
- P09B für ein eigenständiges Xcode-Projekt und gemeinsame Schemes
  vollständig spezifiziert,
- P07C um produktive Updatecheck-/Installationsverdrahtung geschärft,
- P10 vollständig für deterministische Rezepte und itemgenaue Ablehnung
  unvollständiger offizieller Referenzen spezifiziert,
- P11/P32/P38 als gestufte Ziele für direkte SwiftData-Viewzugriffe
  festgelegt,
- P34 für die verhaltensneutrale mechanische Dateiteilung bestätigt,
- P36 um echten externen Prozessabbruch mit Neustart ergänzt,
- P37 um persönliche itemweise Marken-/Releasefreigaben geschärft,
- den veralteten Git-Wurzelhinweis in den Reviewregeln korrigiert.

### Ergebnis und Reihenfolge

1. P09A – Repository-Baseline,
2. P09B – Xcode-Projekt/Schemes,
3. P07C – produktive SDE-Verdrahtung, Einstellungen und Recht,
4. P10 – Rezeptresolver/Referenzlücken,
5. danach P11 bis P37 mit den konkret zugeordneten Restpunkten.

Nach dem Planungsstart wurde sichtbar, dass P07C parallel bereits ausgeführt
wird. Die Reihenfolge wurde deshalb konfliktfrei korrigiert:

1. laufendes P07C abschließen,
2. P09A,
3. P09B,
4. P10,
5. danach die bestehende Folge.

### Build- und Testergebnis

Nicht ausgeführt, weil PLAN-001 ausschließlich Dokumentation und
Promptplanung ändert. Der zuletzt bestätigte Produktstand bleibt P07B mit 153
Debug-/Release-Tests; daraus wird kein neuer Testnachweis abgeleitet.

### Nicht erledigte Punkte

Alle genannten technischen Arbeiten bleiben offen. Insbesondere wurde kein
Commit erstellt, kein Xcode-Projekt erzeugt, kein SDE-Service produktiv
verdrahtet und kein Rezeptresolver implementiert.

### Nächster Prompt

Nach Abschluss des bereits laufenden P07C: P09A – Repository-Baseline und
Git-Nachvollziehbarkeit.

## 2026-07-23 – P07C: SDE-Einstellungen, Automation und Recht

### Ausgangszustand

P07A und P07B stellten Metadatencheck, sicheren Installationspfad und
Phasenjournal bereit. Produktive App-Verdrahtung, Automation, Bedienung,
Diagnoseexport, Retention und Rechtsansicht fehlten.

### Ziel

Den vollständigen SDE-Updatepfad sicher, transparent und
benutzerkontrolliert in die native App integrieren, ohne neue fachliche
MVP-Funktionen vorzuziehen.

### Durchgeführte Arbeiten

- produktive Adapter in `SDEAppComposition` verdrahtet,
- nicht blockierenden Startcheck, Scheduler und Parallelitätsschutz ergänzt,
- kontaktfreie Start-Recovery vor dem ersten Metadatencheck verdrahtet,
- sichere Automationsdefaults und Keychain-Kontakt umgesetzt,
- geprüften Archivcache und Phasenfortschritt ergänzt,
- Status-, Settings-, Log-, Export-, Retention- und Rechtsansicht erstellt,
- Diagnoseexport redigiert und Retention zweistufig bestätigt,
- aktuelle offizielle CCP-Quellen und Eigentumshinweis geprüft,
- Adapterbau beim Review aus dem ViewModel an die Composition Root verschoben,
- Archivcache-Hashfehler reproduziert, korrigiert und regressionsgetestet.

### Zentrale Entscheidungen

Views und ViewModel kennen keine konkreten SDE-Adapter. Download und
Installation sind getrennte Opt-ins. Kontaktwerte bleiben im Schlüsselbund.
Aktive und mindestens eine funktionierende Rollbackversion sind
retentionsgeschützt. Der fehlende manuelle GUI-Nachweis wird nicht als Erfolg
gewertet.

### Neu erstellte Dateien

- `Sources/NewEdenNexus/SDEAppComposition.swift`
- `Sources/NewEdenNexus/SDEAppConfiguration.swift`
- `Sources/NewEdenNexus/SDEDataManagementView.swift`
- `Sources/NewEdenNexus/SDELegalNoticesView.swift`
- `Sources/NewEdenNexus/SDEManagementViewModel.swift`
- `Sources/NewEdenNexusApplication/SDEManagement.swift`
- `Sources/NewEdenNexusInfrastructure/CachedSDEArchiveDownloader.swift`
- `Sources/NewEdenNexusInfrastructure/SDEArchiveRecoveryBoundary.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSDECatalogRetentionRepository.swift`
- `Tests/NewEdenNexusInfrastructureTests/SDEArchiveRecoveryBoundaryTests.swift`
- `Documentation/SDE_SETTINGS_AND_DIAGNOSTICS.md`
- `Documentation/Architecture/ADRs/ADR-0012_SDE-App-Composition-Automation-und-Retention.md`
- `Documentation/Progress/Reports/2026-07-23_P07C_SDE-Einstellungen-Automation-Recht.md`

### Geänderte Dateien

App-Start, Navigation, Runtime, Root-/Settings-Views,
Installationsfortschritt, Logstore, Tests sowie Pflicht-, Architektur-,
Compliance- und Promptdokumentation.

### Build-Ergebnis

SwiftPM Debug und Release erfolgreich. Keine Signing- oder Teamänderung.

### Testergebnis

Debug mit Coverage und Release jeweils 167 Tests, 0 Fehler. Produktive
Source-Zeilenabdeckung einschließlich SwiftUI 63,63 %. Ein fehlerhafter
Zwischenlauf mit zwei Cachetests führte zu einer echten Korrektur; alle
Abschlussläufe sind grün. Der abschließende Review ergänzte außerdem die
zuvor fehlende kontaktfreie Start-Recovery vor dem ersten Metadatencheck und
sicherte Erfolg sowie Fehlerabbruch mit zwei Tests ab.

### Erkannte Probleme

Der isolierte SwiftPM-Prozess erzeugte seinen temporären Store, lieferte aber
ohne echtes Xcode-App-Bundle kein steuerbares Fenster. Der manuelle
Fenster-/Tastatur-/VoiceOver-Smoke-Test mit datenschutzneutralen Screenshots
bleibt `OFF-025`.

### Nicht erledigte Punkte

- manueller P07C-GUI-/Accessibility-Nachweis,
- P37-Recheck der dann aktuellen CCP- und Releasepflichten,
- P36-Prozess-Kill-Recovery-Drill.

### Aktualisierte Features

`TEC-001`, `TEC-006`, `TEC-007`, `DAT-007`, `DAT-009`, `CMP-001`,
`OFF-020`, `KI-020`; neu `OFF-025` und `KI-025`.

### Nächster Prompt

P09A – Repository-Baseline und Git-Nachvollziehbarkeit. Danach P09B
einschließlich `OFF-025`; P10 wurde nicht begonnen.

## 2026-07-23 – P09A: Repository-Baseline und Git-Nachvollziehbarkeit

### Ausgangszustand

Der Projektordner war bereits eine eigene Git-Wurzel auf dem unborn Branch
`main`, besaß aber noch keinen Commit. Sämtliche 212 vorhandenen
Projektdateien waren untracked; `.build`, `.swiftpm` und macOS-Metadaten
waren ignoriert. P07C war technisch abgeschlossen und wegen des fehlenden
manuellen GUI-Nachweises dokumentiert `⚠️`.

### Ziel

Den vollständig geprüften Projektstand als genau einen initialen Root-Commit
sichern, ohne Remote, Push oder Eingriff in das übergeordnete
Home-Repository.

### Durchgeführte Arbeiten

- Git-Wurzel, Branch, unborn-Status, fehlenden Remote und vorgesehenes
  Dateiinventar geprüft,
- `.gitignore` um lokale Datenbanken, Backups, Schlüsselbunddateien,
  SDE-/Import-/Diagnoseartefakte und Xcode-Ergebnisdateien ergänzt,
- 213 finale Projektdateien einschließlich Projektbuch und P09A-Bericht auf
  Zweck, Typ, Größe und Commit-Eignung geprüft,
- Textquellen, Tests, Dokumentation und DOCX-Inhalt auf Geheimnisse, reale
  Kontaktwerte und lokale Datenartefakte geprüft,
- lokale Markdown-Ziele und Promptregister kontrolliert,
- SwiftPM-Paketbeschreibung, Debug-/Release-Build und vollständige
  Debug-/Release-Tests ausgeführt,
- den vollständigen gecachten Initialdiff und dessen Dateistatistik geprüft,
- genau einen Root-Commit auf `main` erstellt und den Folgestatus geprüft.

### Zentrale Entscheidungen

Die öffentliche EVE-Client-ID bleibt als nicht geheime Konfiguration
versioniert. Reale Kontaktwerte, Tokens, Client-Secrets, lokale Stores,
offizielle SDE-Großarchive und Diagnoseexporte bleiben ausgeschlossen.
Künftige Implementierungsprompts committen weiterhin nur bei ausdrücklicher
Autorisierung.

### Neu erstellte Dateien

- `Documentation/Progress/Reports/2026-07-23_P09A_Repository-Baseline-Git-Historie.md`

### Geänderte Dateien

- `.gitignore`,
- Status-, Prompt-, Aufgaben-, Problem-, Review-, Test- und
  Fortschrittsdokumentation.

### Build-Ergebnis

`swift package describe`, SwiftPM Debug und SwiftPM Release erfolgreich.
Kein Xcode-Projekt vorhanden; dessen Erstellung bleibt P09B.

### Testergebnis

Debug mit Coverage und Release jeweils 167 Tests, 0 Fehler. Keine
übersprungenen XCTest-Tests.

### Erkannte Probleme

Keine neue funktionale Regression. P07C bleibt wegen `OFF-025` unabhängig
vom Baseline-Commit teilweise.

### Nicht erledigte Punkte

- P09B-Xcode-Projekt und gemeinsame Schemes,
- manueller P07C-Fenster-/Tastatur-/VoiceOver-Nachweis,
- P10-Rezeptresolver.

### Aktualisierte Features

`TEC-011`, `OFF-023`, `KI-002`, `KI-023`.

### Nächster Prompt

P09B – Eigenständiges Xcode-Projekt und gemeinsame Schemes. P10 erst danach.

## 2026-07-23 – P09B: Eigenständiges Xcode-Projekt und gemeinsame Schemes

### Ausgangszustand

SwiftPM war der einzige verifizierte Buildweg. Ein eigenständiges
Xcode-Projekt, gemeinsame Schemes und der echte P07C-App-/Accessibility-
Nachweis fehlten. P09A hatte zuvor eine reviewbare Git-Baseline erstellt.

### Ziel

App, Module, Tests und opt-in SDE-Abnahmerunner ohne Quellduplikation für
Xcode reproduzierbar machen und `OFF-014` sowie `OFF-025` schließen.

### Durchgeführte Arbeiten

- alle 15 Package-Targets in `project.yml` gespiegelt,
- versioniertes `NewEdenNexus.xcodeproj` erzeugt,
- zwei gemeinsame Schemes und sieben App-Scheme-Testtargets eingerichtet,
- Test-Fixtures für SwiftPM und Xcode aus derselben Quelle nutzbar gemacht,
- Generierungs- und Paritätsprüfskript ergänzt,
- Xcode App Debug/Release, Runner-Build, Xcode-Tests und vollständige
  SwiftPM-Regression ausgeführt,
- App mit isoliertem Profil gestartet und Dashboard, SDE-Normal-/Offline-/
  Warnzustand, Settings, Recht, Tastatur und VoiceOver manuell geprüft,
- Projekt-, Architektur-, Status-, Aufgaben-, Problem-, Test- und
  Promptdokumentation aktualisiert.

### Zentrale Entscheidungen

SwiftPM und Xcode bleiben gleichwertige Beschreibungen derselben Quellen.
`project.yml` ist die reproduzierbare Generatorquelle; das eingecheckte
Projekt ist ohne XcodeGen baubar. Signing, Team und Release-Bundle-ID bleiben
unentschieden. Siehe ADR-0013.

### Neu erstellte Dateien

- `project.yml`,
- `NewEdenNexus.xcodeproj`,
- `Scripts/generate_xcode_project.sh`,
- `Scripts/verify_xcode_project.py`,
- `XcodeSupport/NewEdenNexusTestSupportBundle.swift`,
- `Documentation/Architecture/ADRs/ADR-0013_Xcode-Projekt-und-SwiftPM-Paritaet.md`,
- sechs P09B-Nachweisbilder,
- `Documentation/Progress/Reports/2026-07-23_P09B_Xcode-Projekt-Schemes.md`.

### Geänderte Dateien

Build-/Startanleitung sowie Pflicht-, Architektur-, Prompt-, Test- und
Fortschrittsdokumentation.

### Build-Ergebnis

Xcode App Debug/Release und SDE-Abnahmerunner-Build sowie SwiftPM
Debug/Release erfolgreich. Runner nicht ausgeführt; kein SDE-Download durch
P09B.

### Testergebnis

Xcode: 167 bestanden, 0 fehlgeschlagen, 0 übersprungen. SwiftPM: 167
bestanden, 0 fehlgeschlagen, 0 übersprungen. Paritätscheck: 15 Targets,
sieben Testtargets, zwei gemeinsame Schemes.

### Erkannte Probleme

Erste Zwischenläufe zeigten die XcodeGen-Headerkopie unter
Benutzerskriptsandbox und die notwendige `-parse-as-library`-Option des
Runners. Beide Ursachen wurden begrenzt korrigiert. Kein P09B-kritischer
Fehler bleibt offen.

### Nicht erledigte Punkte

- P10-Rezeptresolver und die 21 nicht aufgelösten offiziellen Referenzen,
- P36-Prozessabbruch-/Neustart-Drill,
- P37-Recheck der dann aktuellen CCP-/Releasebedingungen,
- P34-Dateiaufteilung.

### Aktualisierte Features

`TEC-001`, `TEC-012`, `DAT-009`, `CMP-001`, `OFF-014`, `OFF-020`,
`OFF-025`, `KI-009`, `KI-020`, `KI-025`.

### Nächster Prompt

P10 – Rezept- und Aktivitätsresolver einschließlich `OFF-003`, `OFF-016`,
`KI-004` und `KI-016`.

## 2026-07-23 – P10: Rezept- und Aktivitätsresolver

### Ausgangszustand

P09 stellte rohe, versionsisolierte Blueprint-Produktbezüge bereit. Eine
zentrale fachliche Rezeptwahl fehlte. Im offiziellen Build 3444265 waren 21
Material-/Produktreferenzen ohne passenden Itemtyp bekannt; sie durften nicht
zu unvollständigen Materiallisten führen.

### Ziel

Eindeutige Fertigungs- und Reaktionsrezepte aus genau einer aktiven
SDE-Version deterministisch auflösen und jede fehlende, mehrdeutige oder
referenziell unvollständige Auswahl sichtbar blockieren.

### Durchgeführte Arbeiten

- sendbare Kandidaten-, Ergebnis-, Diagnose- und Fehlerverträge ergänzt,
- `ResolveRecipeUseCase` mit eindeutiger/ausdrücklicher Blueprintwahl,
  stabiler Sortierung und vollständiger Validierung implementiert,
- SwiftData-Katalog um versionsisolierten Kandidatenzugriff und
  Referenzaudit erweitert,
- zentrale Fehleroperation `recipeResolution` mit `NEN-SDE-008` ergänzt,
- Application- und Persistence-Tests für Normal-, Grenz- und Fehlerfälle
  erstellt,
- SDE-Abnahmerunner um Fertigungs-/Reaktionsauflösung und itemgenaue
  Vollprüfung aller Referenzlücken erweitert,
- Xcode-Release-Testbarkeit reproduzierbar in `project.yml` korrigiert,
- Architektur-, Katalog-, Datenmodell-, Status-, Aufgaben- und
  Testdokumentation aktualisiert.

### Zentrale Entscheidungen

Fachliche Auswahl und Validierung liegen in Application; Persistence liefert
nur Kandidaten aus genau einer aktiven Version. Mehrere Blueprints werden
nicht automatisch priorisiert. Unaufgelöste Referenzen blockieren das ganze
Rezept. P10 unterstützt ausschließlich deterministische Fertigung und
Reaktion. Siehe ADR-0014.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/RecipeResolution.swift`,
- `Tests/NewEdenNexusApplicationTests/RecipeResolutionTests.swift`,
- `Tests/NewEdenNexusPersistenceTests/RecipeResolutionPersistenceTests.swift`,
- `Documentation/RECIPE_RESOLUTION.md`,
- `Documentation/Architecture/ADRs/ADR-0014_Deterministischer-Rezeptresolver.md`,
- `Documentation/Progress/Reports/2026-07-23_P10_Rezept-Aktivitaetsresolver.md`.

### Geänderte Dateien

Persistenzadapter, zentrale Fehlerbehandlung, SDE-Abnahmerunner,
Xcode-Projektquelle sowie relevante Architektur-, Daten-, Prompt-, Status-,
Aufgaben-, Problem-, Test- und Fortschrittsdokumentation.

### Build-Ergebnis

SwiftPM Debug/Release, Xcode Debug/Release, beide Xcode-Runner-Builds und
statischer Projektparitätscheck erfolgreich.

### Testergebnis

SwiftPM und Xcode jeweils 181 Tests in Debug und Release, 0 Fehler, 0
übersprungen. Der aktuelle isolierte Build-3444265-Lauf löste ein
Fertigungs- und Reaktionsrezept auf und blockierte alle 21 Referenzlücken
itemgenau.

### Erkannte Probleme

Der erste Xcode-Release-Testlauf war wegen fehlender Release-Testbarkeit der
generierten Module nicht ausführbar. Die Generatorquelle wurde korrigiert und
anschließend vollständig neu geprüft. Der offizielle SDE-Befund mit 21
fehlenden Itemtypen bleibt sichtbar, ist aber kein unkontrollierter
Berechnungsfehler mehr.

### Nicht erledigte Punkte

- Runs, ME, Produktionsgraph und T1-/T2-/Reaktionsketten folgen P13–P19,
- P11-Projektlebenszyklus wurde nicht begonnen,
- unabhängige Punkte für P34, P36 und P37 bleiben offen.

### Aktualisierte Features

`DAT-003`, `DAT-004`, `DAT-005`, `DAT-006`, `DAT-011`, `TEC-005`,
`TEC-007`, `OFF-003`, `OFF-016`, `KI-004`, `KI-016`.

### Nächster Prompt

P11 – Projektlebenszyklus vor Ausführung vollständig spezifizieren und alle
dafür notwendigen offenen Punkte übernehmen.

## 2026-07-24 – P11: Projektlebenszyklus

### Ausgangszustand

Projektmodell und Repository-Port waren vorhanden. `ProjectsView` verwendete
jedoch direkt `@Query` und `modelContext`; zentrale Statusregeln,
Duplizieren, Archivieren und Wiederherstellen fehlten. Schema v4 war aktuell.

### Ziel

Den vollständigen lokalen Projektlebenszyklus zuerst verbindlich
spezifizieren und dann ohne Katalog-, Graph- oder Berechnungsvorgriff
implementieren.

### Durchgeführte Arbeiten

- P11 mit Statusgraph, Archivregel, Architektur, Tests und Definition of Done
  vollständig spezifiziert.
- Application-Service mit injizierbarer Uhr/UUID und typisierten Fehlern
  implementiert.
- Repositoryzugriff für Einzelabfragen und Cancellation gehärtet.
- `ProjectLifecycleViewModel`, Composition Root und vollständige
  Projektansicht mit Filtern, Formular, Statusaktionen, Duplikat,
  Archivbestätigung und Restore umgesetzt.
- zentralen Ladefehler `NEN-PER-006` ergänzt.
- dateibasierte Persistenz-, ViewModel-, App-Integrations-, Architektur- und
  UI-Quelltests ergänzt.
- Xcode-Testhost gegen produktive Store-/SDE-Nebeneffekte isoliert und
  statische Quellprüfungen in den nicht gehosteten Architekturtarget
  verschoben.

### Zentrale Entscheidungen

- Kein dauerhaftes Löschen; Archivierung bleibt reversibel.
- Archivierte Projekte sind schreibgeschützt, aber duplizier- und
  wiederherstellbar.
- Keine Schemaänderung; vorhandener Archivstatus und Projektfelder genügen.
- Katalogbindung bleibt P12.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ProductionProjectLifecycle.swift`
- `Sources/NewEdenNexus/ProjectLifecycleViewModel.swift`
- `Sources/NewEdenNexus/ProjectAppComposition.swift`
- `Sources/NewEdenNexus/AppExecutionEnvironment.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionProjectLifecycleTests.swift`
- `Tests/NewEdenNexusPersistenceTests/ProductionProjectLifecyclePersistenceTests.swift`
- `Tests/NewEdenNexusTests/ProjectLifecycleViewModelTests.swift`
- `Tests/NewEdenNexusArchitectureTests/AppSourceArchitectureTests.swift`
- `Tests/NewEdenNexusArchitectureTests/ProjectLifecycleArchitectureTests.swift`
- `Documentation/PROJECT_LIFECYCLE.md`
- `Documentation/Architecture/ADRs/ADR-0015_Projektlebenszyklus-und-reversible-Archivierung.md`
- `Documentation/Progress/Reports/2026-07-24_P11_Projektlebenszyklus.md`

### Geänderte Dateien

Application-/App-/Persistence-Composition, `ProjectsView`, `RootView`,
Fehlerabbildung, Package-/Xcode-Beschreibung, Tests sowie die verpflichtenden
Status-, Architektur-, Datenmodell-, Test- und Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode bestanden in Debug und Release. Das generierte
Xcode-Projekt enthält weiterhin 15 Targets, sieben Testtargets und zwei
gemeinsame Schemes. Signing- und Teamwerte blieben unverändert.

### Testergebnis

Je Konfiguration **198 Tests, 0 Fehler, 0 übersprungen**. Davon sind 17
P11-spezifisch. Der dateibasierte Lebenszyklus öffnet denselben Store
mehrfach; produktive Benutzerdaten wurden nicht als Testdaten verwendet.

### Erkannte Probleme

Ein zusätzlicher manueller Debug-App-Start zeigte den sicheren lokalen
Storefehler `NEN-PER-001`. Der Lauf wurde nicht als Erfolg gezählt und
veränderte keine Benutzerdaten. `KI-026`/`OFF-026` verlangen eine
nachweislich isolierte Reproduktion vor beziehungsweise innerhalb P12.

Zwischenläufe deckten außerdem doppelte statische Modullinks im gehosteten
Testtarget, SDE-/Keychain-Nebeneffekte beim Testhost und einen hängenden
Dokumenten-TCC-Quelltest auf. Die Targetabhängigkeiten und Testzuordnung
wurden daraufhin korrigiert; alle Abschlussläufe sind grün.

### Nicht erledigte Punkte

- Kataloggestützte Produktauswahl: P12.
- Graph, Runs, ME und Ketten: P13–P19.
- verbleibende direkte SwiftData-Viewzugriffe: P32/P38.
- Eingrenzung des lokalen manuellen Startfehlers: OFF-026.

### Aktualisierte Features

- PRJ-002, PRJ-003 und PRJ-004: vollständig vorhanden.
- PRJ-001: Lebenszyklus und Menge vorhanden, Katalogbindung weiter teilweise.
- TEC-005, TEC-007 und TEC-012: zusätzliche Fehler-, Test- und
  Buildnachweise.

### Nächster Prompt

P12 – Zielproduktauswahl zunächst vollständig spezifizieren und anschließend
ausführen; `OFF-026` als notwendige Voraussetzung mit bearbeiten.

## 2026-07-24 – OFF-026: Storeisolation als P12-Voraussetzung

### Ausgangszustand

P11 war abgeschlossen. Der zusätzliche App-Start hatte den sicheren Fehler
`NEN-PER-001` gezeigt. P12 lag nur als kurzer Entwurf vor. Ein globaler
`~/Library/Application Support/default.store` existierte; Herkunft und
Kompatibilität waren noch nicht geklärt.

### Ziel

P12 vollständig und ausführbar spezifizieren. Anschließend OFF-026
ursächlich klären und einen echten App-Start mit isoliertem Store
nachweisen, ohne eine vorhandene Datei zu löschen, zu ersetzen, zu
verschieben oder ungefragt zu reparieren.

### Durchgeführte Arbeiten

- Projektbuch, Status-, Architektur-, Test- und offene Register sowie
  Quellcode und Git-Diff erneut geprüft.
- P12 mit Zielmodell, Schema-v5-Migration, Katalog-/Resolvergrenze,
  Mengengültigkeit, UX-, Fehler-, Versions-, Test- und DoD-Regeln vollständig
  spezifiziert.
- Für P12 entschieden, keine Marktgruppenobjekte nur zur Navigation zu
  importieren; OFF-021 bleibt bedarfsgesteuert späteren Funktionen
  zugeordnet.
- Globalen `default.store` ausschließlich read-only geprüft: SQLite
  konsistent, aber fremde Tabelle `ZAPIREQUESTMODEL` statt
  New-Eden-Nexus-Signatur.
- app-spezifischen Standardpfad und sichere Legacy-Klassifikation
  implementiert.
- absolutes testbestimmtes Storeargument am Composition Root ergänzt.
- sechs Storepfad-/Signaturtests und einen Startargumenttest ergänzt.
- Xcode-Projekt regeneriert und Parität geprüft.
- echten isolierten App-Prozess gestartet, offenen Pfad per Dateideskriptor
  und Datenbanksignatur geprüft und anschließend geordnet beendet.
- Fremdstore vor und nachher über SHA-256, Größe und Änderungszeit
  verglichen.

### Zentrale Entscheidungen

- Der Produktivstore liegt unter
  `Application Support/NewEdenNexus/NewEdenNexus.store`.
- Ein sicher erkannter eigener Legacy-Store bleibt am bisherigen Ort; es
  erfolgt keine automatische Dateibewegung.
- Fremde Stores werden nicht übernommen oder verändert.
- Ein unlesbarer Legacy-Store scheitert weiterhin sicher statt einen leeren
  Ersatzstore zu erzeugen.
- Der isolierte Startparameter ist nur eine Testgrenze und deaktiviert
  produktive SDE-/Keychain-Nebeneffekte.
- P12 bleibt offen; keine fachliche P12-Implementierung wurde begonnen.

### Neu erstellte Dateien

- `Tests/NewEdenNexusPersistenceTests/NexusDefaultStoreResolutionTests.swift`
- `Documentation/STORE_LOCATION_AND_ISOLATION.md`
- `Documentation/Architecture/ADRs/ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md`
- `Documentation/Progress/Reports/2026-07-24_OFF-026_Isolierter-App-Start.md`

### Geänderte Dateien

- `Sources/NewEdenNexusPersistence/NexusModelContainerFactory.swift`
- `Sources/NewEdenNexus/AppExecutionEnvironment.swift`
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`
- `Tests/NewEdenNexusTests/NewEdenNexusTests.swift`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- P12-Prompt, Promptregister, Architektur-, Datenmodell-, Status-, Feature-,
  Test-, offene Punkte- und Fortschrittsdokumentation sowie `README.md`.

### Build-Ergebnis

- SwiftPM Debug: erfolgreich.
- SwiftPM Release: erfolgreich.
- Xcode Debug: erfolgreich.
- Xcode Release: erfolgreich.
- Xcode-/SwiftPM-Parität: 15 Targets, sieben Testtargets, zwei Schemes.
- Keine Team- oder Projekteinstellung für Signing geändert.

### Testergebnis

- SwiftPM Debug: 205 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- SwiftPM Release: 205 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Debug: 205 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Xcode Release: 205 bestanden, 0 fehlgeschlagen, 0 übersprungen.
- Fokussiert: sieben OFF-026-Fälle bestanden.
- Echter Prozess: isolierter Store konsistent, korrekte Signaturtabellen,
  kein Zugriff auf `default.store`.

### Erkannte Probleme

Ein Teststart mit Store innerhalb des File-Provider-Workspace erzeugte keinen
verwendbaren SQLite-Store und wurde verworfen. Der erfolgreiche
datenschutzneutrale App-Nachweis verwendete deshalb wie vorgesehen
`/private/tmp`. Die Accessibility-Abfrage des GUI-Werkzeugs brach wiederholt
auf Transportebene ab; sie wird nicht als visueller UI-Nachweis gewertet.

### Nicht erledigte Punkte

- P12 ist vollständig spezifiziert, aber nicht implementiert.
- P13 und alle folgenden Fachprompts wurden nicht begonnen.
- OFF-021 bleibt für P27 beziehungsweise einen später nachgewiesenen
  Datenbedarf offen.
- Recovery-UI und benutzergesteuerte Storeverschiebung bleiben P36.

### Aktualisierte Features

- TEC-001: echter isolierter App-Prozess nachgewiesen.
- TEC-003: app-spezifischer Storepfad und sichere Legacy-Erkennung ergänzt.
- TEC-007/TEC-012: 205 Tests in allen vier Konfigurationen.
- PRJ-001: weiterhin teilweise; P12 nun vollständig spezifiziert.
- KI-026/OFF-026: behoben/erledigt.

### Nächster Prompt

P12 – kataloggestützte Zielproduktauswahl anhand der vollständigen
Spezifikation ausführen. P13 nicht automatisch beginnen.

## 2026-07-24 – P12: Kataloggestützte Zielproduktauswahl

### Ausgangszustand

P09 lieferte den lokalen Katalog, P10 den deterministischen Rezeptresolver
und P11 den Projektlebenszyklus. Projekte speicherten ihr Ziel dennoch nur
als Freitext. OFF-026 war erledigt; P13 war nicht begonnen.

### Ziel

Produkt, Aktivität, Blueprint und positive Menge reproduzierbar aus der
aktiven Katalogversion auswählen, Bestandsprojekte erhalten und die Auswahl
über Domain, Application, Persistenz und SwiftUI nutzbar machen.

### Durchgeführte Arbeiten

- validiertes, sendbares Domainziel und lokalisierter Mengenparser,
- Suche, Optionsbildung, Blueprintauswahl und Revalidierung als
  SwiftUI-/SwiftData-freier Application-Service,
- Einzelvalidierung aller Blueprintkandidaten über den P10-Resolver,
- additive v4→v5-Migration und vollständiger Repository-Roundtrip,
- Zielerhalt über Status, Duplikat, Archivierung und Wiederherstellung,
- kataloggestützter Projekteditor mit begrenzter, verzögerter und
  abbrechbarer Suche sowie Aktivitäts-, Kategorie- und Gruppenfiltern,
- Backupversion 5.0.0, stabiler Fehlercode und vollständige Regressionstests,
- alle aktiven offenen Punkte erneut geprüft.

### Zentrale Entscheidungen

CCP-Type-ID und validierter Blueprint sind fachliche Schlüssel; Namen sind
nur Anzeigesnapshots. Bestandsfreitext wird nicht erraten. Bei mehreren
Aktivitäten oder Blueprints entscheidet der Benutzer ausdrücklich.
Marktgruppenobjekte werden ohne konkreten Bedarf nicht importiert.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/ProductionTargetSelection.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV5.swift`
- `Tests/NewEdenNexusDomainTests/ProductionTargetSelectionTests.swift`
- `Tests/NewEdenNexusApplicationTests/ProductionTargetSelectionServiceTests.swift`
- `Documentation/PRODUCT_TARGET_SELECTION.md`
- `Documentation/Architecture/ADRs/ADR-0017_Kataloggebundenes-Produktionsziel-und-Schema-v5.md`
- `Documentation/Progress/Reports/2026-07-24_P12_Zielproduktauswahl.md`

### Geänderte Dateien

Projekt-Domainmodell, Lebenszyklus, Repository, Migrationplan, Backupdienst,
Projekt-ViewModel, Composition Root, Projektansicht, Fehlerbehandlung,
Xcode-Projektmetadaten, bestehende Tests und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM Debug/Release und Xcode Debug/Release erfolgreich. Der direkte
Xcode-Aufruf im File-Provider-Arbeitsordner blockierte beim koordinierten
Lesen der Projektdatei; eine isolierte unveränderte Prüfkopie in
`/private/tmp` bestand beide Konfigurationen.

### Testergebnis

Je 219 Tests in SwiftPM Debug, SwiftPM Release, Xcode Debug und Xcode
Release; 0 fehlgeschlagen und 0 übersprungen. Der fokussierte P12-Lauf
bestand 27 Tests.

### Erkannte Probleme

`ProjectsView.swift` ist durch Lebenszyklus- und Auswahlzustände deutlich
gewachsen. Die rein mechanische Aufteilung ist als `OFF-027`/`KI-027` P34
zugeordnet. Die Computer-Use-Accessibility-Verbindung schloss auf
Transportebene; deshalb wird kein neuer visueller VoiceOver-Nachweis
behauptet.

### Nicht erledigte Punkte

Produktionsgraph, Runs, Materialberechnung und alle P13-Inhalte wurden nicht
begonnen. Die späteren offenen Punkte behalten ihre Zielprompts.

### Aktualisierte Features

PRJ-001 und PRJ-002, TEC-001, TEC-003, TEC-004, TEC-007, TEC-012,
DAT-001 und DAT-006.

### Nächster Prompt

P13 zunächst vollständig spezifizieren und anschließend ausführen. Alle für
P13 notwendigen offenen Punkte sind gemäß `AGENTS.md` einzubeziehen.

## 2026-07-24 – P13: Erklärbarer Produktionsgraph

### Ausgangszustand

P10 bis P12 lieferten Rezeptresolver, Projektlebenszyklus und
kataloggebundenes Ziel in Schema v5. Ein Graphmodell, eine persistente
Graphrepräsentation und eine Graphansicht existierten nicht.

### Ziel

P13 vollständig spezifizieren und anschließend einen deterministischen,
erklärbaren und persistierbaren Produktionsgraphen der ersten Rezeptstufe
umsetzen, ohne Runs, ME oder Rekursion aus P14 bis P18 vorzuziehen.

### Durchgeführte Arbeiten

- P13 einschließlich notwendiger offener Punkte vollständig spezifiziert,
- Graphdomain mit Vorkommens-Knoten, Kanten, Rezeptreferenzen und
  Strukturvalidierung implementiert,
- Resolvergebundene erste Rezeptstufe und Aktualitätsprüfung ergänzt,
- Schema v6, Graphrepository und Backupkompatibilität bis 6.0.0 umgesetzt,
- eigenständige Graphansicht, ViewModel und Composition integriert,
- expliziten SwiftData-Rollback bei Cancellation oder Savefehler ergänzt,
- Migration, Bestandsschutz, Fehler-, Abbruch- und Regressionstests ergänzt,
- Build, Tests, App-Smoke und gesonderten Review ausgeführt.

### Zentrale Entscheidungen

Knotenidentität ist eine Vorkommens-ID; CCP-Type-IDs bleiben fachliche
Referenzen. SwiftData persistiert den validierten Domain-Snapshot kanonisch.
P13 zeigt ausschließlich rohe Mengen der ersten Rezeptstufe.

### Neu erstellte Dateien

Graphdateien in Domain, Application, Persistenz und SwiftUI; fünf
Graphtestsuiten; `PRODUCTION_GRAPH.md`, ADR-0018 und der P13-Abschlussbericht.

### Geänderte Dateien

Composition Root, Runtime, Projekt-/Rootansicht, Fehlerbehandlung,
Migrationsplan, Container, Backupdienst, Paket-/Xcode-Metadaten,
Regressionstests und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM Debug/Release und Xcode Debug/Release erfolgreich. Xcode wurde wegen
der bekannten File-Provider-Blockade aus einer unveränderten isolierten
Prüfkopie ausgeführt. Signing und Team blieben unverändert.

### Testergebnis

SwiftPM Debug und Release jeweils 238 Tests ohne Fehler oder Übersprung.
Alle sieben Xcode-Testtargets bestanden in Debug und Release. Der
abschließend gebaute isolierte App-Prozess erzeugte einen integren
Schema-v6-Store.

### Erkannte Probleme

Die visuelle Computer-Use-Verbindung war nicht verfügbar; ein neuer
Screenshot- oder VoiceOver-Manuallauf wird nicht behauptet. Die
Accessibility-Metadaten und UI-Schichtengrenzen sind automatisiert geprüft.

### Nicht erledigte Punkte

Runs und Outputberechnung P14, ME P15, rekursive T1-/T2-/Reaktionsketten
P16–P18 sowie Aggregation und Überlaufregel P19. Recovery-Lebenszyklus bleibt
P36, mechanische Projektview-Teilung P34.

### Aktualisierte Features

CAL-001, TEC-001, TEC-003, TEC-007 und TEC-012. OFF-004/KI-003 ist nun
teilweise statt vollständig offen; OFF-006, OFF-009, OFF-021 und OFF-027
wurden erneut geprüft.

### Nächster Prompt

P14 zunächst vollständig spezifizieren und anschließend ausführen. P14 wurde
in P13 nicht begonnen.

## 2026-07-24 – P14: Runs und Ausgabemengen

### Ausgangszustand

P13 lieferte Graphformat 1, Rezeptoutput und rohe Mengen der ersten
Rezeptstufe. Runs, tatsächliche Ausgabe, Überschuss und Formelprovenienz
existierten noch nicht. P15 war nicht begonnen.

### Ziel

P14 vollständig spezifizieren und anschließend eine deterministische,
integer- und überlaufsichere Run-/Outputberechnung über Domain, Application,
Persistenz und Graphansicht umsetzen.

### Durchgeführte Arbeiten

- P14 einschließlich notwendiger offener Punkte vollständig spezifiziert,
- `ProductionRunCalculation` mit Formelversion 1, Quotient-/Rest-Ceiling,
  geprüftem Produkt und manipulationssicherer Decodierung implementiert,
- Graphformat 2 und konsistente Runwerte je Rezeptknoten ergänzt,
- Format-1-Bestand lesbar und als veraltet erhalten,
- Graphservice, Repository, ViewModel und Graphansicht integriert,
- echte additive Schema-v7-Modellstufe samt Formelversionsmetadatum ergänzt,
- Backupversion 7.0.0 und Kompatibilität 1.0.0 bis 7.0.0 umgesetzt,
- Grenz-, Overflow-, Manipulations-, Fertigungs-, Reaktions-, Persistenz-,
  Migrations-, Backup-, UI- und Architekturtests ergänzt,
- SwiftPM/Xcode Debug/Release, isolierten App-Smoke und Review ausgeführt.

### Zentrale Entscheidungen

Runs verwenden ausschließlich Ganzzahlen. `maxProductionLimit` bleibt
SDE-Provenienz und wird nicht als Projekt-/Jobgrenze verwendet.
Bestandsgraphen werden nicht stillschweigend neu berechnet.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionRunCalculation.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV7.swift`
- `Tests/NewEdenNexusDomainTests/ProductionRunCalculationTests.swift`
- `Documentation/RUNS_AND_OUTPUTS.md`
- `Documentation/Architecture/ADRs/ADR-0019_Integer-Runs-Graphformat-2-und-Schema-v7.md`
- `Documentation/Progress/Reports/2026-07-24_P14_Runs-Ausgabemengen.md`

### Geänderte Dateien

Graphdomain und -service, Graphrepository, Graphansicht, Migrationplan,
Container, Backupdienst, Xcode-Projektmetadaten, Graph-/Persistenz-/
Migrations-/Backup-/UI-Tests sowie Pflichtdokumentation.

### Build-Ergebnis

SwiftPM und Xcode bestanden Debug und Release. Xcode verwendete isolierte
DerivedData, Signing blieb deaktiviert und Teamwerte wurden nicht geändert.

### Testergebnis

Je 253 Tests in SwiftPM Debug, SwiftPM Release, Xcode Debug und Xcode
Release; 0 fehlgeschlagen und 0 übersprungen. Ein echter isolierter
Debug-App-Prozess lief stabil; sein Schema-v7-Store bestand
`integrity_check`.

### Erkannte Probleme

Eine zunächst nominelle v7-Stufe mit unverändert wiederverwendetem
v6-Modell reproduzierte in der vollständigen v3-Migrationskette einen
SwiftData-Prozessabbruch. Die Ursache wurde durch eine echte additive
v7-Modellversion mit optionaler Formelversionsspalte behoben und mit der
vollständigen Testmatrix regressionsgeprüft.

### Nicht erledigte Punkte

ME P15, rekursive T1-/T2-/Reaktionsketten P16–P18,
Materialaggregation/deren Überlaufregel P19, Recovery-Drill P36 und die
mechanische Projekteditor-Teilung P34. P15 wurde nicht begonnen.

### Aktualisierte Features

CAL-001, CAL-002, TEC-001, TEC-003, TEC-007 und TEC-012. OFF-004,
OFF-006, OFF-009, OFF-021 und OFF-027 wurden erneut geprüft.

### Nächster Prompt

P15 – Material Efficiency zunächst vollständig spezifizieren und erst
anschließend ausführen.

## 2026-07-24 – P15: Material Efficiency

### Ausgangszustand

P14 lieferte Graphformat 2 und Schema v7 mit vollständigen Runs, Ausgabe und
Überschuss der ersten Rezeptstufe. Projekt-ME, Materialgesamtmengen,
Rundung, Ersparnis und Materialformelprovenienz fehlten. P16 war nicht
begonnen.

### Ziel

P15 vollständig spezifizieren und die verifizierte EVE-Blueprint-ME-Regel
zentral, deterministisch, integer- und überlaufsicher über Projekt, Graph,
Persistenz und UI umsetzen.

### Durchgeführte Arbeiten

- Projektbuch und aktuelle offizielle CCP-Regeln abgeglichen,
- P15 einschließlich notwendiger offener Punkte vollständig spezifiziert,
- `ProductionMaterialCalculation` mit Formelversion 1 implementiert,
- Rohbedarf, Effektivbedarf, Ersparnis, Jobaufrundung und
  Ein-Stück-je-Run-Schutz ergänzt,
- Projekt-ME 0 bis 10 und Reaktionsgrenze ME 0 im Lebenszyklus integriert,
- Graphformat 3 und konsistente Materialberechnung je Kante ergänzt,
- Format-1-/2-Bestand lesbar und veraltet erhalten,
- echte additive Schema-v8-Modellstufe und Backupversion 8.0.0 ergänzt,
- Projektliste, Editor und Graphansicht um ME-/Materialwerte ergänzt,
- Domain-, Application-, Persistenz-, Migration-, Backup-, ViewModel-,
  UI- und Architekturtests ergänzt,
- SwiftPM/Xcode Debug/Release, isolierten App-Smoke und Review ausgeführt.

### Zentrale Entscheidungen

Blueprint-ME wird über den gesamten Job ganzzahlig angewendet und einmal
aufgerundet. Basismenge eins je Run bleibt geschützt. Reaktionen erhalten
keinen Blueprint-ME-Wert. Alte Graphpayloads werden nicht still fachlich
neu berechnet.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionMaterialCalculation.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV8.swift`
- `Tests/NewEdenNexusDomainTests/ProductionMaterialCalculationTests.swift`
- `Documentation/MATERIAL_EFFICIENCY.md`
- `Documentation/Architecture/ADRs/ADR-0020_Integer-ME-Graphformat-3-und-Schema-v8.md`
- `Documentation/Progress/Reports/2026-07-24_P15_Material-Efficiency.md`

### Geänderte Dateien

Projekt-/Graphdomain und Application-Services, Projekt-/Graphrepository,
Migrationplan, Container, Backupdienst, Projekt-/Graphansicht,
Xcode-Projektmetadaten, zugehörige Tests und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM und Xcode bestanden Debug und Release. Xcode verwendete isolierte
DerivedData, Signing blieb deaktiviert und Teamwerte wurden nicht geändert.

### Testergebnis

Je 273 Tests in SwiftPM Debug, SwiftPM Release, Xcode Debug und Xcode
Release; 0 fehlgeschlagen und 0 übersprungen. Ein echter isolierter
Debug-App-Prozess lief stabil; sein Schema-v8-Store bestand
`integrity_check`.

### Erkannte Probleme

Ein fokussierter Migrationstest verwendete zunächst nach der Migration einen
historischen statt des aktuellen Schema-v8-Typs und löste einen
SwiftData-Prozessabbruch aus. Der Testzugriff und ein falsch positioniertes
Testargument wurden korrigiert; alle vollständigen Läufe bestanden danach.

### Nicht erledigte Punkte

Rekursive T1-/T2-/Reaktionsketten P16–P18,
Materialaggregation/deren Summenüberlaufregel P19, Recovery-Drill P36 und
mechanische Projekteditor-Teilung P34. P16 wurde nicht begonnen.

### Aktualisierte Features

CAL-001, CAL-003, PRJ-001/002, TEC-001, TEC-003, TEC-004, TEC-007 und
TEC-012. OFF-004, OFF-006, OFF-009, OFF-021 und OFF-027 wurden erneut
geprüft.

### Nächster Prompt

P16 – T1-Berechnung zunächst vollständig spezifizieren und erst
anschließend ausführen.

## 2026-07-24 – P16: T1-Berechnung

### Ausgangszustand

P15 lieferte Graphformat 3 mit einer berechneten Zielrezeptstufe. Rekursive
Manufacturing-Zwischenprodukte, Blattgründe und Expansionsschutz fehlten.

### Ziel

P16 vollständig spezifizieren und eine deterministische,
Manufacturing-only-T1-Kette mit vollständigem Bestandsschutz umsetzen.

### Durchgeführte Arbeiten

- Projektbuch, Quellcode, Tests und offene Register geprüft,
- P16 mit Referenzketten, Abbruchregeln und Sollgraphen spezifiziert,
- rekursive Rezeptauflösung und Graphformat 4 umgesetzt,
- Runs, Ausgabe, Überschuss und Materialbedarf je Stufe ergänzt,
- Ziel- und neutralen Zwischenprodukt-ME mit Herkunft gespeichert,
- Material- und Reaktionsblattgründe ergänzt,
- Zyklen, Tiefe, Knotenlimit, Resolverfehler und Cancellation abgesichert,
- Format-1-/2-/3-Bestand lesbar und veraltet erhalten,
- Graphansicht und Persistenzmetadaten aktualisiert,
- Tests, Xcode-Projekt, isolierten App-Smoke und Review ausgeführt.

### Zentrale Entscheidungen

P16 löst nur Manufacturing auf und rät keine Tech-Stufe. Automatisch
entdeckte Zwischenprodukte tragen sichtbar den neutralen Planungswert ME 0.
Format 4 bleibt in der Schema-v8-Payload; keine neue Migration ist nötig.

### Neu erstellte Dateien

- `Documentation/T1_CALCULATION.md`
- `Documentation/Architecture/ADRs/ADR-0021_Manufacturing-Rekursion-und-Graphformat-4.md`
- `Documentation/Progress/Reports/2026-07-24_P16_T1-Berechnung.md`

### Geänderte Dateien

Graphdomain, Graph-Application-Service, Graphrepository, Graphansicht,
Domain-/Application-/Persistence-/ViewModel-/Architekturtests,
Xcode-Projektmetadaten und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM und Xcode bestanden Debug und Release. Signing und Teamwerte wurden
nicht geändert.

### Testergebnis

Je 280 Tests in SwiftPM Debug, SwiftPM Release, Xcode Debug und Xcode
Release; 0 fehlgeschlagen und 0 übersprungen. Isolierter App-/Store-Smoke:
`integrity_check = ok`.

### Erkannte Probleme

Frühere Tests verwendeten den damaligen `current`-Alias für Graphformat 3.
Sie wurden als explizite Altformatprüfungen erhalten; neue aktuelle Fixtures
tragen die vollständige Format-4-Provenienz.

### Nicht erledigte Punkte

T2/Erfindung P17, Reaktionsrekursion P18, Aggregation und Summenüberlauf
P19, Recovery-Drill P36 und Editoraufteilung P34. P17 wurde nicht begonnen.

### Aktualisierte Features

CAL-001 und CAL-004, TEC-001/007/012 sowie OFF-004, OFF-009 und OFF-021.

### Nächster Prompt

P17 – T2-Berechnung zunächst vollständig spezifizieren und anschließend
ausführen.

## 2026-07-24 – P17/P18: Industrie-Regelgrundlage und vollständige Spezifikation

### Ausgangszustand

P16 war vollständig umgesetzt und reviewed. P17 und P18 bestanden nur aus
kurzen Entwürfen. Der aktuelle Katalog konnte Manufacturing und Reaktionen
auflösen, importierte aber weder MetaGroups beziehungsweise
`types.metaGroupID` noch Aktivitäts-Skills oder die für Decryptoren,
Facilities und Rigs benötigten Dogmadaten.

### Ziel

Die nach P16 notwendigen T2-, Invention- und Reaktionsregeln den bestehenden
Prompts P17 und P18 eindeutig zuordnen, ohne P16 wieder zu öffnen, eine neue
Promptnummer einzuschieben oder Implementierung vorwegzunehmen.

### Durchgeführte Arbeiten

- aktuellen P16-Prompt, Abschlussbericht, Graphcode, Katalogmodell und offene
  Register geprüft,
- verifizierte gemeinsame Spezifikationsgrundlage
  `INDUSTRY_RULES_FOUNDATION.md` angelegt,
- P17 vollständig um Tech-Klassifikation, Blueprint-Herkunft,
  Inventionsabgrenzung, Decryptoren, minimale SDE-Erweiterung,
  Industry-Preflight, Migration, Referenzfälle und Abnahmekriterien ergänzt,
- P18 vollständig um Reaktionsrekursion, neutrale und modifizierte
  Produktionskontexte, Facility-/Reactor-/Rig-/Security-/Skillregeln,
  Rundungs- und Verifikationsgates, P43-Abgrenzung, Referenzfälle und
  Abnahmekriterien ergänzt,
- `OFF-021`/`KI-021` auf den nun belegten P17-/P18-SDE-Bedarf vorgezogen,
- `OFF-028`/`KI-028` für die gemeinsame Industrie-Regelbasis und den
  Agent-Preflight ergänzt,
- Entwickler-Menü, Promptregister, Roadmap, Projektstatus,
  Feature-Matrix, SDE-Dokumentation und offene Aufgaben angepasst.

### Zentrale Entscheidungen

P16 bleibt unverändert abgeschlossen. P17 legt die gemeinsame
Industrie-Regelbasis an; P18 erweitert sie. Reguläre Invention,
historische T2-BPOs und manuelle Planungsszenarien werden getrennt.
P17 implementiert keine stochastische Invention-Kostenoptimierung. P18
implementiert keine vollständige Anlagen-, Fuel-, Slot- oder
Kalenderverwaltung aus P43.

Ein modifizierter Reaktionskontext darf nur mit aktuell verifizierten
Security- und Rundungsregeln als exakt gelten. Andernfalls bleibt nur ein
ausdrücklich gekennzeichnetes neutrales Basisszenario zulässig.

### Build- und Testergebnis

Keine Codeimplementierung und deshalb kein neuer Build- oder Testlauf.
Die zuletzt nachgewiesenen 280 Tests aus P16 werden nicht als Prüfung der
neuen, noch nicht implementierten P17-/P18-Anforderungen ausgegeben.

### Nicht erledigte Punkte

- P17 implementieren, testen, migrieren und reviewen,
- anschließend P18 implementieren, testen, migrieren und reviewen,
- P19 Aggregation und Summenüberlauf,
- spätere vollständige Reaktionsverwaltung P43.

### Nächster Prompt

P17 – die vollständig spezifizierte T2-Berechnung ausführen.

## 2026-07-24 – P17: T2-Berechnung

### Ausgangszustand

P16 war mit Graphformat 4 abgeschlossen. T2-Klassifikation,
Blueprintqualität, Invention-/Decryptorregeln und Regelprovenienz fehlten.
P17 war vollständig spezifiziert; P18 wurde nicht begonnen.

### Ziel

T2-Manufacturing-Ketten deterministisch und kataloggebunden auflösen,
reguläre und historische Blueprintqualitäten trennen und Reaktionen als
bewusste P18-Grenze erhalten.

### Durchgeführte Arbeiten

Versionierten Industrie-Regelvertrag, T2-SDE-Port, Graphformat 5,
stufenbezogene T1-/T2-Qualität, T3-Abgrenzung, UI-Darstellung und
Real-SDE-Nachweis implementiert. Die Decryptor-Type-IDs 34201 bis 34208
wurden über offizielle CCP-Endpunkte verifiziert. Alle aktiven offenen
Punkte wurden erneut geprüft und die P17-Anteile aktualisiert.

### Zentrale Entscheidungen

T2 wird über die konkrete Invention-Beziehung plus fertigbaren
Ausgangs-Blueprint bestimmt. Keine Namens-/ID-Heuristik, keine
Zufallssimulation und kein redundanter SDE-Blindimport. Historische
T2-BPOs bleiben explizite Überschreibungen.

### Neu erstellte Dateien

`IndustryRules.swift`, `T2IndustryData.swift`, zwei Testdateien,
`T2_CALCULATION.md`, ADR-0022 und der P17-Abschlussbericht.

### Geänderte Dateien

Produktionsgraph in Domain/Application/UI, App-Composition,
Real-SDE-Runner, Tests, Xcode-Projekt und verpflichtende Dokumentation.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Xcode lief wegen eines
read-only diagnostizierten macOS-Dateikoordinationslocks aus einer
identischen isolierten Quellkopie. Projektparität: 15 Targets, sieben
Testtargets, zwei gemeinsame Schemes.

### Testergebnis

Vier Suites mit jeweils 292 bestandenen Tests. Offizieller Build 3444265
einschließlich T2-Invention erfolgreich. Isolierter App-Store:
`integrity_check = ok`.

### Erkannte Probleme

Im Review wurden eine fehlende T3-Grenze und eine unvollständige Bindung der
Knotenqualität an die Graph-Katalogprovenienz erkannt und behoben. Xcode
meldete nicht fehlschlagende AppIntents-/Testhost-/Migrationshinweise.

### Nicht erledigte Punkte

Reaktionen P18, Aggregation P19, UI für freie T2-Stufenüberschreibungen und
die unabhängigen P34/P36/P37-Gates.

### Aktualisierte Features

CAL-001, CAL-003, CAL-005, DAT-010, DAT-011, TEC-001, TEC-007 und TEC-012
sowie OFF-004, OFF-021 und OFF-028.

### Nächster Prompt

P18 – Reaktionsstufen anhand der vollständigen Spezifikation ausführen.

## 2026-07-24 – P18: Reaktionsstufen

### Ausgangszustand

P17 war mit Graphformat 5 abgeschlossen. Reaktionsrezepte ließen sich
auflösen, blieben im Produktionsgraphen aber als zurückgestellte Blätter.
Facility-, Reactor-, Rig-, Security- und Skillregeln waren noch nicht
versioniert in die Berechnung eingebunden.

### Ziel

Reaktionen einschließlich Reaction→Reaction deterministisch, erklärbar und
SDE-gebunden in den Produktionsgraphen integrieren, ohne vollständiges
Reaktionsmanagement aus P43 vorzuziehen.

### Durchgeführte Arbeiten

Bedarfsgesteuertes Dogma-Mapping, `ReactionRuleProfile`, zentrale
Material-/Zeitberechnung, neutrale und modifizierte Kontexte, SwiftData-
Adapter, Graphformat 6, Expansionsrichtlinie 3, Schema v9, UI-Darstellung,
Migration, Backup und Real-SDE-Prüfung implementiert.

### Zentrale Entscheidungen

Unvollständige oder nicht verifizierte Regeln schlagen geschlossen fehl.
Ein neutraler Kontext behauptet keine reale Struktur. Reaktionen verwenden
kein Blueprint-ME/TE. Die vorhandene Graphpayload trägt den Kontext; nur das
kataloggebundene Regelprofil benötigt einen neuen SwiftData-Datensatz.

### Neu erstellte Dateien

`ReactionCalculation.swift`, `ReactionIndustryData.swift`,
`SwiftDataReactionIndustryData.swift`, `NexusSchemaV9.swift`,
Reaktions- und Persistenztests, `REACTION_CALCULATION.md` und ADR-0023.

### Geänderte Dateien

SDE-Mapping und -Persistenz, Produktionsgraph in Domain/Application/UI,
App-Composition, Backup, Migrationen, Real-SDE-Runner, Fixtures,
Xcode-Projekt und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Projektparität: 15 Targets,
sieben Testtargets, zwei gemeinsame Schemes.

### Testergebnis

Je 310 Tests in SwiftPM und Xcode Debug/Release, alle erfolgreich. Build
3444265 real geprüft. Isolierter Schema-v9-App-Store:
`integrity_check = ok`.

### Erkannte Probleme

Ein finaler Debuglauf fand eine fehlerhafte Swift-Guard-Formatierung; sie
wurde korrigiert und vollständig nachgetestet. Die reale Abnahme wurde um
die Forderung ergänzt, dass Formeln ausschließlich die Reaktionsaktivität
besitzen. Keine produktiven Benutzerdaten wurden geöffnet.

### Nicht erledigte Punkte

Materialaggregation P19, vollständiges Reaktionsmanagement P43 und die
unabhängigen P34/P36/P37-Gates.

### Aktualisierte Features

CAL-001, CAL-006, DAT-005, DAT-010, TEC-001, TEC-003, TEC-004, TEC-007 und
TEC-012 sowie OFF-004, OFF-006, OFF-021 und OFF-028.

### Nächster Prompt

P19 – Aggregation und Graphschutz vollständig spezifizieren und ausführen.

## 2026-07-24 – P19: Aggregation und Graphschutz

### Ausgangszustand

Graphformat 6 löste T1-, T2- und Reaktionszweige rekursiv auf, bewahrte
Materialvorkommen aber absichtlich getrennt. OFF-004/KI-003 verlangten die
Zusammenführung; OFF-009/KI-012 die noch fehlende Überlaufregel für
Zweigsummen. Formate 1 bis 6, Schema v9 und Backupformat 9.0.0 waren
abgenommen. Der Arbeitsbaum enthielt die unveröffentlichten P09B–P18-
Änderungen und wurde nicht bereinigt oder verworfen.

### Ziel

Eine deterministische, erklärbare Endmaterialaggregation auf dem
vollständigen Produktionsgraphen implementieren und persistierte Graphen
gegen fehlerhafte Beziehungen, Lastgrenzen, manipulierte Summen und
Überlauf schützen.

### Durchgeführte Arbeiten

- P19 vollständig mit Zweck, Voraussetzungen, Risiken, Fachregeln,
  Testmatrix und 15 messbaren Abnahmekriterien spezifiziert,
- `ProductionGraphMaterialAggregator` als reine Domainkomponente ergänzt,
- Type-ID-Gruppierung, effektive Manufacturing-/Reaktionsmengen,
  Vorkommens- und Wurzelpfade sowie deterministische Sortierung umgesetzt,
- Graphformat 7 und Aggregationsformel 1 in die kanonische Payload
  aufgenommen,
- geladene Payloads auf maximal 64 Ebenen, 25.000 Knoten und eindeutige
  Geschwister-Sortierung begrenzt; Zyklusprüfung iterativ ausgeführt,
- gespeicherte Aggregation beim Laden neu berechnet und exakt verglichen,
- Graphansicht um aggregierte Positionen und aufklappbare Pfade ergänzt,
- Domain-, Application-, Persistenz-, ViewModel- und Architekturtests
  erweitert,
- Xcode-Projektdatei aus `project.yml` neu erzeugt und Parität geprüft,
- Pflichtdokumentation, ADR und Abschlussbericht aktualisiert.

### Zentrale Entscheidungen

- Aggregationsschlüssel ist ausschließlich die CCP-Type-ID.
- Nur Materialblätter werden gezählt; Zwischenprodukte nicht doppelt.
- Jede positive Addition bleibt `Int64` und nutzt
  `addingReportingOverflow`.
- Ein Kandidat wird erst nach vollständiger Aggregation und Validierung
  gespeichert.
- P19 ändert weder SwiftData-Schema v9 noch Backupformat 9.0.0.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProductionGraphAggregation.swift`
- `Tests/NewEdenNexusDomainTests/ProductionGraphAggregationTests.swift`
- `Documentation/MATERIAL_AGGREGATION.md`
- `Documentation/Architecture/ADRs/ADR-0024_Graphaggregation-und-Graphformat-7.md`
- `Documentation/Progress/Reports/2026-07-24_P19_Aggregation-Graphschutz.md`

### Geänderte Dateien

Produktionsgraph in Domain/Application/UI, zugehörige Service-, Domain-,
Persistenz-, ViewModel- und Architekturtests, Xcode-Projektmetadaten sowie
alle verpflichtenden Status-, Architektur-, Test- und Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Projektparität: 15 Targets,
sieben Testtargets, zwei gemeinsame Schemes.

### Testergebnis

Je 321 Tests in SwiftPM und Xcode Debug/Release, 0 Fehler und 0
übersprungene Tests. Isolierter Schema-v9-App-Store während und nach dem
Lauf: `PRAGMA integrity_check = ok`.

### Erkannte Probleme

Der direkte Workspace-Build kollidierte einmal mit während des Builds
geänderten Eingaben; die Abschlussprüfung lief deshalb aus einer
identischen temporären Quellkopie. Ohne umgeleiteten oder freigegebenen
Modulcache blockierte die Dateisandbox SwiftPM. Keine fachliche Regression
blieb offen.

### Nicht erledigte Punkte

Bestände/Verfügbarkeit P20–P22, Sicherheitsbestände/Reservierungen P23–P25,
Build-or-Buy P26 sowie die unabhängigen P34/P36/P37-Gates.

### Aktualisierte Features

CAL-001, CAL-004 bis CAL-008, TEC-001, TEC-003, TEC-007 und TEC-012;
OFF-004/KI-003 und OFF-009/KI-012 wurden geschlossen.

### Nächster Prompt

P20 – Lager und manuelle Bestände vollständig spezifizieren und
anschließend ausführen. P20 wurde nicht begonnen.

## 2026-07-24 – P20: Lager und manuelle Bestände

### Ausgangszustand

Schema v9 enthielt SDE-, Projekt-, Graph- und Reaktionsdaten, aber keine
Lager- oder Bestandsmodelle. `Assets` zeigte einen Platzhalter. OFF-005 und
KI-005 beschrieben gemeinsam die noch fehlenden Pakete P20–P25. Der
Arbeitsbaum enthielt unveröffentlichte Änderungen aus P09B–P19; sie wurden
nicht bereinigt, verworfen oder überschrieben.

### Ziel

Lokale logische Lager und manuelle, kataloggebundene Bestandsmengen als
migrationssichere Grundlage für CSV-Import, Verfügbarkeit,
Sicherheitsbestände und Reservierungen implementieren.

### Durchgeführte Arbeiten

- P20 vollständig mit Fachregeln, Risiken, Scopegrenzen und zwölf
  messbaren Abnahmekriterien spezifiziert,
- Lager- und Bestandsdomänenmodelle ergänzt,
- Application-Service und Repository-Port mit Katalogvalidierung,
  Archivschreibschutz und eindeutigen Update-Regeln umgesetzt,
- SwiftData-Repository und additives Schema v10 ergänzt,
- v9→v10-Migration und Backupformat 10.0.0 umgesetzt,
- Assets-Platzhalter durch eine native Lager-/Bestandsverwaltung ersetzt,
- Loading-, Empty-, Error-, Fortschritts-, Archiv- und
  Löschbestätigungszustände ergänzt,
- Fehlercodes `NEN-INV-001` und `NEN-INV-002` zentral registriert,
- Domain-, Service-, Persistenz-, Migrations-, Backup- und
  Architekturtests ergänzt,
- Xcode-Projekt neu erzeugt und die Parität verifiziert,
- OFF-005/KI-005 geprüft und auf den verbleibenden P21–P25-Anteil
  präzisiert,
- Pflichtdokumentation, ADR und Abschlussbericht aktualisiert.

### Zentrale Entscheidungen

- P20 speichert aggregierte manuelle Mengen, keine ESI-Assetinstanzen.
- `(Lager-ID, CCP-Type-ID)` ist der fachliche Eindeutigkeitsschlüssel.
- Mengen sind positive `Int64`-Werte; Bearbeitung ersetzt statt zu addieren.
- Lager werden reversibel archiviert und nicht hart gelöscht.
- Katalogname, Buildnummer und Inhaltshash werden bei der Validierung
  gespeichert.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/Inventory.swift`
- `Sources/NewEdenNexusApplication/InventoryManagement.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV10.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataInventoryRepository.swift`
- `Sources/NewEdenNexus/InventoryAppComposition.swift`
- `Sources/NewEdenNexus/InventoryViewModel.swift`
- `Sources/NewEdenNexus/InventoryView.swift`
- `Sources/NewEdenNexus/InventoryEditorViews.swift`
- `Tests/NewEdenNexusDomainTests/InventoryTests.swift`
- `Tests/NewEdenNexusApplicationTests/InventoryManagementServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/InventoryPersistenceTests.swift`
- `Tests/NewEdenNexusArchitectureTests/InventoryArchitectureTests.swift`
- `Documentation/INVENTORY_MANAGEMENT.md`
- `Documentation/Architecture/ADRs/ADR-0025_Lokale-Lager-und-manuelle-Bestaende.md`
- `Documentation/Progress/Reports/2026-07-24_P20_Lager-und-manuelle-Bestaende.md`

### Geänderte Dateien

App-Composition, Root-/Assets-Navigation, zentrale Fehlerbehandlung,
Migrationsplan, ModelContainer-Factory, Backupdienst, Xcode-Projektmetadaten
sowie alle verpflichtenden Status-, Architektur-, Test- und
Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Projektparität: 15 Targets,
sieben Testtargets, zwei gemeinsame Schemes.

### Testergebnis

Je 335 Tests in SwiftPM und Xcode Debug/Release, 0 Fehler und 0
übersprungene Tests. Die Xcode-Ergebnisdatenbanken bestätigen jeweils 335
erfolgreiche Testläufe.

### Erkannte Probleme

Die eingeschränkte Umgebung konnte benutzerweite SwiftPM-Caches und den
SwiftData-Makroserver im ersten Sandbox-Xcode-Lauf nicht verwenden.
Abschlussläufe nutzten isolierte temporäre Cache-/Derived-Data-Pfade und
die freigegebene Xcode-Ausführung. Nach einer Bereinigung mussten lokal
ausgelagerte iCloud-Projektdateien erneut heruntergeladen werden. Keine
fachliche Regression blieb offen.

### Nicht erledigte Punkte

CSV-Import P21, Verfügbarkeit/Ausschlüsse P22, Sicherheitsbestände P23,
Reservierungen P24/P25 sowie die unabhängigen P34/P36/P37-Gates. Keine neue
visuelle VoiceOver-Sitzung; vollständige Bedienabnahme bleibt P35/P37.

### Aktualisierte Features

INV-001, TEC-001, TEC-003, TEC-004, TEC-007, TEC-012 sowie
OFF-005/KI-005, KI-006 und KI-013.

### Nächster Prompt

P21 – CSV-Bestandsimport vollständig spezifizieren und anschließend
ausführen. P21 wurde nicht begonnen.

## 2026-07-24 – P21: CSV-Bestandsimport

### Ausgangszustand

P20 stellte Lager und manuelle Bestandspositionen in Schema v10 bereit.
Parser, Vorschau, Konfliktentscheidungen, atomarer Import und Bericht
fehlten. Bestehende uncommittete Änderungen wurden erhalten.

### Ziel

Einen sicheren CSV-Bestandsimport vollständig spezifizieren und als
prüfbaren Preview-before-write-Workflow umsetzen.

### Durchgeführte Arbeiten

- vollständige Spezifikation mit 17 messbaren Abnahmekriterien erstellt,
- begrenzten Dateileser und CSV-Parser für relevante Kodierungen,
  Delimiter, Quotes und Zeilenenden umgesetzt,
- explizites Spaltenmapping und itemgenaue schreibfreie Vorschau ergänzt,
- ungültige, unbekannte, neue und bestehende Positionen differenziert,
- doppelte Type-IDs vollständig abgelehnt,
- Ersetzen-/Überspringen-Entscheidungen und ausdrückliche
  Gesamtbestätigung umgesetzt,
- veraltete Datei-, Lager-, Bestands- und Katalogzustände geschützt,
- Mutationen und bereinigten Bericht atomar persistiert,
- additives Schema v11, Migration und Backupformat 11.0.0 ergänzt,
- native Importansicht mit Fortschritt, Abbruch, Fehler und Bericht ergänzt,
- versionierte Fixtures sowie Parser-, Service-, Persistenz-, Migrations-,
  Backup- und Architekturtests erstellt,
- Pflichtdokumentation, ADR und Abschlussbericht aktualisiert.

### Zentrale Entscheidungen

- Die Vorschau schreibt niemals.
- Ein Import zielt immer auf ein vorhandenes aktives Lager.
- Positive exakte `Int64`-Mengen werden ersetzt, niemals still addiert.
- Alle Vorkommen einer doppelten Type-ID sind ungültig, auch wenn eine
  betroffene Zeile zusätzlich einen Mengenfehler besitzt.
- CSV-Rohdaten und vollständige lokale Pfade werden nicht gespeichert.

### Neu erstellte Dateien

- `Sources/NewEdenNexusApplication/InventoryCSVImport.swift`
- `Sources/NewEdenNexusInfrastructure/DelimitedInventoryCSVParser.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV11.swift`
- `Sources/NewEdenNexus/InventoryCSVImportView.swift`
- `Sources/NewEdenNexus/InventoryCSVImportViewModel.swift`
- `Tests/NewEdenNexusApplicationTests/InventoryCSVImportServiceTests.swift`
- `Tests/NewEdenNexusInfrastructureTests/InventoryCSVParserTests.swift`
- `Tests/NewEdenNexusPersistenceTests/InventoryCSVImportPersistenceTests.swift`
- `Tests/NewEdenNexusTestSupport/InventoryCSVReferenceFixture.swift`
- versionierte CSV-Fixtures unter
  `Tests/NewEdenNexusTestSupport/Fixtures/InventoryCSV/v1`
- `Documentation/INVENTORY_CSV_IMPORT.md`
- `Documentation/Architecture/ADRs/ADR-0026_Sicherer-CSV-Bestandsimport-und-Schema-v11.md`
- `Documentation/Progress/Reports/2026-07-24_P21_CSV-Bestandsimport.md`

### Geänderte Dateien

Inventory-Repository und Composition, Lageransicht und ViewModel,
Migrationsplan, Containerfactory, Backupdienst, zentrale Fehlerbehandlung,
Backup- und Architekturtests, generiertes Xcode-Projekt sowie alle
verpflichtenden Status-, Architektur-, Test- und Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Projektparität: 15 Targets,
sieben Testtargets, zwei gemeinsame Schemes.

### Testergebnis

Je 353 Tests in SwiftPM und Xcode Debug/Release, 0 Fehler und 0
übersprungene Tests. Ein isolierter Schema-v11-App-Store meldete
`PRAGMA integrity_check = ok`.

### Erkannte Probleme

Der Parser behandelte das von Swift als einzelnes `Character` gelieferte
CRLF zunächst nicht als Zeilenende. Die Korrektur erkennt CR, LF und CRLF.
Die Kontrollprüfung ergänzte außerdem die vollständige Duplikatablehnung
für Zeilen, die zusätzlich einen Mengenfehler besitzen.

### Nicht erledigte Punkte

Verfügbarkeit/Ausschlüsse P22, Sicherheitsbestände P23, Reservierungen
P24/P25, Build-or-Buy P26 sowie die unabhängigen P34/P36/P37-Gates.

### Aktualisierte Features

INV-001, INV-002, TEC-001, TEC-003, TEC-004, TEC-007 und TEC-012 sowie
OFF-005/KI-005, KI-006 und KI-013.

### Nächster Prompt

P22 – Verfügbarkeit und Ausschlüsse vollständig spezifizieren und
anschließend ausführen. P22 wurde nicht begonnen.

## 2026-07-24 – P22: Verfügbarkeit und Ausschlüsse

### Ausgangszustand

P19 lieferte aggregierte Endmaterialbedarfe, P20/P21 lokale manuelle und
importierte Bestände in Schema v11. Projektbezogene Lager-/Materialfreigaben
und die nachvollziehbare physische Verfügbarkeitsberechnung fehlten.
Vorhandene uncommittete Änderungen wurden erhalten.

### Ziel

P22 vollständig spezifizieren und eine deterministische,
Preview-before-write-gestützte Verfügbarkeit und Ausschlusssteuerung
implementieren, ohne Sicherheitsbestände, Reservierungen oder Build-or-Buy
vorzuziehen.

### Durchgeführte Arbeiten

- vollständige Spezifikation mit 18 messbaren Abnahmekriterien erstellt,
- alle drei Lagerfreigabemodi sowie Materialausschlüsse und
  Mengenobergrenzen modelliert,
- überlaufgeprüfte, doppelfreie Ausschlussaufschlüsselung implementiert,
- aktuellen Projekt-/Graph-/Lager-/Bestandszustand als Preview-Token
  eingeführt,
- Vorschau, ausdrückliche Bestätigung und Stale-State-Schutz umgesetzt,
- projektbezogene Konfiguration atomar persistiert,
- additives Schema v12, Migration und Backupformat 12.0.0 ergänzt,
- native Verfügbarkeitsansicht im Graphworkflow mit Fortschritt, Abbruch,
  Fehler- und Bestätigungszustand ergänzt,
- Domain-, Application-, Persistence-/Migrations- und Architekturtests
  erstellt,
- Xcode-Projekt regeneriert und Pflichtdokumentation aktualisiert.

### Zentrale Entscheidungen

- P22 bezeichnet nur physischen Bestand nach Freigaben, nicht endgültig
  freien Bestand.
- Ergebnisse werden nicht persistiert; nur Benutzerregeln werden
  gespeichert.
- Jede Menge wird genau dem ersten zutreffenden Ausschlussgrund
  zugerechnet.
- Alte gespeicherte Regeln bleiben sichtbar, auch wenn ein Material im
  aktuellen Graph nicht mehr vorkommt.
- Ohne gespeicherten Datensatz gilt explizit „alle aktiven Lager“.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/InventoryAvailability.swift`
- `Sources/NewEdenNexusApplication/InventoryAvailability.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV12.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataInventoryAvailabilityRepository.swift`
- `Sources/NewEdenNexus/InventoryAvailabilityView.swift`
- `Sources/NewEdenNexus/InventoryAvailabilityViewModel.swift`
- `Tests/NewEdenNexusDomainTests/InventoryAvailabilityTests.swift`
- `Tests/NewEdenNexusApplicationTests/InventoryAvailabilityServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/InventoryAvailabilityPersistenceTests.swift`
- `Documentation/INVENTORY_AVAILABILITY.md`
- `Documentation/Architecture/ADRs/ADR-0027_Projektbezogene-Verfuegbarkeit-und-Schema-v12.md`
- `Documentation/Progress/Reports/2026-07-24_P22_Verfuegbarkeit-Ausschluesse.md`

### Geänderte Dateien

Composition Root, Runtime, Projekt-/Graphansichten, Migrationsplan,
Containerfactory, Backupdienst und -tests, Fehlertexte,
Architekturprüfung, generiertes Xcode-Projekt sowie alle verpflichtenden
Status-, Architektur-, Test- und Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Projektgenerator:
15 Targets, sieben Testtargets und zwei gemeinsame Schemes.

### Testergebnis

Je 371 Tests in SwiftPM und Xcode Debug/Release, 0 Fehler und 0
übersprungene Tests. Ein isolierter Schema-v12-App-Store meldete
`PRAGMA integrity_check = ok`.

### Erkannte Probleme

Ein erster Test-Compile enthielt einen unzulässigen Instanzaufruf als
Defaultparameter. Ein zunächst ungeeigneter Stale-Graph-Test änderte nur
einen fachlich irrelevanten Zeitstempel. Der Review erkannte außerdem eine
Cancellation-Prüfung nach bereits erfolgreichem Commit; der Apply-Pfad und
ein Regressionstest sichern nun die eindeutige Commit-Grenze. Alle Befunde
wurden vor den Abschlussläufen korrigiert und erneut geprüft.

### Nicht erledigte Punkte

Sicherheitsbestände P23, Projektreservierungen P24,
Reservierungskonflikte P25, Build-or-Buy P26 sowie die unabhängigen
P34/P36/P37-Gates.

### Aktualisierte Features

INV-003, INV-001, TEC-001, TEC-003, TEC-004, TEC-007 und TEC-012 sowie
OFF-005/KI-005, OFF-006/KI-006 und KI-013.

### Nächster Prompt

P23 – Sicherheitsbestände zunächst vollständig spezifizieren und
anschließend ausführen. P23 wurde nicht begonnen.

## 2026-07-25 – P23: Sicherheitsbestände

### Ausgangszustand

P22 stellte die projektbezogene physische Verfügbarkeit nach Lager-,
Material- und Mengenfreigaben bereit. Sicherheitsbestand, Mindest-, Warn-
und Zielwerte waren weder als Domainregel noch persistent oder in der UI
vorhanden. `OFF-005/KI-005` blieb dafür und für Reservierungen offen;
Schema und Backup endeten bei v12.

### Ziel

P23 vollständig spezifizieren und globale Type-ID-Regeln mit harter
Schutzmenge, unabhängigen Schwellenmeldungen, Preview-before-write,
atomarer Persistenz, Schema v13, UI und belastbaren Nachweisen umsetzen.

### Durchgeführte Arbeiten

- Projektbuchregeln und offene Register gegen den Quellcode abgegrenzt,
- vollständige P23-Spezifikation mit 20 messbaren Abnahmekriterien erstellt,
- deterministischen Sicherheitsbestandsrechner implementiert,
- Preview-/Apply-Service mit vollständigem P22-/Regel-Source-State ergänzt,
- globales `StockPolicyRecord` und atomaren SwiftData-Adapter ergänzt,
- Migration und Backupformat auf v13 erweitert,
- Sicherheitsbestands-Sheet in den Produktionsgraphworkflow integriert,
- 17 Domain-, Application- und Persistenztests ergänzt,
- Xcode-Projekt neu generiert und alle vier Gesamtprüfungen ausgeführt,
- Fach-, Architektur-, Datenmodell-, Status- und Testdokumentation
  aktualisiert.

### Zentrale Entscheidungen

- Regeln gelten global je Type-ID; lagerbezogene Allokation wird ohne
  belastbare Fachregel nicht erfunden.
- Nur Sicherheitsbestand reduziert die verwendbare Menge. Mindest-, Warn-
  und Zielwert werden unabhängig ausgewertet.
- P22-ausgeschlossener aktiver Bestand deckt den globalen Schutz zuerst;
  archivierter Bestand zählt nicht.
- Berechnungsergebnisse werden nicht gespeichert. Vorschau und bestätigter
  atomarer Regel-Commit bleiben getrennt.
- Reservierungen bleiben P24/P25.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/SafetyStock.swift`
- `Sources/NewEdenNexusApplication/SafetyStock.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV13.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataSafetyStockPolicyRepository.swift`
- `Sources/NewEdenNexus/SafetyStockView.swift`
- `Sources/NewEdenNexus/SafetyStockViewModel.swift`
- `Tests/NewEdenNexusDomainTests/SafetyStockTests.swift`
- `Tests/NewEdenNexusApplicationTests/SafetyStockServiceTests.swift`
- `Tests/NewEdenNexusPersistenceTests/SafetyStockPersistenceTests.swift`
- `Documentation/SAFETY_STOCK.md`
- `Documentation/Architecture/ADRs/ADR-0028_Globaler-Sicherheitsbestand-und-Schema-v13.md`
- `Documentation/Progress/Reports/2026-07-25_P23_Sicherheitsbestaende.md`

### Geänderte Dateien

Composition Root, Runtime, Projekt-/Graphansichten, P22-ViewModel-Grenze,
Migrationsplan, Containerfactory, Backupdienst und -tests,
Architekturprüfung, generiertes Xcode-Projekt sowie alle verpflichtenden
Status-, Architektur-, Test- und Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Xcode-Projektprüfung:
15 Targets, sieben Testtargets und zwei gemeinsame Schemes.

### Testergebnis

Fokussiert 17 P23-Tests bestanden. SwiftPM und Xcode bestanden Debug und
Release jeweils mit 388 Tests, 0 Fehlern und 0 übersprungenen Tests. Der
isolierte Schema-v13-App-Store meldete `PRAGMA integrity_check = ok`.

### Erkannte Probleme

Der Review erkannte, dass ein Repository-Rennen zunächst nur als
allgemeiner Persistenzfehler gemeldet worden wäre. Der typisierte
Stale-State-Vertrag und ein Regressionstest beheben dies. Außerdem wurde die
bereits in P22 relevante Cancellation-Grenze nach erfolgreichem Commit
korrigiert. Die SwiftPM-Sandbox konnte den Clang-Modulcache zunächst nicht
beschreiben; die vollständigen Nachweise wurden mit isolierten temporären
Pfaden erfolgreich wiederholt.

### Nicht erledigte Punkte

Projektreservierungen P24, Konkurrenzprüfung P25, Build-or-Buy P26 sowie die
unabhängigen P34/P36/P37-Gates. `OFF-005/KI-005` bleibt ausschließlich für
P24/P25 teilweise offen; `OFF-006/KI-006/KI-013` bleibt für den
Recovery-Lebenszyklus P36 offen.

### Aktualisierte Features

SAF-001, INV-001, INV-003, TEC-001, TEC-003, TEC-004, TEC-007 und TEC-012
sowie OFF-005/KI-005, OFF-006/KI-006 und KI-013.

### Nächster Prompt

P24 – Projektreservierungen zunächst vollständig spezifizieren und
anschließend ausführen. P24 wurde nicht begonnen.

## 2026-07-25 – P24: Projektreservierungen

### Ausgangszustand

P23 stellte die verfügbare Menge nach Lager-/Materialausschlüssen und
globalem Sicherheitsbestand bereit. Projektbindungen, ein
Reservierungslebenszyklus, Persistenz, UI und Archivschutz fehlten.
`OFF-005/KI-005` war für P24/P25 teilweise offen; Schema und Backups
endeten bei v13. Umfangreiche vorhandene Benutzer- und Vorgängeränderungen
blieben unangetastet. Es wurde kein Commit erstellt.

### Ziel

P24 vollständig spezifizieren und globale Projekt-/Type-ID-Reservierungen
mit deterministischer Berechnung, sicherer Vorschau/Bestätigung,
Lebenszyklus, Schema v14, UI, Tests, Dokumentation und gesondertem Review
umsetzen, ohne P25 vorwegzunehmen.

### Durchgeführte Arbeiten

- vollständige P24-Spezifikation mit 23 messbaren Kriterien erstellt,
- Domainmodell, Rechner und vier Reservierungszustände implementiert,
- Preview-/Apply-Service mit vollständigem Source-State ergänzt,
- atomaren SwiftData-Adapter und additive v13→v14-Migration ergänzt,
- Backupkompatibilität bis 14.0.0 erweitert,
- Archivierung bei aktiver Bindung geschützt,
- native Reservierungsansicht in den Graphworkflow integriert,
- stabile Reservierungsfehlercodes ergänzt,
- 20 fokussierte Tests sowie alle vier Gesamtprüfungen ausgeführt,
- isolierten App-Start und Datenbankintegrität geprüft,
- Pflichtdokumentation und unabhängigen Review abgeschlossen.

### Zentrale Entscheidungen

- Bindungen gelten global je Projekt und CCP-Type-ID; Charakter- oder
  Lagerallokationen werden nicht erfunden.
- Nur `reserved` und `partiallyConsumed` binden eine Restmenge.
- Verbrauch und Freigabe verändern keinen physischen Bestand.
- Ablaufdaten sind informativ und lösen keine automatische Freigabe aus.
- Neue Überbuchungen werden blockiert und niemals automatisch gekürzt.
- Nachträglich entstandene Konflikte bleiben P25.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProjectReservation.swift`
- `Sources/NewEdenNexusApplication/ProjectReservation.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV14.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProjectReservationRepository.swift`
- `Sources/NewEdenNexus/ProjectReservationView.swift`
- `Sources/NewEdenNexus/ProjectReservationViewModel.swift`
- drei P24-Testdateien in Domain, Application und Persistence
- `Documentation/PROJECT_RESERVATIONS.md`
- `Documentation/Architecture/ADRs/ADR-0029_Globale-Projektreservierungen-und-Schema-v14.md`
- `Documentation/Progress/Reports/2026-07-25_P24_Projektreservierungen.md`

### Geänderte Dateien

Composition Root, Runtime, Projekt-/Graphansichten,
Projektlebenszykluspersistenz, Fehlerbehandlung, Migrationsplan,
Containerfactory, Backupdienst und -tests, Architekturprüfung,
Xcode-Projekt sowie alle verpflichtenden Status-, Architektur-, Test- und
Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. Das Xcode-Projekt weist
15 Targets, sieben Testtargets und zwei gemeinsame Schemes auf. Signing und
Teamwerte blieben unverändert.

### Testergebnis

Fokussiert 20 P24-Tests bestanden. SwiftPM und Xcode bestanden Debug und
Release jeweils mit 408 Tests, 0 Fehlern und 0 übersprungenen Tests. Der
isolierte Schema-v14-App-Store meldete `PRAGMA integrity_check = ok`.

### Erkannte Probleme

Der Review erkannte vier zunächst fehlende Persistenzprüfungen: Roundtrip
aller Statuswerte, leerer v14-Initialstore, unbekanntes Projekt und
Projektduplikation ohne Reservierungsübernahme. Diese Tests wurden ergänzt
und bestanden anschließend alle fokussierten und vollständigen Läufe. Das
im geöffneten Xcode-Prozess koordinierte Projekt war für CLI-Lesen
vorübergehend blockiert; die Nachweise liefen deshalb über eine temporäre
Projektkopie mit unveränderten verlinkten Quellen.

### Nicht erledigte Punkte

Nachträglich entstandene Reservierungskonflikte und ihre kontrollierte
Auflösung bleiben `OFF-005/KI-005` in P25. Recovery-UI, automatische
Vor-Migrations-Sicherung und End-to-End-Drill bleiben
`OFF-006/KI-006/KI-013` in P36. P25 wurde nicht begonnen.

### Aktualisierte Features

RES-001, INV-001, INV-003, SAF-001, TEC-001, TEC-003, TEC-004, TEC-007
und TEC-012 sowie OFF-005/KI-005, OFF-006/KI-006 und KI-013.

### Nächster Prompt

P25 – Reservierungskonflikte zunächst vollständig spezifizieren und
anschließend ausführen. P25 wurde nicht begonnen.

## 2026-07-25 – P25: Reservierungskonflikte

### Ausgangszustand

P24 verhinderte neue Überbuchungen und speicherte globale
Projekt-/Type-ID-Reservierungen in Schema v14. Konflikte nach späteren
Bestands-, Schutzregel- oder Bedarfsänderungen wurden nicht erkannt.
`OFF-005/KI-005` war teilweise offen. Vorhandene Benutzeränderungen
blieben unangetastet; es wurde kein Commit erstellt.

### Ziel

P25 vollständig spezifizieren und nachträgliche Konflikte deterministisch
erkennen, erklären und ausschließlich nach Vorschau und Bestätigung
atomar auflösen.

### Durchgeführte Arbeiten

- P25 mit 27 messbaren Kriterien vollständig spezifiziert,
- drei Konfliktarten und stabile Prioritätsvorschläge implementiert,
- Preview-/Apply-Service mit vollständigem Source-State ergänzt,
- atomare Mehrprojekt-Reduktion/-Freigabe über die P24-Grenze umgesetzt,
- native Konfliktansicht in Projekt- und Graphworkflow integriert,
- zentrale Fehlercodes und 15 neue Tests ergänzt,
- vier vollständige Build-/Testwege und isolierten App-Start ausgeführt,
- Pflichtdokumentation, ADR und gesonderten Review abgeschlossen.

### Zentrale Entscheidungen

- Konflikte sind berechneter, nicht persistierter Zustand.
- Prioritäten beraten nur; es gibt keine automatische Kürzung.
- Auflösung darf nur reduzieren oder freigeben und muss danach
  konfliktfrei sein.
- Mangels belegter Regel wird keine Lagerallokation erfunden.
- Schema und Backupformat bleiben v14/14.0.0.

### Neu erstellte Dateien

- vier P25-Quelldateien in Domain, Application und App,
- zwei neue P25-Testdateien; Persistenztests wurden erweitert,
- `Documentation/RESERVATION_CONFLICTS.md`,
- `Documentation/Architecture/ADRs/ADR-0030_Berechnete-Reservierungskonflikte-und-kontrollierte-Aufloesung.md`,
- `Documentation/Progress/Reports/2026-07-25_P25_Reservierungskonflikte.md`.

### Geänderte Dateien

Repository-Port/-Adapter, Composition Root, Runtime, Projekt- und
Graphansichten, Fehlerbehandlung, Persistenz-/Architekturtests,
Xcode-Projekt sowie alle verpflichtenden Status-, Architektur-, Test- und
Fortschrittsdokumente.

### Build-Ergebnis

SwiftPM und Xcode Debug/Release erfolgreich. 15 Targets, sieben
Testtargets und zwei gemeinsame Schemes wurden verifiziert. Signing und
Teamwerte blieben unverändert.

### Testergebnis

Fokussiert 21 Tests bestanden. SwiftPM und Xcode bestanden Debug und
Release jeweils mit 423 Tests, 0 Fehlern und 0 übersprungenen Tests. Der
isolierte Schema-v14-App-Store meldete `PRAGMA integrity_check = ok`.

### Erkannte Probleme

Das direkt in Xcode geöffnete Projekt war für den CLI-Test über
`NSFileCoordinator` blockiert. Die Xcode-Nachweise liefen deshalb über
eine temporäre Projektkopie mit verlinkten unveränderten Quellen, ohne
Benutzerarbeit zu schließen. Eine erste Testfixture bildete versehentlich
einen echten verwaisten Konflikt; sie wurde fachlich korrigiert.

### Nicht erledigte Punkte

`OFF-006/KI-006/KI-013` bleibt P36 zugeordnet. P26 bis P37 bleiben offen;
P26 wurde nicht begonnen.

### Aktualisierte Features

RES-001, RES-002, INV-001, INV-003, SAF-001, TEC-001, TEC-007 und
TEC-012 sowie OFF-005/KI-005.

### Nächster Prompt

P26 – Build-or-Buy zunächst vollständig spezifizieren und anschließend
ausführen. P26 wurde nicht begonnen.

## 2026-07-25 – PLAN-002: Tokenarmer Produktionskern

### Ausgangszustand

P25 war erledigt. Die verbleibende Reihenfolge P26–P37 enthielt viele
separate Preis-, Export-, Härtungs- und Releasepakete; wiederholte
Vollspezifikationen und vierfach ausgeführte Gesamtsuiten verursachten
hohen Kontext- und Laufaufwand.

### Ziel

Den unmittelbaren Weg auf Produktion einschließlich T2/Invention und
Lagerabgleich begrenzen, ohne bestehende Funktionen oder offene Risiken zu
verbergen.

### Durchgeführte Arbeiten

- Ravworks-Workflow als öffentliche Funktionsreferenz geprüft,
- `LEAN_MVP_PLAN.md` erstellt,
- P26, P32 und P37 als kurze ausführbare Kernprompts formuliert,
- P27–P31 und P33–P36 sichtbar temporär verschoben,
- AGENTS- und Reviewregeln auf gezielte Lektüre, Dokumentationsdeltas und
  risikobasierte Tests umgestellt,
- Roadmap, Promptregister, Menü, Projektstatus, Feature-Matrix sowie
  offene Punkte konsistent aktualisiert.

### Zentrale Entscheidungen

Unmittelbare Reihenfolge ist P26 → P32 → P37. Der Kern enthält manuelles
Bauen/Kaufen, Produktions-/Inventionsjobs, Lagerabzug und Fehlmengen.
Preise, Gewinn, erweiterter Einkauf, Performance-, Recovery- und
Release-Härtung bleiben erhalten, aber vorläufig außerhalb der Reihenfolge.

### Neu erstellte Dateien

- `Documentation/LEAN_MVP_PLAN.md`
- `Documentation/Progress/Reports/2026-07-25_PLAN-002_Tokenarmer-Kern-MVP.md`

### Geänderte Dateien

AGENTS-/Reviewregeln, P26–P37-Promptdateien und betroffene zentrale
Planungs-/Statusdokumente.

### Build-Ergebnis

Nicht ausgeführt: reine Planungs- und Dokumentationsänderung ohne
Quellcode-, Projekt- oder Datenmodelländerung.

### Testergebnis

Kein App-Test erforderlich. Markdown-Diff, Statuskonsistenz und Links
werden kontrolliert.

### Erkannte Probleme

P36-Recovery und vollständige Release-Compliance bleiben echte offene
Blocker für eine öffentliche Freigabe.

### Nicht erledigte Punkte

P26, P32 und P37 sind offen. P27–P31 und P33–P36 sind temporär
verschoben, nicht erledigt.

### Aktualisierte Features

BOB-001, BUY-001, BUY-002, UI-001, PRC-001/002, FIN-001/002 sowie
Qualitäts-/Recovery-Zuordnungen.

### Nächster Prompt

P26 – schlanken Produktionsentscheidungsplan ausführen.

## 2026-07-25 – P26: Build-or-Buy

### Ausgangszustand

P17–P25 lieferten Graph, Invention, Reaktionen, Lager, Schutz und
Reservierungen getrennt. P26 war spezifiziert, aber nicht implementiert.

### Ziel

Einen reproduzierbaren Plan für Bestand, Bauen/Kaufen,
Produktions-/Inventionsjobs und Fehlmengen erstellen.

### Durchgeführte Arbeiten

- P26 vollständig und knapp spezifiziert,
- Domainrechner für Graphschnitt und stufenweises Lagernetting erstellt,
- vorhandene P22–P24-Regeln im Application-Service wiederverwendet,
- Inventionsmaterialmengen versionsgebunden aus SDE-Rezepten gelesen,
- bestätigungspflichtige projektbezogene Kaufentscheidungen implementiert,
- Schema und Backupformat additiv auf v15/15.0.0 erweitert,
- Xcode-Projekt regeneriert und Parität geprüft.

### Zentrale Entscheidungen

Standard ist **Bauen**; persistiert werden nur **Kaufen**-Abweichungen.
Projektduplikate starten ohne Entscheidungen. Invention plant erfolgreiche
BPCs, aber keine geschätzten Fehlversuche.

### Neu erstellte Dateien

P26-Domain-, Application-, Persistenz- und Testdateien,
`BUILD_OR_BUY_PLANNING.md`, ADR-0031 und der P26-Abschlussbericht.

### Geänderte Dateien

Schema-/Migrations-/Backupverdrahtung, Xcode-Projekt sowie zentrale
Status-, Architektur- und Testdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich; statische Projektparität grün.

### Testergebnis

11 fokussierte und je 434 vollständige SwiftPM-/Xcode-Debugtests bestanden.

### Erkannte Probleme

Die neuen Quellen fehlten im ersten Review im Xcode-Projekt. Die
XcodeGen-Regeneration schloss den Befund vor Abschluss.

### Nicht erledigte Punkte

Die sichtbare Bedienung und kopierbare Fehlmengenliste folgen P32.
Preise, Kosten und erweiterter Einkaufsworkflow bleiben verschoben.

### Aktualisierte Features

BOB-001, BUY-001, TEC-003, TEC-007 und TEC-012.

### Nächster Prompt

P32 – integrierten Kernworkspace ausführen.

## 2026-07-25 – P32: Integrierter Produktionsworkspace

### Ausgangszustand

P26 lieferte einen reproduzierbaren Build-or-Buy-Plan, aber noch keinen
zusammenhängenden sichtbaren Projektworkflow. Dashboard-Reste nutzten direkt
SwiftData; positive Fehlmengen waren nicht kopierbar.

### Ziel

Projekt, Graph, Lager, Schutz, Reservierungen, Konflikte, Bauen/Kaufen,
Produktions-/Inventionsjobs und Fehlmengen in einem kleinen lokalen
Arbeitsablauf verbinden.

### Durchgeführte Arbeiten

- P32 mit Voraussetzungen, Risiken und messbarer Abnahme vervollständigt,
- Workspace-ViewModel und SwiftUI-Workspace erstellt,
- P26-Service über die Composition Root produktiv verdrahtet,
- Vorschau-/Bestätigungsflow für Bauen/Kaufen integriert,
- Produktions-, Inventions-, Lager- und Fehlmengenanzeige ergänzt,
- positive Fehlmengen als `Name<Tab>Menge` kopierbar gemacht,
- Dashboard auf ViewModel-/Use-Case-Grenze umgestellt,
- sichere Fehlerzuordnung `NEN-PLAN-001` ergänzt,
- schmale/breite Render- sowie ViewModel-/Architekturtests ergänzt.

### Zentrale Entscheidungen

Der Workspace berechnet keine Mengen neu und persistiert keine Ergebnisse.
Er zeigt ausschließlich den P26-Snapshot. Eine geänderte, aber noch nicht
neu berechnete Vorschau darf weder gespeichert noch kopiert werden.

### Neu erstellte Dateien

- Workspace-View, Workspace- und Dashboard-ViewModel,
- P32-ViewModel- und Architekturtests,
- `Documentation/PRODUCTION_WORKSPACE.md`,
- ADR-0032,
- P32-Abschlussbericht.

### Geänderte Dateien

Projekt-/Graph-/Runtime-Composition, Dashboard, zentrale Fehlerzuordnung,
Xcode-Projekt sowie Status-, Architektur- und Testdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich; Xcode-/SwiftPM-Parität grün.

### Testergebnis

8 fokussierte sowie je 439 vollständige SwiftPM-/Xcode-Debugtests bestanden;
0 Fehler und 0 übersprungen.

### Erkannte Probleme

Der native Computer-Use-Kanal brach vor einer auswertbaren GUI-Antwort ab.
Deshalb wird kein manueller GUI-/VoiceOver-Nachweis behauptet; reproduzierbare
Render- und Quellarchitekturtests bestanden.

### Nicht erledigte Punkte

P37-End-to-End-Abnahme sowie die bewusst verschobenen P27–P31 und P33–P36.
Future-Views mit direktem SwiftData-Zugriff bleiben P38 zugeordnet.

### Aktualisierte Features

TEC-001/002/007/012, BOB-001, BUY-001 und UI-001.

### Nächster Prompt

P37 – interne Kernabnahme.

## 2026-07-25 – P37: Interne Kernabnahme

### Ausgangszustand

P26 stellte den persistenten Build-or-Buy-Plan bereit, P32 verband ihn mit
dem sichtbaren Produktionsworkspace. Ein zusammenhängender persistenter
Abnahmenachweis für T1, T2/Invention, Lagerabzug, Build-or-Buy und
Wiederöffnung fehlte noch.

### Ziel

Den reduzierten lokalen Produktionskern mit festen, reproduzierbaren
Referenzfällen intern abnehmen, ohne P37 als Release oder allgemeine
Produktionsfreigabe darzustellen.

### Durchgeführte Arbeiten

- P37 mit Voraussetzungen, Nicht-Zielen, Risiken, Sicherheitsgrenzen und
  messbaren Abnahmekriterien vollständig spezifiziert,
- persistenten Schema-v15-Abnahmetest für T1 und T2/Invention ergänzt,
- exakte Runs, Lagerverwendung, Fehlmengen, Produktions- und
  Inventionsaufträge geprüft,
- gespeicherte Build-or-Buy-Entscheidung und identische Wiederöffnung des
  isolierten Stores geprüft,
- Reservierungskonfliktanzeige und Vorschaugrenzen kontrolliert,
- isoliertes App-Bundle gestartet und neuen Store auf Integrität geprüft,
- Xcode-Projekt regeneriert und SwiftPM-/Xcode-Parität verifiziert,
- separaten Review durchgeführt und einen veralteten
  P37-Veröffentlichungshinweis korrigiert.

### Zentrale Entscheidungen

P37 ist eine interne Kernabnahme, kein Release Candidate. Die Testdaten sind
vollständig synthetisch und werden ausschließlich in temporären Stores
verwendet. Der Abnahmetest konsumiert die bestehenden produktiven
Berechnungs-, Persistenz- und Build-or-Buy-Grenzen, statt Berechnungen im Test
nachzubilden.

### Neu erstellte Dateien

- `Tests/NewEdenNexusPersistenceTests/P37CoreAcceptanceTests.swift`
- `Documentation/Progress/Reports/2026-07-25_P37_Interne-Kernabnahme.md`

### Geänderte Dateien

- `Sources/NewEdenNexus/SDELegalNoticesView.swift`
- `Tests/NewEdenNexusArchitectureTests/AppSourceArchitectureTests.swift`
- `NewEdenNexus.xcodeproj/project.pbxproj`
- P37-Prompt, Entwickler-Menü, Promptregister, Status-, Roadmap-, Feature-,
  Offen-, Problem-, Test- und Tagebuchdokumentation.

### Build-Ergebnis

`swift build -c debug` und der Xcode-Debug-Testbuild für macOS arm64 waren
erfolgreich. Die Projektprüfung bestätigte 15 Targets, sieben Testtargets und
zwei gemeinsame Schemes.

### Testergebnis

29 fokussierte P37-Tests sowie jeweils 440 vollständige SwiftPM- und
Xcode-Debugtests bestanden; 0 Fehler und 0 übersprungene Tests. Der
isolierte App-Start erzeugte einen integren Schema-v15-Store.

### Erkannte Probleme

Der Review fand einen veralteten Rechtshinweis, der eine erneute Prüfung
fälschlich an eine Veröffentlichung „in P37“ band. Der Text wurde auf eine
spätere öffentliche Veröffentlichung bezogen und mit einem Architekturtest
abgesichert.

### Nicht erledigte Punkte

P27–P31 bleiben als fachliche Erweiterungen verschoben. P33–P36 bleiben vor
einer öffentlichen Freigabe erforderlich; insbesondere ist der reale externe
Prozessabbruch mit Neustart weiterhin P36 zugeordnet. Ein manueller
GUI-/VoiceOver-Test wird für P37 nicht behauptet.

### Aktualisierte Features

TEC-001, TEC-007, TEC-012, BOB-001 und UI-001.

### Nächster Prompt

P27 – manuelle Preise und Preisprofile reaktivieren.

## 2026-07-25 – P27: Manuelle Preise und Preisprofile

### Ausgangszustand

Der P37-Kern konnte Produktion, Invention, Lager und Bauen/Kaufen abbilden.
Preise bestanden nur als flacher `Double`-Testwert; Profile, Persistenz,
Gültigkeit, Preis-UI und eine ausdrückliche Fehlwertbehandlung fehlten.

### Ziel

Exakte lokale ISK-Preise in wiederverwendbaren Profilen kataloggebunden
verwalten, ohne CSV-Import oder Kostenberechnung vorwegzunehmen.

### Durchgeführte Arbeiten

- P27 vollständig spezifiziert,
- exakte `Int64`-Hundertstel-ISK-Domainwerte und Gültigkeitsregeln ergänzt,
- Profil-/Preis-Service und Repository-Port umgesetzt,
- Schema v16, Migration und Backupformat 16.0.0 ergänzt,
- SwiftData-Repository mit Eindeutigkeit, Aktivierung, Kaskade und
  optimistischem Zustandsschutz umgesetzt,
- Preis-Navigationsmodul, ViewModel und SwiftUI-Ansicht ergänzt,
- fokussierte und vollständige SwiftPM-/Xcode-Prüfungen ausgeführt,
- separaten Diff-, Architektur-, Test- und Dokumentationsreview durchgeführt.

### Zentrale Entscheidungen

Persistente Preise verwenden keine binäre Gleitkommazahl. Fehlende,
zukünftige und abgelaufene Werte bleiben explizit fehlend. Profilwechsel
verändern keine Projekte, Graphen, Lager oder Build-or-Buy-Entscheidungen.

### Neu erstellte Dateien

- Domain-, Application-, Persistence-, ViewModel- und View-Dateien für P27,
- fünf fokussierte Testdateien,
- `Documentation/PRICE_PROFILES.md`,
- `Documentation/Architecture/ADRs/ADR-0033_Exakte-ISK-Preisprofile-und-Schema-v16.md`,
- `Documentation/Progress/Reports/2026-07-25_P27_Manuelle-Preise-und-Profile.md`.

### Geänderte Dateien

Navigation, Composition Root, Fehlerzuordnung, Migrationsplan,
Containerfactory, Backupdienst, Xcode-Projekt und verpflichtende
Status-/Architektur-/Testdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug für macOS arm64 erfolgreich. Die
Xcode-Projektprüfung bestätigte 15 Targets, sieben Testtargets und zwei
Schemes.

### Testergebnis

13 fokussierte P27-Tests sowie jeweils 453 vollständige SwiftPM- und
Xcode-Debugtests bestanden; 0 Fehler, 0 übersprungene Tests.

### Erkannte Probleme

Ein sandboxbedingter Compiler-Cachefehler und ein XCTest-Autoclosurefehler
waren keine Produktfehler. Der Review fand eine localeabhängige
Profilreihenfolge; sie wurde vor der Endabnahme durch die projektweite
Normalisierung ersetzt.

### Nicht erledigte Punkte

CSV-Preisimport bleibt P28, Kosten/Gewinn/ROI P29 und der erweiterte
Einkaufsworkflow P30/P31. Ein manueller GUI-/VoiceOver-Nachweis wird für P27
nicht behauptet.

### Aktualisierte Features

TEC-001, TEC-003, TEC-004 und PRC-001.

### Nächster Prompt

P28 – CSV-Preisimport.

## 2026-07-25 – P28: CSV-Preisimport

### Ausgangszustand

P27 verwaltete exakte manuelle Preise und Profile. Sicherer Massenimport,
zeilengenaue Konflikte, Importprotokolle und zugehörige UI fehlten.

### Ziel

CSV-Preislisten erst prüfen, detailliert anzeigen und nur nach
Einzelentscheidungen sowie ausdrücklicher Bestätigung atomar übernehmen.

### Durchgeführte Arbeiten

- P28 vollständig spezifiziert,
- gehärteten P21-CSV-Transport wiederverwendet,
- Preisformat, Mapping, Katalogprüfung und Detailvorschau umgesetzt,
- atomaren Preis-/Berichtscommit mit Stale-State-Prüfung ergänzt,
- Schema v17, Migration und Backupformat 17.0.0 umgesetzt,
- SwiftData-freie Import-ViewModel-/SwiftUI-Grenze integriert,
- Build, Tests und gesonderten Review ausgeführt.

### Zentrale Entscheidungen

Rohdatei und Pfad werden nicht persistiert. Fehlende Datei-Type-IDs löschen
keine Preise. Importierte Werte tragen Quelle `csv` und bleiben exakte
Hundertstel ISK.

### Neu erstellte Dateien

P28-Application-, Schema-, ViewModel-, View-, Test-, Fach-, ADR- und
Abschlussberichtsdateien.

### Geänderte Dateien

Preis-Domain, Repositoryvertrag/-adapter, Composition, Fehlerzuordnung,
Migration, Backup, Xcode-Projekt und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug für macOS arm64 erfolgreich. Projektparität:
15 Targets, sieben Testtargets und zwei Schemes.

### Testergebnis

22 fokussierte sowie jeweils 461 vollständige SwiftPM-/Xcode-Debugtests
bestanden; 0 Fehler, 0 übersprungen.

### Erkannte Probleme

Nach Sandbox- und inkonsistentem Objektcachefehler bestand der bereinigte
Build. Der Review ergänzte Berichtslöschkaskade und Batch-Konsistenzprüfung.

### Nicht erledigte Punkte

P29–P31 bleiben offen. Die große P28-Application-Datei ist als KI-029 P34
zugeordnet. Kein manueller GUI-/VoiceOver-Nachweis wird behauptet.

### Aktualisierte Features

TEC-003, TEC-004 und PRC-002.

### Nächster Prompt

P29 – Kosten, Gewinn und ROI.

## 2026-07-26 – P29: Kosten, Gewinn und ROI

### Ausgangszustand

P26/P32 lieferten einen reproduzierbaren Build-or-Buy-Plan; P27/P28
lieferten exakte lokale Preisprofile. Kostenkennzahlen, manuelle Jobkosten
und eine projektbezogene Berechnungsbasis fehlten. Schema v17 war aktuell.

### Ziel

Cash- und wirtschaftliche Kosten, Erlös, Gewinn, Marge, ROI und Break-even
deterministisch berechnen, fehlende Preise sichtbar blockieren und die
Berechnungsbasis nach Vorschau und Bestätigung speichern.

### Durchgeführte Arbeiten

- P29 mit Formeln, Rundung, Grenzen und Abnahmekriterien spezifiziert,
- reine Ganzzahl-Domainberechnung ergänzt,
- Application-Service für Preisauflösung, Vorschau, Stale-Prüfung und
  Bestätigung umgesetzt,
- Schema v18 und SwiftData-Repository ergänzt,
- Preisprofil und manuelle Jobkosten in den Produktionsworkspace integriert,
- Migration, Backupformat 18.0.0 und Referenztests ergänzt,
- Xcode-Projekt regeneriert und vollständige Regression ausgeführt.

### Zentrale Entscheidungen

Cash-Kosten bewerten nur Fehlmengen; wirtschaftliche Kosten bewerten die
gesamte eingesetzte Menge einschließlich Lager. Gespeichert werden nur
Preisprofil und Jobkosten, keine veraltbaren Ergebnisse. Fehlende Preise
gelten nicht als 0 ISK. Gebühren, Steuern, SCI und Inventionsfehlversuche
werden ohne belegte Eingabe nicht erfunden.

### Neu erstellte Dateien

- `Sources/NewEdenNexusDomain/ProjectEconomics.swift`
- `Sources/NewEdenNexusApplication/ProjectEconomics.swift`
- `Sources/NewEdenNexusPersistence/NexusSchemaV18.swift`
- `Sources/NewEdenNexusPersistence/SwiftDataProjectEconomicsRepository.swift`
- vier P29-Testdateien,
- `Documentation/PROJECT_ECONOMICS.md`,
- `Documentation/Architecture/ADRs/ADR-0035_Reproduzierbare-Projektwirtschaftlichkeit-und-Schema-v18.md`,
- P29-Abschlussbericht.

### Geänderte Dateien

Produktionsworkspace/-ViewModel/-Composition, Migration, Containerfactory,
Backupdienst/-tests, Xcode-Projekt und Pflichtdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich. Projektparität: 15 Targets,
sieben Testtargets und zwei gemeinsame Schemes.

### Testergebnis

22 fokussierte Prüfungen bestanden. SwiftPM und Xcode Debug bestanden auf
dem finalen Stand jeweils 473 Tests, 0 Fehler, 0 übersprungen.

### Erkannte Probleme

Der erste fokussierte Lauf fand eine veraltete Zukunftsversionsfixture des
Backup-Tests. Der erste Xcode-Gesamtlauf fand eine vom Arbeitsverzeichnis
abhängige neue Architekturprüfung. Beide Testprobleme wurden korrigiert;
Produktivcode war nicht Ursache. Der Review verhinderte zusätzlich eine
mehrdeutige Post-Commit-Abbruchmeldung.

### Nicht erledigte Punkte

P30/P31 bleiben für persistente Einkaufsbearbeitung, Status und Export offen.
Gebühren, reale Finanzen und Live-Märkte bleiben außerhalb von P29. Ein
manueller GUI-/VoiceOver-Test wurde nicht durchgeführt.

### Aktualisierte Features

FIN-001, FIN-002, TEC-001, TEC-003, TEC-004, TEC-007 und OFF-011.

### Nächster Prompt

P30 – Erweiterte Einkaufslisten-Aggregation.

## 2026-07-26 – P30: Erweiterte Einkaufslisten-Aggregation

### Ausgangszustand

P26/P32 lieferten eine berechnete kopierbare Fehlmengenliste. P29 hatte
Schema v18 und 473 Tests je Debug-Buildweg erreicht. Persistente
Zielkaufmengen, Stale-Override-Bereinigung und bestätigtes Speichern fehlten.

### Ziel

Eine deterministische projektbezogene Einkaufsliste mit editierbaren
Mengen, Wiederöffnung und vollständigem Vorschau-vor-Schreiben-Schutz.

### Durchgeführte Arbeiten

Type-ID-Aggregator, Application-Service, SwiftData-Repository, Schema v19,
Workspace-Bedienung, Migration, Backupformat und automatisierte Tests
umgesetzt. P31-Funktionen wurden nicht vorgezogen.

### Zentrale Entscheidungen

Nur Abweichungen von der neu berechneten Fehlmenge werden persistiert.
Der bestätigte P26-Plan wird vor dem atomaren Ersatz erneut geprüft.
Menge null ist eine ausdrückliche Abweichung; veraltete Overrides bleiben
bis zur bestätigten Bereinigung sichtbar.

### Neu erstellte Dateien

Shopping-Domain/Application/Persistenz, Schema v19, vier Testdateien,
`SHOPPING_LIST.md`, ADR-0036 und P30-Abschlussbericht.

### Geänderte Dateien

Workspace, Composition, Migration, Container, Backup, Xcode-Projekt und
verpflichtende Projekt-/Status-/Testdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich. Xcode-Parität mit 15 Targets,
sieben Testtargets und zwei Schemes bestätigt.

### Testergebnis

14 fokussierte Tests sowie 486/486 SwiftPM- und 486/486 Xcode-Debugtests
bestanden; keine Tests übersprungen. Isolierter App-Start:
`integrity_check = ok`, Schema-v19-Tabelle vorhanden.

### Erkannte Probleme

Ein P32-Architekturtest erwartete noch die frühere Beschriftung
„Fehlmengen kopieren“. Der Vertrag wurde auf die neue
„Einkaufsliste kopieren“-Bedienung aktualisiert. Der Review entfernte eine
mehrdeutige Post-Commit-Prüfung.

### Nicht erledigte Punkte

Kaufstatus, Teilkäufe, CSV und projektübergreifender Workflow bleiben P31.
Manueller GUI-/VoiceOver-Test sowie P33–P36 bleiben offen.

### Aktualisierte Features

BUY-001, BUY-002, UI-001, TEC-001, TEC-003, TEC-004, TEC-007,
TEC-012 und OFF-011.

### Nächster Prompt

P31 – Einkaufsworkflow und Export.

## 2026-07-26 – P31: Einkaufsworkflow und Export

### Ausgangszustand

P30 stellte projektbezogene Zielkaufmengen und Klartext bereit. Kaufstatus,
Teilkauf, projektübergreifende Zusammenführung und CSV fehlten; OFF-011 war
deshalb teilweise offen. Schema v19 und 486 Tests je Debug-Buildweg waren
der bestätigte Ausgangsstand.

### Ziel

Ein sicherer zentraler Beschaffungsworkflow für aktuelle Projekte mit
persistenter Projektzuordnung, Restmengen und read-only Export.

### Durchgeführte Arbeiten

Type-ID-Aggregator, Application-Service, SwiftData-Repository, zentrale
Einkaufsansicht, Teilkauf-/Gekauft-Aktionen, Text-/CSV-Export, Schema v20,
Migration, Backupformat und automatisierte Tests wurden umgesetzt.

### Zentrale Entscheidungen

Kauf-Fortschritt ist keine Bestandserhöhung. Er bleibt je Projekt/Type-ID
zugeordnet. Archivierte, nicht berechenbare oder veraltete Zuordnungen
werden nicht stillschweigend gelöscht. CSV bleibt ein Export; ein Reimport
benötigt später einen eigenen Schreibvertrag.

### Neu erstellte Dateien

P31-Domain/Application/Persistenz, Schema v20, Einkaufs-ViewModel/-View,
fünf Testdateien, ADR-0037 und P31-Abschlussbericht.

### Geänderte Dateien

Composition, Runtime, Navigation, zentrale Fehlerbehandlung, Migration,
Container, Backup, Xcode-Projekt sowie verpflichtende Projekt-, Status-,
Architektur- und Testdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich. Xcode-Parität mit 15 Targets,
sieben Testtargets und zwei Schemes bestätigt.

### Testergebnis

15 fokussierte Tests sowie 501/501 SwiftPM- und 501/501 Xcode-Debugtests
bestanden; keine Tests übersprungen. Isolierter App-Start:
`integrity_check = ok`, Schema-v20-Tabelle vorhanden.

### Erkannte Probleme

Der erste Gesamtlauf fand ausschließlich die nach drei neuen zentralen
Fehleroperationen unvollständige Erwartungsmatrix. Sie wurde um
Load/Save/Export ergänzt. Xcode meldete Warnungen zu einem gesperrten
verbundenen Mobilgerät; das explizite macOS-Ziel und das Ergebnis waren
nicht betroffen.

### Nicht erledigte Punkte

Manueller interaktiver GUI-/VoiceOver-Test sowie P33–P36 bleiben vor einer
öffentlichen Freigabe offen. CSV-Reimport ist bewusst nicht Teil von P31.

### Aktualisierte Features

BUY-001, BUY-002, UI-001, TEC-001, TEC-003, TEC-004, TEC-007,
TEC-012 und OFF-011.

### Nächster Prompt

P33 – Appweite Validierung und Fehler-UX bei ausdrücklicher Reaktivierung.

## 2026-07-26 – P33: Appweite Validierung und Fehler-UX

### Ausgangszustand

P04 bot sichere Fehlercodes, Redaction und zentrale Alerts. Kernformulare
erklärten ungültige Eingaben nicht einheitlich; Alerts hatten keinen
kontrollierten Retry für reine Lesevorgänge.

### Ziel

Rohwertfreie Kernvalidierung, einheitliche Inline-UX und sichere,
benutzerinitiierte Lese-Retries ohne Wiederholung von Schreibvorgängen.

### Durchgeführte Arbeiten

`NexusValidationIssue`, Codes `NEN-VAL-001` bis `006`, gemeinsame
Validierungs-/Fehleransichten, Retry-Positivliste, einmalige Runtime-Ausführung
und Kern-Lade-Retries wurden umgesetzt. Projekt-, Lager-, Bestands-, Preis-
und Einkaufsformulare zeigen konkrete Validierungsgründe.

### Zentrale Entscheidungen

UI-Validierung ist seiteneffektfrei und ersetzt keine Serviceprüfung.
Nur idempotente Lese-/Inspect-/Previewoperationen dürfen einen Retry
registrieren; Schreibvorgänge bleiben ausgeschlossen.

### Neu erstellte Dateien

ADR-0038 und P33-Abschlussbericht.

### Geänderte Dateien

Zentrale Fehler-/Runtime-Grenze, betroffene Kernviews und -tests sowie die
kompakten Status-, Architektur- und Testdeltas.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich; 15 Targets, sieben Testtargets und
zwei Schemes konsistent.

### Testergebnis

16 fokussierte Tests sowie 507/507 SwiftPM- und 507/507 Xcode-Debugtests
bestanden; keine Tests übersprungen.

### Erkannte Probleme

Ein neuer asynchroner Testhelper verletzte zunächst Swift-6-Actor-Isolation
und wurde actor-sicher vereinfacht. Keine produktive Regression.

### Nicht erledigte Punkte

P34 Performance, P35 vollständige Accessibility/Lokalisierung, P36 Recovery
und Release-/Complianceprüfung.

### Aktualisierte Features

TEC-001, TEC-005, TEC-007, KI-007 und OFF-007.

### Nächster Prompt

P34 – Performance und große Graphen bei ausdrücklicher Reaktivierung.

## 2026-07-26 – P34: Performance und große Graphen

### Ausgangszustand

P34 war temporär verschoben. Die Katalogsuche besaß eine ältere Messung,
große Graphen wurden vollständig als rekursiver SwiftUI-Baum materialisiert
und vier P34-zugeordnete Dateien waren stark gewachsen.

### Ziel

Messbare Katalog- und Großgraphenbudgets, begrenzte UI-Materialisierung und
verhaltensneutrale Teilung der P34-Wartbarkeitspunkte.

### Durchgeführte Arbeiten

- 50.000-Item-Suche erneut gemessen und mit einem 2-Sekunden-Budget versehen,
- iterative 25.000-Knoten-Projektion mit 1.000er-Sichtfenster umgesetzt,
- große Listen lazy dargestellt und Knotennamenindex wiederverwendet,
- SDE-, Projekteditor- und Preis-CSV-Dateien nach Verantwortung geteilt,
- Xcode-Projekt regeneriert und Parität geprüft.

### Zentrale Entscheidungen

Kein zusätzlicher SwiftData-Index ohne Messbedarf. Graphdaten bleiben
vollständig; nur die UI-Darstellung wird gestaffelt. Schema v20 und
Graphformat 7 bleiben unverändert.

### Neu erstellte Dateien

`ProductionGraphDisplayProjection.swift`, `ProjectEditorSheet.swift`,
`SDEInstallationContracts.swift`, `CCPSDEArchiveDownload.swift`,
`PriceCSVImportModels.swift`, zwei P34-Testdateien,
`PERFORMANCE_AND_LARGE_GRAPHS.md` und ADR-0039.

### Geänderte Dateien

Produktionsgraph-UI, vier mechanisch geteilte Ursprungsdateien,
Architekturtests, Xcode-Projekt und betroffene Steuerdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich.

### Testergebnis

22 fokussierte Tests sowie SwiftPM und Xcode Debug mit jeweils 512 Tests,
0 Fehlern und 0 übersprungenen Tests. Katalog: 0,288/0,295 Sekunden;
Graphprojektion: 0,026/0,026 Sekunden.

### Erkannte Probleme

Keine durch P34 verursachte Regression. Die Zeitwerte sind rechnerbezogene
Debugmessungen und keine allgemeine Produktgarantie.

### Nicht erledigte Punkte

P35 Accessibility/Lokalisierung, P36 Recovery-Drill sowie persönliche
Release-/Complianceprüfung bleiben offen.

### Aktualisierte Features

TEC-001, TEC-007, TEC-012, TEC-013, CAL-008, UI-001; OFF-017, OFF-022 und
OFF-027 sowie KI-017, KI-022, KI-027 und KI-029 geschlossen.

### Nächster Prompt

P35 – Accessibility- und UX-Politur nach ausdrücklicher Reaktivierung.

## 2026-07-26 – P35: Accessibility- und UX-Politur

### Ausgangszustand

P35 war ein kurzer verschobener Entwurf. Die globale Suche filterte keinen
Inhalt, das Hauptfenster erzwang 1.100 Punkte Breite und mehrere Kernbereiche
waren starr horizontal angeordnet.

### Ziel

Den deutschsprachigen Kern-MVP suchbar, fokusgeführt, kontrastadaptiv und
bei schmalen sowie breiten Fenstern bedienbar machen.

### Durchgeführte Arbeiten

- Sidebar-Suche mit deutschen/EVE-Suchbegriffen und Empty State ergänzt,
- Hauptfenster und Kernlayouts adaptiv gemacht,
- semantische macOS-Systemfarben und vollständige Statuslabels eingesetzt,
- Fokusfolge im Projekteditor ergänzt,
- sechs P35-Tests, Accessibility-Dokument und ADR-0040 erstellt.

### Zentrale Entscheidungen

Kein neuer SDE-Übersetzungsdatensatz ohne bestätigte Zielsprache. Keine
Schema-, Fach- oder Benutzerdatenänderung. Der alte Prompt ordnete OFF-020
und OFF-021 falsch zu; maßgeblich bleibt OFFEN.md.

### Neu erstellte Dateien

Zwei P35-Testdateien, `ACCESSIBILITY_AND_UX.md`, ADR-0040 und
P35-Abschlussbericht.

### Geänderte Dateien

App-Navigation, Root-/Dashboard-/Workspace-/Einkaufs-/SDE-/Projekteditor-UI,
Theme, Xcode-Projekt und betroffene Steuerdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich.

### Testergebnis

10 fokussierte sowie 518/518 SwiftPM- und 518/518 Xcode-Debugtests
bestanden; keine Tests übersprungen.

### Erkannte Probleme

Der aktuelle App-Build startete isoliert, aber der Computer-Use-Kanal
schloss vor Ausgabe des Accessibility-Baums seine native Pipe.

### Nicht erledigte Punkte

OFF-030 manueller Tastatur-/VoiceOver-Nachweis; P36 sowie Release-/
Complianceprüfung.

### Aktualisierte Features

TEC-001, TEC-002, TEC-005, TEC-007, TEC-012 und neu TEC-014.

### Nächster Prompt

OFF-030 schließen und P35 final abnehmen; P36 nicht automatisch beginnen.

## 2026-07-26 – OFF-030/P35: Native Accessibility-Abnahme

### Ausgangszustand

P35 war technisch umgesetzt, wegen des ausgefallenen interaktiven
Computer-Use-Kanals aber nur mit Einschränkungen abgenommen.

### Ziel

Standard- und Mindestfenster, Accessibility-Semantik und Tab-Fokus des echten
App-Bundles reproduzierbar prüfen und OFF-030 schließen.

### Durchgeführte Arbeiten

Xcode-UI-Testtarget ergänzt; reales App-Bundle mit isoliertem Store bei
1.280 × 800 und 780 × 560 geprüft; Accessibility-Audit, Kernstatus, Suche
und Tab-Fokusfolge verifiziert. Reale Mindestfensterhöhe und
Dashboard-Metriksemantik korrigiert.

### Zentrale Entscheidungen

Der unzuverlässige interaktive Einmaltest wird durch ein dauerhaftes natives
XCUITest-Gate ersetzt. Nur deaktivierte SwiftUI-/Touch-Bar-
Strukturcontainer sind eng vom Beschreibungs-Audit ausgenommen.

### Neu erstellte Dateien

`Tests/NewEdenNexusUITests/P35AccessibilityUITests.swift` und
`Progress/Reports/2026-07-26_OFF-030_P35-Accessibility-Abnahme.md`.

### Geänderte Dateien

Xcode-Projektspezifikation/-metadaten, P35-App-/Architekturquellen und die
betroffenen Steuer-, Test- und Accessibility-Dokumente.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich; Xcode-Parität mit 16 Targets,
acht Testtargets und zwei Schemes bestätigt.

### Testergebnis

SwiftPM 518/518; Xcode 520/520 einschließlich zwei nativer UI-Tests; keine
übersprungenen Tests.

### Erkannte Probleme

Der interaktive Computer-Use-Kanal blieb unbrauchbar. Das XCUITest-Gate
liefert stattdessen einen reproduzierbaren nativen Nachweis.

### Nicht erledigte Punkte

P36/OFF-024 und die zeitabhängige Release-/Complianceprüfung. P36 wurde
nicht begonnen.

### Aktualisierte Features

TEC-001, TEC-002, TEC-005, TEC-007, TEC-012, TEC-014 und UI-001;
OFF-030/KI-030 geschlossen.

### Nächster Prompt

P36 – Migration und Recovery-Drill, nur nach ausdrücklichem Auftrag.

## 2026-07-26 – OFF-006: Migration-/Recovery-Lebenszyklus

### Ausgangszustand

Backup/Restore war technisch vorhanden; Vor-Migrations-Auslösung,
storefreigebende Runtime-Composition und Recovery-UI fehlten.

### Ziel

OFF-006 schließen, ohne den externen SDE-Prozessabbruch OFF-024 vorzuziehen.

### Durchgeführte Arbeiten

Schema-Inspector und Vor-Migrations-Koordinator ergänzt; App-Start und
Restore auf kontrollierte Storefreigabe/Wiederöffnung umgestellt;
Sicherungsansicht mit read-only Vorschau und Doppelbestätigung ergänzt;
isolierten v19→v20→Restore→Wiederöffnungsdrill implementiert.

### Zentrale Entscheidungen

Unbekannte/future Stores werden vor SwiftData abgelehnt. Backupfehler
blockieren Migration. Downgrade ist nicht unterstützt. OFF-024 bleibt
eigenständig.

### Neu erstellte Dateien

`NexusStoreMigrationBackup.swift`, `LocalRecoveryView.swift`, drei
Recovery-Testdateien, ADR-0041 und der OFF-006-Abschlussbericht.

### Geänderte Dateien

App-Runtime/Composition, Backupservice, Settings, Xcode-Projekt sowie
betroffene Steuer- und Fachdokumentation.

### Build-Ergebnis

SwiftPM Debug und Xcode-App-Debugbuild erfolgreich.

### Testergebnis

8/8 fokussiert, 526/526 SwiftPM und 526/526 Xcode ohne UI. Der UI-Worker
begann in dieser Sitzung keinen Test; OFF-031 erfasst den erneuten Lauf.

### Erkannte Probleme

Keine durch OFF-006 verursachte Produktregression. Xcode-UI-
Worker-Materialisierung in dieser Sitzung blockiert.

### Nicht erledigte Punkte

OFF-024 externer SDE-Prozess-Kill/Neustart; OFF-031 UI-Worker-Retest;
Release-/Complianceprüfung.

### Aktualisierte Features

TEC-003, TEC-004, TEC-008; OFF-006/KI-006/KI-013 geschlossen.

### Nächster Prompt

P36-Restumfang OFF-024, nur nach ausdrücklichem Auftrag.

## 2026-07-26 – P36: Migration und Recovery-Drill

### Ausgangszustand

OFF-006 war erledigt; OFF-024 verlangte noch einen echten externen
Prozessabbruch mit anschließendem Neustart derselben isolierten Composition.

### Ziel

Fünf persistente SDE-Grenzen über reale Prozesse abnehmen, ohne produktive
Daten oder einen Release-Crashschalter zu berühren.

### Durchgeführte Arbeiten

Acceptance-Checkpoint nach Journalpersistenz ergänzt, das bestehende
SDE-Acceptance-Executable um einen Mehrprozess-Koordinator erweitert und
Download, Archivvorbereitung, Staging, Validierung/Backup sowie Promotion
jeweils mit exaktem PID-`SIGKILL` und frischem Recoveryprozess geprüft.

### Zentrale Entscheidungen

Nur versionierte synthetische Fixtures und eigens validierte temporäre
P36-Wurzeln sind zulässig. Produktive Compositions injizieren keinen
Checkpoint. Der Koordinator verwendet weder `killall` noch `pkill`.

### Neu erstellte Dateien

`P36RecoveryAcceptance.swift`, ADR-0042 und der P36-Abschlussbericht.

### Geänderte Dateien

SDE-Installationsvertrag/-service, Acceptance-Runner, Xcode-Projekt,
fokussierte Tests sowie betroffene Steuer-, SDE-, Test- und
Architekturdokumentation.

### Build-Ergebnis

SwiftPM Debug sowie Xcode Debug für App und Acceptance-Executable erfolgreich.

### Testergebnis

Fünf reale SIGKILL-/Neustarts bestanden; SwiftPM 527/527 und
Xcode-kompilierter P36-Testbund 6/6. Die Xcode-Scheme-Orchestrierung konnte
in der Codex-Sandbox `testmanagerd` nicht erreichen.

### Erkannte Probleme

OFF-031 bleibt als Testinfrastruktur-/UI-Worker-Retest vor Release.

### Nicht erledigte Punkte

Zeitabhängige öffentliche Release-/Complianceprüfung und OFF-031; keine
P36-Restarbeit.

### Aktualisierte Features

TEC-001, TEC-003, TEC-007, TEC-008 und DAT-008; OFF-024/KI-024 geschlossen.

### Nächster Prompt

Öffentliche Release-/Complianceprüfung einschließlich OFF-031; P38 nur nach
ausdrücklichem Auftrag.

## 2026-07-26 – REL-001: Öffentliche Release-/Complianceprüfung

### Ausgangszustand

P36/P37 waren abgenommen. OFF-031 und die zeitabhängige öffentliche
Releaseprüfung waren offen; P38 war verschoben.

### Ziel

Aktuelle CCP-/Apple-/Build-/UI-Bereitschaft prüfen, OFF-031 ausführen und
verbleibende Freigabegates ohne Veröffentlichung dokumentieren.

### Durchgeführte Arbeiten

- aktuelle offizielle CCP-/EVE- und Apple-Quellen read-only geprüft,
- SDE-Build `3444265` und Cacheheader erneut bestätigt,
- Drittanbieter-/Eigentumshinweis und fehlende CCP-Bilddateien geprüft,
- SwiftPM/Xcode Release und vollständige Releasetests ausgeführt,
- nativen Xcode-UI-Testworker erfolgreich ausgeführt und OFF-031 geschlossen,
- Bundle-ID, Versionsfelder, Signatur und Gatekeeperstatus geprüft,
- OFF-020 präzisiert und OFF-032 für öffentliche macOS-Distribution erfasst.

### Zentrale Entscheidungen

Die technische Prüfung ist abgeschlossen, aber keine öffentliche Freigabe.
Signing-, Team-, Bundle-ID- und Notarisierungseinstellungen wurden nicht
ohne Eigentümerentscheidung verändert. P38 bleibt unberührt.

### Neu erstellte Dateien

- `Documentation/Prompts/MVP/REL-001_Oeffentliche-Release-Compliance.md`
- `Documentation/Progress/Reports/2026-07-26_REL-001_Oeffentliche-Release-Compliance.md`

### Geänderte Dateien

Nur die betroffenen Steuer-, Compliance-, Test- und Statusdokumente.

### Build-Ergebnis

SwiftPM Release und Xcode Universal Release erfolgreich.

### Testergebnis

SwiftPM Release 527/527; nativer Xcode-UI-Testworker 2/2, jeweils 0 Fehler.

### Erkannte Probleme

KI-032: lokale Bundle-ID, fehlende Versionen, kein Developer ID, kein
Hardened Runtime und keine Notarisierung.

### Nicht erledigte Punkte

OFF-020 persönlicher Eigentümer-Sign-off; OFF-032 öffentliche
macOS-Distribution. Keine fachliche Implementierung und kein P38.

### Aktualisierte Features

`TEC-001`, `TEC-007`, `TEC-008`, `TEC-012`, `DAT-009`, `CMP-001`.

### Nächster Prompt

OFF-032 nach Eigentümerentscheidung zu Bundle-ID, Version, Apple-Team und
Verteilungsweg. P38 nur auf ausdrücklichen Auftrag.

## 2026-07-26 – PLAN-003: Lokaler Betrieb und optionale Distribution

### Ausgangszustand

REL-001 hatte die technische öffentliche Releasebereitschaft geprüft.
OFF-020 und OFF-032 waren als Veröffentlichungsgates erfasst, obwohl der
Projekteigentümer die App auf absehbare Zeit nur lokal nutzen möchte.

### Ziel

Lokale Eigennutzung als verbindliches Betriebsziel festlegen und eine
öffentliche Apple-Distribution als letztes optionales Zukunftspaket
einordnen.

### Durchgeführte Arbeiten

- Projektbeschreibung, Roadmap, Entwickler-Menü, Promptregister,
  Feature-Matrix, Status-, Aufgaben- und Complianceunterlagen abgeglichen,
- P48 nach P47 als letztes optionales Paket ergänzt,
- OFF-020 und OFF-032 auf P48 verschoben,
- lokalen `Release`-Build von einer öffentlichen Veröffentlichung
  abgegrenzt,
- `AGENTS.md` und `README.md` auf den lokalen Zielbetrieb ausgerichtet.

### Zentrale Entscheidungen

App Store, öffentliche Direktverteilung, Developer-ID, Signing und
Notarisierung sind keine MVP- oder lokale DoD-Voraussetzung. Die
CCP-Daten-, Sicherheits- und Drittanbieterregeln gelten lokal weiterhin.
Historische REL-001-Nachweise bleiben unverändert gültig.

### Neu erstellte Dateien

- `Documentation/Prompts/MVP/PLAN-003_Lokaler-Betrieb-und-optionale-Distribution.md`
- `Documentation/Prompts/Future/P48_Optionale-Apple-Distribution.md`
- `Documentation/Progress/Reports/2026-07-26_PLAN-003_Lokaler-Betrieb-und-optionale-Distribution.md`

### Geänderte Dateien

Nur Projekt- und Promptsteuerung, Dokumentationsübersichten, offene Punkte,
Complianceeinordnung, `AGENTS.md` und `README.md`.

### Build-Ergebnis

Nicht erneut ausgeführt: kein App-Code und kein Xcode-Projekt geändert.
Der zuletzt verifizierte Xcode-/SwiftPM-Stand bleibt dokumentiert.

### Testergebnis

Keine App-Tests erneut ausgeführt. Dokumentpfade, Projektparität und
Diff-Format wurden für PLAN-003 geprüft.

### Erkannte Probleme

Keine neue lokale Betriebsblockade. Ein später öffentlich verteilbares
Artefakt benötigt weiterhin OFF-020 und OFF-032.

### Nicht erledigte Punkte

P48 bleibt bewusst optional und wurde nicht begonnen. P38 wurde nicht
verändert oder begonnen.

### Aktualisierte Features

`TEC-001`, `TEC-007`, `TEC-012`, `DST-001`, `DST-002`, `DAT-009`,
`CMP-001`, `UI-001`.

### Nächster Prompt

Kein Prompt automatisch. P38 bis P47 nur auf ausdrücklichen Auftrag; P48
bleibt zuletzt optional.

## 2026-07-26 – PLAN-004: Folgeplanung für den lokalen Ausbau

### Ausgangszustand

Der lokale Produktionsplaner war abgenommen. P38 bis P47 lagen als
ungeordnete beziehungsweise nur grob abhängige Zukunftsentwürfe vor; P48
war bereits zuletzt optional eingeordnet.

### Ziel

Eine verbindliche, nutzenorientierte Folge festlegen und den unmittelbar
nächsten Prompt ausführbar vorbereiten, ohne Implementierung zu beginnen.

### Durchgeführte Arbeiten

- P38 bis P48 als verbindliche Folge geordnet,
- Stop-/Nutzenreviews nach P40, P42 und P44 festgelegt,
- P38 vollständig mit Architektur-, Sicherheits-, Daten- und
  Abnahmekriterien spezifiziert,
- OFF-008, OFF-010 und OFF-013 P38 zugeordnet,
- Roadmap, Entwickler-Menü, Promptregister, Status, offene Punkte,
  bekannte Probleme und Feature-Matrix aktualisiert.

### Zentrale Entscheidungen

P38 bis P40 liefern zuerst persönlichen Nutzen im lokalen Planer. Markt und
Ist-Finanzen folgen in P41/P42, erweiterte Industrie in P43/P44.
Corporation, Cloud und Optimierung bleiben P45–P47 bedarfsabhängig. P48
bleibt das letzte optionale Distributionspaket.

### Neu erstellte Dateien

- `Documentation/Prompts/MVP/PLAN-004_Folgeplanung-lokaler-Ausbau.md`
- `Documentation/Progress/Reports/2026-07-26_PLAN-004_Folgeplanung-lokaler-Ausbau.md`

### Geänderte Dateien

P38–P47-Promptsteuerung sowie die betroffenen Projekt-, Status-, Aufgaben-
und Qualitätsdokumente.

### Build-Ergebnis

Nicht erneut ausgeführt: App-Code und Xcode-Projekt wurden nicht geändert.

### Testergebnis

Keine App-Tests erneut ausgeführt. Dokumentformat, Promptreihenfolge,
Pfade und Xcode-Projektparität wurden geprüft.

### Erkannte Probleme

P38 muss unvalidierte Claimverarbeitung, direkte View-Zugriffe sowie
Keychain-/SwiftData-Teilfehlerrisiken schließen.

### Nicht erledigte Punkte

P38 bis P48 wurden nicht ausgeführt. P39 bis P47 bleiben Entwürfe; P48
bleibt zuletzt optional.

### Aktualisierte Features

`SSO-001`, `ESI-001` sowie die Zukunftsreihenfolge P39–P48.

### Nächster Prompt

P38 – SSO-Härtung ausführen. Noch nicht begonnen.

## 2026-07-26 – P38: SSO-Härtung

### Ausgangszustand

SSO-, Browser-, Callback-, Keychain-, SwiftData- und UI-Verantwortung waren
eng gekoppelt; Claims wurden nicht vollständig kryptografisch abgenommen.

### Ziel

Einen sicheren, injizierbaren lokalen SSO-Adapter ohne ESI-Fachdaten
implementieren und OFF-008, den SSO-Anteil von OFF-010 sowie OFF-013
bearbeiten.

### Durchgeführte Arbeiten

- Auth-/Account-Ports und kompensierenden Application-Service ergänzt,
- OIDC-Discovery, PKCE/State, Loopback, Tokenrefresh sowie
  RS256/JWKS-/Claim-/Scopeprüfung implementiert,
- Refresh-Token-Vault und SwiftData-Account-Repository ergänzt,
- Account-/Synchronisations-UI über ein injiziertes ViewModel angebunden,
- alte monolithische SSO-Service-Datei entfernt,
- automatisierte Fach-, Persistenz-, Infrastruktur- und Architekturtests
  ergänzt.

### Zentrale Entscheidungen

Kein Client Secret im Desktop-Client; keine Access-Token-Persistenz; keine
ESI-Fachdaten in P38. Keychain-/SwiftData-Teilfehler werden explizit
kompensiert. Details stehen in ADR-0043.

### Neu erstellte Dateien

Application-Verträge, SSO-Infrastructure-Adapter, Account-Repository,
Composition/ViewModel, vier P38-Testdateien, SSO-Architekturdokument,
ADR-0043 und P38-Abschlussbericht.

### Geänderte Dateien

Account-/Synchronisationsviews, App-Runtime/RootView, Architekturtestgrenze,
Xcode-Projekt sowie betroffene Steuer- und Qualitätsdokumente.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug erfolgreich.

### Testergebnis

540/540 SwiftPM-Tests erfolgreich. Der fokussierte Xcode-Lauf und seine
Umgebungsbefunde sind in `TEST_HISTORY.md` festgehalten.

### Erkannte Probleme

Kein bestätigter technischer P38-Produktfehler. Der erste signierte
Xcode-Testversuch traf auf Finder-Metadaten im generierten Testbundle; ein
zweiter Sandboxlauf konnte SwiftData-Makros nicht starten.

### Nicht erledigte Punkte

Der reale Eigentümer-SSO-End-to-End-Lauf mit Verbinden, Neustart, Refresh und
bestätigtem Trennen wurde nicht ausgeführt. Deshalb bleibt P38 `⚠️`.

### Aktualisierte Features

SSO-001, OFF-008, OFF-010, OFF-013, KI-010, KI-011 und KI-014.

### Nächster Prompt

P38 manuell abnehmen; P39 erst danach und nur auf ausdrücklichen Auftrag.

## 2026-07-26 – P38: SSO-Laufzeitkorrektur

### Ausgangszustand

Ein realer Verbindungsversuch endete mit `NEN-AUTH-001`, Trennen mit
`NEN-PER-004`; Xcode-Starts konnten zwei Hauptfenster wiederherstellen.

### Ziel

Die Ursachen reproduzieren, korrekt klassifizieren und die lokale
Build-/Fenstergrenze absichern, ohne Tokens oder Benutzerdaten zu verändern.

### Durchgeführte Arbeiten

- Security-/App-Logs auf einen verweigerten Keychain-Zugriff eingegrenzt,
- lokale, git-ignorierte Apple-Development-Konfiguration ergänzt,
- Vault-Fehler als `NEN-AUTH-003` beziehungsweise `NEN-AUTH-002`
  differenziert,
- wiederhergestellte Fensterduplikate und mehrfaches `⌘N` begrenzt,
- Application- und native UI-Regressionstests ergänzt.

### Zentrale Entscheidungen

Keine unsichere Lockerung des Keychain-Zugriffs und keine automatische
Löschung des Alt-Tokens. Persönliche Signierwerte bleiben außerhalb von Git.

### Neu erstellte Dateien

- `Scripts/configure_local_signing.sh`
- `XcodeSupport/AppSigning.xcconfig`
- `Documentation/Progress/Reports/2026-07-26_P38_SSO-Lokalbetrieb-Korrektur.md`

### Geänderte Dateien

App-/Application-Fehlerführung, Hauptfensterlebenszyklus,
Xcode-Konfiguration, Tests sowie betroffene P38-Steuerdokumente.

### Build-Ergebnis

SwiftPM und ad-hoc-Xcode-Debugbuild erfolgreich. Der stabile
Apple-Development-Build ist am gesperrten Login-Keychain blockiert.

### Testergebnis

542/542 SwiftPM-Tests und 1/1 nativer Einzel-Fenster-UI-Test bestanden.

### Erkannte Probleme

OFF-033/KI-033: alter ad-hoc-Keychain-Eintrag und gesperrter Login-Keychain.

### Nicht erledigte Punkte

Stabil signierter Build, kontrollierte Alt-Token-Bereinigung sowie realer
Verbinden-/Neustart-/Refresh-/Trennen-Lauf.

### Aktualisierte Features

`TEC-001`, `SSO-001`, `OFF-010`, `OFF-033`, `KI-033`, `KI-034`.

### Nächster Prompt

P38/OFF-033 nach Entsperren des Anmeldeschlüsselbunds abschließen; P39 erst
danach.

## 2026-07-26 – P38: Buildlog-Nachprüfung

### Ausgangszustand

Der Xcode-Log enthielt wiederholte AppIntents-XPC-Meldungen, alte
SSO-Diagnosecodes und einen Hinweis auf ein unbekanntes SF Symbol.

### Ziel

Build- und Laufzeitmeldungen trennen, den echten UI-Befund korrigieren und
den aktuellen Quellstand isoliert bauen.

### Durchgeführte Arbeiten

`cart.badge.checkmark` durch `checkmark.circle.fill` ersetzt,
Regressionstest ergänzt und ein frisches temporäres Xcode-Projekt gebaut.

### Zentrale Entscheidungen

Systemdiagnostik nicht durch riskante App-/Entitlement-Änderungen
„unterdrücken“. Der Keychain-Befund bleibt getrennt OFF-033.

### Neu erstellte Dateien

- `Documentation/Progress/Reports/2026-07-26_P38_Buildlog-Nachpruefung.md`

### Geänderte Dateien

Einkaufsansicht, zugehöriger Architekturtest und kompakte Statusdokumente.

### Build-Ergebnis

Isolierter Xcode-Debugbuild arm64: `BUILD SUCCEEDED`.

### Testergebnis

Fokussierter Einkaufsworkflow-Architekturtest bestanden.

### Erkannte Probleme

Keine neue Buildblockade. KI-035 ist behoben; OFF-033 bleibt offen.

### Nicht erledigte Punkte

Stabil signierter Real-SSO-Lauf.

### Aktualisierte Features

`TEC-001`, `TEC-007`, `KI-035`.

### Nächster Prompt

P38/OFF-033 nach Entsperren des Login-Keychains abschließen.

## 2026-07-26 – P38: Keychain-Dialogkorrektur
### Ausgangszustand
Reales Verbinden und Trennen erzeugte wiederholte Schlüsselbunddialoge;
`NEN-AUTH-001` enthielt keinen unterscheidbaren OAuth-Fehlergrund.
### Ziel
Unnötige Vault-Lesezugriffe entfernen, Datenkompensation erhalten und die
Fehlerursache ohne Secrets diagnostizierbar machen.
### Durchgeführte Arbeiten
Verbinden und Trennen auf Repository-zuerst mit kompensierendem Rollback
umgestellt; vorbereitende Token-Reads entfernt; stabile `error_reason`-
Diagnosen und Regressionstests ergänzt. Das lokale Signing-Skript liest die
Team-ID nun aus dem Zertifikat-OU. Ergänzte Xcode-Zeilen wurden in
SDE-/macOS-Begleitdiagnostik und relevante Authfehler getrennt.
### Zentrale Entscheidungen
Keine Tokenbereinigung, kein Keychain-Lockern und keine Datenmigration.
Fehlergründe enthalten ausschließlich feste Kategorien.
### Neu erstellte Dateien
- `Documentation/Progress/Reports/2026-07-26_P38_Keychain-Dialogkorrektur.md`
### Geänderte Dateien
Application-SSO/Errorhandling, zwei Application-Testdateien, lokales
Signing-Skript und betroffene P38-Steuerdokumentation.
### Build-Ergebnis
SwiftPM Debug sowie isolierter unsignierter und
Apple-Development-signierter Xcode-Debugbuild erfolgreich; die App bestand
`codesign --verify --deep --strict`.
### Testergebnis
13/13 fokussiert und 544/544 vollständig bestanden.
### Erkannte Probleme
Der OAuth-Grund des bisherigen Laufs ist historisch nicht rekonstruierbar;
der neue Build protokolliert ihn als `error_reason`.
### Nicht erledigte Punkte
Manueller Eigentümerlauf Verbinden/Neustart/Refresh/Trennen.
### Aktualisierte Features
`SSO-001`, `TEC-001`, `TEC-007`, `OFF-033`, `KI-033`.
### Nächster Prompt
P38/OFF-033 mit aktuellem signierten Build manuell abschließen; P39 erst
danach.

## 2026-07-26 – P38: CCP-Misch-JWKS-Korrektur

### Ausgangszustand

Der erneute reale Login lieferte
`error_reason=signing_key_unavailable`.

### Ziel

Den aktuellen offiziellen CCP-Schlüsselsatz korrekt dekodieren, ohne die
RSA-/RS256-Signaturprüfung zu lockern.

### Durchgeführte Arbeiten

Offizielle SSO-Metadaten und JWKS geprüft, den Fehler mit einem gemischten
RSA-/EC-Schlüsselsatz reproduziert, algorithmusspezifische JWK-Felder
optional modelliert und einen Regressionstest ergänzt.

### Zentrale Entscheidungen

Unpassende Schlüssel dürfen den Schlüsselsatz nicht unlesbar machen.
Access-Tokens bleiben auf den zum Header passenden RSA-/RS256-Schlüssel
begrenzt; ES256 wird nicht stillschweigend freigeschaltet.

### Neu erstellte Dateien

- `Documentation/Progress/Reports/2026-07-26_P38_JWKS-Mischschluessel-Korrektur.md`

### Geänderte Dateien

SSO-Infrastructure-Validator, zugehöriger Infrastructure-Test sowie
betroffene P38-Steuer- und Architekturdokumentation.

### Build-Ergebnis

SwiftPM Debug und lokal signierter Xcode-Debugbuild erfolgreich; strikte
Signaturprüfung bestanden.

### Testergebnis

7/7 fokussierte SSO-/JWKS-Tests und 545/545 vollständige SwiftPM-Tests
bestanden.

### Erkannte Probleme

Kein verbleibender automatisiert reproduzierter Misch-JWKS-Fehler.

### Nicht erledigte Punkte

Realer Eigentümerlauf mit Verbinden, Neustart, Refresh und Trennen.

### Aktualisierte Features

`SSO-001`, `TEC-001`, `TEC-007`, `OFF-033`, `KI-036`.

### Nächster Prompt

P38/OFF-033 mit dem korrigierten signierten Build manuell abschließen; P39
erst danach.

## 2026-07-26 – P38: Abschlussabnahme

### Ausgangszustand

Technik, Build und Tests waren bestanden; OFF-033 hielt den bestätigten
Eigentümerlauf und verwaisten ad-hoc-Keychain-Bestand offen.

### Ziel

Den realen Lauf nachweisen, Alt-Tokens ausschließlich nach Einzelvorschau
und ausdrücklicher Freigabe entfernen und P38 abschließend reviewen.

### Durchgeführte Arbeiten

Der Projekteigentümer bestätigte den funktionsfähigen Lauf. Die lokale
Charaktertabelle enthielt nach dem Trennen keinen Datensatz. Zwei verwaiste
Einträge des Dienstes `de.newedennexus.tokens` wurden einzeln identifiziert,
freigegeben und gelöscht; die Kontrollabfrage fand keinen Restbestand.

### Zentrale Entscheidungen

Keine automatische Sammellöschung: jeder neu gefundene Eintrag erforderte
eine eigene Vorschau und Bestätigung. Tokeninhalte wurden nicht ausgelesen.

### Neu erstellte Dateien

- `Documentation/Progress/Reports/2026-07-26_P38_Abschlussabnahme.md`

### Geänderte Dateien

P38-Steuer-, Status-, Feature-, SSO-, Aufgaben-, Befund- und Testdokumente.

### Build-Ergebnis

Unverändert erfolgreich: SwiftPM Debug und lokal signierter Xcode-Debugbuild;
strikte Signaturprüfung bestanden.

### Testergebnis

Unverändert 7/7 fokussierte SSO-/JWKS-Tests und 545/545 SwiftPM-Tests;
Eigentümer-End-to-End-Lauf bestätigt, Schlüsselbund-Restbestand 0.

### Erkannte Probleme

Keine verbleibende P38-Blockade.

### Nicht erledigte Punkte

ESI-Fachdaten bleiben planmäßig P39/P40.

### Aktualisierte Features

`SSO-001`, `TEC-001`, `TEC-007`, `OFF-033`, `KI-033`.

### Nächster Prompt

P39 nur auf ausdrücklichen Auftrag.

## 2026-07-26 – P39: ESI-Infrastruktur und Charaktere

### Ausgangszustand

P38 stellte SSO und lokale Charakterkonten bereit. Eine cachefähige,
limitbewusste ESI-Abfrage öffentlicher Charakterprofile fehlte.

### Ziel

Öffentliche Charakterinformationen ohne private Scopes sicher abrufen,
offline weiterverwenden und in der Accountansicht verständlich darstellen.

### Durchgeführte Arbeiten

Application-Ports und Synchronisationsservice, offizieller HTTP-Client,
atomarer Dateicache, Composition, ViewModel und UI wurden ergänzt. Frischer
Cache, 200/304, Validatoren, 420/429, begrenzter 5xx-Retry, Abbruch,
Offline-Fallback, Cachekorruption und Trennkompensation sind geprüft.

### Zentrale Entscheidungen

Die öffentliche Route erhält keinen Bearer-Token. Profildaten werden
getrennt von SwiftData und Tokens gespeichert. P40 bleibt für private
Assets, Blueprints und Jobs verantwortlich.

### Neu erstellte Dateien

ESI-Applicationvertrag, HTTP-Client, Dateicache, drei fokussierte
Testsuiten, ESI-Architekturdokument, ADR-0044 und P39-Abschlussbericht.

### Geänderte Dateien

SSO-/Account-Service, App-Composition und -UI, zentrale Fehlerzuordnung,
User-Agent-Konfiguration, Xcode-Projekt sowie betroffene Steuer- und
Testdokumente.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug für macOS arm64 erfolgreich.

### Testergebnis

565/565 SwiftPM-Tests bestanden. Ein realer offizieller ESI-Abruf lieferte
HTTP 200 und der konditionale Folgeabruf HTTP 304.

### Erkannte Probleme

Keine kritische P39-Regression. Private ESI-Daten fehlen planmäßig.

### Nicht erledigte Punkte

P40 wurde nicht begonnen. Es gab keinen Commit oder Push.

### Aktualisierte Features

`ESI-001`, `OFF-010`, `KI-010`, `NEN-ESI-001`.

### Nächster Prompt

P40 nur nach Nutzenreview und auf ausdrücklichen Auftrag.

## 2026-07-26 – P40: Persönliche Assets, Blueprints und Industry Jobs

### Ausgangszustand

P39 stellte öffentliche Charakterprofile bereit. Persönliche Assets,
Blueprints und Jobs sowie ein kontrolliertes Vorschau-/Übernahmeverfahren
fehlten.

### Ziel

Exakt drei private ESI-Lesedatenquellen sicher, offlinefähig und ohne
stillschweigende Änderungen an manuellen Beständen integrieren.

### Durchgeführte Arbeiten

Application-Modelle und -Ports, flüchtiger Access-Token-Service,
sequenzieller ESI-Client, versionierter Dateistore, Differenzvorschau,
bestätigtes Apply, UI-Anzeige und Trennkompensation wurden umgesetzt.
Pagination, Cache, Limits und relevante Fehlerpfade sind getestet.

### Zentrale Entscheidungen

Persönliche ESI-Daten bleiben ein eigener Read-Snapshot. Prüfen schreibt
nichts; Übernehmen verlangt eine unveränderte Basisrevision. P40 fordert
nur Assets-, Blueprint- und persönliche Industry-Job-Lesescopes an.

### Neu erstellte Dateien

P40-Applicationvertrag, HTTP-Client, Dateistore, Vorschauansicht, drei
Testsuiten, ADR-0045 und Abschlussbericht.

### Geänderte Dateien

Account-Composition, ViewModel und View, SSO-Trennservice,
Fehlerbehandlung, Xcode-Projekt sowie betroffene ESI- und Steuerdokumente.

### Build-Ergebnis

SwiftPM Debug und Xcode Debug für macOS arm64 erfolgreich. Der
eingeschränkte Xcode-Erstlauf scheiterte nur am blockierten
SwiftData-Makroserver; derselbe Stand baute außerhalb erfolgreich.

### Testergebnis

37 eindeutige fokussierte P40-Tests und 583/583 vollständige SwiftPM-Tests
bestanden. Drei RSA-Tests benötigten die normale Security.framework-
Umgebung außerhalb der Dateisandbox.

### Erkannte Probleme

Kein kritischer P40-Codefehler. Der erste private Live-Abruf erfordert eine
erneute persönliche SSO-Scope-Zustimmung und wurde nicht automatisiert.

### Nicht erledigte Punkte

Keine automatische Vermischung mit manuellen Lagern; P41 wurde nicht
begonnen. Kein Commit oder Push.

### Aktualisierte Features

`ESI-001`, `OFF-010`, `KI-010`, `NEN-ESI-002`, `NEN-ESI-003`.

### Nächster Prompt

P41 nur nach Nutzenreview und ausdrücklichem Auftrag.

## 2026-07-26 – P41: Nutzenreview Live-Marktpreise

### Ausgangszustand

Manuelle und CSV-Preisprofile sowie Kosten-, Gewinn- und ROI-Berechnung sind
vorhanden. Live-Marktpreise waren nur als verschobener Entwurf erfasst.

### Ziel

Nutzen, kleinstmöglichen tragfähigen Umfang und Stopkriterien für P41 prüfen,
ohne P41 zu implementieren.

### Durchgeführte Arbeiten

Vorhandenes Preis-/Wirtschaftlichkeitsmodell, OFF-021 und die aktuellen
offiziellen ESI-Markt-, Cache- und Ratelimitgrenzen wurden abgeglichen.

### Zentrale Entscheidungen

Bedingtes Go nur für öffentliche, projektbezogene und mengenbezogene
Material-Beschaffungspreise nach Vorschau und Bestätigung. Kein neuer
SSO-Scope, kein vollständiger Orderbuchspiegel und keine Markt-Historie.

### Neu erstellte Dateien

Kurzer Nutzenreview-Bericht.

### Geänderte Dateien

P41-Entwurf und betroffene Steuerdokumente.

### Build-Ergebnis

Nicht ausgeführt; keine Codeänderung.

### Testergebnis

Nicht ausgeführt; keine Implementierung.

### Erkannte Probleme

Das bestehende gemeinsame Preisprofil trennt Materialbeschaffung und
Zielerlös nicht. Automatische Erlöspreise bleiben deshalb außerhalb des
ersten Umfangs.

### Nicht erledigte Punkte

P41 wurde nicht begonnen. OFF-021 bleibt als SDE-Bedarfsgate offen.

### Aktualisierte Features

`MKT-001` nur planerisch präzisiert.

### Nächster Prompt

P41 nur auf ausdrücklichen Ausführungsauftrag.

## 2026-07-27 – P41: Live-Marktpreise

### Ausgangszustand

Manuelle/CSV-Preisprofile und Projektwirtschaftlichkeit waren vorhanden;
öffentliche Marktpreise waren nur positiv bewertet, aber nicht implementiert.

### Ziel

Mengenbezogene Material-Beschaffungspreise für die aktuelle Einkaufsliste
kontrolliert aus öffentlichen ESI-Sell-Orders übernehmen.

### Durchgeführte Arbeiten

Marktclient, begrenzter Dateicache, Preisservice, Vorschau/Bestätigung,
Schema-v21-Provenienz, Produktionsworkspace- und Preisprofil-UI sowie
Fehlercodes implementiert. Xcode-Projekt regeneriert.

### Zentrale Entscheidungen

Keine neuen Scopes, keine fest codierten Handelszentren, kein vollständiger
Orderbuchspiegel und keine automatischen Zielerlöse. Preis und Herkunft
werden erst nach Bestätigung atomar gespeichert.

### Neu erstellte Dateien

P41-Service-, Client-, Cache-, Schema-, UI-, Test-, Fach- und ADR-Dateien
sowie Abschlussbericht.

### Geänderte Dateien

Preisdomäne/-repository, Migration/Backup/Schemaerkennung, Workspace-
Composition, zentrale Fehlergrenze, Xcode-Projekt und Steuerdokumentation.

### Build-Ergebnis

SwiftPM Debug erfolgreich; Xcode-Projektverifier erfolgreich. Zwei native
Xcode-Debugbuilds hingen vor der Buildphase und wurden abgebrochen.

### Testergebnis

593/593 SwiftPM-Tests bestanden; P41-Fach-, Migration-, Backup- und
Fehlerregressionen grün.

### Erkannte Probleme

Der Store-Inspector kannte Schema v21 zunächst nicht; korrigiert und erneut
getestet. OFF-034/KI-037 dokumentieren den offenen Xcode-Buildnachweis.

### Nicht erledigte Punkte

Erfolgreicher nativer Xcode-Debugbuild; kein persönlicher Live-Marktabruf.

### Aktualisierte Features

`MKT-001`, `OFF-021`, `OFF-034`, `KI-006`, `KI-037`.

### Nächster Prompt

P41-Xcode-Abnahme; danach P42-Nutzenreview nur auf ausdrücklichen Auftrag.

## 2026-07-27 – OFF-034: P41-Xcode-Abnahme

### Ausgangszustand

P41-Fachcode, SwiftPM-Build und 593 Tests waren grün; native Xcode-Aufrufe
blockierten vor der Buildphase.

### Ziel

Xcode vollständig beenden, den Stillstand eingrenzen und den
macOS-arm64-Debugbuild nachweislich abschließen.

### Durchgeführte Arbeiten

Xcode per regulärem Beenden geschlossen und der Prozessstatus kontrolliert.
Ein Prozesssample lokalisierte den Stillstand in `NSFileCoordinator` beim
Lesen des File-Provider-markierten Projekts. Der hashgleiche Projektstand
wurde isoliert verifiziert und unsigned gebaut.

### Zentrale Entscheidungen

Keine Repository-Metadaten oder Benutzeränderungen verändern. Die Abnahme
verwendet deshalb eine inhaltlich identische temporäre Kopie ohne
File-Provider-Attribut.

### Neu erstellte Dateien

Abschlussbericht `2026-07-27_OFF-034_P41-Xcode-Abnahme.md`.

### Geänderte Dateien

Nur P41-/OFF-034-Status-, Test- und Reviewdokumentation.

### Build-Ergebnis

Projektverifier 16 Targets/acht Testtargets/zwei Schemes; `xcodebuild -list`
erfolgreich; unsigned Xcode Debug für macOS arm64: `BUILD SUCCEEDED`.

### Testergebnis

Unverändert 593/593 SwiftPM-Tests bestanden; kein erneuter Volltestlauf, da
kein Quellcode geändert wurde.

### Erkannte Probleme

File-Provider-Metadaten am Repositorypfad können lokale Xcode-CLI-Aufrufe in
`NSFileCoordinator` blockieren. Keine offene P41-Fachwirkung.

### Nicht erledigte Punkte

Kein persönlicher Live-Marktabruf. P42 wurde nicht begonnen.

### Aktualisierte Features

`MKT-001`, `OFF-034`, `KI-037`.

### Nächster Prompt

P42-Nutzenreview nur auf ausdrücklichen Auftrag.

## 2026-07-27 – P42: Nutzenreview Wallet und reale Projektfinanzen

### Ausgangszustand

P41 war abgeschlossen. P29 berechnete erwartete Wirtschaftlichkeit, P40
lieferte persönliche Jobs und P41 aktuelle Beschaffungspreise. P42 war ein
kurzer verschobener Entwurf.

### Ziel

Nutzen, kleinsten tragfähigen Umfang, Risiken und messbare Abnahme für P42
prüfen, ohne P42 zu implementieren.

### Durchgeführte Arbeiten

Vorhandene Finanz-, SSO-, ESI- und Snapshotgrenzen sowie die aktuelle
offizielle ESI-OpenAPI-, Cache-, Pagination- und Rate-Limit-Dokumentation
geprüft. P42 als begrenzten, bestätigungsgebundenen Read-Workflow
spezifiziert und Steuerdokumentation aktualisiert.

### Zentrale Entscheidungen

Bedingtes Go. Tatsächliche Käufe, Verkäufe und eindeutig belegte Gebühren
sind nützlich; automatische Projektzuordnung, Corporation-Wallets und
vollständige Buchhaltung bleiben ausgeschlossen.

### Neu erstellte Dateien

Abschlussbericht `2026-07-27_P42_Nutzenreview.md`.

### Geänderte Dateien

P42-Spezifikation und betroffene Status-/Planungsdokumente.

### Build-Ergebnis

Nicht ausgeführt; reine Planung ohne Quellcodeänderung.

### Testergebnis

Keine Laufzeittests; Dokumentkonsistenz und Diff wurden geprüft.

### Erkannte Probleme

Walletdaten lassen sich wegen fungibler Materialien und uneinheitlicher
Journal-Kontexte nicht zuverlässig automatisch Projekten zuordnen.

### Nicht erledigte Punkte

P42-Implementierung, Scope-Zustimmung, Migration, Build und Tests.

### Aktualisierte Features

`WAL-001`, `OFF-021`.

### Nächster Prompt

P42 nur auf ausdrücklichen Ausführungsauftrag.

## 2026-07-27 – P42: Wallet und reale Projektfinanzen

### Ausgangszustand

P42 war positiv geprüft und begrenzt spezifiziert, aber nicht implementiert.

### Ziel

Persönliche Wallet-Lesedaten lokal speichern und Istwerte ausschließlich
nach bestätigter Projektzuordnung ausweisen.

### Durchgeführte Arbeiten

Wallet-Domäne, ESI-Client, privater Snapshotstore, Synchronisations- und
Zuordnungsservices, Schema v22, Persistenz, UI, Fehlergrenze und Tests
umgesetzt. Xcode-Projekt und Dokumentation aktualisiert.

### Zentrale Entscheidungen

Genau ein zusätzlicher Read-Scope; Walletrohbestand außerhalb von SwiftData;
nur bestätigte Zuordnungen persistent; Plan und Ist bleiben getrennt.

### Neu erstellte Dateien

Wallet-Quellen und -Tests, `WALLET_AND_PROJECT_FINANCE.md`, ADR-0047 und
P42-Abschlussbericht.

### Geänderte Dateien

Account-Composition/-UI, Auth-Lebenszyklus, Fehlerbehandlung,
Migration/Backup, Xcode-Projekt und betroffene Steuerdokumente.

### Build-Ergebnis

SwiftPM Debug und isolierter Xcode Debug erfolgreich; Projektverifier grün.

### Testergebnis

15/15 fokussierte Wallettests und 608/608 Gesamttests bestanden.

### Erkannte Probleme

Direkter Xcode-CLI-Aufruf am synchronisierten Repositorypfad kann im
bekannten `NSFileCoordinator`-Pfad hängen; isolierter Build erfolgreich.

### Nicht erledigte Punkte

Kein produktiver persönlicher Walletabruf; Corporation-Wallet,
automatische Zuordnung und Buchhaltung sind nicht Teil von P42.

### Aktualisierte Features

`WAL-001`, Schema v22, Backupformat 22, `OFF-021`.

### Nächster Prompt

P43-Nutzenreview nur auf ausdrücklichen Auftrag.

## 2026-07-27 – P43: Nutzenreview Reaktionsmanagement

### Ausgangszustand

P42 war abgeschlossen. P43 bestand nur als verschobener Kurz­entwurf;
Reaktionsberechnung und Reaktionsstufen waren bereits seit P18/P19
implementiert.

### Ziel

Prüfen, ob vollständige Standort-, Fuel-, Slot-, Kalender- und
Auslastungsverwaltung für den lokalen Betrieb genügend Zusatznutzen bietet.

### Durchgeführte Arbeiten

Reaktionsregeln, Produktionsgraph, Build-or-Buy, Lager/Reservierungen,
persönliche Industry Jobs, Kostenintegration, P44-Abgrenzung und
`OFF-021` geprüft. Aktuelle offizielle CCP-Reaktions- und
ESI-Grundlagen kontrolliert. P43 und Steuerdokumentation aktualisiert.

### Zentrale Entscheidungen

Stop/No-Go für den vollständigen Umfang. Reaktivierung erst bei belegtem
Mehrlinien-/Chargenbedarf und dann nur als kleiner manueller lokaler
Workflow ohne Live-Strukturen, Fuelverteilung oder Corporation-Daten.

### Neu erstellte Dateien

Abschlussbericht `2026-07-27_P43_Nutzenreview.md`.

### Geänderte Dateien

P43-Spezifikation und betroffene Status-/Planungsdokumente.

### Build-Ergebnis

Nicht ausgeführt; keine Laufzeitdatei geändert. Letzter Nachweis bleibt
SwiftPM- und Xcode-Debugbuild aus P42.

### Testergebnis

Nicht ausgeführt; reine Planung. Letzter Nachweis bleibt 608/608.

### Erkannte Probleme

Kein neuer kritischer Fehler. Der ursprüngliche P43-Umfang überschneidet
vorhandene Lager-/Reservierungsfunktionen und allgemeine P44-Kapazität.

### Nicht erledigte Punkte

Keine P43-Implementierung. Realer Mehrlinienbedarf ist nicht belegt.

### Aktualisierte Features

`REA-001`, `OFF-021`.

### Nächster Prompt

Vorhandenen Reaktionsfluss real nutzen; P44-Nutzenreview nur auf
ausdrücklichen Auftrag.

## 2026-07-27 – P44: Nutzenreview PI, Logistik und Kapazität

### Ausgangszustand

P43 war geprüft und zurückgestellt. P44 bestand nur als verschobener
Kurzentwurf; der Kernplaner besaß bereits Lagerorte, Reservierungen,
Produktionszeiten sowie persönliche Assets und Industry Jobs.

### Ziel

Prüfen, ob PI-Kolonien, Transporte, Kalender und Kapazitätsplanung für den
lokalen Betrieb genügend Zusatznutzen bieten.

### Durchgeführte Arbeiten

Projektbuchkapitel 14, 21 und 23, vorhandene Produktions-/Lager-/ESI-
Abdeckung, aktuelle CCP-PI-/Manufacturing-Regeln, PI- und Routenendpunkte,
P43-Abgrenzung und `OFF-021` geprüft. P44 und Steuerdokumentation
aktualisiert.

### Zentrale Entscheidungen

Stop/No-Go für das gebündelte Gesamtpaket. Eine spätere Reaktivierung darf
genau einen belegten Teilbedarf behandeln: read-only PI-Monitor, manuelle
Transportcheckliste oder read-only Industry-Job-Zeitleiste.

### Neu erstellte Dateien

Abschlussbericht `2026-07-27_P44_Nutzenreview.md`.

### Geänderte Dateien

P44-Spezifikation und betroffene Status-/Planungsdokumente.

### Build-Ergebnis

Nicht ausgeführt; keine Laufzeitdatei geändert. Letzter Nachweis bleibt
SwiftPM- und Xcode-Debugbuild aus P42.

### Testergebnis

Nicht ausgeführt; reine Planung. Letzter Nachweis bleibt 608/608.

### Erkannte Probleme

Kein neuer kritischer Fehler. PI, Logistik und Kapazität besitzen getrennte
Scope-, Daten- und Berechnungsgrenzen und dürfen nicht als ein ungeteiltes
Implementierungspaket begonnen werden.

### Nicht erledigte Punkte

Keine P44-Implementierung. Konkreter Kolonie-, Mehrstandort- oder
Mehrlinienbedarf ist nicht belegt.

### Aktualisierte Features

`PI-001`, `OFF-021`.

### Nächster Prompt

Vorhandenen Produktions-/Lagerfluss real nutzen; P45-Nutzenreview nur auf
ausdrücklichen Auftrag.

## 2026-07-27 – PLAN-005: Restabnahmefolge P50–P54

### Ausgangszustand und Ziel

P38–P42 waren technisch umgesetzt, P43/P44 zurückgestellt. Ein erneuter
Funktionsaudit sollte verlorene Voraussetzungen des bereits gewünschten
Umfangs identifizieren und ohne Doppelabdeckung in eine ausführbare Folge
überführen.

### Durchgeführte Arbeiten und Entscheidungen

Quellcode, Prompts, Statusregister, offene Punkte, Xcode-Projektbestände und
Git-Zustand wurden abgeglichen. P50–P54 übernehmen ausschließlich belegte
Restarbeit: P40-Nutzbarkeit, P42-Korrekturen, reale Eigentümerabnahme,
Steuerungs-/Projektkanon und einen separat freizugebenden lokalen
Sicherungscommit. P49 bleibt bewusst unbelegt; P43–P48 werden nicht
vorgezogen.

### Build, Tests und Datenwirkung

Keine Laufzeitdatei, kein Schema und keine Benutzerdaten geändert. Der
aktuelle SwiftPM-Nachweis 608/608 und der Projektverifier wurden kontrolliert;
ein neuer Xcode-Build war für die reine Planung nicht erforderlich. Kein
Commit und kein Push.

### Aktualisierte Features und offene Punkte

`ESI-001`, `WAL-001`, `OFF-035` bis `OFF-039` und `KI-038` bis `KI-042`.

### Nächster Prompt

P50 nur auf ausdrücklichen Auftrag.

## 2026-07-27 – P50: P40-Restabnahme persönliche ESI-Daten

### Ausgangszustand

P40 speicherte persönliche Assets, Blueprints und Industry Jobs sicher und
offline, bot aber nur Zähler und keine kontrollierte Wirkung auf die
Produktionsverfügbarkeit.

### Ziel

Persönliche Snapshots detailliert nutzbar machen und Assets ausschließlich
nach Projekt-/Ortsvorschau und ausdrücklicher Bestätigung verrechnen.

### Durchgeführte Arbeiten

Begrenzte Such-/Filter-/Sortierprojektionen und drei Detailansichten
umgesetzt. Eine getrennte ESI-Asset-Verfügbarkeitsquelle mit
Doppelzählungs-, Revisions-, Abbruch- und Überlaufschutz ergänzt. Schema v23,
Migration, Backup, Restore, Wiederöffnung und Trennkompensation erweitert.

### Zentrale Entscheidungen

Manuelle/CSV-Bestände bleiben unverändert; ESI-Mengen werden separat
ausgewiesen. Eine spätere Überschneidung deaktiviert die Wirkung, löscht die
Auswahl aber nicht. Unbekannte Namen bleiben als stabile IDs sichtbar;
OFF-021 löste keinen zusätzlichen SDE-Import aus.

### Neu erstellte Dateien

P50-Detailview, Application-Projektion und -Service, Schema-v23-Repository,
Tests, `ESI_ASSET_AVAILABILITY.md`, ADR-0048 und Abschlussbericht.

### Geänderte Dateien

Composition, Build-or-Buy-Verfügbarkeit, Charaktertrennung,
Migrations-/Backupgrenzen, Xcode-Projekt und betroffene Steuerdokumente.
Der Review ersetzte zusätzlich einen stillen Dateistore-Fallback durch den
zentralen Startup-Fehlerpfad.

### Build-Ergebnis

SwiftPM Debug und finaler isolierter unsigned Xcode-Debugbuild erfolgreich;
Projektverifier 16 Targets, 8 Testtargets, 2 gemeinsame Schemes.

### Testergebnis

8/8 fokussierte Asset-Verfügbarkeitstests und 619/619 Gesamttests bestanden.

### Erkannte Probleme

Der direkte Xcode-Aufruf am File-Provider-Pfad kann weiterhin blockieren;
die isolierte inhaltsgleiche Kopie bestand. Kein P50-Datenverlust oder
kritischer Fehler nachgewiesen.

### Nicht erledigte Punkte

Kein produktiver persönlicher Live-Abruf; dieser Eigentümernachweis bleibt
P52. P51-Korrekturen wurden nicht vorgezogen.

### Aktualisierte Features

`ESI-001`, `OFF-035`, `KI-038`, Schema v23.

### Nächster Prompt

P51 nur auf ausdrücklichen Auftrag.

## 2026-07-27 – P51: P42-Korrektur Scope, Fehler und Plan/Ist

### Ausgangszustand

P42 war technisch vorhanden, aber vier Viewoperationen waren falsch geroutet,
P40 und Wallet teilten einen Vier-Scope-Pfad und die Finanzansicht zeigte
Plan und bestätigtes Ist nicht vollständig nebeneinander.

### Ziel

Fehlerpfade korrigieren, Autorisierung zweckgebunden minimieren und P29-Plan
sowie P42-Ist im selben Projektkontext prüfbar darstellen.

### Durchgeführte Arbeiten

Viewoperationen korrigiert und architekturgetestet. Exakt drei Basisscopes
von der ausdrücklich neu autorisierten Vier-Scope-Walletfreigabe getrennt.
Schema v24 für nicht geheime Scopemetadaten ergänzt. Einen getrennten
Application-Vergleichsdienst und die gemeinsame Plan-/Ist-Ansicht mit
fehlenden, veralteten und archivierten Zuständen umgesetzt.

### Zentrale Entscheidungen

Snapshots gelten nie als Scopebeleg; Migrationen erfinden keine Zustimmung.
Abbruch verändert Account und Token nicht. Wallet-Istwerte überschreiben
keine Planwerte und archivierte Projekte bleiben schreibgeschützt.

### Neu erstellte Dateien

Zweck-/Scopevertrag, Finanzvergleichsdienst, Schema v24, Vergleichstests,
ADR-0049 und P51-Abschlussbericht.

### Geänderte Dateien

SSO-Use-Case, Accountrepository, Composition/ViewModel/UI,
Migrations-/Backupgrenzen, Xcode-Projekt sowie betroffene Steuer- und
Fachdokumentation.

### Build-Ergebnis

SwiftPM Debug und isolierter unsigned Xcode-Debugbuild erfolgreich;
Projektverifier bestätigt 16 Targets, 8 Testtargets und 2 gemeinsame Schemes.

### Testergebnis

58 fokussierte Prüfungen und 631/631 Gesamttests bestanden.

### Erkannte Probleme

Der sandboxed Xcode-Lauf konnte SwiftData-Makros nicht starten; derselbe
isolierte Build bestand außerhalb der Sandbox. Kein P51-Fehler offen.

### Nicht erledigte Punkte

Kein produktiver Eigentümerlauf mit persönlichen P40-/P42-Daten; P52 bleibt
dafür zuständig. Kein Commit oder Push.

### Aktualisierte Features

`WAL-001`, `OFF-036`, `KI-039`, `KI-040`, Schema v24.

### Nächster Prompt

P52 nur auf ausdrücklichen Auftrag.

## 2026-07-27 – P52: Eigentümer-Betriebsabnahme angehalten

### Ausgangszustand

P50/P51 waren automatisiert grün; der produktive P40–P42-Eigentümerlauf
fehlte.

### Ziel

Livepfade mit unmittelbaren Scope- und Schreibbestätigungen prüfen.

### Durchgeführte Arbeiten

Store, Backup, Keychainkonfiguration und Redaction vorgeprüft. 631/631
SwiftPM-Tests und ein signierter Xcode-Debugbuild bestanden. Der Eigentümer
bestätigte den ersten Drei-Scope-Login und den getrennten Walletscope.
Inspect-Schritte wurden ohne Apply versucht.

### Zentrale Entscheidungen

Nach HTTP-400-Refresh und fehlendem Owner-Contact-Nachweis gemäß
P52-Sicherheitsregel angehalten. Keine Fachdatenübernahme. Der nachgewiesene
Form-Encoding-Fehler wird P51 als OFF-040/KI-043 zugeordnet.

### Neu erstellte Dateien

P52-Zwischenbericht.

### Geänderte Dateien

Nur betroffene Status-, Prompt-, SSO- und Auditdokumentation.

### Build-Ergebnis

SwiftPM Debug erfolgreich; lokaler signierter Xcode-Debugbuild und strikte
Signaturprüfung erfolgreich.

### Testergebnis

631/631 automatisierte Tests bestanden; realer Livepfad nicht bestanden.

### Erkannte Probleme

Refresh-Tokens mit `+` werden nicht RFC-konform formularcodiert. Die
Owner-Contact-Angabe ist für den Appprozess nicht lesbar nachgewiesen.

### Nicht erledigte Punkte

P40-/P41-/P42-Vorschau, Apply, Neustart, Offlinefall und Endzustand bleiben
nach OFF-040 offen.

### Aktualisierte Features

`SSO-001`, `ESI-001`, `WAL-001`, `OFF-037`, `OFF-040`, `KI-043`.

### Nächster Prompt

P51-Nachkorrektur; danach P52 mit erneuter Eigentümerfreigabe fortsetzen.

## 2026-07-27 – P51: OAuth- und Keychain-Nachkorrektur

### Ausgangszustand

P52 zeigte HTTP 400 beim Refresh, fehlenden Owner-Contact und eine
irreführende grüne Löschmeldung beim Speichern eines leeren Kontaktfelds.

### Ziel

OAuth-Formwerte korrekt codieren, Keychain-Schreibvorgänge verifizieren und
Speichern eindeutig von bestätigtem Entfernen trennen.

### Durchgeführte Arbeiten

Reservierte Tokenzeichen werden formgerecht codiert. Fehlender und nicht
lesbarer Keychain-Eintrag sind getrennt; Speichern und Entfernen werden durch
Zurücklesen verifiziert. Statusmeldungen stehen direkt an den Kontakt-
Bedienelementen. Leere Eingaben sind gesperrt, Entfernen ist eine eigene
bestätigungspflichtige Aktion.

### Build-Ergebnis

Signierter Xcode-Debugbuild für macOS arm64 erfolgreich.

### Testergebnis

639/639 SwiftPM-Tests sowie 4/4 fokussierte Kontakt-UX-Tests bestanden.

### Erkannte Probleme

Kein automatisierter Blocker. Der echte Neustart-, Refresh- und ESI-Nachweis
steht aus.

### Nicht erledigte Punkte

OFF-040 bleibt bis zum Eigentümer-Livenachweis teilweise offen; P52 hat noch
keine Fachdaten übernommen.

### Aktualisierte Features

`SSO-001`, `ESI-001`, `OFF-040`, `KI-043`.

### Nächster Prompt

P52 ab dem Owner-Contact-Neustartnachweis fortsetzen.

### Ergänzender manueller und visueller Nachweis

Der Projekteigentümer bestätigte die grüne Erfolgsmeldung des verifizierten
Speichervorgangs. Das dabei als kaum erkennbar gemeldete Eingabefeld erhielt
eine sichtbare Beschriftung, einen großen abgerundeten Rahmen und einen
Beispielhinweis. Der fokussierte Quelltest und der signierte Xcode-Debugbuild
bestanden. Im eingeschränkten Vollauf bestanden 636/639 Tests; die drei allein
an Security.framework gescheiterten Fälle bestanden anschließend im
vollständigen 10/10-SSO-Testlauf außerhalb der Sandbox.

## 2026-07-27 – P52: ESI-Livepfad-Nachkorrektur

### Ausgangszustand

Refresh reagierte sichtbar nicht. Persönlicher Apply meldete
`cache_write_failed`, Wallet-Inspect `inconsistent_pagination`.

### Ziel

Die drei nachgewiesenen Ursachen begrenzt korrigieren, ohne Konsistenz-,
Datenschutz- oder Bestätigungsgates zu schwächen.

### Durchgeführte Arbeiten

Refresh zeigt laufenden, erfolgreichen oder fehlgeschlagenen Zustand.
Persönliche Snapshot-Daten werden mit verlustfreiem Datumsformat gespeichert;
alte ISO-8601-Daten bleiben lesbar. Wallet-Journal behält CCPs
seitenübergreifende Konsistenzprüfung und führt nach einem Cachewechsel genau
einen begrenzten Neuversuch aus.

### Build-Ergebnis

Signierter Xcode-Debugbuild für macOS arm64 erfolgreich.

### Testergebnis

4/4 fokussierte Regressionen und 642/642 SwiftPM-Tests bestanden.

### Erkannte Probleme

Keine automatisierte Regression offen. Der Eigentümer-Retest steht aus.

### Nicht erledigte Punkte

OFF-040/OFF-041 sowie die weitere P52-Vorschau-/Bestätigungsfolge.

### Aktualisierte Features

`SSO-001`, `ESI-001`, `WAL-001`, `KI-044`, `OFF-041`.

### Nächster Prompt

P52 mit getrenntem Refresh-, persönlichem Apply- und Wallet-Inspect-Retest
fortsetzen.

### Eigentümer-Retest: Refresh

Nach vollständigem Neubuild bestätigte der Projekteigentümer den sichtbaren
und fehlerfreien Refresh. OFF-040/KI-043 sind damit geschlossen. Persönlicher
Apply und Wallet-Inspect wurden in diesem Schritt nicht erneut ausgeführt.

### Eigentümer-Retest: persönlicher Inspect

Die persönliche ESI-Vorschau erschien fehlerfrei. Es wurde noch keine
Vorschau übernommen; der Cache-Schreibnachweis wartet auf das nächste
ausdrücklich bestätigte Gate.

### Eigentümer-Retest: persönlicher Apply

Nach unmittelbarer Eigentümerbestätigung wurde die persönliche Vorschau
übernommen. Der Vorgang bestand ohne `NEN-ESI-003`; der korrigierte lokale
Snapshot-Schreibpfad ist damit real bestätigt.

### Eigentümer-Retest: Wallet-Unterdiagnose

Wallet-Inspect meldete nach dem begrenzten Retry erneut `NEN-ESI-004`.
Die Konsistenzgrenze blieb unverändert; der bislang allgemeine Diagnosegrund
wurde in sechs redigierte, wertfreie Untergründe aufgeteilt. 15/15 fokussierte
und 644/644 vollständige Tests sowie der signierte Xcode-Debugbuild bestanden.
Der nächste einmalige Live-Inspect muss nur noch den konkreten sicheren
Untergrund liefern; eine Walletübernahme bleibt gesperrt.

## 2026-07-27 – P52: Wallet-From-ID-Korrektur

### Ausgangszustand

Der reale Wallet-Inspect meldete den sicheren Untergrund
`inconsistent_pagination_conflicting_transaction`.

### Ziel

Den nachgewiesenen Paginationfehler korrigieren, ohne echte widersprüchliche
Transaktionen zu akzeptieren oder Walletdaten zu schreiben.

### Durchgeführte Arbeiten

Die offizielle CCP-From-ID-Regel wurde geprüft: Der Cursor-Datensatz ist auf
der Folgeseite erneut enthalten. Der Client dedupliziert diesen Eintrag nun
nach vollständigem fachlichem Inhalt ohne die lokale `sourcePage`. Eine
abweichende Transaktion mit derselben ID bleibt ein harter Konsistenzfehler.

### Build-Ergebnis

Signierter Xcode-Debugbuild für macOS arm64: **BUILD SUCCEEDED**.

### Testergebnis

9/9 fokussierte Walletclient-Tests und 646/646 vollständige SwiftPM-Tests
bestanden; `git diff --check` bestanden.

### Erkannte Probleme

Keine offene automatisierte Regression. Der reale Wallet-Retest steht aus.

### Nicht erledigte Punkte

OFF-041 bleibt bis zur sichtbaren Wallet-Vorschau offen. Keine Walletvorschau
wurde übernommen oder einem Projekt zugeordnet.

### Aktualisierte Features

`WAL-001`, `OFF-041`, `KI-044`.

### Nächster Prompt

P52 mit genau einem Wallet-Inspect im neuen Build fortsetzen.

### Eigentümer-Livenachweis

Der Projekteigentümer bestätigte den Test als erfolgreich: Nach „Wallet
prüfen“ öffnete sich das Vorschaufenster ohne erneuten Diagnosefehler. Der
Inspect blieb schreibfrei; die Vorschau wurde nicht übernommen. OFF-041 und
KI-044 sind damit geschlossen. P52 wartet auf die getrennte
Übernahmeentscheidung.

### Eigentümer-Apply und Neustart

Nach ausdrücklicher Freigabe wurde der Wallet-Snapshot übernommen. Der
Projekteigentümer bestätigte ihn nach vollständigem App-Neustart weiterhin
als vorhanden. Damit sind Apply und Persistenz real bestanden.

Die UI zeigte für Übernehmen und Verwerfen keine klare Abschlussmeldung.
Quellprüfung bestätigte: Übernehmen speichert und schließt die Vorschau;
Verwerfen verwirft ausschließlich die aktuelle Vorschau und löscht keinen
gespeicherten Snapshot. OFF-042/KI-045 dokumentieren die fehlende sichtbare
Rückmeldung, ohne die sichere Persistenzsemantik zu ändern.

## 2026-07-27 – OFF-042: Wallet-Aktionsfeedback

### Ausgangszustand

Apply und Persistenz waren real bestanden, aber Übernehmen und Verwerfen
lieferten nach dem Schließen der Vorschau keine erkennbare Rückmeldung.

### Ziel

Den Aktionsausgang charakterbezogen sichtbar machen, ohne Walletdaten,
Persistenz oder Löschsemantik zu verändern.

### Durchgeführte Arbeiten

Die Accountzeile zeigt Apply-Erfolg, Apply-Fehler sowie Verwerfen mit und ohne
vorhandenen Snapshot. Ein neuer Wallet-Inspect entfernt die alte Meldung.
Verwerfen löscht weiterhin keinen gespeicherten Snapshot.

### Build-Ergebnis

Signierter Xcode-Debugbuild für macOS arm64: **BUILD SUCCEEDED**.

### Testergebnis

4/4 fokussierte Regressionen und 650/650 vollständige SwiftPM-Tests bestanden;
`git diff --check` bestanden.

### Erkannte Probleme

Keine technische Regression. Sichtbarer UI-Liveretest steht aus.

### Nicht erledigte Punkte

OFF-042/KI-045 bleiben bis zum UI-Liveretest teilweise. Keine
Projektzuordnung wurde vorgenommen.

### Aktualisierte Features

`WAL-001`, `OFF-042`, `KI-045`.

### Nächster Prompt

P52 mit schreibfreiem Verwerfen-Liveretest fortsetzen.

### 2026-07-28 – Eigentümer-Livenachweis Verwerfen

Der Projekteigentümer bestätigte im neuen Build die sichtbare Meldung:
„Vorschau verworfen. Der gespeicherte Wallet-Snapshot bleibt erhalten.“
Discard-Feedback und Bestandsschutz sind damit live bestanden. Der
Apply-Feedback-Livetest bleibt bis zu einem neuen ausdrücklichen Gate offen.

### 2026-07-28 – Eigentümer-Livenachweis Apply

Nach neuer ausdrücklicher Freigabe bestätigte der Projekteigentümer die
sichtbare Meldung „Wallet-Snapshot wurde gespeichert.“ Apply- und
Discard-Feedback sind damit live bestanden; OFF-042/KI-045 sind geschlossen.

## 2026-07-28 – P52: OFF-037-Restgate-Inventur

### Ausgangszustand und Ziel

Wallet- und persönlicher ESI-Pfad waren live bestanden; die übrigen
P40-/P41-/P42-Betriebsnachweise waren nur zusammengefasst offen.

### Durchgeführte Arbeiten und Entscheidungen

Quellcode, UI-Gates, Berichte und Steuerdateien wurden abgeglichen. Die
verbleibenden Read-only-, Preview-, Apply-, Neustart-, Offline- und
Endzustandsgates sind einzeln im P52-Prompt erfasst. Schreibende Schritte
bleiben voneinander getrennt und benötigen jeweils eine neue Bestätigung.

### Build- und Testergebnis

45/45 fokussierte P40-/P41-/P42-Regressionen bestanden. Kein neuer
Xcode-Build, da seit dem signierten OFF-042-Build kein Quellcode geändert
wurde.

### Nicht erledigte Punkte und nächster Schritt

OFF-037 bleibt teilweise. Nächstes Gate: P40-1, persönliche Detailansicht
online und schreibfrei prüfen.

## 2026-07-28 – OFF-043: P40-Detailfenster schließen

### Ausgangszustand und Ziel

P40-1 bestand live für Assets, Blueprints und Industry Jobs. Das modale
Detailfenster besaß jedoch keinen sichtbaren Schließen-Button.

### Durchgeführte Arbeiten

Im Kopf der Detailansicht wurde ein beschrifteter Schließen-Button mit
Escape-Kurzbefehl ergänzt. Der bestehende Sheet-, Daten- und
Persistenzpfad blieb unverändert.

### Build- und Testergebnis

1/1 fokussierter Architekturtest und 650/650 vollständige SwiftPM-Tests
bestanden. Apple-Development-signierter Xcode Debug für macOS arm64:
**BUILD SUCCEEDED**.

### Erkannte Probleme und nächster Schritt

Keine technische Regression. OFF-043 bleibt bis zum einmaligen Sichttest
teilweise; danach folgt P40-2.

### 2026-07-28 – Eigentümer-Livenachweis

Der Projekteigentümer bestätigte den sichtbaren Schließen-Button im neuen
Build. OFF-043/KI-046 sind geschlossen. Nächstes Gate ist P40-2, der
schreibfreie Neustart-/Offline-Nachweis.

### 2026-07-28 – P40-2 Eigentümer-Livenachweis

Nach vollständigem App-Neustart ohne Netzverbindung blieben Assets,
Blueprints und Industry Jobs aus dem lokalen persönlichen Snapshot lesbar.
Kein Refresh, Inspect oder Apply wurde ausgelöst; keine Daten wurden
verändert. P40-2 ist bestanden. Nächstes Gate ist P40-3 als Vorschau mit
anschließendem Verwerfen.

## 2026-07-28 – P52/OFF-044: Semantische ESI-Namen und Auswahlrücknahme

### Ausgangszustand

P40-3 bestand nach Anlage eines Referenzprojekts einschließlich Verwerfen.
Eine weitere Auswahl wurde unbeabsichtigt gespeichert. Persönliche Ansichten
zeigten technische IDs statt der benötigten Item-, Orts- und Jobangaben.

### Ziel

Die Ansichten fachlich benennen und die gespeicherte Projektauswahl sicher,
nach Vorschau und ausdrücklicher Bestätigung, zurücknehmbar machen.

### Durchgeführte Arbeiten

- SDE-Item-/Produktnamen sowie zentrale Aktivitäts-, Status- und
  Location-Flag-Bezeichnungen in Asset-, Blueprint-, Vorschau- und
  Jobdarstellung verwendet,
- öffentlichen tokenfreien ESI-Namensadapter und lokalen
  Stations-/Systemnamencache ergänzt,
- technische IDs aus der normalen UI entfernt,
- zweiten Apply-Bestätigungsdialog sowie stale-geschützte
  Rücknahmevorschau und atomare gezielte Löschung ergänzt,
- kanonisches Xcode-Projekt, Tests, ADR-0050 und Steuerdokumente
  aktualisiert.

### Zentrale Entscheidungen

Vorhandene Auswahl bleibt bis zur Eigentümerbestätigung unverändert.
Private Spielerstrukturnamen werden ohne zusätzliche Scope-Autorisierung
nicht erfunden; die UI zeigt einen transparenten generischen Text.

### Build-Ergebnis

Apple-Development-signierter Xcode Debug, Scheme `NewEdenNexus`, macOS
arm64: **BUILD SUCCEEDED**. `plutil -lint` bestanden.

### Testergebnis

18/18 fokussierte und 658/658 vollständige SwiftPM-Tests bestanden;
`git diff --check` bestanden.

### Erkannte Probleme und nicht erledigte Punkte

OFF-044 bleibt bis zum Eigentümer-Sicht- und Rücknahmetest teilweise.
OFF-045 hält die optionale Entscheidung über exakte private
Spielerstrukturnamen fest. P40-4 wurde nicht als bestanden gewertet.

### Aktualisierte Features und nächster Prompt

`ESI-001`, `OFF-037`, `OFF-044`, `OFF-045`, `KI-047`, `KI-048`.
Nächster Schritt: OFF-044-Livetest; danach P40-4 nur mit neuer Freigabe.

## 2026-07-28 – P52/OFF-045/OFF-046: Spielerstrukturen und Typnamen

### Ausgangszustand und Ziel

Die Rücknahme und Anzeige der aktiven Projektauswahl funktionierten live.
Private Spielerstrukturen blieben generisch; einzelne vorhandene Typen
erschienen wegen einer 2.000-Rohzeilen-Grenze fälschlich als unbekannt.

### Durchgeführte Arbeiten und Entscheidungen

Der optionale Strukturnamenscope wird nur nach einem eigenen erklärten
Bestätigungsdialog ergänzt. Die App löst nur referenzierte Strukturen auf,
verwendet HTTP-Validatoren und behält den letzten gültigen Cache offline.
Alle referenzierten Snapshot-Type-IDs werden nun gebündelt aus dem aktiven
SDE geladen; Ladezustand und echter SDE-Fehlbestand sind getrennt.

### Build- und Testergebnis

42/42 fokussierte und 662/662 vollständige SwiftPM-Tests bestanden.
Apple-Development-signierter Xcode Debug für das Scheme `NewEdenNexus`:
**BUILD SUCCEEDED**.

### Erkannte Probleme und nächster Schritt

Keine Konten-, Scope-, Snapshot- oder Projektdaten wurden verändert.
OFF-045/OFF-046 bleiben bis zum Eigentümer-Sichttest teilweise: optionalen
Scope bewusst freigeben, zugänglichen Strukturnamen und vollständige
Typnamen im neuen Build prüfen. P40-4 beginnt dadurch nicht automatisch.

## 2026-07-28 – P52/P40-4: Eigentümer-Betriebsabnahme

### Ausgangszustand und Ziel

P40-3 sowie die Auswahlrücknahme waren bestanden. P40-4 sollte eine bewusst
neu gewählte Projekt-Asset-Auswahl mit separatem Schreibgate und
Neustart-/Offline-Nachweis prüfen.

### Durchgeführte Arbeiten und Ergebnis

Der Eigentümer bestätigte zunächst die schreibfreie Vorschau, anschließend
separat die Speicherung. Die aktive Auswahl war sichtbar und blieb nach
vollständigem App-Neustart ohne Netz beim gleichen Projekt vorhanden. Beim
Offline-Nachweis wurde weder aktualisiert noch eine neue Vorschau erzeugt.

### Build-, Test- und Reviewstatus

Keine Quellcodeänderung. Der zuletzt bestandene Nachweis bleibt 662/662
SwiftPM-Tests und Apple-Development-signierter Xcode Debug. P40-4 ist als
Eigentümerbetrieb `✅ bestanden`; P52 bleibt wegen OFF-045/OFF-046 sowie
P41-/P42-Restgates teilweise.

## 2026-07-28 – P52/OFF-047: Produktionsworkspace-Navigation

### Ausgangszustand und Ziel

P41-1 war wegen des schmalen, sehr langen Produktionsworkspace nicht
verständlich testbar. Ziel war eine breitere und direkt navigierbare
Darstellung ohne fachliche oder persistente Änderung.

### Durchgeführte Arbeiten und Entscheidungen

Das Graph-Sheet verwendet 1.080/1.360 pt Mindest-/Idealbreite. Eine
horizontale segmentierte Leiste schaltet zwischen sechs Bereichen um; nur
der gewählte Bereich wird angezeigt. Ein permanenter Split in der
Projektliste wurde wegen des deutlich größeren Eingriffs nicht umgesetzt.
ADR-0052 und die Workspace-Dokumentation wurden ergänzt.

### Build-, Test- und Reviewstatus

9/9 fokussierte Prüfungen, 662/662 SwiftPM-Tests, `git diff --check` und der
Apple-Development-signierte Xcode-Debugbuild bestanden. Keine Schema-,
Migrations- oder Benutzerdatenänderung. Review: technisch bestanden,
Eigentümer-Sichttest offen.

### Erkannte Probleme und nächster Schritt

OFF-047 bleibt teilweise, bis Breite und alle sechs Bereiche im neuen Build
sichtbar bestätigt sind. Danach P41-1 über **Kosten & ROI** neu beginnen.

## 2026-07-28 – P52/P41-1: ISK-Preissätze und schreibfreie Marktvorschau

### Ausgangszustand und Ziel

Die Bezeichnung „Preisprofil“ vermittelte eine unnötige Währungswahl und
blockierte die P41-1-Vorschau, solange kein Profil vorhanden war.

### Durchgeführte Arbeiten und Entscheidungen

Die UI nennt getrennte Preisstände jetzt Preissätze; alle persistenten und
berechneten Beträge bleiben ISK. Der Marktpreis-Vorschauvertrag akzeptiert
einen fehlenden Ziel-Preissatz, liest dann keine vorhandenen Preise und
sperrt jede Übernahme. Eine PLEX-Anzeige wurde nicht geraten, sondern als
getrennter späterer Buy-/Sell-Quoteausbau OFF-049 festgehalten.

### Build- und Testergebnis

12/12 fokussierte und 664/664 vollständige SwiftPM-Tests bestanden. Der
erste Xcode-Build scheiterte ausschließlich an File-Provider-Metadaten im
Derived-Data-App-Bundle; der identische Apple-Development-signierte
macOS-arm64-Debugbuild bestand mit isoliertem Derived Data.

### Erkannte Probleme und nächster Schritt

Keine Schema-, Migrations- oder Benutzerdatenänderung. OFF-048 bleibt bis zum
Eigentümer-Sichttest teilweise: profilfreie Vorschau abrufen, gesperrte
Übernahme prüfen und über **Schließen** beenden. P41-2 bleibt nicht
autorisiert.

## 2026-07-28 – P52/P41-1: Benannte Marktquellen und Trade Hubs

### Ausgangszustand und Ziel

P41-1 verlangte technische Region- und Location-IDs. Gewünscht waren
benannte Regionen, fünf direkt wählbare Trade Hubs sowie bekannte
Stationen und Spielerstrukturen einschließlich Home-Hubs.

### Durchgeführte Arbeiten und Entscheidungen

Ein öffentlicher Universe-Directory-Adapter lädt und validiert Regionen,
Stationshierarchie und öffentliche Marktstruktur-IDs. Der
Application-Service verbindet sie mit den bereits lokal bekannten
persönlichen Ortsnamen. Die UI zeigt benannte Dropdowns und
Trade-Hub-Schnellwahlen. Private Strukturmärkte bleiben sichtbar, aber
gesperrt, weil der vorhandene P41-Vertrag nur öffentliche regionale
Sell-Orders liest. ADR-0054 dokumentiert diese Grenze.

### Build-, Test- und Datenwirkung

26/26 fokussierte sowie 667/667 vollständige SwiftPM-Tests bestanden.
`git diff --check` und der Apple-Development-signierte Xcode-Debugbuild für
macOS arm64 bestanden. Keine Schema-, Migrations- oder Benutzerdatenänderung.

### Erkannte Probleme und nächster Schritt

OFF-050 bleibt bis zum Eigentümer-Sichttest teilweise. Im nächsten
P41-1-Schritt eine benannte Region, einen Trade Hub und wenn vorhanden einen
bekannten öffentlichen Home-Hub prüfen, Vorschau abrufen und schließen.
Private Strukturorders und PLEX bleiben getrennte spätere Nutzenreviews.

## 2026-07-28 – P52/OFF-050: Eigentümerabnahme

### Ausgangszustand und Ziel

Die benannte Marktquellenauswahl war technisch bestanden, aber noch nicht im
Eigentümerbetrieb bestätigt.

### Durchgeführte Arbeiten und Ergebnis

Der Eigentümer bestätigte, dass die Auswahl funktioniert. Die
Marktpreisvorschau wurde dabei bereits in den gewählten Preissatz übernommen.
Dies ist der vorgesehene P41-2-Schreibvorgang und ändert ausschließlich
diesen Preissatz; Bestände, Projekte und ESI-Snapshots bleiben unberührt.

### Build-, Test- und Reviewstatus

Keine weitere Quellcodeänderung. Der technische Nachweis bleibt 26/26
fokussierte und 667/667 vollständige SwiftPM-Tests sowie der signierte
Xcode-Debugbuild. OFF-050 ist live bestanden. P41-2 bleibt bis zur sichtbaren
Herkunfts-/Cachezeitprüfung, P41-3 bis zum Neustart-/Offline-Nachweis offen.

## 2026-07-28 – P52/P41-2 bis P41-3: Eigentümerabnahme

### Ausgangszustand und Ziel

Die Marktpreise waren bereits übernommen. Offen waren Herkunft, Region oder
Standort, Cachezeit sowie Persistenz nach Neustart beziehungsweise offline.

### Ergebnis

Der Eigentümer bestätigte alle Prüfungen als funktionsfähig. Der gewählte
Preissatz blieb nach vollständigem Neustart beziehungsweise offline erhalten.
P41-1 bis P41-3 sind damit live bestanden.

### Build-, Test- und nächster Schritt

Keine Quellcode- oder weitere Datenänderung. Der technische Nachweis bleibt
26/26 fokussierte und 667/667 vollständige SwiftPM-Tests sowie der signierte
Xcode-Debugbuild. Nächstes Gate ist P42-1 ausschließlich als
Wallet-Projektzuordnungsvorschau mit anschließendem Abbruch/Verwerfen.

## 2026-07-28 – P52/OFF-051: Gruppierte ESI-Detailansichten

### Ausgangszustand und Ziel

Assets und Blueprints wurden sofort als lange Einzelzeilenlisten aufgebaut;
Industry Jobs enthielten auch ausgelieferte Historie. Stationen waren nicht
als primäre Navigation gruppiert und die wiederholte Ortsauflösung belastete
Laden und Interaktion.

### Durchgeführte Arbeiten und Entscheidungen

Ein einmaliger Ortsindex und Application-Projektoren gruppieren Assets,
Blueprints und aktive Jobs alphabetisch nach Stationsnamen. Die SwiftUI-
Ansicht zeigt geschlossene `DisclosureGroup`s, erzeugt Zeilen in
100er-Schritten und projiziert globale Suche und Sortierung nach kurzer
Entprellung außerhalb des Main Threads. Historische Jobs bleiben im
unveränderten Snapshot. ADR-0055 hält die Grenze fest.

### Build-, Test- und Datenwirkung

17/17 fokussierte und 668/668 vollständige SwiftPM-Tests bestanden. 5.001
synthetische Assets wurden in rund 0,064 s gruppiert. Unsigned und mit der
aktuell gültigen Apple-Development-Identität per Team-Override signierter
Xcode Debug bestanden. Keine Schema-, Migrations- oder Benutzerdatenänderung.

### Erkannte Probleme und nächster Schritt

OFF-051 benötigt den Eigentümer-Sichttest. Der unveränderte Projektkanon
enthält eine alte Team-ID; OFF-052 wird ohne vorgezogene Signing-Änderung P53
zugeordnet. Danach folgt P42-1 weiterhin nur als Vorschau mit Verwerfen.

## 2026-07-28 – P52/OFF-051 und P53: Eigentümerabnahme und Kanonvorschau

### Ausgangszustand

OFF-051 wartete auf den realen Sichttest. P53 sollte danach beginnen, durfte
aber Projektkopien, Promptentwurf oder Signing nicht ohne konkrete Prüfung
und gegebenenfalls Bestätigung verändern.

### Ziel

OFF-051 wahrheitsgemäß abschließen, die Stationszeile intuitiver bedienbar
machen und P53 bis zum bestätigungspflichtigen Dateigate ausführen.

### Durchgeführte Arbeiten

- Eigentümerbestätigung für Gruppierung, Suche und aktive Jobs erfasst,
- vollständige Stationszeile als zugängliche Klickfläche umgesetzt,
- sichtbare Roadmap-, Dashboard- und Blueprinttexte an den Ist-Stand angepasst,
- zehn Xcode-Projektstände, P21-Dublette und Signingkonfiguration inventarisiert,
- Kanon temporär aus `project.yml` regeneriert und inhaltlich verglichen,
- recoverbare Einzelvorschau in `P53_CLEANUP_PREVIEW.md` erstellt.

### Zentrale Entscheidungen

`NewEdenNexus.xcodeproj` bleibt der Kanon. Neun nummerierte Kopien und der
alte P21-Entwurf werden vor ausdrücklicher Bestätigung weder verschoben noch
gelöscht. Die Signingkonfiguration wird nicht geändert, weil
Zertifikats-OU und lokaler Teamwert bereits übereinstimmen und der
unveränderte Standardbuild besteht.

### Dateien

Neu: `Documentation/P53_CLEANUP_PREVIEW.md` und der kompakte
OFF-051-Eigentümerbericht. Geändert: betroffene UI-, Architekturtest- und
Steuerdateien. Keine Datei gelöscht oder verschoben.

### Build- und Testergebnis

10/10 fokussierte Architekturtests bestanden. Projektverifier meldet
16 Targets, acht Testtargets und zwei gemeinsame Schemes; `plutil`,
`xcodebuild -list` und der unveränderte Apple-Development-signierte
Xcode-Debugbuild bestanden.

### Erkannte Probleme und nicht erledigte Punkte

OFF-038 bleibt bis zur bestätigten recoverbaren Verschiebung teilweise.
P52 bleibt wegen der nicht ausgeführten P42-Projektzuordnungs-/Endgates
⚠️ beendet. OFF-052 ist ohne Änderung geschlossen.

### Nächster Prompt

P53 nach ausdrücklicher Bestätigung der in
`P53_CLEANUP_PREVIEW.md` beschriebenen Dateiverschiebungen fortsetzen.
## 2026-07-28 – P53: Steuerung und Xcode-Kanon

### Ausgangszustand

Neun historische Xcode-Projektkopien und ein alter P21-Entwurf lagen neben
den aktiven Kanondateien. Die Einzelvorschau war erstellt; die
Dateiverschiebung benötigte Eigentümerbestätigung.

### Ziel

Recoverbar archivieren, genau einen aktiven Xcode-Kanon absichern und die
aktuellen Steuerquellen widerspruchsfrei abschließen.

### Durchgeführte Arbeiten

Der Eigentümer bestätigte die Vorschau. Alle neun Projektkopien und der alte
P21-Entwurf wurden ohne Löschung in die dokumentierten Archive verschoben.
Ein Governance-Prüfer für Projektkanon, Promptregister und aktuelle Links
wurde ergänzt. Statusquellen wurden auf P53 abgeschlossen und P54 als
gesondert commit-freigabepflichtig gesetzt.

### Zentrale Entscheidungen

Historische Inhalte bleiben recoverbar; der aktive Kanon bleibt
`NewEdenNexus.xcodeproj`. Signing wurde nicht verändert, weil
Zertifikats-OU und lokale Teamkonfiguration übereinstimmen.

### Neu erstellte Dateien

`Scripts/verify_project_governance.py`, P53-Abschlussbericht und
dokumentierte Archivpfade.

### Geänderte Dateien

P53-Vorschau, Prompt, Steuerdokumentation sowie die bereits in OFF-051
angepasste Stationszeile und ihr Architekturtest.

### Build-Ergebnis

SwiftPM Debug und unveränderter Apple-Development-signierter Xcode Debug für
macOS arm64 erfolgreich.

### Testergebnis

668/668 SwiftPM-Tests, Projektverifier, `plutil`, `xcodebuild -list`,
Governance-/Linkprüfung und `git diff --check` bestanden.

### Erkannte Probleme

Keine durch P53 verursachte Regression. Die unabhängigen P42-/Namens-
Eigentümergates bleiben offen.

### Nicht erledigte Punkte

OFF-039/P54 benötigt eine neue ausdrückliche Commit-Freigabe; kein Push.

### Aktualisierte Features

Keine Fachfunktion; Projektsteuerung, UI-Statuswahrheit und Xcode-Kanon.

### Nächster Prompt

P54 nur nach gesonderter ausdrücklicher Commit-Freigabe.

## 2026-07-28 – P52/OFF-053: Wallet-Zuordnungsrest

### Ausgangszustand

P42-1 meldete bei der schreibfreien Zuordnungsvorschau `NEN-FIN-001`;
ausgeschöpfte Quellen blieben auswählbar und die Quellpicker hatten keinen
gültigen leeren Zustand.

### Ziel

Restkapazität vor der Vorschau sicher darstellen und den Abbruch weiterhin
garantiert schreibfrei halten.

### Durchgeführte Arbeiten

Application-Projektion für Restmenge/-betrag, gefilterte Quellauswahl,
Inline-Validierung und gültige leere Picker ergänzt. Fach-, UI- und
Abbruchregressionen hinzugefügt; Status- und Fachdokumentation aktualisiert.

### Zentrale Entscheidungen

Restkapazität bleibt deterministische Application-Logik. Erwartbare
Überbuchungen sind Formularvalidierung; unerwartete Persistenzfehler behalten
`NEN-FIN-001`. Keine produktive Zuordnung wurde geschrieben.

### Neu erstellte Dateien

`Documentation/Progress/Reports/2026-07-28_P52_OFF-053-Wallet-Zuordnungsrest.md`

### Geänderte Dateien

Wallet-Application/UI, zwei Testdateien und die betroffenen
P52-/Statusdokumente.

### Build-Ergebnis

Apple-Development-signierter Xcode Debug für macOS arm64:
`BUILD SUCCEEDED`.

### Testergebnis

9/9 Wallet-Fachtests, 1/1 UI-Vertrag und 673/673 Gesamttests bestanden.

### Erkannte Probleme

Kein technischer Blocker. Eigentümer-Retest im neuen Build fehlt.

### Nicht erledigte Punkte

P42-1 live erneut prüfen; P42-2 und Endgate wurden nicht begonnen.

### Aktualisierte Features

WAL-001, OFF-037, OFF-053 und KI-055.

### Nächster Prompt

P42-1 schreibfrei erneut ausführen.

## 2026-07-28 – P55: Projektbudgetplanung

### Ausgangszustand

Die sichtbare Wallet-Projektfinanzansicht entsprach nicht mehr dem gewünschten
Planungsmodell.

### Ziel

Benötigtes Projektbudget aus Materialeinkauf, Logistik und Produktion planen.

### Durchgeführte Arbeiten

Accountzugang zu Projektfinanzen entfernt, getrennten Budgetrechner,
Vorschau/Bestätigung, Persistenz und Schema v25 ergänzt.

### Zentrale Entscheidungen

Die wirksame Einkaufsliste ist die einzige Materialbasis. Wallet-Istdaten
bleiben erhalten, werden aber nicht mit dem Planbudget vermischt.

### Neu erstellte Dateien

Budget-Domain/Application/Persistenz, `PROJECT_BUDGET.md`, ADR-0056,
P55-Prompt und Abschlussbericht.

### Geänderte Dateien

Produktionsworkspace, App-Komposition, Migration/Backup, Tests und betroffene
Steuerdokumentation.

### Build-Ergebnis

Signierter Xcode-Debugbuild für macOS arm64: `BUILD SUCCEEDED`.

### Testergebnis

5/5 Budgettests, 2/2 Architekturprüfungen und 678/678 Gesamttests bestanden.

### Erkannte Probleme

Keine technische Regression.

### Nicht erledigte Punkte

OFF-054 Eigentümer-Sichttest.

### Aktualisierte Features

FIN-001, FIN-002, FIN-003, UI-001 und WAL-001.

### Nächster Prompt

OFF-054; P54 weiterhin nur nach gesonderter Commit-Freigabe.

## 2026-07-29 – P56: Deutsche Zahlenformatierung

### Ausgangszustand

Große sichtbare Mengen und ISK-Beträge waren uneinheitlich gegliedert.

### Ziel

Appweit lesbare deutsche Zahlenformate ohne Änderung fachlicher Werte.

### Durchgeführte Arbeiten

Zentralen UI-Formatter ergänzt und Mengen-/ISK-Ausgaben in den aktuellen
Produktions-, Lager-, Preis-, Wallet-, ESI- und Importansichten umgestellt.

### Zentrale Entscheidungen

IDs, Eingaben, Persistenz, Berechnungen und Exporte bleiben unverändert.

### Neu erstellte Dateien

ADR-0059 und P56-Zahlenformatbericht.

### Geänderte Dateien

UI-Ansichten, zwei Referenztests und betroffene Steuerdokumentation.

### Build-Ergebnis

Apple-Development-signierter Xcode Debug: `BUILD SUCCEEDED`.

### Testergebnis

2/2 Zahlenformat-Referenztests und 681/681 Gesamttests bestanden.

### Erkannte Probleme

Keine technische Regression.

### Nicht erledigte Punkte

OFF-054 Eigentümer-Sichttest.

### Aktualisierte Features

BOB-001, FIN-003 und UI-001.

### Nächster Prompt

OFF-054; P54 weiterhin nur nach gesonderter Commit-Freigabe.

## 2026-07-28 – P56: Gruppierte Build-or-Buy-Auswahl

### Ausgangszustand

Jede herstellbare Zwischenstufe musste einzeln auf Bauen oder Kaufen gesetzt
werden.

### Ziel

Ganze Produktionsarten gesammelt wählen und Einzelabweichungen erhalten.

### Durchgeführte Arbeiten

Produktion, T2/Invention und Reaktionen gruppiert; **Alle bauen**,
**Alle kaufen** und eingeklappte Einzelentscheidungen ergänzt.

### Zentrale Entscheidungen

Kategorien folgen vorhandenen Graphmerkmalen. Gruppenaktionen ändern nur den
Entwurf; der bestehende Vorschau-, Bestätigungs- und Persistenzvertrag bleibt.

### Neu erstellte Dateien

P56-Prompt, ADR-0057 und Abschlussbericht.

### Geänderte Dateien

Workspace-ViewModel/-View, fokussierte Tests und betroffene
Steuerdokumentation.

### Build-Ergebnis

Xcode Debug für macOS arm64 erfolgreich.

### Testergebnis

7/7 Build-or-Buy-, 1/1 Workspace-Architektur- und 679/679 Gesamttests
bestanden.

### Erkannte Probleme

Keine technische Regression.

### Nicht erledigte Punkte

OFF-054 Eigentümer-Sichttest.

### Aktualisierte Features

BOB-001, FIN-003 und UI-001.

### Nächster Prompt

OFF-054; P54 weiterhin nur nach gesonderter Commit-Freigabe.

## 2026-07-29 – P56: Reaktionsfilter und kompakte Auswahl

### Ausgangszustand

Reaktionen waren gemeinsam gruppiert; Einzelpicker wiederholten lange
Itembeschriftungen.

### Ziel

Drei Reaktionsarten schnell filtern und die Build-or-Buy-Bedienung
verdichten.

### Durchgeführte Arbeiten

Biochemical, Composite und Hybrid Polymer Reactions getrennt,
Produktionsart-Filter, **Alles bauen/kaufen** und kompakte Einzelzeilen
ergänzt.

### Zentrale Entscheidungen

Untergruppen verwenden ausschließlich `reactionKind`; fehlende Werte bleiben
unklassifiziert. Filter schreiben nicht, Auswahländerungen benötigen weiterhin
Vorschau und Bestätigung.

### Neu erstellte Dateien

ADR-0058 und P56-Nachkorrekturbericht.

### Geänderte Dateien

Workspace-ViewModel/-View, fokussierte Tests und betroffene
Steuerdokumentation.

### Build-Ergebnis

Apple-Development-signierter Xcode Debug für macOS arm64:
`BUILD SUCCEEDED`.

### Testergebnis

7/7 Build-or-Buy-, 1/1 Workspace-Architektur- und 679/679 Gesamttests
bestanden.

### Erkannte Probleme

Keine technische Regression.

### Nicht erledigte Punkte

OFF-054 Eigentümer-Sichttest.

### Aktualisierte Features

BOB-001 und UI-001.

### Nächster Prompt

OFF-054; P54 weiterhin nur nach gesonderter Commit-Freigabe.

## 2026-07-29 – OFF-055: SDE-Schema-Gate-Korrektur

### Ausgangszustand

Build `3.448.696` war geprüft und vorbereitet, wurde aber trotz unverändertem
CCP-Schema-Changelog mit `NEN-SDE-007-SCHEMA` abgelehnt.

### Ziel

Neue Datenbuilds zulassen, solange der passend geprüfte Changelog keinen
unverstandenen Schemawechsel enthält.

### Durchgeführte Arbeiten

Installationsvertrag, App-Composition und Abnahmerunner trennen Zielbuild,
höchsten Changelog-Eintrag und verstandenen Parserstand. Ein Regressionstest
bildet einen neueren Datenbuild bei bereits verstandenem Schema ab.

### Zentrale Entscheidungen

Ohne exakt zum Zielbuild passenden gespeicherten Metadatenstand bleibt die
Installation gesperrt. Staging, Backup, Aktivierung und Rollback bleiben
unverändert.

### Neu erstellte Dateien

Abschlussbericht `2026-07-29_OFF-055_SDE-Schema-Gate-Korrektur.md`.

### Geänderte Dateien

SDE-Installationsvertrag/-service, App-Composition, Abnahmerunner,
Installationstests und betroffene SDE-/Steuerdokumentation.

### Build-Ergebnis

Apple-Development-signierter Xcode Debug für macOS arm64:
`BUILD SUCCEEDED`.

### Testergebnis

7/7 SDE-Installationstests und 682/682 Gesamttests bestanden. Drei
Security-Framework-Tests konnten innerhalb der Dateisandbox keine RSA-Schlüssel
erzeugen und bestanden unverändert außerhalb dieser Grenze.

### Erkannte Probleme

Keine technische Regression.

### Nicht erledigte Punkte

OFF-055 reale Installation/Aktivierung von Build `3.448.696` und Neustart;
OFF-054 bleibt unabhängig offen.

### Aktualisierte Features

DAT-007 und DAT-008.

### Nächster Prompt

OFF-055 Eigentümer-Livetest; danach OFF-054.

## 2026-07-29 – PLAN-006: Produktionsbuch und Metenox-Folgeplanung

### Ausgangszustand

Die Eigentümer-Arbeitsmappe enthielt den gewünschten Arbeitsablauf für
Produktionshistorie, Kosten, Verkäufe, Walletübersicht und Metenox, während
Nexus dafür nur einzelne Planungs-, Markt-, Job- und Walletbausteine besaß.

### Ziel

Den Bedarf ohne Import privater Daten und ohne vorgezogene Fachimplementierung
in eine tragfähige, nicht doppelte Folgeplanung überführen.

### Durchgeführte Arbeiten

Alle zehn Tabellenblätter wurden schreibfrei strukturell und visuell geprüft.
Vorhandene Nexus-Verträge wurden abgeglichen. Die Fachspezifikation,
ADR-0060, PLAN-006 und die ausführbaren Folgeprompts P57 bis P61 wurden
erstellt; OFF-056 und OFF-057 halten die notwendigen Restbefunde fest.

### Zentrale Entscheidungen

Projektplan, Produktionscharge, Kostenbeleg und Verkauf bleiben getrennt.
Kosten je Unit verwenden die tatsächliche Ausgabemenge. ESI-Zuordnungen
bleiben bestätigungsgebunden. Metenox-Regeln erhalten sichtbare Versionen und
werden unmittelbar vor ihrer Implementierung erneut offiziell geprüft.

### Neu erstellte Dateien

Fachspezifikation, ADR-0060, PLAN-006, P57 bis P61 und Abschlussbericht.

### Geänderte Dateien

Nur die betroffenen Planungs-, Architektur- und Steuerdokumente.

### Build-Ergebnis

Nicht erforderlich: keine Swift-, Xcode-, Schema- oder Datenänderung.

### Testergebnis

Workbook-Struktur und alle zehn gerenderten Tabellenblätter geprüft;
Governance-, Link- und Diff-Prüfung gemäß Abschlussbericht.

### Erkannte Probleme

Die Excel-Formel für Kosten pro Unit teilt durch Runs statt durch tatsächliche
Units. Metenox-Verbrauchswerte sind vor P61 vollständig offiziell zu
verifizieren.

### Nicht erledigte Punkte

Zum Zeitpunkt der PLAN-006-Erstspezifikation waren OFF-055 und OFF-054
vorgelagert. OFF-055 wurde anschließend abgeschlossen; OFF-054 bleibt offen.
P57 bis P61 sind spezifiziert, aber nicht implementiert. P54 bleibt separat
freigabepflichtig.

### Aktualisierte Features

FIN-004 bis FIN-007 und IND-001 als geplant aufgenommen.

### Nächster Prompt

OFF-055 Eigentümer-Livetest, danach OFF-054; anschließend P57 nur auf
ausdrücklichen Auftrag.

## 2026-07-29 – PLAN-006: Ausführungsprompts und Preisquellen

### Ausgangszustand

P57 bis P61 waren geordnet, aber für eine eigenständige spätere Ausführung
noch zu knapp. Preise sollten bevorzugt live aus Jita oder einer änderbaren
benannten Marktquelle stammen.

### Ziel

Alle fünf Prompts ausführbar machen und einen gemeinsamen, sichtbaren
Preisquellenvertrag festlegen.

### Durchgeführte Arbeiten

P57 bis P61 wurden um Domänenumfang, Datenwirkung, UI-Ablauf, Preisrollen,
Fallbacks, Tests und messbare Abnahmen erweitert. `MARKET_PRICES.md` und die
Fachspezifikation enthalten nun dieselbe verbindliche Preispriorität.

### Zentrale Entscheidungen

Jita ist nur Standard, nicht Zwang. Live-ESI und Caches bleiben
quellenidentisch; manuell/CSV ist ein ausdrücklicher Fallback. Reale
Walletwerte und Marktprognosen werden nie vermischt.

### Neu erstellte Dateien

Abschlussbericht zur PLAN-006-Spezifikationsnachkorrektur.

### Geänderte Dateien

P57–P61, Marktpreis- und Produktionsbuchspezifikation sowie
Steuerdokumentation.

### Build-Ergebnis

Nicht erforderlich: reine Dokumentationsänderung.

### Testergebnis

Promptlängen, Governance, Xcode-Projektkonsistenz und Diff geprüft.

### Erkannte Probleme

Buy-Order-Bewertung ist noch nicht implementiert und bleibt bis zu einem
expliziten Marktvertrag `nicht verfügbar`.

### Nicht erledigte Punkte

P57–P61 sind nicht implementiert; OFF-054 bleibt vorgelagert.

### Aktualisierte Features

FIN-004 bis FIN-007 und IND-001 präzisiert.

### Nächster Prompt

OFF-055 abschließen, anschließend OFF-054.

## 2026-07-29 – OFF-055: SDE-Eigentümer-Liveabnahme

### Ausgangszustand

Der technische Pfad war grün; reale Aktivierung und Neustart waren offen.

### Ziel

Aktiven Build `3.448.696`, vollständiges Journal, Neustart und Rollbackversion
real nachweisen.

### Durchgeführte Arbeiten

Appstatus geprüft, App beendet und erneut gestartet. Installationsjournal,
laufender Prozess, SQLite-Integrität, aktive Version und Backupbestand wurden
schreibfrei kontrolliert.

### Zentrale Entscheidungen

Keine erneute Installation ausgeführt, weil Build `3.448.696` bereits sicher
aktiv war. Der fehlende Nachweis war ausschließlich der Neustart.

### Neu erstellte Dateien

Abschlussbericht `2026-07-29_OFF-055_Eigentuemer-Liveabnahme.md`.

### Geänderte Dateien

Nur betroffene Steuer- und Nachweisdokumentation.

### Build-Ergebnis

Kein neuer Build; der abgenommene Apple-Development-Debugbuild wurde real neu
gestartet.

### Testergebnis

Journal `completed`, Backup/Cleanup erfolgreich, `quick_check: ok`, aktiver
Build nach Neustart `3.448.696`, Vorgänger inaktiv erhalten.

### Erkannte Probleme

Die externe macOS-Bedienbrücke verlor nach App-Quit ihre Pipe; Prozess- und
Datenbanknachweis waren davon unabhängig. Kein Nexus-Fehler.

### Nicht erledigte Punkte

OFF-054.

### Aktualisierte Features

DAT-007 und DAT-008 real abgenommen; KI-058 geschlossen.

### Nächster Prompt

OFF-054 Eigentümer-Sichttest.

## 2026-07-29 – OFF-054: Eigentümer-Sichttest

### Ausgangszustand

P55/P56 waren technisch grün; die sichtbare Eigentümerkontrolle war offen.

### Ziel

Build-or-Buy-Gruppierung, Budgetdarstellung und deutsche Zahlenformatierung
im lokalen Betrieb prüfen.

### Durchgeführte Arbeiten

Aktuellen signierten Debugbuild erstellt, drei Gruppen-/Formatregressionen
erneut ausgeführt und den Eigentümerbefund ausgewertet. Der Eigentümer
bestätigte OFF-054 als bestanden und die sichtbare Punktgruppierung.

### Zentrale Entscheidungen

Die gesperrte Preisübernahme ohne Ziel-Preissatz bleibt fail-closed. Der
fehlende verständliche Anlage-/Auswahlweg ist getrennt als OFF-058/KI-059
P58 zugeordnet; P57 wurde nicht begonnen.

### Neu erstellte Dateien

Abschlussbericht `2026-07-29_OFF-054_Eigentuemer-Sichttest.md`.

### Geänderte Dateien

Nur betroffene Steuer-, Nachweis- und P58-Promptdokumentation.

### Build-Ergebnis

Apple-Development-signierter Xcode-Debugbuild: `BUILD SUCCEEDED`.

### Testergebnis

3/3 fokussierte Gruppen-/Formatregressionen bestanden; letzter vollständiger
Projektlauf 682/682 in OFF-055.

### Erkannte Probleme

Ohne vorhandenen Ziel-Preissatz kann die eingebettete ESI-Preisvorschau nicht
übernommen werden; das Budget bleibt dann wegen fehlender Preise unvollständig.

### Nicht erledigte Punkte

OFF-058/KI-059 in P58; P57 bis P61 nicht begonnen.

### Aktualisierte Features

BOB-001 und UI-001 sichtbar abgenommen; FIN-003 mit OFF-058 präzisiert.

### Nächster Prompt

P57 nur auf ausdrücklichen Auftrag.

## 2026-07-29 – P57: Produktionsbuch-Domäne und Persistenz

### Ausgangszustand

Projekte, Produktionsgraphen und optionale ESI-Industry-Jobs waren vorhanden,
aber tatsächliche Produktionschargen besaßen weder eigene Domäne noch
Persistenz oder native Arbeitsansicht.

### Ziel

Unveränderliche Chargen getrennt vom Plan, mit Vorschau-vor-Schreiben,
Jahresnummer, Quellenbindung, Schema v26 und verständlicher Oberfläche.

### Durchgeführte Arbeiten

Domänenmodell, Managementservice, ESI-Job-Vorbelegung,
SwiftData-Repository, additive v25→v26-Migration, Jahreszähler,
Backup-/Restore-Kompatibilität und das native Modul **Produktionsbuch**
umgesetzt. Tabelle und Detailansicht filtern nach Jahr, Status, Projekt,
Charakter, Produkt und Ort. Stale Projekt-, Graph-, Katalog- und Jobstände
werden vor dem Schreiben abgelehnt.

### Zentrale Entscheidungen

Projektplan und tatsächliche Charge bleiben getrennt. Eine Charge bindet
Projekt-, Graph-, Regel- und SDE-Versionen. Unbekannte Namen bleiben `nil`;
historische Chargen werden bei der Migration nicht erfunden. ADR-0060 wurde
akzeptiert.

### Neu erstellte Dateien

Produktionsbatch-Domäne, Managementservice, Schema v26, SwiftData-Repository,
Ledger-View/ViewModel und zugehörige Tests.

### Geänderte Dateien

App-Komposition/Navigation, Migration/Backup, Xcode-Projekt sowie betroffene
Architektur-, Datenmodell-, Status- und Testdokumentation.

### Build-Ergebnis

SwiftPM Debug und Apple-Development-signierter Xcode Debug:
`BUILD SUCCEEDED`.

### Testergebnis

27/27 fokussierte P57-/Architekturtests sowie 695/695 vollständige
SwiftPM-Tests bestanden. Migration, parallele Nummernvergabe, Abbruch,
Wiederöffnung und Backup/Restore sind enthalten.

### Erkannte Probleme

Keine neue technische Regression. Der reale Eigentümer-Neustarttest ist noch
nicht ausgeführt.

### Nicht erledigte Punkte

OFF-059: Charge speichern, App vollständig beenden, neu starten und
unverändert öffnen. P58/OFF-058 wurden nicht begonnen.

### Aktualisierte Features

FIN-004 technisch umgesetzt; OFF-056 teilweise erfüllt.

### Nächster Prompt

OFF-059 Eigentümerabnahme für P57; danach P58 nur auf ausdrücklichen Auftrag.

## 2026-07-29 – OFF-059: P57-Eigentümer-Neustarttest

### Ausgangszustand

P57 war technisch grün; der reale Speichern-/Prozessende-/Neustartnachweis
fehlte.

### Ziel

Eine Produktionscharge real bestätigen, speichern und nach vollständigem
App-Neustart unverändert wieder öffnen.

### Durchgeführte Arbeiten

Der erste Lauf fand einen Bestätigungsdialog hinter der modalen
Erfassungsansicht. Der Dialog wurde in diese Ansicht verschoben und sein
Bestätigungsknopf mit `productionLedger.confirmBatch` prüfbar gemacht.
Anschließend wurde Charge `2026-0001` für Rhea in UALX-3 gespeichert, die App
vollständig beendet und dieselbe Charge nach Neustart unverändert geöffnet.

### Zentrale Entscheidungen

Keine Fach- oder Schemaveränderung; ausschließlich eng begrenzte
Dialogplatzierung und Accessibility-Kennung. Der reale Chargendatensatz bleibt
als Eigentümer-Abnahmenachweis lokal erhalten.

### Neu erstellte Dateien

Abschlussbericht `2026-07-29_OFF-059_P57-Eigentuemer-Neustarttest.md`.

### Geänderte Dateien

`ProductionLedgerView.swift`, zugehöriger Architekturtest und betroffene
Status-, Feature-, Prompt- und Testdokumentation.

### Build-Ergebnis

Apple-Development-signierter Xcode Debug: `BUILD SUCCEEDED`.

### Testergebnis

24/24 fokussierte Tests und 695/695 vollständige SwiftPM-Tests bestanden;
realer Neustarttest bestanden.

### Erkannte Probleme

Der modale Bestätigungsdialog war zunächst verdeckt; behoben und
regressionsgeprüft.

### Nicht erledigte Punkte

OFF-058/KI-059 bleibt P58 zugeordnet. P58 wurde nicht begonnen.

### Aktualisierte Features

FIN-004 und P57 auf `✅`; OFF-059 geschlossen.

### Nächster Prompt

P58 nur auf ausdrücklichen Auftrag.

## 2026-07-29 – P58: Produktionskosten und Preisvorschläge

### Ausgangszustand

P57-Chargen, Projektbudgets, Preissätze und P41-Marktquotes waren vorhanden.
Eine unveränderliche chargengebundene Kostenbasis fehlte; OFF-058 blockierte
die Preisübernahme ohne bereits vorhandenen Ziel-Preissatz.

### Ziel

Typisierte Chargenkosten, nachvollziehbare Jita-/Alternativmarktquotes und
deterministische Stückkosten- und Preisvorschläge bereitstellen.

### Durchgeführte Arbeiten

- Kosten-/Quote-Domäne und Application-Service mit Preview/Confirm/Stale-Schutz,
- Schema v27 und Repository für unveränderliche Kostensnapshots,
- Produktionsbuch-UI für Kostenzeilen, Märkte, Kennzahlen und Bestätigung,
- eingebettete Ziel-Preissatz-Anlage/-Auswahl mit Budgetneuberechnung,
- Migration, Backupgrenze, Tests, Xcode-Projektkanon und Dokumentation.

### Zentrale Entscheidungen

Unbekannte Kosten bleiben unbekannt. Jita und Alternativmarkt verwenden den
bestehenden P41-Sell-Quote-Vertrag. Manuelle/CSV-Werte wirken nur nach
ausdrücklicher Fallbackauswahl. BPO-Anschaffung wird nicht automatisch voll
amortisiert.

### Neu erstellte Dateien

Chargenkosten-Domäne/-Service/-Persistenz, Schema v27, ADR-0061 und vier
P58-Testdateien.

### Geänderte Dateien

Produktionsbuch-, Marktpreis-, Composition-, Migrations-, Backup-, Xcode- und
Steuerdokumente.

### Build-Ergebnis

SwiftPM-Build im Testlauf und Apple-Development-signierter Xcode-Debugbuild
erfolgreich.

### Testergebnis

37/37 fokussierte Tests und 704/704 vollständige SwiftPM-Tests bestanden.

### Erkannte Probleme

Kein technischer Fehler offen. Der reale Sichttest mit Jita und geänderter
Marktquelle fehlt.

### Nicht erledigte Punkte

OFF-060 Eigentümer-Sichttest; P59 wurde nicht begonnen.

### Aktualisierte Features

FIN-003 ist technisch geschlossen; FIN-005 ist technisch umgesetzt und wartet
auf OFF-060. OFF-056 bleibt für P59/P60 teilweise.

### Nächster Prompt

OFF-060 – P58-Eigentümer-Sichttest; danach P59 nur auf ausdrücklichen Auftrag.

## 2026-07-29 – OFF-060: Eigentümer-Sichttest vorbereitet

### Ausgangszustand

Der technische P58-Stand war grün, die Ansicht zeigte jedoch Quoteherkunft,
Zeitstand, Marge und ROI nicht ausreichend sichtbar.

### Ziel

Den realen Jita-/Alternativmarkt-Test verständlich und prüfbar vorbereiten.

### Durchgeführte Arbeiten

Quoteherkunft, Beobachtungszeit, Mengenabdeckung, Orders, Preisregel,
Cacheablauf, Marge und ROI in der Kostenvorschau ergänzt; Architekturtest
geschärft.

### Zentrale Entscheidungen

Keine Daten automatisch geschrieben. OFF-060 bleibt bis zur Bestätigung des
Eigentümers offen.

### Neu erstellte Dateien

Abschlussbericht zur OFF-060-Vorbereitung.

### Geänderte Dateien

Produktionsbuch-UI, Architekturtest und betroffene Nachweisdokumentation.

### Build-Ergebnis

Apple-Development-signierter Xcode-Debugbuild erfolgreich.

### Testergebnis

18/18 fokussierte Tests bestanden; vorheriger P58-Gesamtlauf 704/704.

### Erkannte Probleme

Die macOS-Steuerverbindung dieser Codex-Sitzung schloss vor der
App-Zustandsabfrage; der reale Eigentümerlauf wurde nicht simuliert.

### Nicht erledigte Punkte

Jita und eine geänderte Marktquelle sichtbar prüfen, Vorschau verwerfen und
erst nach ausdrücklicher Bestätigung speichern.

### Aktualisierte Features

FIN-005 bleibt `⚠️` bis zum Eigentümernachweis.

### Nächster Prompt

OFF-060 abschließen; danach P59 nur auf ausdrücklichen Auftrag.

## 2026-07-29 – OFF-060: Eigentümerabnahme abgeschlossen

### Ausgangszustand

Technik, fokussierte Tests und Xcode-Build waren bestanden; nur die
Eigentümerbestätigung fehlte.

### Ziel

Den sichtbaren Jita-/Alternativmarkt-Nachweis abschließen.

### Durchgeführte Arbeiten

Ausdrückliche Eigentümerbestätigung dokumentiert und P58, OFF-060 sowie
FIN-005 konsistent abgeschlossen.

### Zentrale Entscheidungen

Die Eigentümerabnahme wird als eigene Evidenzebene geführt. P59 startet nicht
automatisch.

### Neu erstellte Dateien

Abschlussbericht `2026-07-29_OFF-060_Eigentuemerabnahme.md`.

### Geänderte Dateien

Nur betroffene Steuer-, Status-, Test- und Abnahmedokumentation.

### Build-Ergebnis

Kein neuer Build erforderlich; letzter signierter OFF-060-Debugbuild
erfolgreich.

### Testergebnis

Keine erneute Ausführung; 18/18 OFF-060-fokussiert und vorher 704/704
vollständig bestanden.

### Erkannte Probleme

Keine neue Regression gemeldet.

### Nicht erledigte Punkte

OFF-060 besitzt keine Restarbeit. OFF-056 bleibt für P59/P60 teilweise.

### Aktualisierte Features

P58 und FIN-005 auf `✅`, OFF-060 auf erledigt.

### Nächster Prompt

P59 nur auf ausdrücklichen Auftrag.

## 2026-07-29 – P59: Wallet-Verkaufszuordnung und Realgewinn

### Ausgangszustand

P57-Chargen, unveränderliche P58-Kostensnapshots und erhaltene
P42-Wallet-/Projektzuordnungen waren vorhanden. Eine chargengebundene
Verkaufs- und Gebührenzuordnung mit Realgewinn fehlte.

### Ziel

Bestätigte Projektkapazität ohne Doppelzählung auf Chargen unterteilen und
verkaufte/offene Units, Durchschnittspreis und Realgewinn nachvollziehbar
berechnen.

### Durchgeführte Arbeiten

- zentraler deterministischer Verkaufserfolgsrechner,
- Application-Service mit schreibfreier Vorschau, Bestätigung, Stale- und
  Quellkapazitätsschutz,
- Schema v28 und SwiftData-Repository mit Migration, Backup- und
  Wiederöffnungsprüfung,
- Produktionsbuch-UI für Wallet-/manuelle Verkäufe und Gebühren,
- Regressionstests für Teil-/Vollverkauf, Verwerfen, Offlinebestand,
  Doppelzuordnung, Überverkauf und Recovery,
- v28-Erkennung im Migrations-Backup-Inspector nach Volltestbefund ergänzt.

### Zentrale Entscheidungen

Die bestätigte Projektzuordnung bleibt Eigentümer der Wallet-Quellkapazität.
Marktquotes und offene Orders bleiben Prognosen. Die erste Zuordnung bindet
eine Charge dauerhaft an genau einen Kostensnapshot.

### Neu erstellte Dateien

P59-Domäne, Application-Service, Schema v28, Repository, vier Testdateien,
ADR-0062 und Abschlussbericht.

### Geänderte Dateien

Produktionsbuch-UI/-Composition, Migration/Backup, Xcode-Projekt und betroffene
Steuer- und Fachdokumentation.

### Build-Ergebnis

Unsigned Xcode Debug erfolgreich. Der normale lokale signierte Build ist durch
eine nicht mehr vorhandene Zertifikatsreferenz in der persönlichen
`LocalSigning.xcconfig` blockiert; keine Signing-Einstellung wurde geändert.

### Testergebnis

15/15 fokussierte P59-/Migration-/Recovery-Tests und 713/713 vollständige
SwiftPM-Tests bestanden. Der erste Sandboxlauf konnte drei bestehende
SecKey-JWT-Tests nicht ausführen; außerhalb der Security-Sandbox waren alle
713 Tests grün.

### Erkannte Probleme

KI-060 blockiert den signierten Eigentümerbuild. Kein P59-Codefehler offen.

### Nicht erledigte Punkte

OFF-061: reale Teil-/Vollzuordnung, Vorschau-Verwerfen, Gebühr und identischer
Stand nach App-Neustart.

### Aktualisierte Features

FIN-006 technisch umgesetzt; OFF-037/OFF-053 in den neuen Chargenvertrag
überführt; OFF-056 bleibt bis P60 teilweise.

### Nächster Prompt

OFF-061 nach Wiederherstellung der lokalen Signierung. P60 beginnt erst danach
und nur auf ausdrücklichen Auftrag.

## 2026-07-29 – KI-060/OFF-061: Signierung und Eigentümergate

### Ausgangszustand

P59 war technisch grün; der normale signierte Build und der reale
Eigentümerlauf waren offen.

### Ziel

Lokale Signierung verifizieren und OFF-061 im aktuellen kanonischen Build
vorbereiten.

### Durchgeführte Arbeiten

- gültige Apple-Development-Identität und Team-OU gegen die lokalen
  Xcode-Werte geprüft,
- normalen signierten arm64-Debugbuild ausgeführt und die fertige App strikt
  verifiziert,
- alte P39-/P40-Buildkopien nur aus LaunchServices ausgetragen,
- kanonischen Xcode-Build mit produktivem v28-Store gestartet.

### Zentrale Entscheidungen

Keine Signingdatei ändern, weil Identität und Team bereits korrekt sind.
Produktive Verkaufszuordnungen bleiben an sichtbare Vorschau und ausdrückliche
Eigentümerbestätigung gebunden.

### Neu erstellte Dateien

Zwischenbericht zu KI-060.

### Geänderte Dateien

Nur betroffene Steuer- und Nachweisdokumentation.

### Build-Ergebnis

Apple-Development-signierter arm64-Xcode-Debugbuild erfolgreich; strikte
Codesignaturprüfung bestanden.

### Testergebnis

Keine Codeänderung; P59-Nachweis bleibt 15/15 fokussiert und 713/713
vollständig. Zusätzlich realer Start des kanonischen Builds ohne
`NEN-PER-001`.

### Erkannte Probleme

Computersteuerung wählte zunächst alte, gleich gebündelte Buildkopien. Diese
wurden nicht gelöscht, sondern nur aus LaunchServices ausgetragen.

### Nicht erledigte Punkte

OFF-061: Teilzuordnung, Verwerfen, Gebühr, Vollzuordnung und Neustart durch den
Eigentümer.

### Aktualisierte Features

FIN-006: Signingblocker geschlossen; Eigentümergate läuft.

### Nächster Prompt

OFF-061 abschließen; P60 beginnt nicht automatisch.

## 2026-07-29 – OFF-061: Wallet-Nachweise und realer Ausgangsstand

### Ausgangszustand

KI-060 war geschlossen. Im produktiven v28-Store lagen eine Charge mit nur
einer Output-Unit sowie keine Kostenbasis, Wallet-Projekt- oder
Verkaufszuordnung vor.

### Ziel

Den notwendigen, bestätigungsgebundenen Wallet-Nachweisweg für den sichtbaren
OFF-061-Lauf bereitstellen, ohne die alte Projektfinanzen-Oberfläche
zurückzubringen oder produktive Werte zu erfinden.

### Durchgeführte Arbeiten

- read-only Ausgangszahlen geprüft,
- **Wallet-Nachweise zuordnen** in der Accountansicht ergänzt,
- vorhandenen Wallet-Vorschau-/Bestätigungsdialog auf Nachweise begrenzt,
- Architekturgrenze und P59-/Walletregressionen geprüft.

### Zentrale Entscheidungen

Keine automatische Zuordnung und keine erfundenen Werte. Teilzuordnung,
Verwerfen, Gebühr, Vollzuordnung und Neustart bleiben Eigentümerhandlungen.

### Neu erstellte Dateien

OFF-061-Vorbereitungsbericht.

### Geänderte Dateien

Account-/Wallet-Nachweisansicht, Architekturtest und betroffene
Statusdokumentation.

### Build-Ergebnis

Apple-Development-signierter arm64-Xcode-Debugbuild erfolgreich; strikte
Signaturprüfung bestanden.

### Testergebnis

19/19 fokussierte Architektur-, Wallet- und P59-Tests bestanden. Der
unveränderte P59-Gesamtnachweis bleibt 713/713.

### Erkannte Probleme

Für den realen Gate-Ablauf fehlen noch eine Charge mit mindestens zwei
Output-Units, ihre bestätigte P58-Kostenbasis und bestätigte
Wallet-Verkaufs-/Gebührenkapazität.

### Nicht erledigte Punkte

OFF-061-Eigentümerhandlungen und Neustart.

### Aktualisierte Features

FIN-006 bleibt technisch umgesetzt und betrieblich teilweise.

### Nächster Prompt

OFF-061 sichtbar abschließen; P60 beginnt nicht automatisch.

## 2026-07-30 – OFF-061: historische Chargenbasis geklärt

- read-only nachgewiesen: `2026-0001` bindet ältere Rhea-Projekt-/Graphstände
  und besitzt nur eine Output-Unit,
- die fachlich notwendige Stale-Sperre bleibt erhalten,
- die Fehlermeldung erklärt nun den sicheren Weg über aktuellen Projekt-,
  Graph- und Budgetstand sowie eine neue Charge,
- 2/2 fokussierte Tests und Apple-Development-signierter Xcode-Debugbuild
  bestanden,
- alle älteren parallelen App-Prozesse wurden normal beendet; ausschließlich
  der aktuelle OFF-061-Build läuft,
- keine produktiven Projekt-, Chargen-, Kosten- oder Walletdaten verändert.

## 2026-07-30 – KI-062: Graphresolver und veröffentlichte Rezepte

### Ausgangszustand

`Module für DOC` meldete beim Aktualisieren des Produktionsgraphen
`NEN-GRAPH-001`.

### Ziel

Den Fehler mit realem Datenstand reproduzieren und ohne Änderung produktiver
Benutzerdaten beheben.

### Durchgeführte Arbeiten

- aktuellen Xcode-Laufstore ausschließlich in eine temporäre Diagnosekopie
  gesichert,
- Fehler auf Type 16672 und die Blueprintkandidaten 45732/46207 eingegrenzt,
- implizite Auswahl auf veröffentlichte Kandidaten begrenzt,
- explizite Blueprint-Auswahl gegen Substitution abgesichert,
- Resolver-, Graph-, Persistenz- und T2-Regressionen ergänzt beziehungsweise
  ausgeführt.

### Zentrale Entscheidungen

Nur die offizielle `published`-Eigenschaft priorisiert Kandidaten. Echte
Mehrdeutigkeit bleibt fail-closed; explizite Auswahl wird nie ersetzt.

### Neu erstellte Dateien

- `Documentation/Architecture/ADRs/ADR-0063_Eindeutige-veroeffentlichte-Rezeptauswahl.md`
- `Documentation/Progress/Reports/2026-07-30_KI-062_Graphresolver-veroeffentlichte-Rezepte.md`

### Geänderte Dateien

Resolver, Resolvertests sowie betroffene Status-, Architektur- und
Testdokumentation.

### Build-Ergebnis

Apple-Development-signierter arm64-Xcode-Debugbuild: `BUILD SUCCEEDED`.

### Testergebnis

44/44 fokussierte Tests bestanden; reale temporäre Storekopie erzeugt
566 Knoten und 565 Kanten.

### Erkannte Probleme

Kein verbleibender technischer Graphblocker reproduziert.

### Nicht erledigte Punkte

Sichtbarer Eigentümer-Retest im neu gestarteten Xcode-Lauf; anschließend
OFF-061 fortsetzen.

### Aktualisierte Features

DAT-011 Rezeptresolver und Produktionsgraph.

### Nächster Prompt

Kein neuer Prompt: KI-062 sichtbar bestätigen, dann OFF-061 fortführen.

## 2026-07-30 – KI-062: Eigentümer-Retest bestanden

### Ausgangszustand

Die technische Korrektur war nachgewiesen; der sichtbare App-Retest stand
noch aus.

### Ziel

Bestätigen, dass der Produktionsgraph im neu gebauten realen App-Lauf wieder
erzeugt werden kann.

### Durchgeführte Arbeiten

Eigentümermeldung als getrennten Betriebsnachweis dokumentiert und KI-062 in
Status-, Problem-, Feature- und Berichtsdokumentation geschlossen.

### Zentrale Entscheidungen

Keine erneute technische Prüfung behauptet: Der vorhandene Build-/Testnachweis
und die neue Eigentümerbestätigung bleiben getrennte Evidenzstufen.

### Neu erstellte Dateien

`Documentation/Progress/Reports/2026-07-30_KI-062_Eigentuemer-Retest.md`

### Geänderte Dateien

Nur betroffene Steuer- und Nachweisdokumentation.

### Build-Ergebnis

Nicht erneut ausgeführt; unverändert `BUILD SUCCEEDED`.

### Testergebnis

Keine automatisierten Tests erneut ausgeführt; zuvor 44/44 bestanden.
Eigentümerbetrieb: Produktionsgraph lässt sich wieder erzeugen.

### Erkannte Probleme

Keine offene KI-062-Wirkung.

### Nicht erledigte Punkte

OFF-061 bleibt getrennt in Bearbeitung.

### Aktualisierte Features

DAT-011 vollständig technisch und sichtbar bestätigt.

### Nächster Prompt

OFF-061 fortsetzen; P60 beginnt nicht automatisch.

## 2026-07-30 – KI-063: Sichtbare Budgetkosten-Beschriftungen

### Ausgangszustand

Logistik- und Produktionskosten waren nur über Textfeld-Platzhalter bezeichnet.

### Ziel

Beide Budgeteingaben dauerhaft und unmittelbar verständlich beschriften.

### Durchgeführte Arbeiten

Je Eingabe eine sichtbare Bezeichnung vor dem Betrag und eine eigene
`ISK`-Einheit ergänzt; Architekturregression erweitert.

### Zentrale Entscheidungen

Keine Änderung an Budgetmodell, Bindings, Validierung oder Berechnung.

### Neu erstellte Dateien

`Documentation/Progress/Reports/2026-07-30_KI-063_Budgetkosten-Beschriftungen.md`

### Geänderte Dateien

Budget-View, fokussierter Architekturtest und betroffene Nachweisdokumentation.

### Build-Ergebnis

SwiftPM Debug und Apple-Development-signierter arm64-Xcode-Debugbuild
erfolgreich.

### Testergebnis

1/1 fokussierter Architekturtest bestanden.

### Erkannte Probleme

Keine neue Codewirkung; sichtbare Eigentümerbestätigung folgt im nächsten Lauf.

### Nicht erledigte Punkte

OFF-061 bleibt in Bearbeitung.

### Aktualisierte Features

FIN-003.

### Nächster Prompt

OFF-061 fortsetzen; P60 beginnt nicht automatisch.

## 2026-07-30 – KI-064: Vereinfachte Chargenerfassung

### Ausgangszustand

Eine technische Sonnensystem-ID blockierte die Charge; optionale ESI- und
ID-Felder dominierten den Hauptablauf.

### Ziel

Charge aus Projektwerten erfassen und Zusatzprovenienz nur bei Bedarf zeigen.

### Durchgeführte Arbeiten

Ortszwang entfernt, Formular gruppiert, technische Felder eingeklappt und
fehlende Zusatzwerte als schreibfreien Hinweis dargestellt.

### Zentrale Entscheidungen

Keine Werte erfinden; Vorschau und ausdrückliche Bestätigung beibehalten.

### Neu erstellte Dateien

`Documentation/Progress/Reports/2026-07-30_KI-064_Vereinfachte-Chargenerfassung.md`

### Geänderte Dateien

Chargenservice, Produktionsbuch-UI, Tests, ADR und betroffene Statusdokumente.

### Build-Ergebnis

Apple-Development-signierter arm64-Xcode-Debugbuild erfolgreich.

### Testergebnis

6/6 fokussiert bestanden; Vollsuite 706/716 mit zehn nicht verursachten
Altfehlern.

### Erkannte Probleme

Keine neue Codewirkung.

### Nicht erledigte Punkte

Vereinfachten Ablauf sichtbar prüfen; OFF-061 danach fortsetzen.

### Aktualisierte Features

FIN-004.

### Nächster Prompt

OFF-061 fortsetzen; P60 beginnt nicht automatisch.

## 2026-07-30 – KI-064: Eigentümer-Sichttest bestanden

### Ausgangszustand

KI-064 war technisch bestanden; die sichtbare Bestätigung fehlte.

### Ziel

Vereinfachte Chargenerfassung im realen App-Lauf bewerten.

### Durchgeführte Arbeiten

Eigentümerbestätigung getrennt vom technischen Nachweis dokumentiert.

### Zentrale Entscheidungen

Keine erneute technische Prüfung behauptet.

### Neu erstellte Dateien

Keine.

### Geänderte Dateien

Nur betroffene Steuer- und Nachweisdokumentation.

### Build-Ergebnis

Nicht erneut ausgeführt; zuvor `BUILD SUCCEEDED`.

### Testergebnis

Keine automatisierten Tests erneut ausgeführt; zuvor 6/6 fokussiert.
Eigentümer-Sichttest bestanden.

### Erkannte Probleme

Keine offene KI-064-Wirkung.

### Nicht erledigte Punkte

OFF-061-Kostenbasis und Verkaufszuordnungen.

### Aktualisierte Features

FIN-004 sichtbar bestätigt.

### Nächster Prompt

OFF-061 fortsetzen; P60 beginnt nicht automatisch.
