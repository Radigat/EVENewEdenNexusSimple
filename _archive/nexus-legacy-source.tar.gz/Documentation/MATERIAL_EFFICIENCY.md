# Material Efficiency

Stand: 2026-07-24 · P15

## Zweck und Umfang

P15 berechnet für jede Materialposition der aktuell vorhandenen Rezeptstufe
den Rohbedarf, den durch Blueprint-Materialeffizienz reduzierten Bedarf und
die Ersparnis. Die Berechnung ist zentral, UI-unabhängig, deterministisch,
versioniert und verwendet ausschließlich Ganzzahlen.

P15 bildet ausschließlich Blueprint-ME für Fertigungsrezepte ab. Reaktionen
erhalten keinen Blueprint-ME-Wert. Anlagen-, Rig-, Skill-, Rollen- oder
sonstige Jobmodifikatoren, rekursive Produktionsketten und die Aggregation
gleicher Materialien gehören nicht zu P15.

## Verbindliche Quellen und Regel

Geprüft am 2026-07-24:

- [CCP – Material Efficiency Research](https://support.eveonline.com/hc/en-us/articles/203210542-Material-Efficiency-Research)
- [CCP – Blueprints](https://support.eveonline.com/hc/en-us/articles/203269951-Blueprints)
- [CCP – Static Data](https://developers.eveonline.com/docs/services/static-data/)

CCP beschreibt ME als Prozentreduktion des Materialbedarfs, die auf den
gesamten Job angewendet und anschließend auf die nächste ganze Einheit
aufgerundet wird. Eine Materialposition mit der Basismenge eins je Run darf
dabei nicht unter eine Einheit je Run fallen.

## Ganzzahlige Formel

Für positive Basismenge `B`, positive Runzahl `R` und ganzzahlige
Blueprint-ME `M` von 0 bis 10 gilt:

```text
Rohbedarf = B × R

wenn B == 1:
    Effektivbedarf = Rohbedarf
sonst:
    Zähler = Rohbedarf × (100 − M)
    Effektivbedarf = Zähler / 100
                     + (Zähler % 100 == 0 ? 0 : 1)

Ersparnis = Rohbedarf − Effektivbedarf
```

Die Multiplikationen werden auf `Int64`-Überlauf geprüft. Die Rundung
geschieht genau einmal über den gesamten Job. Fließkommawerte und
Run-für-Run-Rundung werden nicht verwendet.

Für Reaktionen ist `M` verbindlich null; Rohbedarf und Effektivbedarf sind
identisch.

## Domainmodell

`ProductionMaterialCalculation` enthält:

- Formelversion,
- Aktivität,
- Basismenge je Run,
- benötigte Runs,
- Blueprint-ME,
- Rohbedarf,
- Effektivbedarf,
- Ersparnis.

Der öffentliche Initialisierer berechnet alle abgeleiteten Werte. Beim
Decodieren werden sie erneut berechnet und mit dem Payload verglichen.
Unbekannte Formelversionen, ungültige Eingaben, nicht unterstützte
Reaktions-ME, Überläufe und manipulierte Payloads scheitern typisiert.

## Projekt, Graph und Persistenz

Das Produktionsprojekt speichert ME als ganze Zahl von 0 bis 10. Alte
Projekte erhalten bei der Migration den neutralen Wert 0. Beim Wechsel auf
eine Reaktion setzt die UI den Wert sichtbar auf 0; Domain und Persistenz
lehnen widersprüchliche Werte zusätzlich ab.

Graphformat 3 ergänzt:

- `blueprintMaterialEfficiency` als Projektprovenienz,
- `materialCalculation` an jeder Materialkante.

Graphformat 1 und 2 bleiben lesbar, enthalten keine erfundenen ME-Werte und
gelten als veraltet. Das Laden validiert Basismenge, Runs, Aktivität,
ME-Wert sowie die gespeicherten Formelmetadaten gegeneinander.

Schema v8 ergänzt:

- `ProductionProject.materialEfficiency`,
- `ProductionGraphRecord.materialFormulaVersion`.

Beide Felder sind für die leichtgewichtige v7→v8-Migration optional. Neue
Projekte und Graphen schreiben die fachlich validierten Werte. Backups
verwenden Schema 8.0.0 und akzeptieren die migrierbaren Vorgänger 1.0.0 bis
8.0.0.

## UI und Fehlerverhalten

Der Projekteditor bietet für Fertigung einen Stepper von 0 bis 10 Prozent.
Für Reaktionen zeigt er ausdrücklich „nicht anwendbar“. Projektliste und
Graphansicht zeigen ME, Rohbedarf, Effektivbedarf, Ersparnis und
Formelversion.

Rechen-, Validierungs-, Abbruch- oder Persistenzfehler laufen über die
zentrale Produktionsgraph-Fehlergrenze. Ein vorhandener Graph bleibt bei
einem fehlgeschlagenen Neuberechnungsversuch erhalten.

## Bewusste Grenzen

- P16 löst mehrstufige T1-Ketten auf.
- P17 ergänzt T2-Ketten.
- P18 ergänzt notwendige Reaktionsstufen.
- P19 aggregiert gleiche Materialien und schützt Graphdurchläufe.
- Weitere Jobmodifikatoren benötigen eine eigene verifizierte Fachregel und
  werden nicht aus Blueprint-ME abgeleitet.

## Nachweis

- Referenz-, Grenz-, Rundungs-, Überlauf- und Manipulationstests,
- Fertigungs- und Reaktionspfade,
- Graphformat-1-/2-Kompatibilität und Format-3-Invarianten,
- Projekt-/Graph-Roundtrip und Bestandsschutz,
- v7→v8-Migration, zweite Storeöffnung und leeres Schema v8,
- Backupkompatibilität 1.0.0 bis 8.0.0,
- UI-/Architekturtests,
- SwiftPM und Xcode in Debug und Release,
- isolierter Schema-v8-App-/Store-Smoke-Test.
