# Tokenarmer Kern-MVP

Stand: 2026-07-28

Plan-ID: PLAN-002

Aktueller Betriebsnachtrag PLAN-003: Der erreichte Kern wird lokal auf dem
Mac des Projekteigentümers betrieben. Öffentliche Apple-Distribution ist
kein MVP-Gate und bleibt als P48 das letzte optionale Zukunftspaket.

PLAN-004 führte P38 bis P42 aus; P43/P44 wurden nach Nutzenreview
zurückgestellt. PLAN-005 ergänzt nun ausschließlich die notwendige
Restabnahmefolge **P50 → P51 → P52 → P53 → P54**. P49 bleibt bewusst
unbelegt. P45–P48 bleiben zurückgestellt beziehungsweise optional. Der
lokale Kern bleibt während aller Korrekturen eigenständig nutzbar. P50 und
P51 sind abgeschlossen; P52 endete mit den ausdrücklich dokumentierten
P42-Eigentümergates als Restbefund. P53 ist abgeschlossen; P54 benötigt
eine gesonderte ausdrückliche Commit-Freigabe.

## Ziel

Der nächste nutzbare Stand beantwortet ausschließlich:

> Was soll produziert oder erfunden werden, welche Materialien sind im
> gewählten Lagerbestand vorhanden, welche Zwischenprodukte werden selbst
> gebaut und welche Mengen fehlen?

Die bereits abgenommenen P00–P25 bleiben erhalten. Es wird keine bestehende
Funktion entfernt.

## Workflow-Referenz

Ravworks zeigt einen kompakten Ablauf: Konfiguration festlegen, Produkte
eingeben, Bestände angeben und daraus Stückliste, Jobs und
Inventionsübersicht erzeugen. Zwischenprodukte können gekauft statt
produziert werden; Rundung und Chargen bleiben sichtbar.

New Eden Nexus übernimmt nur dieses Ablaufprinzip:

1. Produkt und Menge wählen.
2. vorhandenen lokalen/importierten Lagerbestand berücksichtigen,
3. Zwischenstufen manuell auf **Bauen** oder **Kaufen** setzen,
4. Produktions- und Inventionsjobs anzeigen,
5. fehlende Kaufmengen als einfache kopierbare Liste ausgeben.

Quellen:

- [Ravworks – Überblick](https://ravworks.com/)
- [Ravworks – Production Planner](https://www.ravworks.com/planner)
- [Ravworks – FAQ zu Chargen und T2-Stufen](https://ravworks.com/FAQ)

Dies ist eine Funktionsreferenz, keine Übernahme von Code, Gestaltung oder
unbelegten Berechnungsregeln.

## Verbindlicher unmittelbarer Umfang

### Bereits vorhanden

- SDE, Item-/Blueprintkatalog und Rezeptresolver,
- T1-, T2-, Invention- und Reaktionsgraph,
- Runs, Output, ME und Materialaggregation,
- lokale/CSV-importierte Lagerbestände,
- Ausschlüsse, Sicherheitsbestände, Reservierungen und Konflikte.

### Umsetzungsstand

1. **P26 – schlanker Produktionsentscheidungsplan: ✅ erledigt**
   - Bestand automatisch verwenden,
   - geeignete Zwischenstufe manuell bauen oder kaufen,
   - Produktions- und Inventionsjobs ableiten,
   - fehlende Kaufmengen berechnen.
2. **P32 – integrierter Kernworkspace: ✅ erledigt**
   - vorhandene Projekt-, Graph-, Lager- und P26-Komponenten in einem
     durchgehenden Ablauf verbinden,
   - einfache kopierbare Bedarfsliste bereitstellen.
3. **P37 – interne Kernabnahme: ✅ erledigt**
   - je ein T1- und T2-/Inventionsprojekt end-to-end mit Lagerbestand
     nachweisen,
   - keinen Release-Candidate behaupten.

## Temporär verschoben

- P27: Preisprofile – **anschließend reaktiviert und erledigt**,
- P28: CSV-Preisimport – **anschließend reaktiviert und erledigt**,
- P29: Kosten, Gewinn und ROI – **anschließend reaktiviert und erledigt**,
- P30: erweiterte persistente Einkaufslistenaggregation –
  **anschließend reaktiviert und erledigt**,
- P31: Einkaufsstatus und CSV-Export –
  **anschließend reaktiviert und erledigt**,
- P33: umfassende Fehler-UX-Politur – **anschließend reaktiviert und erledigt**,
- P34: Performanceprogramm und mechanische Großdateiaufteilung –
  **anschließend reaktiviert und erledigt**,
- P35: Accessibility-/UX-Politur – **reaktiviert, einschließlich OFF-030
  abgenommen**,
- P36: vollständiger Recovery- und harter Prozessabbruchdrill –
  **reaktiviert und erledigt**,
- öffentliche Release-/Distributionsabnahme – **nicht Teil des lokalen
  Zielbetriebs; als P48 zuletzt optional verschoben**.

Vorhandene technische Sicherheitsgrenzen, Tests und Backups bleiben aktiv.
Die Verschiebung erlaubt keine Datenverluste und keine Umgehung relevanter
Tests.

## Token- und Prüfstrategie

- Nur aktuelle betroffene Quellen und relevante Dokumentabschnitte lesen.
- Prompts bleiben ausführbar, aber wiederholen weder Projektgeschichte noch
  allgemeine Regeln.
- Je Paket: fokussierte Tests; ein vollständiger SwiftPM-Debuglauf.
- Xcode-Debug nur bei App-/UI-/Projektänderungen.
- Release- und Real-SDE-Läufe nur bei betroffener Release-/SDE-Grenze oder
  ausdrücklicher Abnahme.
- Dokumentation als kurze Deltas; historische Berichte werden verlinkt,
  nicht neu erzählt.

## Definition des nutzbaren Kernstands

Der Kernstand ist erreicht, wenn:

- ein T1- und ein T2-Produkt ausgewählt werden können,
- der T2-Plan seine Inventionsstufe sichtbar enthält,
- Runs und Materialmengen reproduzierbar sind,
- lokale/importierte Lagerbestände, Schutz und Reservierungen abgezogen
  werden,
- Bauen/Kaufen je geeigneter Zwischenstufe manuell steuerbar ist,
- Produktionsjobs, Inventionsjobs und fehlende Kaufmengen verständlich
  angezeigt werden,
- Projekt und Entscheidungen lokal erhalten bleiben,
- fokussierte Tests, SwiftPM Debug und bei UI-Änderungen Xcode Debug
  tatsächlich erfolgreich sind.

Dieser Stand ist der lokal nutzbare Zielbetrieb auf dem Eigentümer-Mac, kein
öffentlicher Release Candidate. App Store, Developer-ID und Notarisierung
sind dafür nicht erforderlich.
