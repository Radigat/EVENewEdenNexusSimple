# SDE-Einstellungen, Automation und Diagnose

Stand: 2026-07-23 · P07C

## Aufruf

Der Bereich **EVE-Daten und SDE** ist über die zentrale Navigation und in den
Einstellungen erreichbar. **Rechtliche Hinweise** ist ein eigener
Einstellungs-Tab.

## Sichere Standardwerte

- automatische Aktualitätsprüfung: an,
- Prüfintervall: 24 Stunden,
- automatischer Download: aus,
- automatische Installation: aus,
- mindestens eine Rollback-Version behalten,
- automatische Löschung alter Versionen: aus,
- persönliche Prüfung der CCP-Bedingungen: nicht vorausgewählt.

Ein Intervall unter 24 Stunden wird auch beim Laden gespeicherter Werte
normalisiert. Die App verhindert parallele Start-, Prüf-, Download- und
Installationsvorgänge. Offline bleibt der zuletzt aktive Katalog verfügbar.

## Kontakt und Bedingungen

Metadaten können ohne Kontakt geprüft werden. Download oder Installation
verlangen eine reale Kontaktmöglichkeit für den User-Agent. Sie wird nach
explizitem Speichern ausschließlich im macOS-Schlüsselbund abgelegt. Sie
erscheint weder im Updatejournal noch im Diagnoseexport.

Die Schaltfläche zur persönlichen Prüfung dokumentiert nur die
Benutzerentscheidung. Die App akzeptiert keine Verträge stellvertretend und
behauptet keine rechtliche oder offizielle Freigabe.

## Updateablauf

1. Beim App-Start abgebrochene Download-, Cache-, Journal-, Import- und
   Stagingartefakte kontaktfrei bereinigen.
2. Nur nach erfolgreicher Recovery Build- und Schemametadaten cachekonform
   prüfen.
3. Bei Opt-in das offizielle Archiv in einen privaten Cache laden.
4. Cachedatei vor Wiederverwendung über Größe und SHA-256 prüfen.
5. P07B-Download-, ZIP-, Staging-, Backup-, Aktivierungs- und Rollbackgates
   ausführen.
6. Fortschritt phasenbezogen anzeigen und Abbruch weiterreichen.
7. Nach Erfolg den vorbereiteten Archivcache entfernen.
8. Optional eine separate Retentionvorschau anzeigen.

Eine unbekannte Schemaänderung blockiert die Installation. Ein
fehlgeschlagener Vorgang lässt den bisherigen aktiven Stand unverändert.

## Storegröße

Die angezeigte lokale Datenbankgröße umfasst die SQLite-Hauptdatei sowie
vorhandene WAL- und SHM-Dateien. Downloadcache und Backups sind nicht
enthalten und werden in der Oberfläche ausdrücklich getrennt benannt.

## Updateprotokoll und Diagnoseexport

Das Protokoll lässt sich nach Build, Phase oder sicherem Diagnosecode filtern
und zeitlich sortieren. Der Export beginnt immer mit einer Vorschau und einer
vom Benutzer gewählten Zieldatei.

Exportiert werden ausschließlich:

- angeforderter und aktivierter Build,
- HTTP-Status und Cacheentscheidung,
- Downloadgröße,
- Datensatzanzahlen,
- Backup-, Cleanup- und Rollbackstatus,
- Phasen, Zeitstempel und sichere Fehlercodes.

Nicht exportiert werden Vorgangs-IDs, URLs, lokale Pfade, Hashes,
Kontaktwerte, Tokens, Secrets oder Spieler-/Accountdaten.

## Alte Versionen

Vor einer Löschung berechnet die App eine neue Vorschau und zeigt die exakten
Buildnummern. Die Bestätigung ist nur für genau diesen Zustand gültig. Die
aktive und mindestens die letzte funktionierende Version bleiben geschützt.
Projekte, Charaktere und andere Benutzerdaten gehören nicht zur
Retentionoperation.

## Aktuelle Prüfgrenze

Logik, Persistenz und SwiftUI-Quellzustände sind automatisiert geprüft.
P09B ergänzt den echten App-Bundle-Start und die manuelle Prüfung von
Normal-, Offline- und Schema-Warnzustand, Navigation, Einstellungen,
Rechtsansicht, Tastatur und VoiceOver mit isoliertem Profil. Der erneute
Abgleich der dann aktuellen CCP-/Releasebedingungen bleibt P37.
