# Produktionsprojekt-Lebenszyklus

Stand: 2026-07-24 · P11

## Zweck und Grenze

P11 stellt den vollständigen lokalen Lebenszyklus eines einzelnen
Produktionsprojekts bereit: anlegen, laden, bearbeiten, Status ändern,
duplizieren, archivieren und wiederherstellen.

Das Zielprodukt bleibt bis P12 ein validierter Freitext. Produktionsgraph,
Runs, ME, Produktionsketten, Bestände, Reservierungen und Kosten werden nicht
vorweggenommen.

## Statusmodell

| Ausgang | Zulässige Ziele |
|---|---|
| Planung | Beschaffung, Produktionsbereit, Archiviert |
| Beschaffung | Planung, Produktionsbereit, Archiviert |
| Produktionsbereit | Planung, Beschaffung, In Produktion, Archiviert |
| In Produktion | Produktionsbereit, Abgeschlossen, Archiviert |
| Abgeschlossen | In Produktion, Archiviert |
| Archiviert | Planung |

Ein Wechsel auf denselben Status ist ein idempotenter No-op. Ungültige
Übergänge erzeugen einen typisierten Fachfehler und schreiben nichts.

## Fachregeln

- Neue Projekte erhalten eine neue UUID, `Planung` und denselben Erstellungs-
  und Änderungszeitpunkt.
- Beim Bearbeiten bleiben UUID, Erstellungszeit und Status erhalten.
- Archivierte Projekte sind schreibgeschützt.
- Duplikate erhalten eine neue UUID, den Suffix ` – Kopie`, den Status
  `Planung` und neue Zeitstempel.
- Archivierung ist reversibel; Wiederherstellung setzt auf `Planung`.
- P11 führt kein dauerhaftes Löschen ein.
- Listen können nicht archivierte, archivierte oder alle Projekte liefern.

## Architektur

```text
ProjectsView
  -> ProjectLifecycleViewModel
      -> ProductionProjectLifecycleManaging
          -> ProductionProjectLifecycleService
              -> ProductionProjectRepository
                  -> SwiftDataProductionProjectRepository
```

`ProjectsView` importiert weder SwiftData noch persistente Modelle. Der
fachliche Statusgraph liegt in Application. `ProjectAppComposition` erzeugt
Repository, Service und ViewModel am App-Rand.

## Datenhaltung

P11 ergänzt keine persistierten Felder. Das vorhandene Schema v4 und die
Migrationen Legacy→v1→v2→v3→v4 bleiben unverändert. Ein dateibasierter
Integrationstest öffnet denselben temporären Store mehrfach und prüft den
kompletten Lebenszyklus einschließlich Zeitstempeln, Archivierung und
Wiederherstellung.

## Fortschreibung bis P15

P12 ergänzt das kataloggebundene Ziel, P13/P14 den Graph- und Runstand und
P15 den validierten Blueprint-ME-Wert. Der P11-Lebenszyklus bleibt dabei die
einzige Mutationsgrenze: Anlage und Bearbeitung schreiben ME, Duplikate
übernehmen es, Statuswechsel, Archivierung und Wiederherstellung erhalten
es. Schema v8 speichert ME optional; migrierter Altbestand wird neutral als
0 gelesen. Reaktionsziele akzeptieren ausschließlich ME 0.

## Bedienung

Die Projektansicht bietet Filter für aktuelle Projekte, Archiv und alle
Projekte, eine Tabelle, ein Anlege-/Bearbeitungsformular, Statusaktionen,
Duplizieren, bestätigte Archivierung und Wiederherstellung. Loading-, Empty-,
Fehler- und laufende Mutationszustände sowie Tastaturkürzel und
Accessibility-Labels sind vorhanden.

## Fehler und Sicherheit

Ladefehler werden zentral als `NEN-PER-006`, Schreibfehler weiterhin als
`NEN-PER-002` dargestellt und redigiert protokolliert. Cancellation und
Repositoryfehler werden nicht verschluckt. Es gibt keinen automatischen
Fallback auf einen leeren produktiven Store und keine Datenlöschung.
