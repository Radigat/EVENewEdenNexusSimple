# ADR-0058 – Reaktionsuntergruppen und kompakte Build-or-Buy-Steuerung

Datum: 2026-07-29  
Status: angenommen mit offenem Eigentümer-Sichttest  
Ergänzt: ADR-0057

## Kontext

ADR-0057 fasste alle Reaktionen in einer gemeinsamen Gruppe zusammen. Für
praktische Make-or-Buy-Entscheidungen müssen die drei bereits im
Produktionsgraphen verifizierten EVE-Reaktionsarten getrennt wählbar sein.
Außerdem beanspruchte die wiederholte sichtbare Pickerbeschriftung zu viel
Platz.

## Entscheidung

- `ProductionGraphRecipeReference.reactionKind` ist die einzige Quelle für
  die Untergruppen **Biochemical Reactions**, **Composite Reactions** und
  **Hybrid Polymer Reactions**.
- Fehlt diese Angabe bei einer Reaktionsstufe, wird sie sichtbar und
  fail-closed als **Unklassifizierte Reaktionen** geführt.
- Eine segmentierte Filterleiste schränkt die sichtbare Gruppe ein, verändert
  aber keine Entscheidung.
- Die globalen Sofortaktionen **Alles bauen** und **Alles kaufen** ändern alle
  Stufen im lokalen Entwurf. Gruppenaktionen bleiben zusätzlich erhalten.
- Einzelzeilen zeigen einmalig die Spalten **Item** und
  **Bauen oder Kaufen**; der Itemname wird nicht in einer zweiten sichtbaren
  Pickerbeschriftung wiederholt. Der vollständige Kontext bleibt für
  VoiceOver erhalten.
- Vorschau, Bestätigung, P26-Plan und Type-ID-Persistenz bleiben unverändert.

## Folgen

Die Änderung benötigt weder neues SDE-Mapping noch eine Migration. Ein Filter
ist reine Darstellung; globale und gruppierte Aktionen werden erst nach
erneuter Vorschau und ausdrücklicher Bestätigung gespeichert. Unbekannte
Reaktionsarten werden nicht geraten.
