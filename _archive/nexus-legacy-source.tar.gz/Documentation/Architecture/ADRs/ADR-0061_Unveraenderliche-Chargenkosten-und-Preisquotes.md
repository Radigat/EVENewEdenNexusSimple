# ADR-0061 – Unveränderliche Chargenkosten und belegte Preisquotes

Status: Akzeptiert · 2026-07-29 · technisch umgesetzt mit P58

## Kontext

P57 speichert tatsächliche Produktionschargen unveränderlich. Projektbudget,
Preissätze und öffentliche ESI-Marktquotes sind dagegen veränderliche
Planungsstände. Für reproduzierbare Stückkosten und Verkaufsvorschläge dürfen
diese Quellen eine historische Charge nicht nachträglich umwerten.

## Entscheidung

- Eine bestätigte Kostenbasis wird als eigener unveränderlicher
  `ProductionBatchCostSnapshot` an genau eine Charge gebunden.
- Kostenzeilen sind typisiert und führen Betrag, Quelle, Zeitpunkt,
  Zuordnungsart und Warnungen. Ein unbekannter Betrag bleibt `nil` und sperrt
  Gesamtkosten und abgeleitete Kennzahlen.
- `PriceQuoteBinding` speichert Markt, Sell-Rolle, Menge, Orderanzahl,
  Zeitstand, Ablauf, Snapshot-/Policy-Identität und Fallbackstatus.
- Jita ist die Standardreferenz. Ein alternativer benannter öffentlicher Markt
  wird über den bestehenden P41-Marktvertrag geladen.
- Ein manueller oder CSV-Preissatz wird nur nach sichtbarer Auswahl als
  Fallback verwendet. Es gibt weder eine stillschweigende Null noch einen
  verdeckten Austausch zwischen Buy und Sell.
- Stückkosten, Aufschläge, Erlös, Gewinn, Marge, ROI und Break-even werden
  deterministisch in ganzzahligen ISK-Hundertsteln berechnet.
- Das Speichern verlangt Vorschau, ausdrückliche Bestätigung und einen
  unveränderten Chargenstand.

## Konsequenzen

Schema v27 ergänzt nur den neuen Snapshot-Datensatz. Die additive Migration
erfindet keine Kostenhistorie. P59 kann realisierte Belege später getrennt
zuordnen, ohne den P58-Prognosesnapshot zu überschreiben.

## Verwarfene Alternativen

- Projektbudget direkt an der Charge referenzieren: verworfen, weil spätere
  Planänderungen historische Werte verändern würden.
- Fehlende Kosten als 0 ISK behandeln: verworfen, weil dadurch Stückkosten und
  Gewinn zu günstig erschienen.
- BPO-Anschaffung automatisch voll zuschlagen: verworfen; die Zuordnung bleibt
  eine bewusste Eigentümerentscheidung.

## Rollback

Die P58-Oberfläche kann deaktiviert werden. Chargen, Projekte, Budgets,
Preissätze und Walletdaten bleiben unverändert; vorhandene Kostensnapshots
bleiben lesbar.
