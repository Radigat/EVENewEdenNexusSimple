# ADR-0029 – Globale Projektreservierungen und Schema v14

Status: Akzeptiert  
Datum: 2026-07-25  
Prompt: P24

## Kontext

Nach P22 und P23 ist bekannt, welche physische Menge eines Materials für ein
Projekt freigegeben und welche globale Menge geschützt ist. Für mehrere
Projekte fehlt noch eine dauerhaft nachvollziehbare Bindung dieser
verwendbaren Menge. Das Projektbuch fordert Projektreservierungen, belegt
aber keine verbindliche Verteilung auf Charaktere oder Lagerorte.

## Entscheidung

1. Reservierungen gelten global für die Kombination aus Projekt-ID und
   positiver CCP-Type-ID.
2. Höchstens eine aktive Bindung je Projekt und Type-ID ist zulässig.
   Terminale Historieneinträge bleiben erhalten.
3. `reserved` und `partiallyConsumed` binden ihre Restmenge; `consumed` und
   `released` binden nichts.
4. P22 und P23 bleiben die vorgelagerten, unveränderten Quellen. Aktive
   Restbindungen anderer Projekte werden anschließend abgezogen.
5. Neue Überbuchungen werden abgelehnt und niemals automatisch gekürzt.
   Nachträglich entstandene Konflikte bleiben Eigentum von P25.
6. Ablaufdatum und Priorität sind persistente Metadaten. Ablauf löst keine
   automatische Freigabe aus.
7. Vorschau und Schreiben bleiben getrennt. Schreiben verlangt Bestätigung
   und denselben vollständigen Quellzustand.
8. Schema v14 ergänzt additiv `StockReservationRecord`; Benutzerdaten und
   SDE-Daten werden nicht umgeschrieben.
9. Projekte mit aktiven Bindungen können nicht archiviert werden.

## Begründung

Die globale Type-ID-Bindung ist die kleinste durch den MVP belegte
Fachregel. Sie verhindert erfundene Lager- oder Charakterzuordnungen,
bleibt reproduzierbar und lässt sich später um echte Allokationen ergänzen.
Der explizite Zustandsautomat erhält Historie und verhindert, dass
Verbrauch oder Freigabe versehentlich Lagerbestände verändern. Die
optimistische Quellzustandsprüfung schützt vor veralteten Vorschauen und
Paralleländerungen.

## Konsequenzen

- P24 kann Reservierungen erstellen, ändern, teilweise oder vollständig
  verbrauchen und freigeben.
- Bestehende aktive Bindungen anderer Projekte reduzieren die für eine neue
  Bindung verfügbare Menge.
- Eine nachträgliche Bestands-, Ausschluss- oder Schutzregeländerung kann
  eine bestehende Bindung faktisch in Konflikt bringen; P25 muss diesen
  Zustand sichtbar machen und kontrolliert auflösen.
- Ohne belastbare Allokationsregel gibt es keine lagerbezogene
  Reservierung.
- Schema v14 und Backupformat 14.0.0 werden Teil der verbindlichen
  Migrations- und Recoverykette.

## Alternativen

- **Reservierung je Lager:** verworfen, weil keine belastbare
  Zuordnungsregel zwischen aggregiertem Graphbedarf und Lagerposition
  vorliegt.
- **Automatische Kürzung bei Überbuchung:** verworfen, weil sie eine
  Benutzerentscheidung und Historie stillschweigend verändern würde.
- **Ablauf mit automatischer Freigabe:** verworfen, weil ein Zeitablauf ohne
  bestätigte Benutzerhandlung Material unerwartet anderen Projekten
  überlassen würde.
- **Nur berechnete, nicht persistente Bindung:** verworfen, weil
  Projektkonkurrenz über App-Neustarts nachvollziehbar bleiben muss.

## Nachweis

20 fokussierte P24-Tests, vier vollständige Debug-/Release-Testwege mit je
408 Tests, Schema-v13→v14-Migration, v14-Leerstore, zweite Öffnung,
Backupkompatibilität und isolierter App-Start sind bestanden.

