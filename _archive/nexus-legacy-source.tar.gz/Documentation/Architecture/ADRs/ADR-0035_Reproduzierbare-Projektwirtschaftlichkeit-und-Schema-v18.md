# ADR-0035 – Reproduzierbare Projektwirtschaftlichkeit und Schema v18

Status: **Akzeptiert**  
Datum: 2026-07-26  
Prompt: P29

## Kontext

P26 liefert einen reproduzierbaren Plan mit Lager- und Kaufanteil; P27/P28
liefern exakte lokale Preise. Kostenkennzahlen dürfen weder Preise als null
erfinden noch veraltete Ergebniszahlen dauerhaft speichern.

## Entscheidung

1. Eine reine Domainkomponente berechnet sämtliche Geld- und Prozentwerte
   mit geprüfter Ganzzahlarithmetik.
2. Cash-Kosten bewerten Fehlmengen, wirtschaftliche Kosten den vollständigen
   Materialeinsatz einschließlich Lager.
3. Erlös basiert auf Zielmenge und Zielproduktpreis desselben Preisprofils.
4. Marge und ROI werden auf einen Basispunkt gerundet; ROI ist bei
   Nullkapital nicht definiert. Break-even je Einheit wird auf ein
   ISK-Hundertstel aufgerundet.
5. Fehlende Preise blockieren die vollständige Berechnung.
6. Persistiert werden nur Preisprofilwahl und manuelle Jobkosten. Ergebnisse
   werden aus aktuellem Plan und Preisstand neu erzeugt.
7. Schema v18 ergänzt additiv einen eindeutigen
   `ProjectEconomicsConfigurationRecord` je Projekt.
8. Vorschau, erneute Preisprüfung, Bestätigung und Optimistic Locking gehen
   jedem Schreibvorgang voraus.

## Folgen

- Kennzahlen bleiben erklärbar und reproduzierbar.
- Bestandsmaterial besitzt wirtschaftlichen Wert, ohne als neuer Cash-Abfluss
  zu erscheinen.
- Profiländerungen oder fehlende Preise werden sichtbar statt kaschiert.
- Marktgebühren, Steuern, SCI und Inventionsfehlversuche bleiben ohne
  belastbare Eingabe außerhalb von P29.
- Backupformat und aktuelle Schemaversion steigen auf 18.0.0.
