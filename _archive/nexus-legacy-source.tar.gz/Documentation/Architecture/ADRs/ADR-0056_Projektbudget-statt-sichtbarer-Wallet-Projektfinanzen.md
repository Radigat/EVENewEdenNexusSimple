# ADR-0056 – Projektbudget statt sichtbarer Wallet-Projektfinanzen

Datum: 2026-07-28  
Status: angenommen

## Kontext

Die sichtbare P42-Projektfinanzansicht verband Wallet-Istwerte und
P29-Wirtschaftlichkeitswerte. Für die aktuelle Projektplanung wird zuerst
ein nachvollziehbares Beschaffungsbudget benötigt.

## Entscheidung

- Die P42-Projektfinanzansicht ist nicht mehr über die Accountoberfläche
  erreichbar. Wallet-Snapshots und bestätigte Zuordnungen werden nicht
  gelöscht.
- Der Produktionsworkspace enthält den Bereich **Budget**.
- Materialkosten stammen ausschließlich aus der wirksamen Einkaufsliste.
  Damit entscheidet der gespeicherte Build-or-Buy-Plan, ob Eingangsrohstoffe
  beziehungsweise Komponenten oder ein Zwischenprodukt gekauft werden.
- Logistik- und Produktionskosten sind getrennte, nichtnegative manuelle
  ISK-Werte.
- Das benötigte Budget ist:

```text
Materialeinkauf + Logistik + Produktion
```

- Preis- oder Kostenänderungen erzeugen zunächst eine schreibfreie Vorschau.
  Die Budgetbasis wird erst nach ausdrücklicher Bestätigung gespeichert.
- Schema v25 ergänzt einen eigenen
  `ProjectBudgetConfigurationRecord`; P29- und P42-Daten bleiben getrennt
  erhalten.

## Folgen

Die neue Planung ist unabhängig von Wallet-Istbuchungen und bewertet keine
Lagerbestände als Cash-Abfluss. Automatische Logistik-, Job-, Steuer- oder
Facilityregeln sind nicht enthalten und dürfen nicht als Nullwerte
interpretiert werden.
