# ADR-0024 – Type-ID-Graphaggregation und Graphformat 7

Status: **Akzeptiert**

Datum: 2026-07-24

Prompt: P19

## Kontext

Graphformat 6 bewahrt jedes Materialvorkommen einzeln. Das ist für
Erklärbarkeit notwendig, beantwortet aber noch nicht, wie viel von einem
identischen Endmaterial über alle T1-, T2- und Reaktionszweige insgesamt
benötigt wird. Eine bloße flache Namenssumme würde CCP-Identitäten
vermischen, Zwischenprodukte doppelt zählen und ihren Ursprung verlieren.

Geladene Graphpayloads brauchten außerdem dieselben Lastgrenzen wie die
Generierung sowie eine verifizierbare Grenze gegen manipulierte
Aggregationssummen.

## Entscheidung

1. Der Produktionsgraph behält seine Vorkommensknoten unverändert.
2. Eine reine Domainkomponente aggregiert ausschließlich Materialblätter
   nach stabiler CCP-Type-ID.
3. Jede Position speichert ihre Einzelvorkommen, effektiven Mengen,
   Blattgründe und vollständigen Wurzelpfade.
4. Reaktionskanten verwenden ihre effektive Reaktionsmenge; alle anderen
   Kanten die effektive Materialmenge.
5. Jede `Int64`-Addition ist überlaufgeprüft und bricht vor Persistenz ab.
6. Graphformat 7 speichert Aggregationsformel 1 in der bestehenden
   kanonischen Payload.
7. Beim Laden wird die Aggregation neu berechnet und exakt verglichen.
8. Tiefe 64, Knotenanzahl 25.000, eindeutige Geschwisterreihenfolge und die
   vorhandenen Strukturinvarianten gelten auch für geladene Payloads.
9. Graphformate 1 bis 6 bleiben lesbar und gelten als veraltet.
10. Schema v9 und Backupformat 9.0.0 bleiben unverändert.

## Folgen

- Der Graph bleibt vollständig erklärbar und liefert zugleich eine
  deterministische Endmaterialsumme.
- Zwischenprodukte werden nicht doppelt gezählt.
- Manipulierte Aggregationen und extreme Summen können keinen gültigen
  Snapshot vortäuschen.
- Ein fehlgeschlagener Kandidat ersetzt keinen vorhandenen Graphen.
- Die kanonische Payload wird größer, weil Pfade pro Vorkommen gespeichert
  werden; konkrete Performancebudgets bleiben P34.
- Bestand, Reservierungen und Build-or-Buy bleiben bewusst nachgelagerte
  Berechnungsschritte.

## Verworfene Alternativen

- **Aggregation nach Name:** Namen sind keine stabilen fachlichen Schlüssel.
- **Globale Deduplizierung der Graphknoten:** würde Zweigprovenienz und
  stufenspezifische Runs/Modifier verlieren.
- **Nur Gesamtsumme ohne Vorkommen:** nicht hinreichend erklärbar.
- **Clamping oder `Double` bei Überlauf:** nicht exakt und nicht
  reproduzierbar.
- **Neue SwiftData-Spalte:** unnötig, da die kanonische Graphpayload bereits
  versioniert ist.

## Nachweis

- `ProductionGraphMaterialAggregator` und Graphformat 7,
- Domain-, Application-, Persistenz- und Architekturtests,
- SwiftPM/Xcode Debug/Release je 321 Tests, 0 Fehler, 0 übersprungen,
- isolierter Schema-v9-App-Store mit erfolgreicher Integritätsprüfung,
- [Materialaggregation](../../MATERIAL_AGGREGATION.md),
- [P19-Abschlussbericht](../../Progress/Reports/2026-07-24_P19_Aggregation-Graphschutz.md).
