# ADR-0054 – Benannte Marktquellen und öffentliche Strukturen

Status: **Akzeptiert mit offenem Eigentümer-Sichttest**  
Datum: 2026-07-28  
Prompt: P52/P41-1

## Kontext

Die P41-Oberfläche verlangte technische Region- und Location-IDs. Diese
Werte sind für die Bedienung ungeeignet. Gewünscht sind benannte Regionen,
direkt wählbare Trade Hubs sowie bekannte Stationen und Spielerstrukturen.
Der bestehende Preisvertrag liest jedoch ausschließlich öffentliche
regionale Verkaufsorders und besitzt weder einen privaten
Strukturmarkt-Scope noch eine Kontoauswahl für private Marktorders.

## Entscheidung

- Regionen werden über die öffentlichen ESI-Universe-Routen geladen und in
  einem benannten Dropdown angeboten. Bei einem Offlinefehler bleiben die
  fünf Trade-Hub-Regionen als klar gekennzeichneter Rückfall verfügbar.
- Jita, Amarr, Dodixie, Rens und Hek werden als überprüfte
  NPC-Trade-Hub-Schnellwahlen mit ihren offiziellen Stations- und
  Regions-IDs angeboten.
- Lokal bereits bekannte Stationen und Spielerstrukturen werden über
  gespeicherte persönliche ESI-Snapshots und den vorhandenen Namenscache
  zusammengeführt. Die Region wird aus Station beziehungsweise Sonnensystem
  über öffentliche ESI-Universe-Daten bestimmt.
- Eine bekannte Spielerstruktur ist nur dann als öffentliche Preisquelle
  auswählbar, wenn sie auch in CCPs öffentlichem Marktstrukturverzeichnis
  vorkommt. Sonstige zugängliche Strukturen bleiben mit Namen sichtbar, aber
  als „privater Markt – noch nicht aktiviert“ gesperrt.
- Der bestehende Abruf verwendet weiter öffentliche regionale Sell-Orders.
  Private Strukturorders benötigen später einen getrennten authentifizierten
  Vertrag, Scope, Kontoauswahl, Cache und Vorschau-vor-Schreiben.
- Technische IDs bleiben interne stabile Schlüssel und werden nicht mehr als
  primäre Eingabefelder dargestellt.

## Konsequenzen

Ein verwendeter Marktstandort in Home-Systemen wie UALX-3 oder X-10-J
erscheint namentlich, sobald seine Struktur in einem aktuellen persönlichen
Snapshot samt Strukturnamen und Region bekannt ist. Ist der konkrete Markt
öffentlich, kann er im bestehenden regionalen Preisabruf als Locationfilter
gewählt werden. Nicht öffentliche Strukturmärkte werden nicht fälschlich als
abrufbar dargestellt.

Die Änderung benötigt keine Datenbankmigration und verändert keine
Benutzerdaten. Universe-Verzeichnisse werden begrenzt, defensiv validiert und
über die HTTP-Cachepolitik sowie einen laufzeitlokalen Cache wiederverwendet.

## Alternativen

- IDs weiterhin manuell eingeben: verworfen, weil fehleranfällig und nicht
  nutzerorientiert.
- Alle bekannten Strukturen auswählbar machen: verworfen, weil der öffentliche
  Regionalorder-Endpunkt nicht den Inhalt privater Strukturmärkte garantiert.
- Unbekannte Home-Hub-Werte fest einbauen: verworfen; Namen, Region und
  Zugänglichkeit dürfen nicht geraten werden.

## Prüfnachweis

- 26 fokussierte Markt-, Directory-, Namens- und Workspace-Tests bestanden.
- 667/667 SwiftPM-Tests bestanden.
- Apple-Development-signierter Xcode-Debugbuild für macOS arm64 bestanden.
- Eigentümer-Sichttest für Regionen, Trade Hubs und einen bekannten Home-Hub
  bleibt getrennt offen.

Offizielle Grundlage: CCP
[API Explorer](https://developers.eveonline.com/api-explorer),
[Map Data](https://developers.eveonline.com/docs/guides/map-data/) und
[ESI Rate Limiting](https://developers.eveonline.com/docs/services/esi/rate-limiting/),
geprüft am 2026-07-28.
