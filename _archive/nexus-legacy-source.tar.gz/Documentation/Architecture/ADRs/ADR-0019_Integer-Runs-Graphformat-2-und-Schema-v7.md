# ADR-0019 – Integer-Runs, Graphformat 2 und Schema v7

Status: Akzeptiert  
Datum: 2026-07-24  
Prompt: P14

## Kontext

Der P13-Graph enthält Rezeptoutput und rohe Materialmengen, aber noch keine
Runzahl oder tatsächlich erzeugte Produktmenge. Die Berechnung muss ohne
Fließkomma, stillen Überlauf, UI-Abhängigkeit oder erfundete
BPO-/BPC-Jobgrenzen reproduzierbar sein. Alte Graphpayloads und Benutzerdaten
müssen lesbar bleiben.

## Entscheidung

1. `ProductionRunCalculation` ist ein unveränderlicher Domainwert mit
   Formelversion 1 und ausschließlich positiven `Int64`-Eingaben.
2. Ceiling-Division erfolgt über Quotient und Rest; die
   Outputmultiplikation verwendet geprüfte Ganzzahlarithmetik.
3. Abgeleitete persistierte Werte werden beim Decodieren neu berechnet und
   bei Widerspruch abgelehnt.
4. Graphformat 2 verlangt eine konsistente Runberechnung je Rezeptknoten.
   Materialknoten dürfen keine tragen.
5. Graphformat 1 bleibt unverändert lesbar, gilt jedoch als veraltet und wird
   nur auf ausdrückliche Benutzeraktion regeneriert.
6. Schema v7 ersetzt den Graphdatensatz leichtgewichtig durch eine
   feldgleiche Version mit optionaler
   `calculationFormulaVersion`. Format-1-Bestand erhält `nil`; neue
   Format-2-Graphen tragen Version 1.
7. `maxProductionLimit` wird nicht als Projekt-, Job- oder Batchgrenze
   interpretiert.

## Folgen

### Positiv

- Run- und Outputwerte sind zentral, nachvollziehbar und testbar,
- Überläufe und manipulierte Payloads scheitern explizit,
- bestehende Graphen und Benutzerdaten bleiben erhalten,
- Persistenzmetadaten erkennen Formel-/Payloadwidersprüche früh,
- P15 kann Material Efficiency auf einer stabilen Runbasis ergänzen.

### Einschränkungen

- P14 berechnet noch keine Materialgesamtmengen,
- BPO-/BPC-Besitz und lizenzierte Rest-Runs sind nicht verfügbar,
- mehrstufige Ketten erhalten ihre eigenen Runberechnungen erst mit
  P16 bis P18.

## Verworfene Alternativen

- **Fließkomma-`ceil`:** unnötige Präzisions- und Konvertierungsrisiken.
- **`(Z + O - 1) / O`:** kann bereits bei der Addition überlaufen.
- **Nur abgeleitete Werte speichern:** würde Manipulation und
  Versionswiderspruch schwerer erkennen lassen.
- **Format-1-Payload automatisch migrieren:** könnte ohne damalige
  Projekt-/Katalogentscheidung neue fachliche Werte erfinden.
- **`maxProductionLimit` als Jobgrenze:** verwechselt SDE-Provenienz mit
  konkretem BPO-/BPC-Besitz.

## Prüfnachweis

- Domain-, Application-, Persistenz-, Migration-, Backup-, ViewModel- und
  Architekturtests,
- 253 Tests jeweils in SwiftPM Debug/Release und Xcode Debug/Release,
- v3→v7- und v6→v7-Bestandsschutz,
- isolierter echter Schema-v7-App-Prozess mit `integrity_check = ok`.
