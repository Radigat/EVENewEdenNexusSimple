# ADR-0016 – App-spezifischer Storepfad und sichere Legacy-Erkennung

Status: **Akzeptiert**  
Datum: 2026-07-24  
Auftrag: OFF-026 als Voraussetzung für P12

## Kontext

`NexusModelContainerFactory` übernahm bisher die URL einer unbenannten
SwiftData-Standardkonfiguration. Auf macOS ergab das den globalen Pfad:

```text
~/Library/Application Support/default.store
```

Auf dem geprüften Rechner existierte dort bereits eine konsistente,
projektexterne Core-Data-Datenbank. Ihre Tabelle `ZAPIREQUESTMODEL` gehört
nicht zum New-Eden-Nexus-Schema. Der sichere Startfehler `NEN-PER-001` war
deshalb korrekt; ein Löschen, Überschreiben oder Öffnen als leerer
Ersatzstore wäre Datenverlust beziehungsweise eine unzulässige Übernahme
fremder Daten gewesen.

## Entscheidung

Der produktive Standardpfad lautet ab OFF-026:

```text
~/Library/Application Support/NewEdenNexus/NewEdenNexus.store
```

Vor der ersten Verwendung dieses Pfads wird ein vorhandener historischer
`default.store` ausschließlich lesend klassifiziert:

- Enthält er die New-Eden-Nexus-Signaturtabellen `ZCHARACTERRECORD` und
  `ZPRODUCTIONPROJECT`, wird er unverändert an seinem bisherigen Ort
  weiterverwendet. Es gibt keine automatische Verschiebung.
- Ist er lesbar, aber fachfremd, bleibt er unangetastet und die App verwendet
  den neuen app-spezifischen Pfad.
- Ist er nicht sicher lesbar, gilt „fail closed“: Die Factory versucht den
  bisherigen Pfad und lässt den zentralen Startfehler greifen. Sie erzeugt
  nicht stillschweigend einen leeren Store.
- Existiert bereits ein app-spezifischer Store, hat dieser Vorrang.

Ein ausschließlich für kontrollierte Tests bestimmtes Startargument kann
eine absolute Store-URL explizit injizieren:

```text
--new-eden-nexus-isolated-store <absolute URL>
```

Dieser Modus deaktiviert produktive SDE-/Keychain-Nebeneffekte wie die
bestehende XCTest-Isolation, ersetzt aber nicht den normalen Produktivpfad.

## Folgen

- Kollisionen mit generischen SwiftData-/Core-Data-Dateinamen werden
  vermieden.
- Ein erkennbarer historischer New-Eden-Nexus-Store bleibt ohne
  unaufgeforderte Migration oder Dateibewegung nutzbar.
- Fremde und nicht eindeutig klassifizierbare Stores werden nicht gelöscht,
  überschrieben oder übernommen.
- Die Pfadauflösung und alle drei Legacy-Fälle sind unabhängig von
  produktiven Benutzerdaten automatisiert testbar.
- Eine spätere benutzergesteuerte Store-Recovery oder Verschiebung benötigt
  weiterhin Backup, Vorschau und ausdrückliche Bestätigung.

## Verifikationsnachweis

- sechs neue Storepfad-/Signaturtests,
- ein Test für das isolierte Startargument,
- SwiftPM und Xcode in Debug und Release mit jeweils 205 bestandenen Tests,
- echter App-Prozess mit explizitem `/private/tmp`-Store,
- `lsof` bestätigte ausschließlich den expliziten Store,
- SQLite-`quick_check` und New-Eden-Nexus-Signaturtabellen erfolgreich,
- fremder globaler `default.store` vor und nach der Prüfung mit identischem
  SHA-256, identischer Größe und identischem Änderungszeitpunkt.

