# ADR-0008 – Versionierter SDE-Stammdatenkatalog

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P08

## Kontext und Problem

P07 erzeugt ein formal geprüftes und gehashtes `.nensde`-Paket, aber noch
keinen fachlich nutzbaren Datenstand. P08 muss große statische Daten
referenzgeprüft speichern, ohne einen unvollständigen Import sichtbar zu
machen oder ältere Rezepte zu überschreiben.

Der reale offizielle Build 3424810 zeigt außerdem zwei relevante
Quellbesonderheiten: IDs und Aktivitätszeiten können `0` sein, und 21
Blueprint-Typreferenzen besitzen keinen Eintrag in `types.jsonl`.

## Entscheidungstreiber

- Local First und reproduzierbare SDE-Stände,
- additive Migration ohne Verlust vorhandener Benutzerdaten,
- vollständige Validierung vor Aktivierung,
- atomarer Sichtbarkeitswechsel,
- Erhalt älterer Rezeptversionen,
- keine erfundenen Ersatz-Itemdaten,
- exakte, indizierte Lookups für P09/P10,
- testbare Schichtengrenzen.

## Betrachtete Alternativen

### A. Aktuellen Datenstand in-place überschreiben

Das spart Speicher, entfernt aber den Rückfallstand und kann historische
Projekte fachlich umdeuten.

### B. Für fehlende Typreferenzen Platzhalter-Items erfinden

Das hält alle Verweise formal geschlossen, würde aber nicht offizielle Namen
und Eigenschaften als Stammdaten ausgeben.

### C. Jeden SDE-Stand unveränderlich speichern und über einen Aktivmarker wählen

Deterministische, eindeutige Identitätsschlüssel enthalten den Inhalts-SHA.
Eine neue Version wird vollständig angelegt und erst mit demselben Save aktiv.
Fehlende Quellreferenzen bleiben als externe ID erhalten und werden explizit
als nicht aufgelöst markiert.

### D. Den gesamten Import bei jeder fehlenden offiziellen Typreferenz ablehnen

Diese strengste Variante verhindert mit dem aktuellen offiziellen Archiv jede
Aktivierung, obwohl die Inkonsistenz erkannt und isoliert werden kann.

## Entscheidung

Alternative C wird umgesetzt:

- `NexusSchemaV2` 2.0.0 ergänzt acht Stammdatenentitäten.
- Schema v1 → v2 ist additive Lightweight-Migration.
- `StaticDataVersion` bindet Build, Inhalts-SHA, Quelle, Counts und Aktivstatus.
- Alle Stammdatensätze erhalten eindeutige zusammengesetzte `identityKey`s.
- Gruppen-/Kategorie-, Typ-/Gruppe- und Blueprint-Typ-Referenzen sind vor dem
  Schreiben zwingend aufgelöst.
- Material-/Produktreferenzen speichern zusätzlich `typeIsResolved`.
- Nicht aufgelöste offizielle Verweise werden gezählt, nicht erfunden oder
  stillschweigend gelöscht.
- Eine Version wird in einem Save geschrieben und aktiviert; Fehler führen zu
  Rollback.
- Alte Versionen bleiben inaktiv erhalten.
- Gleicher Hash ist idempotent; gleiche Buildnummer mit anderem Hash ist ein
  Konflikt.

## Positive Folgen

- P09/P10 erhalten einen reproduzierbaren lokalen Katalog.
- Historische Datenstände bleiben verfügbar.
- Ein abgebrochener oder fehlerhafter Import wird nicht aktiv.
- Offizielle Quellinkonsistenzen sind sichtbar und maschinenprüfbar.
- Exakte Lookup-Schlüssel besitzen SwiftData-Unique-Indizes.

## Negative Folgen

- Mehrere vollständige Stände benötigen zusätzlichen Speicher.
- Namenssuche erhält erst P09 einen eigenen Suchpfad.
- P10 muss nicht aufgelöste Rezepte explizit behandeln.
- SDE-Skillanforderungen und Marktgruppenentitäten sind noch nicht persistiert.
- Automatische Backupauslösung vor Migration bleibt P36.

## Daten- und Sicherheitswirkung

Die Migration fügt ausschließlich neue Entitäten hinzu. Bestehende Charakter-
und Projektdaten behalten Modellnamen, Felder und Werte. Tests verwenden
temporäre Stores. Der offizielle Realstand lag nur temporär außerhalb des
Repositorys und wurde nicht eingecheckt.

Backups tragen ab P08 Schemaversion 2.0.0. Restore akzeptiert 1.0.0 weiterhin
als migrierbaren Vorgänger, aber keine unbekannte zukünftige Version.

## Verifikation

- Migration 0.9.0 → 1.0.0 → 2.0.0 und direkte 1.0.0 → 2.0.0,
- synthetische Mapping-, Referenz-, Aktivierungs- und Rollbacktests,
- Debug-/Release-Build und vollständige Testläufe,
- offizieller Build 3424810 end-to-end bis Wiederöffnung des SwiftData-Stores,
- gesonderter Diff-, Architektur-, Datenwirkungs- und Dokumentationsreview.

## Folgearbeiten

- P09: indizierter Item- und Blueprintkatalog,
- P10: Rezeptresolver mit sichtbarer Ablehnung nicht aufgelöster Verweise,
- P34: Messbudgets und Versionenrotation bei großen Datenständen,
- P36: automatische Vor-Migrations-Sicherung und Recovery-Drill.
