# ADR-0001 – Modul- und Schichtenarchitektur

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P02

## Kontext und Problem

Der Ausgangsstand bestand aus einem ausführbaren SwiftPM-Target. SwiftUI, SwiftData-Modelle, Persistenzzugriffe, SSO, Keychain, Network und Python-Prozessadapter waren gemeinsam kompiliert. Künftige Produktionsberechnungen hätten dadurch leicht UI- oder Infrastrukturschnittstellen übernommen.

Gleichzeitig dürfen die bestehenden SwiftData-Modelle nicht ohne geprüfte Migration in ein anderes Modul verschoben werden.

## Entscheidungstreiber

- Local-/Offline-First-MVP,
- deterministische und isoliert testbare Fachlogik,
- Abhängigkeitsregeln möglichst zur Compile-Zeit,
- kleine, risikoarme Migration aus dem Ist-Stand,
- Schutz existierender SwiftData-Stores,
- keine leeren Architekturtargets,
- spätere austauschbare Persistenz- und Importadapter.

## Betrachtete Alternativen

### A. Ein Target mit Ordnerkonventionen

Vorteile:

- geringster Umbau,
- keine neuen Targetimporte.

Nachteile:

- Grenzen sind nur Konvention,
- Domain kann unbemerkt SwiftUI oder SwiftData importieren,
- spätere Kopplung bleibt wahrscheinlich.

### B. Vollständige Aufteilung einschließlich UI und Persistence in P02

Vorteile:

- sofortige physische Trennung aller Bereiche.

Nachteile:

- sehr großer Refactor,
- SwiftData-Schemaidentität und Benutzerdaten wären ohne P03-Migration gefährdet,
- zahlreiche Views müssten gleichzeitig umgebaut werden,
- überschreitet den kleinsten tragfähigen P02-Umfang.

### C. Inkrementelle SwiftPM-Schichtung

Domain, Application und Infrastructure werden als echte Targets eingeführt. Das ausführbare Target bleibt vorübergehend Presentation, bestehende Persistenz und Composition Root. Persistence folgt kontrolliert in P03.

Vorteile:

- Compile-Time-Grenzen für neuen Fachcode,
- bestehendes Verhalten und SwiftData-Typen bleiben erhalten,
- kleine, testbare Migration,
- keine spätere Live-Datenabhängigkeit des Fachkerns.

Nachteile:

- App-Target bleibt vorübergehend gemischt,
- direkte SwiftData-Zugriffe in Views bestehen bis zu späteren Prompts,
- Persistence ist zunächst nur dokumentierter Zielbereich.

## Entscheidung

Alternative C wird umgesetzt.

Targets:

- `NewEdenNexusDomain`,
- `NewEdenNexusApplication`,
- `NewEdenNexusInfrastructure`,
- `NewEdenNexus` als ausführbarer Übergangstarget.

Dependency-Richtung:

```text
App ──> Infrastructure ──> Application ──> Domain
App ─────────────────────> Application ──> Domain
```

Domain und Application erhalten zusätzlich automatisierte Importgrenzentests. Persistente `@Model`-Typen bleiben bis P03 im bisherigen Modul.

## Begründung

Die inkrementelle Variante schafft für alle neuen MVP-Berechnungen sofort eine harte innere Grenze, ohne ungetestete Datenmigration oder flächendeckenden UI-Umbau. Sie folgt dem Projektbuchprinzip der Schichtentrennung, priorisiert aber den reduzierten MVP und die reale Ausgangslage.

## Positive Folgen

- Domain und Application bauen unabhängig von SwiftUI und SwiftData.
- konkrete Adapter können ausgetauscht und injiziert werden.
- Tests können Fachregeln ohne App, Datenbank oder Netzwerk ausführen.
- P03 erhält einen klaren Zielpunkt für Persistence.
- Zukunftscode zwingt dem MVP-Kern keine Live-Abhängigkeit auf.

## Negative Folgen

- `NewEdenNexus` enthält weiterhin SwiftUI, SwiftData und Future-Code.
- bestehende Views greifen weiterhin direkt auf SwiftData zu.
- die physische Presentation-/Persistence-Trennung ist noch nicht vollständig.
- zusätzliche Targets erhöhen die Package-Komplexität geringfügig.

## Migrations- und Rückfallstrategie

P03 erfasst zuerst Schema und Storeidentität, bevor persistente Typen verschoben werden. Scheitert die neue Targetstruktur, können die drei neuen Targets zurückgebaut werden, da P02 keine persistente Schemaänderung einführt. Ein Rückfall auf ein einzelnes Target ist jedoch nur mit dokumentierter neuer Entscheidung zulässig.

## Betroffene Prompts

- P03: Persistence und Migrationen,
- P04: Fehler/Logging,
- P05: Testfundament,
- P07: SDE-Adapter,
- P11 bis P32: produktive Use Cases und Presentation-Anbindung.

## Bekannte offene Punkte

- SwiftData-Repositories und Modellmapping,
- Composition der ersten produktiven Use Cases,
- Umgang mit bestehendem SSO-/Future-Code,
- zentrale Konfiguration und Fehlerdarstellung.
