# ADR-0057 – Gruppierte Build-or-Buy-Auswahl

Datum: 2026-07-28  
Status: angenommen mit offenem Eigentümer-Sichttest

## Kontext

Der Produktionsworkspace bot jede herstellbare Zwischenstufe ausschließlich
als einzelne Build-or-Buy-Entscheidung an. In großen Produktionsketten war
eine einheitliche Entscheidung, beispielsweise alle Reaktionen zu kaufen,
dadurch unnötig aufwendig.

## Entscheidung

- Die Präsentationsprojektion ordnet Zwischenstufen anhand der bereits im
  Graphen gespeicherten Rezeptmerkmale den Gruppen **Produktion**,
  **T2 und Invention** oder **Reaktionen** zu.
- Erscheint dieselbe Type-ID mit widersprüchlichen Kategorien, wird sie
  sichtbar als **Weitere Produktionsstufen** geführt. Es wird keine
  Fachzuordnung geraten.
- Jede Gruppe besitzt die Entwurfsaktionen **Alle bauen** und **Alle kaufen**.
  Einzelentscheidungen bleiben aufklappbar.
- Gruppenaktionen transformieren ausschließlich den lokalen
  Entscheidungsentwurf. Berechnung und Speicherung verwenden unverändert den
  zentralen P26-Plan sowie Vorschau und ausdrückliche Bestätigung.
- Persistiert werden weiterhin einzelne projektbezogene Type-ID-
  Entscheidungen. Schema v25 und alle Benutzerdaten bleiben unverändert.

## Folgen

Einkaufsliste und Projektbudget reagieren ohne zusätzliche Berechnungslogik
auf die wirksamen Einzelentscheidungen. Eine später wieder auf **Bauen**
gesetzte Oberstufe verwendet die zuvor gewählte Gruppenpräferenz weiterhin.
Automatische Empfehlungen und preisbasierte Optimierung bleiben außerhalb
dieser Entscheidung.
