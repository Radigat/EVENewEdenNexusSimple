# ADR-0063 – Eindeutige veröffentlichte Rezeptauswahl

Status: Akzeptiert  
Datum: 2026-07-30  
Prompt: KI-062/OFF-061

## Kontext

Der offizielle SDE-Build 3.448.696 enthält für einzelne Produkte neben dem
veröffentlichten Fertigungs- oder Reaktionsrezept weiterhin unveröffentlichte
Test- beziehungsweise Legacy-Blueprints. Für `Tungsten Carbide` liefern
beispielsweise sowohl der unveröffentlichte `Test Reaction Blueprint`
(45732) als auch die veröffentlichte `Tungsten Carbide Reaction Formula`
(46207) einen Reaktionskandidaten.

Der bisherige P10-Vertrag prüfte die Kandidatenanzahl vor dem
Veröffentlichungsstatus. Dadurch erschien ein fachlich eindeutig
veröffentlichtes Rezept fälschlich als mehrdeutig und blockierte den
Produktionsgraphen mit `NEN-GRAPH-001`.

## Entscheidung

- Bei einer impliziten Rezeptwahl nehmen vorhandene veröffentlichte
  Blueprintkandidaten allein an der Eindeutigkeitsprüfung teil.
- Genau ein veröffentlichter Kandidat wird deterministisch ausgewählt.
- Mehrere veröffentlichte Kandidaten bleiben als echte Mehrdeutigkeit
  blockiert.
- Existiert kein veröffentlichter Kandidat, bleibt das bisherige
  Fail-closed-Verhalten erhalten; ein unveröffentlichtes Rezept wird nicht
  verwendbar gemacht.
- Eine explizit angeforderte Blueprint-ID wird niemals durch ein anderes
  Rezept ersetzt. Ist sie unveröffentlicht, wird sie weiterhin abgelehnt.
- Veröffentlichung des Zielprodukts, vollständige Typreferenzen,
  Aktivversion und alle übrigen P10-Validierungen bleiben unverändert.

## Folgen

Der Resolver kann offizielle SDE-Restdaten von tatsächlich nutzbaren
Rezepten unterscheiden, ohne nach Blueprint-ID, Outputmenge oder einem
anderen unbelegten Kriterium zu priorisieren. Es gibt keine Schema-,
Migrations- oder Benutzerdatenänderung.

Eine reale, ausschließlich temporäre Kopie des Xcode-Laufstores erzeugte
nach der Korrektur den Graphen für `Multispectrum Shield Hardener II`
vollständig mit 566 Knoten und 565 Kanten.
