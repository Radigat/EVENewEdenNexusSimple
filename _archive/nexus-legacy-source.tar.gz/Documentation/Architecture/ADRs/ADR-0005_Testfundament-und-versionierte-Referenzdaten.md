# ADR-0005 – Testfundament und versionierte Referenzdaten

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P05

## Kontext und Problem

Nach P04 existierten 34 erfolgreiche Tests, aber gemeinsame Testwerte, Projekt-Builder und temporäre Storepfade waren lokal in einzelnen Tests verteilt. Ein versioniertes, offline ladbares Referenzpaket fehlte. Gleichzeitig sind SDE, Produktionsgraph und die eigentlichen T1-/T2-/Reaktionsregeln noch nicht implementiert.

## Entscheidungstreiber

- reproduzierbare und isolierte Tests,
- keine produktiven Benutzerdaten oder Storepfade,
- feste Sollwerte für vorhandene Regeln,
- wiederverwendbare Testhelfer ohne Produktabhängigkeit,
- versionierbare Erweiterung durch spätere Fachprompts,
- keine vorgezogenen oder erfundenen EVE-Rezepte,
- providerneutraler lokaler und CI-fähiger Prüfweg.

## Betrachtete Alternativen

### A. Helfer in jedem Testtarget duplizieren

Vorteil ist die kleinste Packageänderung. Dagegen stehen driftende Standardwerte, mehrfach implementierte Storebereinigung und keine gemeinsame Fixture-Versionierung.

### B. Testhelfer in produktive Targets verschieben

Die Helfer wären leicht importierbar, würden aber Testbelange in Domain oder Persistence veröffentlichen und den produktiven API-Umfang unnötig erweitern.

### C. Gemeinsamer nicht exportierter TestSupport-Target

Ein SwiftPM-Target unter `Tests/` enthält Loader, Builder, temporäre Pfade und Ressourcen. Er hängt nur von Domain ab, wird nicht als Package-Produkt exportiert und nur von Testtargets verwendet.

### D. Bereits echte EVE-Produktionsreferenzen festschreiben

Dies würde die spätere SDE- und Regelverifikation vorwegnehmen. Unbestätigte Rezeptwerte könnten als vermeintliche fachliche Wahrheit dauerhaft Regressionstests prägen.

## Entscheidung

Alternative C wird umgesetzt. Alternative D wird ausdrücklich verworfen.

- Target: `NewEdenNexusTestSupport`.
- Ressource: `Fixtures/Foundation/v1/foundation-reference.json`.
- Datensatzversion: `1.0.0`.
- kompatibles produktives Schema: `1.0.0`.
- Datenklassifikation: `synthetic`.
- SDE- und ESI-Version bleiben leer.
- Loader prüft Datensatzversion, Schemaversion, vorhandene Fälle und eindeutige Test-IDs.
- Builder verwenden feste UUIDs und Zeitwerte.
- temporäre Storepfade liegen außerhalb produktiver Datenverzeichnisse.
- `Scripts/ci-verify.sh` ist der providerneutrale Gesamteinstieg.

## Referenzumfang

P05 friert nur bereits implementierte Regeln ein:

- `MAT-REF-001`: Gruppierung, Sortierung, negative Mengenbegrenzung und Rundung,
- `MAT-REF-002`: leere Materialaggregation,
- `PROJECT-REF-001`: Projektidentität, feste Zeitwerte und Namensnormalisierung.

Das synthetische Referenzprodukt ist weder SDE-Item noch Blueprintrezept.

## Positive Folgen

- spätere Fachprompts können stabile Fixtures ergänzen,
- Testwerte und Schemaerwartung sind maschinenlesbar versioniert,
- Persistenztests verwenden einen gemeinsamen isolierten Pfadhelfer,
- Domainreferenzfälle laufen ohne App, Datenbank oder Netzwerk,
- CI-Anbieter müssen keinen eigenen Befehlsablauf erfinden.

## Negative Folgen

- ein zusätzlicher SwiftPM-Target erhöht den Testgraph geringfügig,
- die erste Fixture-Version deckt bewusst nur vorhandene Grundlagen ab,
- UI-, Last-, Backup-, Import- und vollständige Produktionsreferenzen fehlen weiterhin.

## Daten- und Sicherheitswirkung

Das produktive SwiftData-Schema bleibt unverändert. Das Referenzpaket enthält keine echten Tokens, Accountdaten, persönlichen Informationen oder Corporation-Daten. Temporäre Stores werden in eindeutigen Verzeichnissen erzeugt und nach den Tests entfernt.

## Verifikation

- `swift package describe`,
- Debug- und Release-Build,
- Debug-Testlauf mit Coverage,
- Release-Testlauf,
- 40 Tests ohne Fehler oder Überspringen,
- Prüfung des Ressourcenmanifests, der Versionsfehler, Builderwerte, Storebereinigung und aller drei Sollwertfälle,
- statische Secret-, Force-Unwrap- und Skriptprüfung.

## Folgearbeiten

- P06: Backup-/Restore-Fixtures,
- P07 bis P10: versionierte SDE- und Importdaten,
- P13 bis P19: verifizierte Produktionsreferenzprojekte,
- P20 bis P31: Bestands-, Reservierungs-, Preis- und Einkaufslistenfälle,
- P34/P35/P37: Performance-, UI- und Releaseabnahme.
