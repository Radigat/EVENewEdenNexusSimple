# ADR-0027 – Projektbezogene Verfügbarkeit und Schema v12

Status: **Akzeptiert**  
Datum: 2026-07-24  
Prompt: P22

## Kontext

P19 liefert den aggregierten Bruttobedarf, P20/P21 liefern lokale manuelle
und importierte Bestände. Vor Sicherheitsbeständen und Reservierungen muss
eindeutig festgelegt werden, welche physischen Mengen ein Projekt überhaupt
einbeziehen darf. Persistierte Ergebniszahlen würden nach jeder
Bestandsänderung veralten.

## Entscheidung

- Verfügbarkeitsregeln werden je Projekt, Ergebnisse dagegen nicht
  persistiert.
- Die Domain berechnet ausschließlich mit `Int64`, deterministisch und mit
  Überlaufprüfung.
- Ausschlüsse folgen der festen Reihenfolge Archiv, Lagerauswahl,
  Materialregel und Mengenobergrenze.
- Jede ausgeschlossene Menge wird genau einer Stufe zugerechnet.
- Preview und Apply sind getrennt; Apply benötigt Bestätigung und einen
  unveränderten Quellzustand.
- Neue unbekannte Regeln werden abgelehnt. Gespeicherte Regeln für
  inzwischen nicht mehr benötigte Materialien bleiben sichtbar und
  ungenutzt, damit keine Benutzerentscheidung still verloren geht.
- Schema v12 ergänzt nur
  `InventoryAvailabilityConfigurationRecord`; die v11→v12-Migration
  erfindet keine Konfiguration.
- P23 bis P25 dürfen den P22-Wert nicht als endgültig frei verfügbar
  bezeichnen, sondern bauen ihre Schutz- und Reservierungsabzüge darauf auf.

## Folgen

- Gleichartige Eingaben erzeugen reproduzierbare Detailzeilen.
- Änderungen an Projekt, Graph, Lager, Bestand oder Konfiguration
  invalidieren eine alte Vorschau.
- Der Benutzer sieht die Wirkung jeder Freigaberegel vor dem Schreiben.
- Sicherheitsbestand und Reservierung können später ergänzt werden, ohne
  die physische P22-Basis umzudeuten.
- Ein Projekt ohne gespeicherten Datensatz verwendet explizit alle aktiven
  Lager; dieser Standard wird erst nach bestätigter Änderung gespeichert.

## Verwarfene Alternativen

- globale statt projektbezogener Regeln,
- direktes Speichern beim Umschalten eines Filters,
- Persistieren berechneter Verfügbarkeitszahlen,
- Vermischen von physischer Verfügbarkeit, Schutzbestand und Reservierung,
- stilles Löschen nicht mehr verwendeter Regeln,
- Gleitkomma- oder ungeprüfte Ganzzahlsummen.

## Nachweis

Domain-, Application-, Persistence-, Migrations-, Backup- und
UI-Architekturtests; SwiftPM und Xcode Debug/Release jeweils 371 Tests;
Schema-v11→v12-Bestandsschutz und zweite Öffnung.
