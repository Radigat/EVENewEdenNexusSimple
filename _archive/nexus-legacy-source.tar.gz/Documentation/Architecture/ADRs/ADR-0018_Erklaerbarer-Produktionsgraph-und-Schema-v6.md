# ADR-0018 – Erklärbarer Produktionsgraph und Schema v6

Status: Akzeptiert  
Datum: 2026-07-24  
Prompt: P13

## Kontext

Nach P12 besitzt ein Produktionsprojekt ein kataloggebundenes Ziel und ein
eindeutig auflösbares Rezept. Für Runs, ME und mehrstufige Ketten wird eine
stabile Graphbasis benötigt, die gleiche Typen in unterschiedlichen
Vorkommen nicht zusammenzieht, nachvollziehbar persistiert werden kann und
keine UI- oder SwiftData-Abhängigkeit in die Fachlogik trägt.

## Entscheidung

1. Der Domain-Snapshot ist eine unveränderliche, sendbare
   Knoten-Kanten-Struktur mit versioniertem Payloadformat.
2. Knoten besitzen Vorkommens-IDs; CCP-Type-IDs sind fachliche Referenzen,
   aber keine Knotenidentität.
3. Kanten enthalten in P13 ausschließlich positive rohe
   Rezeptmaterialmengen. Runs, ME und Aggregation werden nicht vorgezogen.
4. Der Application-Service verwendet das exakt im Projekt gespeicherte
   Blueprint und dieselbe Katalogprovenienz. Er speichert erst nach
   vollständiger Validierung.
5. Schema v6 ergänzt additiv genau einen kanonisch codierten
   `ProductionGraphRecord` je Projekt.
6. Zyklen, unerreichbare Knoten, inkonsistente Tiefen, ungültige Endpunkte
   und unpassende Elternrezepte blockieren Speicherung und Laden.
7. Ein bestehender Snapshot bleibt bei Resolver-, Validierungs-,
   Abbruch- oder Persistenzfehlern erhalten.

## Folgen

### Positiv

- spätere Berechnungsschritte arbeiten auf einer deterministischen,
  UI-unabhängigen Struktur,
- gleiche Materialien dürfen in mehreren Produktionszweigen vorkommen,
- Persistenz, Migration und Backups sind versioniert,
- Benutzer können Herkunft, Aktivität und Rezeptbezug jeder Kante
  nachvollziehen,
- Veraltetheit ist prüfbar, ohne automatisch Benutzerdaten zu überschreiben.

### Einschränkungen

- P13 zeigt nur die erste Rezeptstufe und rohe Mengen,
- die Graph-ID wird pro Erzeugung neu vergeben; die Topologie ist
  deterministisch, nicht der Nachweiszeitpunkt,
- echte mehrstufige Ketten sowie Mengenaggregation bleiben P16 bis P19.

## Verworfene Alternativen

- **Type-ID als Knoten-ID:** würde mehrere fachlich unterschiedliche
  Vorkommen vorzeitig zusammenführen.
- **Graph nur flüchtig in der View:** wäre nicht reproduzierbar und nicht
  migrier- oder backupfähig.
- **SwiftData-Modelle als Domainmodell:** würde Fachlogik und Persistenz
  koppeln.
- **Runs und Rekursion bereits in P13:** würde unbestätigte Rundungsregeln und
  den Scope späterer Prompts vorziehen.

## Prüfnachweis

- Domain-, Application-, Persistenz-, ViewModel- und Architekturtests,
- additive v5→v6-Migration und leerer Schema-v6-Store,
- Debug/Release über SwiftPM und Xcode,
- echter isolierter App-Prozess mit konsistentem Schema-v6-Store.

