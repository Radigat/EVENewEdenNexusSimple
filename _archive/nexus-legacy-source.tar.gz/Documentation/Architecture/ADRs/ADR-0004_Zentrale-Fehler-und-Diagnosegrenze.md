# ADR-0004 – Zentrale Fehler- und Diagnosegrenze

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P04

## Kontext

Vor P04 behandelte der App-Target Fehler lokal und uneinheitlich. Der Datenbankstart verwendete `fatalError`, drei SwiftData-Speicherpfade verwarfen Fehler mit `try?`, und die Accountansicht zeigte ungefiltertes `localizedDescription`. Ein Logger-Port und verbindliche Redaktionsregeln fehlten.

Ein zentraler Fehlerpfad muss Application- und UI-Grenzen einhalten, ohne technische Frameworks in Domain oder Application einzuführen und ohne sensible EVE-/Benutzerdaten zu protokollieren.

## Entscheidungstreiber

- kein App-Absturz bei lokalem Datenbankfehler,
- keine verschluckten Schreibfehler,
- sichere, verständliche UI-Texte,
- strukturierte und korrelierbare Diagnosen,
- keine Tokens, Namen, Pfade oder Serverantworten in Logs,
- testbare Abstraktion ohne OSLog in Application,
- keine globale veränderliche Loggerinstanz,
- kein Datenbankreset oder Leerstore-Fallback.

## Alternativen

### A. Lokale Alerts und `print`

Vorteil: minimale Änderungen.

Nachteile: keine Taxonomie, keine einheitlichen Redaktionsregeln, schlecht testbar, keine zentrale Korrelation.

### B. OSLog direkt in Views und Repositories

Vorteil: direkter Zugriff auf Unified Logging.

Nachteile: Frameworkkopplung in inneren Schichten, Duplikate, hohes Risiko ungefilterter Werte, schwer austauschbar.

### C. Application-Port plus zentraler App-Runtime und OSLog-Adapter

Application definiert sichere Fehler-/Diagnosetypen und den Logger-Port. Infrastructure implementiert Unified Logging. Der App-Target setzt den Adapter zusammen und präsentiert sichere Fehler.

Vorteile: klare Abhängigkeiten, testbare Redaction, einheitlicher UI-Fluss, austauschbarer Adapter.

Nachteile: zusätzlicher Mappingaufwand; UI-Texte benötigen später eine vollständige Lokalisierungsstrategie.

## Entscheidung

Alternative C wird umgesetzt.

- `NexusFailureMapper` erzeugt sichere `NexusFailure`-Werte.
- `DiagnosticLogging` ist der Application-Port.
- `UnifiedDiagnosticLogger` ist der OSLog-Adapter in Infrastructure.
- `NexusAppRuntime` ist die injizierte zentrale Fehler- und Startzustandsgrenze im App-Target.
- `DiagnosticValue` verlangt eine bewusste Public-/Private-Einstufung.

## Datenschutz

Die ursprüngliche Fehlerbeschreibung wird nicht in `NexusFailure` übernommen. Logs enthalten nur feste Codes, Operationen, Kategorien, Korrelations-IDs und ausdrücklich sichere technische Metadaten. Private Werte erscheinen ausschließlich als `<redacted>`.

Das OSLog-Subsystem lautet `de.newedennexus.app`; die jeweilige strukturierte Fehlerkategorie wird als OSLog-Kategorie verwendet.

## Fehler- und Datenwirkung

P04 ändert kein SwiftData-Schema und keine gespeicherten Daten.

Bei einem fehlgeschlagenen SwiftData-Speichervorgang wird der `ModelContext` zurückgerollt. Bei Startfehlern bleibt der bestehende Store unangetastet; die App bietet einen Retry über dieselbe versionierte Containerfactory.

Keychain und SwiftData besitzen keine gemeinsame Transaktion. Diese Grenze wird für P38 dokumentiert; P04 führt keine neue SSO-Fachlogik ein.

## Positive Folgen

- kein `fatalError` im produktiven App-Target,
- keine verworfenen aktuellen SwiftData-Speicherfehler,
- sichere zentrale Fehlerdarstellung,
- strukturierte Unified-Log-Ereignisse,
- automatisiert geprüfte Redaction,
- Start-Retry ohne Store-Ersatz,
- Logger-Port bleibt von OSLog entkoppelt.

## Negative Folgen

- UI-Texte sind noch nicht über String Catalogs lokalisiert,
- bestehende Views greifen weiterhin direkt auf SwiftData zu,
- Runtime-Fehler werden aktuell einzeln als Alert und nicht als Verlauf dargestellt,
- kein Diagnoseexport oder persistentes Logarchiv.

## Folgeprompts

- P05: Testfundament und gemeinsame Fixtures,
- P06: Backup/Restore,
- P11 ff.: Application-Use-Cases statt direkter View-Persistenz,
- P33: vollständige Validierungs- und Fehler-UX,
- P35: manuelle Accessibility-/UI-Prüfung,
- P38: SSO-/Keychain-Härtung und Cross-Store-Kompensation.
