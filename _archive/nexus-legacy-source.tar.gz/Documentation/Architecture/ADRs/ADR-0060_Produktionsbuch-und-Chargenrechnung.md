# ADR-0060 – Produktionsbuch als projektgebundene Chargenrechnung

Status: Akzeptiert · 2026-07-29 · umgesetzt mit P57

## Kontext

Die bisherige Projektwirtschaftlichkeit bildet einen Plan ab. Walletbelege
konnten einem Projekt zugeordnet werden, die sichtbare Oberfläche wurde aber
auf Eigentümerwunsch zurückgezogen. Die neue Anforderung benötigt zusätzlich
eine fortlaufende Historie tatsächlich hergestellter und verkaufter Chargen.

## Entscheidung

- Projekt, Produktionscharge, Kostenbeleg und Verkauf bleiben getrennte
  Zustände.
- Eine Charge bindet ihren Plan-/Graphstand und darf durch spätere
  Planneuberechnung nicht verändert werden.
- Walletquellkapazität bleibt auf Projektebene eindeutig. Chargen teilen nur
  bestätigte Projektzuordnungen auf.
- Kosten werden typisiert und mit Quelle/Zeitpunkt gespeichert.
- Marktaufträge zeigen Verkaufsfortschritt; Realgewinn entsteht erst aus
  bestätigten Transaktionen und Gebühren.
- Projekt, Datum, Status, Runs, ME, TE und Output reichen für eine lokale
  Charge. Produktionsort, Charakter, ESI-Job, Blueprintbezug und technische
  IDs sind optionale Provenienz; fehlende Werte werden angezeigt, aber weder
  erfunden noch als Schreibblocker behandelt.
- Metenox bleibt ein eigener Rechner mit versionierten Regeln.

## Alternativen

- Die alte P42-Oberfläche wieder einblenden: verworfen, weil sie keine
  Chargen-, Output- oder Verkaufsmengen führt.
- Excel-Zeile 1:1 persistieren: verworfen, weil Quellen, Teilzuordnungen und
  Regelversionen fehlen.
- Wallettransaktionen automatisch zuordnen: verworfen; Vorschläge bleiben
  schreibfrei bis zur Bestätigung.

## Konsequenzen

P57 benötigt ein additives Schema. P59 benötigt eine kapazitätsgeprüfte
Unterzuordnung bestehender Projektbelege. Migrationen dürfen keine historischen
Chargen oder Zuordnungen erfinden.

## Rollback

Neue Tabellen/Ansichten können deaktiviert werden, ohne Projekte, Budgets,
Wallet-Snapshots oder bestehende Projektzuordnungen zu löschen.
