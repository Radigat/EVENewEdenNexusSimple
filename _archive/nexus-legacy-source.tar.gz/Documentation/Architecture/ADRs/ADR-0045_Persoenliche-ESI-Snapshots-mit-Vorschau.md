# ADR-0045 – Persönliche ESI-Snapshots mit Vorschau

Status: Akzeptiert · 2026-07-26 · P40

## Kontext

Persönliche Assets, Blueprints und Industry Jobs ändern sich extern und
können groß sowie paginiert sein. Eine unmittelbare Übernahme würde lokale
Löschungen unsichtbar machen und manuelle Bestände gefährden.

## Entscheidung

- P40 verwendet exakt drei persönliche Read-Scopes und keine Schreib-,
  Wallet-, Markt- oder Corporation-Scopes.
- Access-Tokens bleiben flüchtig; Refresh-Tokens verbleiben im Keychain.
- Assets und Blueprints werden sequenziell mit `X-Pages`, Seitenvalidatoren,
  konsistentem Last-Modified und festen Größenlimits abgerufen.
- Ein Abruf erzeugt zuerst eine detaillierte, nicht persistierte
  Änderungs­vorschau.
- Nur ausdrückliches Übernehmen aktiviert einen gemeinsamen versionierten
  Snapshot für Assets, Blueprints und Jobs.
- Basisrevision, validiertes Staging und atomarer Dateiaustausch verhindern
  die Übernahme veralteter oder teilweiser Stände.
- Persönliche ESI-Daten bleiben von SDE, SwiftData und manuellen Lagern
  getrennt.

## Folgen

Der letzte gültige Snapshot bleibt offline verfügbar und kann beim Trennen
kompensierbar entfernt werden. Vor dem ersten Abruf ist eine erneute
SSO-Zustimmung zu den drei Scopes erforderlich. Eine automatische
Bestandsverrechnung ist ausdrücklich nicht Teil von P40.
