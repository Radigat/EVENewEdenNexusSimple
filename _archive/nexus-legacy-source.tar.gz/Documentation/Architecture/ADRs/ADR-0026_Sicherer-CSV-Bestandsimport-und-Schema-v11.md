# ADR-0026 – Sicherer CSV-Bestandsimport und Schema v11

Status: **Akzeptiert**  
Datum: 2026-07-24  
Prompt: P21

## Kontext

P20 stellt eindeutige lokale Lager und manuelle Bestände bereit. Ein
CSV-Import kann viele Positionen gleichzeitig verändern und benötigt daher
eine nachvollziehbare Vorschau, positionsgenaue Konfliktentscheidungen und
eine Transaktionsgrenze, die Teilimporte verhindert.

## Entscheidung

- Der Import verwendet eine getrennte Prüf- und Schreibphase.
- Ein Import zielt auf genau ein vorhandenes aktives Lager.
- Type-IDs sind die fachlichen Schlüssel; Namen dienen nur der optionalen
  Gegenprüfung.
- Doppelte Type-IDs werden abgelehnt und niemals still aggregiert.
- Abweichende vorhandene Mengen verlangen je Zeile `Ersetzen` oder
  `Überspringen`.
- Schreiben verlangt eine ausdrückliche Bestätigung und unveränderte
  Lager-, Katalog- und Bestandsvorbedingungen.
- Änderungen und Bericht werden atomar gespeichert.
- Schema v11 ergänzt ausschließlich `InventoryImportRecord`; Rohdatei und
  Pfad werden nicht gespeichert.
- Parser und Dateileser liegen in Infrastructure, Orchestrierung in
  Application, Transaktion in Persistence und Darstellung in Presentation.

## Folgen

- Eine Vorschau kann keine Benutzerdaten verändern.
- Gleichzeitige oder zwischenzeitliche Bestandsänderungen überschreiben
  nichts unbemerkt.
- Ein Neustart kann keinen halben Import sehen.
- P22 kann manuelle und importierte Mengen über dieselbe
  `ManualStockSnapshot`-Quelle auswerten.
- Berichtslöschung, Importhistorienverwaltung und andere Importformate
  bleiben außerhalb von P21.

## Verwarfene Alternativen

- sofortiges Schreiben während des Parsens,
- globale „alle ersetzen“-Entscheidung,
- stillschweigende Addition doppelter CSV-Zeilen,
- Dateiname oder Itemname als fachlicher Primärschlüssel,
- Speicherung der vollständigen Rohdatei.

## Nachweis

Parser-, Service-, Transaktions-, Migrations-, Backup- und
UI-Architekturtests; SwiftPM und Xcode Debug/Release jeweils 353 Tests;
isolierter Schema-v11-App-Store mit erfolgreicher Integritätsprüfung.
