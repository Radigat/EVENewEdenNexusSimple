# ADR-0031 – Build-or-Buy, Lagernetting und Schema v15

Status: Angenommen  
Datum: 2026-07-25  
Prompt: P26

## Kontext

Der P19-Graph beschreibt den vollständigen Produktionsweg. P22–P25
beschreiben verfügbare, geschützte und reservierte Bestände. P26 muss beide
Seiten verbinden, ohne vorhandene Berechnungsregeln zu duplizieren oder
Preise und Optimierung vorzuziehen.

## Entscheidung

1. Der Domainrechner traversiert den validierten Graphen deterministisch und
   führt einen gemeinsamen verfügbaren Pool je CCP-Type-ID.
2. Vorhandene Zwischenprodukte reduzieren die neu nötigen Runs und damit
   die nachgelagerte Materialkette.
3. **Kaufen** ist die einzige gespeicherte Abweichung vom Standard
   **Bauen** und schneidet den verbleibenden Unterbaum an der Type-ID ab.
4. Lagerfilter, Sicherheitsbestand und fremde Reservierungen werden über die
   vorhandenen P22–P24-Rechner bestimmt, nicht neu implementiert.
5. Inventionsmaterialmengen stammen aus dem zum Graphen passenden
   SDE-Rezept. Geplant werden benötigte erfolgreiche Kopien, keine
   geschätzten Fehlversuche.
6. Entscheidungen werden projektbezogen in einem additiven Schema v15
   gespeichert. Vorschau, Bestätigung und optimistische Versionsprüfung
   schützen Schreibvorgänge.
7. Projektduplikate übernehmen Entscheidungen bewusst nicht.

## Konsequenzen

- T1, T2, Invention und Reaktionen liefern einen gemeinsamen Arbeitsplan.
- Bestand wird auch auf Zwischenstufen berücksichtigt und nicht doppelt
  verwendet.
- Veraltete Entscheidungen werden sichtbar und fail-closed behandelt.
- Schema v14 migriert leichtgewichtig; Backupformat ist 15.0.0.
- Die sichtbare SwiftUI-Integration bleibt P32.
- Preise, Empfehlung und erweiterter Einkaufsworkflow bleiben verschoben.

## Nachweis

- 11 fokussierte P26-Tests,
- SwiftPM Debug: 434 Tests,
- Xcode Debug: 434 Tests,
- v14→v15-Migration, Leerstore, Wiederöffnung, Stale-State und
  Backupkompatibilität,
- XcodeGen-Paritätsprüfung mit 15 Targets, sieben Testtargets und zwei
  gemeinsamen Schemes.
