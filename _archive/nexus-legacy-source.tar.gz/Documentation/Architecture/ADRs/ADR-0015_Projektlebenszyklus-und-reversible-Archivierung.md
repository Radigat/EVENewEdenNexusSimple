# ADR-0015 – Projektlebenszyklus und reversible Archivierung

- Status: Akzeptiert
- Datum: 2026-07-24
- Prompt: P11

## Kontext

Das persistente Projektmodell und ein Repository-Port bestanden seit P03.
Die bisherige `ProjectsView` griff jedoch direkt mit `@Query` und
`modelContext` auf SwiftData zu. Statusregeln, Duplizieren, Archivieren und
Wiederherstellen waren nicht als zentrale, testbare Fachgrenze vorhanden.

## Entscheidung

1. Der Lebenszyklus wird in
   `ProductionProjectLifecycleService` innerhalb von Application
   implementiert.
2. Die erlaubten Statuskanten liegen zentral in
   `ProductionProjectStatusPolicy`.
3. Die Presentation verwendet ein `@MainActor`-ViewModel und kennt nur
   Application-/Domain-Typen.
4. Konkrete SwiftData-Composition erfolgt ausschließlich in
   `ProjectAppComposition`.
5. Archivierung ist reversibel; endgültiges Löschen ist nicht Teil von P11.
6. Archivierte Projekte sind schreibgeschützt, dürfen aber dupliziert oder
   nach `Planung` wiederhergestellt werden.
7. Das persistente Schema bleibt v4; P11 fügt keine Felder und keine
   Migration hinzu.

## Folgen

- Fachregeln sind deterministisch und mit fester Uhr/UUID testbar.
- Ungültige Übergänge schreiben nichts.
- `ProjectsView` enthält keinen direkten SwiftData-Zugriff mehr.
- Bestehende Projekte bleiben ohne Migration lesbar.
- Kataloggestützte Zielproduktauswahl bleibt ausdrücklich P12.
- Ein späteres endgültiges Löschen benötigt einen eigenen, bestätigten
  Auftrag mit Abhängigkeits-, Backup- und Recoveryprüfung.

## Nachweis

- Application-Referenztests für alle erlaubten Statuskanten und
  Fehlerpfade,
- dateibasierter Persistenztest mit Wiederöffnung,
- ViewModel-/App-Integrationstests,
- Architektur- und UI-Quelltests,
- vollständige SwiftPM- und Xcode-Suites in Debug und Release.

