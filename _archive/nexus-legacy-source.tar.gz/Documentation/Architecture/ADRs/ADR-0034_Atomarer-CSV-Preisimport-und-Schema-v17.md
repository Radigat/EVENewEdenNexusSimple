# ADR-0034 – Atomarer CSV-Preisimport und Schema v17

Status: **Akzeptiert**  
Datum: 2026-07-25  
Prompt: P28

## Kontext

P27 verwaltete exakte manuelle Preise, besaß aber keinen sicheren
Massenimport. Ein zeilenweises direktes Speichern könnte bei Fehlern
Teilstände erzeugen und vorhandene Werte ohne nachvollziehbare Entscheidung
überschreiben.

## Entscheidung

P28 verwendet den bereits gehärteten P21-CSV-Transport, ergänzt aber einen
eigenen Preisvertrag. Vorschau und Einzelentscheidungen bleiben
schreibfrei. Ein bestätigter Batch prüft Profil, vorhandene Preise und
Katalogprovenienz erneut und speichert Mutationen sowie Bericht atomar.

Importierte Preise tragen Quelle `csv`. Schema v17 ergänzt
`PriceImportRecord` mit einem versionierten, zeilengenauen Bericht. Rohdatei
und Pfad werden nicht persistiert. Berichte folgen dem Lebenszyklus ihres
Profils.

## Konsequenzen

- kein unbemerkter Teilimport,
- Konflikte bleiben benutzerkontrolliert,
- fehlgeschlagene oder veraltete Vorschauen erhalten den Altbestand,
- P29 kann manuelle und CSV-Preise über denselben P27-Auflöser verwenden,
- v16→v17 ist additiv; Backupformat steigt auf 17.0.0.

## Verworfen

- direkte Speicherung beim Einlesen,
- stilles Überschreiben vorhandener Preise,
- Ersetzen des gesamten Profils durch Dateiinhalt,
- Persistieren der Rohdatei oder lokaler Pfade,
- localeabhängige Gleitkommawerte.

## Nachweis

22 fokussierte P28-/Backup-/Fehlerprüfungen sowie jeweils 461 vollständige
SwiftPM-/Xcode-Debugtests. Migration, Leerstore, Wiederöffnung,
Löschkaskade, Stale State, atomarer Bericht und isolierter Schema-v17-App-
Start wurden geprüft.
