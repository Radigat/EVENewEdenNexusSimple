# ADR-0032 – Integrierter Produktionsworkspace

Status: Akzeptiert  
Datum: 2026-07-25  
Prompt: P32

## Kontext

P11–P26 stellten Projekt, Graph, Lagerregeln, Schutz, Reservierungen,
Konflikte und Build-or-Buy als getrennte Dienste und Ansichten bereit. Der
P26-Plan war reproduzierbar, aber nicht als zusammenhängender Arbeitsablauf
bedienbar. Gleichzeitig griff das produktive Dashboard noch direkt auf
SwiftData zu.

## Entscheidung

1. Der vorhandene Graphdialog wird zum projektbezogenen
   Produktionsworkspace erweitert; die erklärbare Graphansicht bleibt
   erhalten.
2. `BuildOrBuyWorkspaceViewModel` verwendet ausschließlich den
   `BuildOrBuyPlanning`-Port. SwiftData-Adapter entstehen nur in
   `ProjectAppComposition`.
3. Bauen ist der sichtbare Standard. Kaufen wird erst nach neuer Vorschau
   und ausdrücklicher Bestätigung über den P26-Service gespeichert.
4. Jobs und Fehlmengen werden nicht erneut berechnet oder persistiert,
   sondern aus dem aktuellen P26-Snapshot dargestellt.
5. Projekt- oder graphfremde sowie veraltete Vorschauen bleiben verborgen.
   Unberechnete Änderungen sperren Speicherung und Zwischenablage.
6. Die Textliste enthält ausschließlich positive Fehlmengen im Format
   `Name<Tab>Menge`.
7. Das Dashboard liest Projekt-Snapshots über einen ViewModel-/Use-Case-Pfad
   statt über `@Query`.

## Folgen

- Ein T1- oder T2/Inventionsprojekt ist über einen durchgehenden lokalen
  Workflow bedienbar.
- Lager, Sicherheitsbestand und Reservierungen werden genau einmal im
  P26-Service verrechnet.
- Der UI-Pfad verändert keine physischen Bestände oder Reservierungen.
- Schema und Backupformat bleiben v15/15.0.0.
- Preise, Kosten, Einkaufsstatus und Exporte bleiben bewusst verschoben.
- Character-/SSO-/ESI-Views mit direktem SwiftData-Zugriff bleiben außerhalb
  des P32-Kerns P38 zugeordnet.

## Nachweis

- fokussierte ViewModel-, Render-, Architektur- und Fehlerpfadtests,
- T1-Bauen/Kaufen, T2-Invention, Lagerabzug, projektfremde Vorschau,
  schmale/breite Rendergröße, Tastatur- und Accessibility-Verträge,
- vollständige SwiftPM- und Xcode-Debug-Suite,
- statische Xcode-/SwiftPM-Projektparität.
