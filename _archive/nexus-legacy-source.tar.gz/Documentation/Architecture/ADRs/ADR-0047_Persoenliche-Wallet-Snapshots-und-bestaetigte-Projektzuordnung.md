# ADR-0047 – Persönliche Wallet-Snapshots und bestätigte Projektzuordnung

Status: Akzeptiert  
Datum: 2026-07-27

## Kontext

P42 soll reale Käufe, Verkäufe und belegte Gebühren nutzbar machen, ohne aus
fungiblen Materialien oder uneinheitlichen Journal-Kontexten eine
Projektzuordnung zu erfinden.

## Entscheidung

- Persönliche Walletdaten werden mit genau einem zusätzlichen Read-Scope aus
  drei offiziellen Charakterendpunkten gelesen.
- Der vollständige Walletstand liegt als eigener revisionsgebundener
  Dateisnapshot außerhalb von SwiftData.
- Nur ausdrücklich bestätigte Teil- oder Vollzuordnungen werden additiv in
  SwiftData-Schema v22 gespeichert.
- Quellmenge, Quellbetrag, Walletrevision und vorhandene Zuordnungen werden
  vor jedem Schreiben erneut geprüft.
- Istwerte werden separat von P29-Planwerten berechnet.
- Charaktertrennung löscht Walletdaten nur nach transparenter Bestätigung und
  nimmt sie in die bestehende Kompensation auf.

## Folgen

Der Workflow bleibt lokal, nachvollziehbar und offline lesbar. Er benötigt
keine Corporation-Daten und keinen zusätzlichen SDE-Import. Automatische
Projektzuordnung und vollständige Buchhaltung bleiben bewusst ausgeschlossen.
