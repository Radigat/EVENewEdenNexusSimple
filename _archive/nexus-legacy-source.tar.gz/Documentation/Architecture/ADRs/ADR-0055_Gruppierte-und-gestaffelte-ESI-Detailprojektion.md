# ADR-0055 – Gruppierte und gestaffelte ESI-Detailprojektion

Status: Akzeptiert mit offenem Eigentümer-Sichttest  
Datum: 2026-07-28  
Kontext: P52/OFF-051

## Entscheidung

Persönliche Assets, Blueprints und aktive Industry Jobs werden in der
Account-Detailansicht alphabetisch nach aufgelöstem Stationsnamen gruppiert.
Stationsgruppen sind zunächst geschlossen. Beim Öffnen werden höchstens 100
Zeilen erzeugt; weitere Zeilen folgen in 100er-Schritten.

Suche und Sortierung arbeiten weiterhin auf dem vollständigen lokalen
Snapshot. Eine Suche öffnet alle Gruppen mit Treffern. Nur die Darstellung
der Industry Jobs filtert exakt den ESI-Status `active`; historische Jobs
bleiben unverändert im Snapshot gespeichert.

Ein einmal je Projektionslauf erzeugter Ortsindex ersetzt die frühere
wiederholte vollständige Asset-Baumauflösung. Gruppierung und Suche laufen
außerhalb des Main Threads; Ergebnisse überholter Suchaufträge werden nicht
mehr veröffentlicht.

## Folgen

- eingeklappte Stationen erzeugen keine Tausenden SwiftUI-Zeilen,
- Stationen bleiben unabhängig von der Zeilensortierung alphabetisch,
- die Suche bleibt vollständig und ist nicht auf sichtbare Zeilen begrenzt,
- ESI-, SDE-, Projekt- und Benutzerdatenmodelle ändern sich nicht,
- historische Jobanzeige kann später als eigener, ausdrücklich gewählter
  Verlauf ergänzt werden.

## Nachweis

17 fokussierte Prüfungen bestanden. Die globale Suche fand einen Treffer
hinter 5.000 Asset-Zeilen; 5.001 Assets wurden im Testlauf in rund 0,064 s
gruppiert. Die vollständige SwiftPM-Suite bestand mit 668/668 Tests.
Apple-Development-signierter Xcode Debug für macOS arm64 bestand mit dem
aktuell gültigen Team als Kommandozeilen-Override.
