# ADR-0012 – SDE-App-Composition, Automation und Retention

Status: akzeptiert mit offenem manuellem UI-Nachweis  
Datum: 2026-07-23

## Kontext

P07A stellt den cachekonformen Metadatencheck bereit, P07B den sicheren
Download-, Staging-, Aktivierungs- und Rollbackpfad. Für die reale App fehlten
eine Composition Root, ein benutzerkontrollierter Lebenszyklus, sichtbare
Status- und Rechtsinformationen, ein bereinigter Diagnoseexport sowie eine
bestätigte Aufbewahrungsregel für alte Katalogversionen.

## Entscheidung

1. `SDEAppComposition` erzeugt alle konkreten Netzwerk-, Datei- und
   SwiftData-Adapter am App-Rand. `SDEManagementViewModel` erhält nur
   injizierbare Closures und importiert weder SwiftData noch konkrete Adapter.
2. `NexusAppRuntime` öffnet zuerst den Benutzerstore und erzeugt danach die
   SDE-Verwaltung. Vor dem ersten Check bereinigt eine kontaktfreie
   `SDEArchiveRecoveryBoundary` abgebrochene Download-/Cacheartefakte; der
   Installationsservice führt Journal-, Import- und Staging-Recovery aus.
   Erst danach läuft der Check nicht blockierend und höchstens nach der
   bestehenden 24-Stunden-Policy. Ein Recoveryfehler verhindert einen neuen
   Updatevorgang.
3. Automatische Prüfung ist standardmäßig aktiv. Download und Installation
   sind getrennte, standardmäßig deaktivierte Opt-ins. Automatische
   Installation verlangt zusätzlich persönliche Bedingungen-Prüfung und
   einen realen, im Schlüsselbund gespeicherten User-Agent-Kontakt.
4. Vorbereitete Archive liegen in einem privaten Cache, werden vor
   Wiederverwendung über Größe und SHA-256 geprüft und nach erfolgreicher
   Installation entfernt.
5. Das Updateprotokoll bleibt das pfadbereinigte P07B-Journal. Ein zusätzlicher
   Diagnoseexport enthält nur strukturierte Build-, Phasen-, Mengen- und
   sichere Fehlerdaten und wird erst nach Vorschau gespeichert.
6. Retention arbeitet zweistufig: Vorschau mit exakten Buildnummern und
   Bestätigungs-ID, danach erneute Zustandsprüfung. Aktive und mindestens eine
   letzte funktionierende Version bleiben geschützt.
7. Die App zeigt die unabhängige Drittanbieterstellung, den am Prüftag
   verlangten CCP-Eigentumshinweis, aktive SDE-Version und ausschließlich
   offizielle Links. Die Ansicht behauptet weder Rechtsberatung noch
   CCP-Genehmigung.

## Folgen

Positiv:

- produktive P07A-/P07B-Verdrahtung ohne konkrete Adapter im ViewModel,
- kontrollierte und abbrechbare Aufgaben ohne parallele Doppelvorgänge,
- sichere Defaults und unveränderte Offline-Nutzbarkeit,
- Keychain statt Quellcode oder Preferences für den Kontakt,
- nachvollziehbare Retention mit Bestandsschutz,
- diagnosefähige UI ohne Secrets, Kontakte oder lokale Pfade.

Einschränkungen:

- die tatsächliche Fenster-, Tastatur- und VoiceOver-Abnahme mit
  datenschutzneutralen Screenshots konnte im reinen SwiftPM-Stand nicht
  erbracht werden,
- P09B muss nach Erzeugung des echten Xcode-App-Bundles den P07C-UI-Smoke-Test
  wiederholen,
- vor P37 werden die dann aktuellen CCP-Texte und Releasepflichten erneut
  persönlich geprüft.

## Nachweise

- 167 Tests in Debug und Release,
- Application-Policy-, Scheduler-, Parallelitäts- und Offlinefälle,
- Start-Recovery mit Erfolgs- und Fehlerpfad,
- Cache-Integrität, Logreihenfolge und Diagnose-Redaction,
- Retention mit exakter Bestätigung und Erhalt von Benutzerprojekten,
- statischer Composition-/UI-/Accessibility-/Rechtstexttest,
- Debug-/Release-Build erfolgreich.
