# ADR-0033 – Exakte ISK-Preisprofile und Schema v16

Status: **Akzeptiert**  
Datum: 2026-07-25  
Prompt: P27

## Kontext

Die vorhandene flache Materialaggregation verwendete `Double`-Preise nur
als DTO-Testwert. Wiederverwendbare Profile, Persistenz, Gültigkeit und eine
explizite Behandlung fehlender Preise fehlten. Binäre Gleitkommazahlen sind
für persistente Kostenwerte nicht reproduzierbar genug.

## Entscheidung

Manuelle Einheitspreise werden als positive `Int64`-Hundertstel ISK
modelliert. Profile und Preise erhalten getrennte Domainmodelle,
Application-Ports und additive SwiftData-Entitäten in Schema v16.

Ein Preis ist über `(profileID, typeID)` eindeutig, besitzt
SDE-Provenienz, Quelle `manual` sowie ein inklusives `validFrom` und ein
optionales exklusives `validUntil`. Fehlende oder zeitlich ungültige Werte
bleiben explizit fehlend. Profilwechsel und Löschungen sind
benutzerkontrollierte atomare Operationen.

## Konsequenzen

- keine Rundungsdrift bei Speicherung und Wiederöffnung,
- P28 kann später weitere Quellen ergänzen, ohne P27 umzudeuten,
- P29 erhält eine klare Preisauflösung samt fehlenden Type-IDs,
- v15→v16 ist additiv und erfindet keine Profile oder Preise,
- Backupformat und aktuelle Schemaversion steigen auf 16.0.0,
- Projekte, Graphen, Lager und Build-or-Buy bleiben von Profilwechseln
  unberührt.

## Verworfen

- `Double` als persistenter Preis: nicht exakt reproduzierbar,
- Name als Itemschlüssel: nicht stabil; CCP-Type-ID bleibt Fachschlüssel,
- fehlende Preise als null ISK: fachlich irreführend,
- automatische Profilaktivierung bei bloßer Auswahl: nicht ausreichend
  benutzerkontrolliert.

## Nachweis

13 fokussierte Domain-, Application-, Persistenz-, ViewModel- und
Architekturtests sowie jeweils 453 vollständige SwiftPM-/Xcode-Debugtests.
Die v15→v16-Migration, Wiederöffnung, Kaskadenlöschung, Backupformat 16.0.0
und ein isolierter App-Start mit zwei neuen Tabellen wurden geprüft.
