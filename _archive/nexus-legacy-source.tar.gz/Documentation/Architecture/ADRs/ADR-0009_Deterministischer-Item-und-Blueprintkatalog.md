# ADR-0009 – Deterministischer Item- und Blueprintkatalog

Status: Akzeptiert  
Datum: 2026-07-23  
Prompt: P09

## Kontext

P08 speichert versionierte statische Daten atomar, bietet aber noch keine
stabile Application-Grenze für Produktauswahl und nachgelagerte
Rezeptauflösung. Direkte SwiftData-Abfragen aus Views würden Schichten
vermischen. Ein vollständiges Laden von mehr als 52.000 Itemtypen in den
Speicher wäre unnötig und erschwerte messbare Begrenzung.

Namenssuche muss bei Groß-/Kleinschreibung und Diakritika reproduzierbar sein.
Gleichzeitig unterstützt das Mindestziel macOS 14 nicht den in neueren
SwiftData-Versionen verfügbaren nicht-eindeutigen `#Index` in der hier
benötigten Form.

## Entscheidung

1. Application definiert `ItemBlueprintCatalogReading`, eigenständige
   Use-Cases und vollständig SwiftData-freie Ergebnis-/Filtertypen.
2. Persistence implementiert den Port als `@ModelActor`.
3. Jede Abfrage verlangt genau eine aktive SDE-Version und begrenzt alle
   Lookups auf deren Inhalts-SHA.
4. Namen werden zentral kanonisiert. Schema v3 speichert den Schlüssel
   `ItemType.searchName`; eine benutzerdefinierte v2→v3-Migration füllt ihn für
   bestehende Stores.
5. Treffer werden nach `searchName` und externer Type-ID sortiert.
6. Limits liegen zwischen 1 und 100. Ein zusätzlicher Treffer ermittelt
   `hasMore`; einfache Suchen laden höchstens `limit + 1` Itemzeilen.
7. Produktionsbezüge bleiben rohe, transparente Katalogdaten. P09 wählt kein
   Rezept und erhält `typeIsResolved`.
8. Fehlende Datensätze sind typisierte `notFound`-Ergebnisse. Versions-,
   Konsistenz- und Persistenzfehler bleiben unterscheidbar.
9. Ein reproduzierbarer 50.000-Item-Test misst Laufzeit und tatsächlich
   geladene Itemzeilen. Ein nativer nicht-eindeutiger Index wird erst bei
   Plattformverfügbarkeit und nachgewiesenem Bedarf ergänzt.

## Geprüfte Alternativen

### Direkte SwiftData-Abfragen aus SwiftUI

Verworfen. Views würden Versionierungs-, Filter- und Konsistenzlogik enthalten
und wären schwer isoliert testbar.

### Vollständiger In-Memory-Katalog

Verworfen. Er widerspricht der begrenzten Abfrage und skaliert bei mehreren
SDE-Versionen unnötig schlecht.

### Nur Laufzeitnormalisierung ohne persistierten Suchschlüssel

Verworfen. Die Sortierung und Filterung wäre vom Prozesszustand abhängig und
könnte mehr Datensätze in den Speicher ziehen.

### Mindestziel auf macOS 15 anheben

Verworfen. Ein Plattformwechsel ist für P09 nicht erforderlich. Die
macOS-14-kompatible Lösung erfüllt den gemessenen Bedarf.

## Folgen

Positiv:

- klare Application-/Persistence-Grenze,
- deterministische, versionierte und begrenzte Abfragen,
- migrationssicherer Suchschlüssel,
- nachweisbarer Speicherzugriff,
- sichere Grundlage für P10 und P12.

Zu beachten:

- P10 muss konkurrierende Aktivitäten und nicht aufgelöste Referenzen fachlich
  behandeln,
- P12 ergänzt die sichtbare Produktauswahl,
- P34 beobachtet reale Latenz und entscheidet bei Messbedarf über weitere
  Index-/Cachingstrategien,
- die v2→v3-Migration benötigt einen vollständigen Backfill aller Itemtypen.

## Nachweise

- `ItemBlueprintCatalogTests`,
- `ItemBlueprintCatalogPersistenceTests`,
- v2→v3-Migrationstest,
- Debug-/Release-Lauf mit jeweils 100 Tests,
- 50.000-Item-Performancefall,
- offizieller Schema-v3-SDE-E2E-Test mit Build 3424810.

