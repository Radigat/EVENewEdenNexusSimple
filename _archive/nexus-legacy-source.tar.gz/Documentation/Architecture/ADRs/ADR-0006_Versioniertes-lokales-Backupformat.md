# ADR-0006 – Versioniertes lokales Backupformat

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P06

## Kontext und Problem

Der lokale SwiftData-Store verwendet SQLite und kann aktive WAL-/SHM-Seitendateien besitzen. Eine bloße Kopie der Hauptdatei ist bei geöffnetem Store nicht zuverlässig. Vor künftigen Migrationen und vor einer Wiederherstellung wird deshalb eine konsistente, prüfbare und versionierte Sicherungsgrenze benötigt.

## Entscheidungstreiber

- Local First und Offline First,
- konsistente Sicherung eines geöffneten Quellstores,
- keine stillschweigende Datenüberschreibung,
- Format- und Schemakompatibilität vor Restore,
- Integritäts- und Prüfsummennachweis,
- atomische Veröffentlichung und atomischer Zielersatz,
- keine Geheimnisse aus dem Keychain,
- testbarer Application-Port mit austauschbarem Persistence-Adapter,
- keine destruktive Aufbewahrungsautomatik.

## Betrachtete Alternativen

### A. Hauptdatei, WAL und SHM direkt kopieren

Das ist leicht umzusetzen, besitzt aber ohne koordinierte SQLite-Grenze keinen belastbaren Konsistenzzeitpunkt. Die Alternative wird verworfen.

### B. SwiftData-Entitäten einzeln als JSON exportieren

Ein logischer Export wäre gut lesbar, müsste aber jedes heutige und künftige Modell separat serialisieren, Beziehungen rekonstruieren und eigene Migrationen erhalten. Als vollständige technische Storesicherung ist er für P06 zu fehleranfällig.

### C. SQLite-Online-Backup in einem versionierten Verzeichnispaket

SQLite erzeugt einen konsistenten Snapshot. Ein Manifest kann Format, Schema, Größe und SHA-256 binden. Das Paket bleibt ohne zusätzlichen Archivparser prüfbar und kann atomar im Zielverzeichnis veröffentlicht werden.

### D. Sofort komprimiertes und anwendungseigen verschlüsseltes Archiv

Dies vergrößert Parser-, Schlüsselmanagement- und Recovery-Komplexität. Da Tokens ohnehin im Keychain verbleiben und P06 nur lokale technische Backups benötigt, wird dies für Formatversion 1 zurückgestellt.

## Entscheidung

Alternative C wird umgesetzt:

- Paketendung `.nenbackup`,
- Verzeichnispaket mit `manifest.json` und `database.sqlite`,
- Formatkennung `com.newedennexus.local-backup`, Version 1,
- Schemabindung an `1.0.0`,
- SQLite-Online-Backup statt unkoordinierter Dateikopie,
- immutable read-only `PRAGMA quick_check`,
- Dateigröße und SHA-256,
- atomare Veröffentlichung aus `.partial`,
- privater Dateimodus `0700`/`0600`,
- Backuparten `manual`, `beforeMigration`, `beforeRestore`,
- keine Komprimierung und Verschlüsselung in Version 1,
- `keep all`, keine automatische Löschung.

Vor dem Ersetzen eines vorhandenen Zielstores ist ein erfolgreiches Sicherheitsbackup Pflicht. Restore verlangt Vorschau, ausdrückliche Bestätigung und einen als geschlossen deklarierten Zielstore. WAL-/SHM-Dateien werden erst nach dem Sicherheitsbackup kontrolliert behandelt und bei fehlgeschlagenem Austausch zurückgelegt.

## Positive Folgen

- geöffnete Quellstores können konsistent gesichert werden,
- beschädigte, manipulierte oder inkompatible Pakete werden vor Restore abgelehnt,
- unvollständige Sicherungen erscheinen nicht als fertiges Paket,
- ein vorhandener Zielstand bleibt als verifiziertes Sicherheitsbackup wiederherstellbar,
- Application bleibt SQLite- und SwiftData-frei,
- das Format kann künftig versioniert erweitert werden.

## Negative Folgen

- unkomprimierte Pakete benötigen mehr Speicher,
- `keep all` kann ohne spätere Rotation wachsen,
- externe Datenträger benötigen eine vom Benutzer gewählte Schutzstrategie,
- der Dienst kann einen geschlossenen SwiftData-Container nicht selbst verifizieren,
- automatische Vor-Migrations-Sicherung und vollständige Recovery-UX fehlen bis P36.

## Daten- und Sicherheitswirkung

P06 verändert weder SwiftData-Schema noch Migrationsplan. Backup und Restore arbeiten auf explizit übergebenen Store-URLs. Keychain-Tokens, Client Secrets und Logs sind nicht Teil des Pakets. Sichere Fehlermeldungen enthalten keine vollständigen lokalen Pfade oder Datensatzinhalte.

## Verifikation

- Debug- und Release-Build,
- vollständige Debug-/Release-Testsuite,
- sieben neue Integrationstests mit echten temporären SwiftData-Stores,
- geöffnetes-Store-Backup, Prüfsumme, Integrität und Dateirechte,
- Manipulations-, Bestätigungs-, Format- und Vorschauänderungsfehler,
- automatisches Sicherheitsbackup und Wiederherstellung beider Datenstände,
- Architektur- und Redaction-Regressionsprüfungen.

## Folgearbeiten

- künftiger Schemwechsel: `beforeMigration` kontrolliert vor Containeröffnung verdrahten,
- P36: App-Lebenszyklus, Restore-UI, Neustart und Recovery-Drill,
- spätere Einstellungen: Speicherort, Zeitplan, Rotation und optional Komprimierung,
- optionales neues Format nur über eine neue Formatversion und Kompatibilitätstests.

