# ADR-0028 – Globaler Sicherheitsbestand und Schema v13

Status: Akzeptiert
Datum: 2026-07-25
Prompt: P23

## Kontext

P22 berechnet die projektbezogene physische Verfügbarkeit nach Lager-,
Material- und Mengenfreigaben. Das Projektbuch verlangt zusätzlich einen
nicht automatisch verbrauchbaren Sicherheitsbestand sowie Mindest-, Warn-
und Zielmengen. Es definiert aber keine eindeutige Allokation
lagerbezogener und globaler Schutzmengen. Reservierungen sind eigene
Folgepakete.

## Entscheidung

1. P23 speichert höchstens eine globale Regel je positiver CCP-Type-ID.
2. Nur `safetyStockQuantity` reduziert die für das Projekt verwendbare
   P22-Menge. Mindest-, Warn- und Zielwerte erzeugen unabhängige Hinweise.
3. Aktiver Bestand, den P22 bereits ausschließt, deckt den globalen
   Sicherheitsbestand zuerst. Archivierte Bestände zählen nicht.
4. Vorschau und bestätigtes Speichern werden getrennt. Der Source-State
   umfasst die vollständigen P22-Quellen und alle betroffenen
   Regelversionen.
5. Mehrere Regeln werden atomar ersetzt; eine zwischenzeitliche Änderung
   wird als veraltete Vorschau gemeldet.
6. Schema v13 ergänzt additiv `StockPolicyRecord`. Es werden keine Regeln
   aus bestehenden Beständen geraten.

## Alternativen

- Lagerbezogene Regeln wurden verworfen, weil die notwendige
  Verteilungsregel nicht belegt ist.
- Eine einzige geordnete Schwellenkette wurde verworfen; das Projektbuch
  verlangt die Werte, aber keine zwingende Größenreihenfolge.
- Persistierte Berechnungsergebnisse wurden verworfen. Sie werden aus
  aktuellem Graph-, Bestands-, P22- und Regelzustand reproduzierbar
  berechnet.

## Auswirkungen

- Ohne Regel bleibt das P22-Ergebnis unverändert.
- Sicherheitsbestand wird hart geschützt; Schwellenwarnungen blockieren
  nicht.
- P24/P25 können Reservierungen als getrennte Berechnungsstufe ergänzen.
- Schema v13 und Backupformat 13.0.0 bleiben rückwärtskompatibel.

## Nachweis

- 17 neue P23-Tests einschließlich Stale-State an Service- und
  Repositorygrenze,
- v12→v13-Migration, Leerstore, Wiederöffnung und Regel-Roundtrip,
- SwiftPM und Xcode Debug/Release jeweils 388 Tests, 0 Fehler und 0
  übersprungen,
- isolierter App-Start mit `PRAGMA integrity_check = ok`.
