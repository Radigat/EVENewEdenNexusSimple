# ADR-0022 – T2-Invention und Graphformat 5

Status: Angenommen  
Datum: 2026-07-24  
Prompt: P17

## Kontext

P16 löste Manufacturing-Ketten ohne Tech-Klassifikation auf und verwendete
für Zwischenprodukte den neutralen Planungswert ME 0. P17 musste T2-Stufen
erkennen, ihre Blueprintqualität herkunftsgerecht planen und zugleich
verhindern, dass Wahrscheinlichkeiten als garantierte Ergebnisse
erscheinen.

Der vorhandene SDE-Katalog speichert bereits Invention-Produkte,
Grundruns, Wahrscheinlichkeiten und Materialien. Ein zusätzlicher
MetaGroup-/Dogma-Import hätte die konkrete T2-Entscheidung nicht verbessert,
aber Schema, Speicherbedarf und Migrationsrisiko vergrößert.

## Entscheidung

1. T2 wird über die eindeutige SDE-Beziehung
   fertigbarer Ausgangs-Blueprint → Invention-Produkt/Fertigungs-Blueprint
   erkannt. Ein Ausgangs-Blueprint ohne Manufacturing-Aktivität wird als
   Reverse-Engineering-/T3-Grenze typisiert abgelehnt.
2. Fehlende Beziehung bedeutet Tech I; mehrere Beziehungen, ungelöste
   Referenzen oder fehlende Wahrscheinlichkeit blockieren.
3. `IndustryRuleSet` Version 1 bindet verifizierte
   Invention-/Decryptorregeln an SDE-Build und Inhaltshash.
4. Die Standardplanung verwendet reguläre Invention ohne Decryptor,
   ME 2 / TE 4 und die SDE-Grundruns.
5. Gespeichert wird die Zahl benötigter erfolgreicher BPCs, nicht eine
   erfundene Zahl garantierter oder erwarteter Versuche.
6. Historische T2-BPOs und BPCs daraus sind explizite
   Qualitätsüberschreibungen und keine regulären Invention-Ergebnisse.
7. Jede Manufacturing-Stufe besitzt eigene Tech- und
   Blueprintqualitätsprovenienz.
8. Graphformat 5 und Expansionsrichtlinie 2 speichern diese Angaben im
   vorhandenen Graphpayload.
9. SwiftData-Schema v8 und Backupformat 8.0.0 bleiben unverändert.
10. Skills, MetaGroups und Decryptor-Dogma werden nicht allein zur
    redundanten Bestätigung importiert; P18 prüft seinen Dogma-Bedarf
    separat.

## Konsequenzen

Positiv:

- keine Namens- oder ID-Heuristik,
- keine versehentliche T3-Klassifikation als T2,
- reale produktspezifische Grundruns und Wahrscheinlichkeiten,
- unabhängige ME-Werte in gemischten T1-/T2-Ketten,
- klarer Unterschied zwischen Planung und Besitz,
- Altgraphen bleiben lesbar,
- keine Datenmigration und kein zusätzlicher SDE-Speicherbedarf.

Bewusste Einschränkungen:

- keine Zufallssimulation oder erwarteten Fehlversuche,
- keine Invention-Kosten,
- keine persönliche Blueprintbibliothek,
- keine UI zur freien Stufenüberschreibung; die fachliche API ist
  vorhanden,
- Reaktionen und Aggregation folgen P18/P19.

## Verifikation

- alle acht Decryptoren plus kein Decryptor,
- ME-2-/TE-4-Basisqualität,
- historische T2-BPO-Ausnahme,
- gemischte T1-/T2-Kette und Basismenge-eins-Schutz,
- fehlende und mehrdeutige Invention-Quelle,
- fehlende Wahrscheinlichkeit,
- Regel-/Katalog-Preflight,
- Graphformat-5-Roundtrip und Altformate 1 bis 4,
- offizieller Build 3444265 mit Blueprint 691 → 11372,
- SwiftPM/Xcode Debug und Release,
- isolierter App-/Store-Smoke.
