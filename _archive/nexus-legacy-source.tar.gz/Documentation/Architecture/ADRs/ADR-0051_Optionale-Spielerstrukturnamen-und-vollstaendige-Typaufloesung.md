# ADR-0051 – Optionale Spielerstrukturnamen und vollständige Typauflösung

Status: Akzeptiert mit offenem Eigentümer-Livetest  
Datum: 2026-07-28  
Prompt: P52/OFF-045/OFF-046

## Kontext

OFF-044 ersetzte technische IDs durch fachliche Namen. Öffentliche Stations-
und Systemnamen konnten scopefrei aufgelöst werden, private
Spielerstrukturen jedoch nicht. Außerdem lud die Detailansicht Typnamen nur
für die ersten 2.000 Rohdatensätze eines persönlichen Snapshots. Nach
Sortierung oder Filterung konnten dadurch vorhandene SDE-Typen fälschlich
als unbekannt erscheinen.

## Entscheidung

- Private Spielerstrukturnamen werden nur nach einer separaten,
  zweckgebunden erklärten Zustimmung zu
  `esi-universe.read_structures.v1` geladen.
- Die Neuautorisierung erhält bereits bestätigte Produktions- und
  Walletscopes. Abbruch verändert weder Token- und Scopemetadaten noch
  gespeicherte Snapshots.
- Angefragt werden nur Strukturen, die der aktuelle Snapshot tatsächlich
  referenziert. Pro Struktur werden ETag, Last-Modified und Ablaufdaten
  gespeichert; `304 Not Modified` und Offlinebetrieb verwenden den letzten
  gültigen Cache.
- Ohne Scope, bei fehlendem Zugriff oder unbekanntem Namen zeigt die UI eine
  fachliche generische Bezeichnung, aber keine rohe Struktur-ID.
- Typnamen werden für alle im Snapshot referenzierten Type-IDs gebündelt aus
  dem aktiven lokalen SDE geladen. Die 2.000-Zeilen-Grenze entfällt.
- Ladezustand und ein im aktiven SDE tatsächlich fehlender Typ werden
  ausdrücklich unterschieden. Namen werden nicht erfunden.

## Folgen

Der zusätzliche Scope bleibt optional und benutzerkontrolliert. Die
Namensauflösung schreibt keine Asset-, Projekt- oder Bestandsdaten. Der
Strukturnamencache enthält ausschließlich abgeleitete Namen. Die vollständige
Typauflösung verhindert falsche „unbekannt“-Anzeigen; ein wirklich fehlender
SDE-Typ bleibt transparent erkennbar.

## Nachweis

- 42/42 fokussierte Scope-, Struktur-, Cache-, Katalog- und
  Architekturtests bestanden.
- 662/662 vollständige SwiftPM-Tests bestanden.
- Apple-Development-signierter Xcode-Debugbuild, Scheme `NewEdenNexus`,
  Ziel macOS: `BUILD SUCCEEDED`.
- Keine produktiven Konten, Scopes, Snapshots oder Projektauswahlen wurden
  durch die Implementierung verändert.
- Eigentümer-Livetest für Scope-Zustimmung, sichtbaren Strukturnamen und
  vollständige Typnamen bleibt OFF-045/OFF-046.
