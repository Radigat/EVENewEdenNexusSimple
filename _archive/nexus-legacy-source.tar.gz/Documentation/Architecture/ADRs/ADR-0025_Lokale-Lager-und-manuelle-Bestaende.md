# ADR-0025 – Lokale Lager und manuelle Bestände

Status: **Akzeptiert**  
Datum: 2026-07-24  
Prompt: P20

## Kontext

Der Produktionsplaner benötigt vor CSV-Import, Verfügbarkeitsberechnung und
Reservierungen eine sichere lokale Bestandsquelle. Das Projektbuch beschreibt
darüber hinaus ESI-Assets, Containerhierarchien und virtuelle Lager. Diese
Bereiche gehören nicht zum reduzierten P20-Umfang und dürfen lokale
Benutzerdaten nicht mit späteren Live-Daten vermischen.

## Entscheidung

1. P20 modelliert ausschließlich lokale logische `StorageLocationSnapshot`s
   und aggregierte `ManualStockSnapshot`s.
2. Lager- und Bestandsdomäne, Application-Service, Repository-Port,
   SwiftData-Adapter und SwiftUI bleiben getrennt.
3. Eine Position ist über `(locationID, typeID)` eindeutig. Die persistente
   `stockIdentity` bildet diesen fachlichen Schlüssel deterministisch ab.
4. Bestandsmengen sind positive `Int64`-Stückzahlen. Updates ersetzen den
   Wert und addieren nicht implizit.
5. Neue oder bearbeitete Positionen werden gegen veröffentlichte Items des
   aktiven SDE-Katalogs geprüft und speichern dessen Provenienz.
6. Lager werden reversibel archiviert. Archivierte Lager und ihre Positionen
   bleiben erhalten und sind schreibgeschützt.
7. Schema v10 ergänzt beide Modelle additiv; die Migration v9→v10 erfindet
   keine Werte. Backupformat und Kompatibilitätsgrenze steigen auf 10.0.0.

## Folgen

- P21 kann einen CSV-Import gegen einen klaren Repository- und
  Validierungsvertrag implementieren.
- P22 kann Verfügbarkeit aus eindeutigen Lager-/Type-ID-Positionen berechnen.
- Vorhandene SDE-, Projekt-, Graph- und Reaktionsdaten bleiben getrennt und
  unangetastet.
- P20 bildet keine ESI-Assetinstanzen, Container, Besitzer, virtuelle Lager,
  Sicherheitsbestände oder Reservierungen ab.
- Katalogänderungen überschreiben gespeicherte Namen nicht automatisch; eine
  spätere Bearbeitung validiert erneut gegen die aktive Version.

## Alternativen

- Direkter SwiftData-Zugriff aus SwiftUI wurde wegen fehlender Testbarkeit und
  Schichtenverletzung verworfen.
- Eine einzelne globale Mengenzeile je Type-ID wurde verworfen, weil P22
  Lagerfilter und Ausschlüsse benötigt.
- Hartes Löschen von Lagern wurde wegen Datenverlust und fehlender
  Wiederherstellbarkeit verworfen.
- ESI-Assetmodelle wurden wegen MVP-Scope und zukünftiger Datenquellentrennung
  verworfen.

## Nachweis

- Domain-, Application-, Persistenz-, Migrations-, Backup- und
  Architekturtests,
- vier vollständige SwiftPM-/Xcode-Testläufe mit jeweils 335 Tests,
- [Lager- und Bestandsdokumentation](../../INVENTORY_MANAGEMENT.md),
- [P20-Abschlussbericht](../../Progress/Reports/2026-07-24_P20_Lager-und-manuelle-Bestaende.md).

