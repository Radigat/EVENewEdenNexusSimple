# ADR-0049 – Zweckgebundene ESI-Scopes und Plan-/Ist-Vergleich

Status: Akzeptiert  
Datum: 2026-07-27  
Prompt: P51

## Kontext

P40 benötigt drei persönliche Produktionsscopes. P42 benötigt zusätzlich den
Walletscope. Vor P51 forderte der gemeinsame Laufzeitpfad alle vier Scopes,
ohne die spätere Erweiterung verlässlich vom Basiszweck zu trennen. Außerdem
waren lokale Snapshots kein belastbarer Nachweis der Zustimmung und die
P29-Planwerte standen nicht direkt neben den bestätigten P42-Istwerten.

## Entscheidung

- Scopes werden zentral nach Zweck definiert: drei für persönliche
  Produktionsdaten, vier erst für Wallet.
- Der Walletscope wird nur nach eigener Erklärung und ausdrücklicher
  Neuautorisierung desselben Charakters gespeichert.
- Gespeichert wird ausschließlich die nicht geheime, angeforderte Scopeliste
  mit Zeitstempel in Schema v24. Access- und Refresh-Token bleiben außerhalb
  dieses Datensatzes.
- Migrationen erfinden keine Zustimmung. Ein Snapshot aktiviert keinen Scope.
- P29-Plan und bestätigtes P42-Ist werden je Projekt getrennt berechnet und in
  einer gemeinsamen Vergleichsansicht dargestellt.
- Archivierte, fehlende und veraltete Zustände bleiben explizit; Walletdaten
  überschreiben keine Planwerte.

## Folgen

Alte Konten müssen den jeweiligen Zweck erneut autorisieren, wenn kein lokaler
Nachweis vorliegt. Ein abgebrochener Walletdialog erhält den bisherigen
Account- und Tokenstand. Trennen entfernt Scopemetadaten zusammen mit den
charakterbezogenen Daten. Der produktive Eigentümerlauf bleibt P52.

## Nachweis

Scope-, Neuautorisierungs-, Abbruch-, Fehlerpfad-, Plan-/Ist-, Migrations-,
Wiederöffnungs-, Backup-/Restore- und Trennregressionen sind Bestandteil der
631/631 bestandenen SwiftPM-Tests. Der isolierte unsigned Xcode-Debugbuild für
macOS bestand.
