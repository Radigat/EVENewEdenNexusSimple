# ADR-0046 – Mengenbezogene ESI-Materialpreise und Schema v21

Status: **Akzeptiert**  
Datum: 2026-07-27  
Prompt: P41

## Kontext

Materialkosten mussten bislang manuell oder per CSV gepflegt werden.
Öffentliche regionale Sell-Orders sind ohne zusätzliche SSO-Berechtigung
verfügbar. Ein einzelnes Orderminimum bildet größere Einkaufsmengen jedoch
nicht zuverlässig ab. Außerdem darf eine Netz- oder Teilantwort bestehende
lokale Preise nicht unkontrolliert überschreiben.

## Entscheidung

- P41 lädt ausschließlich angeforderte Einkaufs-Type-IDs und keine kompletten
  Orderbücher.
- Region und optionale Location sind Benutzereingaben; Handelszentren werden
  nicht fest codiert.
- Die Beschaffungskosten werden deterministisch über die günstigsten
  vollständig erfüllbaren Sell-Orders mengenbezogen berechnet.
- Der Application-Service erzeugt eine zeit- und revisionsgebundene Vorschau.
  Nur eine ausdrückliche Bestätigung darf Preise schreiben.
- HTTP-Validatoren, Rate-Limits und Offline-Fallback werden über einen
  separaten begrenzten Dateicache behandelt.
- Schema v21 speichert ausschließlich die Herkunft bestätigter ESI-Preise.
  Berechnete Orderbücher werden nicht in SwiftData gespiegelt.
- Manuelle und CSV-Schreibwege ersetzen den Preis und entfernen seine
  ESI-Herkunft in derselben Transaktion.

## Folgen

Materialkosten können mit einer sichtbaren Markt-, Mengen- und
Frischeprovenienz aktualisiert werden. Zielerlöse bleiben bewusst manuell oder
CSV-basiert, bis Einkaufs- und Verkaufspreisrollen getrennt modelliert sind.
P41 führt keinen neuen persönlichen Scope und keinen zusätzlichen SDE-Import
ein.

## Nachweis

Die P41-Service-, Client-, Cache-, Persistenz-, Migrations-, Fehler- und
Backupfälle sind Bestandteil der vollständigen SwiftPM-Suite. 593/593 Tests
bestanden. Das Xcode-Projekt wurde regeneriert und statisch auf 16 Targets,
acht Testtargets und zwei gemeinsame Schemes geprüft. Nach Eingrenzung des
File-Provider-/`NSFileCoordinator`-Stillstands bestand der hashgleiche
isolierte Projektstand `xcodebuild -list` und den unsigned
macOS-arm64-Debugbuild.
