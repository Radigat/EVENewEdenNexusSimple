# ADR-0053 – ISK-Preissätze und profilfreie Marktvorschau

Status: **Akzeptiert mit offenem Eigentümer-Sichttest**  
Datum: 2026-07-28  
Prompt: P52/P41-1

## Kontext

Die Oberfläche bezeichnete getrennte Preisstände als „Preisprofile“ und
zeigte bei deren Anlage zusätzlich die feste Währung ISK. Dadurch entstand
der falsche Eindruck, Profile dienten der Währungswahl. Gleichzeitig konnte
die öffentliche P41-Marktpreisvorschau ohne vorhandenes Profil nicht geöffnet
werden, obwohl eine Vorschau keine Daten schreibt.

## Entscheidung

- Produktionskosten, Marktpreise und gespeicherte Preisstände bleiben
  ausschließlich ISK-Werte in exakten Hundertstel ISK.
- Die UI bezeichnet `PriceProfileSnapshot` als **Preissatz**. Ein Preissatz
  trennt Preisstände oder Szenarien wie „Jita Einkauf“ und „manuell
  konservativ“; er ist keine Währung.
- Eine ESI-Materialpreisvorschau darf ohne Ziel-Preissatz erstellt werden.
  In diesem Zustand werden keine vorhandenen Preise verglichen und
  „Übernehmen“ bleibt gesperrt.
- Erst eine ausdrücklich bestätigte Übernahme benötigt einen vorhandenen,
  unveränderten Ziel-Preissatz.
- Eine optionale PLEX-Anzeige ist nur ein abgeleiteter Anzeigewert. Sie darf
  ISK-Werte nicht ersetzen und benötigt vor Umsetzung getrennte öffentliche
  PLEX-Buy-/Sell-Quotes mit Region, Zeitpunkt, Frische und Preisrichtung.

## Alternativen

- Profile vollständig entfernen: verworfen, weil getrennte Preisstände und
  reproduzierbare Szenarien fachlich weiterhin benötigt werden.
- Automatisch einen Preissatz anlegen: verworfen, weil eine Vorschau keinen
  unbemerkten Schreibvorgang auslösen darf.
- PLEX als persistente zweite Währung speichern: verworfen; die
  Produktionsrechnung bleibt ISK-basiert.

## Folgen und Rückweg

Schema und bestehende Preis-/Projektdaten bleiben unverändert. Der interne
Typname bleibt aus Kompatibilitätsgründen bestehen; nur der Vorschauvertrag
erlaubt einen optionalen Ziel-Preissatz. Ein Rückweg besteht in der erneuten
Pflichtauswahl eines Preissatzes, ohne Datenmigration.

## Nachweis

12/12 fokussierte Markt-/Workspace-Tests und 664/664 vollständige
SwiftPM-Tests bestanden. Der Apple-Development-signierte Xcode-Debugbuild
für macOS arm64 bestand mit isoliertem Derived Data. OFF-048 hält den
Eigentümer-Sichttest fest; OFF-049 die optionale spätere PLEX-Anzeige.
