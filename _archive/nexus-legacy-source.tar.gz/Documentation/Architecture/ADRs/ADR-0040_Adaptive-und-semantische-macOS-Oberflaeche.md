# ADR-0040 – Adaptive und semantische macOS-Oberfläche

Status: Akzeptiert

Datum: 2026-07-26

Prompt: P35

## Kontext

Der Produktionsplaner besaß bereits Labels, Tastaturkürzel und einzelne
Renderer-Tests. Das Hauptfenster erzwang jedoch 1.100 Punkte Breite,
Dashboard und Kernbereiche nutzten starre horizontale Anordnungen und
eigene helle Farben. Die globale Suche filterte keinen Inhalt.

## Entscheidung

- Die Hauptansicht unterstützt 780 × 560 Punkte.
- Platzabhängige Kernbereiche nutzen adaptive Grids oder `ViewThatFits`.
- Navigation wird über eine echte, normalisierte Sidebar-Suche gefiltert.
- Bedeutungsfarben folgen semantischen macOS-Systemfarben.
- Relevante Metriken und Zustände erhalten vollständige Accessibility-Texte.
- Der Projekteditor besitzt eine explizite Fokusreihenfolge.
- Die deutsche MVP-Oberfläche bleibt der einzige bestätigte Sprachumfang.
- Ein Xcode-UI-Testtarget prüft das echte App-Bundle dauerhaft über den
  nativen Accessibility-Kanal.

## Folgen

- Schmale und breite Fenster verwenden denselben fachlichen Zustand.
- Farb- und Symbolinformation ist durch Text ergänzt.
- Es entstehen keine Schema-, Daten- oder Berechnungsänderungen.
- Ein vollständiger neuer String Catalog wird erst bei bestätigter weiterer
  Zielsprache eingeführt.

## Nachweis

SwiftPM Debug bestand 518 Tests; Xcode Debug bestand 520 Tests. Renderer-,
Architektur- und zwei native UI-Tests prüfen schmale/breite Pfade, Fokus,
Suche, semantische Farben, SDE-Status und den Accessibility-Audit. Das echte
App-Bundle wurde dabei bei 1.280 × 800 und 780 × 560 mit isoliertem Store
ausgeführt. `OFF-030` ist geschlossen. Der interaktive Computer-Use-Kanal
blieb unbrauchbar und wird nicht als manueller VoiceOver-Erfolg dargestellt.
