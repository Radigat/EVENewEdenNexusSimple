# ADR-0050 – Semantische ESI-Namen und reversible Asset-Auswahl

Status: Akzeptiert mit offenem Eigentümer-Livetest  
Datum: 2026-07-28  
Prompt: P52/OFF-044

## Kontext

P50 verwendete stabile CCP-IDs korrekt als interne Schlüssel, zeigte sie
aber zugleich prominent in Assets, Blueprints, Industry Jobs und
Projektvorschauen. Fachlich benötigt der Benutzer Itemname, Ort,
Aktivität, Status und Produkt. Eine versehentlich bestätigte
Projekt-Asset-Auswahl besaß außerdem keinen kontrollierten Rücknahmepfad.

## Entscheidung

- CCP-IDs bleiben interne fachliche Schlüssel und werden aus der normalen
  persönlichen UI entfernt.
- Item- und Produktnamen stammen aus dem aktiven SDE-Katalog.
- Aktivität, Status und Location Flag werden über zentrale deterministische
  Präsentationsregeln benannt.
- NPC-Stationen und Sonnensysteme werden tokenfrei über den offiziellen
  ESI-Namensendpunkt aufgelöst. Ein begrenzter charakterbezogener Dateicache
  erhält die Namen offline und wird beim Trennen kompensierbar entfernt.
- Private Spielerstrukturen erhalten ohne den noch nicht autorisierten Scope
  `esi-universe.read_structures.v1` keinen erfundenen Namen. Die UI zeigt
  eine transparente generische Bezeichnung.
- Vor dem Speichern einer Projekt-Asset-Auswahl ist ein zweiter
  Bestätigungsdialog erforderlich.
- Rücknahme erzeugt zuerst eine positions- und ortsbezogene Vorschau.
  Schreiben erfordert ausdrückliche Bestätigung und einen unveränderten
  gespeicherten Stand; entfernt wird nur die Projektauswahl.

## Folgen

Die UI ist fachlich lesbar, ohne Datenidentitäten zu verlieren. Die
Namensauflösung verändert keine Benutzer- oder Produktionsdaten und
benötigt keinen neuen persönlichen Scope. Eine unbeabsichtigte Auswahl ist
reversibel, ohne ESI-Snapshot oder manuelle/CSV-Bestände zu löschen.
Exakte private Strukturnamen bleiben eine sichtbar dokumentierte optionale
Scope-Entscheidung.

## Nachweis

- 18/18 fokussierte Namens-, Cache-, Projektions-, Rücknahme- und
  Persistenztests bestanden.
- 658/658 vollständige SwiftPM-Tests bestanden.
- kanonischer Apple-Development-signierter Xcode-Debugbuild für macOS arm64:
  `BUILD SUCCEEDED`.
- `plutil -lint` und `git diff --check` bestanden.
- Eigentümer-Sicht- und Rücknahmetest bleibt OFF-044.
