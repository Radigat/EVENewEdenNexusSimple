# ADR-0036 – Projektbezogene Einkaufs-Overrides und Schema v19

Status: Akzeptiert  
Datum: 2026-07-26  
Prompt: P30

## Kontext

P26 liefert bereits eine korrekte, Type-ID-basierte Nettokaufmenge. Diese
Berechnung darf weder dupliziert noch durch persistierte Ergebnis-Snapshots
veralten. Benutzer benötigen dennoch editierbare, wiederöffnungsfeste
Zielkaufmengen.

## Entscheidung

Die Anwendung persistiert ausschließlich projektbezogene Abweichungen von
der jeweils neu berechneten Fehlmenge. Die Domain führt Anforderungen
deterministisch zusammen; der Application-Service bindet die Vorschau an
den vollständigen P26-Quellzustand. Speichern erfordert eine Bestätigung
und einen erneut identischen bestätigten Build-or-Buy-Plan.

Schema v19 ergänzt additive `ShoppingQuantityOverrideRecord`-Datensätze.
Berechnete Listen, Namen, Preise und Status werden nicht gespeichert.

## Konsequenzen

- Lager- und Planänderungen wirken bei der nächsten Berechnung automatisch.
- Eine Menge null ist eine ausdrückliche Abweichung und bleibt gespeichert.
- Veraltete Type-ID-Overrides können sichtbar und bestätigt bereinigt werden.
- Unbestätigte Build-or-Buy-Entwürfe können keine dauerhafte Einkaufsliste
  erzeugen.
- Kaufstatus, CSV und projektübergreifende Beschaffung bleiben P31.

## Nachweis

Domain-, Service-, Persistenz-, Migrations-, Backup-, Architektur- und
Workspace-Tests sowie vollständige SwiftPM-/Xcode-Debugsuiten mit jeweils
486 bestandenen Tests.
