# ADR-0003 – SwiftData-Schema v1 und Persistenzgrenze

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P03

## Kontext und Problem

Vor P03 lagen `CharacterRecord` und `ProductionProject` im ausführbaren App-Target. Der `ModelContainer` wurde direkt mit den Modelltypen aufgebaut. Es gab keine explizite Schemaversion, keinen Migrationsplan, keine Repository-Grenze und kein validierendes Mapping zur Domain.

Ein ungeprüftes Verschieben der `@Model`-Typen konnte Entityidentität und vorhandene Stores gefährden.

## Entscheidungstreiber

- Erhalt vorhandener Benutzerdaten,
- explizit versionierte SwiftData-Schemata,
- automatisierter Legacy-Migrationsnachweis,
- klare Domain-/Application-/Persistence-Grenze,
- kein leerer Ersatzstore bei Fehlern,
- kleinster Scope ohne vorgezogene Fachentitäten,
- testbare Repository-Implementierung.

## Betrachtete Alternativen

### A. Modelle im App-Target belassen

Vorteile:

- kein Modulwechsel,
- kleinste Quellcodeänderung.

Nachteile:

- P02-Architektur bleibt unvollständig,
- Application besitzt keinen austauschbaren Repository-Port,
- Views und Persistenz bleiben dauerhaft gekoppelt.

### B. Sofort vollständiges MVP-Schema anlegen

Vorteile:

- alle künftigen Entitäten wären früh vorhanden.

Nachteile:

- Fachregeln, Beziehungen und Indizes müssten vor den zuständigen Prompts geraten werden,
- große, riskante Migration,
- zahlreiche ungenutzte Modelle,
- Scope-Verstoß.

### C. Exaktes Legacy-Schema plus additives Schema v1

Das bisherige Schema wird als Version 0.9.0 feldgenau beschrieben. Schema v1 erhält dieselben Entitäten und ergänzt nur `recordVersion`. Modelle, Factory und Repository ziehen in einen eigenen Persistence-Target.

Vorteile:

- realer Migrationspfad,
- geringe und messbare Datenwirkung,
- keine vorgezogenen Fachentitäten,
- klare Target- und Repository-Grenze,
- spätere Schemata können kontrolliert auf v1 aufbauen.

Nachteile:

- bestehende Views nutzen vorerst weiterhin `@Query` und `modelContext`,
- `CharacterRecord` bleibt aus Kompatibilitätsgründen im Schema, obwohl SSO Zukunftsumfang ist,
- Backup/Restore ist erst P06 verfügbar,
- Downgrade wird nicht unterstützt.

## Entscheidung

Alternative C wird umgesetzt.

- `NexusLegacySchema`: Version 0.9.0.
- `NexusSchemaV1`: Version 1.0.0.
- `NexusMigrationPlan`: Lightweight-Migration 0.9.0 → 1.0.0.
- `NewEdenNexusPersistence`: Modelle, Migration, Factory, Mapping und Repository.
- `ProductionProjectSnapshot`: Domainmodell.
- `ProductionProjectRepository`: Application-Port.

## Datenwirkung

Beide vorhandenen Entitäten erhalten ein nicht optionales `recordVersion: Int` mit Standardwert 1. Alle Legacy-Felder, IDs, Optionalitäten und Unique-Constraints bleiben unverändert.

Es werden keine Datensätze gelöscht, zusammengeführt oder fachlich umgedeutet.

## Migrationsnachweis

Ein separates Testfixture definiert die früheren Top-Level-Modellnamen und Felder. Der Strukturtest vergleicht:

- Entitynamen,
- Attributnamen,
- Typen,
- Optionalität,
- Unique-Flags,
- Unique-Constraints.

Der dateibasierte Migrationstest erhält sämtliche festen Charakter- und Projektwerte, prüft die neue Datensatzversion und öffnet den migrierten Store ein zweites Mal.

## Positive Folgen

- explizite Schemaversion und Migration,
- Persistenz ist physisch von Presentation getrennt,
- Domain und Application bleiben SwiftData-frei,
- Repository kann mit In-Memory-Store getestet werden,
- Mappingfehler werden sichtbar,
- spätere Schemaänderungen besitzen eine klare Basis.

## Negative Folgen

- direkte SwiftData-Zugriffe in vorhandenen Views bleiben Übergangsschuld,
- App-Start verwendet bis P04 weiterhin `fatalError`,
- es gibt vor P06 kein automatisches Backup vor Updates,
- Legacy-Schema muss für Nachvollziehbarkeit dauerhaft im Code verbleiben.

## Rückfall- und Wiederherstellungsstrategie

Die Migration ist ausschließlich additiv. Ein Fehlschlag wird an den Aufrufer weitergegeben; der Store wird nicht gelöscht und nicht durch einen leeren Store ersetzt.

Ein Downgrade auf die unversionierte App wird nicht unterstützt. Vor künftigen destruktiven oder nicht leichtgewichtigen Migrationen sind Backup und Restore aus P06 erforderlich.

## Betroffene Prompts

- P04: Containerfehler ohne `fatalError`,
- P05: Testfundament,
- P06: Backup/Restore,
- P07 ff.: neue versionierte Schemata,
- P11: vollständiger Projektlebenszyklus und View-Use-Cases.

## Offene Punkte

- direkte `@Query`-/`modelContext`-Verwendung in vorhandenen Views,
- Datenbankintegritätsprüfung,
- Backup vor Migration,
- fachliche Versionierung künftiger Projektberechnungen,
- SDE- und Bestandsbeziehungen.
