# ADR-0023: Verifizierter Reaktionskontext und Graphformat 6

Status: Akzeptiert

Datum: 2026-07-24

Prompt: P18

## Kontext

Graphformat 5 löste T1- und T2-Manufacturing rekursiv auf, ließ
Reaktionsprodukte jedoch als sichtbare Grenze stehen. Reaktionsmodifier
hängen von SDE-Dogmawerten, Formelart, Facility, Reactor, Rig,
Securityklassifikation und Skillstufe ab. Unbelegte Standardwerte würden
eine Genauigkeit vortäuschen, die der gespeicherte Graph nicht reproduzieren
kann.

## Entscheidung

1. Reaktionen verwenden einen eigenen, SDE-Build- und
   Inhaltshash-gebundenen `ReactionRuleProfile` mit maschinenlesbarem
   Preflight.
2. Nur die konkret benötigten Typ-Dogma-, Attribut- und Effektzeilen werden
   verarbeitet; Benutzerdaten und SDE-Regeldaten bleiben getrennt.
3. Jede Reaktionsstufe speichert entweder einen streng neutralen Basiskontext
   oder einen vollständig validierten modifizierten Kontext.
4. Material und Zeit werden zentral, ganzzahlig, überlaufgeprüft und mit
   eigenen Formelversionen berechnet. Blueprint-ME/TE bleibt für
   Reaktionen 0.
5. Graphformat 6 und Expansionsrichtlinie 3 erlauben rekursive
   Manufacturing-/Reaction-Kombinationen. Formate 1 bis 5 bleiben lesbar
   und veraltet.
6. Schema v9 speichert das Regelprofil kataloggebunden. Die Migration
   v8→v9 ist additiv; Backupformat 9.0.0 wird unterstützt.

## Folgen

- Reaktionswerte sind erklärbar und gegen den aktiven SDE-Stand prüfbar.
- Fehlende oder geänderte Dogmawerte blockieren den Import beziehungsweise
  die Berechnung statt still auf Annahmen zurückzufallen.
- Ein neutraler Kontext ist ausdrücklich ein Basisszenario, keine Aussage
  über eine reale Spielerstruktur.
- P19 kann die getrennten Vorkommensmengen anschließend aggregieren.
- Reale Strukturzustände, Fuel, Kosten, Slots, Kalender und Optimierung
  bleiben außerhalb P18 und gehören zu P43.

## Nachweis

- 310 Tests in SwiftPM und Xcode, jeweils Debug und Release,
- realer Build-3444265-Import mit allen drei Reaktionsarten,
- Format-6-Roundtrip und Manipulationsschutz,
- additive v8→v9-Migration und leerer v9-Store,
- isolierter App-Start mit `PRAGMA integrity_check = ok`.
