# ADR-0020 – Integer-ME, Graphformat 3 und Schema v8

Status: Akzeptiert  
Datum: 2026-07-24  
Prompt: P15

## Kontext

P14 liefert für die erste Rezeptstufe vollständige Runs. P15 muss daraus den
Materialbedarf nach EVE-Blueprint-ME berechnen, ohne Fließkomma,
Run-für-Run-Rundung, stillen Überlauf oder UI-Abhängigkeit. Alte Projekte
und Graphen dürfen keine nachträglich erfundenen ME-Werte erhalten.

## Entscheidung

1. `ProductionMaterialCalculation` ist ein unveränderlicher Domainwert mit
   Formelversion 1 und positiver `Int64`-Basismenge und Runzahl.
2. Fertigungs-ME ist eine ganze Prozentzahl von 0 bis 10. Reaktionen
   akzeptieren ausschließlich ME 0.
3. Der Rohbedarf wird über den ganzen Job multipliziert, anschließend
   ganzzahlig reduziert und genau einmal aufgerundet. Basismenge eins je Run
   bleibt vollständig geschützt.
4. Beide Multiplikationen sind überlaufgeprüft. Abgeleitete Payloadwerte
   werden beim Decodieren neu berechnet und bei Widerspruch abgelehnt.
5. Graphformat 3 verlangt Projekt-ME und eine konsistente
   Materialberechnung an jeder Materialkante.
6. Graphformat 1 und 2 bleiben unverändert lesbar, gelten aber als veraltet
   und werden nur auf Benutzeraktion neu erzeugt.
7. Schema v8 ergänzt optionale Felder für Projekt-ME und
   Materialformelversion. Migrierter Bestand interpretiert fehlende
   Projekt-ME ausschließlich als neutralen Wert 0.
8. Job-, Anlagen-, Rig-, Skill- und sonstige Modifikatoren werden nicht in
   Blueprint-ME hineingerechnet.

## Folgen

### Positiv

- Materialmengen sind zentral, erklärbar und reproduzierbar,
- EVE-Jobrundung und der Ein-Stück-Schutz sind referenzgetestet,
- Überläufe und manipulierte Payloads scheitern explizit,
- alte Graphen und Benutzerdaten bleiben erhalten,
- P16 bis P19 können jede spätere Rezeptstufe auf derselben Formelbasis
  aufbauen.

### Einschränkungen

- P15 berechnet nur die vorhandene erste Rezeptstufe,
- Zwischenprodukte und Reaktionen werden noch nicht rekursiv erzeugt,
- gleiche Materialien werden noch nicht stufenübergreifend aggregiert,
- Blueprint-ME ist ein lokaler Projektwert; persönliche Blueprints sind
  weiterhin bewusst verschoben.

## Verworfene Alternativen

- **Fließkomma und `ceil`:** unnötiges Präzisions- und
  Konvertierungsrisiko.
- **Rundung je Run:** widerspricht der verifizierten CCP-Jobregel.
- **Automatisches Aufwerten alter Graphpayloads:** würde fachliche Werte ohne
  damalige Benutzerentscheidung erfinden.
- **ME auch für Reaktionsformeln:** wäre keine verifizierte
  Blueprint-ME-Regel.
- **Alle Jobmodifikatoren in einem Prozentwert:** vermischt getrennte
  Fachregeln und verhindert nachvollziehbare Berechnungen.

## Prüfnachweis

- Domain-, Application-, Persistenz-, Migration-, Backup-, ViewModel- und
  Architekturtests,
- 273 Tests jeweils in SwiftPM Debug/Release und Xcode Debug/Release,
- v3→v8- und v7→v8-Bestandsschutz,
- isolierter echter Schema-v8-App-Prozess mit `integrity_check = ok`.
