# ADR-0021 – Manufacturing-Rekursion und Graphformat 4

Status: Angenommen  
Datum: 2026-07-24  
Prompt: P16

## Kontext

Graphformat 3 speicherte ein Zielrezept, dessen Runs und ME-berechnete
Materialkanten. Für eine T1-Produktionsplanung mussten herstellbare
Materialien als eigene Rezeptstufen aufgelöst werden. Dabei durften weder
Reaktions- und T2-Logik vorgezogen noch fehlende Tech-Stufen, Blueprint-ME
oder Rezeptentscheidungen geraten werden.

## Entscheidung

1. P16 traversiert ausschließlich eindeutige Manufacturing-Rezepte.
2. Der aktive Katalog entscheidet anhand vorhandener
   Manufacturing-Aktivitäten, ob eine Position auflösbar ist.
3. Eindeutige Rezepte werden als vorkommensbezogene Zwischenproduktknoten
   mit eigener Run-, Ausgabe-, Überschuss- und Materialberechnung angelegt.
4. Ziel-ME stammt aus dem Projekt. Automatisch entdeckte Zwischenprodukte
   tragen den expliziten neutralen Planungswert ME 0 mit eigener Provenienz.
5. Nicht herstellbare Positionen und Reaktionsgrenzen bleiben begründete
   Blätter.
6. Graphformat 4 speichert Expansionsrichtlinienversion, ME-Provenienz und
   Blattgrund und validiert die Mengenkopplung zwischen Kante und
   Zwischenprodukt.
7. Zyklen werden pro Vorfahrenpfad erkannt. Tiefe 64 und 25.000 Knoten sind
   technische Schutzgrenzen.
8. Der fertige Graph wird erst nach vollständiger Validierung gespeichert.
9. Format 1 bis 3 bleiben lesbar und gelten als veraltet.
10. Die codierte Payload bleibt in SwiftData-Schema v8; es wird keine
    unnötige Schemamigration angelegt.

## Konsequenzen

Positiv:

- deterministische und erklärbare mehrstufige T1-Berechnung,
- identische Typen dürfen in unterschiedlichen Zweigen vorkommen,
- Fehler, Katalogwechsel und Cancellation erhalten den Altgraphen,
- spätere T2-, Reaktions-, Aggregations- und Build-or-Buy-Regeln können die
  klar markierten Grenzen gezielt erweitern,
- keine Migration oder Änderung an Benutzerdaten.

Bewusste Einschränkungen:

- P16 klassifiziert keine Tech-Stufe aus nicht importierten Daten,
- Zwischenprodukt-ME ist noch nicht benutzerdefiniert,
- gleiche Endmaterialien werden erst in P19 summiert,
- Reaktionsblätter werden erst in P18 weiter aufgelöst.

## Verifikation

- dreistufige Referenzkette mit festen Sollmengen,
- getrennte gleiche Materialvorkommen,
- Reaktionsgrenze,
- ME-Provenienz und Kanten-/Sollmengeninvariante,
- mehrdeutige und ungelöste Rezepte,
- Zyklus, Tiefen- und Knotengrenze,
- Run-/Materialüberlauf,
- Cancellation und Persistenzfehler mit Bestandsschutz,
- Format-1-/2-/3-Kompatibilität und Format-4-Roundtrip,
- SwiftPM und Xcode in Debug und Release,
- isolierter App-/Store-Smoke.
