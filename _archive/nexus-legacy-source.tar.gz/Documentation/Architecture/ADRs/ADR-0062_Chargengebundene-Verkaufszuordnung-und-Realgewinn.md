# ADR-0062 – Chargengebundene Verkaufszuordnung und Realgewinn

Status: Akzeptiert, Eigentümer-Betriebsabnahme offen  
Datum: 2026-07-29  
Prompt: P59

## Kontext

P42 speichert persönliche Wallet-Snapshots und ausdrücklich bestätigte
Projektzuordnungen. P57 bindet reale Produktionschargen, P58 deren
unveränderliche Kostenbasis. Für Realgewinn dürfen weder eine öffentliche
Marktquote noch ein eigener offener Marktauftrag als tatsächlicher Erlös
gelten. Dieselbe Walletquelle darf außerdem projekt- und chargenübergreifend
nicht über ihre bestätigte Kapazität hinaus verwendet werden.

## Entscheidung

- Eine Charge unterteilt ausschließlich bereits bestätigte
  `WalletProjectAssignmentSnapshot`-Kapazität.
- Vor jedem Schreiben steht eine schreibfreie Vorschau; Speichern verlangt
  eine ausdrückliche Bestätigung.
- Die Zuordnung kopiert Belegart, Projekt, Charge, Charakter, Quellidentität,
  Walletrevision, Belegdatum, Menge und Betrag. Tokens und private
  ESI-Payloads werden nicht dupliziert.
- Der erste bestätigte Beleg bindet alle späteren Belege derselben Charge an
  genau einen unveränderlichen P58-Kostensnapshot.
- Manuelle Istbelege benötigen positiven Betrag, Datum und eine explizite
  sichere Begründung. Sie erhalten keine erfundene ESI-Provenienz.
- Schema v28 ergänzt additive
  `ProductionBatchSaleAllocationRecord`-Datensätze. Die Migration v27→v28
  erzeugt keine Verkaufsvergangenheit.
- Die persistente Grenze prüft Charge, Projekt, Kostenbindung, Stale-Stand,
  Überverkauf und die projektübergreifende Restkapazität atomar.

## Berechnung

Realisierte Kosten werden proportional zur bestätigten Verkaufsmenge aus der
unveränderlichen Chargenkostenbasis abgegrenzt. Beim vollständigen Verkauf
wird der verbleibende Rundungsrest exakt übernommen.

```text
Realgewinn = bestätigter Bruttoerlös
           − realisierte Chargenkosten
           − bestätigte Verkaufsgebühren
```

Offene Units behalten ihren Kostenanteil. Marktquotes und offene Marktorders
bleiben Prognose und erzeugen keinen Realgewinn.

## Folgen

- Wallet-Refresh, Offlinebetrieb oder Accounttrennung löschen bestätigte
  Chargenhistorie nicht.
- Ein veralteter Wallet-, Projekt- oder Chargenstand blockiert die Übernahme
  und verlangt eine neue Vorschau.
- P60 darf diese unveränderlichen Ergebnisse aggregieren, aber nicht
  umdeuten.
- Teilzuordnung, Vollzuordnung und identischer Neustartstand bleiben als
  reales Eigentümergate offen.
