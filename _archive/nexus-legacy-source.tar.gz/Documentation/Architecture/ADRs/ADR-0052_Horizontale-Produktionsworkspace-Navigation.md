# ADR-0052 – Horizontale Produktionsworkspace-Navigation

Status: Akzeptiert mit offenem Eigentümer-Sichttest  
Datum: 2026-07-28  
Prompt: P52/OFF-047

## Kontext

Der Produktionsworkspace zeigte Planung, Lager, Kosten, Materialsumme und
Graphstufen in einer schmalen, durchgehend vertikalen Seite. Der
Projekteigentümer konnte dadurch den P41-1-Marktpreisablauf nicht zuverlässig
finden oder überblicken.

## Entscheidung

- Das bestehende Graph-Sheet bleibt der einzige Produktionsworkspace.
- Seine Mindestbreite beträgt 1.080 pt, die Idealbreite 1.360 pt.
- Eine barrierefrei beschriftete segmentierte Leiste bietet sechs Bereiche:
  Übersicht, Bauen/Kaufen, Lager/Einkauf, Kosten/ROI, Materialsumme und
  Produktionsstufen.
- Unterhalb der Leiste wird jeweils nur der gewählte Bereich dargestellt.
- Übersicht enthält Planmetriken sowie Produktions- und Inventionsjobs.
- Die vorhandenen ViewModels, Fachservices, Vorschau-/Bestätigungsgates und
  Persistenzverträge bleiben unverändert.

## Abgewogene Alternative

Ein dauerhafter Split direkt unter der Projektliste wurde nicht umgesetzt.
Er hätte Navigation, Lebenszyklus und Zustandsbesitz von `ProjectsView`
wesentlich erweitert, obwohl die belegte Ursache bereits durch ein breiteres
Sheet und direkte Bereichswahl beseitigt wird.

## Folgen

Der Benutzer erreicht jeden Arbeitsbereich ohne Scrollsuche. Es gibt keine
Schema-, Migrations- oder Benutzerdatenänderung. P41-1 wird über
**Kosten & ROI** fortgesetzt, sobald der Eigentümer die neue Darstellung im
gebauten App-Bundle sichtbar bestätigt hat.

## Nachweis

- 9/9 fokussierte Workspace-, Render- und Accessibility-Prüfungen bestanden,
- 662/662 SwiftPM-Tests bestanden,
- Apple-Development-signierter Xcode-Debugbuild für macOS arm64:
  `BUILD SUCCEEDED`,
- `git diff --check` bestanden,
- Eigentümer-Sichttest: offen.
