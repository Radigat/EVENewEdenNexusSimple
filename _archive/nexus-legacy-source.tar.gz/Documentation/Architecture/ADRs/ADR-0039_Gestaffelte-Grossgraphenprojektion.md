# ADR-0039 – Gestaffelte Großgraphenprojektion

Status: Akzeptiert · 2026-07-26 · P34

## Kontext

Der Domänengraph akzeptiert bewusst bis zu 25.000 Knoten. Die bisherige
SwiftUI-Ansicht erzeugte dafür rekursiv den gesamten Anzeigebaum und baute
für jedes Materialvorkommen erneut eine vollständige Knoten-Namensabbildung.
Die Fachberechnung und die bestehende Graphschutzgrenze sind korrekt.

## Entscheidung

- Bis 500 Knoten bleibt die aufklappbare `OutlineGroup` erhalten.
- Größere Graphen werden iterativ in stabiler Depth-First-Reihenfolge
  projiziert.
- Initial werden 1.000 Zeilen erzeugt; Benutzer können jeweils weitere
  1.000 Zeilen anfordern.
- Große Zeilenlisten verwenden `LazyVStack`.
- Die Namensabbildung für Materialpfade wird einmal je Darstellung erzeugt.

## Alternativen

- Vollständigen Baum weiter materialisieren: verworfen wegen ungebremster
  UI-Arbeit.
- Fachgraph auf 1.000 Knoten kürzen: verworfen, weil Berechnungsdaten
  verloren gingen.
- Pagination im Persistenzmodell: verworfen, weil P34 keine Schema- oder
  Fachänderung benötigt.

## Konsequenzen

Der gespeicherte Graph bleibt vollständig und unverändert. Sehr große
Graphen sind zunächst nur teilweise sichtbar, weisen die Anzahl offen aus
und lassen sich kontrolliert erweitern. Die Projektion ist deterministisch,
UI-lokal und benötigt keine Migration.
