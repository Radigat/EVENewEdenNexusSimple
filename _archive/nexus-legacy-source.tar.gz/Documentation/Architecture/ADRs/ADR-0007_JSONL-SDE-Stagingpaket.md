# ADR-0007 – JSONL-SDE-Stagingpaket

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P07

## Kontext und Problem

Die statischen EVE-Daten sind groß, werden von CCP versioniert veröffentlicht und bilden später die Grundlage für Items, Blueprints, Aktivitäten und Reaktionen. Unvollständige, beschädigte oder während des Imports veränderte Dateien dürfen nicht als aktive Stammdaten erscheinen.

P07 benötigt eine testbare technische Grenze vor dem noch nicht implementierten SwiftData-Mapping aus P08.

## Entscheidungstreiber

- offizielle CCP-Daten und Lizenzgrenze,
- Local First und Offline First,
- speicherschonende Verarbeitung großer Dateien,
- deterministische und reproduzierbare Vorschau,
- erkennbare Quellenänderung,
- keine Aktivierung unvollständiger Daten,
- Application-Port ohne CryptoKit oder konkreten Dateiadapter,
- synthetische Offline-Tests ohne echte SDE-Inhalte im Repository.

## Betrachtete Alternativen

### A. YAML vollständig decodieren

Das offizielle Format ist verfügbar, benötigt bei großen Dokumenten aber eine aufwendigere Streamingstrategie und kann leicht zur vollständigen Materialisierung führen. Für die P07-Grenze wird es nicht gewählt.

### B. JSONL direkt in den produktiven SwiftData-Store importieren

Das verbindet technische Formatprüfung, fachliches Mapping, Migration und Aktivierung in einem Schritt. Ein Fehler könnte einen unvollständigen Stand sichtbar machen. P08 soll Schema und Mapping getrennt entscheiden.

### C. Offizielle JSONL-Dateien blockweise prüfen und ein versioniertes Stagingpaket veröffentlichen

Jede Zeile kann unabhängig validiert werden. Dateihashes und ein kanonischer Gesamthash binden Vorschau und Kopie. Erst nach erneuter Prüfung wird das Paket im selben Verzeichnis atomar umbenannt.

### D. Eigenes vereinfachtes Community-Konvertierungsformat

Dies würde eine zweite, nicht offizielle Semantik und zusätzliche Vertrauensgrenze einführen. Es wird verworfen.

## Entscheidung

Alternative C wird umgesetzt:

- Quelle ist ein lokal entpacktes offizielles Tranquility-JSONL-Archiv,
- Pflichtdateien sind Kategorien, Gruppen, Typen und Blueprints,
- blockweises Lesen mit zeilenweiser UTF-8-/JSON-/`_key`-Prüfung,
- SHA-256 je Datei und kanonischer SHA-256 des benötigten Inhalts,
- read-only Vorschau vor jeder schreibenden Stagingoperation,
- erneute vollständige Prüfung der kopierten Dateien,
- Vergleich des Staging-Snapshots mit der Vorschau,
- `.nensde`-Verzeichnispaket mit Manifest, Formatversion 1,
- atomare Veröffentlichung aus `.partial`,
- private lokale Rechte `0700`/`0600`,
- Aufbewahrung `keep all`,
- keine produktive Schema- oder Storeänderung.

Die lokal berechneten SHA-256-Werte werden ausdrücklich nur als Integritätsbindung verwendet. Solange die offizielle Automatisierungsdokumentation keine kryptografische Archivsignatur oder -prüfsumme vorgibt, wird keine Herkunftsauthentizität behauptet.

## Positive Folgen

- große Dateien werden nicht vollständig für die JSONL-Verarbeitung geladen,
- identische Eingaben erzeugen identische Snapshots,
- beschädigte oder formal ungeeignete Datensätze werden früh abgelehnt,
- eine Quellenänderung nach Vorschau hinterlässt kein finales Paket,
- P08 erhält eine klar versionierte, erneut prüfbare Eingabe,
- Application bleibt adapter- und CryptoKit-frei.

## Negative Folgen

- Download und Entpacken erfolgen zunächst außerhalb der App,
- `_key`-Mengen werden zur Eindeutigkeitsprüfung je Datei im Arbeitsspeicher gehalten,
- Formatversion 1 enthält nur vier Pflichtdatensätze,
- lokale SHA-256-Werte ersetzen keine offizielle Signatur,
- erfolgreiche Pakete benötigen ohne Rotation zusätzlichen Speicher.

## Daten- und Sicherheitswirkung

P07 ändert weder `NexusSchemaV1` noch den Migrationsplan oder einen produktiven Store. Die Fixtures sind synthetisch. Fehler- und Diagnosetexte legen keine Quelldaten oder vollständigen Pfade offen. Symbolische Links werden an der Quell-, Datensatz- und Zielverzeichnisgrenze abgelehnt.

## Verifikation

- Debug- und Release-Build,
- vollständige Debug-/Release-Testsuite,
- feste synthetische Referenzhashes,
- Erfolgs-, Determinismus-, Manipulations-, Validierungs- und Abbruchtests,
- Dateirechte und fehlende `.partial`-Reste,
- Architektur- und Redaction-Regressionsprüfungen.

## Folgearbeiten

- P08: statisches SwiftData-Schema, Mapping und transaktionaler Import,
- P09: Item-/Blueprintkatalog,
- P10: Rezept- und Aktivitätsresolver,
- später: offizieller Download, HTTP-Caching, optionale verifizierbare CCP-Prüfsumme, Diff, Aktivierung und Rotation.

