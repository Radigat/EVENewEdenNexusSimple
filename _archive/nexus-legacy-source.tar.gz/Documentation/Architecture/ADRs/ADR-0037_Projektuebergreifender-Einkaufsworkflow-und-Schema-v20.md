# ADR-0037 – Projektübergreifender Einkaufsworkflow und Schema v20

Status: **Akzeptiert**  
Datum: 2026-07-26  
Prompt: P31

## Kontext

P30 speichert projektbezogene Zielkaufmengen, besitzt aber keinen
projektübergreifenden Arbeitsbereich und keinen Kauf-Fortschritt. Eine
globale Zahl ohne Projektzuordnung wäre bei Teilkäufen mehrdeutig. Das
Eintragen gekaufter Mengen als Lagerbestand würde außerdem eine fachlich
unbelegte physische Einlagerung vortäuschen.

## Entscheidung

1. Kauf-Fortschritt wird je Projekt und CCP-Type-ID gespeichert.
2. Der zentrale Workflow berechnet die P30-Liste jedes aktuellen Projekts
   neu und aggregiert die Quellen anschließend nach Type-ID.
3. Die offene Menge ist Ziel minus höchstens bis zum Ziel angerechneter
   Kauf-Fortschritt.
4. Kauf-Fortschritt verändert keine Lager-, Schutz- oder
   Reservierungsdatensätze.
5. Nicht aktuelle oder vorübergehend nicht berechenbare Zuordnungen werden
   nicht automatisch gelöscht.
6. Jeder Schreibvorgang benötigt vollständige Vorschau, erneute
   Quellstandsprüfung und Bestätigung.
7. Text und CSV sind read-only. P31 bietet keinen Reimport-Schreibpfad.
8. Schema v20 ergänzt additiv `PurchaseProgressRecord`; fachliche
   Eindeutigkeit Projekt/Type-ID wird im Repository geprüft.

## Folgen

- Teilkäufe bleiben auch bei mehreren Projekten eindeutig und
  nachvollziehbar.
- Archivierung oder temporär fehlende Graphen vernichten keinen
  Einkaufsfortschritt.
- Ein tatsächlicher Wareneingang muss weiterhin bewusst als Bestand
  erfasst oder importiert werden.
- Ein späterer CSV-Import benötigt einen eigenen Preview-before-write- und
  Konfliktvertrag.
- Ein Projekt ohne berechenbaren Plan wird sichtbar ausgelassen, blockiert
  aber nicht alle übrigen Projekte.

## Verifikation

Domain-, Application-, Persistenz-, Migrations-, Backup-, Architektur- und
UI-Tests prüfen Aggregation, Teilkäufe, Übermengen, Vorschau/Bestätigung,
Stale-State, Scope-Isolation, Export und Wiederöffnung. SwiftPM und Xcode
Debug bestehen jeweils 501 Tests; der isolierte v20-Store meldet
`PRAGMA integrity_check = ok`.
