# ADR-0042 – Externer SDE-Prozess-Recovery-Drill

- **Status:** Akzeptiert
- **Datum:** 2026-07-26
- **Prompt:** P36 / OFF-024

## Kontext

Die SDE-Recovery war für jede persistente Phase im selben Prozess getestet.
OFF-024 verlangte zusätzlich den Nachweis über eine echte Prozessgrenze,
ohne produktive Daten oder einen Release-Crashschalter zu verwenden.

## Entscheidung

`SDEInstallationService` besitzt einen optional injizierbaren
Acceptance-Checkpoint. Er wird ausschließlich nach erfolgreicher atomarer
Journalpersistenz aufgerufen und bleibt in allen produktiven Compositions
`nil`.

Das getrennte `NewEdenNexusSDEAcceptance`-Executable koordiniert fünf
temporäre Szenariostores. Es startet je einen Installationsprozess, prüft
Phase und exakte PID, beendet nur diese PID durch `SIGKILL` und startet eine
neue Recovery-Composition auf demselben Store. Fixtures, Archiv und Stores
sind synthetisch und liegen ausschließlich unter einer eigens validierten
temporären P36-Wurzel.

## Konsequenzen

- Der Realnachweis nutzt denselben Installations-, Journal-, Staging-,
  Backup-, Katalog- und Recoverycode wie die App.
- Produktionscode enthält keinen aktivierbaren Crashbefehl.
- Fremde Pfade werden abgelehnt; `killall` und `pkill` werden nicht verwendet.
- Altbuild, Katalog, Benutzerdaten, Journal, Rollback, Aufbewahrung,
  idempotenter Neustart und Cleanup sind messbare Abnahmekriterien.
- Das Datenbankschema und produktive Benutzerdaten bleiben unverändert.

## Nachweis

Fünf verschiedene Kindprozesse wurden an `downloading`,
`validatingSource`, `validatingStagingStore`, `creatingSafetyBackup` und
`promoting` mit Signalstatus 9 beendet. Alle fünf Neustarts bestanden die
Integritätsprüfung; SwiftPM bestand 527 Tests und der Xcode-kompilierte
fokussierte Testbund 6 Tests.
