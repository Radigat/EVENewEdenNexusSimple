# ADR-0017 – Kataloggebundenes Produktionsziel und Schema v5

Status: **Akzeptiert**  
Datum: 2026-07-24  
Prompt: P12

## Kontext

P11-Projekte besaßen nur einen freien Produktnamen. Dieser Wert reicht weder
für eine reproduzierbare Rezeptauflösung noch für die spätere
Produktionsgraphberechnung. Eine automatische Namenszuordnung wäre bei
mehrdeutigen oder nach einem SDE-Wechsel veränderten Einträgen unsicher.

## Entscheidung

Ein neues oder geändertes Ziel wird als validiertes
`ProductionTargetSelection` gespeichert. Der Application-Service kombiniert
den read-only Item-/Blueprintkatalog aus P09 mit dem Rezeptresolver aus P10
und erzeugt das Ziel erst nach erfolgreicher, versionsgleicher Prüfung.

Schema v5 ergänzt die stabilen Produkt-/Blueprint-IDs, Aktivität und
Katalogprovenienz additiv. Bestehende Projekte erhalten keine erfundene
Zuordnung; ihre neuen Felder bleiben `nil`.

## Konsequenzen

- Produktnamen sind nur Anzeigesnapshots, keine Schlüssel.
- Ein eindeutiges vollständiges Rezept darf automatisch gewählt werden.
- Mehrere vollständige Rezepte benötigen eine bewusste Blueprintwahl.
- Defekte Alternativkandidaten blockieren nicht einen vollständigen
  Kandidaten.
- Gespeicherte Ziele werden beim Bearbeiten gegen den aktiven Katalog
  revalidiert.
- Backup-Schema `5.0.0` bleibt zu den additiven Versionen 1.0.0 bis 4.0.0
  kompatibel.
- Graph-, Run-, ME- und Materiallogik bleiben P13–P19.

## Verworfene Alternativen

- **Name als Schlüssel:** nicht stabil und nicht eindeutig.
- **Automatische Namensmigration:** würde fachliche Identität erfinden.
- **Ersten Blueprint still wählen:** bei Mehrdeutigkeit nicht
  reproduzierbar.
- **Marktgruppenimport nur für P12:** ohne fachlichen Mehrwert und entgegen
  dem bedarfsgesteuerten SDE-Prinzip.

