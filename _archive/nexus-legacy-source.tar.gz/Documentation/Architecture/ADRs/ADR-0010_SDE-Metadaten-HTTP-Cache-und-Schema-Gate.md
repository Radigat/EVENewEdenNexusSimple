# ADR-0010: SDE-Metadaten, HTTP-Cache und Schema-Gate

Status: **Akzeptiert**  
Datum: 2026-07-23  
Prompt: P07A

## Kontext

Der bestehende P07–P09-Pfad kann einen lokal bereitgestellten SDE prüfen,
normalisieren und versioniert aktivieren. Er konnte nicht selbst feststellen,
ob CCP einen neueren Build veröffentlicht hat. Ungebremste Abrufe,
unkontrollierte Retries oder eine Aktivierung trotz unbekannter
Schemaänderungen wären für einen Local-First-Client nicht vertretbar.

## Entscheidung

1. Application besitzt einen adapterfreien `SDEUpdateService` mit injizierter
   Zeit, Netzwerkprüfung, Persistenz, Logging, Sleeper und Jitter.
2. Ausschließlich die beiden festen offiziellen Tranquility-Endpunkte für
   `latest.jsonl` und `schema-changelog.yaml` sind zulässig. Redirects werden
   nicht verfolgt; eine abweichende finale URL wird abgelehnt.
3. Ein lokales Mindestintervall von 24 Stunden und die HTTP-Frischezeit wirken
   gemeinsam. Ein manueller Force-Check umgeht nur das lokale Intervall.
4. ETag, Last-Modified, Cachefrist und validierte letzte Metadaten werden
   persistent gespeichert; 304 ohne passende Nutzlast wird abgelehnt.
5. Retries sind auf ausgewählte transiente Fehler begrenzt und verwenden
   `Retry-After` oder exponentielles Backoff mit Jitter.
6. Der Schema-Changelog wird mit einem kleinen, versionsbezeichneten Parser
   gelesen. Unbekannte Zusatzfelder sind zulässig; fehlende oder typveränderte
   Pflichtwerte nicht.
7. Ein Changelogstand nach dem verstandenen Parserbuild erzeugt
   `schemaReviewRequired`. P07A lädt oder aktiviert keine SDE-Version.
8. Der Prüfzustand wird additiv in `NexusSchemaV4` gespeichert.

## Gründe

- Der Metadatencheck bleibt unabhängig von Download und Aktivierung testbar.
- Explizite Validatoren machen Cacheentscheidungen reproduzierbar.
- Das zweistufige Intervall verhindert unnötige CCP-Anfragen.
- Das Schema-Gate stoppt unbekannte Änderungen vor jeder späteren Aktivierung.
- Der aktive lokale Katalog bleibt bei Offline- und Fehlerzuständen nutzbar.

## Verworfene Alternativen

- **Nur URLCache verwenden:** Cachezustand und 304-Nutzlast wären nicht
  fachlich nachvollziehbar persistiert.
- **Bei jedem Appstart ungeprüft abrufen:** widerspricht dem konservativen
  Abrufmodell.
- **Archiv sofort nach neuer Buildnummer installieren:** vermischt
  Metadatenprüfung, Download, Import und Aktivierung und erschwert Rollback.
- **Vollständigen YAML-Frameworkparser hinzufügen:** für ein einziges
  benötigtes Integerfeld unnötige Abhängigkeit; der kleine Parser lehnt
  relevante Strukturänderungen ausdrücklich ab.

## Konsequenzen

- Schema 4.0.0 und Backupkompatibilität müssen ab P07A berücksichtigt werden.
- P07B darf nur auf validierten Metadaten aufbauen und muss Download,
  Archivschutz, isolierten Import und Promotion ergänzen.
- P07C verdrahtet Startprüfung, manuelle Bedienung und rechtliche Hinweise.
- Die Eigentümerkontaktangabe bleibt zentrale Konfiguration und persönliche
  Aufgabe; sie wird nicht erfunden.

## Korrektur 2026-07-29 – Datenbuild und Schemawechsel getrennt

Der P07B-Installer muss dieselbe Entscheidung wie der Metadatencheck
verwenden: Maßgeblich ist der höchste validierte
`schemaChangelog[].afterBuildNumber`, nicht die aktuelle SDE-Daten-Buildnummer.
Ein neuer Datenbuild darf daher installiert werden, wenn der zugehörige
gespeicherte Metadatencheck exakt diesen Zielbuild bestätigt und der höchste
Schemawechsel nicht nach dem verstandenen Parserstand liegt.

Fehlender Changelogstand, ein nicht zum Ziel passender offizieller Build oder
ein unverstandener Schemawechsel bleiben vor Download/Import beziehungsweise
vor Nutzung des vorbereiteten Archivs mit `NEN-SDE-007-SCHEMA` gesperrt.
Staging, Backup, Aktivierung und Rollback ändern sich nicht.

## Nachweise

- 30 neue P07A-spezifische Service-, HTTP-, Persistenz- und Migrationstests,
- 41 gezielte Regressionstests sowie ein zusätzlicher fokussierter
  Cache-Randfalllauf,
- vollständige 130 Tests in Debug und Release,
- Architekturgrenztests,
- manueller read-only Abruf der zwei offiziellen Metadatenressourcen.
