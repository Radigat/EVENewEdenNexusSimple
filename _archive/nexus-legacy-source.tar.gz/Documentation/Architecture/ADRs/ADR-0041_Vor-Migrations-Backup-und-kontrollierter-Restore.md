# ADR-0041 – Vor-Migrations-Backup und kontrollierter Restore

Status: Akzeptiert

Datum: 2026-07-26

Prompt: OFF-006 / P36-Teilumfang

## Kontext

Der technische P06-Backupdienst konnte konsistente SQLite-Snapshots und
bestätigte Restores durchführen. Vor dem automatischen Öffnen eines älteren
SwiftData-Stores fehlten jedoch Schemaerkennung und Sicherung. Die App hielt
außerdem den Containerzustand während eines Restore-Aufrufs.

## Entscheidung

- Ein read-only SQLite-Inspector erkennt unterstützte Nexus-Schemata 1 bis 20
  vor dem Öffnen durch SwiftData.
- Bei einer älteren unterstützten Version muss zuerst ein verifiziertes
  `beforeMigration`-Backup erfolgreich sein.
- Nicht als Nexus-Schema erkennbare Fremdstores werden vor dem Öffnen
  abgelehnt. Ein Store-Downgrade von einer künftigen App-Version wird nicht
  unterstützt oder als sicher behauptet.
- Restore beginnt nur aus einer unveränderten read-only Vorschau nach einer
  Prüfbestätigung und einer zweiten finalen Bestätigung.
- Der Runtime-Rand beendet SDE-Arbeit, verwirft storegebundene ViewModels und
  den Containerzustand, lässt den Backupdienst mit `closed` ersetzen und
  öffnet anschließend über dieselbe Migrationsgrenze erneut.
- Ein vorhandener Zielstore erhält vor dem Ersetzen ein `beforeRestore`-
  Sicherheitsbackup.
- Ältere Backups dürfen vorwärts migriert werden. Ein Downgrade der Datenbank
  oder die Verwendung mit einer älteren App-Version wird nicht unterstützt.

## Folgen

- Ein Backupfehler verhindert die Migration und lässt den Altstore unverändert.
- SDE-, Keychain- und Benutzerdatenquellen bleiben getrennt; Backups enthalten
  keine Tokens.
- OFF-006 ist geschlossen. Der reale externe SDE-Prozessabbruch OFF-024 bleibt
  ein eigenständiger P36- und Release-Nachweis.

## Nachweis

Acht fokussierte Tests prüfen Schemaerkennung, Fremdstore-Ablehnung,
Backupfehler, Vorschau,
Doppelbestätigung, Storefreigabe und
v19→Backup→v20→Restore→Wiederöffnung. SwiftPM bestand 526/526 Tests; der
Xcode-App-Build sowie 526/526 Xcode-Tests ohne UI bestanden. Der UI-Worker
startete in dieser Sitzung keinen Test und ist getrennt als OFF-031 erfasst.
