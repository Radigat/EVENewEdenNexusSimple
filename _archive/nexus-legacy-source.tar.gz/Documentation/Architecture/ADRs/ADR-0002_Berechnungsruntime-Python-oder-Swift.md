# ADR-0002 – Berechnungsruntime: Python oder Swift

- **Status:** Akzeptiert
- **Datum:** 2026-07-23
- **Prompt:** P02

## Kontext und Problem

Die vorhandene Materialaggregation wurde über `/usr/bin/env python3` und ein gebündeltes Skript ausgeführt. Die Einstellung `python.executable` wurde nicht ausgewertet. `Process.waitUntilExit()` blockierte den aufrufenden Thread und es gab weder Timeout noch Cancellation. Für eine native macOS-App entstand damit eine zusätzliche, außerhalb des App-Bundles nicht garantierte Laufzeitabhängigkeit.

Die tatsächlich vorhandene Python-Funktion war klein und deterministisch: Mengen klemmen, nach Type-ID gruppieren, sortieren, Kosten summieren und kaufmännisch runden.

## Entscheidungstreiber

- native, offline nutzbare macOS-App,
- reproduzierbare Berechnungen,
- einfache Distribution und Signierung,
- keine externe Laufzeitvoraussetzung,
- strukturierte Nebenläufigkeit,
- isolierte Unit-Tests,
- funktionale Parität zum vorhandenen Pfad.

## Betrachtete Alternativen

### A. Externes Python über `/usr/bin/env`

Vorteile:

- vorhandener Code bleibt nahezu unverändert,
- Python eignet sich grundsätzlich für komplexe Datenberechnungen.

Nachteile:

- Python ist auf Zielsystemen nicht als kompatible Laufzeit garantiert,
- unkontrollierter Pfad und Versionsstand,
- zusätzlicher Prozess, Pipes und JSON-Fehlergrenze,
- blockierendes Warten, fehlende Cancellation und Timeouts,
- Einstellung und tatsächlicher Prozessaufruf widersprechen sich.

### B. Python-Laufzeit in das App-Bundle integrieren

Vorteile:

- kontrollierbare Version,
- bestehende Python-Berechnungen könnten wachsen.

Nachteile:

- deutlich größeres Bundle,
- zusätzlicher Signierungs-, Sandbox-, Update- und Lizenzaufwand,
- für die vorhandene kleine Aggregation unverhältnismäßig,
- weiterhin Prozess-/Interop-Komplexität.

### C. Native Swift-Implementierung

Vorteile:

- keine zusätzliche Runtime,
- direkter, typisierter und testbarer Aufruf,
- kompatibel mit Swift Concurrency und App-Signierung,
- geringere Fehlerfläche,
- Domain kann vollständig offline und prozessfrei testen.

Nachteile:

- bestehende Semantik musste präzise nachgebildet werden,
- zukünftige Berechnungen müssen in Swift implementiert werden,
- Decimal-/Double-Grenzen benötigen explizite Tests.

## Entscheidung

Alternative C wird umgesetzt. Die vorhandene Aggregation wird in `NewEdenNexusDomain` als `MaterialSummaryCalculator` implementiert. Application stellt den Port `MaterialSummarizing` und den Use Case `SummarizeMaterialsUseCase` bereit. Infrastructure liefert `NativeMaterialSummaryService`.

Python-Engine, Skriptressource und die ungenutzte Python-Einstellung werden entfernt.

## Begründung

Die vorhandene Logik ist klein genug für eine direkte, überprüfbare Swift-Umsetzung. Eine Python-Laufzeit würde für den aktuellen MVP mehr Betriebs- und Auslieferungsrisiko als fachlichen Nutzen schaffen. Die native Lösung erfüllt das Projektziel einer nativen, lokalen Anwendung und hält den Fachkern frei von Prozess- und Dateisystemabhängigkeiten.

## Paritätsnachweis

Automatisierte Tests belegen:

- leere Eingabe,
- Gruppierung gleicher Type-IDs,
- Übernahme von Name und Preis des ersten Eintrags,
- Klemmen negativer Mengen auf null,
- deterministische Sortierung,
- kaufmännische Rundung auf zwei Stellen,
- identische Wiederholung,
- Fehler für ungültige ID, leeren Namen und nicht endlichen Preis,
- Aufruf über injizierten nativen Adapter.

Der erste Testlauf deckte eine abweichende binäre Double-Repräsentation nach `NSDecimalNumber.doubleValue` auf. Die Konvertierung erfolgt deshalb nach Decimal-Rundung über die kanonische Dezimalzeichenfolge; die gesamte Suite wurde danach erneut erfolgreich ausgeführt.

## Positive Folgen

- keine externe Python-Installation erforderlich,
- keine Prozess-, Pipe- oder JSON-Interop-Grenze,
- kein blockierendes `waitUntilExit()`,
- geringerer Bundle- und Signierungsaufwand,
- Fachlogik direkt testbar.

## Negative Folgen

- Python ist nicht mehr als alternative Berechnungsruntime vorbereitet,
- eine spätere erneute Einführung benötigt ein neues ADR und einen echten Anwendungsfall,
- Geldbeträge verwenden im vorhandenen Übergangsmodell weiterhin `Double` an der API-Grenze; spätere Preismodelle müssen dies fachlich entscheiden.

## Migrations- und Rückfallstrategie

Da der Python-Pfad keine persistenten Daten schrieb und nicht produktiv von einer View verwendet wurde, ist keine Datenmigration nötig. Ein Rückfall wäre durch Wiederherstellung eines Infrastructure-Adapters möglich, erfordert aber ein neues ADR mit Bundle-, Signierungs-, Timeout- und Cancellation-Konzept sowie erneuten Paritätstests.

## Betroffene Prompts

- P05: Referenztestfundament,
- P14 bis P19: Produktionsberechnungen,
- P27 bis P29: Preise und Kosten.

## Bekannte offene Punkte

- fachlicher Geldtyp und Rundungsregeln für P27/P29,
- Überlaufstrategie für sehr große aggregierte Mengen,
- Performancegrenzen für große Produktionsgraphen in P34.
