# ADR-0013 – Xcode-Projekt und SwiftPM-Parität

Status: **Akzeptiert**  
Datum: 2026-07-23  
Prompt: P09B

## Kontext

Bis P09A war `Package.swift` die einzige reproduzierbar geprüfte
Buildbeschreibung. Ein eigenständiges Xcode-Projekt, gemeinsame Schemes und
ein echter App-Bundle-Start für die manuelle macOS-Abnahme fehlten.

Die vorhandenen Modulgrenzen, Quellen und Tests dürfen nicht dupliziert
werden. Gleichzeitig benötigt die native App ein versioniertes
`NewEdenNexus.xcodeproj`, das per Xcode und `xcodebuild` funktioniert, ohne
den SwiftPM-Weg zu ersetzen.

## Entscheidung

1. `Sources/` und `Tests/` bleiben die einzigen produktiven und testbezogenen
   Quellen.
2. `Package.swift` bleibt der providerneutrale SwiftPM-Buildweg.
3. `project.yml` beschreibt dieselben 15 Targets für XcodeGen und erzeugt das
   versionierte `NewEdenNexus.xcodeproj`.
4. Die gemeinsamen Schemes `NewEdenNexus` und
   `NewEdenNexusSDEAcceptance` werden im Projekt versioniert.
5. Das App-Scheme enthält alle sieben Testtargets und isoliert Run- und
   Testprofile über projektlokale `CFFIXED_USER_HOME`-Pfade unter `.build`.
6. Der SDE-Abnahmerunner wird in Xcode nur gebaut. Seine Ausführung bleibt an
   die bestehenden expliziten Owner-, Kontakt-, Build- und Schema-Gates
   gebunden.
7. CLI-Nachweise laufen ohne Signing. Die Bundle-ID
   `com.newedennexus.local.NewEdenNexus` ist ausschließlich ein lokaler,
   nicht freigegebener Entwicklungsplatzhalter.
8. `Scripts/verify_xcode_project.py` vergleicht Package- und Xcode-Targets,
   referenzierte Swift-Dateien, Testtargets, gemeinsame Schemes,
   Fixture-Zuordnung und verbotene persönliche beziehungsweise Signing-
   Metadaten.
9. Die kleine Xcode-only-Datei
   `XcodeSupport/NewEdenNexusTestSupportBundle.swift` bildet ausschließlich
   den von SwiftPM generierten `Bundle.module`-Zugriff für dieselben
   Test-Fixtures nach; sie enthält keine Fachlogik.

## Begründung

Ein eingechecktes Projekt erlaubt reproduzierbare native macOS-Builds,
gemeinsame Scheme-Konfiguration und manuelle App-Abnahmen. Die generierbare
Beschreibung reduziert schwer sichtbare manuelle Änderungen in der
Projektdatei. Der statische Paritätscheck macht Drift zwischen den beiden
Buildbeschreibungen vor einem Build sichtbar.

## Konsequenzen

- Target- oder Quelldateiänderungen müssen künftig in `Package.swift` und
  `project.yml` konsistent gepflegt und mit dem Prüfskript kontrolliert
  werden.
- Die App kann über Xcode oder SwiftPM gebaut und getestet werden.
- XcodeGen ist nur zur Regeneration erforderlich; der normale Build des
  eingecheckten Projekts benötigt es nicht.
- Xcode-spezifische Benutzerzustände, DerivedData und Result-Bundles bleiben
  unversioniert.
- Es werden keine Signing-, Team-, Distribution-, Notarisierungs- oder
  Release-Bundle-ID-Entscheidungen vorweggenommen.

## Nachweise

- statischer Paritätscheck: 15 Targets, sieben Testtargets und zwei
  gemeinsame Schemes,
- `xcodebuild -list` erkennt Debug, Release und die gemeinsamen Schemes,
- Xcode Debug und Release der App erfolgreich,
- Xcode-Build des SDE-Abnahmerunners erfolgreich, ohne ihn auszuführen,
- Xcode-Testlauf: 167 bestanden, 0 fehlgeschlagen, 0 übersprungen,
- SwiftPM Debug, Release und 167 Tests erfolgreich,
- manueller App-, Einstellungs-, Tastatur- und VoiceOver-Smoke-Test mit
  isoliertem Profil.
