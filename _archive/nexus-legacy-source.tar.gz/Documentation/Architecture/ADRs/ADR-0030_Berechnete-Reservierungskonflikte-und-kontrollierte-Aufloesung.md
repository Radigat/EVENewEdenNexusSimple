# ADR-0030 – Berechnete Reservierungskonflikte und kontrollierte Auflösung

Status: Akzeptiert  
Datum: 2026-07-25  
Prompt: P25

## Kontext

P24 verhindert neue Überbuchungen, kann aber Konflikte nicht ausschließen,
die später durch Bestandsänderungen, veränderte Ausschlüsse,
Sicherheitsbestände oder einen neuen Produktionsgraph entstehen. Ein
persistierter Konfliktstatus könnte nach jeder dieser Änderungen veralten.
Das Projektbuch verlangt zudem sichtbare Konkurrenz, Prioritäten und eine
bewusste Auflösung ohne stille Mengenanpassung.

## Entscheidung

Reservierungskonflikte werden deterministisch aus dem aktuellen
P22-/P23-Kontext, dem aktuellen Projektbedarf und allen relevanten aktiven
P24-Reservierungen berechnet. Konfliktzustände und Auflösungsvorschläge
werden nicht persistiert; Schema v14 bleibt unverändert.

Eine Änderung ist auf Reduktion oder Freigabe aktiver Reservierungen
beschränkt. Sie benötigt eine schreibfreie Vorschau, ausdrückliche
Bestätigung, einen vollständigen Source-State-Abgleich und eine atomare
Repository-Transaktion. Ein Vorschlag muss alle in der Vorschau sichtbaren
Konflikte beseitigen. Prioritäten bestimmen nur eine stabile
Vorschlagsreihenfolge und lösen niemals automatisch auf.

## Alternativen

- **Konfliktstatus persistieren:** verworfen, weil jede Änderung an
  Beständen, Filtern, Schutzregeln, Graphen oder Reservierungen den Status
  invalidieren könnte.
- **Automatisch nach Priorität kürzen:** verworfen, weil dies eine
  benutzerkontrollierte Materialbindung ohne Bestätigung verändern würde.
- **Reservierungen einzelnen Lagern zuordnen:** nicht gewählt, da im
  aktuellen MVP keine belastbare Allokationsregel vorhanden ist.

## Folgen

- Konfliktanzeigen entsprechen dem jeweils geladenen Quellzustand.
- Das bestehende v14-Datenmodell, Migrationen und Backups bleiben
  unverändert.
- Mehrere Projekte können in einer bestätigten Operation atomar angepasst
  werden.
- Die Berechnung nutzt für die physische Verfügbarkeit den
  P22-/P23-Kontext des betrachteten Projekts; diese bewusste Grenze bleibt
  sichtbar dokumentiert.
- P26 kann nur mit einem konfliktfreien oder bewusst unveränderten
  Reservierungsstand weiterplanen.

## Nachweis

Domain-, Application-, Persistence- und Architekturtests prüfen
Bestandsunterdeckung, Bedarfsüberschreitung, verwaiste Bindungen,
Prioritätsreihenfolge, Ablaufwarnungen, schreibfreie Vorschau,
Bestätigung, atomare Mehrprojektänderung, Abbruch und veralteten
Quellzustand. SwiftPM und Xcode bestanden Debug und Release jeweils mit
423 Tests.
