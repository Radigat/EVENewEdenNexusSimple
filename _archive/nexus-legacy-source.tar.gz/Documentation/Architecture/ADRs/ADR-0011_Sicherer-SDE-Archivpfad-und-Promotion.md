# ADR-0011 – Sicherer SDE-Archivpfad und Promotion

Status: angenommen und durch Real-SDE-Abnahme bestätigt  
Datum: 2026-07-23

## Kontext

P07–P09 verarbeiten lokal bereitgestellte JSONL-Dateien. P07A prüft
offizielle Build- und Schemametadaten. Für einen produktiven Updatepfad
fehlen Download, defensive Archivgrenze, isolierte Persistenz,
Sicherheitsbackup, Rollback und Crash-Recovery.

ZIPFoundation oder ein anderes neues Drittanbieterpaket ist im Projekt nicht
vorhanden. Foundation bietet auf macOS 14 keine vollständige öffentliche
ZIP-Extraktions-API. Ein unkontrollierter Shellaufruf wäre nicht vertretbar.

## Entscheidung

1. Application definiert Ports und eine phasenprotokollierte
   `SDEInstallationService`-Orchestrierung.
2. Infrastructure bildet die Archiv-URL ausschließlich aus einer validierten
   positiven Buildnummer und dem festen offiziellen CCP-Host.
3. Ein eigener, read-only Central-Directory-Parser validiert das ZIP vor
   jeder Extraktion und vergleicht zusätzlich lokale Header.
4. Die eigentliche Dekompression verwendet die feste macOS-Systemgrenze
   `/usr/bin/ditto` ohne Shell. Pfad und Argumentform sind nicht
   benutzerkonfigurierbar; die Grenze ist injizierbar.
5. Nach der Extraktion wird der reale Dateibaum vollständig erneut geprüft.
6. P07/P08 validieren das versionierte Stagingpaket und mappen die JSONL-Zeilen
   in begrenzte Katalogbatches. Der P07B-Service akzeptiert keinen
   ausschließlich vollmaterialisierenden Legacy-Adapter.
7. Persistence schreibt die Batches zuerst in einen separaten temporären
   SwiftData-Store, gleicht die Gesamtmengen ab und öffnet ihn erneut.
8. Vor Promotion eines vorhandenen aktiven Stores wird ein
   `beforeSDEUpdate`-SQLite-Backup erzeugt.
9. Die Promotion schreibt ebenfalls in begrenzten Batches. Erst nach
   vollständigem Mengenabgleich werden Version und Aktivmarker gemeinsam
   gespeichert. Kandidatenzeilen sind über den Inhaltshash gezielt
   bereinigbar. Frühere Versionen bleiben per Buildnummer reaktivierbar.
10. Ein pfadbereinigtes JSON-Phasenjournal außerhalb des aktiven Stores
    ermöglicht die Erkennung und Bereinigung nichtterminaler Vorgänge.
11. Produktiver Download verlangt ausdrücklich Eigentümerbestätigung und
    eine reale User-Agent-Kontaktangabe.

## Begründung

Die Vorprüfung verhindert, dass `ditto` untrusted Pfade oder Sonderobjekte
ungeprüft verarbeitet. Die feste Systemgrenze vermeidet eine neue
Paketabhängigkeit und erlaubt gleichzeitig reale Extraktion. Die
Nachprüfung schützt gegen Unterschiede zwischen ZIP-Metadaten und
Extraktorverhalten.

Der temporäre Store beweist Schema-, Save- und Wiederöffnungsfähigkeit, bevor
der aktive Store berührt wird. Die abschließende Transaktion hält
Versionsabschluss und Aktivmarker zusammen; ein Abbruch davor hinterlässt
keine aktive Teilversion. Backup und erhaltene Vorgängerversion bieten zwei
voneinander unabhängige Rückfallgrenzen.

## Folgen

Positiv:

- feste offizielle Quelle und Redirectschutz,
- begrenzter Download und defensive ZIP-Grenze,
- kein direkter Import in den aktiven Store,
- Wiederöffnung vor Promotion,
- zeilenweises Mapping und begrenzte Persistenzbatches,
- rund 61 % geringerer maximaler RSS im realen Build-3444265-Import,
- expliziter Rollback und phasenbasierte Wiederherstellung,
- keine neue Drittanbieterbibliothek oder Shellinterpretation.

Einschränkungen:

- die App-Startverdrahtung und sichtbare Updatehistorie folgen P07C,
- der Prozessabbruch-Drill aller Phasen bleibt P36.

## Nachweise

- `CCPSDEArchivePipelineTests`,
- `SDEInstallationServiceTests`,
- `FileSDEInstallationLogStoreTests`,
- `StaticDataCatalogRepositoryTests`,
- Debug-/Release-Gesamtlauf mit jeweils 153 Tests,
- zwei vollständige Build-3444265-Realimporte mit identischem Inhalt und
  948–952 MB maximalem RSS.
