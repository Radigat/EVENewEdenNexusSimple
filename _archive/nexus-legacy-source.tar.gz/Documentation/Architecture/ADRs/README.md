# Architecture Decision Records

Stand: 2026-07-29

ADRs dokumentieren grundlegende technische Entscheidungen. Sie werden nachträglich nicht stillschweigend umgeschrieben. Eine ersetzte Entscheidung erhält den Status `Ersetzt` und verweist auf das neue ADR.

## Statuswerte

- **Vorgeschlagen:** noch nicht verbindlich umgesetzt.
- **Akzeptiert:** verbindlich und im aktuellen Stand umgesetzt.
- **Ersetzt:** durch ein späteres ADR abgelöst.
- **Verworfen:** geprüft, aber nicht gewählt.

## Register

| ID | Titel | Status | Prompt | Datum |
|---|---|---|---|---|
| [ADR-0001](ADR-0001_Modul-und-Schichtenarchitektur.md) | Modul- und Schichtenarchitektur | Akzeptiert | P02 | 2026-07-23 |
| [ADR-0002](ADR-0002_Berechnungsruntime-Python-oder-Swift.md) | Berechnungsruntime: Python oder Swift | Akzeptiert | P02 | 2026-07-23 |
| [ADR-0003](ADR-0003_SwiftData-Schema-v1-und-Persistenzgrenze.md) | SwiftData-Schema v1 und Persistenzgrenze | Akzeptiert | P03 | 2026-07-23 |
| [ADR-0004](ADR-0004_Zentrale-Fehler-und-Diagnosegrenze.md) | Zentrale Fehler- und Diagnosegrenze | Akzeptiert | P04 | 2026-07-23 |
| [ADR-0005](ADR-0005_Testfundament-und-versionierte-Referenzdaten.md) | Testfundament und versionierte Referenzdaten | Akzeptiert | P05 | 2026-07-23 |
| [ADR-0006](ADR-0006_Versioniertes-lokales-Backupformat.md) | Versioniertes lokales Backupformat | Akzeptiert | P06 | 2026-07-23 |
| [ADR-0007](ADR-0007_JSONL-SDE-Stagingpaket.md) | JSONL-SDE-Stagingpaket | Akzeptiert | P07 | 2026-07-23 |
| [ADR-0008](ADR-0008_Versionierter-SDE-Stammdatenkatalog.md) | Versionierter SDE-Stammdatenkatalog | Akzeptiert | P08 | 2026-07-23 |
| [ADR-0009](ADR-0009_Deterministischer-Item-und-Blueprintkatalog.md) | Deterministischer Item- und Blueprintkatalog | Akzeptiert | P09 | 2026-07-23 |
| [ADR-0010](ADR-0010_SDE-Metadaten-HTTP-Cache-und-Schema-Gate.md) | SDE-Metadaten, HTTP-Cache und Schema-Gate | Akzeptiert | P07A | 2026-07-23 |
| [ADR-0011](ADR-0011_Sicherer-SDE-Archivpfad-und-Promotion.md) | Sicherer SDE-Archivpfad und Promotion | Akzeptiert | P07B | 2026-07-23 |
| [ADR-0012](ADR-0012_SDE-App-Composition-Automation-und-Retention.md) | SDE-App-Composition, Automation und Retention | Akzeptiert mit offenem manuellem UI-Nachweis | P07C | 2026-07-23 |
| [ADR-0013](ADR-0013_Xcode-Projekt-und-SwiftPM-Paritaet.md) | Xcode-Projekt und SwiftPM-Parität | Akzeptiert | P09B | 2026-07-23 |
| [ADR-0014](ADR-0014_Deterministischer-Rezeptresolver.md) | Deterministischer Rezept- und Aktivitätsresolver | Akzeptiert | P10 | 2026-07-23 |
| [ADR-0015](ADR-0015_Projektlebenszyklus-und-reversible-Archivierung.md) | Projektlebenszyklus und reversible Archivierung | Akzeptiert | P11 | 2026-07-24 |
| [ADR-0016](ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md) | App-spezifischer Storepfad und sichere Legacy-Erkennung | Akzeptiert | OFF-026/P12-Voraussetzung | 2026-07-24 |
| [ADR-0017](ADR-0017_Kataloggebundenes-Produktionsziel-und-Schema-v5.md) | Kataloggebundenes Produktionsziel und Schema v5 | Akzeptiert | P12 | 2026-07-24 |
| [ADR-0018](ADR-0018_Erklaerbarer-Produktionsgraph-und-Schema-v6.md) | Erklärbarer Produktionsgraph und Schema v6 | Akzeptiert | P13 | 2026-07-24 |
| [ADR-0019](ADR-0019_Integer-Runs-Graphformat-2-und-Schema-v7.md) | Integer-Runs, Graphformat 2 und Schema v7 | Akzeptiert | P14 | 2026-07-24 |
| [ADR-0020](ADR-0020_Integer-ME-Graphformat-3-und-Schema-v8.md) | Integer-ME, Graphformat 3 und Schema v8 | Akzeptiert | P15 | 2026-07-24 |
| [ADR-0021](ADR-0021_Manufacturing-Rekursion-und-Graphformat-4.md) | Manufacturing-Rekursion und Graphformat 4 | Akzeptiert | P16 | 2026-07-24 |
| [ADR-0022](ADR-0022_T2-Invention-und-Graphformat-5.md) | T2-Invention und Graphformat 5 | Akzeptiert | P17 | 2026-07-24 |
| [ADR-0023](ADR-0023_Reaktionskontext-und-Graphformat-6.md) | Verifizierter Reaktionskontext und Graphformat 6 | Akzeptiert | P18 | 2026-07-24 |
| [ADR-0024](ADR-0024_Graphaggregation-und-Graphformat-7.md) | Type-ID-Graphaggregation und Graphformat 7 | Akzeptiert | P19 | 2026-07-24 |
| [ADR-0025](ADR-0025_Lokale-Lager-und-manuelle-Bestaende.md) | Lokale Lager und manuelle Bestände | Akzeptiert | P20 | 2026-07-24 |
| [ADR-0026](ADR-0026_Sicherer-CSV-Bestandsimport-und-Schema-v11.md) | Sicherer CSV-Bestandsimport und Schema v11 | Akzeptiert | P21 | 2026-07-24 |
| [ADR-0027](ADR-0027_Projektbezogene-Verfuegbarkeit-und-Schema-v12.md) | Projektbezogene Verfügbarkeit und Schema v12 | Akzeptiert | P22 | 2026-07-24 |
| [ADR-0028](ADR-0028_Globaler-Sicherheitsbestand-und-Schema-v13.md) | Globaler Sicherheitsbestand und Schema v13 | Akzeptiert | P23 | 2026-07-25 |
| [ADR-0029](ADR-0029_Globale-Projektreservierungen-und-Schema-v14.md) | Globale Projektreservierungen und Schema v14 | Akzeptiert | P24 | 2026-07-25 |
| [ADR-0030](ADR-0030_Berechnete-Reservierungskonflikte-und-kontrollierte-Aufloesung.md) | Berechnete Reservierungskonflikte und kontrollierte Auflösung | Akzeptiert | P25 | 2026-07-25 |
| [ADR-0031](ADR-0031_Build-or-Buy-und-Schema-v15.md) | Build-or-Buy, Lagernetting und Schema v15 | Akzeptiert | P26 | 2026-07-25 |
| [ADR-0032](ADR-0032_Integrierter-Produktionsworkspace.md) | Integrierter Produktionsworkspace | Akzeptiert | P32 | 2026-07-25 |
| [ADR-0033](ADR-0033_Exakte-ISK-Preisprofile-und-Schema-v16.md) | Exakte ISK-Preisprofile und Schema v16 | Akzeptiert | P27 | 2026-07-25 |
| [ADR-0034](ADR-0034_Atomarer-CSV-Preisimport-und-Schema-v17.md) | Atomarer CSV-Preisimport und Schema v17 | Akzeptiert | P28 | 2026-07-25 |
| [ADR-0035](ADR-0035_Reproduzierbare-Projektwirtschaftlichkeit-und-Schema-v18.md) | Reproduzierbare Projektwirtschaftlichkeit und Schema v18 | Akzeptiert | P29 | 2026-07-26 |
| [ADR-0036](ADR-0036_Projektbezogene-Einkaufs-Overrides-und-Schema-v19.md) | Projektbezogene Einkaufs-Overrides und Schema v19 | Akzeptiert | P30 | 2026-07-26 |
| [ADR-0037](ADR-0037_Projektuebergreifender-Einkaufsworkflow-und-Schema-v20.md) | Projektübergreifender Einkaufsworkflow und Schema v20 | Akzeptiert | P31 | 2026-07-26 |
| [ADR-0038](ADR-0038_Sichere-Validierung-und-kontrollierter-UI-Retry.md) | Sichere Validierung und kontrollierter UI-Retry | Akzeptiert | P33 | 2026-07-26 |
| [ADR-0039](ADR-0039_Gestaffelte-Grossgraphenprojektion.md) | Gestaffelte Großgraphenprojektion | Akzeptiert | P34 | 2026-07-26 |
| [ADR-0040](ADR-0040_Adaptive-und-semantische-macOS-Oberflaeche.md) | Adaptive und semantische macOS-Oberfläche | Akzeptiert | P35/OFF-030 | 2026-07-26 |
| [ADR-0041](ADR-0041_Vor-Migrations-Backup-und-kontrollierter-Restore.md) | Vor-Migrations-Backup und kontrollierter Restore | Akzeptiert | OFF-006/P36 | 2026-07-26 |
| [ADR-0042](ADR-0042_Externer-SDE-Prozess-Recovery-Drill.md) | Externer SDE-Prozess-Recovery-Drill | Akzeptiert | P36/OFF-024 | 2026-07-26 |
| [ADR-0043](ADR-0043_SSO-Ports-JWT-und-Kompensation.md) | SSO-Ports, JWT-Prüfung und Kompensation | Akzeptiert mit offenem manuellem SSO-Nachweis | P38 | 2026-07-26 |
| [ADR-0044](ADR-0044_Oeffentliche-ESI-Charakterbasis-und-Dateicache.md) | Öffentliche ESI-Charakterbasis und Dateicache | Akzeptiert | P39 | 2026-07-26 |
| [ADR-0045](ADR-0045_Persoenliche-ESI-Snapshots-mit-Vorschau.md) | Persönliche ESI-Snapshots mit Vorschau | Akzeptiert | P40 | 2026-07-26 |
| [ADR-0046](ADR-0046_Mengenbezogene-ESI-Materialpreise-und-Schema-v21.md) | Mengenbezogene ESI-Materialpreise und Schema v21 | Akzeptiert | P41 | 2026-07-27 |
| [ADR-0047](ADR-0047_Persoenliche-Wallet-Snapshots-und-bestaetigte-Projektzuordnung.md) | Persönliche Wallet-Snapshots und bestätigte Projektzuordnung | Akzeptiert | P42 | 2026-07-27 |
| [ADR-0048](ADR-0048_Projektbezogene-ESI-Asset-Verfuegbarkeit-und-Schema-v23.md) | Projektbezogene ESI-Asset-Verfügbarkeit und Schema v23 | Akzeptiert | P50 | 2026-07-27 |
| [ADR-0049](ADR-0049_Zweckgebundene-ESI-Scopes-und-Plan-Ist-Vergleich.md) | Zweckgebundene ESI-Scopes und Plan-/Ist-Vergleich | Akzeptiert | P51 | 2026-07-27 |
| [ADR-0050](ADR-0050_Semantische-ESI-Namen-und-reversible-Asset-Auswahl.md) | Semantische ESI-Namen und reversible Asset-Auswahl | Akzeptiert mit offenem Eigentümer-Livetest | P52/OFF-044 | 2026-07-28 |
| [ADR-0051](ADR-0051_Optionale-Spielerstrukturnamen-und-vollstaendige-Typaufloesung.md) | Optionale Spielerstrukturnamen und vollständige Typauflösung | Akzeptiert mit offenem Eigentümer-Livetest | P52/OFF-045/OFF-046 | 2026-07-28 |
| [ADR-0052](ADR-0052_Horizontale-Produktionsworkspace-Navigation.md) | Horizontale Produktionsworkspace-Navigation | Akzeptiert mit offenem Eigentümer-Sichttest | P52/OFF-047 | 2026-07-28 |
| [ADR-0053](ADR-0053_ISK-Preissaetze-und-profilfreie-Marktvorschau.md) | ISK-Preissätze und profilfreie Marktvorschau | Akzeptiert mit offenem Eigentümer-Sichttest | P52/P41-1/OFF-048 | 2026-07-28 |
| [ADR-0054](ADR-0054_Benannte-Marktquellen-und-oeffentliche-Strukturen.md) | Benannte Marktquellen und öffentliche Strukturen | Akzeptiert mit offenem Eigentümer-Sichttest | P52/P41-1/OFF-050 | 2026-07-28 |
| [ADR-0055](ADR-0055_Gruppierte-und-gestaffelte-ESI-Detailprojektion.md) | Gruppierte und gestaffelte ESI-Detailprojektion | Akzeptiert mit offenem Eigentümer-Sichttest | P52/OFF-051 | 2026-07-28 |
| [ADR-0056](ADR-0056_Projektbudget-statt-sichtbarer-Wallet-Projektfinanzen.md) | Projektbudget statt sichtbarer Wallet-Projektfinanzen | Akzeptiert mit offenem Eigentümer-Sichttest | P55/OFF-054 | 2026-07-28 |
| [ADR-0057](ADR-0057_Gruppierte-Build-or-Buy-Auswahl.md) | Gruppierte Build-or-Buy-Auswahl | Akzeptiert mit offenem Eigentümer-Sichttest | P56/OFF-054 | 2026-07-28 |
| [ADR-0058](ADR-0058_Reaktionsuntergruppen-und-kompakte-Build-or-Buy-Steuerung.md) | Reaktionsuntergruppen und kompakte Build-or-Buy-Steuerung | Akzeptiert mit offenem Eigentümer-Sichttest | P56/OFF-054 | 2026-07-29 |
| [ADR-0059](ADR-0059_Deutsche-Zahlenformatierung-in-der-UI.md) | Deutsche Zahlenformatierung in der UI | Akzeptiert mit offenem Eigentümer-Sichttest | P56/OFF-054 | 2026-07-29 |
| [ADR-0060](ADR-0060_Produktionsbuch-und-Chargenrechnung.md) | Produktionsbuch als projektgebundene Chargenrechnung | Akzeptiert | P57 | 2026-07-29 |
| [ADR-0061](ADR-0061_Unveraenderliche-Chargenkosten-und-Preisquotes.md) | Unveränderliche Chargenkosten und belegte Preisquotes | Akzeptiert, Eigentümer-Sichttest offen | P58 | 2026-07-29 |
| [ADR-0062](ADR-0062_Chargengebundene-Verkaufszuordnung-und-Realgewinn.md) | Chargengebundene Verkaufszuordnung und Realgewinn | Akzeptiert, Eigentümer-Betriebsabnahme offen | P59 | 2026-07-29 |
| [ADR-0063](ADR-0063_Eindeutige-veroeffentlichte-Rezeptauswahl.md) | Eindeutige veröffentlichte Rezeptauswahl | Akzeptiert | KI-062/OFF-061 | 2026-07-30 |
