# ADR-0044 – Öffentliche ESI-Charakterbasis und Dateicache

- Status: Akzeptiert
- Datum: 2026-07-26
- Prompt: P39

## Kontext

Verbundene Charaktere sollen öffentliche CCP-Profildaten
ressourcenschonend anzeigen können. Diese Daten ändern sich unabhängig vom
lokalen Charakterkonto, benötigen keinen privaten Scope und dürfen weder den
App-Start noch den Offlinebetrieb blockieren.

## Entscheidung

Application definiert transportneutrale Ports für Abruf, Cache und
Synchronisation. Infrastructure implementiert den offiziellen
unversionierten Charakterpfad mit festem Kompatibilitätsdatum, HTTP-
Validatoren und konservativer Limitbehandlung. Der öffentliche Request
sendet keinen Bearer-Token.

Profile werden getrennt von SwiftData und Tokens in einer begrenzten,
versionierten JSON-Datei gespeichert. Der Cache wird semantisch validiert,
mit restriktiven Dateirechten atomar ersetzt und beim Trennen kompensierbar
gelöscht. Frische Einträge vermeiden Netzwerkzugriffe; 304 und
Offline-Fallback erhalten den letzten gültigen Stand.

## Konsequenzen

- P39 benötigt keine Schemamigration.
- Öffentliche ESI-Daten bleiben von SDE, Benutzerdaten und Berechnungen
  getrennt.
- Cachekorruption beschädigt weder Account- noch Projektdaten.
- Rate-Limits und Abbruch sind Teil des Application-Vertrags.
- Der Eigentümerkontakt bleibt im Schlüsselbund und wird nur zur
  User-Agent-Konfiguration verwendet.
- Private Scopes, Assets, Blueprints und Jobs bleiben P40.

## Alternativen

Direkter Netzwerkzugriff aus der View wurde wegen fehlender Testbarkeit
verworfen. Speicherung im `CharacterRecord` wurde wegen vermischter
Lebenszyklen und unnötiger Migration verworfen. Ein Bearer-Token für die
öffentliche Route wurde wegen fehlenden fachlichen Bedarfs verworfen.

## Nachweis

- 565/565 SwiftPM-Tests,
- erfolgreicher SwiftPM- und Xcode-Debugbuild,
- automatisierte Cache-, Validator-, Limit-, Offline-, Abbruch- und
  Kompensationstests,
- realer offizieller ESI-Abruf mit HTTP 200 und konditional HTTP 304,
- [ESI-Architektur](../../ESI_ARCHITECTURE.md).
