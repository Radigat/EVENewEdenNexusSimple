# ADR-0038 – Sichere Validierung und kontrollierter UI-Retry

- **Status:** Akzeptiert
- **Datum:** 2026-07-26
- **Prompt:** P33

## Kontext

P04 stellte sichere Fehlercodes, Redaction und einen zentralen Alert bereit.
Im aktuellen Produktionsplaner deaktivierten Kernformulare ungültige Aktionen
jedoch teilweise ohne gemeinsame Begründung. Laufzeitfehler konnten nur
geschlossen werden, obwohl reine Lesevorgänge gefahrlos erneut angestoßen
werden können.

## Entscheidung

- `NexusValidationIssue` beschreibt ausschließlich sichere, UI-unabhängige
  Feldprobleme mit den stabilen Codes `NEN-VAL-001` bis `NEN-VAL-006`.
- Die Factorys erhalten keinen eingegebenen Rohwert. Domänen- und
  Application-Validatoren bleiben die letzte Schreibgrenze.
- `NexusValidationSummary` ist die gemeinsame SwiftUI-Darstellung für die
  Kernformulare und mengenbezogene Einkaufsvalidierung.
- `NexusOperation.userRetryPolicy` ist eine geschlossene Positivliste
  idempotenter Lese-, Inspect- und Previewoperationen.
- `NexusAppRuntime` speichert einen Retry nur für diese Positivliste, entfernt
  Fehler und Closure vor der Ausführung und führt dieselbe Closure höchstens
  einmal aus.
- Schreib-, Apply-, Aktivierungs-, Restore- und Löschoperationen erhalten
  niemals einen Runtime-Retry.

## Daten- und Sicherheitswirkung

P33 ändert kein SwiftData-Schema und schreibt keine neuen Benutzerdaten.
Fehlerinstanztexte gelangen weiterhin weder in UI noch in Diagnosen. Ein Retry
ist eine erneute, ausdrücklich vom Benutzer ausgelöste Operation und keine
automatische Schleife.

## Folgen

Kernformulare erklären fehlende Pflichtfelder, Auswahl, Mengen, ISK-Beträge
und Datumsbereiche konsistent. Sichere Ladefehler erhalten eine
Wiederholungsmöglichkeit; potenziell mehrdeutige Schreibvorgänge bleiben davon
ausgeschlossen. Vollständige Lokalisierung, manuelle VoiceOver-Abnahme und
Recovery-Drill verbleiben in P35 beziehungsweise P36.
