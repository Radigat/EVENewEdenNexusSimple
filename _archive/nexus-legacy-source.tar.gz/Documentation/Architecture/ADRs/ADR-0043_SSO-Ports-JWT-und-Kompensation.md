# ADR-0043 – SSO-Ports, JWT-Prüfung und Kompensation

- Status: Akzeptiert mit offenem manuellem SSO-Nachweis
- Datum: 2026-07-26
- Prompt: P38

## Kontext

Der vorhandene Zukunftscode führte Browser, Loopback, Tokenverarbeitung,
Keychain, SwiftData und UI eng zusammen. JWT-Inhalte wurden nicht als
vollständig verifizierte Identität behandelt. Keychain und SwiftData können
keine gemeinsame atomare Transaktion bilden.

## Entscheidung

Application definiert getrennte Ports für Authorization Flow, URL-Start,
Callback, Refresh-Token-Vault, Charakterkonto-Repository und
Kontoverwaltung. Infrastructure implementiert die macOS-/HTTP-Grenzen;
Persistence adaptiert `CharacterRecord`; die App verdrahtet ausschließlich.

Der Authorization Flow verwendet OIDC-Discovery, Authorization Code mit
PKCE S256, zufälligen `state`, einen einmaligen exakten Loopback-Callback und
eine kryptografische RS256/JWKS-Prüfung aller verbindlichen Claims und
Scopes. Ein Client Secret wird weder benötigt noch gespeichert.

Der Refresh-Token liegt ausschließlich im Keychain. Der
`EVEAccountConnectionService` kompensiert Teilfehler: Nach fehlerhaftem
SwiftData-Speichern oder -Löschen wird der vorherige Token-/Kontostand
wiederhergestellt. Trennen verlangt explizite Bestätigung.

Lokale interaktive Builds verwenden eine stabile Apple-Development-
Identität aus einer git-ignorierten Xcode-Konfiguration. Unsigned
CLI-/CI-Builds bleiben möglich, besitzen aber keinen produktiven
Keychain-Vertrag. Persönliche Team- und Zertifikatswerte gelangen nicht in
Projektdateien oder Git.

## Konsequenzen

- Views kennen weder SwiftData noch Keychain.
- Domain/Application bleiben frei von UI-, Network- und Security-Frameworks.
- Tokens, Codes, Verifier, State und rohe Serverantworten werden nicht
  protokolliert.
- `CharacterRecord` bleibt schemakompatibel; P38 benötigt keine Migration.
- ESI-Fachdaten bleiben strikt P39/P40.
- AppKit, Network und Security sind zulässige Infrastructure-Adapter; die
  Architekturprüfung verbietet dort weiterhin SwiftUI und SwiftData.
- Keychain-Zugriffsfehler werden als eigener Application-Fehler
  `localCredentialAccessFailed` gemeldet und nicht als SSO- oder
  SwiftData-Fehler fehlklassifiziert.

## Alternativen

- Ein monolithischer App-Service wurde wegen fehlender Testbarkeit und
  Schichtenverletzungen verworfen.
- Ungeprüftes JWT-Decoding wurde aus Sicherheitsgründen verworfen.
- Ein Client Secret im Desktop-Client wurde gemäß CCP-Desktop-Flow
  verworfen.
- Eine behauptete gemeinsame Keychain-/SwiftData-Transaktion ist technisch
  nicht verfügbar; deshalb wird explizit kompensiert.

## Nachweis

- 542 SwiftPM-Debugtests, darunter P38-Tests für Authorization, Signatur,
  Claims, Scopes, Vault-Fehler, Persistenz und Kompensation,
- erfolgreicher SwiftPM- und ad-hoc-Xcode-Debugbuild,
- stabil signierter Build und manueller Eigentümer-SSO-End-to-End-Lauf
  bleiben Abnahmevoraussetzung.
