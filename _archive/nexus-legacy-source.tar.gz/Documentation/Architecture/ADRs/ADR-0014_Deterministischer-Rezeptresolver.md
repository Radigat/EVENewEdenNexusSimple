# ADR-0014 – Deterministischer Rezept- und Aktivitätsresolver

Status: Angenommen  
Datum: 2026-07-23  
Prompt: P10

## Kontext

Der P09-Katalog stellt versionierte Blueprintaktivitäten, Materialien und
Produkte bereit. Eine fachliche Produktionsplanung darf diese Rohdaten nicht
direkt verwenden: Mehrdeutige Blueprints, inaktive SDE-Versionen,
unveröffentlichte Ziele oder nicht aufgelöste Typreferenzen könnten sonst
eine scheinbar vollständige, tatsächlich aber falsche Materialliste
erzeugen.

## Entscheidung

- Die Fachauswahl liegt zentral im SwiftData-freien
  `ResolveRecipeUseCase`.
- Persistence implementiert den Port `RecipeCandidateReading` und liefert
  Kandidaten ausschließlich aus genau einer aktiven SDE-Version.
- P10 unterstützt nur deterministische Fertigungs- und Reaktionsrezepte.
- Ohne explizite Blueprint-ID ist nur genau ein Kandidat zulässig.
  Mehrdeutigkeit wird mit stabil sortierten Blueprint-IDs abgelehnt.
- Blueprint und Zielprodukt müssen veröffentlicht sein.
- Eine nicht aufgelöste Material- oder Produktreferenz blockiert das
  gesamte Rezept mit itemgenauer Diagnose `NEN-RECIPE-001`.
- Der zusätzliche Port `RecipeReferenceAuditing` ermöglicht eine
  vollständige versionsbezogene Abnahme aller Referenzlücken.
- Der Resolver ermittelt weder Runs noch ME, Ketten, Graphen oder Kosten.

## Begründung

Die Trennung hält Persistenzabfragen austauschbar und macht die fachlichen
Regeln mit festen DTOs deterministisch testbar. Eine harte Ablehnung
unvollständiger Referenzen schützt Berechnung und Benutzerdaten vor
stillschweigenden Unterbedarfen. Der Verzicht auf automatische
Blueprintprioritäten verhindert unbelegte Entscheidungen.

## Folgen

Positiv:

- reproduzierbare Ergebnisse aus einem eindeutig belegten SDE-Stand,
- klare Fehler für fehlende, falsche, mehrdeutige und unvollständige
  Rezepte,
- vollständige Real-SDE-Prüfung ohne produktiven Benutzerstore,
- stabiler Vertrag für P13 bis P18.

Einschränkungen:

- mehrere gültige Blueprints benötigen eine explizite Benutzerauswahl,
- Erfindung bleibt wegen ihrer Wahrscheinlichkeitssemantik ausgeschlossen,
- Produktionsmengen und Rekursion folgen erst in späteren Prompts,
- bekannte Lücken der offiziellen SDE werden sichtbar blockiert, aber nicht
  durch lokale Ersatzdaten „repariert“.

## Alternativen

- Auswahl des kleinsten oder ersten Blueprint: verworfen, da unbelegt.
- Filterung unvollständiger Zeilen: verworfen, da fachlich falsche Mengen
  entstehen.
- Resolverlogik im SwiftData-Adapter: verworfen, da Fachregeln und
  Persistenz gekoppelt würden.
- Importabbruch für den gesamten SDE-Build: verworfen, da vollständige
  unabhängige Rezepte weiterhin sicher nutzbar sind.
