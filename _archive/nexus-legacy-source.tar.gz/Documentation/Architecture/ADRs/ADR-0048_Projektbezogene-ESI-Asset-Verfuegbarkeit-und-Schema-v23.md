# ADR-0048 – Projektbezogene ESI-Asset-Verfügbarkeit und Schema v23

Status: Akzeptiert  
Datum: 2026-07-27  
Prompt: P50

## Kontext

P40 speicherte persönliche Assets sicher und offline, vermischte sie aber
bewusst nicht mit manuellen oder importierten Lagern. Für eine praktische
Produktionsplanung wird eine kontrollierte Nutzung benötigt, ohne
Doppelzählungen, erfundene Ortsnamen oder automatische Fachmutationen.

## Entscheidung

- Persönliche Assets bleiben ein getrennter read-only P40-Dateisnapshot.
- Der Benutzer wählt Projekt und EVE-Location-IDs und erhält vor jeder
  Aktivierung eine positionsgenaue Vorschau.
- Positive manuelle oder CSV-Bestände desselben Typs blockieren die
  Aktivierung; eine nachträgliche Überschneidung deaktiviert die Wirkung.
- Die Bestätigung speichert nur Projekt, Charakter, Quellrevision und
  gruppierte Type-/Location-/Mengenzeilen in SwiftData-Schema v23.
- Die Produktionsplanung ergänzt diese Mengen als separat ausgewiesene
  externe physische Menge, bevor Schutzbestand, Reservierung und
  Build-or-Buy berechnet werden.
- Snapshot-, Bestands- und Auswahlrevisionen schützen vor veralteten
  Vorschauen. Fehler und Abbruch lassen den bisherigen Stand unverändert.
- Blueprint- und Jobdaten bleiben Anzeige; keine Projektannahme wird
  automatisch geändert.

## Folgen

ESI-Assets können lokal, offline und nachvollziehbar in genau einem
bestätigten Projektkontext wirken. Manuelle/CSV-Bestände bleiben
unverändert. Schema v23 ist additiv und backupfähig. Unbekannte Typ- und
Location-IDs bleiben sichtbar; ein zusätzlicher SDE-Import ist nicht nötig.

## Nachweis

Application-, Projektions-, Architektur-, Persistenz-, Migration-, Backup-,
Trenn- und vollständige Regressionstests sowie ein unsigned isolierter
Xcode-Debugbuild sind Bestandteil der P50-Abnahme.
