# ADR-0059 – Deutsche Zahlenformatierung in der UI

Status: Akzeptiert mit offenem Eigentümer-Sichttest  
Datum: 2026-07-29  
Kontext: P56/OFF-054

## Entscheidung

Sichtbare Mengen und Zählwerte verwenden unabhängig von der macOS-Sprache
eine feste deutsche Tausendergruppierung (`1.234.567`). Sichtbare
ISK-Beträge verwenden zusätzlich ein Dezimalkomma und zwei Nachkommastellen
(`1.234.567,89 ISK`).

Die Darstellung wird zentral durch `NexusNumberFormat` im UI-Target erzeugt.
Domänenwerte, Persistenz, Berechnungen, technische IDs, editierbare
Rohtexte sowie CSV-/Kopierformate bleiben unverändert.

## Gründe und Folgen

- Große EVE-Mengen und ISK-Beträge sind konsistent lesbar.
- Formatierung bleibt Präsentationslogik; fachliche Werte werden nicht
  gerundet oder verändert.
- Eingaben und maschinenlesbare Exporte behalten ihre bestehenden Parser-
  und Austauschverträge.
- Neue sichtbare Mengen- oder ISK-Ausgaben müssen den zentralen Formatter
  verwenden.

## Nachweis

- Referenztests für Null, Tausender, Millionen und negative Werte,
- 681/681 SwiftPM-Tests bestanden,
- Apple-Development-signierter Xcode-Debug-Build: `BUILD SUCCEEDED`,
- Eigentümer-Sichtkontrolle bleibt Bestandteil von `OFF-054`.
