# Rezept- und Aktivitätsauflösung

Stand: 2026-07-23 · Implementiert mit P10

## Zweck und Grenze

`ResolveRecipeUseCase` löst genau ein Fertigungs- oder Reaktionsrezept aus
der aktiven lokalen SDE-Version auf. Der Anwendungsfall ist frei von
SwiftUI und SwiftData und liefert reproduzierbare, stabil sortierte
Ergebnisse.

P10 berechnet keine Runs, Material Efficiency, Produktionsketten, Kosten
oder Graphen. `copying`, `research_material`, `research_time` und
`invention` bleiben Katalogaktivitäten, sind aber keine deterministischen
Produktionsrezepte dieses Resolvers.

## Eingabe und Ausgabe

Eingabe:

- Produkt-Type-ID,
- Aktivität `manufacturing` oder `reaction`,
- optional eine ausdrücklich gewählte Blueprint-Type-ID.

Erfolgreiche Ausgabe:

- Buildnummer und Inhaltshash der aktiven SDE-Version,
- Blueprint-, Aktivitäts- und Produkt-Type-ID,
- Outputmenge je Lauf,
- Aktivitätszeit,
- optionales Produktionslimit,
- vollständig aufgelöste Materialzeilen mit Menge, Verbrauchsart und
  stabiler Reihenfolge.

## Auswahlregeln

1. Der Persistenzadapter liest genau eine aktive SDE-Version.
2. Eine explizite Blueprint-ID muss zur Produkt-/Aktivitätskombination
   passen.
3. Ohne explizite Blueprint-ID wird genau ein Kandidat akzeptiert.
4. Kein Kandidat ergibt `recipeNotFound`; mehrere Kandidaten ergeben
   `ambiguousRecipe` mit aufsteigend sortierten Blueprint-IDs.
5. Es gibt keine automatische Priorität zwischen mehreren Blueprints.
6. Blueprint und angefragtes Produkt müssen veröffentlicht sein.
   Materialtypen werden nicht aufgrund ihres Veröffentlichungsstatus aus
   einem ansonsten vollständigen CCP-Rezept entfernt.
7. Eine materialverbrauchende Fertigungs- oder Reaktionsaktivität ohne
   Materialzeilen ist ungültig.
8. Mengen müssen positiv, Sortierwerte und Zeiten nicht negativ und ein
   vorhandenes Produktionslimit positiv sein. Wahrscheinlichkeitsprodukte
   werden nicht als deterministische Fertigungs- oder Reaktionsausgabe
   akzeptiert.

## Referenzintegrität

Jede Material- oder Produktzeile mit `typeIsResolved == false` blockiert das
gesamte betroffene Rezept. Der Resolver prüft Referenzlücken vor
Veröffentlichungs- und Mengenregeln, damit die eigentliche Datenlücke
itemgenau sichtbar bleibt.

Die Diagnose `NEN-RECIPE-001` enthält:

- aktive Buildnummer und Inhaltshash,
- Blueprint-Type-ID,
- Aktivität,
- Rolle `material` oder `product`,
- fehlende Type-ID.

Weitere sichere Diagnosekennungen:

| Code | Bedeutung |
|---|---|
| `NEN-RECIPE-002` | materialverbrauchendes Rezept ohne Materialien |
| `NEN-RECIPE-003` | Blueprint oder angefragtes Produkt unveröffentlicht |
| `NEN-RECIPE-004` | strukturell widersprüchlicher Kandidat |
| `NEN-SDE-008` | zentrale Benutzerfehlergrenze für Rezeptauflösung |

Es werden keine Platzhaltertypen erzeugt, keine Zeilen ignoriert und keine
Daten aus einem inaktiven Build beigemischt.

## Architektur

```text
ResolveRecipeUseCase
└── RecipeCandidateReading
    └── SwiftDataItemBlueprintCatalog
        └── genau eine aktive StaticDataVersion

RecipeReferenceAuditing
└── SwiftDataItemBlueprintCatalog
    └── itemgenaue Material-/Produktlücken des aktiven Builds
```

Die Kandidatenauswahl und fachliche Validierung liegen in Application.
Persistence übernimmt ausschließlich den versionsisolierten Lesezugriff
und die Abbildung persistenter Zeilen auf sendbare DTOs.

## Abnahme 2026-07-23

Der isolierte Real-SDE-Lauf verwendete den offiziellen Build `3444265` mit
Inhaltshash
`3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`.
Er löste ein vollständiges Rifter-Fertigungsrezept und ein vollständiges
Reaktionsrezept auf. Alle 21 im Build vorhandenen nicht aufgelösten
Blueprintreferenzen wurden einzeln mit `NEN-RECIPE-001` erkannt und ihre
betroffenen Rezepte vollständig blockiert.

Die Zahl 21 ist kein fest codierter Sollwert. Der Abnahmerunner zählt und
prüft die tatsächlichen Lücken der jeweils aktiven Version.

## Erweiterung

Spätere Berechnungsschritte verwenden `ResolvedRecipe` als geprüften
Ausgangspunkt:

- P13 Produktionsgraph,
- P14 Runs und Ausgabemengen,
- P15 Material Efficiency,
- P16/P17 T1-/T2-Ketten,
- P18 Reaktionsstufen.

Eine neue Aktivität darf erst unterstützt werden, wenn ihre Semantik,
Ausgaben und gegebenenfalls Wahrscheinlichkeiten separat spezifiziert und
mit festen Referenzfällen getestet sind.
