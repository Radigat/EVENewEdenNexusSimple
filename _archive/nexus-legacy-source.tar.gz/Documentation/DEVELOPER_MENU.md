# Entwickler-Menü

Zentrale Steuerdatei · Stand: 2026-07-30

## Cockpit

| Feld | Aktueller Wert |
|---|---|
| Aktuelle Entwicklungsstufe | **Stufe A – lokal nutzbarer Produktions-/Inventionsplaner** |
| Aktueller Prompt | **OFF-061 – P59-Eigentümergate in Bearbeitung** |
| Aktueller Ausführungsplan | **KI-064 entfernt den unnötigen Sonnensystem-Zwang und verschlankt die Chargenerfassung. Nun OFF-061 mit der neuen Charge, Kostenbasis, Teil-/Vollzuordnung, Verwerfen, Gebühr und Neustart abschließen. P60/P61 nur auf ausdrücklichen Auftrag; P54 separat freigabepflichtig.** |
| Letzte ergänzende Konfiguration | **CFG-001 – aktuelle öffentliche EVE-Client-ID zentral eingetragen und Altstandard migriert** |
| Zuletzt abgeschlossener Prompt | **P58 – Produktionskosten und Preisvorschläge; P59 noch nicht vollständig abgenommen** |
| Zuletzt abgeschlossener offener Punkt | **OFF-060 – Eigentümer-Sichttest mit Jita und geänderter Marktquelle** |
| Build-Status | **✅ KI-064: SwiftPM Debug und Apple-Development-signierter arm64-Xcode-Debugbuild `BUILD SUCCEEDED`** |
| Teststatus | **✅ KI-064 6/6 fokussiert; Vollsuite 706/716, zehn bekannte fremde Fehler in zurückgezogener P51-UI-Prüfung und lokalen SSO-Security-Fixtures.** |
| Reviewstatus | **✅ KI-064 technisch und sichtbar bestanden; ⚠️ OFF-061-Kostenbasis, Teil-/Vollzuordnung samt Neustart offen** |
| Bekannter kritischer Fehler | **Kein KI-064-Codeblocker: Produktionsort ist optional. Für OFF-061 fehlen noch die verbleibenden Eigentümerhandlungen.** |
| Nächstes empfohlenes Arbeitspaket | **OFF-061 – P59-Eigentümerabnahme; P60 erst danach und nur auf ausdrücklichen Auftrag** |

Statuswerte: ⬜ offen · 🔄 in Bearbeitung · ⚠️ teilweise/blockiert · ✅ erledigt · ⏸️ verschoben · ❌ fehlgeschlagen

## Prompt-Reihenfolge P00–P61

| ID | Status | Titel | Promptdatei | Abschlussbericht |
|---|---|---|---|---|
| P00 | ✅ erledigt | Entwickler-Cockpit | [Prompt](Prompts/MVP/P00_Entwickler-Cockpit.md) | [Bericht](Progress/Reports/2026-07-23_P00_Entwickler-Cockpit.md) |
| P01 | ✅ erledigt | Dauerhafte Entwicklungsregeln | [Prompt](Prompts/MVP/P01_Dauerhafte-Entwicklungsregeln.md) | [Bericht](Progress/Reports/2026-07-23_P01_Dauerhafte-Entwicklungsregeln.md) |
| P02 | ✅ erledigt | Zielarchitektur und Modulgrenzen | [Prompt](Prompts/MVP/P02_Zielarchitektur.md) | [Bericht](Progress/Reports/2026-07-23_P02_Zielarchitektur-und-Modulgrenzen.md) |
| P03 | ✅ erledigt | Domänenmodell und Migrationen | [Prompt](Prompts/MVP/P03_Domaenenmodell-Migrationen.md) | [Bericht](Progress/Reports/2026-07-23_P03_Domaenenmodell-Schema-v1-und-Migrationen.md) |
| P04 | ✅ erledigt | Fehlerbehandlung und Logging | [Prompt](Prompts/MVP/P04_Fehlerbehandlung-Logging.md) | [Bericht](Progress/Reports/2026-07-23_P04_Fehlerbehandlung-und-Logging.md) |
| P05 | ✅ erledigt | Testfundament und Referenzdaten | [Prompt](Prompts/MVP/P05_Testfundament.md) | [Bericht](Progress/Reports/2026-07-23_P05_Testfundament-und-Referenzdaten.md) |
| P06 | ✅ erledigt | Lokale Backups | [Prompt](Prompts/MVP/P06_Backups.md) | [Bericht](Progress/Reports/2026-07-23_P06_Lokale-Backups.md) |
| P07 | ✅ erledigt | SDE-Importpipeline | [Prompt](Prompts/MVP/P07_SDE-Importpipeline.md) | [Bericht](Progress/Reports/2026-07-23_P07_SDE-Importpipeline.md) |
| P08 | ✅ erledigt | Statisches Datenschema | [Prompt](Prompts/MVP/P08_Statisches-Datenschema.md) | [Bericht](Progress/Reports/2026-07-23_P08_Statisches-Datenschema.md) |
| P09 | ✅ erledigt | Item- und Blueprintkatalog | [Prompt](Prompts/MVP/P09_Item-Blueprintkatalog.md) | [Bericht](Progress/Reports/2026-07-23_P09_Item-Blueprintkatalog.md) |
| P09A | ✅ erledigt | Repository-Baseline und Git-Nachvollziehbarkeit | [Prompt](Prompts/MVP/P09A_Repository-Baseline-Git-Historie.md) | [Bericht](Progress/Reports/2026-07-23_P09A_Repository-Baseline-Git-Historie.md) |
| P09B | ✅ erledigt | Eigenständiges Xcode-Projekt und gemeinsame Schemes | [Prompt](Prompts/MVP/P09B_Xcode-Projekt-Schemes.md) | [Bericht](Progress/Reports/2026-07-23_P09B_Xcode-Projekt-Schemes.md) |
| P10 | ✅ erledigt | Rezept- und Aktivitätsresolver | [Prompt](Prompts/MVP/P10_Rezept-Aktivitaetsresolver.md) | [Bericht](Progress/Reports/2026-07-23_P10_Rezept-Aktivitaetsresolver.md) |
| P11 | ✅ erledigt | Projektlebenszyklus | [Prompt](Prompts/MVP/P11_Projektlebenszyklus.md) | [Bericht](Progress/Reports/2026-07-24_P11_Projektlebenszyklus.md) |
| P12 | ✅ erledigt | Kataloggestützte Zielproduktauswahl | [Prompt](Prompts/MVP/P12_Zielproduktauswahl.md) | [Bericht](Progress/Reports/2026-07-24_P12_Zielproduktauswahl.md) |
| P13 | ✅ erledigt | Erklärbarer Produktionsgraph | [Prompt](Prompts/MVP/P13_Produktionsgraph.md) | [Bericht](Progress/Reports/2026-07-24_P13_Produktionsgraph.md) |
| P14 | ✅ erledigt | Runs und Ausgabemengen | [Prompt](Prompts/MVP/P14_Runs-Ausgabemengen.md) | [Bericht](Progress/Reports/2026-07-24_P14_Runs-Ausgabemengen.md) |
| P15 | ✅ erledigt | Material Efficiency | [Prompt](Prompts/MVP/P15_Material-Efficiency.md) | [Bericht](Progress/Reports/2026-07-24_P15_Material-Efficiency.md) |
| P16 | ✅ erledigt | T1-Berechnung | [Prompt](Prompts/MVP/P16_T1-Berechnung.md) | [Bericht](Progress/Reports/2026-07-24_P16_T1-Berechnung.md) |
| P17 | ✅ erledigt | T2-Berechnung | [Prompt](Prompts/MVP/P17_T2-Berechnung.md) | [Bericht](Progress/Reports/2026-07-24_P17_T2-Berechnung.md) |
| P18 | ✅ erledigt | Reaktionsstufen | [Prompt](Prompts/MVP/P18_Reaktionsstufen.md) | [Bericht](Progress/Reports/2026-07-24_P18_Reaktionsstufen.md) |
| P19 | ✅ erledigt | Aggregation und Graphschutz | [Prompt](Prompts/MVP/P19_Aggregation-Graphschutz.md) | [Bericht](Progress/Reports/2026-07-24_P19_Aggregation-Graphschutz.md) |
| P20 | ✅ erledigt | Lager und manuelle Bestände | [Prompt](Prompts/MVP/P20_Lager-Manuelle-Bestaende.md) | [Bericht](Progress/Reports/2026-07-24_P20_Lager-und-manuelle-Bestaende.md) |
| P21 | ✅ erledigt | CSV-Bestandsimport | [Prompt](Prompts/MVP/P21_CSV-Bestandsimport.md) | [Bericht](Progress/Reports/2026-07-24_P21_CSV-Bestandsimport.md) |
| P22 | ✅ erledigt | Verfügbarkeit und Ausschlüsse | [Prompt](Prompts/MVP/P22_Verfuegbarkeit-Ausschluesse.md) | [Bericht](Progress/Reports/2026-07-24_P22_Verfuegbarkeit-Ausschluesse.md) |
| P23 | ✅ erledigt | Sicherheitsbestände | [Prompt](Prompts/MVP/P23_Sicherheitsbestaende.md) | [Bericht](Progress/Reports/2026-07-25_P23_Sicherheitsbestaende.md) |
| P24 | ✅ erledigt | Projektreservierungen | [Prompt](Prompts/MVP/P24_Projektreservierungen.md) | [Bericht](Progress/Reports/2026-07-25_P24_Projektreservierungen.md) |
| P25 | ✅ erledigt | Reservierungskonflikte | [Prompt](Prompts/MVP/P25_Reservierungskonflikte.md) | [Bericht](Progress/Reports/2026-07-25_P25_Reservierungskonflikte.md) |
| P26 | ✅ erledigt | Schlanker Produktionsentscheidungsplan | [Prompt](Prompts/MVP/P26_Build-or-Buy.md) | [Bericht](Progress/Reports/2026-07-25_P26_Build-or-Buy.md) |
| P27 | ✅ erledigt | Manuelle Preise und Profile | [Prompt](Prompts/MVP/P27_Manuelle-Preise-Profile.md) | [Bericht](Progress/Reports/2026-07-25_P27_Manuelle-Preise-und-Profile.md) |
| P28 | ✅ erledigt | CSV-Preisimport | [Prompt](Prompts/MVP/P28_CSV-Preisimport.md) | [Bericht](Progress/Reports/2026-07-25_P28_CSV-Preisimport.md) |
| P29 | ✅ erledigt | Kosten, Gewinn und ROI | [Prompt](Prompts/MVP/P29_Kosten-Gewinn-ROI.md) | [Bericht](Progress/Reports/2026-07-26_P29_Kosten-Gewinn-ROI.md) |
| P30 | ✅ erledigt | Erweiterte Einkaufslisten-Aggregation | [Prompt](Prompts/MVP/P30_Einkaufslisten-Aggregation.md) | [Bericht](Progress/Reports/2026-07-26_P30_Einkaufslisten-Aggregation.md) |
| P31 | ✅ erledigt | Einkaufsworkflow und Export | [Prompt](Prompts/MVP/P31_Einkaufsworkflow-Export.md) | [Bericht](Progress/Reports/2026-07-26_P31_Einkaufsworkflow-und-Export.md) |
| P32 | ✅ erledigt | Integrierter Kernworkspace | [Prompt](Prompts/MVP/P32_Integrierter-Produktionsworkspace.md) | [Bericht](Progress/Reports/2026-07-25_P32_Integrierter-Produktionsworkspace.md) |
| P33 | ✅ erledigt | Appweite Validierung und Fehler-UX | [Prompt](Prompts/MVP/P33_Validierung-Fehler-UX.md) | [Bericht](Progress/Reports/2026-07-26_P33_Appweite-Validierung-und-Fehler-UX.md) |
| P34 | ✅ erledigt | Performance und große Graphen | [Prompt](Prompts/MVP/P34_Performance-Grosse-Graphen.md) | [Bericht](Progress/Reports/2026-07-26_P34_Performance-und-grosse-Graphen.md) |
| P35 | ✅ erledigt | Accessibility- und UX-Politur | [Prompt](Prompts/MVP/P35_Accessibility-UX.md) | [Technikbericht](Progress/Reports/2026-07-26_P35_Accessibility-und-UX-Politur.md) · [Abnahme](Progress/Reports/2026-07-26_OFF-030_P35-Accessibility-Abnahme.md) |
| P36 | ✅ erledigt | Migration und Recovery-Drill | [Prompt](Prompts/MVP/P36_Migration-Recovery-Drill.md) | [OFF-006-Bericht](Progress/Reports/2026-07-26_OFF-006_Migration-Recovery-Lebenszyklus.md) · [P36-Bericht](Progress/Reports/2026-07-26_P36_Migration-Recovery-Drill.md) |
| P37 | ✅ erledigt | Interne Kernabnahme | [Prompt](Prompts/MVP/P37_MVP-Abnahme-Release.md) | [Bericht](Progress/Reports/2026-07-25_P37_Interne-Kernabnahme.md) |
| P38 | ✅ erledigt | SSO-Härtung | [vollständiger Prompt](Prompts/Future/P38_SSO-Haertung.md) | [Technikbericht](Progress/Reports/2026-07-26_P38_SSO-Haertung.md) · [Laufzeitkorrektur](Progress/Reports/2026-07-26_P38_SSO-Lokalbetrieb-Korrektur.md) · [Buildlog-Nachprüfung](Progress/Reports/2026-07-26_P38_Buildlog-Nachpruefung.md) · [Keychain-Dialogkorrektur](Progress/Reports/2026-07-26_P38_Keychain-Dialogkorrektur.md) · [Abschlussabnahme](Progress/Reports/2026-07-26_P38_Abschlussabnahme.md) |
| P39 | ✅ erledigt | ESI-Infrastruktur und Charaktere | [vollständiger Prompt](Prompts/Future/P39_ESI-Infrastruktur-Charaktere.md) | [Bericht](Progress/Reports/2026-07-26_P39_ESI-Infrastruktur-und-Charaktere.md) |
| P40 | ✅ einschließlich Restabnahme P50 | Persönliche Assets, Blueprints und Industry Jobs | [vollständiger Prompt](Prompts/Future/P40_Live-Assets-Blueprints-Jobs.md) | [P40-Bericht](Progress/Reports/2026-07-26_P40_Persoenliche-Assets-Blueprints-und-Jobs.md) · [P50-Abnahme](Progress/Reports/2026-07-27_P50_P40-Restabnahme-Persoenliche-ESI-Daten.md) |
| P41 | ✅ erledigt | Live-Marktpreise | [ausgeführter Prompt](Prompts/Future/P41_Live-Marktpreise.md) | [Nutzenreview](Progress/Reports/2026-07-26_P41_Nutzenreview.md) · [Ausführungsbericht](Progress/Reports/2026-07-27_P41_Live-Marktpreise.md) · [Xcode-Abnahme](Progress/Reports/2026-07-27_OFF-034_P41-Xcode-Abnahme.md) |
| P42 | ⏸️ Technik und Daten erhalten; sichtbare Projektfinanzoberfläche durch P55 zurückgezogen | Wallet und reale Projektfinanzen | [ausgeführter Prompt](Prompts/Future/P42_Wallet-Projektfinanzen.md) | [Nutzenreview](Progress/Reports/2026-07-27_P42_Nutzenreview.md) · [Ausführungsbericht](Progress/Reports/2026-07-27_P42_Wallet-und-reale-Projektfinanzen.md) · [P51-Korrektur](Progress/Reports/2026-07-27_P51_P42-Korrektur-Scope-Fehler-Plan-Ist.md) |
| P43 | ⏸️ Nutzenreview abgeschlossen | Vollständiges Reaktionsmanagement | [Review und Reaktivierungsgrenze](Prompts/Future/P43_Reaktionsmanagement.md) | [Nutzenreview](Progress/Reports/2026-07-27_P43_Nutzenreview.md) |
| P44 | ⏸️ Nutzenreview abgeschlossen | PI, Logistik und Kapazität | [Review und Reaktivierungsgrenze](Prompts/Future/P44_PI-Logistik-Kapazitaet.md) | [Nutzenreview](Progress/Reports/2026-07-27_P44_Nutzenreview.md) |
| P45 | ⏸️ verschoben | Corporation Edition | [Entwurf](Prompts/Future/P45_Corporation-Edition.md) | — |
| P46 | ⏸️ verschoben | Cloud und Mehrbenutzerbetrieb | [Entwurf](Prompts/Future/P46_Cloud-Mehrbenutzer.md) | — |
| P47 | ⏸️ verschoben | Optimierung, KI und Plattformzukunft | [Entwurf](Prompts/Future/P47_Optimierung-KI-Plattform.md) | — |
| P48 | ⏸️ optional verschoben | Öffentliche macOS-/App-Store-Distribution | [Entwurf](Prompts/Future/P48_Optionale-Apple-Distribution.md) | — |
| P50 | ✅ erledigt | P40-Restabnahme persönliche ESI-Daten | [vollständiger Prompt](Prompts/Future/P50_P40-Restabnahme-Persoenliche-ESI-Daten.md) | [Bericht](Progress/Reports/2026-07-27_P50_P40-Restabnahme-Persoenliche-ESI-Daten.md) |
| P51 | ✅ einschließlich OAuth-/Keychain-Livenachweis erledigt | P42-Korrektur Scope, Fehler, Plan/Ist | [vollständiger Prompt](Prompts/Future/P51_P42-Korrektur-Scope-Fehler-Plan-Ist.md) | [ursprünglicher Bericht](Progress/Reports/2026-07-27_P51_P42-Korrektur-Scope-Fehler-Plan-Ist.md) · [Nachkorrektur](Progress/Reports/2026-07-27_P51_OAuth-und-Keychain-Nachkorrektur.md) |
| P52 | ⏸️ P40/P41 abgenommen; P42-Eigentümergates durch P55-Oberflächenrückzug pausiert | P40–P42 Eigentümer-Betriebsabnahme | [vollständiger Prompt](Prompts/Future/P52_P40-P42-Eigentuemer-Betriebsabnahme.md) | [Zwischenbericht](Progress/Reports/2026-07-27_P52_Eigentuemer-Betriebsabnahme.md) · [Restgate-Inventur](Progress/Reports/2026-07-28_P52_OFF-037-Restgate-Inventur.md) · [OFF-053 Technik](Progress/Reports/2026-07-28_P52_OFF-053-Wallet-Zuordnungsrest.md) |
| P53 | ✅ erledigt | Steuerung und Xcode-Kanon | [vollständiger Prompt](Prompts/Future/P53_Steuerung-und-Xcode-Kanon-Bereinigung.md) | [Vorschau und Ausführung](P53_CLEANUP_PREVIEW.md) · [Bericht](Progress/Reports/2026-07-28_P53_Steuerung-und-Xcode-Kanon.md) |
| P54 | ⬜ wartet auf gesonderte Commit-Freigabe | Lokaler Git-Sicherungspunkt | [vollständiger Prompt](Prompts/Future/P54_Gepruefter-lokaler-Git-Sicherungspunkt.md) | — |
| P55 | ✅ technisch und sichtbar bestanden | Projektbudgetplanung | [vollständiger Prompt](Prompts/MVP/P55_Projektbudgetplanung.md) | [Bericht](Progress/Reports/2026-07-28_P55_Projektbudgetplanung.md) · [Eigentümerabnahme](Progress/Reports/2026-07-29_OFF-054_Eigentuemer-Sichttest.md) |
| P56 | ✅ technisch und sichtbar bestanden | Gruppierte Build-or-Buy-Auswahl, Reaktionsfilter und lesbare Zahlen | [vollständiger Prompt](Prompts/MVP/P56_Gruppierte-Build-or-Buy-Auswahl.md) | [Grundbericht](Progress/Reports/2026-07-28_P56_Gruppierte-Build-or-Buy-Auswahl.md) · [Reaktionsfilter](Progress/Reports/2026-07-29_P56_Reaktionsfilter-und-kompakte-Auswahl.md) · [Zahlenformat](Progress/Reports/2026-07-29_P56_Deutsche-Zahlenformatierung.md) · [Eigentümerabnahme](Progress/Reports/2026-07-29_OFF-054_Eigentuemer-Sichttest.md) |
| P57 | ✅ einschließlich OFF-059 erledigt | Produktionsbuch-Domäne und Persistenz | [vollständiger Prompt](Prompts/MVP/P57_Produktionsbuch-Domaene-Persistenz.md) | [Technikbericht](Progress/Reports/2026-07-29_P57_Produktionsbuch-Domaene-Persistenz.md) · [Eigentümer-Neustarttest](Progress/Reports/2026-07-29_OFF-059_P57-Eigentuemer-Neustarttest.md) |
| P58 | ✅ einschließlich OFF-060 erledigt | Produktionskosten und Preisvorschläge | [vollständiger Prompt](Prompts/MVP/P58_Produktionskosten-und-Preisvorschlaege.md) | [Technikbericht](Progress/Reports/2026-07-29_P58_Produktionskosten-und-Preisvorschlaege.md) · [Eigentümerabnahme](Progress/Reports/2026-07-29_OFF-060_Eigentuemerabnahme.md) |
| P59 | 🔄 technisch umgesetzt; OFF-061 in Bearbeitung | Wallet-/Verkaufszuordnung und Realgewinn | [vollständiger Prompt](Prompts/MVP/P59_Wallet-Verkaufszuordnung-Realgewinn.md) | [Technikbericht](Progress/Reports/2026-07-29_P59_Wallet-Verkaufszuordnung-und-Realgewinn.md) · [Signingnachweis](Progress/Reports/2026-07-29_KI-060_Lokale-Signierung.md) · [OFF-061-Vorbereitung](Progress/Reports/2026-07-29_OFF-061_Vorbereitung-Wallet-Nachweise.md) |
| P60 | ⬜ offen | Produktionsanalyse und Walletübersicht | [vollständiger Prompt](Prompts/MVP/P60_Produktionsanalyse-und-Wallet-Uebersicht.md) | — |
| P61 | ⬜ offen | Metenox-Wirtschaftlichkeitsrechner | [vollständiger Prompt](Prompts/MVP/P61_Metenox-Wirtschaftlichkeitsrechner.md) | — |

## Ergänzende verbindliche SDE-Pakete

AUD-SDE-001 hat den umfangreichen CCP-SDE-Gesamtauftrag gegen P07–P09
abgeglichen. Die Offline-Kerne bleiben erledigt; folgende Lücken sind vor der
MVP-Abnahme zusätzlich zu schließen:

| ID | Status | Titel | Promptdatei | Abschlussbericht |
|---|---|---|---|---|
| P07A | ✅ erledigt | Offizielle SDE-Metadaten, HTTP-Cache und CCP-Compliance | [Prompt](Prompts/MVP/P07A_SDE-Metadaten-HTTP-Cache-Compliance.md) | [Bericht](Progress/Reports/2026-07-23_P07A_SDE-Metadaten-HTTP-Cache-Compliance.md) |
| P07B | ✅ erledigt | Sicherer SDE-Download, Archivprüfung und Aktivierung | [Prompt](Prompts/MVP/P07B_SDE-Download-Archiv-Aktivierung.md) | [Technikbericht](Progress/Reports/2026-07-23_P07B_SDE-Download-Archiv-Aktivierung.md) · [Realabnahme](Progress/Reports/2026-07-23_P07B_Real-SDE-Abnahme.md) · [Speicherabnahme](Progress/Reports/2026-07-23_P07B_Speichergrenze.md) |
| P07C | ✅ erledigt | SDE-Einstellungen, Automatisierung und rechtliche Hinweise | [Prompt](Prompts/MVP/P07C_SDE-Einstellungen-Automation-Recht.md) | [Technikbericht](Progress/Reports/2026-07-23_P07C_SDE-Einstellungen-Automation-Recht.md) · [abschließende GUI-Abnahme in P09B](Progress/Reports/2026-07-23_P09B_Xcode-Projekt-Schemes.md) |

## Ergänzende Releaseprüfung

| ID | Status | Titel | Promptdatei | Abschlussbericht |
|---|---|---|---|---|
| REL-001 | ✅ technische Prüfung erledigt | Öffentliche Release-/Complianceprüfung einschließlich OFF-031 | [Prompt](Prompts/MVP/REL-001_Oeffentliche-Release-Compliance.md) | [Bericht](Progress/Reports/2026-07-26_REL-001_Oeffentliche-Release-Compliance.md) |

## Ergänzende Planungsentscheidung

| ID | Status | Titel | Promptdatei | Abschlussbericht |
|---|---|---|---|---|
| PLAN-003 | ✅ erledigt | Lokaler Betrieb und optionale Distribution | [Prompt](Prompts/MVP/PLAN-003_Lokaler-Betrieb-und-optionale-Distribution.md) | [Bericht](Progress/Reports/2026-07-26_PLAN-003_Lokaler-Betrieb-und-optionale-Distribution.md) |
| PLAN-004 | ✅ erledigt | Folgeplanung für den lokalen Ausbau | [Prompt](Prompts/MVP/PLAN-004_Folgeplanung-lokaler-Ausbau.md) | [Bericht](Progress/Reports/2026-07-26_PLAN-004_Folgeplanung-lokaler-Ausbau.md) |
| PLAN-005 | ✅ erledigt | Restkorrektur und Betriebsabnahme P50–P54 | [Prompt](Prompts/MVP/PLAN-005_P50-P54-Restabnahmefolge.md) | [Bericht](Progress/Reports/2026-07-27_PLAN-005_P50-P54-Restabnahmefolge.md) |
| PLAN-006 | ✅ Spezifikation erledigt | Produktionsbuch, Verkaufserfolg und Metenox P57–P61 | [Prompt](Prompts/MVP/PLAN-006_Produktionsbuch-und-Metenox-Folgeplanung.md) | [Bericht](Progress/Reports/2026-07-29_PLAN-006_Produktionsbuch-und-Metenox-Folgeplanung.md) |

## Nächste Handlung

PLAN-005 ordnet die nach dem Funktionsaudit notwendigen Restarbeiten als
P50→P51→P52→P53→P54. P40-1 bis P40-4, Auswahlrücknahme sowie persönlicher
und Wallet-Snapshotpfad sind real bestätigt. Die benannte
Marktquellenauswahl, Vorschau, Preisübernahme, Herkunft/Cachezeit und
Neustart-/Offlinebestand sowie OFF-051 sind live bestanden. P52 endet mit
den weiterhin offenen P42-Projektzuordnungs-/Endgates als dokumentiertem
Restblocker. P53 archivierte nach ausdrücklicher Bestätigung neun
historische Xcode-Projekte und den alten P21-Entwurf recoverbar; genau ein
Projektkanon liegt in der Repositorywurzel.
OFF-045/OFF-046 bleiben unabhängig als Namens-Livetests erhalten. P49 bleibt
unbelegt; P43–P48 werden nicht vorgezogen. OFF-052 ist ohne Änderung
geschlossen: Zertifikats-OU, lokale Team-ID und unveränderter Standardbuild
stimmen überein.
Die drei P42-Gates werden nicht fortgesetzt, solange die frühere sichtbare
Projektfinanzoberfläche bewusst zurückgezogen ist. P55 stellt stattdessen
das Planbudget aus Materialeinkauf, Logistik und Produktion bereit. P56
gruppiert Build-or-Buy nach Produktion, T2/Invention sowie den drei
Reaktionsarten und ergänzt Filter und globale Sofortaktionen.
OFF-054 hat diesen neuen Ablauf sichtbar bestätigt. Der dabei erkannte
fehlende Übergang von einer ESI-Preisvorschau ohne Ziel-Preissatz zur
Preisübernahme wurde als OFF-058 in P58 technisch geschlossen. P54 darf weiterhin nur
nach einer gesonderten ausdrücklichen Commit-Freigabe beginnen und enthält
keinen Push.

PLAN-006 überführt die private Referenzarbeitsmappe ohne Datenimport in den
neuen Ausbau P57–P61. OFF-054 und OFF-055 sind abgeschlossen. P57 ist
einschließlich OFF-059 erledigt: Charge `2026-0001` wurde gespeichert, die App
vollständig beendet und nach dem Neustart mit unveränderter Nummer, Produkt und
Ort wieder geöffnet. P58 ist einschließlich OFF-058 und der realen
OFF-060-Eigentümerabnahme abgeschlossen. P59 ist technisch umgesetzt; als
nächster Schritt folgt OFF-061. P60 beginnt nicht automatisch.

Weitere Details: [Kern-MVP-Plan](LEAN_MVP_PLAN.md), [Prompt-Register](Prompts/README.md), [aktueller Projektstatus](CURRENT_PROJECT_STATUS.md), [Feature-Matrix](FEATURE_MATRIX.md), [Offene-Punkte-Audit](OFFEN.md), [bekannte Probleme](KNOWN_ISSUES.md).
