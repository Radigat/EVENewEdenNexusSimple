# SDE-Metadaten- und Aktualitätsprüfung

Stand: 2026-07-23 · P07A

## Zweck und Scope

P07A ergänzt einen sicheren, ressourcenschonenden Metadatenpfad für den
offiziellen Tranquility-SDE. Er vergleicht den lokal aktiven Build mit CCPs
aktueller Buildnummer, bewertet den offiziellen Schema-Changelog und speichert
den Prüfzustand lokal.

Archivdownload, ZIP-Entpacken, Import und Aktivierung gehören zu P07B.
P07C verdrahtet den Check produktiv mit Startautomation und
Benutzeroberfläche; die P07A-Grenze selbst bleibt UI-frei.

## Offizielle Ressourcen

Der Adapter akzeptiert ausschließlich:

- `https://developers.eveonline.com/static-data/tranquility/latest.jsonl`
- `https://developers.eveonline.com/static-data/tranquility/schema-changelog.yaml`

Die URLs sind feste Programmkonfiguration. Redirects werden nicht verfolgt;
eine abweichende finale URL wird zusätzlich abgelehnt. Frei konfigurierbare
Hosts werden nicht als SDE-Metadatenquelle verwendet.

Der manuelle read-only Nachweis vom 2026-07-23 ergab:

- aktueller Build `3444265`,
- Release `2026-07-23T11:06:22Z`,
- `latest.jsonl`: HTTP 200, `application/jsonlines+json`, ETag,
  Last-Modified und `Cache-Control: max-age=300`,
- `schema-changelog.yaml`: HTTP 200, `text/vnd.yaml`, ETag,
  Last-Modified und `Cache-Control: max-age=300`,
- höchster verstandener Changelog-Eintrag `afterBuildNumber: 3407448`.

Der Abruf lud kein SDE-Archiv herunter und änderte keinen lokalen Katalog.

## Schichten

```text
SDEUpdateService
├── ActiveSDEVersionReading
├── SDEReleaseChecking
├── SDEUpdateStateStoring
├── SDEUpdateClock
└── DiagnosticLogging
        │
        ├── CCPSDEMetadataClient
        │   ├── SDEHTTPTransport
        │   ├── SDEBackoffSleeping
        │   └── SDEJitterGenerating
        └── SwiftDataSDEUpdateStateRepository
```

Application definiert Zustände, Ports, Policy und Orchestrierung ohne
URLSession, SwiftData oder UI. Infrastructure implementiert HTTP, Parser,
Timeouts und Retry. Persistence liest die aktive SDE-Version und speichert den
Prüfzustand in Schema v4.

## Cache- und Abrufregeln

- Automatische Prüfungen besitzen ein lokales Mindestintervall von 24 Stunden.
- Eine erzwungene manuelle Prüfung umgeht nur dieses lokale Intervall.
- Frische, vom Server vorgegebene Cachezeiten werden auch manuell und für jede
  der beiden Ressourcen getrennt respektiert.
- ETag und Last-Modified werden getrennt je Ressource gespeichert und als
  `If-None-Match` beziehungsweise `If-Modified-Since` wiederverwendet.
- HTTP 304 nutzt nur einen zuvor validierten gespeicherten Metadatenstand.
- Ein 304 ohne passende Cache-Nutzlast wird sicher abgelehnt.
- Es existiert keine Polling-Schleife.

## HTTP- und Retryregeln

Der URLSession-Transport arbeitet mit deaktiviertem automatischem URL-Cache
und expliziten Request-/Resource-Timeouts. Der Applicationcache bleibt damit
die nachvollziehbare Quelle für Validatoren und Frische.

Wiederholt werden höchstens Transport-/Timeoutfehler sowie HTTP 408, 429, 500,
502, 503 und 504. Die Anzahl ist begrenzt. `Retry-After` hat Vorrang;
andernfalls wird exponentielles Backoff mit injizierbarem Jitter verwendet.
Andere 4xx-Antworten werden nicht wiederholt. Task-Abbruch wird unverändert
weitergereicht.

Der User-Agent wird zentral aus Appname, Version, Integrationszweck und einer
optionalen Eigentümerkontaktangabe erzeugt. Zeilenumbrüche und Steuerzeichen
werden abgelehnt. Eine Kontaktadresse wird weder erfunden noch hartcodiert.

## Parser- und Schema-Gate

Der JSONL-Parser akzeptiert unbekannte Zusatzfelder, verlangt aber genau einen
eindeutigen `_key == "sde"`-Datensatz, eine positive Buildnummer und ein
gültiges ISO-8601-Releasedatum. Fehlende Pflichtfelder, doppelte Datensätze
oder geänderte Datentypen sind inkompatibel.

Der bewusst kleine YAML-Parser liest ausschließlich
`schemaChangelog[].afterBuildNumber`. Zusätzliche Felder werden toleriert;
fehlende oder typveränderte Pflichtwerte werden abgelehnt. Liegt eine
Schemaänderung nach dem konfigurierten verstandenen Build, liefert der Service
`schemaReviewRequired`. P07A aktiviert in diesem Zustand nichts.

## Persistenz

`NexusSchemaV4` 4.0.0 ergänzt genau einen `SDEUpdateCheckRecord` mit:

- letztem Versuch und letzter erfolgreicher Prüfung,
- zuletzt bekannter offizieller Buildnummer und Releasezeit,
- Validatoren und Cachefrist je offizieller Ressource,
- Changelog-Höchststand, Eintragszahl und Parser-Version,
- sicherem Ergebnisstatus und sicherem Fehlercode.

Die Migration 3.0.0 → 4.0.0 ist additiv. Bestehende Benutzer- und SDE-Daten
werden nicht verändert. Mehrere aktive SDE-Versionen oder mehrere
Prüfzustandsdatensätze werden als Integritätsfehler abgelehnt.

## Statusmodell

- `current`
- `updateAvailable`
- `notModified`
- `offline`
- `schemaReviewRequired`
- `failed`

Offline- oder HTTP-Fehler deaktivieren den bestehenden aktiven Katalog nicht.
Rohantworten, lokale Pfade und personenbezogene Werte werden weder im
persistierten Status noch im zentralen Diagnoseereignis gespeichert.

## Eigentümeraufgabe

Vor produktivem Netzwerkbetrieb muss der Projekteigentümer eine geeignete
Kontaktmöglichkeit für die zentrale User-Agent-Konfiguration festlegen und die
aktuellen CCP-Bedingungen persönlich prüfen. P07A akzeptiert keine Vereinbarung
stellvertretend.

## Produktive P07C-Verdrahtung

`SDEAppComposition` erzeugt den Metadatenclient und `SDEUpdateService` am
App-Rand. Nach erfolgreichem Storestart führt `NexusAppRuntime` zuerst eine
kontaktfreie Recovery abgebrochener Installationsartefakte aus und löst nur
bei deren Erfolg einen nicht blockierenden, nicht erzwungenen Check aus. Der
Scheduler verwendet mindestens 24 Stunden; manuelle Checks sind möglich,
parallele Requests werden verhindert.

Automatische Prüfung ist an. Download und Installation bleiben getrennte
Opt-ins. Offline-, Fehler- und Schemaänderungszustände werden sichtbar
dargestellt und verändern den aktiven Katalog nicht.

## Ergänzung P07B

P07B verwendet eine durch P07A validierte positive Buildnummer ausschließlich
für die feste versionierte Archiv-URL. Schema-Gate, Eigentümerbestätigung und
reale User-Agent-Kontaktangabe sind Voraussetzungen des Installationspfads.
Download, ZIP-Prüfung, isolierter Store, Backup, Promotion, Rollback und
Phasenjournal sind in
[SDE_ARCHIVE_INSTALLATION.md](SDE_ARCHIVE_INSTALLATION.md) beschrieben.

Der aktuelle Real-SDE-Lauf und P07B sind nach persönlicher
Eigentümerentscheidung abgeschlossen. P07C ergänzt die produktive Bedienung.
P09B hat den manuellen Fenster-, Status-, Tastatur- und VoiceOver-Nachweis
über das echte App-Bundle mit isoliertem Profil abgeschlossen.

### OFF-055-Korrektur

Seit 2026-07-29 übernimmt der Installer zusätzlich den zum offiziellen
Zielbuild gespeicherten höchsten Changelog-Eintrag. Er vergleicht diesen mit
dem verstandenen Parserstand. Die Daten-Buildnummer selbst ist kein
Schemawechsel. Damit bleiben unbekannte Schemaänderungen gesperrt, während
reine Datenupdates nicht mehr fälschlich `NEN-SDE-007-SCHEMA` auslösen.
