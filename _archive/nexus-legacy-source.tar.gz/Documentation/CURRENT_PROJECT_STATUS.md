# Aktueller Projektstatus

## 2026-07-30 – KI-064 Chargenerfassung vereinfacht

Die P57-Chargenerfassung verlangte entgegen ihrem optionalen Domänenmodell
eine technische Sonnensystem-ID. Dadurch blockierte ein für die Planung
entbehrliches Detail den OFF-061-Hauptablauf.

Produktionsort, Charakterbezug, ESI-Job und technische IDs sind nun optionale
Zusatzangaben. Projekt, Datum, Status, Runs, ME, TE und Ausgabemenge bilden den
sichtbaren Hauptablauf; Namen können ohne technische IDs erfasst werden.
Fehlende Zusatzangaben bleiben als sachlicher Hinweis sichtbar, werden nicht
erfunden und verhindern die ausdrücklich bestätigte Speicherung nicht.

5/5 Fachtests und 1/1 UI-Vertragstest sowie der
Apple-Development-signierte arm64-Xcode-Debugbuild sind erfolgreich. Die
Vollsuite erreicht 706/716; die zehn Fehler liegen unverändert in der
zurückgezogenen P51-Projektfinanz-UI-Prüfung und lokalen
SSO-Security-Key-Fixtures. OFF-061 bleibt bis zum sichtbaren vereinfachten
Eigentümerlauf und den Verkaufszuordnungen in Bearbeitung.

Der Projekteigentümer hat anschließend bestätigt, dass die vereinfachte
Chargenerfassung deutlich besser funktioniert. KI-064 ist damit technisch
und sichtbar geschlossen. OFF-061 setzt bei der Kostenbasis der neuen Charge
fort.

## 2026-07-30 – KI-063 Budgetkosten dauerhaft beschriftet

Im Bereich **Budget** waren „Logistikkosten“ und „Produktionskosten“ nur als
Platzhalter der beiden Eingabefelder vorhanden. Sobald ein Wert angezeigt
oder das Feld fokussiert wurde, war der Zweck visuell nicht mehr eindeutig.

Beide Eingaben besitzen nun unmittelbar davor eine dauerhaft sichtbare
Beschriftung und unmittelbar danach ihre Einheit `ISK`. Die vorhandenen
Bindings, Validierungen und Budgetberechnungen wurden nicht verändert.
Der fokussierte Architekturtest, SwiftPM Debug und der
Apple-Development-signierte arm64-Xcode-Debugbuild sind erfolgreich.
OFF-061 bleibt unabhängig davon in Bearbeitung.

## 2026-07-30 – KI-062 vollständig geschlossen, OFF-061 in Bearbeitung

`NEN-GRAPH-001` beim Projekt `Module für DOC` wurde auf einer konsistenten
temporären Kopie des aktuellen Xcode-Laufstores reproduziert. Projekt und
aktiver SDE-Build 3.448.696 waren konsistent. Der eigentliche Fehler lag im
Rezeptresolver: Für `Tungsten Carbide` wurden die unveröffentlichte
Testformel 45732 und die veröffentlichte Reaktionsformel 46207 vor der
Veröffentlichungsprüfung als Mehrdeutigkeit gewertet.

Die implizite Auswahl berücksichtigt jetzt vorhandene veröffentlichte
Kandidaten zuerst. Genau ein veröffentlichtes Rezept wird verwendet; mehrere
veröffentlichte Kandidaten bleiben blockiert. Eine explizite Blueprint-ID
wird niemals durch ein anderes Rezept ersetzt und ein unveröffentlichtes
explizites Rezept bleibt ungültig. Es wurden keine SDE-, Projekt- oder
Benutzerdaten geändert.

Auf derselben temporären Storekopie entstand danach der vollständige
T2-/Reaktionsgraph mit 566 Knoten und 565 Kanten. 44/44 fokussierte
Resolver-, Graph-, Persistenz- und T2-Tests sowie der
Apple-Development-signierte arm64-Xcode-Debugbuild sind erfolgreich. KI-062
ist technisch behoben. Der Projekteigentümer bestätigte anschließend im neu
gebauten realen App-Lauf, dass der Produktionsgraph wieder erzeugt werden
kann. Damit ist auch die sichtbare Betriebsabnahme bestanden und KI-062
vollständig geschlossen. OFF-061 bleibt bis zum anschließenden Budget-,
Chargen-, Kosten- und Verkaufsnachweis in Bearbeitung.

## 2026-07-29 – KI-060 geschlossen, OFF-061 in Bearbeitung

Produktionschargen können bestätigte Projektkapazität aus vorhandenen
Wallet-Verkaufs- und Gebührenzuordnungen kontrolliert unterteilen. Zusätzlich
sind begründete manuelle Istbelege möglich. Jede neue Zuordnung entsteht
zunächst als schreibfreie Vorschau und wird erst nach ausdrücklicher
Bestätigung gespeichert. Stale Walletrevisionen, Doppelverwendung,
Quellüberbuchung und Überverkauf werden abgewiesen.

Die erste Zuordnung bindet die Charge an genau einen unveränderlichen
P58-Kostensnapshot. Verkaufte und offene Units, Erlös, Verkaufsgebühren,
realisierter Kostenanteil, Durchschnittspreis, Marge, ROI und Realgewinn
werden deterministisch berechnet. Offene Marktorders und öffentliche
Marktquotes bleiben Prognosen und erzeugen keinen Realgewinn.

Schema v28 speichert nur die chargengebundene Zuordnung und ihre notwendige
Provenienz. Accounttrennung oder fehlender Offline-Walletcache löschen
bestätigte Historie nicht. Die v28-Erkennung, Vor-Migrations-Sicherung,
Wiederöffnung und Recovery wurden nach einer im Volltest gefundenen
v27-Restannahme korrigiert und gezielt erneut geprüft.

KI-060 ist geschlossen: Die bereits lokale konfigurierte Identität ist wieder
als gültige Apple-Development-Identität verfügbar. Der normale arm64-
Xcode-Debugbuild ist signiert erfolgreich; `codesign --verify --deep --strict`
bestätigt App, Team `99K5WATB4A` und Designated Requirement. Eine Änderung
an Signing- oder Teamdaten war nicht erforderlich.

Die technische Abnahme umfasst weiterhin 15/15 fokussierte P59-/Migration-/
Recovery-Tests und 713/713 vollständige SwiftPM-Tests. Für die notwendige
sichtbare Wallet-Nachweiszuordnung bestanden zusätzlich 19/19 fokussierte
Architektur-, Wallet- und Verkaufsregressionen sowie ein erneut signierter
Xcode-Debugbuild. Der kanonische aktuelle Build öffnet den produktiven
v28-Store. Alte registrierte P39-/P40-Buildkopien
wurden nur aus LaunchServices ausgetragen, nicht gelöscht; deren
`NEN-PER-001` war kein Fehler des aktuellen Builds. Die reale
Eigentümerabnahme mit Teilzuordnung, Vorschau-Verwerfen, Gebühr,
Vollzuordnung und Neustart bleibt OFF-061.

Der produktive Store enthält vor dem Eigentümerlauf eine Charge mit nur einer
Output-Unit sowie keine bestätigte Chargenkostenbasis, Wallet-Projektzuordnung
oder Verkaufszuordnung. Die App bietet deshalb bei vorhandenem
Wallet-Snapshot nun den engen Einstieg **Wallet-Nachweise zuordnen**. Er nutzt
den vorhandenen Vorschau-/Bestätigungsvertrag für Verkaufstransaktionen und
Gebührenjournal, ohne die durch P55 zurückgezogene alte
Projektfinanzen-Oberfläche wieder einzuführen. Reale Werte werden erst nach
sichtbarer Eigentümerbestätigung gespeichert. P60 wurde nicht begonnen.

Die Charge `2026-0001` kann nicht als OFF-061-Testcharge nachträglich
umgewertet werden: Ihr gebundener Rhea-Projekt-/Graphstand liegt zeitlich vor
dem inzwischen geänderten aktuellen Projekt und Graph. Die Stale-Sperre ist
beabsichtigt und verhindert eine falsche historische Materialkostenbasis.
OFF-061 benötigt deshalb einen aktuellen Projekt-/Graphstand für mindestens
zwei Einheiten und anschließend eine neue bestätigte Charge.

## 2026-07-29 – P58 einschließlich OFF-060 abgeschlossen

Das Produktionsbuch kann für jede Charge eine vollständige, typisierte
Kostenbasis aus Material, Job/Index, Facility/SCC/Steuer, Blueprint/Invention,
Logistik, Marktgebühren und manuellen Zusatzkosten vorbereiten. Unbekannte
Werte bleiben unbekannt. Stückkosten, Aufschläge +5/+10 Prozent, Erlös,
Gewinn, Marge, ROI und Break-even werden deterministisch in
ISK-Hundertsteln berechnet.

Jita ist die Standard-Sell-Referenz; eine zweite benannte öffentliche Region
oder Marktlocation kann über den vorhandenen P41-Pfad gewählt werden. Quotes
speichern Menge, Markt, Zeit, Frische, Orders, Snapshot und Policy. Ein
manueller/CSV-Preissatz wirkt nur nach ausdrücklicher Fallbackauswahl.
Die Kostenvorschau zeigt jetzt je Jita-/Alternativquote den benannten Markt,
Live-/Cache-/Fallbackherkunft, Beobachtungszeit, Mengenabdeckung, Orderzahl,
Preisregel und gegebenenfalls Cacheablauf. Marge und ROI stehen sichtbar bei
den übrigen Kennzahlen.
Vorschau und Bestätigung erzeugen einen unveränderlichen
`ProductionBatchCostSnapshot` in Schema v27.

OFF-058/KI-059 ist technisch geschlossen: Im eingebetteten
ESI-Materialpreisablauf kann ein Ziel-Preissatz angelegt oder gewählt werden;
nach bestätigter Übernahme wird er ausgewählt und das Budget neu geladen.
37/37 ursprüngliche P58-Tests und 704/704 vollständige SwiftPM-Tests sind
bestanden. Nach der reinen OFF-060-Sichtbarkeitskorrektur bestanden zusätzlich
18/18 fokussierte Tests und ein neuer Apple-Development-signierter
Xcode-Debugbuild. Der Review ist technisch bestanden.

Der Eigentümer hat am 2026-07-29 die Schließung des sichtbaren OFF-060-Ablaufs
mit Jita und einer geänderten Marktquelle ausdrücklich bestätigt. Vorschau,
Quell-/Zeitangaben, Kennzahlen und die Bestätigungsgrenze gelten damit im
lokalen Betrieb als abgenommen. OFF-060 und P58 sind `✅`.

P59 wurde danach technisch umgesetzt; sein aktueller Stand steht am
Dokumentanfang.

## 2026-07-29 – P57 einschließlich OFF-059 abgeschlossen

Der reale lokale OFF-059-Lauf hat Charge `2026-0001` für **Rhea** im System
**UALX-3** nach Vorschau und ausdrücklicher Bestätigung gespeichert. Der
App-Prozess wurde vollständig beendet und derselbe signierte Debug-Build neu
gestartet. Das Produktionsbuch öffnete dieselbe Charge mit unveränderter
Jahresnummer, Produkt, Ausgabemenge, Status und Ort wieder.

Der während der ersten Abnahme gefundene UI-Blocker wurde eng behoben: Der
Bestätigungsdialog gehört nun zur modalen Erfassungsansicht und ist dort
unmittelbar sichtbar; `productionLedger.confirmBatch` bildet den prüfbaren
Bestätigungsknopf ab. 24/24 fokussierte Tests, 695/695 vollständige
SwiftPM-Tests und der Apple-Development-signierte Xcode-Debugbuild sind grün.
P57 und OFF-059 sind damit `✅`. Zu diesem damaligen Stand waren P58 und
OFF-058 noch nicht begonnen; der aktuelle P58-Stand steht am Dokumentanfang.

## 2026-07-29 – P57 technischer Zwischenstand vor OFF-059

Das neue native Modul **Produktionsbuch** erfasst tatsächliche
Produktionschargen getrennt vom veränderbaren Projektplan. Domäne und
Application-Service binden Projekt-, Graph-, Regel- und SDE-Stand, erlauben
manuelle oder ESI-Job-basierte Vorbelegung und schreiben erst nach Vorschau
und ausdrücklicher Bestätigung. Unaufgelöste Namen werden nicht erfunden.

Schema v26 ergänzt Chargensnapshots und pro UTC-Kalenderjahr eindeutige
Anzeigenummern. Die additive v25→v26-Migration erzeugt keine historischen
Chargen. Automatisierte Nachweise decken parallele Nummernvergabe,
Stale-Schutz, Filter, Abbruch, Wiederöffnung sowie Backup/Restore ab.

Die App bietet Tabelle, Details und Filter nach Jahr, Status, Projekt,
Charakter, Produkt und Ort. 27/27 fokussierte Tests, 695/695 Tests der
vollständigen Suite sowie der Apple-Development-signierte Xcode-Debugbuild
sind bestanden. Der gesonderte Review ist technisch bestanden.

Zu diesem Zwischenstand blieb P57 gemäß Definition of Done `⚠️`, bis der reale
Speichern-/Neustartnachweis erbracht war. OFF-059 hat diesen Nachweis
anschließend erbracht; maßgeblich ist der oberste Statusabschnitt. P58 und
OFF-058 wurden nicht begonnen.

## 2026-07-29 – OFF-054 Eigentümer-Sichttest bestanden

Der Eigentümer hat den sichtbaren P55/P56-Ablauf als bestanden bestätigt.
Insbesondere wurde die Punktgruppierung der dargestellten Mengen und
ISK-Beträge im aktuellen Build ausdrücklich bestätigt. Der aktuelle
Apple-Development-signierte Xcode-Debugbuild sowie drei erneut fokussierte
Gruppen-/Formatregressionen bestanden.

Die ESI-Materialpreisvorschau konnte im Eigentümerbestand mangels
auswählbarem Ziel-Preissatz nicht gespeichert werden; das Budget blieb
deshalb bei unvollständigen Einkaufspreisen. Der bestehende schreibfreie
Fail-closed-Vertrag funktioniert damit wie spezifiziert, besitzt aber keinen
verständlichen eingebetteten Anlage-/Auswahlweg. Dieser getrennte Befund ist
als OFF-058/KI-059 P58 zugeordnet und ändert die Eigentümerentscheidung zu
OFF-054 nicht.

Zu diesem Abnahmezeitpunkt war P57 noch nicht begonnen; der aktuelle
P57-Stand ist im obersten Statusabschnitt dokumentiert.

## 2026-07-29 – OFF-055 real abgeschlossen und Preisquellenvertrag geschärft

Der offizielle SDE-Build `3.448.696` wurde vollständig importiert und atomar
aktiviert. Das Installationsjournal endet in `completed`, meldet
Sicherheitsbackup und erfolgreiches Cleanup. Nach einem echten App-Prozess-
neustart läuft New Eden Nexus weiter; die lokale Datenbank führt ausschließlich
Build `3.448.696` als aktiv. `PRAGMA quick_check` meldet `ok`, der vorherige
Build `3.444.265` bleibt als inaktive Rollbackversion erhalten. OFF-055 ist
damit technisch und im lokalen Eigentümerbetrieb erledigt.

P57 bis P61 wurden zusätzlich zu vollständigen Ausführungsprompts erweitert.
Für prognostische Preise gilt: öffentliche Live-ESI-Quote am benannten Markt,
Cache derselben Quelle, ausdrücklich gewählter manueller/CSV-Fallback und
sonst `nicht verfügbar`. Jita ist Standard; Region, Trade Hub oder bekannte
öffentliche Station/Struktur können vom Benutzer geändert werden. Realisierte
P59-Werte stammen nur aus bestätigten Belegen oder manuellen Istbuchungen.

OFF-054 und OFF-055 sind abgeschlossen. Zu diesem Zeitpunkt wartete P57 noch
auf ausdrücklichen Auftrag; inzwischen ist es technisch umgesetzt.

## 2026-07-29 – PLAN-006 Produktionsbuch und Metenox-Folgeplanung

Die private Eigentümer-Arbeitsmappe wurde schreibfrei analysiert. Nexus besitzt
bereits Projekt-, Graph-, Budget-, Preis-, Industry-Job- und Walletgrundlagen.
Es fehlen jedoch ein persistentes Produktionsbuch mit Chargen, eine neue
chargengebundene Istfinanz, aggregierte Produktionsauswertungen und ein
Metenox-Wirtschaftlichkeitsrechner.

[`PRODUCTION_LEDGER_AND_METENOX.md`](PRODUCTION_LEDGER_AND_METENOX.md)
definiert die Trennung von Plan, Charge, Beleg und Verkauf. P57–P61 sind
zum Planungszeitpunkt vollständig spezifiziert, aber nicht begonnen. Private Arbeitsmappendaten
wurden weder importiert noch in Git übernommen. OFF-056 bündelt die
Produktionsbuch-/Istfinanzumsetzung; OFF-057 bindet den Metenox-Rechner an
erneut verifizierte, versionierte CCP-/SDE-Regeln.

OFF-054 und OFF-055 sind abgeschlossen. Der damalige nächste Schritt war P57;
sein aktueller technischer Stand steht am Dokumentanfang. P54 bleibt ein
unabhängiger, gesondert freizugebender lokaler Commit.

## 2026-07-29 – OFF-055 SDE-Schema-Gate-Korrektur

`NEN-SDE-007-SCHEMA` entstand beim Wechsel von Build `3.444.265` auf
`3.448.696`, obwohl der offizielle CCP-Schema-Changelog weiterhin höchstens
`afterBuildNumber: 3.407.448` meldet. Der Metadatencheck bewertete das korrekt,
der Installer verglich jedoch fälschlich die neue Daten-Buildnummer direkt mit
dem verstandenen Parserstand.

Der Installationsvertrag führt nun den tatsächlich geprüften höchsten
Changelog-Eintrag getrennt von Zielbuild und Parserstand. Installiert wird nur,
wenn der gespeicherte offizielle Build exakt zum Ziel passt und der geprüfte
Schemawechsel verstanden ist. Fehlende oder unbekannte Metadaten bleiben
fail-closed. Downloadcache, isolierter Stagingstore, Backup, atomare
Aktivierung und Rollback sind unverändert.

7/7 SDE-Installationstests einschließlich der neuen Datenbuild-/alten
Schemawechsel-Regression und 682/682 Gesamttests bestanden. Der
Apple-Development-signierte Xcode-Debugbuild meldete `BUILD SUCCEEDED`.
Die technische Korrektur selbst änderte zunächst keine produktiven Daten.
Der anschließende Eigentümerlauf aktivierte Build `3.448.696` vollständig;
Aktivierung, Backup, Cleanup, Prozessneustart und aktive Katalogversion wurden
am 2026-07-29 nachgewiesen. `OFF-055` ist erledigt.

## 2026-07-29 – P56 Deutsche Zahlenformatierung

Sichtbare Mengen und Zählwerte verwenden nun zentral die feste deutsche
Tausendergruppierung (`1.234.567`). Sichtbare ISK-Werte ergänzen
Dezimalkomma und zwei Nachkommastellen (`1.234.567,89 ISK`). Die Änderung
deckt die aktuellen Dashboard-, Produktions-, Lager-, Reservierungs-,
Einkaufs-, Preis-, Wallet-, ESI- und Importansichten ab.

Technische IDs, Eingabefelder, Domänenwerte, Berechnungen, Persistenz und
maschinenlesbare Exporte blieben unverändert. 2/2 neue Referenztests,
681/681 Gesamttests und der Apple-Development-signierte Xcode-Debugbuild
sind bestanden. `OFF-054` bleibt für die sichtbare Eigentümerkontrolle offen.

## 2026-07-29 – P56 Reaktionsfilter und kompakte Auswahl

Die P56-Gruppierung unterscheidet Reaktionen nun anhand des bereits im
Produktionsgraphen vorhandenen `reactionKind`:

- **Biochemical Reactions**,
- **Composite Reactions**,
- **Hybrid Polymer Reactions**,
- sichtbare **Unklassifizierte Reaktionen** bei fehlendem Wert.

Eine segmentierte Leiste filtert die sichtbare Produktionsart, ohne
Entscheidungen zu ändern. **Alles bauen** und **Alles kaufen** wirken direkt
auf den vollständigen Entwurf; die bisherigen Gruppenaktionen bleiben.
Einzelzeilen zeigen Itemname und den kurzen Bauen-/Kaufen-Picker unter einer
einmaligen Überschrift. Der ausführliche Itemkontext bleibt für VoiceOver.

7/7 fokussierte ViewModel-Tests, 1/1 Workspace-Architekturtest, 679/679
Gesamttests und der Apple-Development-signierte Xcode-Debugbuild sind
bestanden. Schema und Benutzerdaten blieben unverändert. `OFF-054` bleibt
für den Eigentümer-Sichttest offen.

## 2026-07-28 – P56 Gruppierte Build-or-Buy-Auswahl

Der Bereich **Bauen / Kaufen** gruppiert herstellbare Zwischenstufen nun
nach **Produktion**, **T2 und Invention** sowie **Reaktionen**. Jede Gruppe
kann vollständig auf **Alle bauen** oder **Alle kaufen** gesetzt werden.
Einzelentscheidungen bleiben innerhalb der Gruppe aufklappbar.

Die Kategorien stammen ausschließlich aus den vorhandenen Rezeptaktivitäten
und Inventionsreferenzen des Produktionsgraphen. Widersprüchliche
Mehrfachzuordnungen werden sichtbar in einer neutralen Restgruppe gehalten.
Gruppenaktionen ändern zunächst nur den Entwurf; Berechnung, Vorschau,
Bestätigung und Type-ID-Persistenz bleiben unverändert. Eine Schema- oder
Benutzerdatenänderung war nicht erforderlich.

7/7 Build-or-Buy-Tests, 1/1 Workspace-Architekturtest und 679/679
Gesamttests sind bestanden. Der native Xcode-Debugbuild ist im
Entwickler-Menü nachgewiesen. `OFF-054` bleibt für den sichtbaren
Eigentümerlauf mit Gruppenwahl, Einzelabweichung, Budget und Neustart offen.

## 2026-07-28 – P55 Projektbudgetplanung

Die bisher über Accounts erreichbare Ansicht `Projektfinanzen` wurde
bewusst aus der sichtbaren Oberfläche entfernt. Wallet-Snapshots,
Zuordnungen und der historische P29-/P42-Code wurden nicht gelöscht.

Der Produktionsworkspace enthält stattdessen den Bereich **Budget**:

- Materialeinkauf aus der wirksamen Einkaufsliste,
- einzelne Build-or-Buy-Wahl für herstellbare Zwischenstufen,
- getrennte manuelle Logistik- und Produktionskosten,
- benötigtes Gesamtbudget als überprüfte Summe,
- Vorschau und Bestätigung vor Speicherung.

Schema v25 ergänzt eine getrennte Projektbudgetkonfiguration. Die additive
v24→v25-Migration erhält bestehende Projekte. 5/5 Budgettests, 2/2
Architekturtests, 678/678 Gesamttests und der signierte Xcode-Debugbuild
sind bestanden. `OFF-054` bleibt als Eigentümer-Sichttest offen; die
P42-Projektfinanzgates pausieren.

## Historischer P52-Stand vor P55

Der erste P42-1-Eigentümerversuch meldete beim Erzeugen beziehungsweise
Schließen der Zuordnungsvorschau `NEN-FIN-001`. Der Abbruchpfad selbst ist
nicht schreibend; die Oberfläche bot jedoch bereits vollständig oder
teilweise ausgeschöpfte Walletquellen ohne sichtbare Restkapazität an und
leitete erwartbare Überbuchungen irreführend an den Speicherfehlerdialog
weiter. OFF-053 ergänzt eine deterministische Application-Projektion für
verfügbare Restmenge und Restbetrag. Erschöpfte Quellen werden nicht mehr
angeboten, erwartbare Abweichungen erscheinen inline und leere Picker besitzen
einen gültigen Zustand. Ein neuer Test beweist ausdrücklich, dass Verwerfen
keine Zuordnung persistiert. 9/9 Wallet-Fachtests, 1/1 UI-Vertrag,
673/673 Gesamttests und der Apple-Development-signierte Xcode Debug sind
grün. Ein separater strikter `codesign`-Nachlauf meldete für das isolierte
Debugartefakt trotz erfolgreicher Xcode-Signierschritte
`CSSMERR_TP_NOT_TRUSTED`; der reale Xcode-Start ist daher Teil des Retests.
P42-1 bleibt bis zum realen schreibfreien Retest offen; P42-2 wurde nicht
begonnen.

Der Eigentümer bestätigte OFF-051 vollständig im realen Datenbestand.
Zusätzlich lässt sich jede Stationsgruppe nun durch Klick auf die gesamte
Stationszeile statt nur auf den Pfeil bedienen; der fokussierte
Architekturlauf bestand mit 10/10 Tests. P52 wurde anschließend mit den
weiterhin getrennt offenen P42-Projektzuordnungs-/Endgates als exakt
dokumentiertem Restblocker beendet und P53 ausdrücklich gestartet.

P53 inventarisierte und bereinigte den Xcode-/Promptkanon.
`NewEdenNexus.xcodeproj` enthält
alle 313 Swift-Referenzen; Projektverifier, `plutil`, temporäre
Neugenerierung, Schemes und unveränderter signierter Standard-Debugbuild
bestanden. Neun nummerierte Projektkopien sind nachweislich ältere
Generierungsstände. Der zweite P21-Prompt ist ein unreferenzierter
achtzeiliger Entwurf. Nach ausdrücklicher Bestätigung wurden alle neun
Projektkopien unter `Documentation/Archive/XcodeProjects/` und der Entwurf
unter `Documentation/Prompts/Archive/` recoverbar archiviert. In der
Repositorywurzel liegt genau ein Xcode-Projekt. Der Governance-Prüfer
validiert diesen Kanon, das Promptregister und die aktuellen Steuerlinks.
Die Signing-Konfiguration ist bereits korrekt: Zertifikats-OU und
Development-Team sind `99K5WATB4A`; OFF-052 war eine Fehlinterpretation der
sichtbaren Zertifikatsbezeichnung. Es wurde keine Signing-Datei geändert.

Die persönlichen Accountdetails projizieren Assets, Blueprints und aktive
Industry Jobs jetzt alphabetisch nach aufgelöstem Stationsnamen.
Stationsgruppen sind zunächst geschlossen und erzeugen sichtbare Zeilen in
100er-Schritten. Die Suche bleibt global über den vollständigen Snapshot,
öffnet Treffergruppen automatisch und läuft nach kurzer Entprellung außerhalb
des Main Threads. Ein einmaliger Ortsindex ersetzt die frühere wiederholte
vollständige Asset-Baumauflösung. Ausgelieferte und andere historische Jobs
bleiben gespeichert, werden in dieser Arbeitsansicht aber nicht mehr gezeigt.
17/17 fokussierte und 668/668 vollständige SwiftPM-Tests bestanden; die
Projektion von 5.001 synthetischen Assets benötigte rund 0,064 s.
Apple-Development-signierter Xcode Debug bestand zunächst per
Kommandozeilen-Override und in P53 anschließend auch unverändert über die
lokale Standardkonfiguration. Keine Schema-, Migrations- oder
Benutzerdatenänderung erfolgte. OFF-051 ist im Eigentümerbetrieb bestanden;
OFF-052 wurde ohne Signing-Änderung geschlossen.

Die P41-Preisquelle ist jetzt ohne technische Region- oder Location-ID
bedienbar. Das Formular lädt alle benannten ESI-Regionen, bietet Jita, Amarr,
Dodixie, Rens und Hek als Schnellwahl und ordnet lokal bekannte Stationen
sowie Spielerstrukturen ihrer Region zu. Öffentliche Strukturmärkte sind
auswählbar; bekannte private Strukturen werden benannt, aber bis zu einem
eigenen authentifizierten Marktvertrag gesperrt. Ein verwendeter
Marktstandort in Home-Systemen wie UALX-3 oder X-10-J erscheint, sobald
seine Struktur im persönlichen Snapshot samt Namen bekannt ist.
26/26 fokussierte und 667/667 vollständige SwiftPM-Tests sowie
der Apple-Development-signierte Xcode-Debugbuild bestanden. Schema und
Benutzerdaten wurden durch die Implementierung nicht automatisch geändert.
Der Eigentümer bestätigte anschließend die Funktion und übernahm die
Marktpreisvorschau bereits in den gewählten Preissatz. OFF-050 ist damit
technisch und live bestanden. Der Eigentümer bestätigte anschließend auch
ESI-Herkunft, Region/Standort, Cachezeit und den erhaltenen Preissatz nach
vollständigem Neustart beziehungsweise offline. P41-1 bis P41-3 sind damit
live bestanden.

Die feste Währung der Produktionsrechnung ist in der UI eindeutig:
Alle Kosten und Preise bleiben ISK; getrennte Preisstände heißen
**Preissätze** und sind keine Währungsprofile. Die öffentliche
ESI-Materialpreisvorschau kann auch ohne vorhandenen Ziel-Preissatz geöffnet
werden. Sie liest dann keinen vorhandenen Preisstand und sperrt die
Übernahme fail-closed. Die zugehörigen fokussierten Regressionen, die
aktuelle Vollsuite und der Apple-Development-signierte Xcode-Debugbuild mit
isoliertem Derived Data bestanden. OFF-048 bleibt bis zum sichtbaren
Eigentümertest teilweise.

P41-1 ist einschließlich benannter Auswahl und Vorschau bestanden. Die
Übernahme wurde ausgeführt und zählt als bestandener P41-2-Schreibschritt;
sie ändert ausschließlich den gewählten Preissatz. P41-3 bestätigte dessen
Neustart-/Offline-Persistenz. Eine optionale PLEX-Anzeige wird als
abgeleiteter Wert aus einem
ausdrücklich gewählten öffentlichen PLEX-Buy- oder Sell-Quote geplant. Sie
ändert keine ISK-Werte und bleibt OFF-049, bis beide Preisrichtungen samt
Region, Zeitpunkt und Frische sauber modelliert sind.

Vor dem P41-1-Livetest wurde der Produktionsworkspace gezielt neu gegliedert.
Das Graphfenster verwendet nun 1.080 pt Mindest- und 1.360 pt Idealbreite.
Eine horizontale segmentierte Navigation öffnet jeweils genau einen der
Bereiche **Übersicht**, **Bauen / Kaufen**, **Lager & Einkauf**,
**Kosten & ROI**, **Materialsumme** und **Produktionsstufen**. Die bisherige
lange Gesamtseite entfällt; Berechnungs-, Vorschau-, Bestätigungs- und
Persistenzverträge blieben unverändert. 9/9 fokussierte Prüfungen,
662/662 SwiftPM-Tests und der Apple-Development-signierte Xcode-Debugbuild
bestanden. OFF-047 bleibt bis zum Eigentümer-Sichttest teilweise; P41-1
beginnt danach im Bereich **Kosten & ROI** neu.

P40-1 bis P40-4 sind im Eigentümerbetrieb bestanden. Für P40-4 wurde eine
neue Projekt-Asset-Auswahl zuerst schreibfrei geprüft, anschließend separat
ausdrücklich gespeichert und als aktive Auswahl bestätigt. Nach vollständigem
App-Neustart ohne Netz blieb dieselbe Auswahl lokal lesbar; es wurde weder
aktualisiert noch eine neue Vorschau ausgelöst.

OFF-044 ersetzt technische IDs in persönlichen Assets, Blueprints,
Vorschauen und Industry Jobs durch SDE-Itemnamen, Aktivität, Status, Produkt
und scopefrei auflösbare Stations-/Systemnamen. Eine gespeicherte
Projekt-Asset-Auswahl besitzt nun eine separate Rücknahmevorschau,
Stale-Prüfung und ausdrückliche Bestätigung; vorhandene Daten werden nicht
automatisch verändert. 18/18 fokussierte und 658/658 vollständige
SwiftPM-Tests sowie der Apple-Development-signierte Xcode-Debugbuild
bestanden. Rücknahme und aktive Auswahl sind live bestätigt; die neue
Typnamensichtprüfung bleibt offen. Exakte Namen
privater Spielerstrukturen werden jetzt über einen eigenen erklärten
Opt-in für `esi-universe.read_structures.v1` aufgelöst. Ohne aktuellen Scope
oder tatsächlichen Zugriff bleibt die technische ID verborgen. Außerdem
wurde die Ursache der irreführenden „unbekannten Gegenstände“ behoben:
Typnamen werden nicht mehr nur für die ersten 2.000 Rohzeilen, sondern
gebündelt für alle im Snapshot referenzierten Typen aus dem aktiven SDE
geladen. 662/662 Tests und der signierte Xcode-Debugbuild bestanden; reale
SSO-Zustimmung und Sichttest stehen aus.

## Kurzurteil

Der P52-Livebefund ist technisch nachkorrigiert: OAuth-Formwerte schützen
reservierte Tokenzeichen, Keychain-Leseprobleme werden von fehlenden Einträgen
unterschieden und jeder Owner-Contact-Schreibvorgang wird unmittelbar
zurückgelesen. Die Kontakt-UI zeigt das Ergebnis direkt an den Bedienelementen.
Eine leere Eingabe kann nicht mehr versehentlich löschen; dafür existiert eine
eigene bestätigungspflichtige Aktion. 639/639 SwiftPM-Tests sowie der signierte
Xcode-Debugbuild für macOS arm64 bestanden. Der Projekteigentümer bestätigte
den erfolgreichen Speichervorgang über die App. Das zuvor kaum erkennbare
Feld besitzt nun eine sichtbare Beschriftung, einen großen Rahmen und einen
Beispielhinweis. Der Projekteigentümer bestätigte anschließend auch das
Wiedererkennen nach vollständigem Neustart. OFF-040 bleibt nur bis zum
Refresh-/ESI-Nachweis `teilweise`.
Persönliche ESI-, Wallet- oder Marktdaten wurden noch nicht übernommen.

Der anschließende Eigentümerlauf belegte drei weitere konkrete P52-Befunde:
Refresh hatte keinerlei positives UI-Feedback, persönlicher Apply scheiterte
mit `cache_write_failed` an einem nicht verlustfreien Datums-Roundtrip und
Wallet-Inspect mit `inconsistent_pagination` an einem ESI-Cachewechsel
zwischen Journalseiten. Die App zeigt Refresh nun als laufend/erfolgreich/
fehlgeschlagen. Der persönliche Dateicache bewahrt Sekundenbruchteile und
liest das alte ISO-8601-Format weiterhin. Die Walletprüfung behält CCPs
Konsistenzgrenze bei und wiederholt genau einmal nach einem Cachewechsel.
642/642 Tests und der signierte Xcode-Debugbuild bestanden. Der reale
Eigentümer-Retest steht aus; es wurde durch die Korrektur keine Vorschau
automatisch übernommen.

Der Projekteigentümer bestätigte anschließend den realen Refresh: sichtbarer
Fortschritt, grüne Erfolgsmeldung und kein `NEN-AUTH-*`-Fehler. Zusammen mit
dem zuvor bestätigten Owner-Contact-Neustart und erfolgreichen öffentlichen
Charakterabruf ist OFF-040 geschlossen; P51 ist vollständig nachgewiesen.
Zu diesem Zeitpunkt blieb P52 wegen OFF-041 für persönlichen Apply und
Wallet-Inspect offen.

Der nachfolgend ausdrücklich bestätigte persönliche Apply bestand ebenfalls:
Die Vorschau wurde lokal gespeichert, `NEN-ESI-003` trat nicht erneut auf.
Damit ist der persönliche Cache-Schreibpfad real abgenommen. Danach blieb
OFF-041 nur noch für den Wallet-Inspect-Retest offen; eine Walletvorschau
wurde in diesem Gate weder übernommen noch einem Projekt zugeordnet.

Der Wallet-Retest meldete trotz des einmaligen Cachewechsel-Neuversuchs erneut
`NEN-ESI-004`. Da der bisherige Grund `inconsistent_pagination` mehrere
unterschiedliche Schutzgrenzen zusammenfasste, unterscheidet die redigierte
Diagnose jetzt Seitenzahlwechsel, fehlendes oder abweichendes `Last-Modified`,
doppelte Journalzeilen, widersprüchliche Transaktionen und einen stehenden
Transaktionscursor. Die UI behält den stabilen Diagnosecode; Logs enthalten
keine Headerwerte, Walletinhalte oder Tokens. 15/15 fokussierte und 644/644
vollständige Tests sowie der signierte Xcode-Debugbuild bestanden. OFF-041
blieb bis zu einem neuen einmaligen Wallet-Inspect mit konkretem sicheren
Untergrund offen.

Der anschließende sichere Untergrund
`inconsistent_pagination_conflicting_transaction` legte einen lokalen
Vergleichsfehler offen: CCPs `from_id`-Pagination liefert den Cursor-Datensatz
auf der Folgeseite absichtlich erneut. Die App hatte beim Duplikatvergleich
auch die ausschließlich lokal vergebene `sourcePage` berücksichtigt und
dadurch den erwarteten Überlapp als Konflikt bewertet. Der Client vergleicht
nun den vollständigen fachlichen Transaktionsinhalt ohne `sourcePage`, behält
beim identischen Cursor-Datensatz den ersten Eintrag und lehnt tatsächlich
abweichende Nutzdaten weiterhin ab. 9/9 fokussierte Walletclient-Tests,
646/646 vollständige SwiftPM-Tests, `git diff --check` und der signierte
Xcode-Debugbuild bestanden. OFF-041 blieb damit nur bis zum erneuten realen
Wallet-Inspect offen; es wurden keine Walletdaten übernommen.

Der Projekteigentümer bestätigte anschließend den realen Retest: „Wallet
prüfen“ öffnet das Vorschaufenster; `NEN-ESI-004` trat nicht erneut auf.
Damit sind die From-ID-Korrektur, OFF-041 und KI-044 live bestätigt. Der
Inspect blieb schreibfrei. Die Wallet-Vorschau wurde noch nicht übernommen
und benötigt weiterhin eine neue ausdrückliche Eigentümerfreigabe. P52 bleibt
für diese Entscheidung und die übrigen Betriebsnachweise auf `⚠️`.

Nach ausdrücklicher Eigentümerfreigabe wurde der Wallet-Snapshot übernommen.
Der Projekteigentümer beendete die App vollständig und bestätigte den
Snapshot nach Neustart weiterhin in der Accountansicht. Damit sind Apply und
Persistenz real bestanden; Walletwerte wurden nicht in die Dokumentation
übernommen. Die Bedienoberfläche zeigt nach „Wallet-Snapshot übernehmen“ oder
„Verwerfen“ jedoch keine eindeutige Abschlussmeldung. „Verwerfen“ entfernt
korrekt nur die aktuelle Vorschau und nicht den bereits gespeicherten
Snapshot, erklärt diesen Unterschied aber nicht. Diese UX-/Nachweislücke ist
als OFF-042/KI-045 offen; P52 bleibt für sie und die übrigen Betriebsnachweise
auf `⚠️`.

OFF-042 ist technisch umgesetzt: Die Accountzeile zeigt nach erfolgreichem
Apply, fehlgeschlagenem Apply und Verwerfen einen eigenen Status. Beim
Verwerfen wird unterschieden, ob ein gespeicherter Wallet-Snapshot erhalten
bleibt oder noch keiner gespeichert wurde. Der nächste Wallet-Inspect entfernt
die vorherige Aktionsmeldung. Es wurden weder Schema noch Walletpersistenz
oder Löschverhalten verändert. Vier fokussierte Regressionen, 650/650
SwiftPM-Tests, `git diff --check` und der signierte Xcode-Debugbuild bestanden.
Am 2026-07-28 bestätigte der Projekteigentümer im neuen Build die sichtbare
Meldung „Vorschau verworfen. Der gespeicherte Wallet-Snapshot bleibt
erhalten.“ Damit sind Discard-Feedback und Bestandsschutz live bestanden.
OFF-042/KI-045 bleiben nur noch bis zur sichtbaren Apply-Erfolgsmeldung
`teilweise`; ein erneuter Apply benötigt ein neues ausdrückliches Gate.

Nach dieser ausdrücklichen Freigabe bestätigte der Projekteigentümer auch die
sichtbare Meldung „Wallet-Snapshot wurde gespeichert.“ Damit sind Apply- und
Discard-Feedback im echten Build bestanden. OFF-042/KI-045 sind geschlossen;
der Walletpfad bleibt einschließlich Persistenz nach Neustart konsistent.
P52 bleibt ausschließlich wegen der übrigen OFF-037-Betriebsnachweise
`teilweise`.

Die Restgate-Inventur vom 2026-07-28 grenzt diese Nachweise jetzt einzeln
ab: offen sind die P40-Detail-/Offlineprüfung und projektbezogene
Assetverfügbarkeit, der echte P41-Marktpreisfluss mit Abbruch, bestätigter
Übernahme und Offline-Cache sowie eine bewusst gewählte
P42-Projektzuordnung mit Plan/Ist- und Neustartprüfung. Der abschließende
Konto-Endzustand ist ausdrücklich zu wählen. 45/45 fokussierte Regressionen
für diese Grenzen bestanden; seit dem signierten OFF-042-Xcode-Build wurde
kein Quellcode geändert. Als nächstes folgt ausschließlich die schreibfreie
P40-Detailprüfung.

P40-1 wurde anschließend im echten Build für Assets, Blueprints und Industry
Jobs bestanden. Der dabei erkannte fehlende sichtbare Schließen-Button ist
als OFF-043/KI-046 technisch korrigiert: Die Detailansicht besitzt nun einen
beschrifteten Button und Escape-Kurzbefehl. 1/1 fokussierter Test, 650/650
vollständige SwiftPM-Tests und der Apple-Development-signierte
Xcode-Debugbuild bestanden. Zu diesem Zeitpunkt stand vor P40-2 nur noch
der sichtbare OFF-043-Liveretest im neuen Build aus.

Der Projekteigentümer bestätigte den sichtbaren Schließen-Button
anschließend im neuen Build. OFF-043/KI-046 sind vollständig geschlossen.
P40-2 war danach das nächste Gate: Nach vollständigem App-Neustart und ohne
Netzverbindung sollte ausschließlich geprüft werden, ob der lokale
persönliche Snapshot mit Assets, Blueprints und Industry Jobs weiterhin
lesbar ist.

Der Projekteigentümer bestätigte P40-2 anschließend nach vollständigem
App-Neustart ohne Netzverbindung. Assets, Blueprints und Industry Jobs
blieben aus dem lokalen Snapshot lesbar; kein Refresh, Inspect oder Apply
wurde ausgelöst. P40-3 wurde danach mit Projekt, ausgewählten
EVE-Lagerorten, Vorschau und Verwerfen live bestanden. Die anschließend
unbeabsichtigt gespeicherte Auswahl wurde über Rücknahmevorschau und
ausdrückliche Bestätigung entfernt; die aktive Auswahl wird korrekt
angezeigt. Die verbleibenden Namensprüfungen sind OFF-045/OFF-046.

Das erneute Funktionsaudit hat
echte Restbefunde zwischen implementierter Technik und nutzbarem,
prüfbarem Betriebsfluss gefunden. PLAN-005 ordnet sie ohne Doppelabdeckung
als **P50 → P51 → P52 → P53 → P54**. P50 hat P40-Nutzbarkeit und die
kontrollierte Asset-Verfügbarkeit abgeschlossen. P51 hat das
P42-Fehlerrouting, die zweckgebundenen Scopes und den Plan-/Istvergleich
geschlossen. Offen bleiben reale Eigentümerabnahme, Steuerungs-/Xcode-Kanon
und abschließend ein gesondert
freizugebender lokaler Git-Sicherungspunkt. P49 bleibt bewusst unbelegt.

P51 trennt die Autorisierung jetzt nach Zweck: P40 fordert exakt drei
Produktions-Read-Scopes; der Walletscope wird erst nach eigener Erklärung und
ausdrücklicher Neuautorisierung ergänzt. Nicht geheime Scopemetadaten liegen
additiv in Schema v24, während Refresh-Tokens ausschließlich im Keychain
verbleiben. Die vier P40-/P42-Viewoperationen verwenden ihre korrekten
Fehlercodes. P29-Planwerte und bestätigte P42-Istkosten, -erlöse und Saldo
stehen im selben Projektkontext nebeneinander; fehlende, veraltete und
archivierte Zustände sind explizit. 631/631 SwiftPM-Tests sowie ein isolierter
unsigned Xcode-Debugbuild bestanden. Ein produktiver Eigentümerlauf bleibt
bewusst P52.

Das P44-Nutzenreview endet mit einem Stop/No-Go für das gebündelte
Gesamtpaket aus PI-Monitoring, Logistik und Kapazitätsplanung. Die drei
Bereiche besitzen getrennte Daten-, Scope- und Berechnungsgrenzen; ohne
belegten Kolonie-, Mehrstandort- oder Mehrlinienbetrieb entsteht kein
ausreichender Zusatznutzen. Eine spätere Reaktivierung darf genau einen
nachgewiesenen Teilbedarf adressieren. Es wurde kein Laufzeitcode geändert.

Das P43-Nutzenreview endet mit einem Stop/No-Go für vollständiges
Reaktionsmanagement zum jetzigen Zeitpunkt. P18/P19/P26 beantworten die
Produktionsfrage bereits mit Reaktionsruns, Material-/Zeitfaktoren,
mehrstufigen Ketten, Lagerabzug und Build-or-Buy. Standort-, Fuel-, Slot-,
Kalender- und Auslastungsverwaltung hätte ohne belegten Mehrlinienbetrieb
geringen Zusatznutzen, würde vorhandene Module duplizieren und P44
überschneiden. Es wurde kein Laufzeitcode geändert.

P42 ist im freigegebenen begrenzten Umfang einschließlich P51-Korrektur
technisch abgenommen. Genau ein zusätzlicher
persönlicher Read-Scope lädt Kontostand, Journal und Transaktionen in einen
privaten versionierten Offline-Snapshot. Vollständige oder teilweise
Projektzuordnungen werden erst nach Vorschau und Bestätigung in Schema v22
gespeichert; Planwerte aus P29 bleiben unverändert. Corporation-Wallets,
automatische Zuordnung und vollständige Buchhaltung bleiben ausgeschlossen.
OFF-036/KI-039/KI-040 sind geschlossen. SwiftPM Debug, 631/631 Tests und ein
isolierter Xcode-Debugbuild bestanden.

P41 ist im freigegebenen reduzierten Umfang umgesetzt: öffentliche
CCP-ESI-Sell-Orders werden nur für Type-IDs der aktuellen Einkaufsliste
geladen und nach Vorschau sowie Bestätigung als mengenbezogene
Material-Beschaffungspreise übernommen. Region und optionale Location sind
Benutzereingaben; es gibt keine neuen SSO-Scopes oder fest codierten
Handelszentren. Herkunft, Menge und Cachealter bleiben je Preis sichtbar.
Schema v21 trennt diese Provenienz von manuellen/CSV-Preisen. 593/593
SwiftPM-Tests und der unsigned Xcode-Debugbuild für macOS arm64 bestanden.
P41 und OFF-034 sind damit `✅ erledigt`.

P40 einschließlich P50-Restabnahme ist abgeschlossen. Die App lädt
persönliche Assets, Blueprints und
Industry Jobs mit exakt drei Read-Scopes, sequenzieller Pagination,
Cachevalidatoren, Limits und typisierten Fehlern. Der Abruf erzeugt zuerst
eine nicht persistierte Differenzvorschau; nur ausdrückliches Übernehmen
aktiviert einen getrennten, versionierten und atomaren Offline-Snapshot.
Manuelle Lager, Projekte und Preise bleiben unverändert. P50 ergänzt
detaillierte such-, filter- und sortierbare Offlineansichten sowie eine
projektbezogene Asset-Auswahl mit Detailvorschau, ausdrücklicher Bestätigung,
Doppelzählungs- und Revisionsschutz. Schema v23 speichert nur die bestätigte
Type-/Location-/Mengenwahl. 619/619 SwiftPM-Tests und der isolierte unsigned
Xcode-Debugbuild bestanden. Ein persönlicher Live-Abruf wurde nicht
ausgeführt; dafür muss der
Eigentümer beim erneuten Verbinden die drei Lesescopes bestätigen.

PLAN-003 setzt die **lokale Eigennutzung auf dem Mac des
Projekteigentümers** als verbindliches Betriebsziel. Für diesen Zielbetrieb
ist der aktuelle Stand technisch geprüft: SwiftPM Release 527/527 Tests,
Xcode-Universal-Build erfolgreich und nativer UI-Testworker 2/2. Lokale
Bundle-ID, fehlende App-Store-Metadaten sowie fehlende Developer-ID-/
Notarisierung sind bewusst keine lokalen MVP-Blocker.

REL-001 bleibt als gültiger technischer Befund für eine mögliche spätere
Veröffentlichung erhalten. OFF-020 und OFF-032 wurden jedoch auf P48
verschoben. P48 ist das letzte optionale Zukunftspaket nach P47 und wird nur
auf ausdrücklichen Auftrag aktiviert.

PLAN-004 legt den lokalen Ausbau fest: **P38 → P39 → P40 → P41 → P42 →
P43 → P44 → P45 → P46 → P47 → P48**. P38 ist technisch umgesetzt:
Application-Ports, gehärteter PKCE-/Loopback-Flow, OIDC/JWKS-JWT-Prüfung,
Keychain-/SwiftData-Kompensation und entkoppelte Account-Views sind
automatisiert geprüft. Beim ersten realen Versuch wurden `NEN-AUTH-001` und
`NEN-PER-004` auf verweigerten Zugriff auf einen von einem früheren
ad-hoc-signierten Build angelegten Keychain-Eintrag zurückgeführt. Die App
unterscheidet diesen Fall nun als `NEN-AUTH-003` beziehungsweise
`NEN-AUTH-002`; eine lokale, git-ignorierte Apple-Development-Konfiguration
sorgt künftig für eine stabile Code-Identität. Der lokale Zugriff des
Signierwerkzeugs wurde vom Projekteigentümer freigegeben; der aktuelle
signierte Debugbuild besteht.

Das gemeldete doppelte Hauptfenster ist korrigiert: wiederhergestellte
Duplikate werden geschlossen und `⌘N` aktiviert das vorhandene Hauptfenster.
Die nachfolgende Buildlog-Prüfung bestätigte außerdem einen erfolgreichen
isolierten Xcode-Debugbuild. Die wiederholten
`com.apple.linkd.autoShortcut`-Meldungen sind AppIntents-Systemdiagnostik,
kein Buildabbruch. Das ungültige SF Symbol `cart.badge.checkmark` wurde
durch `checkmark.circle.fill` ersetzt und fokussiert getestet.
Der frühere Eigentümer-SSO-End-to-End-Lauf schloss P38 zunächst ab. Der
aktuelle P52-Lauf hat jedoch KI-043 in der bislang nicht repräsentativen
Refresh-Testfixture nachgewiesen. P39/P40/P41 einschließlich P50 und der
ursprüngliche P51-Umfang bleiben technisch vorhanden. KI-043 ist
automatisiert nachkorrigiert; ihre Livefreigabe wartet nur noch auf die
manuellen OFF-040-Neustart-, Refresh- und ESI-Nachweise. Die P43- und
P44-Nutzenreviews sind abgeschlossen, beide Implementierungen
zurückgestellt. P45 bis P47 bleiben bedarfsabhängig und P48 zuletzt
optional.

Der nachfolgende Reallauf zeigte unnötig aufeinanderfolgende
Schlüsselbundfreigaben beim Verbinden und Trennen. Der Application-Service
liest den bisherigen Token nun weder vor einer Neuverbindung noch vor dem
Trennen. Lokaler Charakterdatensatz und Keychain werden in kompensierbarer
Reihenfolge geändert; bei einem Vault-Fehler wird der vorherige
Charakterstand wiederhergestellt. Sichere OAuth-Diagnosen enthalten
zusätzlich `error_reason`, ohne Scope-Namen, Tokens oder Rohwerte
offenzulegen. 544 SwiftPM-Tests sowie isolierte unsignierte und
Apple-Development-signierte Xcode-Debugbuilds sind erfolgreich. Das lokale
Signing-Skript ermittelt die Team-ID nun aus dem Zertifikatsfeld `OU`; die
entstandene App bestand zusätzlich `codesign --verify --deep --strict`.
Der nachfolgende Eigentümerlauf und die kontrollierte Alt-Token-Bereinigung
schlossen OFF-033.

Die ergänzten Xcode-Zeilen ändern diese Einordnung nicht:
`NEN-SDE-006` mit `level=info` und `status=update_available` meldet nur ein
verfügbares SDE-Update. `DetachedSignatures`- sowie bereits abgebrochene
Network-Listener sind macOS-Laufzeitdiagnostik. Handlungsrelevant bleiben
die beiden Appfehler `NEN-AUTH-001` und `NEN-AUTH-002`; ein neuer Lauf
liefert für `NEN-AUTH-001` zusätzlich den sicheren `error_reason`.

Dieser sichere Grund identifizierte im nächsten Reallauf
`signing_key_unavailable`. Der am 2026-07-26 abgerufene offizielle
CCP-JWKS enthält gleichzeitig einen RSA-/RS256- und einen EC-/ES256-
Eintrag. Das bisherige Modell verlangte RSA-Felder bei jedem Eintrag und
verwarf deshalb den vollständigen Schlüsselsatz. `JWK` bildet
algorithmusspezifische Felder nun optional ab; die Prüfung wählt weiterhin
ausschließlich den zum JWT-Header passenden RSA-/RS256-Schlüssel. Der
Mischschlüssel-Regressionsfall, 545/545 SwiftPM-Tests sowie ein strikt
verifizierter Apple-Development-Xcode-Debugbuild bestanden. Der erneute
Eigentümerlauf wurde bestätigt; OFF-033 ist geschlossen.

P36 schließt den Recovery-Nachweis über eine reale Prozessgrenze. Fünf
getrennte, ausschließlich temporäre Installationsprozesse erreichten die
persistierten Phasen `downloading`, `validatingSource`,
`validatingStagingStore`, `creatingSafetyBackup` und `promoting`. Der
Koordinator beendete jeweils nur die protokollierte PID mit `SIGKILL`; eine
frische Recovery-Composition öffnete danach denselben Store. In allen fünf
Fällen blieben Altbuild, Katalogabfrage, Charakter- und Projektfixture,
Journalabschluss, Rollback, Aufbewahrungsregel und Cleanup korrekt; ein
zweiter Recoverylauf war wirkungslos. SwiftPM bestand 527/527 Tests. Xcode
baute App und Acceptance-Executable; der Xcode-kompilierte P36-Testbund
bestand 6/6 direkt im nativen Runner. Die Scheme-Orchestrierung konnte
innerhalb der Codex-Sandbox `testmanagerd` nicht erreichen. Dieser
historische Befund wurde in REL-001 durch den erfolgreichen nativen
UI-Worker-Lauf geschlossen; OFF-024 bleibt geschlossen.

P35 ergänzt die funktionale, diakritiktolerante Sidebar-Suche, adaptive
Layouts für Dashboard, Produktionsworkspace, Einkauf und SDE, semantische
macOS-Systemfarben sowie Fokusführung und vollständige Statusansagen.
Schema v20, Graphformat 7 und Benutzerdaten blieben unverändert. Ein neues
Xcode-UI-Testtarget startet das echte App-Bundle mit isoliertem Store und
prüft 1.280 × 800 sowie 780 × 560, Kernstatus, Suche, Accessibility-Audit
und Tab-Fokusfolge. SwiftPM Debug bestand 518 Tests; Xcode Debug bestand
520 Tests einschließlich der zwei UI-Tests. OFF-030 ist geschlossen und P35
gilt als ✅. Der interaktive Computer-Use-Kanal blieb technisch unbrauchbar;
ein manueller VoiceOver-Einmaltest wird nicht behauptet.

P34 sichert große Produktionsgraphen bis zur bestehenden
25.000-Knoten-Grenze ab. Bis 500 Knoten bleibt die aufklappbare Baumansicht;
darüber projiziert die UI deterministisch zunächst 1.000 Knoten und lädt auf
Benutzeraktion in 1.000er-Schritten nach. `LazyVStack` und ein einmaliger
Knotennamenindex verhindern ungebremste View-Materialisierung. Die
25.000-Knoten-Projektion benötigte in SwiftPM/Xcode Debug rund 0,026 Sekunden.
Die 50.000-Item-Katalogsuche blieb mit zehn Läufen bei 0,288/0,295 Sekunden
und je 51 gelesenen Zeilen in einem Batch; ein zusätzlicher Index ist nicht
begründet. SDE-Installation/-Archiv, Projekteditor und Preis-CSV wurden
verhaltensneutral nach Verantwortung geteilt. Schema v20, Graphformat 7 und
Benutzerdaten blieben unverändert. SwiftPM und Xcode Debug bestanden jeweils
512 Tests.

P33 harmonisiert die sichere Fehler-UX des Produktionsplaner-MVP.
`NexusValidationIssue` liefert stabile, rohwertfreie Feldhinweise; Projekt-,
Lager-, Bestands-, Preis- und Einkaufsformulare verwenden eine gemeinsame
Darstellung. Benutzer-Retries sind ausschließlich für eine geschlossene
Liste idempotenter Lese-/Inspect-/Previewoperationen zugelassen und werden
vor einmaliger Ausführung entfernt. Schreibvorgänge bleiben ausgeschlossen.
P33 ändert weder Schema v20 noch Benutzerdaten. 16 fokussierte Prüfungen
sowie SwiftPM und Xcode Debug bestanden mit jeweils 507 Tests.

P31 führt die P30-Zielkaufmengen aller aktuellen Projekte Type-ID-basiert
zusammen. Teilkäufe und vollständige Käufe werden je Projekt/Type-ID
gespeichert, ohne Lagerbestände, Sicherheitsbestände oder Reservierungen zu
verändern. Text- und UTF-8-CSV-Export sind read-only. Vorschau, Bestätigung
und vollständiger Source-State verhindern veraltete Schreibvorgänge.
Schema v20 und Backupformat 20.0.0 sind getestet; OFF-011 ist geschlossen.

P27 ergänzt den intern abgenommenen Produktionskern um lokale,
wiederverwendbare Preisprofile und exakte manuelle ISK-Einheitspreise.
Beträge werden als `Int64`-Hundertstel gespeichert, zeitlich gültige Preise
explizit aufgelöst und fehlende Werte nie als null ISK erfunden. Schema v16,
Backupformat 16.0.0 und das neue Preis-Navigationsmodul sind getestet.

PLAN-002 ist abgeschlossen. P37 weist den Produktions-/Inventionskern mit
Lagerabgleich, manueller Bauen/Kaufen-Entscheidung, Joblisten, Fehlmengen
und persistenter Wiederöffnung intern nach. Dies ist kein öffentlicher
Release Candidate. P28–P36 einschließlich OFF-030, OFF-006 und OFF-024 sind
abgenommen. Bestehende
Funktionen und Sicherheitsgrenzen wurden nicht entfernt.

Die synthetische P37-Abnahme speichert je ein T1- und T2-Projekt samt
Graphen und Lager in einem isolierten Schema-v15-Store. Nach Wiederöffnung
bleiben beide Pläne exakt identisch. T1 verwendet 4 Zwischenprodukte aus
dem Lager, produziert 6 in drei Runs und weist 4 fehlende Rohmaterialien
aus. T2 hält die Komponentenentscheidung **Kaufen**, zeigt zwei erfolgreiche
Inventionskopien sowie Fehlmengen 9 für die Komponente und 3 für den
Datacore. Konfliktgründe, Projekte, Prioritäten und Reduktionsvorschläge
bleiben erklärbar und die Vorschau schreibt nicht.

P32 verbindet den vorhandenen P26-Plan nun sichtbar mit Projekt,
Produktionsgraph, Lagerabzug, Sicherheitsbeständen, Reservierungen und
berechnetem Konfliktstatus. Geeignete Zwischenstufen lassen sich über eine
schreibfreie Vorschau auf Bauen oder Kaufen setzen. Produktions- und
Inventionsjobs sowie ausschließlich positive Fehlmengen werden angezeigt;
die Fehlmengen sind deterministisch als `Name<Tab>Menge` kopierbar.

Dashboard, Projekt-, Graph-, Wirtschafts- und Workspace-UI greifen nicht direkt auf
SwiftData zu. Projekt- oder graphfremde, veraltete beziehungsweise nach
einer Änderung noch nicht neu berechnete Vorschauen werden weder angezeigt
noch gespeichert oder kopiert. P27–P31 haben die aktuelle Schemastufe
additiv auf v20 angehoben. Das aktuelle Backupformat ist 20.0.0.
16 fokussierte P33-Prüfungen sowie SwiftPM und Xcode Debug mit je
507 Tests bestanden.

P41 hebt die aktuelle Schemastufe additiv auf v21 und das Backupformat auf
21.0.0 an. Marktpreisprovenienz ist von Preisen, Projekten, Lagern und
persönlichen ESI-Snapshots getrennt. Die v20→v21-Migration, Wiederöffnung,
Backupkompatibilität und 593 Gesamttests sind grün. Der Xcode-Debugbuild des
identischen Projektstands ist ebenfalls erfolgreich.

P42 hebt die aktuelle Schemastufe additiv auf v22 und das Backupformat auf
22.0.0 an. Bestätigte Projektzuordnungen bleiben vom privaten Walletsnapshot
und von P29-Planwerten getrennt. Die v21→v22-Migration, Wiederöffnung,
Überzuordnungs-/Stale-Schutz und Trennkompensation sind getestet.

New Eden Nexus besitzt nun zusätzlich zum lokalen SDE-Offlinekern und
P07A-Metadatencheck einen technischen Installationspfad: fester offizieller
Archivdownload, Größen-/Speichergrenzen, defensive ZIP-Prüfung, kontrollierte
Systemextraktion mit Nachprüfung, isolierter SwiftData-Stagingstore,
Sicherheitsbackup, atomare Promotion, expliziter Rollback und dauerhaftes
pfadbereinigtes Phasenjournal.

P07B ist `✅ erledigt`. Der Projekteigentümer hat die aktuellen
CCP-Bedingungen persönlich bestätigt und eine reale Kontaktangabe nur für den
Laufzeit-User-Agent bereitgestellt. Der aktuelle offizielle Build `3444265`
wurde nach dem Speicherumbau zweimal blockweise heruntergeladen, geprüft,
importiert, aktiviert, wieder geöffnet und über Rifter/Blueprint abgefragt.
Beide Läufe bereinigten ihre temporären Daten.

Das Mapping liest JSONL zeilenweise und gibt begrenzte Batches an isolierte
SwiftData-Stores weiter. Auch die Promotion erfolgt batchweise; der
Aktivmarker wird erst nach vollständigem Mengenabgleich gesetzt. Die reale
Messung sank von zuvor rund 2,45 GB auf 948–952 MB Peak-RSS, also um rund
61 %.

P07C verdrahtet P07A und P07B nun produktiv über `SDEAppComposition`.
Nicht blockierender Startcheck, langfristiger Scheduler, sichere
Automationsdefaults, Fortschritt/Abbruch, Keychain-Kontakt, filterbares
Phasenjournal, redigierter Diagnoseexport, bestätigte Retention sowie
SDE- und Rechtsansicht sind umgesetzt. Debug und Release bestehen jeweils
167 Tests. Vor dem ersten Metadatencheck bereinigt eine kontaktfreie
Recovery-Grenze abgebrochene Download-, Cache-, Import- und
Stagingartefakte; schlägt diese Wiederherstellung fehl, wird kein neuer
Updatevorgang begonnen.

Die vom Projekteigentümer bereitgestellte aktuelle öffentliche EVE-Client-ID
ist seit CFG-001 zentral konfiguriert. Der App-Start ersetzt ausschließlich
den früheren Projektstandard oder einen leeren Wert; eine individuell
eingetragene Client-ID bleibt erhalten. Die Callback-URL bleibt unverändert
`http://localhost:52721/callback`. Damit wurde keine SSO-/ESI-Fachfunktion
vorgezogen; ein echter Login bleibt P38 und ist weiterhin nicht abgenommen.

P09B ergänzt nun das eigenständige `NewEdenNexus.xcodeproj`, zwei gemeinsame
Schemes, alle 15 Package-Targets und einen statischen Paritätscheck. App Debug
und Release, der nur gebaute SDE-Abnahmerunner, 167 Xcode-Tests sowie SwiftPM
Debug/Release und 167 SwiftPM-Tests sind erfolgreich. Das echte App-Bundle
wurde auf My Mac mit isoliertem Profil gestartet; Dashboard, SDE-Ansicht,
Settings, Rechtstab, der manuelle Updatekurzbefehl und VoiceOver wurden
geprüft. Damit sind `OFF-014`, `OFF-025`, `KI-009` und `KI-025` geschlossen
und die frühere P07C-Einschränkung ist aufgehoben.

P10 ergänzt einen UI- und SwiftData-freien `ResolveRecipeUseCase` für
eindeutige Fertigungs- und Reaktionsrezepte. Ein neuer Persistence-Port liest
vollständige Kandidaten ausschließlich aus genau einer aktiven SDE-Version.
Fehlende, falsche, mehrdeutige, unveröffentlichte, probabilistische oder
strukturell widersprüchliche Kandidaten werden typisiert abgelehnt. Jede
nicht aufgelöste Material- oder Produktreferenz blockiert das gesamte Rezept
mit stabiler itemgenauer Diagnose.

Der aktuelle offizielle Build `3444265` wurde erneut in einem isolierten
Store geprüft. Rifter/Blueprint 691 und ein vollständiges Reaktionsrezept
wurden aufgelöst. Alle 21 tatsächlich vorhandenen Referenzlücken wurden
einzeln mit `NEN-RECIPE-001` nachgewiesen; kein betroffenes Rezept wurde als
vollständig zurückgegeben. `OFF-003`, `OFF-016`, `KI-004` und `KI-016` sind
damit geschlossen.

P11 ergänzt den vollständigen lokalen Projektlebenszyklus. Ein zentraler,
UI- und SwiftData-freier Application-Service lädt, filtert, erstellt,
bearbeitet, dupliziert, archiviert und restauriert Projekte. Er erzwingt den
verbindlichen Statusgraphen, idempotente gleiche Statuswechsel und
Schreibschutz für Archive. Uhr und UUID sind injizierbar.

`ProjectsView` verwendet nun `ProjectLifecycleViewModel` statt `@Query` und
`modelContext`. Die konkrete Repository-Composition liegt in
`ProjectAppComposition`; Loading-, Empty-, Fehler-, Filter-, Formular-,
Status-, Duplikat-, Archiv- und Restorepfade sind vorhanden. P11 ergänzt
keine persistierten Felder: Schema v4 und alle Migrationen bleiben
unverändert. Ein dateibasierter Test öffnet denselben Store mehrfach und
prüft den vollständigen Lebenszyklus.

P12 bindet neue beziehungsweise geänderte Projektziele jetzt an stabile
Produkt- und Blueprint-IDs, Fertigung oder Reaktion sowie die Provenienz der
aktiven Katalogversion. Der Application-Service durchsucht ausschließlich
produzierbare veröffentlichte Typen, validiert jeden Blueprintkandidaten über
den P10-Resolver und verlangt bei Mehrdeutigkeit eine explizite Auswahl. Der
Projekteditor bietet verzögerte, abbrechbare Suche, Aktivitäts-, Kategorie-
und Gruppenfilter, Auswahlzustände und lokalisierte positive Ganzzahlen ohne
willkürliche Obergrenze.

Die additive Schema-v5-Migration erhält Bestandsprojekte unverändert und
erfindet keine Namenszuordnung. Neue Zielfelder werden vollständig
roundtrip-fähig gespeichert und bei Bearbeitung gegen die aktive
Katalogversion revalidiert. Marktgruppenobjekte sind für die P12-Suche nicht
erforderlich; Kategorie, Gruppe und Aktivität genügen.

P13 ergänzt einen UI- und SwiftData-freien Graphsnapshot mit
Vorkommens-Knoten, gerichteten Materialkanten, Rezeptprovenienz und
vollständiger Strukturvalidierung. Der Application-Service erzeugt
deterministisch die erste Stufe des exakt im Projekt gespeicherten
Blueprintrezepts. Ungültige, abgebrochene oder nicht versionsgleiche
Neuberechnungen verändern einen vorhandenen Snapshot nicht.

Schema v6 speichert pro Projekt höchstens einen kanonisch codierten Graphen.
Die additive v5→v6-Migration, Backupversionen 1.0.0 bis 6.0.0,
Repository-Roundtrip, Graphansicht und Veraltetheitsanzeige sind geprüft.
Nach P13 bestehen 238 Tests jeweils über SwiftPM in Debug und Release sowie
alle sieben Xcode-Testtargets in beiden Konfigurationen.

P14 ergänzt `ProductionRunCalculation` mit Formelversion 1,
ganzzahliger Ceiling-Division, geprüfter Outputmultiplikation und
Manipulationserkennung. Neue Graphen verwenden Format 2 und zeigen Runs,
tatsächliche Ausgabe, Überschuss und Formelversion; Format-1-Graphen bleiben
lesbar und veraltet. `maxProductionLimit` wird nicht als Projekt- oder
Jobgrenze interpretiert.

Schema v7 führt den Graphdatensatz mit optionaler
`calculationFormulaVersion` fort. Die vollständige v3→v7-Kette und eine
direkte v6→v7-Migration mit Projekt, aktivem SDE-Stand, Format-1-Payload und
zweiter Öffnung sind geprüft. Backups unterstützen 1.0.0 bis 7.0.0.
SwiftPM und Xcode bestanden Debug und Release mit jeweils 253 Tests.

P15 ergänzt `ProductionMaterialCalculation` mit Formelversion 1. Für jede
Materialkante der vorhandenen Rezeptstufe werden Rohbedarf, nach
Blueprint-ME reduzierter Effektivbedarf und Ersparnis über den gesamten Job
ganzzahlig berechnet. Basismenge eins je Run bleibt geschützt; Reaktionen
akzeptieren ausschließlich ME 0. Beide Multiplikationen sind
überlaufgeprüft, persistierte abgeleitete Werte werden beim Laden neu
berechnet.

Projekte speichern ME als ganze Zahl von 0 bis 10. Graphformat 3 verlangt
ME-Provenienz und eine konsistente Materialberechnung je Kante; Format 1 und
2 bleiben lesbar und veraltet. Schema v8 ergänzt optionale Felder für
Projekt-ME und Materialformelversion. Die v3→v8- und v7→v8-Migration,
Backups 1.0.0 bis 8.0.0 sowie ein isolierter echter Schema-v8-App-Start sind
geprüft. SwiftPM und Xcode bestanden Debug und Release mit jeweils 273
Tests.

P16 erweitert den Produktionsgraphen mit Graphformat 4 zu einer
deterministischen Manufacturing-only-T1-Kette. Jede eindeutig herstellbare
Materialposition wird als eigenes Zwischenprodukt mit Sollmenge, Runs,
tatsächlicher Ausgabe, Überschuss und ME-berechneten Materialkanten
aufgelöst. Das Ziel verwendet den Projekt-ME-Wert; automatisch gefundene
Zwischenprodukte tragen sichtbar den neutralen Planungswert ME 0 und dessen
Herkunft, ohne einen besessenen Blueprintwert zu behaupten.

Materialien ohne Herstellungsrezept und zurückgestellte Reaktionsprodukte
bleiben als begründete Blätter erhalten. Gleiche Typen in verschiedenen
Zweigen werden nicht vorzeitig zusammengeführt. Zyklen, mehrdeutige oder
ungelöste Rezepte, Katalogwechsel, Tiefe über 64, mehr als 25.000 Knoten,
Berechnungsüberläufe und Cancellation brechen vor dem Speichern ab und
erhalten einen vorhandenen Graphen. Format 1 bis 3 bleiben lesbar und
veraltet. Da Format 4 in der vorhandenen codierten Payload gespeichert wird,
bleiben SwiftData-Schema und Backupversion bei v8/8.0.0.

Der vorhandene SDE-Umfang aus Typen, Blueprints, Aktivitäten, Produkten und
Materialien reicht für P16 vollständig aus; OFF-021 erforderte keinen
weiteren Import. SwiftPM und Xcode bestanden Debug und Release mit jeweils
280 Tests. Der isolierte Debug-App-Prozess lief mit einem eigenen
Schema-v8-Store; `PRAGMA integrity_check` ergab `ok`.

P17 erweitert diese Basis mit Graphformat 5 um kataloggebundene T1-/T2-
Klassifikation, Blueprint-Herkunft und -qualität, reguläre und historische
T2-Szenarien, alle acht Decryptoren sowie `IndustryRuleSet` v1 und
maschinenlesbaren Preflight. T2 entsteht nur aus einer eindeutigen
Invention-Beziehung mit einem selbst fertigbaren Ausgangs-Blueprint;
Reverse Engineering/T3 wird typisiert abgelehnt.

Jede T1-/T2-Stufe trägt eigene ME-/TE-/Run- und Regelprovenienz. Reguläre
Invention plant die erforderlichen erfolgreichen BPCs, behauptet jedoch
keine garantierten Versuche. Der vorhandene Katalog deckte Grundruns,
Wahrscheinlichkeit, Datacores und die T3-Abgrenzung vollständig; ein
zusätzlicher Meta-/Skill-/Dogma-Import war für P17 nicht erforderlich.
Schema v8 und Backupformat 8.0.0 bleiben unverändert. SwiftPM und Xcode
bestanden Debug und Release mit jeweils 292 Tests. Der offizielle Build
3444265 bestätigte Blueprint 691 → 11372, Grundrun 1,
Basiswahrscheinlichkeit 0,3 und Datacores 20172/20424. Der isolierte
App-Store bestand `PRAGMA integrity_check`.

P18 ist nun umgesetzt. Der SDE-Import verarbeitet zusätzlich genau die
benötigten Typ-Dogma-, Attribut- und Effektdaten und erzeugt daraus ein an
Build und Inhaltshash gebundenes `ReactionRuleProfile`. Composite-, Hybrid-,
Biochemical- und Molecular-Forged-Formeln werden ihrer Reactorart
zugeordnet; unbekannte, gemischte oder nicht verifizierte Regeln schlagen
geschlossen fehl.

Graphformat 6 und Expansionsrichtlinie 3 lösen Manufacturing → Reaction,
Reaction → Manufacturing und Reaction → Reaction rekursiv auf. Jede
Reaktionsstufe speichert Formelart, Reactor, neutralen oder vollständig
modifizierten Facility-/Rig-/Security-/Skillkontext sowie ganzzahlige
Material- und Zeitaufschlüsselungen. Blueprint-ME und -TE bleiben für
Reaktionen ausgeschlossen. Schema v9 speichert das kataloggebundene
Regelprofil additiv; Backupformat 9.0.0 ist geprüft.

SwiftPM und Xcode bestanden Debug und Release jeweils mit 310 Tests.
Der offizielle SDE-Build 3444265 wurde in einem isolierten Store mit allen
drei Reaktionsarten, reinen Reaktionsaktivitäten und Regelprofil geprüft.
Ein isolierter Schema-v9-App-Prozess erzeugte die erwarteten Tabellen;
`PRAGMA integrity_check` meldete `ok`.

P19 ergänzt Graphformat 7 und Aggregationsformel 1. Ausschließlich
tatsächliche Materialblätter werden nach stabiler CCP-Type-ID summiert;
Zwischenprodukte bleiben ausgeschlossen. Jede Position bewahrt ihre
Einzelvorkommen, effektiven Mengen, Blattgründe und vollständigen Pfade von
der Wurzel. Manufacturing- und Reaktionszweige verwenden ihre bereits
berechneten effektiven Kantenmengen.

Jede Addition ist als positive `Int64`-Operation überlaufgeprüft. Der erste
Überlauf, inkonsistente Namen derselben Type-ID, fehlende Pfade, manipulierte
Summen, Zyklen, fehlerhafte Beziehungen, Tiefe über 64 oder mehr als 25.000
Knoten blockieren den Kandidaten vor Persistenz; ein Altgraph bleibt
unverändert. Geladene Format-7-Payloads werden durch Neuberechnung exakt
verifiziert. Formate 1 bis 6 bleiben lesbar und veraltet. Schema v9 und
Backupformat 9.0.0 bleiben unverändert.

SwiftPM und Xcode bestanden Debug und Release jeweils mit 321 Tests, 0
Fehlern und 0 übersprungenen Tests. Der isolierte P19-App-Prozess öffnete
ausschließlich einen temporären Schema-v9-Store; `PRAGMA integrity_check`
meldete während und nach dem Lauf `ok`.

P20 ergänzt das additive Schema v10 um lokale logische Lagerorte und
manuelle Bestandspositionen. Lager besitzen stabile UUIDs, normalisiert
eindeutige Namen, Typ, Notiz und reversiblen Archivstatus. Archivieren
erhält alle Positionen und sperrt Änderungen bis zur Wiederherstellung.

Bestandspositionen sind je `(Lager-ID, CCP-Type-ID)` eindeutig. Positive
`Int64`-Mengen werden bei einer Bearbeitung ersetzt, nicht addiert. Neue
oder geänderte Positionen werden gegen veröffentlichte Items des aktiven
Katalogs geprüft und speichern Buildnummer sowie Inhaltshash. Das Löschen
einer Position benötigt eine ausdrückliche UI-Bestätigung und berührt weder
andere Positionen noch das Lager. Verfügbarkeit, Schutzbestände und
Reservierungen bleiben P22–P25.

SwiftPM und Xcode bestanden Debug und Release jeweils mit 335 Tests, 0
Fehlern und 0 übersprungenen Tests. Ein befüllter v9-Store migrierte
verlustfrei nach v10 und ließ sich zweimal öffnen; der v10-Leerstore und
Backups 1.0.0 bis 10.0.0 sind geprüft.

P21 ergänzt einen kontrollierten CSV-Bestandsimport. Unterstützt werden
UTF-8 einschließlich BOM, UTF-16 LE/BE mit BOM sowie konservative
Windows-1252-/Latin-1-Rückfälle, Komma, Semikolon und Tabulator,
Anführungszeichen, maskierte Anführungszeichen, CR/LF/CRLF und mehrzeilige
Felder. Datei-, Zeilen- und Spaltengrenzen verhindern unbeschränkte
Verarbeitung.

Der Import liest zunächst ausschließlich. Nach explizitem Feldmapping
entsteht eine itemgenaue Vorschau; Type-ID, positive ganzzahlige Menge,
optionaler Name, aktiver Katalog und bestehender Lagerbestand werden
validiert. Doppelte Type-IDs machen alle betroffenen Zeilen ungültig.
Bestehende Positionen benötigen je Zeile eine Entscheidung `ersetzen` oder
`überspringen`. Erst eine ausdrückliche Gesamtbestätigung erlaubt den
atomaren Schreibvorgang. Zwischen Vorschau und Schreiben veränderte Lager-,
Bestands- oder Katalogstände blockieren den Import.

Schema v11 ergänzt persistente, bereinigte Importberichte, ohne CSV-Rohdaten
zu speichern. Migration v10→v11, leerer v11-Store und Backups 1.0.0 bis
11.0.0 sind geprüft. SwiftPM und Xcode bestanden Debug und Release jeweils
mit 353 Tests, 0 Fehlern und 0 übersprungenen Tests.

P22 ergänzt projektbezogene physische Verfügbarkeit auf Basis der
Graphformat-7-Endmaterialaggregation und der lokalen P20/P21-Bestände. Der
Benutzer kann alle aktiven, nur ausgewählte oder keine Lager einbeziehen,
Materialien vollständig ausschließen und je Type-ID eine nichtnegative
Mengenobergrenze setzen.

Die Berechnung trennt gespeicherten Bestand, Archiv-, Lager-/Modus-,
Material- und Cap-Ausschluss sowie einbeziehbare, verwendbare und ungedeckte
Menge. Sie ist `Int64`-basiert, überlaufgeprüft, deterministisch und frei von
UI- sowie Persistenzabhängigkeiten. Ergebnisse werden nicht gespeichert.
Nur eine ausdrücklich bestätigte, noch aktuelle Vorschau darf die
projektbezogene Konfiguration atomar ersetzen.

Schema v12 ergänzt
`InventoryAvailabilityConfigurationRecord`. Die additive v11→v12-Migration,
zweite Öffnung, leerer v12-Store sowie Backups 1.0.0 bis 12.0.0 und die
Ablehnung 13.0.0 sind geprüft. SwiftPM und Xcode bestanden Debug und Release
jeweils mit 371 Tests, 0 Fehlern und 0 übersprungenen Tests. Ein isolierter
App-Prozess startete stabil; `PRAGMA integrity_check` meldete `ok` und der
v12-Store enthielt die erwartete Verfügbarkeits-, Lager- und Projekttabelle.

P23 ergänzt globale, Type-ID-basierte Sicherheitsbestandsregeln auf der
physischen P22-Basis. Aktiver Bestand, den P22 bereits ausschließt, deckt den
Schutz zuerst; archivierter Bestand zählt nicht. Nur die Sicherheitsmenge
wird automatisch zurückgehalten. Mindest-, Warn- und Zielschwellen werden
unabhängig ausgewertet und mit Istwert, Schwelle und Differenz angezeigt.

Vorschau und Speichern sind getrennt. Apply verlangt Bestätigung und prüft
Projekt, Graph, Lager, Bestände, P22-Konfiguration sowie alle betroffenen
Regelversionen erneut. Regelanlage, Änderung und Löschung erfolgen atomar;
ein Repository-Rennen wird als veraltete Vorschau gemeldet.

Schema v13 ergänzt `StockPolicyRecord`. Migration v12→v13, Leerstore,
zweite Öffnung und Backups 1.0.0 bis 13.0.0 sind geprüft. SwiftPM und Xcode
bestanden Debug und Release jeweils mit 388 Tests, 0 Fehlern und 0
übersprungenen Tests.

P24 ergänzt globale Projekt-/Type-ID-Reservierungen auf genau dieser
P22-/P23-Basis. Der Domainkern trennt eigene und fremde aktive Restbindungen,
prüft jede `Int64`-Summe und verhindert neue Überbuchungen. Reservieren,
Ändern, teilweiser oder vollständiger Verbrauch und Freigabe laufen über
einen expliziten Zustandsautomaten. Ablaufdaten informieren, lösen aber
keine automatische Freigabe aus.

Der Application-Service trennt schreibfreie Vorschau und ausdrücklich
bestätigten Apply. Vollständige Projekt-, Graph-, Bestands-, Ausschluss-,
Schutzregel- und Reservierungszustände verhindern veraltete oder
konkurrierende Schreibvorgänge. Schema v14 speichert Reservierungshistorie
additiv; Projekte mit aktiven Bindungen können nicht archiviert werden.
Migration v13→v14, Leerstore, zweite Öffnung, Backups bis 14.0.0 und ein
isolierter App-Start sind bestanden. SwiftPM und Xcode bestehen Debug und
Release jeweils mit 408 Tests.

P25 berechnet darauf Bestandsunterdeckung, Bedarfsüberschreitung und nicht
mehr benötigte aktive Bindungen. Stabile Prioritäten liefern ausschließlich
Vorschläge. Eine Auflösung darf nach schreibfreier Vorschau und
ausdrücklicher Bestätigung nur reduzieren oder freigeben und wird über die
P24-Grenze atomar gespeichert. Konflikte werden nicht persistiert; Schema
und Backupformat bleiben v14/14.0.0. SwiftPM und Xcode bestehen Debug und
Release jeweils mit 423 Tests.

OFF-026 ist vor der P12-Ausführung erledigt. Ursache von `NEN-PER-001` war
die Kollision des generischen SwiftData-Pfads
`Application Support/default.store` mit einer konsistenten fremden
Core-Data-Datenbank. New Eden Nexus verwendet nun
`Application Support/NewEdenNexus/NewEdenNexus.store`, erkennt einen eigenen
historischen Store read-only an seinen Signaturtabellen und lässt fremde
Stores unangetastet. Ein echter isolierter App-Prozess erzeugte einen
konsistenten damaligen Schema-v4-Store; die fremde Datei blieb vor und nach der
Prüfung byteidentisch.

PLAN-001 hat die zuletzt gemeldeten technischen Schulden gegen Quellcode,
Git-Status, offene Register und die Promptfolge geprüft. Zwei bisher nicht
verbindlich eingeordnete Lücken erhalten eigene Zwischenpakete direkt nach P07C:
P09A für die erste geprüfte Git-Baseline und P09B für ein eigenständiges
Xcode-Projekt mit gemeinsamen Schemes. Alle übrigen Befunde bleiben ihren
bereits geplanten Zielprompts zugeordnet und wurden dort mit konkreteren
Abnahmekriterien abgesichert. PLAN-001 hat keinen Code implementiert, nichts
gestaged und keinen Commit erzeugt.

P09A hat diesen geprüften Gesamtstand anschließend als genau einen initialen
Root-Commit auf `main` gesichert. Vorher wurden 213 Projektdateien
inventarisiert, das Projektbuch als projektbezogen geprüft, lokale
Dokumentlinks kontrolliert und Quellen, Tests, Dokumentation sowie DOCX-Inhalt
auf Geheimnisse, reale Kontaktwerte und lokale Datenartefakte untersucht.
Es wurde kein Remote angelegt und nichts gepusht. Künftige Reviews können nun
gegen `HEAD` beziehungsweise den jeweiligen Ausgangscommit arbeiten.

## Technischer Ist-Zustand

- Swift Package, Swift Tools 6.0, Mindestziel macOS 14.
- Produkte: ausführbares `NewEdenNexus` sowie der opt-in,
  laufzeitkonfigurierte `NewEdenNexusSDEAcceptance`-Abnahmerunner.
- Produktive Targets: Domain, Application, Infrastructure, Persistence und App.
- sieben Testtargets plus TestSupport und Legacy-Schema-Fixture; 388
  automatisierte Tests.
- CLI-Buildwege: SwiftPM und eigenständiges `NewEdenNexus.xcodeproj` mit
  gemeinsamen App-/SDE-Abnahmerunner-Schemes.
- eigene Git-Wurzel im Projektordner, Branch `main`, initiale geprüfte
  Baseline vorhanden.
- kein Remote; nichts wurde gepusht.

## P07A–P07C-Architektur

```text
SDEUpdateService
├── ActiveSDEVersionReading
├── SDEReleaseChecking
├── SDEUpdateStateStoring
├── SDEUpdateClock
└── DiagnosticLogging
        │
        ├── CCPSDEMetadataClient
        │   ├── SDEHTTPTransport
        │   ├── SDEBackoffSleeping
        │   └── SDEJitterGenerating
        └── SwiftDataSDEUpdateStateRepository

SDEInstallationService
├── SDEArchiveDownloading
├── SDEArchivePreparing
├── SDEImporting / StaticDataCatalogStreamingMapping
├── StaticDataCatalogStreamingStaging
├── SDEPromotionSafetyBackingUp
├── StaticDataCatalogStreamingStoring / RollingBack
├── ActiveSDEVersionReading
└── SDEInstallationLogStoring
        │
        ├── CCPSDEArchiveDownloader
        ├── SecureSDEArchivePreparer
        ├── SwiftDataSDEStagingService
        ├── SQLiteSDEPromotionSafetyBackup
        └── FileSDEInstallationLogStore

SDEAppComposition
├── SDEUpdateService + CCPSDEMetadataClient
├── CachedSDEArchiveDownloader + SDEInstallationService
├── SDEArchiveRecoveryBoundary
├── SwiftData-Repositories
├── KeychainStore
└── SDEManagementViewModel
        ├── 24-h-Start-/Laufzeitscheduler
        ├── Status, Fortschritt und Abbruch
        ├── Logfilter und redigierter Export
        └── bestätigte Katalog-Retention
```

- Application ist UI-, URLSession- und SwiftData-frei.
- Infrastructure verwendet feste offizielle HTTPS-URLs, ETag,
  Last-Modified, 304, Cache-Control, Timeouts sowie begrenztes
  Backoff/Jitter.
- Automatische Prüfungen sind lokal mindestens 24 Stunden gedrosselt. Eine
  manuelle erzwungene Prüfung respektiert weiterhin frische Servercachezeiten.
- Der JSONL-Parser verlangt genau einen gültigen `_key == "sde"`-Datensatz.
- Der kleine YAML-Parser toleriert Zusatzfelder, lehnt fehlende oder
  typveränderte Pflichtfelder aber ab.
- Unverstandene neuere Schemaänderungen führen zu
  `schemaReviewRequired`.
- Offline- und Fehlerzustände verändern den aktiven Katalog nicht.
- Der User-Agent ist zentral konfiguriert; eine Kontaktmöglichkeit wird nicht
  erfunden oder hartcodiert.
- Zentrale Fehleroperation `sdeMetadataCheck` mit Code `NEN-SDE-006`.
- Der Archivpfad nutzt ausschließlich die feste versionierte CCP-URL und
  lehnt Redirects, falschen Status/Inhaltstyp, Längenabweichungen und
  unzureichenden Speicher ab.
- Central Directory und lokale ZIP-Header werden vor dem festen,
  shellfreien `/usr/bin/ditto`-Aufruf geprüft; der extrahierte Dateibaum wird
  danach vollständig erneut validiert.
- Ein temporärer Schema-v4-Store wird aktiviert und wieder geöffnet, bevor
  der aktive Store ein `beforeSDEUpdate`-Backup und eine blockweise atomar
  abgeschlossene Promotion erhält.
- Ein Kandidaten-Inhaltshash erlaubt, unvollständige Batchimporte gezielt zu
  entfernen; eine abgeschlossene Version mit demselben Hash wird geschützt.
- Alte SDE-Versionen bleiben erhalten und können per Buildnummer reaktiviert
  werden.
- Nichtterminale Phasenjournale können beim nächsten Start bereinigt oder
  anhand des aktiven Builds abgeschlossen werden.
- Der App-Start führt diese Wiederherstellung vor dem ersten
  Metadatencheck über eine kontaktfreie Cleanup-Grenze aus. Ein
  Recoveryfehler blockiert den neuen Check und bleibt als sicherer
  Diagnosecode sichtbar.
- Der opt-in Abnahmerunner verlangt Owner-Gate, Build, geprüften Schemastand
  und Kontakt zur Laufzeit. Er berührt keinen produktiven Benutzerstore,
  prüft Wiederöffnung und Katalogabfragen und entfernt erfolgreiche
  Abnahmeartefakte.
- `SDEManagementViewModel` importiert weder SwiftData noch konkrete
  Netzwerk-/Dateiadapter; alle produktiven Implementierungen entstehen in
  `SDEAppComposition`.
- Automatischer Download und Installation sind getrennte Opt-ins und
  standardmäßig deaktiviert. Installation verlangt zusätzlich persönliche
  Bedingungen-Prüfung und einen realen Schlüsselbundkontakt.
- Der private Archivcache prüft Größe und SHA-256 vor Wiederverwendung.
- Diagnoseexporte enthalten keine Vorgangs-IDs, URLs, Pfade, Hashes,
  Kontakte, Tokens oder Accountdaten.
- Retention verlangt Vorschau plus exakte Bestätigung und schützt aktive
  sowie mindestens eine Rollback-Version.

## P10-Rezeptresolver

```text
ResolveRecipeUseCase
├── RecipeCandidateReading
│   └── SwiftDataItemBlueprintCatalog
│       └── genau eine aktive StaticDataVersion
└── stabile Fachregeln
    ├── eindeutige oder explizite Blueprintwahl
    ├── manufacturing / reaction
    ├── Veröffentlichung und Mengenintegrität
    └── vollständige Referenzablehnung

RecipeReferenceAuditing
└── itemgenauer Audit aller Material-/Produktlücken des aktiven Builds
```

- Application importiert weder SwiftData noch SwiftUI.
- Persistenz bildet vollständige Kandidaten auf sendbare DTOs ab; die
  fachliche Entscheidung verbleibt im Use-Case.
- Mehrere Kandidaten werden nicht automatisch priorisiert.
- `copying`, Forschung und `invention` werden nicht als deterministische
  Produktionsrezepte interpretiert.
- Ergebnis und Diagnosen enthalten Buildnummer und Inhaltshash.
- P10 verändert weder das SwiftData-Schema noch Benutzerdaten.
- Die Graphbasis und erste Rezeptstufe sind in P13 vorhanden; P14 ergänzt
  Runs und Output, P15 Blueprint-ME und Materialbedarf. Rekursion,
  Aggregation und Kosten bleiben P16–P19
  beziehungsweise P29.

## Datenhaltung und Migration

| Schema | Version | Zweck |
|---|---:|---|
| `NexusLegacySchema` | 0.9.0 | Migrationsquelle |
| `NexusSchemaV1` | 1.0.0 | Projekt-/Charakterbasis |
| `NexusSchemaV2` | 2.0.0 | versionierter statischer Katalog |
| `NexusSchemaV3` | 3.0.0 | persistenter Item-Suchschlüssel |
| `NexusSchemaV4` | 4.0.0 | persistenter SDE-Prüfstatus |
| `NexusSchemaV5` | 5.0.0 | kataloggebundenes Projektziel |
| `NexusSchemaV6` | 6.0.0 | persistierter Produktionsgraph |
| `NexusSchemaV7` | 7.0.0 | Runformel-Provenienz |
| `NexusSchemaV8` | 8.0.0 | Projekt-ME und Materialformel-Provenienz |
| `NexusSchemaV9` | 9.0.0 | Reaktionsregelprofil |
| `NexusSchemaV10` | 10.0.0 | Lager und manuelle Bestände |
| `NexusSchemaV11` | 11.0.0 | CSV-Importberichte |
| `NexusSchemaV12` | 12.0.0 | projektbezogene Verfügbarkeitsregeln |
| `NexusSchemaV13` | 13.0.0 | globale Schutzbestandsregeln |
| `NexusSchemaV14` | 14.0.0 | globale Projektreservierungen |

Schema v4 ergänzt additiv `SDEUpdateCheckRecord`. Gespeichert werden letzter
Versuch, letzter Erfolg, offizieller Build/Release, Validatoren,
Cachefristen, Schema-Changelog-Stand, Parser-Version und sicherer Status.

Die Migrationskette bis v14 ist dateibasiert mit Projekten, aktivem Katalog,
Graphbestand, Lager/Beständen, Importberichten, Verfügbarkeits- und
Schutzregeln sowie Reservierungen geprüft. Backups werden als Schema 14.0.0
erzeugt; 1.0.0 bis 14.0.0 bleiben als migrierbare Vorgänger zulässig. Ein
unbekanntes 15.0.0
wird abgelehnt.

## Offizielle read-only Prüfung

Am 2026-07-23 lieferten die offiziellen Endpunkte:

- aktueller Build `3444265`,
- Release `2026-07-23T11:06:22Z`,
- `latest.jsonl`: HTTP 200, `application/jsonlines+json`, ETag,
  Last-Modified, `Cache-Control: max-age=300`,
- `schema-changelog.yaml`: HTTP 200, `text/vnd.yaml`, ETag,
  Last-Modified, `Cache-Control: max-age=300`,
- höchster Changelog-Eintrag `afterBuildNumber: 3407448`.

Das offizielle Archiv für Build `3444265` antwortete direkt mit HTTP 200,
`application/zip`, `Content-Length: 98707648`, ETag und Last-Modified. Zwei
isolierte P07B-Läufe lieferten reproduzierbar:

- 48 Kategorien,
- 1.609 Gruppen,
- 52.821 Itemtypen,
- 5.082 Blueprints,
- 19.137 Aktivitäten,
- 36.499 Materialien,
- 6.329 Produkte,
- 21 erhaltene, explizit nicht aufgelöste Typreferenzen,
- Inhaltshash
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`.

Beide Stores wurden erneut geöffnet und mit Item 587 „Rifter“ sowie
Blueprint 691 abgefragt. Das Sicherheitsbackup wurde erzeugt und alle
temporären Abnahmeartefakte wurden entfernt. Kein produktiver Benutzerstore
wurde geöffnet oder verändert.

## Build- und Teststatus

P26 wurde über die in P09B eingerichteten Xcode- und SwiftPM-Wege auf My Mac
geprüft. Für den Xcode-CLI-Nachweis war Signing ausgeschaltet; es wurden
keine Teamwerte hinterlegt:

- Xcode-Projektliste: 15 Targets, Debug/Release und gemeinsame Schemes
  erkannt,
- Xcode-App Debug: erfolgreich,
- Xcode Debug: **alle sieben konfigurierten Testtargets erfolgreich**,
- SwiftPM Debug: erfolgreich,
- SwiftPM Debug: **434 Tests, 0 Fehler, 0 übersprungen**,
- Xcode Debug: **434 Tests, 0 Fehler, 0 übersprungen**,
- statischer Xcode-/SwiftPM-Paritätscheck: 15 Targets, sieben Testtargets,
  zwei gemeinsame Schemes.

P26 ergänzt Domainrechner, Application-Orchestrierung und Schema v15 für
Build-or-Buy. Der fokussierte Lauf bestand 11 Domain-, Application- und
Persistenztests. Migration, Leerstore, Wiederöffnung, Backup,
Preview-before-write, Stale-State, Projektduplikat-Standard und
Xcode-/SwiftPM-Parität sind abgedeckt. Der letzte Release-Nachweis bleibt
der grüne P25-Stand; PLAN-002 verlangt für P26 nur Debug. Kein produktiver
Benutzerstore wurde geöffnet oder verändert.

Der isolierte Release-Abnahmerunner bestand mit Build `3444265`, löste je ein
vollständiges Fertigungs- und Reaktionsrezept auf und blockierte alle 21
gefundenen Referenzlücken itemgenau. Backup, Wiederöffnung und Cleanup waren
erfolgreich; kein produktiver Benutzerstore wurde geöffnet.

Die bereits vorhandenen P07B-/P07C-Nachweise bleiben ebenfalls gültig:

- fokussierte P07B-Gruppen: Download/ZIP/Journal/Orchestrierung,
  Staging-Wiederöffnung, Rollback und Wiederanlauf an allen persistenten
  Phasengrenzen erfolgreich,
- P07C-Debug und -Release jeweils **167 Tests, 0 Fehler**.

Coverage nach P07C einschließlich der nicht laufzeitgerenderten SwiftUI-
Zeilen:

- produktive Sources: **63,63 %** (`7509/11801` Zeilen),
- `SDEManagement.swift`: **100 %** Zeilen,
- `CachedSDEArchiveDownloader.swift`: **90,73 %** Zeilen,
- `SwiftDataSDECatalogRetentionRepository.swift`: **93,20 %** Zeilen,
- `SDEManagementViewModel.swift`: **39,54 %** Zeilen,
- `SDEArchiveRecoveryBoundary.swift`: **87,50 %** Zeilen.

Low-Memory-Realabnahme nach dem Umbau:

- erster Lauf: 33,391 s, Peak-RSS 952.057.856 Bytes,
- zweiter Lauf: 33,202 s, Peak-RSS 948.125.696 Bytes,
- identische Mengen und identischer Inhaltshash wie die frühere
  Snapshot-Baseline mit 2.448.506.880–2.454.126.592 Bytes,
- Download, Backup, Terminaljournal, Cleanup, Wiederöffnung,
  Rifter-/Blueprintabfrage jeweils erfolgreich,
- Kontakt- und Accountwerte wurden weder im Repository noch in
  Abnahmeartefakten gefunden.

Ein eingeschränkter `xcodebuild -list`-Kontrolllauf meldete nicht
projektspezifische CoreSimulator-/Cachewarnungen. Die freigegebenen macOS-
Build- und Testläufe sowie alle Abschlussbefehle endeten mit Exitcode 0. Beim
ersten Xcode-Aufbau scheiterte die XcodeGen-Headerkopie an der
Benutzerskriptsandbox; die reproduzierbare Projektkonfiguration schaltet
diese für das Projekt aus. Keine Compilerwarnung wurde pauschal
unterdrückt.

Der erste vollständige P07C-Lauf deckte einen Fehler im neuen Archivcache auf:
Nach dem Verschieben wurde die nicht mehr vorhandene temporäre Datei gehasht.
Die Hashberechnung wurde vor das Verschieben gesetzt; gezielter
Regressionstest sowie vollständige Debug-/Release-Suite sind danach grün.

## Vorhandene App-Funktionen

- native SwiftUI-App und zentrale Navigation,
- vollständiger lokaler Projektlebenszyklus mit Statusregeln, Duplikaten,
  reversibler Archivierung und SwiftData-freier Projektansicht,
- kataloggebundene Produkt-, Aktivitäts-, Blueprint- und Mengenauswahl,
- Schema-v14-SwiftData-Store und versionierte Migrationen,
- technische Backup-/Restore-Grenze,
- validiertes SDE-Staging, Mapping und versionierte Aktivierung,
- read-only Item-/Blueprintkatalog,
- deterministischer Fertigungs-/Reaktionsresolver mit Referenzaudit,
- persistierter erklärbarer Produktionsgraph mit rekursiven
  T1-/T2-/Reaktionsketten,
- integer-sichere Runs, tatsächliche Ausgabe und Überschuss,
- referenzgeprüfte Blueprint-ME, Materialbedarf und Ersparnis,
- SDE-Metadatencheck mit HTTP-Cache und Schema-Gate,
- technischer SDE-Archivdownload mit ZIP-/Speichergrenzen,
- isolierter SDE-Teststore, Voraktivierungsbackup, Rollback und Phasenjournal,
- produktive SDE-App-Composition, Startautomation und manuelle Updateaktionen,
- SDE-Status/Settings, Fortschritt, Verlauf und redigierter Diagnoseexport,
- bestätigte Retention mit aktivem und letztem funktionierendem Schutzstand,
- unabhängige Drittanbieter-/Eigentumsansicht mit offiziellen Links,
- zentrale Fehler- und Diagnosegrenze,
- synthetische Referenzdaten und optionaler Real-SDE-Testhaken,
- flache native Materialaggregation,
- lokale logische Lager und kataloggebundene manuelle Bestände,
- kontrollierter CSV-Bestandsimport mit atomarem Detailbericht,
- projektbezogene physische Verfügbarkeit mit erklärbaren Lager-, Material-
  und Mengenfreigaben,
- globale Sicherheitsbestände und persistente Projektreservierungen mit
  Preview-before-write, Lebenszyklus und Archivschutz,
- berechnete Reservierungskonflikte mit stabilen Prioritätsvorschlägen und
  bestätigter atomarer Reduktion/Freigabe,
- integrierter Produktions-/Inventionsworkspace mit Build-or-Buy,
  Wirtschaftlichkeit und persistenter Zielkaufmenge,
- projektübergreifender Einkauf mit Teilkäufen sowie Text-/CSV-Export,
- eingefrorener SSO/PKCE-/Keychain-Zukunftscode,
- eigenständiges Xcode-Projekt mit gemeinsamen App-/Runner-Schemes und
  statischem SwiftPM-Paritätscheck.

## Fehlende unmittelbare Kernbereiche

Im fachlichen Produktions-, Inventions-, Lager-, Preis- und Einkaufsfluss
ist kein neuer Großbereich erforderlich. P50/P51 sind abgeschlossen; P52
endete mit den ausdrücklich dokumentierten P42-Projektzuordnungs-/Endgates
als OFF-037-Restbefund. P53 ist vollständig abgeschlossen.
Öffentliche Distributionsarbeit
blockiert den lokalen Zielbetrieb weiterhin nicht.

P27–P36 wurden nach der internen Kernabnahme reaktiviert und erledigt.
Unabhängige Bedarfsgates und Zukunftsbefunde bleiben in `OFFEN.md`
erhalten. P38–P42 einschließlich P50/P51 sind technisch vorhanden;
OFF-040 ist im Eigentümerbetrieb abgeschlossen. P52 führt die verbleibenden
P42-Endgates nach der OFF-053-Korrektur fort; P53 schließt den Kanon. P54
bleibt danach als lokaler Sicherungspunkt mit gesonderter Commit-Freigabe
offen. P43 bis P47
bleiben nachgelagert; P48 bleibt danach optional zuletzt.

## Offene-Punkte-Audit

- `OFF-018` / `KI-018` sind durch P07A erledigt.
- `OFF-020` ist für den lokalen Betrieb nicht erforderlich und wurde als
  persönliche Veröffentlichungsvoraussetzung auf P48 verschoben.
- `OFF-019` / `KI-019` sind durch blockweises Mapping, Persistieren und zwei
  reale Unter-1-GiB-Läufe erledigt. Der ergänzende tatsächliche
  Prozessabbruch/App-Neustart ist mit P36 ebenfalls abgenommen.
- `OFF-006` / `KI-006` / `KI-013` sind erledigt: automatische
  Vor-Migrations-Sicherung, kontrollierter Store-Lebenszyklus,
  Recovery-UI und isolierter v19→v20→Restore→Wiederöffnungsdrill sind
  nachgewiesen. Downgrade bleibt nicht unterstützt.
- `OFF-004` / `KI-003` sind erledigt: Graphformat 7 aggregiert
  Materialblätter nach Type-ID und bewahrt jeden Wurzelpfad.
- `OFF-009` / `KI-012` sind erledigt: Aggregationssummen prüfen jede
  `Int64`-Addition und erhalten den Altgraphen bei Überlauf.
- `OFF-003` / `KI-004` sind durch den deterministischen, versionsisolierten
  Resolver erledigt.
- `OFF-016` / `KI-016` sind durch die itemgenaue Ablehnung aller 21
  Referenzlücken des aktuellen Builds erledigt. Der offizielle
  Quelldatenbefund bleibt sichtbar.
- `OFF-021` verhindert weiterhin einen ungezielten Import sämtlicher
  SDE-Datensätze. P18 importiert nur den real belegten
  Facility-/Reactor-/Rig-/Reaction-Dogmaumfang. P41 benötigt lediglich
  vorhandene Type-IDs und benutzerdefinierte Region-/Location-IDs; es wurde
  kein weiterer SDE-Datensatz importiert. Künftiger Ortsdatenbedarf bleibt am
  selben Gate.
- `OFF-028` / `KI-028` ist erledigt: T2-Regelbasis,
  Blueprint-Herkunft, Reaktionsprofil und beide Preflights sind
  implementiert und real geprüft.
- `OFF-014` / `KI-009` sind durch das eigenständige Projekt, gemeinsame
  Schemes und die Xcode-/SwiftPM-Nachweise erledigt.
- `OFF-023` / `KI-023` sind durch die geprüfte P09A-Root-Baseline erledigt.
- `OFF-024` / `KI-024` sind erledigt: fünf externe SIGKILL-Abbrüche an
  persistenten SDE-Grenzen wurden jeweils durch eine neue Composition auf
  demselben isolierten Store erfolgreich wiederhergestellt.
- `OFF-025` / `KI-025` sind durch den isolierten manuellen App-, Tastatur- und
  VoiceOver-Smoke-Test in P09B erledigt.
- `OFF-026` / `KI-026` sind durch den app-spezifischen Storepfad, die sichere
  Legacy-Signaturprüfung und den echten isolierten App-Prozess erledigt. Der
  fremde globale Store blieb unverändert.
- `OFF-030` / `KI-030` sind durch zwei native Xcode-UI-Tests des echten
  App-Bundles bei Standard- und Mindestfenster, Accessibility-Audit und
  Tab-Fokusnachweis erledigt.
- `OFF-031` / `KI-031` sind durch den erneuten nativen Xcode-UI-Worker-Lauf
  mit 2/2 bestandenen Tests erledigt.
- `OFF-032` / `KI-032` ist als optionaler P48-Umfang verschoben. Bundle-ID,
  Version, Developer-ID, Hardened Runtime, Archiv, Notarisierung, Stapling
  beziehungsweise App-Store-Einreichung sind keine lokalen Blocker.
- `OFF-008` / `KI-011` sind durch P11, P32 und abschließend P38 erledigt;
  Account-/SSO-Views verwenden Application-Use-Cases und injizierte Ports.
- `OFF-013` / `KI-014` sind durch die getestete P38-Kompensation zwischen
  Keychain und SwiftData erledigt.
- `OFF-010` / `KI-010` ist durch P38–P40 erledigt: gehärtetes SSO,
  öffentliche Charakterbasis und getrennte persönliche
  Assets-/Blueprint-/Job-Snapshots sind implementiert und geprüft.
- `OFF-005` / `KI-005` ist durch P20–P25 erledigt: Lager, Verfügbarkeit,
  Schutzbestände, Projektbindungen sowie nachträgliche Konflikterkennung
  und bestätigte atomare Auflösung sind nachgewiesen.
- `OFF-035` / `KI-038` ist durch P50 erledigt: detaillierte P40-Nutzung und
  kontrollierte opt-in Asset-Verfügbarkeit ohne automatische Vermischung.
- `OFF-036` / `KI-039` / `KI-040` wurden in P51 geschlossen: korrektes
  Fehlerrouting, transparente Scope-Minimierung und echter
  Plan-/Ist-Seitenvergleich.
- `OFF-037` gehört ausschließlich in P52 und verlangt die reale
  Eigentümer-Betriebsabnahme der P40–P42-Datenpfade.
- `OFF-053` / `KI-055` ist technisch korrigiert; P42-1 benötigt noch den
  schreibfreien Eigentümer-Retest im neuen Build.
- `OFF-038` / `KI-041` ist durch Status-, Link- und Kanonbereinigung sowie
  die bestätigte recoverbare Archivierung geschlossen.
- `OFF-039` / `KI-042` gehört P54. Ein lokaler Commit erfordert unmittelbar
  vorher eine gesonderte ausdrückliche Freigabe; ein Push ist ausgeschlossen.

## Technische Schulden, Risiken und Zielprompts

| Befund | Verbindliche Behandlung |
|---|---|
| bestehende Views griffen teilweise direkt auf SwiftData zu | **P38–P40 erledigt**: SSO, öffentliche Charakterdaten und persönliche ESI-Snapshots verwenden Application-Ports, getrennte Stores und Architekturtests |
| tatsächlicher Prozessabbruch/App-Neustart | **P36/OFF-024 erledigt**; fünf persistente Grenzen mit externem SIGKILL und frischem Neustart abgenommen |
| Xcode-UI-Worker startete in der OFF-006-Sitzung keinen Test | **REL-001/OFF-031 erledigt**; 2/2 native UI-Tests bestanden |
| große P07B-Vertrags-/Orchestrierungs- und Download-/Archivdateien | **P34 erledigt**, nach Verantwortung geteilt und durch Vertrags-/Architekturtests verifiziert |
| persönliche Marken-/Veröffentlichungsfreigaben | für lokale SDE-Nutzung technisch ausreichend geprüft; zusätzlicher Sign-off erst optional in **P48/OFF-020** |
| öffentliche macOS-Verteilung nicht konfiguriert | kein lokales Risiko; **P48/OFF-032** bleibt zuletzt optional |
| offizielle Blueprintreferenzen können in einem Build nicht auflösbar sein | P10 blockiert jedes betroffene Rezept itemgenau; künftige Builds werden durch den Abnahmerunner erneut gezählt |
| P40-Detailfluss und kontrollierte Asset-Verfügbarkeit | **P50/OFF-035 erledigt**; Schema v23, Preview/Bestätigung und Doppelzählungsschutz geprüft |
| P42-Fehlerrouting, Scope-Transparenz und Plan-/Ist-Darstellung | **in P51/OFF-036 geschlossen** |
| produktive P40-/P41-/P42-Betriebsabnahme teilweise offen | **P52/OFF-037/OFF-053**; P40- und P41-Gates bestanden, P42-1 nach technischer Restkapazitätskorrektur im Retest; P42-2 und Endgate offen |
| technische IDs und unbeabsichtigte Projekt-Asset-Auswahl | **OFF-044 teilweise live behoben**; Rücknahme bestätigt, vollständige Typnamensichtprüfung im neuen Build offen |
| exakte Namen privater Spielerstrukturen | **OFF-045 technisch umgesetzt**; eigener Opt-in-Scope, privater cachekonformer Abruf und ID-freier Fallback; reale Zustimmung/Sichttest offen |
| irreführende unbekannte Gegenstände | **OFF-046/KI-049 technisch behoben**; 2.000-Rohzeilen-Grenze entfernt, echtes SDE-Fehlen getrennt angezeigt; Sichttest offen |
| widersprüchliche Steuertexte und uneindeutige Projekt-/Promptkopien | **P53/OFF-038 erledigt**; ein Projektkanon, historische Kopien recoverbar archiviert |
| großer Stand seit Baseline nicht lokal gesichert | **P54/OFF-039**, nur nach gesonderter Commit-Freigabe |

## Reviewstatus

P51/OFF-040 sowie P52/OFF-041/OFF-042/P40-1 bis P40-4 und die
Auswahlrücknahme sind technisch und
live bestanden:
Owner-Contact, Refresh, öffentlicher und persönlicher ESI-Pfad sowie
Wallet-Inspect/Apply, Aktionsfeedback und Persistenz nach Neustart wurden
bestätigt. P40-4 bestand mit korrekter Vorschau, separater ausdrücklicher
Speicherung und erhaltener aktiver Auswahl nach vollständigem Neustart ohne
Netz. OFF-045/OFF-046 bestanden 662/662 Tests und den signierten
Xcode-Debugbuild. Die Gesamtentscheidung bleibt **⚠️ mit Einschränkung**
wegen der realen Struktur-Scope-Zustimmung, des Typnamen-Sichttests und der übrigen
P52/OFF-037-Betriebsabnahme.

OFF-054 ist für P55/P56 ebenfalls technisch und im Eigentümer-Sichttest
bestanden. Der damals offene OFF-058-Befund ist inzwischen in P58 technisch
geschlossen.

## Empfohlene nächste Aufgabe

OFF-061 im neuen P59-Chargenablauf sichtbar abschließen; KI-060 ist
nach signiertem Build und strikter Signaturprüfung geschlossen. Die
historische P42-Oberfläche bleibt zurückgezogen. P60 beginnt erst nach
OFF-061 und nur auf ausdrücklichen Auftrag. P54 bleibt ausschließlich mit gesonderter
Commit-Freigabe zulässig. Die unabhängigen Namens-Livetests OFF-045/OFF-046
bleiben wahrheitsgemäß offen. P49 bleibt unbelegt; P43–P48 bleiben
zurückgestellt beziehungsweise optional.

## P26-Nachtrag

P26 verwendet die vorhandenen P22–P24-Rechner für Lagerfilter,
Sicherheitsbestand und Reservierungen. Bestand auf Zwischenstufen reduziert
Runs und Unterketten; eine Kaufentscheidung schneidet nur den gewählten
Unterbaum ab. Inventionsmaterialmengen werden versionsgebunden aus dem
SDE-Rezept geladen, ohne Fehlversuche zu schätzen.

Schema v15 speichert nur projektbezogene Kaufabweichungen. Migration,
Leerstore, Wiederöffnung und Backupformat 15.0.0 sind geprüft.
SwiftPM und Xcode Debug bestanden jeweils 434 Tests; 11 davon prüfen P26
gezielt. Die UI wurde anschließend in P32 ergänzt.

## P32-Nachtrag

`ProductionWorkspaceView` stellt ausschließlich P26-Ergebnisse dar.
`BuildOrBuyWorkspaceViewModel` hängt am Application-Port und speichert nur
nach Vorschau sowie ausdrücklicher Bestätigung. Das Dashboard verwendet nun
ebenfalls einen ViewModel-/Use-Case-Pfad. P32 verändert weder Schema noch
Lager- oder Reservierungsdaten.

SwiftPM und Xcode Debug bestanden jeweils 439 Tests, 0 Fehler und
0 übersprungene Tests. Acht fokussierte Prüfungen decken T1-Bauen/Kaufen,
T2-Invention, Lagerabzug, projektfremde Vorschau, schmale/breite
Rendergrößen, Fehlerzuordnung sowie UI-/Accessibility-Verträge ab. Der
native Computer-Use-Kanal brach bei der ergänzenden isolierten Sichtprüfung
technisch ab; deshalb wird kein manueller GUI-/VoiceOver-Nachweis behauptet.
Die reproduzierbaren Render- und Quellarchitekturprüfungen sind erfolgreich.

## P38-Nachtrag

P38 ersetzt den monolithischen SSO-Apppfad durch injizierte
Application-Ports, OS-Adapter in Infrastructure und ein
SwiftData-Account-Repository. Authorization Code mit PKCE S256,
kryptografischer `state`, exakter einmaliger Loopback-Callback,
OIDC-Discovery, RS256/JWKS-Prüfung sowie Issuer-, Audience-, Ablauf-,
Subject- und Scopeprüfung sind implementiert. Refresh-Token verbleiben
ausschließlich im Keychain; gekoppelte Accountmutationen besitzen getestete
Kompensation. Account- und Synchronisationsansicht führen weder SwiftData-
noch Keychain-Zugriffe aus. Schema v20 und Benutzerdaten bleiben unverändert.

SwiftPM Debug baute erfolgreich; 540/540 Tests bestanden. Der Xcode-
Debugbuild der App war erfolgreich. Der fokussierte Xcode-Testlauf wurde
zusätzlich geprüft; sein Ergebnis und die Umgebungsgrenzen sind in
`TEST_HISTORY.md` dokumentiert. Der nachgelagerte Eigentümerlauf, die leere
Charaktertabelle nach dem Trennen und die kontrollierte Bereinigung der zwei
verwaisten Alt-Tokens schließen OFF-033. P38 ist `✅`.

## P39-Nachtrag

P39 ergänzt eine transportneutrale Application-Grenze, einen offiziellen
öffentlichen ESI-Client und einen getrennten, begrenzten Dateicache.
Frische Daten verursachen keinen Netzabruf; 200, 304, Cachevalidatoren,
Serverlimits, ein begrenzter 5xx-Retry, Abbruch und Offline-Fallback sind
automatisiert geprüft. Der öffentliche Request verwendet keinen
Access-Token und keine privaten Scopes. Beim bestätigten Trennen werden
Account, Refresh-Token und öffentlicher Charaktercache kompensierbar
entfernt.

SwiftPM Debug, 565/565 Tests und Xcode Debug für macOS arm64 bestanden.
Ein realer CCP-Test lieferte 200 und anschließend 304. Es gab keine
Schemaänderung. P40 wurde danach separat umgesetzt.

## P40-Nachtrag

P40 ergänzt transportneutrale Modelle und Ports für Assets, Blueprints und
Industry Jobs, einen offiziellen Bearer-ESI-Client und einen getrennten
persönlichen Dateisnapshot. Exakt drei Read-Scopes werden angefordert.
Assets und Blueprints werden sequenziell bis `X-Pages` geladen; Validatoren,
Last-Modified-Konsistenz, 200/304, 401/403, 420/429, begrenzter 5xx-Retry,
Offlinebetrieb, Abbruch, Schema- und Ressourcenlimits sind geprüft.

Vor jeder lokalen Änderung zeigt die App Einfüge-, Änderungs- und
Löschsummen sowie einzelne Änderungen. Apply verlangt die unveränderte
Basisrevision und aktiviert einen validierten Staging-Stand atomar.
Trennen entfernt den privaten Snapshot kompensierbar. Keine SwiftData-
Migration und keine automatische Vermischung mit manuellen Lagern.

37 eindeutige fokussierte P40-Tests und 583/583 vollständige SwiftPM-Tests
bestanden. Xcode Debug für macOS arm64 bestand außerhalb der restriktiven
Makro-Sandbox. Der erste persönliche Live-Abruf bleibt eine
Eigentümerhandlung mit erneuter SSO-Scope-Zustimmung, kein offener
Codefehler.
