# Projektreservierungen

Stand: 2026-07-25  
Prompt: P24  
Formelversion: 1  
Persistenzschema: v14

## Zweck und Grenze

P24 bindet die nach P22 und P23 für ein Projekt verwendbaren
Materialmengen an genau dieses Projekt. Die Bindung ist global je
CCP-Type-ID. Eine Aufteilung auf Charaktere oder einzelne Lager wird nicht
erfunden, weil dafür im aktuellen MVP keine belastbare Allokationsregel
vorliegt.

Reservierungen verändern den physischen Lagerbestand nicht. Verbrauch,
Freigabe und Ablauf ändern ausschließlich den Reservierungszustand.
Systematische Erkennung und Auflösung nachträglich entstandener
Überbuchungen ist durch P25 ergänzt; siehe
[Reservierungskonflikte](RESERVATION_CONFLICTS.md).

## Berechnungsreihenfolge

Für jede aggregierte Endmaterialzeile gilt:

1. P22 berechnet die physisch freigegebene Menge.
2. P23 zieht den globalen Sicherheitsbestand ab.
3. P24 summiert die aktiven Restbindungen anderer Projekte.
4. Die eigene aktive Bindung wird getrennt ausgewiesen.

```text
freiVorEigenemProjekt =
  max(0, nachSicherheitsbestand - andereAktiveReservierungen)

maximalReservierbar =
  min(Projektbedarf, freiVorEigenemProjekt)

freiNachEigenemProjekt =
  max(0, freiVorEigenemProjekt - eigeneVorgabe)

ungedeckterBedarf =
  max(0, Projektbedarf - eigeneVorgabe)
```

Alle Mengen verwenden `Int64`; Summenüberläufe werden abgelehnt. Eine neue
oder erhöhte Bindung oberhalb von `maximalReservierbar` wird nicht
gespeichert.

## Lebenszyklus

| Status | Bindet Bestand | Bedeutung |
|---|---:|---|
| `reserved` | ja | vollständig unverbrauchte Bindung |
| `partiallyConsumed` | ja | Restmenge bleibt gebunden |
| `consumed` | nein | gesamte reservierte Menge fachlich verbraucht |
| `released` | nein | Restbindung bewusst freigegeben |

Prioritäten liegen im Bereich 1 bis 3. Ein optionales Ablaufdatum ist
informativ: Es kennzeichnet eine aktive Bindung als abgelaufen, löst sie
aber nicht automatisch. Terminale Datensätze bleiben als Historie erhalten;
eine spätere neue Bindung erhält eine neue UUID.

Ein Projekt mit aktiver Reservierung kann nicht archiviert werden. Damit
entsteht kein unsichtbarer bindender Bestand.

## Vorschau und bestätigtes Schreiben

`ProjectReservationService.preview` ist schreibfrei. Die Vorschau enthält
P22-/P23-Zustand, Graph-ID, gespeicherte Reservierungsversionen, geplante
Änderungen und das berechnete Ergebnis.

`apply` benötigt:

- eine ausdrückliche Bestätigung,
- denselben Projekt-, Graph-, Bestands-, Ausschluss-,
  Sicherheitsbestands- und Reservierungszustand,
- einen nicht archivierten, vorhandenen Zielprojekt-Datensatz,
- atomar gültige Änderungen ohne zweite aktive Bindung desselben Projekts
  und derselben Type-ID.

Bei veraltetem Zustand, Paralleländerung, Abbruch oder Persistenzfehler
bleibt der bestehende Stand erhalten.

## Schichten

```text
ProjectReservationView
  -> ProjectReservationViewModel
    -> ProjectReservationManaging
      -> ProjectReservationService
        -> SafetyStockManaging
        -> ProjectReservationRepository
          -> SwiftDataProjectReservationRepository
            -> NexusSchemaV14.StockReservationRecord
```

SwiftUI kennt keine SwiftData-Modelle. Berechnung, Zustandsautomat und
Validierung liegen in Domain und Application; SwiftData übernimmt nur
Persistenz und zusätzliche Integritätsprüfungen.

## Daten- und Datenschutzgrenze

Persistiert werden Projekt-ID, stabile CCP-Type-ID, Mengen, Priorität,
optionaler Ablaufzeitpunkt, Status und Zeitstempel. Namen, Charakterdaten,
Kontaktdaten, Tokens, Lagerallokationen und berechnete Vorschauergebnisse
werden nicht in Reservierungsdatensätzen gespeichert.

## Nachweis

- 20 fokussierte Domain-, Application- und Persistenztests,
- SwiftPM Debug und Release: jeweils 408 Tests bestanden,
- Xcode Debug und Release: jeweils 408 Tests bestanden,
- v13→v14-Migration, leere v14-Datenbank und zweite Öffnung,
- Backupkompatibilität 1.0.0 bis 14.0.0,
- isolierter App-Start mit `PRAGMA integrity_check = ok`,
- gesonderter Review gemäß `Documentation/REVIEW_RULES.md`.

## Ergänzung durch P25

P25 persistiert keinen Konfliktstatus und verändert das v14-Schema nicht.
Es berechnet Konflikte immer neu aus Projektbedarf, P22-/P23-Verfügbarkeit
und aktiven P24-Bindungen. Eine konfliktfreie Vorschau darf bestehende
aktive Bindungen nach ausdrücklicher Bestätigung atomar reduzieren oder
freigeben; automatische Prioritätsentscheidungen sind ausgeschlossen.
