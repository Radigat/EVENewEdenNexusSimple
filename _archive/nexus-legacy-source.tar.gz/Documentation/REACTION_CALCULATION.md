# Reaktionsstufen im Produktionsgraph

Stand: 2026-07-24 · P18

## Zweck und Scope

P18 integriert notwendige Reaktionen als berechenbare Stufen in denselben
deterministischen Produktionsgraphen wie T1 und T2. Unterstützt werden
Composite-, Hybrid- und Biochemical-Reaktionen einschließlich
Molecular-Forged-Formeln. Eine Stufe kann ein neutrales Basisszenario oder
einen vollständig belegten modifizierten Kontext verwenden.

Nicht enthalten sind reale Strukturzustände, Fuel, Steuern, Slots, Kalender,
Standorte oder automatische Optimierung. Diese Funktionen bleiben P43.

## Offizielle Grundlage

Geprüft wurden am 2026-07-24:

- die offizielle CCP-SDE-Dokumentation und der offizielle JSONL-SDE,
- die CCP-Supportseite zu Reaktionen,
- SDE-Build `3444265`, veröffentlicht am 2026-07-23.

Der reale Import bestätigte:

- 52.821 Typen, 5.082 Blueprints, 19.137 Aktivitäten,
  36.499 Material- und 6.329 Produktzeilen,
- Composite-, Hybrid- und Biochemical-Formeln,
- Reactor-Typen `45537`, `45538` und `45539`,
- Refinery-Typen Athanor `35835` und Tatara `35836`,
- Reactions-Skill `45746`,
- Reaktionsrigs `46484` bis `46497`,
- die benötigten Dogma-Attribute `2356`, `2357`, `2660`, `2713`, `2714`
  und `2721` sowie Effekte `6892` und `6976`.

Die Zuordnung lautet:

| Formelgruppe | Reaktionsart | Reactor |
|---|---|---|
| 1888 Composite Reaction Formulas | Composite | 45537 |
| 1889 Polymer Reaction Formulas | Hybrid | 45538 |
| 1890 Biochemical Reaction Formulas | Biochemical | 45539 |
| 4097 Molecular-Forged Reaction Formulas | Biochemical | 45539 |

## Versionierter Regelvertrag

`ReactionRuleProfile` Version 1 wird beim SDE-Import aus genau den benötigten
Typ-, Dogma- und Gruppenwerten erzeugt. Das Profil ist an Buildnummer und
Inhaltshash gebunden und wird als `ReactionRuleRecord` gespeichert. Fehlende
Pflichtwerte, falsche Namen, unbekannte Gruppen, nicht passende Reactorarten,
unzulässige Rigs oder ein nicht verifiziertes Profil blockieren die
Berechnung.

Der Import speichert keine vollständige Dogma-Kopie. Er liest sieben
SDE-Datensätze gestreamt, behält aber nur 20 relevante Typ-Dogma-Einträge,
sechs Attributdefinitionen und acht Effektdefinitionen für die Prüfung des
Regelprofils. Benutzerdaten bleiben davon getrennt.

## Produktionskontext

`neutralBase` verwendet keine Anlage, keinen Reactor, keine Rigs, keinen
Security-Bandwert und Skillstufe 0. Alle Faktoren sind 1,0. Dieser Modus
behauptet keine reale Strukturkonfiguration.

`modified` verlangt:

- Athanor oder Tatara,
- den zur Formelart passenden Reactor,
- Low-Sec oder Null-Sec/Wormhole,
- Skillstufe 0 bis 5,
- höchstens ein passendes Zeit- und ein passendes Materialrig.

Jede Auswahl und alle Regelversionen werden im Graphsnapshot gespeichert.
Ungültige oder unvollständige Kontexte schlagen geschlossen fehl; es werden
keine Ersatzwerte erfunden.

## Berechnung und Rundung

Runs und Ausgabemengen verwenden die ganzzahlige P14-Ceiling-Regel.
Blueprint-ME und Blueprint-TE sind für Reaktionen nicht anwendbar und müssen
technisch 0 bleiben.

Materialformel Version 1:

1. `Rohmenge = Basismenge je Run × Runs`,
2. der SDE-Rigbonus wird mit dem Security-Multiplikator skaliert,
3. `Effektivmenge = ceil(Rohmenge × Materialfaktor)`.

Zeitformel Version 1:

1. `Basisdauer = Basiszeit × Runs`,
2. Reactions-Skillfaktor anwenden und auf volle Sekunden aufrunden,
3. Facility-Faktor anwenden und aufrunden,
4. Zeitrigfaktor einschließlich Securityskalierung anwenden und aufrunden.

Alle Multiplikationen prüfen Integerüberlauf. Codierte abgeleitete Werte
werden beim Laden neu berechnet; Manipulation oder veraltete Formelversionen
werden abgelehnt.

## Graph und Persistenz

Graphformat 6 und Expansionsrichtlinie 3 erlauben:

- Manufacturing → Reaction,
- Reaction → Manufacturing,
- Reaction → Reaction,
- gemischte T1-/T2-/Reaktionsketten.

Reaktionsknoten speichern Formel, Art, Reactor, Kontext, Zeitaufschlüsselung
und Regelprovenienz. Reaktionsmaterialkanten speichern Rohmenge,
Materialfaktor, Effektivmenge und Ersparnis. Formate 1 bis 5 bleiben lesbar,
werden aber als veraltet behandelt.

Schema v9 ergänzt ausschließlich den kataloggebundenen
`ReactionRuleRecord`. Die Migration v8→v9 ist additiv; Projekt- und
Graphpayloads bleiben erhalten. Backupformat 9.0.0 ist unterstützt.

## Fehler- und Bestandsschutz

Eine Neuberechnung wird nicht gespeichert bei:

- unbekannter oder nicht reiner Reaktionsformel,
- fehlendem oder nicht verifiziertem Regelprofil,
- Katalog-/Hashwechsel,
- falscher Facility-/Reactor-/Rig-/Security-/Skillkombination,
- nicht aufgelösten Typreferenzen,
- Zyklus, Tiefe, Knotenlimit, Überlauf oder Cancellation,
- inkonsistenter oder manipulierter Persistenzpayload.

Ein bereits gespeicherter Graph bleibt in diesen Fällen unverändert.

## Nachweise und Grenzen

SwiftPM und Xcode bestanden Debug und Release mit jeweils 310 Tests.
Der reale isolierte Import von Build 3444265 bestätigte eine reine
Composite-Reaktionsformel, alle drei Reaktionsarten und das verifizierte
Regelprofil. Ein isolierter Schema-v9-App-Store bestand
`PRAGMA integrity_check`.

P19 führt gleiche Materialien kontrolliert nach Type-ID zusammen und
bewahrt ihre Vorkommens-/Wurzelpfade.
P43 bleibt für vollständiges Reaktionsmanagement zuständig.
