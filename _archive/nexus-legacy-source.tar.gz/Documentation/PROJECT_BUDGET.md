# Projektbudget

Stand: 2026-07-28 · P55/P56

## Zweck

Das Projektbudget beantwortet: Wie viel ISK muss für die aktuell geplante
Beschaffung, Logistik und Produktion bereitstehen?

## Materialbudget

Die Berechnung verwendet ausschließlich die aktuelle wirksame Einkaufsliste.
Diese entsteht nach Lagerabzug, Schutzbeständen, Reservierungen,
Build-or-Buy-Entscheidungen und bestätigten Mengenabweichungen.
Ob diese Entscheidungen einzeln oder mit einer P56-Gruppenaktion getroffen
wurden, ändert den Budgetvertrag nicht.

- **Bauen:** Die Stufe bleibt Produktionsjob; ihre fehlenden Eingabematerialien
  werden gekauft.
- **Kaufen:** Der Teilgraph endet an dieser Stufe; stattdessen wird das
  Zwischenprodukt gekauft.
- Rohstoffe, Komponenten, Zwischenprodukte und Invention-Materialien werden
  je Type-ID nur einmal mit ihrer wirksamen Einkaufsmenge bewertet.

Fehlende Preise bleiben sichtbar und verhindern eine vollständige
Budgetberechnung. Es werden keine Nullpreise erfunden.

## Kostenblöcke

```text
Materialeinkauf = Summe(Einkaufsmenge × Einheitspreis)
Benötigtes Budget = Materialeinkauf + Logistikkosten + Produktionskosten
```

Alle Beträge werden deterministisch in ISK-Hundertsteln gerechnet und auf
Überlauf geprüft. Logistik- und Produktionskosten sind derzeit manuelle,
nichtnegative Projektwerte. Eine automatische Routen-, Facility-, Steuer-,
SCI- oder Jobkostenberechnung ist nicht enthalten.

## Speicherung

Gespeichert werden je Projekt nur Preissatz, Logistikkosten und
Produktionskosten. Berechnungsergebnisse werden aus aktuellem Plan,
Einkaufsliste und Preisen neu erzeugt. Vorschau und Preisstand werden vor
dem bestätigten Schreiben erneut geprüft.

Schema v25 ergänzt dafür `ProjectBudgetConfigurationRecord`. Die additive
Migration v24→v25 erhält Projekte, Preise, Bestände, P29-Konfigurationen,
Wallet-Snapshots und P42-Zuordnungen.

## Sichtbare Grenze zu Wallet

Die frühere Projektfinanzansicht wurde aus der Accountoberfläche entfernt.
Bestehende Walletdaten bleiben erhalten, sind aber nicht Teil der
Planbudgetrechnung. Eine spätere Istkosten-/Budgetgegenüberstellung benötigt
einen eigenen ausdrücklichen Auftrag.
