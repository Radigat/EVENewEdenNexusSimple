# Item- und Blueprintkatalog

Stand: 2026-07-23 · P09, um P10-Resolvergrenze ergänzt

## Zweck und Grenze

Der P09-Katalog stellt statische EVE-Stammdaten aus genau einer aktiven
SDE-Version read-only bereit. Er dient nachgelagerten Use-Cases für
Produktauswahl und Rezeptauflösung, enthält aber weder eine eigene UI noch eine
fachliche Entscheidung zwischen konkurrierenden Rezepten.

## Application-Vertrag

`ItemBlueprintCatalogReading` definiert:

- begrenzte Itemsuche,
- exakten Item-Lookup per externer Type-ID,
- exakten Blueprint-Lookup per externer Blueprint-Type-ID.

Die drei Use-Cases kapseln den Port. Application-Typen importieren weder
SwiftData noch SwiftUI.

Exakte Lookups liefern `CatalogLookupResult.found` oder `.notFound`. Ein nicht
vorhandener Datensatz ist damit ein erwartbares, typisiertes Ergebnis und kein
Persistenzfehler.

## Suche und Filter

`CatalogSearchRequest` unterstützt:

- optionalen Namenstext,
- Veröffentlichung `published`, `unpublished` oder `any`,
- optionale Kategorie-ID,
- optionale Gruppen-ID,
- optional `producible`,
- optionale Blueprint-Aktivität,
- Limit 1 bis 100.

Ein leerer Suchtext ist nur zusammen mit mindestens einem semantischen Filter
zulässig. Negative IDs und Limits außerhalb des Bereichs werden vor dem
Repositoryzugriff abgelehnt.

Die Namensnormalisierung:

1. entfernt führenden, nachfolgenden und mehrfachen Leerraum,
2. faltet Groß-/Kleinschreibung,
3. faltet Diakritika,
4. vereinheitlicht Zeichenbreite.

Der persistierte Schlüssel `ItemType.searchName` verwendet dieselbe zentrale
Normalisierung. Treffer werden deterministisch nach `searchName` und danach
nach externer Type-ID sortiert.

## Version und Begrenzung

Jede Abfrage ermittelt genau eine aktive `StaticDataVersion`.

- keine aktive Version: `noActiveVersion`,
- mehr als eine aktive Version: `multipleActiveVersions`,
- genau eine aktive Version: alle Abfragen bleiben strikt auf deren
  Inhalts-SHA begrenzt.

Suchergebnisse enthalten `CatalogDataVersion`, Treffer und `hasMore`. Für
einfache Filter werden höchstens `limit + 1` Itemzeilen geladen. Filter über
Produktionsbezüge arbeiten in begrenzten Batches und deduplizieren Items vor
der Seitenausgabe.

## Item- und Blueprintdetails

Itemdetails enthalten:

- Type-ID, Name, Veröffentlichung, Volumen und Basispreis,
- Gruppe und Kategorie,
- Blueprints/Aktivitäten, in denen das Item als Produkt entsteht.

Blueprintdetails enthalten:

- Blueprint-Type-ID und optional aufgelöstes Blueprint-Item,
- unterstützte Aktivitätsarten,
- Produktbezüge mit Aktivitätszeit, Menge und optionalem
  Wahrscheinlichkeitswert,
- eine zusammengefasste Kennzeichnung, wenn die zugehörige Aktivität nicht
  aufgelöste Material- oder Produktreferenzen besitzt.

Die Reihenfolgen sind stabil. P09 erhält nicht aufgelöste Referenzen sichtbar.
P10 lädt über `RecipeCandidateReading` die vollständigen Material- und
Produktzeilen aus genau einer aktiven Version. `ResolveRecipeUseCase` lehnt
jede unvollständige Referenz itemgenau ab; Details stehen in
[RECIPE_RESOLUTION.md](RECIPE_RESOLUTION.md).

## Datenmodell und Migration

`NexusSchemaV3` 3.0.0 ergänzt `ItemType.searchName`. Die benutzerdefinierte
Migration v2→v3 berechnet den Wert für alle vorhandenen Itemtypen und speichert
den Store. Neue P08-Importe setzen ihn direkt im Initializer.

Backups verwenden Schema 3.0.0; 1.0.0 und 2.0.0 bleiben als migrierbare
Vorgänger zulässig.

## Fehler und Diagnose

Katalogvertragsfehler unterscheiden ungültige Eingaben, Versionsfehler,
inkonsistente Referenzen und Persistenzfehler. Die zentrale Fehlergrenze bildet
Katalogabfragen auf `NEN-SDE-005` ab. Rohfehler und lokale Pfade gelangen nicht
in die Benutzeranzeige.

`CancellationError` bleibt erhalten und wird nicht als Persistenzfehler
maskiert.

## Performance-Nachweis

Der P09-Regressionstest erzeugt 50.000 synthetische Itemtypen und führt zehn
Suchen mit Limit 50 aus:

- Prüfgerät: MacBook Pro (Mac16,8), Apple M4 Pro mit 14 CPU-Kernen und
  24 GB RAM, macOS 26.5.2,
- Debug-Gesamtlauf: 0,300 Sekunden für den Abfrageblock,
- Release-Gesamtlauf: 0,296 Sekunden,
- je Abfrage höchstens 51 geladene Itemzeilen,
- genau ein Item-Fetch-Batch für den einfachen Suchfall.

Das Mindestziel macOS 14 verwendet keinen nativen nicht-eindeutigen
SwiftData-`#Index`. Der persistente kanonische Schlüssel, das DB-Prädikat und
das harte Limit erfüllen den P09-Nachweis. P34 bewertet die reale Suchlatenz
erneut, falls Datenmenge oder Zielplattform dies erfordern.

## Prüfnachweise

- Application-Vertrags- und Validierungstests,
- Persistence-Tests für Suche, Filter, Deduplizierung, Versionen,
  Inkonsistenzen und Abbruch,
- Migrationstest v2→v3 mit Backfill,
- Backupkompatibilität 1.0.0/2.0.0/3.0.0,
- P10-Debug-/Release-Gesamtlauf mit jeweils 181 Tests,
- offizieller Build 3444265 bis Store-Wiederöffnung, Fertigungs- und
  Reaktionsauflösung sowie vollständigem Referenzaudit.
