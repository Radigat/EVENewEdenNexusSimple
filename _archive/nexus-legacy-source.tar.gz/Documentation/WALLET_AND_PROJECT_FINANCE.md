# Wallet und reale Projektfinanzen

> P55 hat die frühere sichtbare Projektfinanzansicht aus der Accountoberfläche
> entfernt. P59 verwendet die erhaltenen, bestätigten Projektzuordnungen nun
> ausschließlich als kapazitätsgeschützte Quelle für Chargenverkäufe und
> Verkaufsgebühren im Produktionsbuch.

Stand: 2026-07-29 · P42/P51/P59

## Umfang und Datenquellen

P42 liest ausschließlich persönliche Charakterdaten aus den offiziellen
ESI-Endpunkten für Kontostand, Journal und Transaktionen. Erforderlich ist
zusätzlich zu den P40-Scopes genau
`esi-wallet.read_character_wallet.v1`. Corporation-Wallets, Schreibzugriffe,
automatische Buchhaltung und automatische Projektzuordnungen sind nicht
enthalten.

P40 fordert zunächst nur seine drei persönlichen Produktionsscopes.
Bestehende Charaktere müssen den zusätzlichen Walletscope in einem eigenen
Dialog erklärt bekommen und einmal sichtbar über EVE SSO neu autorisieren.
Die App leitet die Berechtigung ausschließlich aus lokal gespeicherten
Scopemetadaten ab, nie aus dem Vorhandensein eines Snapshots. Ohne alle vier
Read-Scopes wird kein Wallet-Endpunkt aufgerufen.

## Abruf und lokaler Snapshot

`URLSessionESIWalletClient` verwendet den zentralen ESI-Transport und:

- `X-Compatibility-Date`, User-Agent und Bearer-Token,
- ETag/`If-None-Match` und Last-Modified/`If-Modified-Since`,
- begrenzte `X-Pages`-Journalpagination und `from_id`-Transaktionen,
- Deduplizierung über Journal- beziehungsweise Transaktions-ID,
- explizite Behandlung von 304, 401/403, 420/429, 5xx und Offline,
- Größen-, Seiten- und Datensatzgrenzen sowie Abbruchweitergabe.

`FileESIWalletStore` speichert je Charakter einen privaten JSON-Snapshot
unter `Application Support/NewEdenNexus/WalletSnapshots`. Verzeichnis und
Dateien erhalten restriktive POSIX-Rechte; Schreibvorgänge erfolgen über eine
temporäre Datei und atomaren Austausch. Der Snapshot ist revisionsgebunden
und unabhängig von SDE-, P40- und Marktdaten.

## Projektzuordnung

Walletdaten verändern niemals automatisch ein Projekt. Der Benutzer wählt:

1. Projekt und Transaktion beziehungsweise eindeutig zuordenbare
   Journalbuchung,
2. vollständige oder partielle Menge beziehungsweise ISK-Betrag,
3. eine nicht persistierte Vorschau,
4. eine ausdrückliche Bestätigung.

Die Anwendung verhindert Doppel- und Mehrprojektzuordnungen oberhalb der
Quellmenge oder des Quellbetrags. Eine zwischenzeitlich geänderte Wallet-
Revision oder Zuordnung macht die Vorschau ungültig. Beträge werden
deterministisch in ISK-Hundertsteln normalisiert und überlaufgeprüft.

Vor der Vorschau berechnet eine reine Application-Projektion aus Snapshot und
bereits bestätigten Zuordnungen die sicher verfügbare Restmenge
beziehungsweise den Restbetrag. Vollständig ausgeschöpfte oder inkonsistente
Quellen werden nicht als neue Auswahl angeboten. Erwartbare Überbuchungen
erscheinen als Inline-Hinweis; `NEN-FIN-001` bleibt unerwarteten
Speicher-/Anwendungsfehlern vorbehalten. Das Verwerfen einer Vorschau entfernt
nur den flüchtigen Vorschauzustand und schreibt keine Projektzuordnung.

Bestätigte Istkosten, Isterlöse und der realisierte Saldo werden getrennt von
P29-Planwerten berechnet. Erwartete Kosten, Gewinn, Marge und ROI werden
nicht überschrieben.

P59 unterteilt eine bestätigte Projektquelle weiter auf Produktionschargen.
Die Summe aller Chargenzuordnungen darf weder die Projektmenge noch den
Projektbetrag überschreiten. Die Vorschau bindet den aktuellen Walletstand;
ein Refresh vor Bestätigung macht sie ungültig. Öffentliche Marktquotes und
eigene offene Marktorders sind keine Istbelege.

Die Finanzansicht zeigt für dasselbe ausgewählte Projekt Kosten, Erlöse und
Gewinn beziehungsweise Saldo in zwei Spalten: P29-Plan und bestätigtes
P42-Ist. Fehlender Ziel-/Graph-/Preisstand, fehlende Zuordnungen, veraltete
Walletrevisionen und archivierte Projekte besitzen explizite Zustände.
Archivierte Projekte bleiben lesbar, nehmen aber keine neuen Zuordnungen an.

## Datenlebenszyklus

Bestätigte Zuordnungen liegen im additiven SwiftData-Schema v22.
Die Migration v21→v22 erfindet keine Walletdaten. Backups verwenden
seit P59 Schemaangabe `28.0.0` und bleiben zu den Versionen 1 bis 28
kompatibel. Schema v24 ergänzt nur nicht geheime Scopemetadaten; Schema v25
ergänzt ausschließlich die getrennte Projektbudgetbasis. Schema v26 ergänzt
das Produktionsbuch, Schema v27 die unveränderliche Kostenbasis und Schema
v28 chargengebundene Verkaufs-/Gebührenzuordnungen.

Beim Trennen eines Charakters nennt der Bestätigungsdialog ausdrücklich
Wallet-Snapshot und bestätigte Wallet-Projektzuordnungen. Die Löschung ist in
den bestehenden Kompensationsablauf eingebunden: Schlägt ein späterer Schritt
fehl, werden Konto, Snapshot und Zuordnungen wiederhergestellt.

## Datenschutz und Diagnose

Access- und Refresh-Tokens werden weder im Snapshot noch in SwiftData, Logs
oder Berichten gespeichert. Parteien, Walletpositionen und Quell-IDs werden
nicht protokolliert. Zentrale Diagnosecodes sind `NEN-ESI-004`,
`NEN-ESI-005` und `NEN-FIN-001`.

## Grenzen

- Das Journal liefert nur den von ESI verfügbaren Zeitraum; fehlende Historie
  wird nicht rekonstruiert.
- Type- und Location-IDs bleiben im ersten Umfang IDs; `OFF-021` verhindert
  einen unbelegten zusätzlichen SDE-Import.
- Ein realer Walletabruf setzt die persönliche erneute SSO-Zustimmung voraus
  und wird erst in P52 mit Benutzerproduktivdaten geprüft.
