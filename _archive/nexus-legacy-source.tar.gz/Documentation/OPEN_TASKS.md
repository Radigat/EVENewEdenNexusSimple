# Offene Aufgaben

Stand: 2026-07-29

## Sofort

- [x] PLAN-005 – notwendige Restkorrekturen und Eigentümerabnahme ohne
  Doppelabdeckung als P50→P51→P52→P53→P54 festlegen; P49 bleibt bewusst
  unbelegt.
- [x] P50 – P40-Restabnahme mit prüfbaren Asset-/Blueprint-/Job-Details und
  kontrollierter opt-in Asset-Verfügbarkeitsquelle; Schema v23 sowie
  Preview-/Bestätigungs- und Doppelzählungsschutz abgenommen.
- [x] OFF-040/P51-Nachkorrektur – technische OAuth-, Rotation-, Keychain- und
  Kontakt-UX-Korrektur sowie Speichern, Neustart, öffentlicher ESI-Abruf und
  sichtbarer Refresh durch den Eigentümer bestätigt.
- [x] P52 – mit den damaligen P42-Projektzuordnungs-/Endgates als
  dokumentiertem Restblocker beendet; P40/P41 und OFF-051 sind bestanden.
- [x] P55 – die sichtbare P42-Projektfinanzoberfläche zurückgezogen und die
  damaligen P42-Gates pausiert; Walletdaten bleiben erhalten.
- [x] P56 technisch – Produktion, T2/Invention, Biochemical, Composite und
  Hybrid Polymer Reactions getrennt; Filter, globale Sammelwahl und kompakte
  Einzelabweichungen ergänzt.
- [x] OFF-054 – sichtbaren P55/P56-Ablauf und deutsche Zahlenformatierung
  im Eigentümerbetrieb bestätigt.
- [x] OFF-059/P57 – Charge `2026-0001` nach Vorschau und Bestätigung
  gespeichert, App vollständig beendet, neu gestartet und mit unveränderter
  Jahresnummer erneut geöffnet.
- [x] OFF-058/P58 – aus der eingebetteten ESI-Preisvorschau einen
  Ziel-Preissatz anlegen oder auswählen, Preise bestätigen und das Budget
  anschließend neu berechnen können; technisch mit Regressionstest
  abgeschlossen.
- [x] OFF-060/P58 – reale Chargenkostenvorschau zuerst mit Jita, danach mit
  einer geänderten benannten öffentlichen Marktquelle sichtbar prüfen;
  Herkunft, Beobachtungszeit, Marge und ROI sind im neuen Build sichtbar;
  Verwerfen bleibt schreibfrei, Speichern verlangt Bestätigung; vom
  Eigentümer am 2026-07-29 ausdrücklich geschlossen.
- [x] OFF-055 – SDE `3.448.696` vollständig aktiviert; Journal, Backup,
  Cleanup, Datenbankintegrität und aktiver Build nach echtem App-Neustart
  bestätigt. Build `3.444.265` bleibt als Rollbackversion erhalten.
- [x] PLAN-006 – Eigentümer-Arbeitsmappe schreibfrei analysiert und
  Produktionsbuch, Istfinanz, Analyse sowie Metenox als P57–P61 spezifiziert.
- [x] P57 mit OFF-059 und P58 mit OFF-060 real abgenommen.
- [x] P59 technisch – bestätigte Projekt-Walletkapazität und begründete
  manuelle Istbelege chargengebunden zuordnen; Realgewinn, Restmengen,
  Stale-/Doppel-/Überbuchungsschutz und Schema v28 umgesetzt.
- [ ] OFF-061/P59 – Teilzuordnung, Verwerfen, Gebühr, Vollzuordnung und
  identisches Ergebnis nach echtem App-Neustart im Eigentümerbetrieb
  bestätigen. KI-060 ist geschlossen; der signierte kanonische Build läuft.
  Vor dem Test eine Charge mit mindestens 2 Output-Units und bestätigter
  P58-Kostenbasis anlegen sowie Verkaufstransaktion und Gebührenjournal über
  **Wallet-Nachweise zuordnen** nach Vorschau bestätigen.
- [ ] P60 – erst nach OFF-061 und nur auf ausdrücklichen Auftrag beginnen.
  P61 und P54 bleiben unabhängig freigabepflichtig.
- [x] P52/P40-1 – persönliche Detailansicht für Assets, Blueprints und
  Industry Jobs online schreibfrei geprüft.
- [x] OFF-043/P40-1 – neu ergänzten sichtbaren Schließen-Button im
  aktuellen Build erfolgreich betätigt.
- [x] P52/P40-2 – App vollständig beendet, ohne Netz neu geöffnet und die
  lokalen Asset-, Blueprint- und Industry-Job-Details schreibfrei geprüft.
- [x] P52/P40-3 – nicht produktionskritisches Projekt und EVE-Lagerorte
  gewählt, Assetverfügbarkeitsvorschau geprüft und Verwerfen live bestätigt.
- [ ] OFF-044/OFF-046/P52 – nach neuem Build prüfen, dass die bestätigte
  Rücknahme erhalten bleibt und keine im SDE vorhandenen sichtbaren Typen
  mehr als „unbekannt“ erscheinen.
- [ ] OFF-045/P52 – über „Strukturnamen freigeben“ den erläuterten Scope im
  echten EVE-Dialog ausdrücklich bestätigen und einen zugänglichen
  Spielerstrukturnamen prüfen; Abbruch muss Daten und Scopes erhalten.
- [x] P52/P40-4 – neue Projekt-Asset-Auswahl nach korrekter Vorschau und
  eigener ausdrücklicher Bestätigung gespeichert; aktive Auswahl nach
  vollständigem Neustart ohne Netz weiterhin vorhanden.
- [ ] OFF-047/P52 – historischer Sichttest: prüfen, dass der Produktionsworkspace
  deutlich breiter öffnet, die horizontale Menüleiste alle sechs Bereiche
  direkt erreicht und nie wieder die gesamte Arbeitsfläche als eine lange
  Seite durchsucht werden muss. Der frühere Bereich „Kosten & ROI“ heißt seit
  P55 „Budget“.
- [ ] OFF-048/P52/P41-1 – im neuen Build ohne angelegten Preissatz
  `ESI-Materialpreise` öffnen, Region wählen, schreibfreie Vorschau abrufen,
  gesperrte Übernahme prüfen und über **Schließen** beenden.
- [ ] OFF-049 – optionale PLEX-Anzeige erst in einem ausdrücklichen späteren
  Marktauftrag mit getrenntem Buy-/Sell-Kurs, Region, Zeitpunkt und Frische
  spezifizieren; ISK bleibt Rechen- und Speicherwährung.
- [x] OFF-050/P52/P41-1 – benannte Regionsliste öffnen, einen der fünf
  Trade Hubs wählen und einen bekannten Marktstandort in einem Home-System
  wie UALX-3 oder X-10-J prüfen. Öffentliche Strukturmärkte dürfen wählbar,
  private bekannte
  Strukturen nur benannt und gesperrt sein. Eigentümer bestätigte die
  Funktion; die Vorschau wurde bereits in den gewählten Preissatz übernommen.
- [x] P41-2/P41-3 – den bereits übernommenen Preissatz auf sichtbare
  ESI-Herkunft, Region/Standort und Cachezeit prüfen; anschließend App
  vollständig beenden und den Stand nach Neustart beziehungsweise offline
  kontrollieren. Eigentümer bestätigte alle Prüfungen als bestanden.
- [x] OFF-051/P52 – gruppierte persönliche ESI-Details live bestätigt;
  alphabetische Stationen, Auf-/Zuklappen, globale Suche und ausschließlich
  aktive Industry Jobs funktionieren. Die vollständige Stationszeile ist
  zusätzlich klickbar und fokussiert getestet.
- [x] P42-1/OFF-053 – technisch korrigiert, aber der Eigentümer-Retest ist
  durch den P55-Oberflächenrückzug pausiert und kein aktuelles Gate.
- [ ] Späterer privater Strukturmarkt-Nutzenreview – nur auf ausdrücklichen
  Auftrag einen authentifizierten Strukturorder-Vertrag mit Scope,
  Kontoauswahl, Cache und eigener Vorschau spezifizieren. Nicht in P41-1
  vorziehen.
- [x] P52/P42-2 – durch P55 pausiert; nur nach einer späteren ausdrücklichen
  Neuspezifikation der sichtbaren Istfinanzen wieder aufnehmen.
- [x] OFF-041/P52 – Wallet-Inspect nach Korrektur des inklusiven
  CCP-`from_id`-Cursors real bestanden; Vorschaufenster öffnet ohne
  `NEN-ESI-004`. Keine Walletdaten wurden dabei übernommen.
- [x] P52 Wallet-Gate – Vorschau nach ausdrücklicher Eigentümerfreigabe
  übernommen und nach vollständigem App-Neustart weiterhin vorhanden.
- [x] OFF-042/P52 – Apply- und Verwerfen-Rückmeldung im echten Build
  bestätigt; Bestandsschutz, Speicherung und Persistenzsemantik unverändert.
- [x] P53 – neun nummerierte Xcode-Projektstände und der alte P21-Entwurf
  nach ausdrücklicher Bestätigung recoverbar archiviert; Kanon, Register,
  Links, Build und Tests geprüft. Nichts gelöscht.
- [x] OFF-052/P53 – lokale Team-ID gegen das Zertifikats-OU geprüft;
  unveränderter signierter Standardbuild bestanden, daher keine
  Signing-Änderung erforderlich.
- [ ] P54 – geprüften lokalen Sicherungscommit nach separater ausdrücklicher
  Freigabe erstellen; kein Push.
- [x] PLAN-004 – Folgeprompts ohne Doppelabdeckung als
  P38→P39→P40→P41→P42→P43→P44→P45→P46→P47→P48 festlegen.
- [x] P38 – technische SSO-Härtung, OFF-008 sowie OFF-013 sind umgesetzt;
  die gemeldeten Keychain-Diagnosepfade und das doppelte Hauptfenster sind
  korrigiert. Vorbereitende Token-Reads bei Verbinden/Trennen sind entfernt;
  Authfehler liefern nun einen sicheren `error_reason`; der damit erkannte
  Misch-JWKS-Decoderfehler ist als KI-036 behoben. Eigentümerlauf und
  kontrollierte Bereinigung der zwei verwaisten Alt-Tokens schließen
  OFF-033; P38 ist `✅`.
- [x] P39 – öffentliche ESI-Charakterbasis mit HTTP-Cache, Limits,
  Offlinebestand und kontrollierter Cachelöschung umgesetzt und abgenommen.
- [x] PLAN-003 – lokalen Betrieb auf dem Rechner des Projekteigentümers als
  verbindliches Ziel festlegen und öffentliche Apple-Distribution als P48,
  letztes optionales Zukunftspaket nach P47, einordnen.
- [x] P07C technisch umsetzen, Build/Tests/Review dokumentieren und bei
  fehlendem manuellem GUI-Nachweis ehrlich auf `⚠️` setzen.
- [x] P09A – aktuellen geprüften Projektstand nach Inhalts-, Geheimnis-,
  Build- und Testprüfung als ersten Commit in der Projekt-Git-Wurzel sichern;
  kein Push und kein Eingriff in andere Repositories.
- [x] P09B – eigenständiges `NewEdenNexus.xcodeproj`, gemeinsame Schemes und
  reproduzierbare Xcode-/SwiftPM-Nachweise ergänzen; dabei `OFF-025` durch
  einen datenschutzneutralen P07C-Fenster-/Tastatur-/VoiceOver-Smoke-Test mit
  Screenshots schließen.
- [x] P10 – deterministischen Rezept-/Aktivitätsresolver implementieren und
  `OFF-003`, `OFF-016`, `KI-004` sowie `KI-016` einschließlich der 21
  offiziellen Referenzlücken verbindlich bearbeiten.
- [x] P11 – lokalen Projektlebenszyklus vollständig spezifizieren,
  implementieren, über Application/ViewModel/Persistenz/UI prüfen und
  dokumentieren.
- [x] `OFF-026`: Kollision mit fremdem globalen `default.store` eingegrenzt,
  app-spezifischen Storepfad und sichere Legacy-Erkennung umgesetzt,
  isolierten echten App-Start nachgewiesen und Fremdstore unverändert
  erhalten.
- [x] P12 anhand der vollständigen Spezifikation ausführen: kataloggebundenes
  Produkt, Aktivität, Blueprint, positive Menge, Provenienz und additive
  Schema-v5-Migration implementieren.
- [x] P13 vollständig spezifiziert und ausgeführt: erklärbarer
  Schema-v6-Produktionsgraph, erste Rezeptstufe, Persistenz, UI und
  Debug-/Release-Nachweise.
- [x] P14 vollständig spezifiziert und ausgeführt: integer-sichere Runs,
  tatsächliche Ausgabe, Überschuss, Graphformat 2, Schema v7 und
  Debug-/Release-Nachweise.
- [x] P15 vollständig spezifiziert und ausgeführt: referenzgeprüfte
  Blueprint-ME, ganzzahlige Jobrundung, Graphformat 3, Schema v8 und
  Debug-/Release-Nachweise.
- [x] P16 vollständig spezifiziert und ausgeführt: Manufacturing-only-
  T1-Rekursion, Graphformat 4, Fehler-/Abbruchschutz und Referenzkette sind
  geprüft.
- [x] P17 vollständig spezifiziert: T2-Klassifikation, Blueprint-Herkunft,
  Inventionsabgrenzung, minimale SDE-Erweiterung, Industry-Preflight,
  Referenzfälle und Abnahmekriterien sind verbindlich beschrieben.
- [x] P17 anhand der vollständigen Spezifikation umgesetzt: versionierte
  Industrie-Regeln, T2-/T3-Abgrenzung, Blueprintqualität, Graphformat 5,
  292 Tests je Buildweg/Konfiguration und Real-SDE-Abnahme.
- [x] P18 vollständig spezifiziert: rekursive Reaktionsstufen, neutrale und
  modifizierte Kontexte, Facility-/Reactor-/Rig-/Security-/Skillregeln,
  P43-Abgrenzung und Referenzfälle sind verbindlich beschrieben.
- [x] P18 anhand der vollständigen Spezifikation ausgeführt:
  SDE-gebundenes Reaktionsprofil, neutrale/modifizierte Kontexte,
  Graphformat 6, Schema v9, 310 Tests und Real-SDE-Abnahme.
- [x] P19 vollständig spezifiziert und ausgeführt: Type-ID-Aggregation,
  Erklärpfade, Graphformat 7, Summen-/Graphschutz; OFF-004/OFF-009 und
  KI-003/KI-012 geschlossen.
- [x] P07C – P07A-Updatecheck und P07B-Installationsservice produktiv über
  `SDEAppComposition` verdrahten; Settings, Verlauf, Diagnoseexport,
  Retention und Rechtsansicht ergänzen.
- [x] AUD-SDE-001: CCP-SDE-Gesamtprompt gegen Quellcode, Tests,
  Dokumentation und aktuelle offizielle Quellen prüfen.
- [x] SDE-Restumfang in P07A, P07B und P07C zerlegen und vollständig
  spezifizieren.
- [x] P07A – offiziellen Build-/Schema-Metadatencheck, HTTP-Cache und
  Compliancegrundlage implementieren.
- [x] P07B-Technikkern – festen Archivdownload, Größen-/ZIP-Schutz,
  isolierten Stagingstore, Sicherheitsbackup, Promotion, Rollback,
  Bereinigung und persistentes Phasenjournal umgesetzt und mit 146
  Debug-/Release-Tests geprüft.
- [x] P07B-Abnahme – persönliche CCP-Bestätigung und reale, ausschließlich
  zur Laufzeit übergebene Kontaktangabe erhalten; Build 3444265 zweimal
  vollständig heruntergeladen, importiert, wieder geöffnet, abgefragt und
  bereinigt.
- [x] P07B – Mapping und Persistenz blockweise ausführen; Build 3444265
  zweimal mit 948–952 MB Peak-RSS und identischem Inhalt nachgemessen.
- [x] P07B – Wiederanlauf nach jeder persistenten Phasengrenze automatisiert
  simuliert; vorherige aktive Version und Cleanup bleiben nachweisbar.
- [x] P36 / OFF-024 – fünf isolierte Installationsprozesse an persistenten
  SDE-Grenzen extern durch `SIGKILL` beendet und jeweils auf demselben Store
  neu gestartet; Integrität, Rollback, Aufbewahrung und Cleanup nachgewiesen.
- [x] OFF-006 – automatische Vor-Migrations-Sicherung, kontrollierten
  Store-Lebenszyklus, Recovery-UI und isolierten
  Backup→Migration→Restore→Wiederöffnungsdrill umsetzen.
- [x] OFF-031 – nativen Xcode-UI-Testworker erneut ausgeführt; zwei echte
  Accessibility-/Tastaturtests gegen das App-Bundle bestanden.
- [x] P34 – `SDEInstallation.swift` und
  `CCPSDEArchivePipeline.swift` nach Verantwortung aufteilen, sobald der
  Realpfad stabil abgenommen ist; keine Verhaltensänderung.
- [x] P04 vollständig spezifizieren: zentrale Fehlerbehandlung und Logging.
- [x] P04 implementieren, testen, reviewen und dokumentieren.
- [x] P05 vollständig spezifizieren: Testfundament und Referenzdaten.
- [x] P05 implementieren, mit Debug-/Release-Testläufen prüfen, reviewen und dokumentieren.
- [x] P06 vollständig spezifizieren: versioniertes Backupformat und sichere Restore-Grenzen.
- [x] P06 implementieren, mit temporären SwiftData-Stores prüfen, reviewen und dokumentieren.
- [x] P07 vollständig spezifizieren: offizielle Quelle, JSONL-Regeln und Staginggrenze.
- [x] P07 implementieren, mit synthetischen Fixtures in Debug/Release prüfen, reviewen und dokumentieren.
- [x] P08 vollständig spezifizieren: Feldmapping, Schema v2, Referenz- und Aktivierungsregeln.
- [x] P08 implementieren, mit synthetischen Tests und offiziellem Build 3424810 prüfen, reviewen und dokumentieren.
- [x] P09 implementieren: Application-Port, aktive Versionsabfragen, exakte Lookups, normalisierte Suche, Filter, Begrenzung und Produktionsbezüge.
- [x] P09 mit Schema-v3-Migration, 50.000-Item-Performancefall, Debug/Release und offiziellem Build 3424810 prüfen, reviewen und dokumentieren.
- [x] Projektordner nach ausdrücklicher Benutzerfreigabe als eigene Git-Wurzel initialisieren; Home-Repository unverändert lassen.
- [x] Projektbezogene `.gitignore` erstellen und regelweise prüfen.
- [x] Zukunftscode für SSO/ESI im Architekturplan vom MVP-Fachkern abgrenzen.
- [x] CFG-001: aktuelle öffentliche EVE-Client-ID zentral konfigurieren,
  früheren Projektstandard gezielt migrieren und eigene IDs erhalten.

## Stufe A

- [x] P09B einschließlich `OFF-025` abgeschlossen.
- [x] P20 nach vollständiger Spezifikation mit Schema v10, Lagerorten,
  manuellen Beständen, Migration, Backup, UI und Review umsetzen.
- [x] P21 nach vollständiger Spezifikation mit begrenztem CSV-Parser,
  itemgenauer Vorschau, ausdrücklicher Bestätigung, atomarem Importbericht,
  Schema v11, Migration, Backup, UI und Review umsetzen.
- [x] P22 nach vollständiger Spezifikation mit projektbezogener
  Preview-before-write-Verfügbarkeit, Lager-/Material-/Mengenfreigaben,
  Schema v12, Migration, Backup, UI und Review umsetzen.
- [x] P23 nach vollständiger Spezifikation mit globalen Type-ID-Regeln,
  Schutzberechnung, unabhängigen Schwellenmeldungen, Schema v13, Migration,
  Backup, UI und Review umsetzen.
- [x] P24 nach vollständiger Spezifikation mit globalen
  Projektreservierungen, Preview-before-write, atomarem Lebenszyklus,
  Schema v14, Archivschutz, UI, Tests und Review umsetzen.
- [x] P25 nach vollständiger Spezifikation mit berechneten Konfliktarten,
  stabilen Prioritätsvorschlägen, Preview-before-write, atomarer
  Reduktion/Freigabe, UI, Tests und Review umsetzen.
- [x] PLAN-002 mit persistenter T1-/T2-Kernabnahme in P37 abschließen.
- [x] P26 mit Build-or-Buy, stufenweisem Lagernetting,
  Produktions-/Inventionsjobs, Fehlmengen, Schema v15 und Review umsetzen.
- [x] P32 mit integriertem Projekt-/Graph-/Lager-/Build-or-Buy-Workspace,
  Produktions-/Inventionsjobs, Konfliktstatus, kopierbaren Fehlmengen,
  persistenzfreiem Dashboard und Review umsetzen.
- [x] P27–P31 und P33–P36 während der internen Kernabnahme temporär
  verschoben halten; nichts stillschweigend vorziehen.
- [x] P37 nur als internen Kernstand abnehmen und keinen Release Candidate
  behaupten.
- [x] P27 mit exakten ISK-Preisprofilen, Schema v16, Backup, UI, Tests und
  Review umsetzen.
- [x] P28 mit kontrolliertem CSV-Preisimport, Einzelkonflikten, atomarem
  Bericht, Schema v17, Backup, UI, Tests und Review umsetzen.
- [x] P29 mit Cash-/wirtschaftlichen Kosten, manuellen Jobkosten, Erlös,
  Gewinn, Marge, ROI, Break-even, Schema v18 und Review umsetzen.
- [x] P30 mit Type-ID-Aggregation, persistenten Zielkaufmengen,
  Vorschau/Bestätigung, Schema v19, UI, Tests und Review umsetzen.
- [x] P31 mit projektübergreifender Type-ID-Aggregation, Teilkäufen,
  gekauft-Status, Text-/CSV-Export, Schema v20, UI, Tests und Review
  umsetzen.
- [x] P33 mit stabilen Validierungscodes, gemeinsamer Kernformular-UX,
  kontrollierten Lese-Retries und Schreib-Retry-Sperre umsetzen.
- [x] `OFF-030` – aktuellen P35-Build nativ bei schmalem sowie breitem
  Fenster, per Accessibility-Audit und mit Tab-Fokusfolge prüfen; P35 final
  abgenommen.
- [x] P36-Restumfang OFF-024 mit realem Prozessabbruch und Neustart
  abgeschlossen.
- [x] REL-001 – aktuelle technische Release-/Complianceprüfung einschließlich
  OFF-031 ausgeführt und dokumentiert.
- [x] P09 als Item-/Blueprintkatalog mit aktiver Version, ID-Lookups, Suche, Filterung, Begrenzung und verbindlich übernommenen offenen Punkten vollständig spezifizieren.
- [x] P10 vollständig spezifizieren und dabei `OFF-003`, `OFF-016`, `KI-004` und `KI-016` verbindlich übernehmen.
- [x] P10 muss nicht aufgelöste offizielle Typreferenzen sichtbar ablehnen;
  Build 3444265 itemgenau mit 21 blockierten Referenzen geprüft.
- [ ] Jede fachliche Berechnung mit Referenzdatensätzen, Randfällen und Rundungsnachweisen versehen.
- [ ] Vor jeder Statusänderung auf `✅` Build, relevante Tests und Abschlussbericht nachweisen.

## Verbindliche Folgeplanung

- [x] P55 technisch: sichtbare Wallet-Projektfinanzen zurückgezogen und
  Planbudget aus Materialeinkauf, Logistik und Produktion umgesetzt.
- [ ] P42-Projektfinanzgates pausieren; keine Fortsetzung ohne neuen
  ausdrücklichen Auftrag für eine getrennte Istfinanz-Neukonzeption.

- [x] P39 – ESI-Infrastruktur, Caching, Limits, Refresh und Charakterbasis.
- [x] P40 – persönliche Assets, Blueprints und Industry Jobs lokal
  synchronisieren.
- [x] P41 – begrenzter Umfang für öffentliche, mengenbezogene
  Material-Beschaffungspreise nach Vorschau/Bestätigung; 593/593
  SwiftPM-Tests und unsigned macOS-arm64-Xcode-Debugbuild bestanden.
- [x] P42 – technische Walletdaten und Zuordnungen bleiben erhalten; die
  sichtbare Projektfinanzoberfläche ist seit P55 pausiert.
- [ ] P43 – Nutzenreview abgeschlossen; vollständige Umsetzung bis zu einem
  belegten Mehrlinien-/Chargenplanungsbedarf zurückgestellt.
- [ ] P44 – Nutzenreview abgeschlossen; Gesamtumsetzung bis zu einem
  belegten PI-, Mehrstandort- oder Mehrlinienbedarf zurückgestellt.
- [ ] P45 – Corporation Edition, Rollen und gemeinsame Projekte.
- [ ] P46 – optionale Cloud- und Mehrbenutzersynchronisation.
- [ ] P47 – erklärbare Optimierung, Solver und KI-Unterstützung.
- [ ] P48 – zuletzt optional: OFF-020/OFF-032 bearbeiten und Mac App Store
  oder öffentliche Direktverteilung vollständig abnehmen.
- [ ] P54 – verbleibender Sicherungsschritt gemäß PLAN-005; P52 ist mit
  dokumentiertem OFF-037/P42-Restbefund beendet, P53 abgeschlossen.
  P43–P48 bleiben davon unberührt und beginnen nicht automatisch.

P54 beginnt nur nach neuer ausdrücklicher Commit-Freigabe und enthält keinen
Push. Kein Zukunftspaket beginnt automatisch.

## Dokumentationspflege

- [ ] Ausführbare Kernprompts kurz halten; Entwürfe erst bei Reaktivierung
  konkretisieren.
- [ ] Vor jedem Promptabschluss alle aktiven Punkte in [OFFEN.md](OFFEN.md) erneut gegen Code, Tests oder Dokumentation prüfen.
- [ ] Nach jedem Prompt Tagebuch, Feature-Matrix, Status, Testhistorie und Abschlussbericht aktualisieren.
- [ ] Projektbuch-Abweichungen als Architekturänderung oder ADR dokumentieren.
