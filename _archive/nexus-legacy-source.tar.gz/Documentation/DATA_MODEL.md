# Datenmodell

Stand: 2026-07-29 · Schema v28 und Graphformat 7 nach P59

## 1. Geltungsbereich

Schema v15 erhält die bereits vor P03 gespeicherten Objekte:

- `CharacterRecord` als Kompatibilitätsmodell des vorhandenen Zukunftscodes,
- `ProductionProject` als bestehende Projektbasis.

Zusätzlich enthält Schema v15 den versionierten statischen SDE-Katalog, einen
persistenten normalisierten Item-Suchschlüssel und den technischen
SDE-Aktualitätsprüfstatus, das kataloggebundene Projektziel und den
persistierten Produktionsgraphsnapshot, das Reaktionsregelprofil sowie lokale
Lagerorte, manuelle Bestandspositionen, CSV-Importberichte und
projektbezogene Verfügbarkeitsregeln, globale Schutzbestandsregeln und
Projektreservierungen. Preis- und Einkaufslistenentitäten folgen in ihren
jeweiligen Prompts.

## 2. Schemaversionen

| Schema | Version | Zweck |
|---|---|---|
| `NexusLegacySchema` | 0.9.0 | feldgenaue Beschreibung des vor P03 unversionierten Stores |
| `NexusSchemaV1` | 1.0.0 | explizites Basisschema mit additiver Datensatzversion |
| `NexusSchemaV2` | 2.0.0 | versionierter SDE-Stammdatenkatalog vor Suchschlüssel |
| `NexusSchemaV3` | 3.0.0 | persistenter Item-Suchschlüssel |
| `NexusSchemaV4` | 4.0.0 | persistenter SDE-Prüfstatus |
| `NexusSchemaV5` | 5.0.0 | kataloggebundenes Projektziel |
| `NexusSchemaV6` | 6.0.0 | persistierter Produktionsgraph |
| `NexusSchemaV7` | 7.0.0 | Runformel-Provenienz |
| `NexusSchemaV8` | 8.0.0 | Projekt-ME und Materialformel-Provenienz |
| `NexusSchemaV9` | 9.0.0 | SDE-gebundenes Reaktionsregelprofil |
| `NexusSchemaV10` | 10.0.0 | Lagerorte und manuelle Bestände |
| `NexusSchemaV11` | 11.0.0 | kontrollierte CSV-Importberichte |
| `NexusSchemaV12` | 12.0.0 | projektbezogene Verfügbarkeitsregeln |
| `NexusSchemaV13` | 13.0.0 | globale Schutzbestandsregeln |
| `NexusSchemaV14` | 14.0.0 | aktuelle globale Projektreservierungen |
| `NexusSchemaV15` | 15.0.0 | projektbezogene Build-or-Buy-Kaufabweichungen |
| `NexusSchemaV16` | 16.0.0 | Preisprofile und manuelle Preise |
| `NexusSchemaV17` | 17.0.0 | CSV-Preisimportberichte |
| `NexusSchemaV18` | 18.0.0 | Projektwirtschaftlichkeitskonfiguration |
| `NexusSchemaV19` | 19.0.0 | Einkaufsmengen-Overrides |
| `NexusSchemaV20` | 20.0.0 | projektbezogener Kauf-Fortschritt |
| `NexusSchemaV21` | 21.0.0 | ESI-Marktpreisprovenienz |
| `NexusSchemaV22` | 22.0.0 | bestätigte Wallet-Projektzuordnungen |
| `NexusSchemaV23` | 23.0.0 | bestätigte projektbezogene ESI-Asset-Auswahl |
| `NexusSchemaV24` | 24.0.0 | zweckgebundene nicht geheime ESI-Scopemetadaten |
| `NexusSchemaV25` | 25.0.0 | getrennte Projektbudgetbasis aus Preissatz, Logistik- und Produktionskosten |
| `NexusSchemaV26` | 26.0.0 | Produktionschargen und kalenderjährliche Anzeigenummern |
| `NexusSchemaV27` | 27.0.0 | unveränderliche Chargenkosten- und Preisquotesnapshots |
| `NexusSchemaV28` | 28.0.0 | chargengebundene Verkaufs- und Gebührenzuordnungen |

`NexusMigrationPlan` registriert alle versionierten Schemata, die Migrationen
0.9.0 → 1.0.0 → 2.0.0, die benutzerdefinierte v2→v3-Backfillmigration und
die additiven Migrationen bis v28.

### Schema v25 – Projektbudget

`ProjectBudgetConfigurationRecord` speichert je Projekt genau einen
Preissatz sowie nichtnegative Logistik- und Produktionskosten in
ISK-Hundertsteln. Material- und Gesamtbudget bleiben berechnete Werte aus
der wirksamen Einkaufsliste. Die additive v24→v25-Migration erfindet keine
Budgetkonfiguration und verändert keine P29-/P42-Daten.

### Schema v26 – Produktionsbuch

`ProductionBatchRecord` speichert filterbare Metadaten und den vollständig
codierten, unveränderlichen Chargensnapshot. Dieser bindet Projekt-, Graph-,
Regel- und SDE-Stand, Produkt, Runs, ME/TE, tatsächliche Ausgabemenge sowie
optionale ESI-, Charakter-, Blueprint- und Ortsbezüge. Unaufgelöste Namen
bleiben `nil`.

`ProductionBatchAnnualCounterRecord` vergibt je UTC-Kalenderjahr eine
eindeutige fortlaufende Anzeigenummer. Zählerreservierung und Chargeninsert
werden gemeinsam gespeichert; Fehler rollen beide Änderungen zurück. Die
additive v25→v26-Migration erzeugt keine historischen Chargen. Backup/Restore
und Wiederöffnung sind mit einer gespeicherten Charge geprüft.

### Schema v27 – Chargenkosten und Preisquotes

`ProductionBatchCostSnapshotRecord` bindet einen vollständig codierten,
unveränderlichen Kostensnapshot an eine vorhandene Produktionscharge.
Filterbare Metadaten enthalten Charge, Projekt, Zielprodukt, Formel- und
Regelversion sowie Erstellungszeit. Der Payload führt typisierte Kostenzeilen,
Quoteprovenienz, tatsächliche Ausgabemenge und deterministisch berechnete
Stückkosten, Aufschläge, Erlös, Gewinn, Marge, ROI und Break-even.

Unbekannte Kosten bleiben optional und werden weder als Null gespeichert noch
in vollständige Kennzahlen umgedeutet. Die additive v26→v27-Migration erzeugt
keine historischen Kostensnapshots. Repository und Backup/Restore erhalten
Projekt-, Chargen-, Preis-, Wallet- und Bestandsdaten unverändert.

### Schema v28 – Verkauf und Realgewinn

`ProductionBatchSaleAllocationRecord` speichert einen vollständig codierten
Verkaufs- oder Gebührennachweis mit filterbaren Metadaten für Charge, Projekt,
unveränderliche Kostenbasis, Belegart, Quelle, Menge, Betrag, Quellzeit und
Erstellungszeit. Walletbelege übernehmen zusätzlich Charakter,
Projektzuordnung, Quellidentität und Walletrevision; manuelle Belege benötigen
eine explizite Begründung und erhalten keine erfundene ESI-Provenienz.

Die persistente Grenze verhindert Überverkauf, doppelte IDs, gemischte
Kostenbasen, Stale-Stand und die projekt- oder chargenübergreifende
Übernutzung einer bestätigten Wallet-Projektkapazität. Die additive
v27→v28-Migration erzeugt keine Verkaufsvergangenheit. Lokale Backups führen
Schema `28.0.0` und bleiben mit den vorherigen Schemaversionen kompatibel.

## 3. Legacy-Schema

### CharacterRecord

P38 verwendet diesen bestehenden Datensatz als lokalen Charakterkonto-
Adapter, ohne das SwiftData-Schema zu ändern. Der Refresh-Token wird niemals
in `CharacterRecord` gespeichert, sondern ausschließlich im macOS-Keychain
unter der stabilen Charakter-ID. `EVECharacterAccount` ist das getrennte
Application-Modell für UI und Use-Cases. Verbinden und Trennen kompensieren
Teilfehler zwischen Keychain und SwiftData und überschreiben keine Projekte,
Bestände oder sonstigen Benutzerdaten.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `characterID` | `Int64` | nein | unique |
| `name` | `String` | nein | bestehender Wert |
| `accountLabel` | `String` | nein | bestehender Wert |
| `syncStateRaw` | `String` | nein | bestehender Raw-Wert |
| `lastSync` | `Date` | ja | bestehender Wert |
| `industrySlots` | `Int` | nein | bestehender Wert |
| `scienceSlots` | `Int` | nein | bestehender Wert |
| `activeJobs` | `Int` | nein | bestehender Wert |
| `createdAt` | `Date` | nein | bestehender Wert |

### ProductionProject

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | unique |
| `name` | `String` | nein | bestehender Wert |
| `productName` | `String` | nein | bestehender Wert |
| `targetQuantity` | `Int` | nein | bestehender Wert |
| `statusRaw` | `String` | nein | bestehender Raw-Wert |
| `priority` | `Int` | nein | bestehender Wert |
| `targetDate` | `Date` | ja | bestehender Wert |
| `notes` | `String` | nein | bestehender Wert |
| `createdAt` | `Date` | nein | bestehender Wert |
| `updatedAt` | `Date` | nein | bestehender Wert |

Das Testfixture definiert dieselben Top-Level-Modellnamen. Ein automatisierter Strukturvergleich prüft Entitynamen, Attributnamen, Typen, Optionalität, Unique-Flags und Unique-Constraints.

## 4. Schema v1

Schema v1 erhält alle Legacy-Felder unverändert und ergänzt in beiden Entitäten:

| Attribut | Typ | Standard | Wirkung |
|---|---|---:|---|
| `recordVersion` | `Int` | `1` | additive Version des Datensatzformats |

Die Migration ist additiv. Es wird kein Legacy-Feld umbenannt, gelöscht, konvertiert oder überschrieben.

## 5. Schema v2 – statischer Katalog

Schema v2 erhält `CharacterRecord` und `ProductionProject` feldgleich und
ergänzt:

| Entität | Zweck | Eindeutiger Lookup |
|---|---|---|
| `StaticDataVersion` | Build, Inhalts-SHA, Quelle, Counts und Aktivmarker | `contentSHA256`, `buildNumber` |
| `ItemCategory` | EVE-Kategorie | `dataVersion + externalCategoryID` |
| `ItemGroup` | EVE-Gruppe mit Kategorie-ID | `dataVersion + externalGroupID` |
| `ItemType` | relevanter Typstammsatz | `dataVersion + externalTypeID` |
| `BlueprintDefinition` | Blueprintkopf und Runlimit | `dataVersion + blueprintTypeID` |
| `BlueprintActivity` | Aktivität und Basiszeit | `dataVersion + blueprintTypeID + activity` |
| `BlueprintMaterial` | Material, Menge, Verbrauch und Reihenfolge | zusätzlich `materialTypeID` |
| `BlueprintProduct` | Produkt, Menge, Wahrscheinlichkeit und Reihenfolge | zusätzlich `productTypeID` |

Jeder zusammengesetzte `identityKey` ist mit `@Attribute(.unique)` hinterlegt.
Dadurch besitzt der exakte versionsgebundene Lookup einen SwiftData-Index.
Schema v2 enthält noch keinen normalisierten Namensschlüssel.

### Referenzregeln

- Gruppe → Kategorie, Typ → Gruppe/Kategorie und Blueprint → Blueprint-Typ
  müssen vor dem Schreiben aufgelöst sein.
- Material- und Produktreferenzen speichern `typeIsResolved`.
- Fehlende offizielle Typreferenzen werden als nicht aufgelöst erhalten und
  in `StaticDataVersion.unresolvedTypeReferenceCount` gezählt.
- Mengen sind positiv, Zeiten nichtnegativ und Wahrscheinlichkeiten liegen in
  `(0, 1]`.
- Aktivitäten sind auf die sechs im offiziellen Build beobachteten Schlüssel
  begrenzt.

### Versions- und Aktivierungsregel

Ein neuer Datenstand wird unter seinem Inhalts-SHA vollständig angelegt.
Frühere Stände bleiben inaktiv erhalten. Datensätze und Aktivmarker werden mit
einem `ModelContext.save()` veröffentlicht. Bei Fehler oder Abbruch wird
zurückgerollt. Derselbe Hash ist idempotent; dieselbe Buildnummer mit anderem
Hash wird abgelehnt.

## 6. Schema v3 – Item-Suchschlüssel

Schema v3 erhält alle v2-Entitäten und ergänzt an `ItemType`:

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `searchName` | `String` | nein | zentral normalisierter Name für Suche und Sortierung |

Die Normalisierung faltet Groß-/Kleinschreibung, Diakritika und Zeichenbreite
und vereinheitlicht Leerraum. Neue SDE-Importe setzen den Schlüssel direkt.
Die benutzerdefinierte Migration v2→v3 berechnet ihn für alle vorhandenen
Itemtypen und speichert den Store.

Das Mindestziel macOS 14 verwendet keinen nativen nicht-eindeutigen
SwiftData-`#Index` für dieses Feld. DB-Prädikat, persistierter Schlüssel,
harte Ergebnisgrenze und der 50.000-Item-Messnachweis bilden die aktuelle
Kataloggrenze.

## 7. Schema v4 – SDE-Aktualitätsstatus

Schema v4 erhält sämtliche v3-Entitäten feldgleich und ergänzt
`SDEUpdateCheckRecord`. Der Datensatz speichert genau den letzten technischen
Prüfzustand:

| Attributgruppe | Inhalt |
|---|---|
| Zeit | letzter Versuch, letzte erfolgreiche Prüfung |
| Release | offizielle Buildnummer und Releasezeit |
| HTTP-Cache | ETag, Last-Modified und Frischefrist je Ressource |
| Schema | höchster Changelog-Build, Eintragszahl und Parser-Version |
| Ergebnis | stabiler Statusrawwert und optionaler sicherer Fehlercode |

Es wird höchstens ein Datensatz erwartet. Mehrere Datensätze werden nicht
stillschweigend zusammengeführt, sondern als Datenintegritätsfehler
abgelehnt. Die Migration v3→v4 ist additiv und verändert weder Benutzer- noch
statische Katalogdaten.

## 8. Persistenztypen und Domain

Persistenztypen leben in `NewEdenNexusPersistence` und importieren SwiftData. Sie sind nicht das fachliche API der Application.

Das Domainmodell `ProductionProjectSnapshot` ist:

- immutable,
- `Sendable`,
- `Equatable`,
- frei von SwiftData und SwiftUI.

### Domainfelder

- `id: UUID`
- `name: String`
- `productName: String`
- `targetQuantity: Int`
- `status: ProjectStatus`
- `priority: Int`
- `targetDate: Date?`
- `notes: String`
- `createdAt: Date`
- `updatedAt: Date`

### Invarianten

- Name ist nach Trimmen nicht leer.
- Produktname ist nach Trimmen nicht leer.
- Zielmenge ist größer null.
- Priorität liegt zwischen 1 und 3.
- Status ist ein gültiger `ProjectStatus`.
- `createdAt <= updatedAt`.

Verletzungen erzeugen `ProductionProjectValidationError`. Ein unbekannter persistierter Status erzeugt `ProductionProjectPersistenceError.invalidStatus`; er wird nicht stillschweigend als „Planung“ ausgegeben.

## 9. Projekt-Mapping

```text
NexusSchemaV3.ProductionProject
        │ explizites validierendes Mapping
        ▼
ProductionProjectSnapshot
        │ explizites Upsert-Mapping
        ▼
NexusSchemaV3.ProductionProject
```

Lesen validiert Status und sämtliche Domain-Invarianten. Schreiben akzeptiert nur einen bereits validierten Snapshot.

Der bestehende SwiftUI-Initialisierer des Persistenztyps klemmt eine Zielmenge weiterhin auf mindestens 1, um das bestehende App-Verhalten nicht in P03 zu verändern.

## 10. Repository-Ports

Application definiert:

```swift
public protocol ProductionProjectRepository: Sendable {
    func save(_ project: ProductionProjectSnapshot) async throws
    func project(id: UUID) async throws -> ProductionProjectSnapshot?
    func projects() async throws -> [ProductionProjectSnapshot]
}
```

`SwiftDataProductionProjectRepository` ist ein `@ModelActor` in Persistence.

Verhalten:

- `save` führt anhand der stabilen UUID ein Insert oder Update aus,
- ein Update erzeugt kein Duplikat,
- `project(id:)` lädt höchstens einen Datensatz,
- `projects()` sortiert nach `updatedAt` absteigend, anschließend Name und UUID aufsteigend,
- `ModelContext.save()`-Fehler werden weitergegeben.

P11 ergänzt darauf den Application-Lebenszyklus ohne Schemaänderung:
Anlegen, Bearbeiten, Statuswechsel, Duplizieren, Archivieren und
Wiederherstellen verwenden dieselben Projektfelder. Archivierung wird über
den vorhandenen Status gespeichert; dauerhaftes Löschen ist ausgeschlossen.
Ein dateibasierter Test öffnet denselben Store mehrfach und prüft den
vollständigen Lebenszyklus einschließlich Zeitstempeln.

Für den SDE-Katalog definiert Application `StaticDataCatalogMapping` und
`StaticDataCatalogStoring`. `ImportStaticDataUseCase` verbindet beide Ports.
Infrastructure implementiert das JSONL-Mapping,
`SwiftDataStaticDataCatalogRepository` die Aktivierung.

Für P09 definiert Application zusätzlich `ItemBlueprintCatalogReading` und
drei Use-Cases für Suche, Item- und Blueprint-Lookup. Der
`SwiftDataItemBlueprintCatalog` implementiert diese Grenze auf der genau einen
aktiven Version. Persistenzmodelle werden nicht als Application-Ergebnisse
ausgegeben.

P10 ergänzt die read-only Ports `RecipeCandidateReading` und
`RecipeReferenceAuditing`. `ResolveRecipeUseCase` trifft die fachliche
Auswahl und Validierung in Application; `SwiftDataItemBlueprintCatalog`
liefert nur versionsisolierte Kandidaten und Referenzaudits. Es entstehen
keine neuen persistierten Entitäten und keine Schemaänderung.

## 11. ModelContainer

`NexusModelContainerFactory` ist die einzige Produktionsfactory für:

- Standardstore der App,
- dateibasierten Store an expliziter URL,
- In-Memory-Store für Tests.

Alle Varianten verwenden:

- `Schema(versionedSchema: NexusSchemaV12.self)`,
- `NexusMigrationPlan`.

Der Produktivpfad ist
`~/Library/Application Support/NewEdenNexus/NewEdenNexus.store`.
Ein vorhandener historischer `default.store` wird vor einer Entscheidung
read-only anhand der Tabellen `ZCHARACTERRECORD` und
`ZPRODUCTIONPROJECT` klassifiziert:

- vollständige Signatur: am bisherigen Ort weiterverwenden,
- fremde Signatur: nicht verändern und app-spezifischen Store verwenden,
- nicht sicher lesbar: sicher scheitern statt leeren Ersatzstore erzeugen.

Ein bereits vorhandener app-spezifischer Store hat Vorrang. Der
testbestimmte Parameter `--new-eden-nexus-isolated-store` akzeptiert nur
absolute Pfade und umgeht keine Schema- oder Migrationsprüfung.

Bei einem Fehler wird kein leerer Ersatzstore erzeugt. Der seit P04
implementierte Runtime-Fehlerfluss zeigt den Startfehler sicher an und erlaubt
einen erneuten Öffnungsversuch.

Sechs Storepfad-/Signaturtests und ein Startargumenttest decken fehlenden,
fremden, gültigen und unlesbaren Legacy-Store, den Vorrang des neuen Pfads
sowie einen expliziten dateibasierten Store ab. Der OFF-026-Reallauf
bestätigte zusätzlich einen konsistenten isolierten Store und einen
unveränderten fremden globalen Store.

## 12. Migrationsnachweis

Der automatisierte Test:

1. erstellt einen dateibasierten Store mit dem Legacy-Fixture,
2. speichert einen Charakter und ein Projekt mit festen Werten,
3. schließt den Legacy-Zugriff,
4. öffnet denselben Store über Schema v8 und den Migrationsplan,
5. vergleicht jedes gespeicherte Attribut,
6. prüft `recordVersion == 1`,
7. öffnet denselben migrierten Store erneut und wiederholt den Vergleich.

Der Test verwendet ein UUID-basiertes temporäres Verzeichnis und entfernt es anschließend. Produktive Benutzerdaten werden nicht geöffnet.

Ein zweiter Test erzeugt ausdrücklich einen dateibasierten Schema-v1-Store,
migriert ihn nach v2, prüft alle Projektwerte sowie leere neue
Stammdatentabellen und öffnet den Store erneut.

Ein dritter Test erzeugt einen dateibasierten Schema-v2-Store mit Itemtypen,
migriert ihn nach v3 und prüft den normalisierten `searchName` sowie die
erneute Öffnung.

Ein vierter Test erzeugt einen dateibasierten Schema-v3-Store mit Projekt und
aktivem SDE-Katalog, migriert nach v4 und prüft deren vollständigen Erhalt
sowie den neuen leeren Prüfstatus. Ein neuer leerer Schema-v8-Store wird
separat geprüft.

Ein fünfter Test erzeugt einen Schema-v4-Store mit aktiven, abgeschlossenen
und archivierten Projekten. Die v4→v5-Migration erhält Werte, Status und
Zeitstempel, lässt aber alle fünf neuen Zielfelder leer. Derselbe Store wird
anschließend erneut über Schema v5 geöffnet.

Ein sechster Test erzeugt einen Schema-v5-Store mit kataloggebundenem
Projektziel, migriert ihn nach v6 und prüft alle Projekt- und Katalogwerte
sowie die neue leere Graphentabelle. Ein separater Repositorytest prüft
Graph-Roundtrip, atomaren Ersatz und die Ablehnung beschädigter Payloads.

P14 ergänzt eine direkte v6→v7-Prüfung mit Projekt, aktivem SDE-Datenstand
und Format-1-Graphpayload sowie eine zweite Storeöffnung. Die vollständige
v3→v7-Kette wird zusätzlich durch die bestehende SDE-Migrationsregression
abgedeckt.

P15 ergänzt eine direkte v7→v8-Prüfung. Projekt, aktiver SDE-Datenstand und
Format-2-Graphpayload bleiben erhalten; die neuen optionalen Felder sind
zunächst leer und derselbe Store wird erneut geöffnet. Die bestehende
Regression prüft zusätzlich die vollständige v3→v8-Kette.

## 13. Integritäts- und Rückfallgrenzen

- P03 implementiert keine Store-Löschung.
- P03 implementiert keinen Fallback auf einen leeren Store.
- P03 enthält keine destruktive Migration.
- Ein Migrationsfehler verhindert das Öffnen.
- Ein Downgrade von v8 auf ältere Schemata wird nicht unterstützt.
- Backup/Restore erzeugt ab P15 Schema-8.0.0-Pakete und akzeptiert 1.0.0 bis
  8.0.0; die Versionen 1.0.0 bis 7.0.0 werden dabei als migrierbare
  Vorgänger behandelt.
- Ein aktivierter älterer SDE-Datenstand bleibt als lokaler Rückfallstand
  erhalten.
- P07B prüft einen neuen Katalog zunächst in einem separaten temporären
  aktuellen Store und öffnet diesen erneut. Erst danach wird der aktive Store
  gesichert und die neue `StaticDataVersion` atomar aktiviert.
- Rollback reaktiviert eine vorhandene Version per Buildnummer; P07B führt
  keine Katalogversionlöschung ein.

Bis P36 bleiben Schemaänderungen additiv und durch Migrations-,
Wiederöffnungs- und Backupregressionstests abgesichert.

## 14. Verschobene Entitäten

| Bereich | Geplanter Prompt |
|---|---|
| Build-or-Buy-Entscheidungen | Schema v15 / P26 |
| Preisprofile | P27–P28 |
| Einkaufslisten | P30–P31 |

P25-Konflikte werden aus Schema-v14-Reservierungen und aktuellem
P22-/P23-Zustand berechnet und deshalb nicht als Entität persistiert. Eine
tatsächliche künftige Ergänzung benötigt eine neue `VersionedSchema`-Version
und passende Migrationstests.

## 15. Schema v5 – kataloggebundenes Produktionsziel

Schema v5 ersetzt ausschließlich das persistente Projektmodell durch eine
feldgleiche Variante mit fünf additiven optionalen Attributen:

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `productTypeID` | `Int64` | ja | positive stabile CCP-Type-ID |
| `productActivityRaw` | `String` | ja | `manufacturing` oder `reaction` |
| `productBlueprintTypeID` | `Int64` | ja | positiv und für Produkt/Aktivität validiert |
| `productCatalogBuildNumber` | `Int` | ja | positive geprüfte SDE-Buildnummer |
| `productCatalogContentSHA256` | `String` | ja | nicht leere geprüfte Katalogprovenienz |

Alle fünf Felder sind bei Bestandsprojekten gemeinsam leer. Bei neuen oder
neu ausgewählten Zielen müssen sie gemeinsam vorhanden und als
`ProductionTargetSelection` gültig sein. `productName` bleibt als
Anzeigesnapshot erhalten; er ist kein Schlüssel.

## 16. Schema v6 – persistierter Produktionsgraph

Schema v6 ergänzt additiv `ProductionGraphRecord`. Das Projektmodell und alle
vorhandenen SDE-Tabellen bleiben feldgleich.

| Attribut | Typ | Regel |
|---|---|---|
| `projectID` | `UUID` | eindeutig; höchstens ein Snapshot je Projekt |
| `graphID` | `UUID` | Domainidentität des Snapshots |
| `catalogBuildNumber` | `Int` | positive SDE-Buildnummer |
| `catalogContentSHA256` | `String` | nicht leere Katalogprovenienz |
| `formatVersion` | `Int` | P13: `1`; P14: `2`; P15: `3` |
| `createdAt` / `updatedAt` | `Date` | Snapshotnachweis |
| `payload` | `Data` | kanonisch codierter und validierter Domain-Snapshot |

Redundante Spalten und Payload müssen beim Laden übereinstimmen. Der
Repositoryadapter validiert den Domain-Snapshot vor dem Speichern und nach
dem Decodieren. Die v5→v6-Migration ist additiv und erzeugt für
Bestandsprojekte keine geratenen Graphen.

## 17. Schema v7 – Runformel-Provenienz

Schema v7 führt `ProductionGraphRecord` feldgleich fort und ergänzt genau ein
optionales Attribut:

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `calculationFormulaVersion` | `Int` | ja | `1` für neue Graphformat-2-Payloads; `nil` für migrierten Format-1-Bestand |

Die eigentlichen Runwerte bleiben Bestandteil des kanonisch codierten
Domain-Snapshots. Dessen Graphformat steigt von 1 auf 2 und speichert je
Rezeptknoten eine `ProductionRunCalculation` mit Formelversion, Zielmenge,
Output je Run, Runs, tatsächlicher Ausgabe und Überschuss.

Beim Laden müssen Datensatzmetadaten und Payload übereinstimmen. Format 2
verlangt Formelversion 1; Format 1 verlangt `nil`. Die leichte
v6→v7-Migration erhält Projekte, SDE-Katalog und Graphpayload unverändert.

## 18. Schema v8 – Projekt-ME und Materialformel-Provenienz

Schema v8 führt Projekt und Graph als echte additive Modellversionen fort.

| Entität | Attribut | Typ | Optional | Regel |
|---|---|---|---:|---|
| `ProductionProject` | `materialEfficiency` | `Int` | ja | neue Projekte 0 bis 10; `nil` aus Altbestand wird als 0 gelesen |
| `ProductionGraphRecord` | `materialFormulaVersion` | `Int` | ja | `1` für Graphformat 3; `nil` für Format 1/2 |

Graphformat 3 speichert zusätzlich `blueprintMaterialEfficiency` und je
Materialkante eine `ProductionMaterialCalculation` mit Basismenge, Runs,
ME, Rohbedarf, Effektivbedarf und Ersparnis. Beim Laden müssen
Projektprovenienz, Kantenwerte, Elternruns, Aktivität, Domainformel und
Persistenzmetadatum übereinstimmen.

Die leichte v7→v8-Migration erfindet keine Graphberechnung. Alte
Format-1-/2-Payloads und alle Benutzer- und SDE-Daten bleiben unverändert
lesbar und gelten bis zur bewussten Neuberechnung als veraltet.

## 19. P16 – Graphformat 4 ohne Schemaänderung

P16 ändert keine SwiftData-Spalte und keine Datenbankschemaversion. Das
vorhandene `ProductionGraphRecord.payload` speichert nun optional das
Graphformat 4 mit:

| Payloadwert | Typ | Bedeutung |
|---|---|---|
| `expansionPolicyVersion` | `Int?` | `1` für Manufacturing-only-Rekursion |
| `recipe.materialEfficiency` | `Int?` | ME-Wert der konkreten Rezeptstufe |
| `recipe.materialEfficiencySource` | Enum? | Projekt-Blueprint oder neutraler Zwischenproduktwert |
| `node.leafReason` | Enum? | kein Herstellungsrezept oder in P18 folgende Reaktion |

Format 4 verlangt die Mengenkopplung:

```text
incomingEdge.materialCalculation.effectiveQuantity
  == intermediate.runCalculation.requestedOutputQuantity
```

Format 1 bis 3 bleiben codier- und lesbar. Ihre neuen optionalen Felder sind
`nil`; sie gelten als veraltet und werden erst nach bewusster Neuerzeugung
ersetzt. `materialFormulaVersion` bleibt für Format 3 und 4 gleich `1`.
Schema v8, Migrationsplan und Backupmanifest 8.0.0 bleiben unverändert.

## 20. P17 – Graphformat 5 ohne Schemaänderung

P17 erweitert ausschließlich das codierte `ProductionGraphRecord.payload`.
Jeder Rezeptknoten kann nun Tech-Stufe, `BlueprintPlanningQuality` und
`InventionStageReference` tragen. Die Qualitätsprovenienz enthält
Blueprint-Type-ID, Herkunft, Art, ME, TE, lizenzierte Runs, optionalen
Decryptor, Regelversion sowie SDE-Build und Inhaltshash.

Graphformat 5 verlangt, dass Regel- und Katalogprovenienz des Knotens mit
der Graphprovenienz übereinstimmen. Reguläre T2-BPCs benötigen zusätzlich
eine gültige Invention-Referenz; historische T2-BPOs dürfen diese Referenz
nicht vortäuschen. Format 1 bis 4 bleiben lesbar und gelten als veraltet.

SwiftData-Schema v8, Migrationsplan, Run-/Materialformelversion 1 und
Backupmanifest 8.0.0 bleiben unverändert.

## 21. P18 – Schema v9 und Graphformat 6

Schema v9 ergänzt additiv `ReactionRuleRecord`. Der Datensatz gehört zu
genau einer SDE-Inhaltsversion und enthält das kanonisch codierte,
versionierte `ReactionRuleProfile`. Projekte und Benutzerdaten werden nicht
verändert. Die v8→v9-Migration, vollständige Legacykette, zweite Öffnung,
Leerstore und Backups 1.0.0 bis 9.0.0 sind geprüft.

Graphformat 6 speichert in der bestehenden Payload zusätzlich:

| Payloadwert | Bedeutung |
|---|---|
| `recipe.reactionKind` | Composite, Hybrid oder Biochemical |
| `recipe.reactorTypeID` | passender Reactor aus dem aktiven Regelprofil |
| `recipe.reactionContext` | neutraler oder vollständig modifizierter Kontext |
| `recipe.reactionTimeCalculation` | Basiszeit, Faktoren und Effektivzeit |
| `edge.reactionMaterialCalculation` | Rohmenge, Faktor, Effektivmenge und Ersparnis |

Format 6 verlangt Expansionsrichtlinie 3, Katalog-/Regelprovenienz,
Reaktions-ME 0 und eine gültige Neuberechnung aller abgeleiteten Werte.
Formate 1 bis 5 bleiben lesbar und veraltet.

## 22. P19 – Graphformat 7 ohne Schemaänderung

P19 erweitert ausschließlich das codierte
`ProductionGraphRecord.payload`. Graphformat 7 verlangt
`ProductionGraphMaterialAggregation` mit Formelversion 1.

| Payloadwert | Bedeutung |
|---|---|
| `materialAggregation.formulaVersion` | aktuell `1` |
| `materialAggregation.lines[].typeID` | stabiler CCP-Aggregationsschlüssel |
| `materialAggregation.lines[].name` | kanonischer Anzeigewert |
| `materialAggregation.lines[].totalQuantity` | überlaufgeprüfte positive `Int64`-Summe |
| `materialAggregation.lines[].occurrences[]` | Blatt-ID, effektive Einzelmenge, Blattgrund und Wurzelpfad |

Die Aggregation zählt nur Materialblätter. Beim Laden wird sie aus Knoten
und Kanten neu berechnet und exakt verglichen. Formate 1 bis 6 bleiben
lesbar, enthalten keine Aggregation und gelten als veraltet.

Es gibt keine neue SwiftData-Spalte, keine Migration und keinen
Defaultwert für Altgraphen. Schema v9, `NexusMigrationPlan` und
Backupmanifest 9.0.0 bleiben unverändert.

## 23. P20 – Schema v10: Lagerorte und manuelle Bestände

Schema v10 ergänzt zwei additive Benutzerdatenmodelle. SDE-, Projekt-,
Graph- und Reaktionsdaten werden nicht verändert.

### `StorageLocationRecord`

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `name` | `String` | nein | getrimmter Anzeigename |
| `normalizedName` | `String` | nein | normalisierter Eindeutigkeitsschlüssel |
| `kindRaw` | `String` | nein | definierter `StorageLocationKind` |
| `notes` | `String` | nein | getrimmt, leer zulässig |
| `isArchived` | `Bool` | nein | reversible Archivierung |
| `createdAt` | `Date` | nein | unveränderter Erstellzeitpunkt |
| `updatedAt` | `Date` | nein | nicht vor `createdAt` |

Normalisiert doppelte Namen sind auch über archivierte Lager hinweg
unzulässig. Lager werden in P20 nicht hart gelöscht.

### `ManualStockRecord`

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `locationID` | `UUID` | nein | vorhandenes Lager |
| `typeID` | `Int64` | nein | positive stabile CCP-Type-ID |
| `stockIdentity` | `String` | nein | eindeutiger Schlüssel aus Lager-ID und Type-ID |
| `itemName` | `String` | nein | beim Speichern belegter Katalogname |
| `quantity` | `Int64` | nein | strikt positiv |
| `catalogBuildNumber` | `Int` | nein | aktiver SDE-Build bei Validierung |
| `catalogContentSHA256` | `String` | nein | aktive Katalogprovenienz |
| `createdAt` | `Date` | nein | unveränderter Erstellzeitpunkt |
| `updatedAt` | `Date` | nein | nicht vor `createdAt` |

Eine erneute Speicherung derselben `(locationID, typeID)`-Kombination
ersetzt die Menge deterministisch und erzeugt keine zweite Position.
Archivierte Lager und ihre Positionen bleiben erhalten, sind jedoch
schreibgeschützt.

Die leichte v9→v10-Migration erfindet keine Lager oder Bestände. Sie erhält
alle vorhandenen Daten und kann anschließend wiederholt geöffnet werden.
Der Backupdienst schreibt Format 10.0.0 und akzeptiert Formate 1.0.0 bis
10.0.0; höhere unbekannte Formate werden abgelehnt.

## 24. P21 – Schema v11: CSV-Importberichte

Schema v11 ergänzt `InventoryImportRecord` additiv. Bestehende Lager,
Bestände und alle übrigen Benutzer- sowie SDE-Daten bleiben unverändert.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Berichtsbezeichner |
| `createdAt` | `Date` | nein | Abschlusszeitpunkt des Schreibvorgangs |
| `sourceFileName` | `String` | nein | bereinigter Dateiname, kein Pfad |
| `sourceSHA256` | `String` | nein | 64-stelliger Kleinbuchstaben-Hash |
| `locationID` | `UUID` | nein | beim Import gültiges aktives Lager |
| `catalogBuildNumber` | `Int` | nein | bei Vorschau und Apply identischer Build |
| `catalogContentSHA256` | `String` | nein | bei Vorschau und Apply identischer Kataloghash |
| `insertedCount` | `Int` | nein | erfolgreich neu geschriebene Positionen |
| `replacedCount` | `Int` | nein | erfolgreich ersetzte Positionen |
| `skippedCount` | `Int` | nein | bewusst übersprungene Konflikte |
| `invalidCount` | `Int` | nein | in der Vorschau abgelehnte Datenzeilen |
| `detailsPayload` | `Data` | nein | versionierter, bereinigter Ergebnisbericht |

CSV-Rohzeilen und vollständige lokale Pfade werden nicht persistiert. Der
Repository-Adapter validiert alle Mutationserwartungen vor dem ersten
Schreibzugriff und speichert Mutationen sowie Bericht mit genau einem
`ModelContext.save()`. Bei Fehlern wird `rollback()` aufgerufen.

Die leichte v10→v11-Migration erfindet keine Berichte und verändert keine
Bestände. Der Backupdienst schreibt Format 11.0.0 und akzeptiert Formate
1.0.0 bis 11.0.0; höhere unbekannte Formate werden abgelehnt.

## 25. P22 – Schema v12: projektbezogene Verfügbarkeitsregeln

Schema v12 ergänzt additiv
`InventoryAvailabilityConfigurationRecord`. Je Projekt ist höchstens ein
Datensatz zulässig; berechnete Verfügbarkeitszahlen werden nicht
persistiert.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `projectID` | `UUID` | nein | eindeutiger Projektbezug |
| `modeRaw` | `String` | nein | alle aktiven, ausgewählte oder keine Lager |
| `includedLocationIDsPayload` | `Data` | nein | kanonisch sortierte UUID-Strings |
| `excludedTypeIDsPayload` | `Data` | nein | kanonisch sortierte positive Type-IDs |
| `capsPayload` | `Data` | nein | kanonisch sortierte nichtnegative Obergrenzen |
| `createdAt` | `Date` | nein | unveränderter Erstellungszeitpunkt |
| `updatedAt` | `Date` | nein | optimistisches Parallelitätsmerkmal |
| `recordVersion` | `Int` | nein | aktuell `1` |

Die Domain verbietet doppelte Regeln, Lagerauswahl außerhalb des
Auswahlmodus sowie gleichzeitigen Ausschluss und Obergrenze derselben
Type-ID. Der Repositoryadapter prüft Projektbestand, Archivstatus und den
erwarteten gespeicherten Änderungszeitpunkt vor dem atomaren Save.

Die leichte v11→v12-Migration erfindet keine Konfiguration und erhält
Projekte, Lager, Bestände und Importberichte. Ein befüllter v11-Store wurde
nach der Migration zweimal geöffnet; ein leerer v12-Store wurde separat
geprüft. Der Backupdienst schreibt Format 12.0.0 und akzeptiert Formate
1.0.0 bis 12.0.0; 13.0.0 wird als unbekannte Zukunftsversion abgelehnt.

## 26. P23 – Schema v13: globale Sicherheitsbestandsregeln

Schema v13 ergänzt additiv `StockPolicyRecord`. Je positiver CCP-Type-ID ist
höchstens eine globale Regel zulässig; Namen und berechnete
Verfügbarkeitswerte werden nicht persistiert.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `typeID` | `Int64` | nein | positiver CCP-Schlüssel, eindeutig |
| `safetyStockQuantity` | `Int64` | nein | nichtnegative harte Schutzmenge |
| `minimumQuantity` | `Int64` | ja | nichtnegative unabhängige Schwelle |
| `warningQuantity` | `Int64` | ja | nichtnegative unabhängige Schwelle |
| `targetQuantity` | `Int64` | ja | nichtnegative unabhängige Schwelle |
| `createdAt` | `Date` | nein | unveränderter Erstellungszeitpunkt |
| `updatedAt` | `Date` | nein | optimistisches Parallelitätsmerkmal |
| `recordVersion` | `Int` | nein | aktuell `1` |

Die leichte v12→v13-Migration erfindet keine Regeln und erhält Projekte,
Graphen, Lager, Bestände, Importe und P22-Konfigurationen. Ein befüllter
v12-Store wurde migriert und erneut geöffnet; ein leerer v13-Store wurde
separat geprüft. Der Backupdienst schreibt Format 13.0.0 und akzeptiert
Formate 1.0.0 bis 13.0.0; 14.0.0 wird als unbekannte Zukunftsversion
abgelehnt.

## 27. P24 – Schema v14: Projektreservierungen

Schema v14 ergänzt additiv `StockReservationRecord`. Reservierungen gelten
global je Projekt und positiver CCP-Type-ID. Berechnete P22-/P23-/P24-
Vorschauergebnisse und Lagerallokationen werden nicht persistiert.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `projectID` | `UUID` | nein | vorhandenes, nicht archiviertes Projekt |
| `typeID` | `Int64` | nein | positive stabile CCP-Type-ID |
| `reservedQuantity` | `Int64` | nein | positive Gesamtbindung |
| `consumedQuantity` | `Int64` | nein | 0 bis Gesamtbindung |
| `priority` | `Int` | nein | 1 bis 3 |
| `expiresAt` | `Date` | ja | informativ, nicht vor Erstellung |
| `statusRaw` | `String` | nein | `reserved`, `partiallyConsumed`, `consumed` oder `released` |
| `createdAt` | `Date` | nein | unveränderter Erstellungszeitpunkt |
| `updatedAt` | `Date` | nein | optimistisches Parallelitätsmerkmal |
| `releasedAt` | `Date` | ja | nur bei Freigabe gesetzt |
| `consumedAt` | `Date` | ja | nur bei vollständigem Verbrauch gesetzt |
| `recordVersion` | `Int` | nein | aktuell `1` |

Je Projekt und Type-ID ist höchstens ein bindender Datensatz zulässig.
`reserved` und `partiallyConsumed` binden
`reservedQuantity - consumedQuantity`; terminale Datensätze bleiben als
Historie erhalten. Das Repository prüft Projektbestand, Archivstatus,
eindeutige aktive Bindungen und den erwarteten gespeicherten Zustand vor
einem atomaren Save.

Die leichte v13→v14-Migration erfindet keine Reservierungen und erhält
Projekte, Graphen, Lager, Bestände, Importe, P22-Konfigurationen und
P23-Regeln. Ein befüllter v13-Store wurde migriert und erneut geöffnet; ein
leerer v14-Store wurde separat geprüft. Der Backupdienst schreibt Format
14.0.0 und akzeptiert Formate 1.0.0 bis 14.0.0; 15.0.0 wird als unbekannte
Zukunftsversion abgelehnt.

## 28. P26 – Schema v15: Build-or-Buy-Entscheidungen

Schema v15 ergänzt additiv `BuildOrBuyDecisionRecord` mit UUID,
Projekt-ID, positiver CCP-Type-ID, Entscheidung, Erstell-/Änderungszeit und
interner Recordversion. Persistiert werden ausschließlich projektbezogene
**Kaufen**-Abweichungen; fehlende Datensätze bedeuten **Bauen**.

Die leichte v14→v15-Migration erhält alle vorhandenen Tabellen und erfindet
keine Entscheidungen. Ein befüllter v14-Store, ein leerer v15-Store und die
zweite Öffnung wurden geprüft. Projektduplikate beginnen bewusst ohne
übernommene Kaufabweichungen. Der Backupdienst schreibt 15.0.0 und
akzeptiert die Versionen 1.0.0 bis 15.0.0.

## 29. P27 – Schema v16: Preisprofile und manuelle Preise

Schema v16 ergänzt additiv `PriceProfileRecord` und `ManualPriceRecord`.
Profile besitzen UUID, normalisierten eindeutigen Namen, Währung ISK,
Aktivstatus sowie Erstellungs- und Änderungszeit. Höchstens ein Profil ist
aktiv.

Manuelle Preise sind über `(profileID, typeID)` eindeutig. Der Betrag wird
exakt als positive `Int64`-Anzahl von Hundertstel ISK gespeichert. Jeder
Preis trägt aktive SDE-Version, Quelle `manual`, einen inklusiven
Gültigkeitsbeginn und ein optionales exklusives Gültigkeitsende. Namen sind
keine fachlichen Itemschlüssel.

Die leichte v15→v16-Migration erhält alle bisherigen Tabellen und legt keine
erfundenen Profile oder Preise an. Wiederöffnung, Kaskadenlöschung, Leerstore
und v15-Bestandsschutz sind getestet. Der Backupdienst schreibt 16.0.0,
akzeptiert 1.0.0 bis 16.0.0 und lehnt 17.0.0 als unbekannte Zukunftsversion
ab.

## 30. P28 – Schema v17: CSV-Preisimportberichte

Schema v17 ergänzt additiv `PriceImportRecord` mit UUID, Profil-ID,
Importzeit, bereinigtem Dateinamen, SHA-256, versioniertem JSON-Bericht und
Payloadversion. Die Rohdatei und ihr lokaler Pfad werden nicht gespeichert.

Preismutationen verwenden weiterhin `ManualPriceRecord`; importierte Werte
tragen `sourceRaw = csv`. Ein bestätigter Import speichert alle Einfügungen
und Ersetzungen zusammen mit dem Bericht in einer Transaktion. Das Löschen
eines Profils entfernt Preise und zugehörige Berichte.

Die leichte v16→v17-Migration erhält Profile, Preise und alle vorherigen
Fachdaten und erfindet keine Berichte. Der Backupdienst schreibt 17.0.0,
akzeptiert 1.0.0 bis 17.0.0 und lehnt 18.0.0 ab.

## 31. P29 – Schema v18: Projektwirtschaftlichkeitsbasis

Schema v18 ergänzt additiv `ProjectEconomicsConfigurationRecord` mit UUID,
eindeutiger Projekt-ID, Preisprofil-ID, manuellen Jobkosten in
ISK-Hundertsteln sowie Erstellungs- und Änderungszeit. Je Projekt ist
höchstens eine Konfiguration zulässig.

Persistiert werden keine berechneten Kosten-, Gewinn- oder ROI-Werte.
Diese entstehen reproduzierbar aus aktuellem Build-or-Buy-Plan und den
zum Berechnungsstichtag gültigen Preisen. Das Repository prüft Projekt und
Preisprofil sowie den erwarteten Änderungszeitpunkt vor dem Schreiben.

Die leichte v17→v18-Migration erhält Preisprofile, Preisimportberichte und
alle vorherigen Fachdaten und erfindet keine Konfiguration. Leerstore,
befüllter v17-Store, Wiederöffnung und Stale-State sind getestet. Der
Backupdienst schreibt 18.0.0 und akzeptiert 1.0.0 bis 18.0.0.

## 32. P30 – Schema v19: Einkaufsmengen-Overrides

Schema v19 ergänzt additiv `ShoppingQuantityOverrideRecord`.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `projectID` | `UUID` | nein | vorhandenes Projekt |
| `typeID` | `Int64` | nein | positive stabile CCP-Type-ID |
| `quantity` | `Int64` | nein | nichtnegative Zielkaufmenge |
| `createdAt` | `Date` | nein | unveränderter Erstellungszeitpunkt |
| `updatedAt` | `Date` | nein | optimistisches Parallelitätsmerkmal |

Je Projekt und Type-ID ist höchstens ein Override zulässig. Persistiert
werden nur Abweichungen von der jeweils aktuell berechneten Fehlmenge;
Namen, Quellen, Preise und berechnete Listen bleiben reproduzierbare Werte.

Die leichte v18→v19-Migration erhält Wirtschaftlichkeitsbasis, Preise und
alle früheren Fachdaten und erfindet keine Overrides. Befüllter v18-Store,
Leerstand, Wiederöffnung, Stale-State und leeres Duplikatprojekt sind
getestet. Der Backupdienst schreibt 19.0.0 und akzeptiert 1.0.0 bis 19.0.0.

## 33. P31 – Schema v20: Projektbezogener Kauf-Fortschritt

Schema v20 ergänzt additiv `PurchaseProgressRecord`.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler lokaler Schlüssel, eindeutig |
| `projectID` | `UUID` | nein | vorhandenes Projekt |
| `typeID` | `Int64` | nein | positive stabile CCP-Type-ID |
| `purchasedQuantity` | `Int64` | nein | positive zugeordnete Kaufmenge |
| `createdAt` | `Date` | nein | unveränderter Erstellungszeitpunkt |
| `updatedAt` | `Date` | nein | optimistisches Parallelitätsmerkmal |

Je Projekt und Type-ID ist höchstens ein Fortschrittsdatensatz zulässig.
Null wird durch einen fehlenden Datensatz dargestellt. Der Fortschritt
verändert keine Bestands-, Schutz- oder Reservierungsdaten. Sinkt ein
aktuelles Einkaufsziel, bleibt eine höhere frühere Zuordnung erhalten und
wird fachlich höchstens bis zum aktuellen Ziel angerechnet.

Die leichte v19→v20-Migration erhält insbesondere P30-Overrides und erfindet
keinen Kauf-Fortschritt. Befüllter v19-Store, Wiederöffnung, Scope-Isolation
und Stale-State sind getestet. Der Backupdienst schreibt 20.0.0, akzeptiert
1.0.0 bis 20.0.0 und lehnt 21.0.0 ab.

## 34. P41 – Schema v21: ESI-Marktpreisprovenienz

Schema v21 ergänzt additiv `MarketPriceProvenanceRecord`. Der Datensatz ist
über `priceID` einem bestätigten Preis zugeordnet und speichert Profil- und
Type-ID, Region, optionale Location und Anzeigename, angeforderte/erfüllte
Menge, verwendete Orderanzahl, Gesamtpreis in Hundertstel-ISK,
Orderabruf-/Prüfzeit, optionalen Cacheablauf, Quellpfad, Erstellungszeit und
Recordversion.

Die eigentlichen Preise bleiben `ManualPriceRecord` und tragen für diesen
Schreibweg `sourceRaw = esi_market`. Orderbücher und berechnete
Wirtschaftlichkeitswerte werden nicht in SwiftData gespiegelt. Ein bestätigter
Marktimport schreibt Preis und Provenienz atomar; eine spätere manuelle oder
CSV-Ersetzung entfernt die Marktprovenienz in derselben Transaktion.

Die leichte v20→v21-Migration erhält alle bisherigen Benutzerdaten und
erfindet keine Marktpreise oder Herkunft. Befüllter v20-Store, Leerstand,
Wiederöffnung, atomarer Apply und manuelle Ersetzung sind getestet. Der
Backupdienst schrieb in diesem historischen Stand 21.0.0.

## 35. P42 – Schema v22: bestätigte Wallet-Projektzuordnungen

Schema v22 ergänzt additiv `WalletProjectAssignmentRecord`. Der Datensatz
bindet eine charakterbezogene Transaktions- oder Journalquelle nach
ausdrücklicher Bestätigung an genau ein Projekt und speichert Quell-ID,
Richtung, zugeordneten Betrag beziehungsweise Menge, Walletrevision,
Erstellungszeit und Recordversion. Mehrere Teilzuordnungen dürfen zusammen
den belegten Quellwert nicht überschreiten.

Kontostand, Journal und Transaktionen verbleiben im getrennten privaten
Wallet-Dateisnapshot. Planwerte aus P29 werden weder ersetzt noch verändert;
Istkosten und realisierte Erlöse werden reproduzierbar aus bestätigten
Zuordnungen berechnet.

Die leichte v21→v22-Migration erhält alle bisherigen Benutzerdaten und
erfindet keine Zuordnung. Befüllter v21-Store, Leerstore, Wiederöffnung,
Überzuordnung, Stale-State und Trennkompensation sind getestet. Der
Backupdienst schreibt 22.0.0 und akzeptiert 1.0.0 bis 22.0.0.

## 36. P50 – Schema v23: bestätigte ESI-Asset-Auswahl

Schema v23 ergänzt additiv `ESIAssetAvailabilitySelectionRecord`.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `id` | `UUID` | nein | stabiler eindeutiger Datensatzschlüssel |
| `projectID` | `UUID` | nein | vorhandenes Produktionsprojekt |
| `characterID` | `Int64` | nein | positive CCP-Charakter-ID |
| `sourceRevision` | `UUID` | nein | exakte Revision des persönlichen P40-Snapshots |
| `linesJSON` | `Data` | nein | versionierte positive Type-/Location-/Mengenzeilen |
| `createdAt` | `Date` | nein | unveränderter Erstellungszeitpunkt |
| `updatedAt` | `Date` | nein | optimistisches Parallelitätsmerkmal |
| `recordVersion` | `Int` | nein | aktuell `1` |

Je Projekt wird fachlich höchstens eine Auswahl akzeptiert. Namen werden
nicht persistiert. Die Auswahl verändert weder den P40-Dateisnapshot noch
manuelle/CSV-Bestände; sie ergänzt die Verfügbarkeit erst im
Application-Service. Snapshotrevision, Lagerzustand und bisherige Auswahl
werden vor dem Schreiben erneut geprüft.

Die leichte v22→v23-Migration erhält alle bisherigen Benutzerdaten und
erfindet keine Asset-Auswahl. Leerstand, Rundlauf, Wiederöffnung,
Löschen/Wiederherstellen, Altstoremigration und Trennkompensation sind
getestet. Der Backupdienst schrieb in diesem historischen Stand 23.0.0.

## 37. P51 – Schema v24: zweckgebundene ESI-Scopemetadaten

Schema v24 ergänzt additiv `EVEAccountAuthorizationRecord`.

| Attribut | Typ | Optional | Regel |
|---|---|---:|---|
| `characterID` | `Int64` | nein | eindeutige stabile CCP-Charakter-ID |
| `scopesJSON` | `Data` | nein | normalisierte Liste ausdrücklich angeforderter Scopes |
| `authorizedAt` | `Date` | nein | Zeitpunkt der erfolgreichen Autorisierung |
| `recordVersion` | `Int` | nein | aktuell `1` |

Der Datensatz enthält weder Access- noch Refresh-Token. Er wird gemeinsam mit
dem Charakterkonto gespeichert und beim Trennen entfernt. Ein bestehendes
Konto ohne Datensatz gilt als „Berechtigung nicht lokal nachgewiesen“; die
Migration v23→v24 erfindet deshalb keine Scopes. P40 verwendet exakt drei
Produktionsscopes. Erst eine erfolgreiche ausdrückliche Wallet-
Neuautorisierung speichert zusätzlich den vierten Walletscope.

Migration, Leerstore, Rundlauf, Wiederöffnung, Abbruch vor Schreiben,
Kompensation, Trennen sowie Backup/Restore sind getestet. Der Backupdienst
schreibt 24.0.0 und akzeptiert 1.0.0 bis 24.0.0.
