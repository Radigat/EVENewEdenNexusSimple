# Implementation Roadmap

Stand: 2026-07-28 · PLAN-005/P53 abgeschlossen

## Leitlinie

Die Roadmap priorisiert einen lokal auf dem Eigentümer-Mac nutzbaren
Produktions-/Inventionsplaner. Bestehende Funktionen bleiben erhalten; P26
bis P37 und REL-001 sind abgeschlossen. Lokale Fach- und Qualitätsarbeit
kann auf ausdrücklichen Auftrag fortgesetzt werden. Eine öffentliche
Apple-Distribution ist kein aktuelles Gate. Details:
[Tokenarmer Kern-MVP](LEAN_MVP_PLAN.md).

P38 bis P42 sind technisch umgesetzt. Die P43-/P44-Nutzenreviews stellten
beide Gesamtumsetzungen zurück. PLAN-005 schließt vor jedem weiteren
Zukunftsfeature die beim Funktionsaudit belegten Restbefunde in der Folge
**P50 → P51 → P52 → P53 → P54**. P49 bleibt bewusst unbelegt. P50 und P51
sind abgeschlossen; P52 wurde wegen der getrennt offenen
P42-Eigentümergates mit dokumentiertem Blocker beendet. P53 ist nach
bestätigter recoverbarer Archivierung und vollständiger Kanonprüfung
abgeschlossen; P54 bleibt gesondert commit-freigabepflichtig.

## Stufe A – Produktionsplaner MVP

### A0 – Steuerung und Fundament

P00 bis P07 haben Cockpit, Regeln, Schichten, Schema v1, Fehlergrenze,
Testfundament, Backup und SDE-Staging umgesetzt. P08 hat Schema v2,
fachliches SDE-Mapping, Referenzklassifizierung und versionierte atomare
Aktivierung ergänzt. P09 hat Schema v3 und den deterministischen, begrenzten
Item-/Blueprintkatalog umgesetzt und mit einem offiziellen Realstand geprüft.

AUD-SDE-001 hat danach den vollständigen CCP-SDE-Onlineauftrag geprüft:
Download, HTTP-Cache, ZIP-Sicherheit, Schema-Changelog, Update-UI,
Updateprotokoll und rechtliche Kennzeichnung fehlten. P07A hat
Metadatenprüfung, HTTP-Cache, Schema-Gate, Schema v4 und die technische
Compliancekonfiguration umgesetzt. P07B hat Download, Archivschutz,
isolierten Stagingstore, Backup, Aktivierung, Rollback und Phasenjournal
technisch ergänzt. Die Eigentümerentscheidung liegt vor und der aktuelle
Build 3444265 wurde real erfolgreich installiert und wieder geöffnet.
Blockweises Mapping und Persistieren senkten den maximalen RSS gegenüber der
Snapshot-Baseline um rund 61 % auf 948–952 MB. P07C ist technisch umgesetzt.
PLAN-001 ordnete danach zwei technische Zwischenpakete ein: P09A schuf die
erste reviewbare Git-Baseline; P09B ergänzte das eigenständige Xcode-Projekt,
gemeinsame Schemes und den zuvor fehlenden manuellen P07C-GUI-/
Accessibility-Nachweis. P10 ergänzt den deterministischen
Fertigungs-/Reaktionsresolver, die aktive Versionsisolation und die sichere
itemgenaue Ablehnung unvollständiger Referenzen. P11 hat anschließend den
vollständigen lokalen Projektlebenszyklus und die SwiftData-freie
Projektansicht umgesetzt.

### A1 – Statische Daten

P07 validiert und staged die vier technischen JSONL-Pflichtdatensätze. P08
speichert Items, Blueprints und Aktivitäten versioniert. P09 erschließt den
Katalog.

Ergänzende Reihenfolge:

1. **P07A – erledigt:** offizieller Build-/Schema-Metadatencheck,
   HTTP-Caching und Compliancegrundlage,
2. **P07B – erledigt:** technischer und aktueller Real-SDE-Pfad,
   blockweises Low-Memory-Mapping und sichere Aktivierung abgenommen,
3. **P07C – erledigt:** produktive Updatecheck-/Installationsverdrahtung,
   SDE-Einstellungen, 24-h-Automation, Protokoll, Diagnoseexport und
   rechtliche Hinweise einschließlich manueller GUI-Abnahme,
4. **P09A – erledigt:** erster geprüfter Commit als Repository-Baseline,
5. **P09B – erledigt:** eigenständiges Xcode-Projekt, gemeinsame Schemes,
   Xcode-/SwiftPM-Nachweise und P07C-Accessibility-Abnahme,
6. **P10 – erledigt:** verwendbare Rezepte deterministisch auflösen und
   unvollständige Referenzen itemgenau ablehnen,
7. **P11 – erledigt:** Projekte anlegen, bearbeiten, filtern, Status ändern,
   duplizieren, reversibel archivieren und wiederherstellen,
8. **P12 – erledigt:** kataloggebundene Produkt-, Aktivitäts-, Blueprint- und
   Mengenauswahl mit Schema-v5-Bestandsschutz,
9. **P13 – erledigt:** erklärbarer, persistierter Produktionsgraph mit
   erster Rezeptstufe und Schema-v6-Bestandsschutz,
10. **P14 – erledigt:** integer-sichere Runs, tatsächliche Ausgabe,
    Überschuss, Graphformat 2 und Schema-v7-Bestandsschutz,
11. **P15 – erledigt:** referenzgeprüfte Blueprint-ME,
    Materialbedarfsaufschlüsselung, Graphformat 3 und
    Schema-v8-Bestandsschutz,
12. **P16 – erledigt:** rekursive Manufacturing-only-T1-Ketten,
    Graphformat 4, ME-Provenienz je Stufe und begründete Blätter ohne neue
    Schemamigration.
13. **P17 – erledigt:** kataloggebundene T2-Klassifikation,
    Blueprintqualität, Invention-/Decryptorregeln, T3-Abgrenzung und
    Graphformat 5 ohne neue Schemamigration.
14. **P18 – erledigt:** SDE-gebundene Reaktionsregeln, neutrale und
    modifizierte Kontexte, rekursive Reaktionsstufen, Graphformat 6 und
    additives Schema v9.
15. **P19 – erledigt:** Type-ID-basierte Materialaggregation,
    Vorkommens-/Pfadnachweise, Graphformat 7, Summenüberlaufschutz sowie
    geladene Tiefe-/Knoten-/Beziehungskontrollen ohne Schemamigration.

P11 schließt den `ProjectsView`-Anteil von `OFF-008` und `KI-011`. P12 ist
einschließlich seiner Voraussetzung OFF-026 umgesetzt und reviewed. P13
liefert die Graphbasis und erste Rezeptstufe; P14 ergänzt Runs und Output,
P15 die Material-Efficiency-Berechnung und P16 die rekursive
Manufacturing-only-T1-Kette.
P17 bis P19 sind umgesetzt und abgenommen. P18 erweitert den
Industrie-Regelvertrag um rekursive Reaktionsstufen und verifizierte
Produktionskontexte. P19 ergänzt die kontrollierte Aggregation und
Graphschutzgrenzen.
REL-001 hat den zeitabhängigen technischen CCP-Recheck abgeschlossen. Die
noch persönlichen beziehungsweise Apple-spezifischen Veröffentlichungspunkte
sind nicht für den lokalen Betrieb erforderlich und wurden P48 zugeordnet.

### A2 – Produktionskern

P11 hat den Projektlebenszyklus, P12 die Zielproduktauswahl, P13 die
Graphbasis mit erster Rezeptstufe, P14 Runs sowie Output, P15 Blueprint-ME
und P16 die T1-Rekursion umgesetzt. P17 liefert nun Tech-Klassifikation,
Blueprint-Herkunft, T2-/T3-Inventionsabgrenzung und
T2-Manufacturing-Ketten. P18 liefert Reaktionsstufen mit neutralem oder
verifiziert modifiziertem Kontext. P19 liefert Zusammenführung und
Diagnose. Der Produktionskern P11 bis P19 ist damit implementiert. P20
ergänzt Schema v10, lokale Lager und manuelle Bestände; P21 ergänzt den
sicheren CSV-Import mit Vorschau, Bestätigung, atomarem Bericht und Schema
v11. P22 ergänzt projektbezogene physische Verfügbarkeit nach Lager-,
Material- und Mengenfreigaben mit Preview-before-write und Schema v12.
P23 ergänzt globale Sicherheitsbestandsregeln, unabhängige Mindest-, Warn-
und Zielmeldungen sowie Schema v13.
P24 ergänzt globale Projekt-/Type-ID-Reservierungen mit explizitem
Lebenszyklus, atomarer Vorschau-/Bestätigungsgrenze, Archivschutz und
Schema v14.
P25 ergänzt berechnete Reservierungskonflikte und bestätigte atomare
Reduktion/Freigabe ohne neue Schemastufe.

### A3 – Schlanker Produktionsentscheidungsplan

P20 bis P26 sind erledigt und liefern Lager, manuelle/importierte Bestände,
projektbezogene Verfügbarkeit/Ausschlüsse, Schutz, Reservierungen und
Konfliktauflösung sowie die für den Kern benötigte manuelle
Bauen/Kaufen-Entscheidung, Produktions-/Inventionsjobs und Fehlmengen.

### A4 – Integrierter Kernworkflow

P32 verbindet nun Produkt, Graph, Lager, Bauen/Kaufen, Produktionsjobs,
Inventionsjobs und eine einfache kopierbare Bedarfsliste. P27 ergänzt
exakte manuelle ISK-Preisprofile und Schema v16; P28 den kontrollierten
CSV-Preisimport und Schema v17. P29 ergänzt Cash-/wirtschaftliche Kosten,
Erlös, Gewinn, Marge, ROI, Break-even und Schema v18. P30 ergänzt
Type-ID-Aggregation, persistente Zielkaufmengen und Schema v19. P31 ergänzt
projektübergreifende Beschaffung, Teilkäufe, Text-/CSV-Export und Schema v20.

### A5 – Interne Kernabnahme

P37 hat je ein T1- und T2-/Inventionsprojekt end-to-end mit Lagerbestand,
Kaufentscheidung und Store-Wiederöffnung geprüft. PLAN-002 ist damit als
interner Kernstand abgeschlossen, nicht als Release Candidate. P27 ist
danach erledigt; P28 bis P34 sind ebenfalls abgenommen. P35 ist einschließlich
OFF-030 mit nativen Xcode-UI-Tests abgenommen. P36 ist vollständig:
OFF-006 deckt Vor-Migrations-Sicherung, Recovery-UI und den isolierten
Restore-/Migrationsdrill ab; OFF-024 ergänzt fünf reale
SIGKILL-/Neustart-Grenzen im SDE-Ablauf. REL-001 hat anschließend den
aktuellen technischen Compliancebefund und OFF-031 abgeschlossen. Damit ist
der lokale Betriebsstand nicht durch öffentliche Distributionsthemen
blockiert.

### A6 – Lokaler Betriebsstand

PLAN-003 setzt die lokale Eigennutzung als verbindliches Betriebsziel.
Unsigned beziehungsweise ad hoc signierte lokale Builds, lokale Bundle-ID
und fehlende App-Store-Metadaten sind für diesen Zielbetrieb keine Mängel.
Lokale Starts, Datenintegrität, Backups, Tests und nachvollziehbare Fehler
bleiben weiterhin verbindlich.

### A7 – Produktionsbuch und realer Verkaufserfolg

PLAN-006 ordnet den neuen, durch die Eigentümer-Arbeitsmappe belegten Bedarf:

1. P57 – Produktionschargen und Persistenz,
2. P58 – Kostenaufschlüsselung und Verkaufspreisvorschläge,
3. P59 – bestätigte Wallet-/Verkaufszuordnung und Realgewinn,
4. P60 – Produktionsanalyse und Gesamtwallet.

Die vorhandenen P29-/P42-/P55-Grundlagen werden wiederverwendet. Die frühere
P42-Oberfläche wird nicht unverändert reaktiviert.

P57 und P58 sind einschließlich Eigentümergates abgeschlossen. P59 ist
technisch umgesetzt; OFF-061 verlangt noch Teil-/Vollzuordnung und Neustart im
lokalen Eigentümerbetrieb. P60 beginnt erst danach und nur auf ausdrücklichen
Auftrag.

### A8 – Metenox-Wirtschaftlichkeit

P61 ergänzt nach erneutem offiziellen Regel-/SDE-Preflight einen getrennten
Mondrechner. Unbelegte Fuel-/Reprocessingwerte bleiben bis dahin offene,
versionierte Annahmen.

## Spätere Stufen

- **Stufe B:** P38 → P39 → P40 – SSO, ESI-Basis und persönliche
  Live-Assets/Blueprints/Jobs. Abgeschlossen.
- **Stufe C:** P41 → P42 – Live-Märkte, Wallet und reale Finanzen.
  Abgeschlossen.
- **Stufe D:** P43 → P44 – beide Nutzenreviews abgeschlossen und
  vollständige Umsetzungen zurückgestellt; Reaktivierung nur bei
  dokumentiertem Praxisbedarf.
- **Stufe E:** P45 → P46 → P47 – Corporation, optionale Cloud/
  Mehrbenutzerfunktionen und erklärbare Optimierung/KI.
- **Stufe F:** P48 – als letztes optionales Paket Mac App Store oder
  öffentliche Direktverteilung entscheiden und dann Signing,
  Store-Metadaten, Hardened Runtime, Archivierung, Notarisierung und
  Distributionsabnahme umsetzen.

Nach P40, P42 und P44 erfolgt jeweils ein Nutzen-/Stopreview. Ein späterer
Abschnitt wird nur begonnen, wenn der Projekteigentümer ihn ausdrücklich
aktiviert und alle benötigten Vorgänger abgenommen sind.

Details und Abhängigkeiten stehen im [Prompt-Register](Prompts/README.md).
