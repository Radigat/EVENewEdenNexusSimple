# SDE-Import und Staging

Stand: 2026-07-23 · Paketformat 1 · erweitert durch P08/P09 und
AUD-SDE-001

## Zweck und Grenze

P07 prüft einen lokal entpackten, offiziellen EVE Static Data Export im JSON-Lines-Format und veröffentlicht die vier für den nächsten Schritt benötigten Dateien als validiertes `.nensde`-Stagingpaket.

P08 liest dieses Paket erneut, führt das fachliche Feldmapping aus und kann den
vollständig validierten Stand als Schema-v2-Stammdaten aktivieren.
Die Katalogsuche ist seit P09 implementiert; die fachliche Rezeptauflösung
folgt P10.

## Offizielle Quelle

- SDE-Übersicht: `https://developers.eveonline.com/static-data`
- Automatisierung und Formate: `https://developers.eveonline.com/docs/services/static-data/`
- Lizenz: `https://developers.eveonline.com/license-agreement`
- Buildbezogene JSONL-URL:
  `https://developers.eveonline.com/static-data/tranquility/eve-online-static-data-<build>-jsonl.zip`

P07 verwendet JSON Lines, weil jede Zeile unabhängig geprüft und große Dateien
in festen Blöcken verarbeitet werden können. YAML, Netzwerkdownload,
HTTP-Caching und ZIP-Extraktion sind im aktuellen Code noch nicht enthalten.
Sie sind nach dem
[CCP-SDE-Soll–Ist-Audit](SDE_CCP_INTEGRATION_AUDIT.md) verbindlich auf P07A
bis P07C verteilt und müssen vor der MVP-Releaseabnahme abgeschlossen werden.

Die CCP-Automatisierungsdokumentation beschreibt Buildnummer, ETag und `Last-Modified`, veröffentlicht dort aber keine verbindliche kryptografische Archivprüfsumme. P07 berechnet deshalb lokale SHA-256-Werte. Sie binden die geprüfte Vorschau an das spätere Staging, sind jedoch keine Behauptung über eine offizielle Signatur oder Herkunftsauthentizität.

## Eingabe

Der Aufrufer übergibt:

- ein reales, nicht symbolisch verlinktes Quellverzeichnis,
- eine positive Tranquility-Buildnummer,
- optional einen `Sendable`-Fortschrittempfänger.

Im Quellverzeichnis sind genau diese Pflichtdateien erforderlich:

```text
categories.jsonl
groups.jsonl
types.jsonl
blueprints.jsonl
```

Weitere Quelldateien werden nicht kopiert. Produktive oder echte SDE-Daten werden nicht im Repository gespeichert.

## Prüfregeln

`JSONLinesSDEImportService` liest jede Datei blockweise. Die vollständige JSONL-Datei wird nicht materialisiert. Für jede Zeile gelten:

- valides UTF-8,
- keine Leerzeile,
- konfigurierte maximale Zeilenlänge,
- valides JSON,
- Objekt als JSON-Wurzel,
- vorhandener nichtnegativer ganzzahliger `_key`,
- eindeutiger `_key` innerhalb derselben Datei.

Leere Dateien, fehlende oder nicht reguläre Dateien und symbolische Links werden abgelehnt. Die Verarbeitung reagiert auf Task-Abbruch und veröffentlicht danach kein Paket.

Die read-only Vorschau enthält je Datei Anzahl, Bytezahl und SHA-256. Zusätzlich bindet ein kanonischer Gesamt-SHA-256 Buildnummer, feste Datensatzreihenfolge und alle Dateibeschreibungen.

## Stagingablauf

```text
lokale JSONL-Quelle
        │
        ▼
read-only Vorschau und SHA-256
        │
        ▼
privates .partial-Verzeichnis
        │
        ├── nur Pflichtdateien kopieren
        ├── Kopien vollständig erneut prüfen
        └── Snapshot mit Vorschau vergleichen
        │
        ▼
manifest.json schreiben
        │
        ▼
atomar zu .nensde veröffentlichen
```

Ändert sich die Quelle zwischen Vorschau und Staging, stimmt der erneut berechnete Snapshot nicht überein. Das partielle Paket wird entfernt und kein finales Paket veröffentlicht.

## Paketformat 1

```text
NewEdenNexus-SDE-<build>-<UUID>.nensde/
├── manifest.json
├── categories.jsonl
├── groups.jsonl
├── types.jsonl
└── blueprints.jsonl
```

Manifest:

- Formatkennung `com.newedennexus.sde-staging`,
- Formatversion `1`,
- Paket-ID und Erstellungszeit,
- Buildnummer und Quellenformat,
- offizielle Archiv- und Lizenz-URL,
- Datensatzbeschreibungen,
- kanonischer Gesamt-SHA-256.

Das Paketverzeichnis erhält lokale Rechte `0700`, die Dateien `0600`. Erfolgreiche Pakete werden nicht automatisch gelöscht.

## Schichten und Fehler

`NewEdenNexusApplication` definiert `SDEImporting`, Datentransfertypen, Fortschritt und strukturierte Fehler, ohne CryptoKit oder konkrete Dateiverarbeitung zu importieren.

`NewEdenNexusInfrastructure` implementiert den JSONL-Dateiadapter und SHA-256. Die zentrale sichere Fehlergrenze verwendet:

- `NEN-SDE-001` für die Prüfung,
- `NEN-SDE-002` für das Staging.

Sichere Fehler- und Diagnosetexte enthalten keine lokalen Vollpfade, JSON-Zeilen, Itemnamen oder Blueprintinhalte.

## Verifikation

Das versionierte Testpaket unter `Tests/NewEdenNexusTestSupport/Fixtures/SDE/v1/` ist ausdrücklich synthetisch. Es enthält keine EVE-Spieldaten.

Automatisiert geprüft werden insbesondere:

- feste Counts und SHA-256,
- deterministische Wiederholung,
- vollständiges Manifest, Inhalt und Dateirechte,
- atomare Veröffentlichung ohne `.partial`-Rest,
- fehlende, leere, fehlerhafte und symbolisch verlinkte Eingaben,
- UTF-8, JSON-Wurzel, Zeilengröße und sämtliche `_key`-Regeln,
- Quellenänderung nach Vorschau,
- vorhandenes Zielpaket,
- Abbruch ohne Veröffentlichung.

## Fachliches Mapping und Aktivierung ab P08

`JSONLinesSDECatalogMapper` prüft Manifest, Dateibeschreibungen und
Gesamt-SHA erneut, liest alle vier Dateien blockweise und mappt Kategorien,
Gruppen, Typen, Blueprintdefinitionen, Aktivitäten, Materialien und Produkte.

Vor dem ersten Store-Schreibzugriff werden Pflichtfelder, Wertebereiche,
Eindeutigkeit und Referenzen validiert. Gültige externe IDs und
Aktivitätszeiten dürfen `0` sein. Ein Aktivierungs-Repository speichert neue
Stände unter dem Inhalts-SHA, erhält ältere Stände und wechselt den Aktivmarker
in demselben Save.

Der offizielle Build 3424810 wurde lokal end-to-end geprüft. Seine vier
Dateien umfassen 59.478 JSONL-Sätze. Das Mapping ergab 19.137 Aktivitäten,
36.499 Materialzeilen und 6.329 Produktzeilen. 21 Material-/Produktreferenzen
verweisen auf Typ-IDs, die im selben offiziellen `types.jsonl` fehlen. Diese
Zeilen bleiben erhalten und werden mit `typeIsResolved == false` sowie einem
Versionszähler ausgewiesen; es werden keine Ersatzitems erfunden.

## Folgearbeiten

- P07A: offizielle Build- und Schemametadaten, HTTP-Cache,
  Compliancekonfiguration und Schema-v4-Prüfstatus – **erledigt**,
- P07B: offizieller Download, sichere ZIP-Extraktion, isolierter Importstore,
  Crash-Recovery, Rotation und Updateprotokoll,
- P07C: SDE-Einstellungen, 24-Stunden-Automation, Status-/Fortschrittsanzeige,
  Diagnoseexport und rechtliche Hinweise,
- P10: Rezept-, Aktivitäts- und Reaktionsauflösung – **erledigt**,
- P10: nicht aufgelöste Typreferenzen itemgenau ablehnen – **erledigt**,
- P17: T2 aus vorhandenen Invention-/Manufacturingdaten ohne zusätzlichen
  Blindimport – **erledigt**,
- P18: minimale Facility-, Reactor-, Rig- und Reaction-Dogmadaten für
  verifizierte Reaktionskontexte – **erledigt**,
- P27/P35/P39–P44: weitere SDE-Datensätze ausschließlich nach
  dokumentiertem Fachbedarf ergänzen; kein Blindimport.

Die fachlichen Mindestfelder und Abschlussgates für P17/P18 stehen in
[Industrie-Regelgrundlage](INDUSTRY_RULES_FOUNDATION.md).

Der zuletzt real geprüfte Stand `3444265` ist ein isolierter Testnachweis,
keine Aktualitätsgarantie für künftige Releases und kein produktiver
Benutzerstore. P07B importierte ihn sicher; P10 öffnete ihn erneut, löste
Fertigung und Reaktion auf und blockierte alle 21 tatsächlichen
Referenzlücken itemgenau. P18 importierte daraus zusätzlich 20 relevante
Typ-Dogma-, sechs Attribut- und acht Effektdefinitionen und bestätigte alle
drei Reaktionsarten. Details:
[SDE-Aktualitätsprüfung](SDE_UPDATE_CHECK.md) und
[Rezeptauflösung](RECIPE_RESOLUTION.md).
