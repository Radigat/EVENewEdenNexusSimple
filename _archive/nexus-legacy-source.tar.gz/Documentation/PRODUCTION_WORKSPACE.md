# Integrierter Produktionsworkspace

Stand: 2026-07-29 · P32/P52/P55/P56

## Zweck

Der Produktionsworkspace verbindet den gespeicherten Projektstand mit dem
Produktionsgraphen, dem P26-Plan, lokalen Beständen, Sicherheitsbeständen,
Reservierungen und berechneten Reservierungskonflikten. Er führt keine
eigene Mengenberechnung durch.

## Bedienablauf

1. Produktionsprojekt anlegen oder öffnen.
2. Produktionsworkspace über den Projektbefehl öffnen.
3. Fehlenden oder veralteten Graphen erzeugen.
4. Über die horizontale Leiste zwischen **Übersicht**, **Bauen / Kaufen**,
   **Lager & Einkauf**, **Budget**, **Materialsumme** und
   **Produktionsstufen** wechseln.
5. verfügbare Lager-, Schutz- und Reservierungsregeln prüfen.
6. Produktionsart filtern, bei Bedarf **Alles bauen** wählen oder eine
   Gruppe wie **Composite Reactions** auf **Bauen** beziehungsweise
   **Kaufen** setzen und nur gewünschte Einzelabweichungen aufklappen.
7. schreibfreie Vorschau berechnen.
8. Produktionsjobs, Inventionsjobs und positive Fehlmengen prüfen.
9. Entscheidungen ausdrücklich bestätigen oder den Vorgang abbrechen.
10. Im Bereich **Budget** Preissatz, Logistik- und Produktionskosten
    festlegen und die Budgetvorschau bestätigen.
11. Fehlmengen über **Fehlmengen kopieren** als `Name<Tab>Menge` übernehmen.

## Zustände und Schutz

- Ohne Graph wird ein Erzeugen-Zustand gezeigt.
- Ein veralteter Graph verbirgt die abgeleitete Planung.
- Während Laden, Vorschau und Speicherung werden konkurrierende Aktionen
  gesperrt.
- Eine geänderte, aber noch nicht berechnete Entscheidung sperrt Speichern
  und Kopieren.
- Projekt- oder graphfremde Vorschauen werden nicht angezeigt.
- Stale-State, Abbruch und Fehler schreiben keine Entscheidung.
- Gespeichert werden nur bestätigte projektbezogene Kaufabweichungen.
- Lagerbestände, Sicherheitsbestände und Reservierungen werden im Workspace
  niemals verändert.

## Darstellung

Das Graphfenster öffnet mit 1.080 pt Mindest- und 1.360 pt Idealbreite. Die
Bereichsleiste bleibt oberhalb des scrollenden Inhalts sichtbar; die App zeigt
nur den gewählten Arbeitsbereich statt einer einzigen langen Gesamtseite.

Der Workspace zeigt:

- gefilterte Build-or-Buy-Entscheidungen für Produktion, T2/Invention,
  Biochemical, Composite und Hybrid Polymer Reactions,
- globale und gruppenbezogene Sofortaktionen sowie kompakte optionale
  Einzelzeilen,
- Produktionsjobs mit Runs, Ausgabe und verwendeter Zwischenproduktmenge,
- Inventionsjobs mit erfolgreichen Kopien, lizenzierten Runs und
  Basiswahrscheinlichkeit,
- Bedarf, verwendbaren Bestand und Fehlmenge je Type-ID,
- Anzahl und Zustand berechneter Reservierungskonflikte,
- eine einfache kopierbare Liste ausschließlich positiver Fehlmengen.

## Tastatur und Accessibility

- `⌘⇧P`: Plan, Lager und Konfliktstatus aktualisieren,
- `⌘⇧V`: geänderte Build-or-Buy-Vorschau berechnen,
- Standardaktion: geprüfte Entscheidung übernehmen,
- `⌘⇧C`: aktuelle positive Fehlmengen kopieren.

Wesentliche Status-, Auswahl-, Job-, Mengen- und Konfliktelemente besitzen
explizite Accessibility-Labels oder kombinierte semantische Gruppen.

## Architektur

`BuildOrBuyWorkspaceViewModel` hängt ausschließlich am
`BuildOrBuyPlanning`-Port. Konkrete SwiftData-Repositories werden in
`ProjectAppComposition` verdrahtet. `ProductionWorkspaceView`,
`ProductionGraphView`, `ProjectsView`, `DashboardView` und ihre ViewModels
enthalten keinen direkten SwiftData-Zugriff.

Die Workspace-Basis entstand mit Schema v15. P55 ergänzt additiv Schema v25
für die Projektbudgetkonfiguration. Details zur Berechnung stehen in
[`BUILD_OR_BUY_PLANNING.md`](BUILD_OR_BUY_PLANNING.md), die Entscheidung in
[`ADR-0032`](Architecture/ADRs/ADR-0032_Integrierter-Produktionsworkspace.md)
und die aktuelle Darstellung in
[`ADR-0052`](Architecture/ADRs/ADR-0052_Horizontale-Produktionsworkspace-Navigation.md).

P56 ergänzt die gruppierte Entwurfssteuerung aus
[`ADR-0057`](Architecture/ADRs/ADR-0057_Gruppierte-Build-or-Buy-Auswahl.md).
Sie speichert keine Gruppenkonfiguration, sondern übergibt die daraus
entstehenden Einzelentscheidungen an den unveränderten P26-Vertrag.
[`ADR-0058`](Architecture/ADRs/ADR-0058_Reaktionsuntergruppen-und-kompakte-Build-or-Buy-Steuerung.md)
ergänzt die drei Reaktionsuntergruppen, den schreibfreien Filter, globale
Sofortaktionen und die kompakte Einzelzeile.

[`ADR-0059`](Architecture/ADRs/ADR-0059_Deutsche-Zahlenformatierung-in-der-UI.md)
legt die appweite Präsentationsregel fest: sichtbare Mengen werden als
`1.234.567`, sichtbare ISK-Werte als `1.234.567,89 ISK` dargestellt.
Technische IDs, Eingabefelder, Berechnungen und Exporte behalten ihre
bisherigen unveränderten Datenformate.

Der frühere Bereich **Kosten & ROI** ist seit P55 durch **Budget** ersetzt.
Das Materialbudget folgt der wirksamen Einkaufsliste: Eine als `Kaufen`
markierte Zwischenstufe wird direkt bewertet; bei `Bauen` werden stattdessen
ihre fehlenden Eingaben bewertet. Logistik und Produktion sind getrennte
manuelle ISK-Blöcke. Details stehen in
[`PROJECT_BUDGET.md`](PROJECT_BUDGET.md) und
[`ADR-0056`](Architecture/ADRs/ADR-0056_Projektbudget-statt-sichtbarer-Wallet-Projektfinanzen.md).

## Bewusste Grenzen

Automatische Fracht-, Routen-, Facility-, Steuer-, SCI- oder
Jobkostenberechnungen sind nicht Teil von P55. Die frühere Gewinn-/ROI-
Oberfläche und Wallet-Istfinanzen sind nicht Bestandteil des neuen
Planbudgets.
