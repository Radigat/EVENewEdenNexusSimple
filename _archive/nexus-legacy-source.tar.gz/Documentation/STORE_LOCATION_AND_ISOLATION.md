# Storepfad und Startisolation

Stand: 2026-07-24 · OFF-026 erledigt

## Produktiver Store

New Eden Nexus verwendet:

```text
~/Library/Application Support/NewEdenNexus/NewEdenNexus.store
```

Der frühere generische SwiftData-Pfad
`~/Library/Application Support/default.store` ist kein sicherer
app-spezifischer Speicherort. Er wird nur lesend auf die
New-Eden-Nexus-Signatur geprüft. Ein fachfremder Store bleibt vollständig
unangetastet.

Die Anwendung löscht, ersetzt, kopiert oder verschiebt einen vorhandenen
Legacy-Store nicht automatisch.

## Sichere Auflösungsreihenfolge

1. Ein vorhandener app-spezifischer Store wird verwendet.
2. Ohne app-spezifischen Store wird ein vorhandener `default.store`
   ausschließlich lesend klassifiziert.
3. Ein sicher erkannter New-Eden-Nexus-Legacy-Store wird an Ort und Stelle
   weiterverwendet.
4. Ein sicher erkannter fremder Store wird ignoriert; die App legt ihren
   app-spezifischen Store an.
5. Ein unlesbarer Legacy-Store führt weiterhin zum sicheren zentralen
   Startfehler statt zu einem stillen leeren Ersatzstore.

## Isolierter Teststart

Für einen kontrollierten manuellen Smoke-Test kann ein absoluter Pfad
angegeben werden:

```text
NewEdenNexus \
  --new-eden-nexus-isolated-store \
  /private/tmp/NewEdenNexus-Test/NewEdenNexus.store
```

Das Argument ist ausschließlich eine Testgrenze. Relative Pfade und ein
fehlender Wert werden abgelehnt. Dieser Modus zählt als Testumgebung und
startet deshalb keine produktive SDE-Automation oder Keychain-Composition.

## OFF-026-Nachweis

Der am 2026-07-24 untersuchte globale `default.store` war konsistent, enthielt
aber `ZAPIREQUESTMODEL` statt der New-Eden-Nexus-Tabellen. Er wurde nicht
verändert. Ein echter isolierter App-Prozess erzeugte dagegen einen
konsistenten Store mit `ZCHARACTERRECORD` und `ZPRODUCTIONPROJECT`.

Details stehen in
[ADR-0016](Architecture/ADRs/ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md)
und im
[OFF-026-Abschlussbericht](Progress/Reports/2026-07-24_OFF-026_Isolierter-App-Start.md).
