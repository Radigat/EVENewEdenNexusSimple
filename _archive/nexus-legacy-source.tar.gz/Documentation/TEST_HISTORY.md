# Testhistorie

## 2026-07-23 – P00: Entwickler-Cockpit

### Umgebung

- macOS, Apple Silicon
- Xcode 26.6 (Build 17F113)
- Swift 6.3.3
- Package-Plattform: macOS 14

### Build

```bash
swift build -c debug
```

Ergebnis: **erfolgreich** (`Build complete!`). Im erfolgreichen Lauf wurden keine Compilerwarnungen ausgegeben.

### Tests

```bash
swift test -c debug
```

Ergebnis: **erfolgreich**, 2 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler.

| Test | Ergebnis | Abdeckung |
|---|---|---|
| `testProjectNormalizesQuantity` | ✅ | Mindestmenge 1 und initialer Projektstatus |
| `testPythonMaterialAggregation` | ✅ | Zusammenführung identischer Type-ID, Gesamtmenge und Kosten |

Die zusätzlich ausgegebene Swift-Testing-Zeile meldet 0 Tests in 0 Suites; das Package verwendet derzeit XCTest, dessen zwei Tests zuvor erfolgreich liefen.

### Strukturprüfungen

```bash
swift package describe
xcodebuild -list -workspace .swiftpm/xcode/package.xcworkspace
```

- `swift package describe`: außerhalb der Sandbox erfolgreich; Produkt und beide Targets bestätigt.
- `xcodebuild -list ...`: fehlgeschlagen mit `'.swiftpm/xcode/package.xcworkspace' is not a workspace file`; zusätzlich Sandbox-/Simulatorwarnungen. Der generierte Workspace und ein verwalteter `NewEdenNexus`-Scheme-Eintrag sind auf Dateiebene vorhanden.

### Nicht ausgeführt

- Release-Build,
- UI-Tests,
- echter SSO-Durchlauf,
- Netzwerk-/ESI-Integration,
- Persistenz-, Migrations- oder Wiederherstellungstests,
- Performance- und Accessibility-Tests.

## 2026-07-23 – P01: Dauerhafte Entwicklungsregeln

### Strukturprüfung

```bash
find . -maxdepth 5 \( -name '*.xcodeproj' -o -name '*.xcworkspace' -o -name '*.xcscheme' -o -name 'Package.swift' \) -print
xcodebuild -version
swift package describe
```

Ergebnis: Swift Package für macOS 14, Produkt `NewEdenNexus`, Testtarget `NewEdenNexusTests`, Xcode 26.6. Kein eigenständiges `.xcodeproj`; generierter SwiftPM-Workspace vorhanden.

### Build

```bash
swift build -c debug
```

Ergebnis: **erfolgreich**, `Build complete!`, keine Warnung im erfolgreichen Lauf.

### Tests

```bash
swift test -c debug
```

Ergebnis: **erfolgreich**, 2 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler. Die zusätzliche Swift-Testing-Ausgabe meldet weiterhin 0 Tests in 0 Suites, da die vorhandenen Tests XCTest verwenden.

### Einordnung

P01 ändert keinen App-Code. Der Build-/Testlauf dient als Regressionskontrolle des unveränderten Ausgangsstands. Die gesonderte Struktur- und Verlinkungsprüfung der neuen Markdown-Regeln wurde erfolgreich abgeschlossen.

## 2026-07-23 – P02: Zielarchitektur und Modulgrenzen

### Baseline

```bash
swift package describe
swift build -c debug
swift test -c debug
```

Ergebnis vor Änderung: ein App- und ein Testtarget; Debug-Build erfolgreich; 2 XCTest-Tests, 0 Fehler.

### Target- und Buildprüfung nach Änderung

```bash
swift package describe
swift build -c debug
swift build -c release
```

Ergebnis:

- vier produktive Targets und drei Testtargets bestätigt,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen in den erfolgreichen Läufen.

### Erster Testlauf

```bash
swift test -c debug
```

Ergebnis: **10 bestanden, 1 fehlgeschlagen**. Der Paritätstest erkannte nach Decimal-Rundung `5.5600000000000005` statt der erwarteten kanonischen Double-Repräsentation `5.56`.

Korrektur: Decimal wird nach Rundung über seine kanonische Dezimalzeichenfolge in `Double` konvertiert. Kein Test wurde abgeschwächt oder entfernt.

### Abschließender Testlauf

```bash
swift test -c debug
```

Ergebnis: **11 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler**.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 3 | verbotene Domain-/Application-Imports und adapterfreie Application-Nutzung |
| `MaterialSummaryCalculatorTests` | 6 | leer, Parität, Determinismus, ungültige ID, leerer Name, nicht endlicher Preis |
| `NewEdenNexusTests` | 2 | Projektregression und injizierter nativer Aggregationspfad |

Die zusätzliche Swift-Testing-Ausgabe meldet 0 Tests in 0 Suites; alle 11 vorhandenen Tests verwenden XCTest.

### Nicht ausgeführt

- UI-Tests,
- Persistenz-/Migrationstests, da P02 kein Schema ändert,
- echter SSO-/Netzwerktest,
- Performance- und Accessibility-Tests,
- manuelle App-GUI-Prüfung.

## 2026-07-23 – P03: Domänenmodell, Schema v1 und Migrationen

### Baseline

```bash
swift package describe
swift build -c debug
swift test -c debug
```

Ergebnis vor P03: vier produktive Targets, drei Testtargets, Debug-Build erfolgreich, **11 XCTest-Tests und 0 Fehler**.

### Zwischenläufe

- Der erste Build nach Registrierung von `NewEdenNexusPersistenceTests` schlug erwartungsgemäß fehl, weil dessen Quellverzeichnis noch nicht angelegt war; der Target wurde anschließend mit den vorgesehenen Tests befüllt.
- Ein SwiftData-`#Predicate` kompilierte zunächst nicht, weil es `project.id` über einen Snapshot-Keypath erfasste. Die stabile UUID wird nun vor dem Prädikat lokal gebunden.
- Im ersten Test-Compile waren `CharacterRecord` und `ProductionProject` zwischen Legacy-Fixture und Schema v1 mehrdeutig. Die aktuellen Schemamodelle werden im Test ausdrücklich über `NexusSchemaV1` qualifiziert.

Kein fehlgeschlagener Zwischenlauf wurde als bestanden dokumentiert; keine Prüfung wurde entfernt oder abgeschwächt.

### Abschließender Target-, Build- und Testlauf

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Ergebnis:

- fünf produktive Targets bestätigt,
- vier Testtargets plus separates Legacy-Fixture-Target bestätigt,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen in den erfolgreichen Läufen,
- **26 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler**.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 4 | Domain-, Application- und Persistence-Importgrenzen sowie adapterfreier Application-Port |
| `MaterialSummaryCalculatorTests` | 6 | P02-Regressionsumfang |
| `ProductionProjectSnapshotTests` | 6 | Normalisierung und sämtliche P03-Domain-Invarianten |
| `NexusPersistenceTests` | 8 | Legacy-Struktur, Standardpfad, Migration/Wiederöffnung, Leerstore, Repository, Sortierung und ungültiges Mapping |
| `NewEdenNexusTests` | 2 | App-/Integrationsregressionen |

### Migrationsnachweis

Der Migrationstest verwendet ausschließlich ein UUID-basiertes temporäres Verzeichnis. Er erzeugt dort einen Store mit dem früheren Top-Level-Schema, speichert einen Charakter und ein Projekt mit festen Werten und öffnet anschließend dieselbe Datei über `NexusSchemaV1` und `NexusMigrationPlan`.

Geprüft wurden:

- Anzahl beider Entitäten,
- alle gespeicherten Legacy-Attribute einschließlich IDs, optionaler Datumswerte und Raw-Status,
- `recordVersion == 1` für beide Entitäten,
- unveränderte Werte nach einer zweiten Öffnung des bereits migrierten Stores.

Der Strukturtest vergleicht Entitynamen, Attributnamen, reflektierte Typen, Optionalität, Unique-Flags und Unique-Constraints des Testfixtures mit `NexusLegacySchema`.

### Nicht ausgeführt

- UI- und manuelle GUI-Tests,
- echter SSO-/Netzwerkdurchlauf,
- Performance- und Accessibility-Tests,
- Backup-/Restore-Test und Downgrade-Test,
- Migration einer produktiven Benutzerdatenbank.

## 2026-07-23 – P04: Fehlerbehandlung und Logging

### Baseline

Der erste Sandboxlauf:

```bash
swift package describe
```

scheiterte beim Schreiben in den systemweiten Swift-/Clang-Modulcache mit `Operation not permitted`. Das war eine Ausführungsumgebungsgrenze, kein Manifest- oder Quellcodefehler.

Mit freigegebenem Cachezugriff wurden ausgeführt:

```bash
swift package describe
swift build -c debug
swift test -c debug
```

Ergebnis vor P04-Codeänderungen: Targetgraph bestätigt, Debug-Build erfolgreich, **26 Tests und 0 Fehler**.

### Erster P04-Lauf

```bash
swift build -c debug
swift test -c debug
```

Ergebnis: Debug-Build erfolgreich, **33 Tests und 0 Fehler**. Danach wurde zusätzlich die Infrastructure-Importgrenze automatisiert abgesichert und der Keychain-Löschfehler genauer klassifiziert.

### Abschließender Lauf

```bash
swift package describe
swift build -c debug
swift test -c debug
swift build -c release
```

Ergebnis:

- fünf produktive Targets,
- fünf Testtargets plus Legacy-Fixture-Target,
- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- keine Compilerwarnungen in den erfolgreichen Läufen,
- **34 XCTest-Tests, 0 Fehler, 0 unerwartete Fehler**.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 5 | Importgrenzen von Domain, Application, Infrastructure und Persistence sowie adapterfreier Application-Port |
| `ErrorHandlingTests` | 3 | vollständiges Operation-Mapping, Raw-Error-Schutz, Metadatenredaction und Sortierung |
| `MaterialSummaryCalculatorTests` | 6 | P02-Berechnungsregression |
| `ProductionProjectSnapshotTests` | 6 | P03-Domaininvarianten |
| `NexusPersistenceTests` | 8 | P03-Schema-, Migration-, Leerstore- und Repositoryregression |
| `NewEdenNexusTests` | 6 | Appintegration, Startfehler, Retry, Einzel-Logging, Dismiss und statische Source-Prüfung |

### P04-Nachweise

- alle acht Operationen mappen auf stabile Codes und Kategorien,
- ein `LocalizedError` mit Secret-Sentinel erscheint weder in UI- noch Diagnosetext,
- private Metadaten enthalten im gerenderten Log nur `<redacted>`,
- öffentliche Metadaten werden sortiert und Zeilenumbrüche neutralisiert,
- Startfehler erzeugt `.failed` statt Absturz,
- zweiter Startversuch kann einen In-Memory-Container öffnen,
- jeder von der Runtime gemeldete Fehler erzeugt genau ein Ereignis,
- produktive App-Sources enthalten kein `fatalError(` und kein `try? modelContext.save()`,
- alle P02-/P03-Regressionsprüfungen bleiben grün.

### Nicht ausgeführt

- UI- und manueller App-GUI-Test,
- echter SSO-/Netzwerkdurchlauf,
- Auslesen und visuelle Prüfung des macOS-Unified-Log-Streams,
- Performance- und Accessibility-Tests,
- Backup-/Restore-Test,
- produktiver Datenbankfehler oder produktive Benutzerdaten.

## 2026-07-23 – OFF-001: Git-Wurzel

### Repositoryprüfungen

Vorher:

```text
project git root: /Users/svenstolze
project .git: nicht vorhanden
home .git: vorhanden
```

Nach `git init --initial-branch=main .` im Projektordner:

```text
project git root: /Users/svenstolze/Documents/Codex/EVE Nexus
project branch: main
project status: No commits yet on main
home git root: /Users/svenstolze
home branch: main
home .git: weiterhin vorhanden
```

Die vor und nach dem Vorgang geprüften Home-`.git`-Metadaten blieben identisch: Inode `34224172`, mtime `1784782540`, Größe `320`.

### Build und Tests

Nicht erneut ausgeführt, da kein App-Code, Package oder Datenmodell geändert wurde. Der letzte P04-Nachweis bleibt Debug-/Release-Build erfolgreich und 34 Tests ohne Fehler.

## 2026-07-23 – OFF-002: Gitignore

### Positive Ignore-Prüfungen

```bash
git check-ignore -v <Pfad>
```

Erfolgreich der jeweils vorgesehenen Regel zugeordnet:

- `.DS_Store`,
- `.build` und Unterpfade,
- `.swiftpm` und `xcuserdata`,
- `DerivedData`,
- `*.xcuserstate`,
- `.xcode.env.local`,
- `.env` und `.env.local`,
- `*.swp` und Editor-Backups.

### Negative Ignore-Prüfungen

Nicht ignoriert:

- `Package.swift`,
- `Sources/NewEdenNexus/NewEdenNexusApp.swift`,
- `Documentation/OFFEN.md`,
- `Package.resolved`,
- `.env.example`.

`git status --short` zeigt generierte Artefakte nicht mehr als untracked; `git status --short --ignored` weist `.DS_Store`, `.build/` und `.swiftpm/` als ignoriert aus.

Ein kombinierter Abschlusscheck verwendete zunächst versehentlich den zsh-Spezialparameter `path` als Schleifenvariable und konnte deshalb nach den ersten erfolgreichen Prüfungen keine weiteren Programme auflösen. Das Repository wurde dabei nicht verändert. Derselbe Check wurde anschließend mit `candidate_path` vollständig und erfolgreich wiederholt.

### Build und Tests

Nicht erneut ausgeführt, da weder App-Code, Package, Datenmodell noch Buildkonfiguration geändert wurden. Der letzte P04-Nachweis bleibt gültig: Debug-/Release-Build erfolgreich, 34 Tests ohne Fehler.

## 2026-07-23 – P05: Testfundament und Referenzdaten

### Befehle

```bash
swift package describe
swift test -c debug --enable-code-coverage
./Scripts/ci-verify.sh
swift test --show-codecov-path
```

`Scripts/ci-verify.sh` führt zusätzlich `swift build -c debug`, `swift build -c release` und `swift test -c release` aus.

### Ergebnis

- Targetgraph einschließlich `NewEdenNexusTestSupport` und `NewEdenNexusTestSupportTests` erkannt.
- Debug-Build erfolgreich.
- Release-Build erfolgreich.
- Debug-Testlauf mit Coverage: **40 Tests, 0 Fehler, 0 unerwartete Fehler**.
- Release-Testlauf: **40 Tests, 0 Fehler, 0 unerwartete Fehler**.
- keine übersprungenen XCTest-Tests.
- providerneutraler Gesamtlauf erfolgreich.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 5 | Schichten- und Importgrenzen |
| `ErrorHandlingTests` | 3 | Fehlercodes, Rohtextschutz und Redaction |
| `MaterialSummaryCalculatorTests` | 6 | Aggregation, Rundung und Fehlerpfade |
| `ProductionProjectSnapshotTests` | 6 | Projektdomaininvarianten |
| `ReferenceDatasetTests` | 2 | drei versionierte Sollwertfälle |
| `NexusPersistenceTests` | 8 | Schema, Migration, Leerstore und Repository |
| `NewEdenNexusTests` | 6 | App-Runtime und Integrationsregression |
| `TestSupportTests` | 4 | Loader, Versionsfehler, Builder und temporäre Stores |

### Coverage-Baseline

- alle instrumentierten Dateien einschließlich Tests: `1779/3022` Zeilen = `58,87 %`,
- produktive Sources: `462/1677` = `27,55 %`,
- Domain und Application: `286/288` = `99,31 %`,
- P05-TestSupport: `103/106` = `97,17 %`.

### Strukturelle Prüfungen

- JSON syntaktisch gültig,
- CI-Skript syntaktisch gültig und ausführbar,
- keine Secret-/Tokenmuster in P05-Fixtures,
- kein Force-Unwrap, `fatalError`, `preconditionFailure` oder `try?` im TestSupport,
- nach dem Testlauf keine `NewEdenNexus-P0*`-Storeverzeichnisse im temporären Testpfad vorhanden,
- alle Markdown-Dateilinks gültig.

### Fehler und Wiederholung

Der erste `swift package describe` scheiterte in der Dateisandbox am nicht beschreibbaren Benutzer-Modulcache. Nach Umleitung auf eigene temporäre Modul-Caches blieb der verschachtelte Swift-Sandboxprozess blockiert. Alle Paket-, Build-, Test- und Coverage-Prüfungen wurden anschließend außerhalb der Dateisandbox mit denselben Projektdateien erfolgreich ausgeführt.

### Nicht ausgeführt

- manueller App-GUI-/UI-Test,
- echte SDE-, ESI- oder Netzwerkprüfung,
- Performance- oder Lasttest,
- Backup-/Restore-Test,
- Zugriff auf produktive Benutzerdaten.

## 2026-07-23 – P06: Lokale Backups

### Befehle

```bash
swift test
swift test --filter SQLiteLocalBackupServiceTests
./Scripts/ci-verify.sh
swift test --show-codecov-path
xcrun llvm-cov report <Testbinary> -instr-profile=<default.profdata>
```

`Scripts/ci-verify.sh` führte `swift package describe`, Debug-/Release-Build, Debug-Test mit Coverage und Release-Test aus.

### Erster vollständiger Testlauf

Der Build war erfolgreich. Von 47 Tests schlugen 6 neue Backup-Tests mit SQLite-Code 14 beim `quick_check` fehl. Ursache war die read-only Öffnung eines aus einem WAL-Store erzeugten Snapshots: SQLite versuchte für die Prüfung Seitendateien zu öffnen.

Korrektur: Die Integritätsprüfung verwendet nun ausdrücklich einen SQLite-URI mit `immutable=1`. Sie bleibt dadurch read-only und benötigt keine WAL-/SHM-Dateien im Paket. Der anschließende gezielte Lauf bestand mit 7 von 7 Tests.

Im gesonderten Review wurde danach der Schutz gegen eine inhaltliche Zieländerung nach der Vorschau ergänzt. Der Ziel-Fingerabdruck bindet Hauptdatei, WAL und SHM an die Vorschau. Der neue Regressionstest bestand; der endgültige Gesamtlauf umfasst 48 Tests.

### Abschließendes Ergebnis

- Targetgraph bestätigt.
- Debug-Build erfolgreich.
- Release-Build erfolgreich.
- Debug-Testlauf mit Coverage: **48 Tests, 0 Fehler, 0 unerwartete Fehler**.
- Release-Testlauf: **48 Tests, 0 Fehler, 0 unerwartete Fehler**.
- keine übersprungenen XCTest-Tests.
- keine Compilerwarnungen in den erfolgreichen Läufen.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 5 | Schichten- und Importgrenzen einschließlich SQLite/CryptoKit-Verbot in Application |
| `ErrorHandlingTests` | 3 | Fehlercodes, sichere Texte und Redaction |
| `MaterialSummaryCalculatorTests` | 6 | Aggregation, Rundung und Fehlerpfade |
| `ProductionProjectSnapshotTests` | 6 | Projektdomaininvarianten |
| `ReferenceDatasetTests` | 2 | versionierte Sollwertfälle |
| `NexusPersistenceTests` | 8 | Schema, Migration, Leerstore und Repository |
| `SQLiteLocalBackupServiceTests` | 8 | Backup, Integrität, Manipulation, Gates, Restore und Sicherheitsbackup |
| `NewEdenNexusTests` | 6 | App-Runtime und Integrationsregression |
| `TestSupportTests` | 4 | Loader, Versionen, Builder und temporäre Stores |

### P06-Nachweise

- Backup eines geöffneten SwiftData-Quellcontainers,
- `.nenbackup`-Manifest, Paketstruktur und restriktive Dateirechte,
- keine verbleibenden `.partial`-Pakete,
- Prüfsummen- und Formatmanipulation werden abgelehnt,
- Vorschau verändert das Ziel nicht,
- fehlende Bestätigung und offener Zielstatus werden abgelehnt,
- Backup- und Zieländerungen nach Vorschau werden abgelehnt,
- Restore erzeugt ein verifiziertes `beforeRestore`-Backup,
- ursprünglicher und wiederhergestellter Datenstand können vollständig erneut geöffnet werden,
- fehlende Quelle erzeugt kein Artefakt,
- alle P02- bis P05-Regressionsprüfungen bleiben grün.

### Coverage

- alle instrumentierten Dateien einschließlich Tests: `2852/4241` Zeilen = `67,25 %`,
- produktive Sources: `1061/2415` = `43,93 %`,
- Domain und Application: `336/338` = `99,41 %`,
- SQLite-Backupadapter: `549/682` = `80,50 %`.

### Nicht ausgeführt

- manuelle App-GUI-/Restore-UI-Prüfung,
- Restore eines produktiven Benutzerstores,
- externer Datenträger, 3-2-1- oder Rotationsprüfung,
- Performance-/Lasttest mit sehr großem Store,
- Prozessabbruch exakt während Veröffentlichung oder Zielersatz,
- vollständiger App-Neustart- und Recovery-Drill aus P36.

## 2026-07-23 – P07: SDE-Importpipeline

### Befehle

```bash
swift test --filter JSONLinesSDEImportServiceTests
swift test --filter NewEdenNexusInfrastructureTests
./Scripts/ci-verify.sh
swift test --show-codecov-path
```

`Scripts/ci-verify.sh` führte `swift package describe`, Debug-/Release-Build, Debug-Test mit Coverage und Release-Test aus.

### Zwischenlauf und Korrektur

Die ersten neun P07-Kernfälle bestanden. Nach Ergänzung aller defensiven Eingabegrenzen bestanden zunächst 18 Infrastrukturtests.

Im gesonderten Review wurde der ungültige `_key`-Fall JSON-Boolean `true` ergänzt. Dieser Lauf schlug mit **1 von 18** fehl, weil Foundation den Boolean als `NSNumber` und anschließend als `Int(1)` brückte. Die produktive Validierung prüft nun vor der exakten Ganzzahlkonvertierung ausdrücklich gegen `CFBooleanGetTypeID()`.

Der gezielte Lauf bestand danach mit 18 von 18 Tests. Anschließend wurde der vollständige Debug-/Release-Prüfpfad erneut ausgeführt.

### Abschließendes Ergebnis

- Targetgraph einschließlich `NewEdenNexusInfrastructureTests` bestätigt.
- Debug-Build erfolgreich.
- Release-Build erfolgreich.
- Debug-Testlauf mit Coverage: **67 Tests, 0 Fehler, 0 unerwartete Fehler**.
- Release-Testlauf: **67 Tests, 0 Fehler, 0 unerwartete Fehler**.
- keine übersprungenen XCTest-Tests.
- keine Compilerwarnungen im erfolgreichen Abschlusslauf.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 5 | Schichten- und Importgrenzen |
| `ErrorHandlingTests` | 3 | Fehlercodes, sichere Texte und Redaction |
| `JSONLinesSDEImportServiceTests` | 9 | Vorschau, Hash, Manifest, Rechte, Determinismus, Quellenänderung |
| `JSONLinesSDEImportValidationTests` | 9 | UTF-8, JSON, Zeilen, Schlüssel, Links, Kollision, Abbruch |
| `MaterialSummaryCalculatorTests` | 6 | Aggregation, Rundung und Fehlerpfade |
| `ProductionProjectSnapshotTests` | 6 | Projektdomaininvarianten |
| `ReferenceDatasetTests` | 2 | versionierte Sollwertfälle |
| `NexusPersistenceTests` | 8 | Schema, Migration, Leerstore und Repository |
| `SQLiteLocalBackupServiceTests` | 8 | Backup, Integrität, Gates und Restore |
| `NewEdenNexusTests` | 6 | App-Runtime und Integrationsregression |
| `TestSupportTests` | 5 | Loader, Versionen, Builder, Stores und SDE-Fixture |

### P07-Nachweise

- fester synthetischer Gesamt-SHA-256 und feste Counts,
- identische Quelle liefert identischen Snapshot,
- vollständiges decodierbares Manifest,
- Paket- und Dateirechte `0700`/`0600`,
- kein `.partial`-Rest nach Fehlern,
- Quellenänderung nach Vorschau abgelehnt,
- fehlende/leere/fehlerhafte Datei abgelehnt,
- ungültiges UTF-8, JSON-Wurzel und Größenlimit abgelehnt,
- fehlende, nicht ganzzahlige, nicht positive, boolesche und doppelte `_key` abgelehnt,
- symbolische Links und vorhandenes Zielpaket abgelehnt,
- Task-Abbruch bleibt `CancellationError` und veröffentlicht nichts,
- alle P02- bis P06-Regressionsprüfungen bleiben grün.

### Coverage

- alle instrumentierten Dateien: `4232/5702` Zeilen = `74,22 %`,
- produktive Sources: `1637/3045` = `53,76 %`,
- `JSONLinesSDEImportService.swift`: `507/560` = `90,54 %`.

### Nicht ausgeführt

- realer aktueller CCP-SDE-Großdatensatz,
- Netzwerkdownload, HTTP-Caching oder ZIP-Extraktion,
- Performance-/Lastmessung,
- manuelle App-GUI-/SDE-UI-Prüfung,
- Import in einen produktiven SwiftData-Store,
- produktive Benutzerdaten.

## 2026-07-23 – P08: Statisches Datenschema

### Befehle

```bash
swift test -c debug
env NEN_REAL_SDE_DIRECTORY=<temporäres-Verzeichnis> \
  NEN_REAL_SDE_BUILD=3424810 \
  swift test -c debug --filter OfficialSDEPersistenceIntegrationTests
./Scripts/ci-verify.sh
swift test --show-codecov-path
```

`Scripts/ci-verify.sh` führte Packagebeschreibung, Debug-/Release-Build,
Debug-Test mit Coverage und Release-Test aus.

### Zwischenläufe und Korrekturen

1. Der erste Debuglauf hatte 77 Tests und zwei erwartungsbezogene Fehler:
   neue SDE-Fehlercodes fehlten im vollständigen Mappingtest und der erweiterte
   synthetische Fixturehash war noch nicht aktualisiert. Beide Nachweise
   wurden korrigiert.
2. Der erste offizielle Lauf zeigte, dass `_key == 0` gültig ist. Die frühere
   P07-Regel wurde auf nichtnegative Ganzzahlen korrigiert und getestet.
3. Der zweite offizielle Lauf zeigte Aktivitätszeiten `0`. Das Mapping erlaubt
   nun nichtnegative Zeiten mit Regressionstest.
4. Der dritte offizielle Lauf zeigte 21 Typ-IDs, die in Blueprintmaterialien
   oder -produkten referenziert, aber im selben `types.jsonl` nicht vorhanden
   sind. Die Zeilen bleiben erhalten, werden explizit als nicht aufgelöst
   markiert und gezählt.
5. Nach Aktualisierung des nachgewiesenen Zählers bestand der vollständige
   offizielle End-to-End-Lauf.

### Abschließendes Ergebnis

- Debug-Build erfolgreich.
- Release-Build erfolgreich.
- Debug mit Coverage: **83 Tests, 0 Fehler, 0 unerwartete Fehler**.
- Release: **83 Tests, 0 Fehler, 0 unerwartete Fehler**.
- offizieller Build-3424810-E2E-Test: **1 Test, 0 Fehler, 18,765 s**.
- keine übersprungenen XCTest-Tests.
- keine Compilerwarnungen im erfolgreichen Abschlusslauf.

| Suite | Anzahl | Inhalt |
|---|---:|---|
| `ArchitectureBoundaryTests` | 5 | Schichtengrenzen |
| `ErrorHandlingTests` | 3 | stabile Codes und Redaction |
| `JSONLinesSDEImportServiceTests` | 9 | Staging, Hash, Manifest und Atomarität |
| `JSONLinesSDEImportValidationTests` | 10 | defensive Formatgrenzen einschließlich ID 0 |
| `JSONLinesSDECatalogMapperTests` | 7 | Mapping, Referenzen, Zeit 0 und Manipulation |
| `NexusPersistenceTests` | 9 | Legacy/v1/v2-Migration, Leerstore und Projekte |
| `StaticDataCatalogRepositoryTests` | 4 | Aktivierung, Idempotenz, Historie und Konflikt |
| `OfficialSDEPersistenceIntegrationTests` | 1 | konfigurierbarer SDE-E2E- oder synthetischer Fallback |
| `SQLiteLocalBackupServiceTests` | 10 | Backup/Restore und Schema 1.0.0/2.0.0 |
| übrige Domain-/App-/TestSupport-Suiten | 25 | bestehende Regressionen |

### Realnachweis Build 3424810

- 48 Kategorien,
- 1.605 Gruppen,
- 52.743 Typen,
- 5.082 Blueprints,
- 19.137 Aktivitäten,
- 36.499 Materialien,
- 6.329 Produkte,
- 21 nicht aufgelöste Typreferenzen,
- Aktivierung in temporärem Schema-v2-Store,
- erfolgreiche Store-Wiederöffnung und Countvergleich.

### Coverage

- alle instrumentierten Dateien: `6231/7999` = `77,90 %`,
- produktive Sources: `2914/4543` = `64,14 %`,
- `StaticDataCatalog.swift`: `250/305` = `81,97 %`,
- `JSONLinesSDECatalogMapper.swift`: `694/842` = `82,42 %`,
- `SwiftDataStaticDataCatalogRepository.swift`: `166/178` = `93,26 %`.

### Nicht ausgeführt

- produktiver Benutzerstore,
- automatische `beforeMigration`-Auslösung,
- Crash exakt während des Aktivierungs-Saves,
- In-App-Download/ZIP,
- GUI-/Accessibility-Prüfung,
- wiederholte Benchmarkreihe und Speicherprofil.

## 2026-07-23 – P09: Item- und Blueprintkatalog

### Befehle

```bash
swift test --disable-sandbox -c debug --filter ItemBlueprintCatalog
./Scripts/ci-verify.sh
env NEN_REAL_SDE_DIRECTORY=<temporäres-Verzeichnis> \
  NEN_REAL_SDE_BUILD=3424810 \
  swift test --disable-sandbox -c debug \
  --filter OfficialSDEPersistenceIntegrationTests
swift test --show-codecov-path
```

Für die lokalen SwiftPM-Läufe wurden isolierte Modulcachepfade unter
`/private/tmp` verwendet. Produktive Benutzerdaten wurden nicht geöffnet.

### Zwischenläufe und Korrekturen

1. Ein erster normaler Sandbox-Build scheiterte am nicht beschreibbaren
   globalen Clang-/SwiftPM-Cache. Das war ein Umgebungsfehler. Mit isoliertem
   Cache und deaktivierter SwiftPM-Sandbox baute derselbe Quellstand.
2. Gezielte Application- und Persistence-Katalogtests wurden während der
   Implementierung wiederholt.
3. Nach Einführung von Schema v3 wurden alle Migrations-, Backup- und
   Real-SDE-Nachweise erneut ausgeführt.
4. Der offizielle Test wurde abschließend nochmals im finalen Schema-v3-Stand
   mit echten Katalogabfragen ausgeführt.

### Abschließendes Ergebnis

- Targetgraph bestätigt.
- Debug-Build erfolgreich.
- Release-Build erfolgreich.
- Debug mit Coverage: **100 Tests, 0 Fehler, 0 unerwartete Fehler**.
- Release: **100 Tests, 0 Fehler, 0 unerwartete Fehler**.
- offizieller Build-3424810-E2E-Test: **1 Test, 0 Fehler, 19,407 s**.
- keine übersprungenen XCTest-Tests.
- keine Compilerwarnungen im erfolgreichen Gesamtlauf.

Die Migrationstests geben die nicht fehlschlagende Core-Data-Meldung
„Migration was completed by another client“ aus. Der offizielle Realtest gibt
nach WAL-Wartung die nicht fehlschlagende Meldung zur Store-Change-
Benachrichtigungsregistrierung aus. Beide Läufe endeten mit Exitcode 0.

### P09-Nachweise

- sechs Application-Vertrags-/Validierungsfälle,
- zehn Persistence-Katalogfälle einschließlich Performance,
- exakte Item- und Blueprint-Lookups,
- typisiertes `notFound`,
- Groß-/Kleinschreibung, Diakritika und deterministische Gleichnamensortierung,
- Veröffentlichung, Kategorie, Gruppe, Produktionsfähigkeit und Aktivität,
- Begrenzung, `hasMore` und Deduplizierung,
- Wechsel der aktiven Version sowie keine/mehrere aktive Versionen,
- inkonsistente Referenzen und Task-Abbruch,
- v2→v3-Migration mit `searchName`-Backfill,
- Backupkompatibilität für Schema 1.0.0, 2.0.0 und 3.0.0,
- offizieller SDE-Store nach Wiederöffnung per ID und Name abgefragt.

### Performance

Der Performancefall erzeugt 50.000 synthetische Itemtypen und führt zehn
Suchen mit Limit 50 aus:

- Prüfgerät: MacBook Pro (Mac16,8), Apple M4 Pro, 14 CPU-Kerne, 24 GB RAM,
  macOS 26.5.2,
- Debug-Gesamtlauf: 0,300 s für den Abfrageblock,
- Release-Gesamtlauf: 0,296 s,
- je Suche höchstens 51 geladene Itemzeilen,
- ein Item-Fetch-Batch im einfachen Suchpfad.

Die Zeit für das Erzeugen des 50.000-Zeilen-Teststores ist nicht Bestandteil
der ausgewiesenen Abfragelatenz.

### Coverage

- alle instrumentierten Dateien: `7922/9825` = `80,63 %`,
- produktive Sources: `3652/5397` = `67,66 %`,
- `ItemBlueprintCatalog.swift`: `133/136`,
- `SwiftDataItemBlueprintCatalog.swift`: `497/527`,
- `NexusMigrationPlan.swift`: `43/43`.

### Nicht ausgeführt

- produktiver Benutzerstore,
- manuelle GUI-/Accessibility-Prüfung, da P09 keine UI einführt,
- automatische `beforeMigration`-Auslösung,
- wiederholte Messreihe auf mehreren Macs,
- Prozessabbruch exakt während des Migrations-Saves.

## 2026-07-23 – AUD-SDE-001: CCP-SDE-Soll-Ist-Audit

### Prüfart

Read-only Abgleich von Quellcode, Testnachweisen, SDE-Dokumentation,
Statusdateien und offiziellen CCP-Webquellen. Es wurde kein Produktcode und
kein Datenbankschema geändert.

### Externe Metadatenprüfung

- `latest.jsonl`: HTTP 200, SDE-Build `3444265`, Release
  `2026-07-23T11:06:22Z`, `ETag`, `Last-Modified` und
  `Cache-Control: max-age=300`.
- `schema-changelog.yaml`: erreichbar mit denselben Cachevalidatorarten;
  höchster gelesener `afterBuildNumber` `3407448`.
- Build `3444265` wurde nicht heruntergeladen, entpackt oder importiert.

### Build und Tests

Kein erneuter Build und kein erneuter XCTest-Lauf, weil ausschließlich
Markdown-Dokumentation geändert wurde. Der letzte unveränderte Produktnachweis
bleibt P09:

- Debug-Build erfolgreich,
- Release-Build erfolgreich,
- Debug und Release jeweils 100 XCTest-Tests, 0 Fehler,
- offizieller Build-3424810-E2E-Test erfolgreich.

Diese Ergebnisse belegen nicht die noch fehlenden HTTP-, Download-, ZIP-,
Scheduler-, Crash-, UI- oder Compliancepfade.

### Dokumentationsprüfung

Die neue Soll-Ist-Matrix deckt alle 18 Abschnitte und Abnahmekriterien des
Gesamtprompts ab. P07A bis P07C enthalten zugehörige Restarbeit und
Prüfnachweise. Die betroffenen Folgeprompts wurden auf diese Voraussetzungen
verwiesen.

## 2026-07-23 – P07A: SDE-Metadaten, HTTP-Cache und Compliance

### Abschlussbefehle

```bash
env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07A-Debug/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07A-Debug/swiftpm \
  swift test --disable-sandbox -c debug --enable-code-coverage

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07A-Release/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07A-Release/swiftpm \
  swift build --disable-sandbox -c release

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07A-Release/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07A-Release/swiftpm \
  swift test --disable-sandbox -c release
```

`swift package --disable-sandbox describe` wurde mit separatem isoliertem
Cache ebenfalls erfolgreich ausgeführt.

### Ergebnis

- gezielte P07A-/Backup-/Fehlerregression: **41 Tests, 0 Fehler**,
- nach Reviewkorrekturen zusätzlich fokussiert: **11 Service-** und
  **13 HTTP-Tests**, jeweils 0 Fehler,
- Debug mit Coverage: **130 Tests, 0 Fehler**,
- Release: **130 Tests, 0 Fehler**,
- keine übersprungenen XCTest-Tests,
- fünf Architekturgrenztests erfolgreich.

### Neue Testgruppen

| Testgruppe | Anzahl | Inhalt |
|---|---:|---|
| `SDEUpdateServiceTests` | 11 | Buildvergleich, 24 h, ressourcengenaue Cachefrische, 304, Offline, Schema-Gate, Abbruch |
| `CCPSDEMetadataClientTests` | 13 | feste URLs, Redirectschutz, Header, Parser, Inhaltstyp, Retry, 404/429/5xx, Timeout |
| `SDEUpdateStateRepositoryTests` | 6 | Statusroundtrip, aktive Version, Integrität, v3→v4 |

### Zwischenbefunde

1. Der erste gezielte Compilelauf scheiterte ausschließlich an `await` in
   XCTest-Autoclosures. Die Werte werden nun vor den Assertions aufgelöst.
2. Ein anschließender Lauf fand zwei Fehler im CRLF-Header-Test. Ursache war
   die Swift-Graphembehandlung; die produktive Headerprüfung validiert nun
   Unicode-Scalars. Der Regressionstest blieb erhalten.
3. Nach Korrektur bestanden 41 gezielte und zunächst jeweils 128
   vollständige Tests.
4. Der gesonderte Review fand eine asymmetrische Cachefrist. Nach der
   ressourcengenauen Korrektur bestanden 11 fokussierte Service- und jeweils
   129 vollständige Tests.
5. Der finale Sicherheitsreview fand die standardmäßige Redirectfolge.
   Redirects und abweichende finale URLs werden nun abgelehnt. Danach
   bestanden 13 fokussierte HTTP- und jeweils 130 vollständige Tests.

### Coverage

- alle instrumentierten Dateien: `10111/12186` = `82,97 %`,
- produktive Sources: `4668/6568` = `71,07 %`,
- `SDEUpdateChecking.swift`: `436/469` = `92,96 %`,
- `CCPSDEMetadataClient.swift`: `430/541` = `79,48 %`,
- `SwiftDataSDEUpdateStateRepository.swift`: `117/128` = `91,41 %`.

### Manueller read-only Nachweis

Die zwei festen offiziellen Metadatenressourcen lieferten HTTP 200,
Build `3444265`, Release `2026-07-23T11:06:22Z`, Validatoren und
`max-age=300`; der höchste Changelog-Eintrag war `3407448`. Kein Archiv wurde
geladen oder importiert.

### Nicht ausgeführt

- produktiver Benutzerstore,
- SDE-Archivdownload, ZIP-/Crash-/Aktivierungspfad,
- GUI-/Accessibility-Prüfung,
- automatische Startprüfung.

## 2026-07-23 – P07B: SDE-Archivdownload und Promotion

### Abschlussbefehle

```bash
env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-VerifiedDebug/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-VerifiedDebug/swiftpm \
  swift test --disable-sandbox -c debug --enable-code-coverage \
  --scratch-path /private/tmp/NewEdenNexus-P07B-VerifiedDebug/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/swiftpm \
  swift build --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-P07B-VerifiedRelease/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-VerifiedRelease/swiftpm \
  swift test --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-P07B-VerifiedRelease/build
```

### Ergebnis

- Debug mit Coverage: **145 Tests, 0 Fehler**,
- Release-Build: erfolgreich,
- Release: **145 Tests, 0 Fehler**,
- keine übersprungenen XCTest-Tests,
- fünf Architekturgrenztests erfolgreich.

### Neue und erweiterte Testgruppen

| Testgruppe | Anzahl | Inhalt |
|---|---:|---|
| `CCPSDEArchivePipelineTests` | 7 | feste URL, Header/Injection, Größe, Speicher, Redirect, ZIP-Manipulation, Bombenverhältnis, echte `ditto`-Grenze |
| `FileSDEInstallationLogStoreTests` | 3 | sicherer JSON-Roundtrip, nichtterminale Erkennung, Cleanup-Wiederaufnahme, keine lokalen Pfade |
| `SDEInstallationServiceTests` | 3 | Compliance-/Schema-Gates, Erfolg, Aktivierungsfehler, Rollback und Cleanup |
| `StaticDataCatalogRepositoryTests` | 6 | bisherige Aktivierung plus isolierte Wiederöffnung und Rollback |

### Coverage

- alle instrumentierten Zeilen: `12218/14574` = `83,83 %`,
- produktive Sources: `5781/7945` = `72,76 %`,
- `SDEInstallation.swift`: `277/317` = `87,38 %`,
- `CCPSDEArchivePipeline.swift`: `610/782` = `78,01 %`,
- `FileSDEInstallationLogStore.swift`: `109/127` = `85,83 %`,
- `SwiftDataSDEStagingService.swift`: `92/123` = `74,80 %`.

### Sicherheitsfälle

Geprüft wurden falscher HTTP-Status, Größenabweichung, zu wenig Speicher,
Redirect, beschädigtes ZIP, `..`-/absoluter Pfad, unerwarteter Dateityp,
Unix-Symlink, normalisiertes Duplikat, Bombenverhältnis, kontrollierte reale
Extraktion, Nachprüfung, Staging-Wiederöffnung, Aktivierungsfehler, Rollback
und Bereinigung.

### Nicht ausgeführt

- aktueller offizieller SDE-Download und Realimport,
- produktiver Benutzerstore,
- Prozessabbruch nach jeder Phasengrenze mit App-Neustart,
- belastbares Speicherprofil des vollständigen Snapshot-Mappings,
- GUI-/Accessibility-Prüfung.

## 2026-07-23 – P07B: Aktuelle Real-SDE-Abnahme

### Offizielle Vorprüfung

- `latest.jsonl`: Build `3444265`, Release
  `2026-07-23T11:06:22Z`,
- Schema-Changelog: höchster Eintrag `afterBuildNumber: 3407448`,
- Archiv: HTTP 200, `application/zip`, 98.707.648 Bytes, ETag und
  Last-Modified,
- ausschließlich offizielle CCP-Endpunkte.

### Realabnahme

Der Release-Runner wurde mit Owner-Gate, Build, geprüftem Schemastand und
einer nur über verdeckte Standardeingabe bereitgestellten Kontaktangabe
ausgeführt. Die Kontaktangabe erscheint in keinem Befehl, Ergebnis, Journal
oder Repositorydokument.

Ergebnis beider Läufe:

- Build 3444265 vollständig heruntergeladen, geprüft und importiert,
- Sicherheitsbackup und Aktivierung erfolgreich,
- Store erneut geöffnet,
- Rifter (Type-ID 587) und Blueprint 691 erfolgreich abgefragt,
- identischer Inhaltshash
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`,
- 48 Kategorien, 1.609 Gruppen, 52.821 Typen, 5.082 Blueprints,
  19.137 Aktivitäten, 36.499 Materialien und 6.329 Produkte,
- 21 nicht aufgelöste Referenzen unverändert erhalten,
- Terminaljournal und Cleanup erfolgreich,
- keine verbleibenden temporären Realabnahmeartefakte.

Messwerte:

| Lauf | Fachliche Laufzeit | Peak-RSS | Ergebnis |
|---|---:|---:|---|
| 1 | 34,10 s | 2.454.126.592 Bytes | ✅ |
| 2 mit Auto-Cleanup | 32,55 s | 2.448.506.880 Bytes | ✅ |

### Automatisierter Phasenwiederanlauf

`SDEInstallationServiceTests` prüft nun nichtterminale Journale an jeder
persistenten Grenze von `started` bis `promoting`. Vorheriger Aktivbuild,
Recoveryabschluss und Cleanup bleiben in allen Fällen konsistent.

### Abschlussbefehle

```bash
env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-FinalDebug/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-FinalDebug/swiftpm \
  swift test --disable-sandbox -c debug --enable-code-coverage \
  --scratch-path /private/tmp/NewEdenNexus-P07B-FinalDebug/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-FinalRelease/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-FinalRelease/swiftpm \
  swift build --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-P07B-FinalRelease/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P07B-FinalReleaseTests/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P07B-FinalReleaseTests/swiftpm \
  swift test --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-P07B-FinalReleaseTests/build
```

Ergebnis:

- Debug mit Coverage: **146 Tests, 0 Fehler**,
- Release-Build: **erfolgreich**,
- Release: **146 Tests, 0 Fehler**,
- keine übersprungenen XCTest-Tests,
- fünf Architekturgrenztests erfolgreich.

Coverage der produktiven Sources:

- `5798/7945` Zeilen = `72,98 %`,
- `SDEInstallation.swift`: `294/317` = `92,74 %`,
- `CCPSDEArchivePipeline.swift`: `610/782` = `78,01 %`.

### Nicht als bestanden bewertet

- vollständig blockweises Low-Memory-Mapping; Peak-RSS liegt bei rund
  2,45 GB,
- tatsächlicher Prozessabbruch mit anschließendem App-Neustart,
- produktive App-Startverdrahtung,
- GUI-/Accessibility-/Rechtsansicht.

## 2026-07-23 – CFG-001: Öffentliche EVE-Client-ID

### Automatisierte Prüfungen

```bash
env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-ClientID-Debug/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-ClientID-Debug/swiftpm \
  swift test --disable-sandbox -c debug \
  --scratch-path /private/tmp/NewEdenNexus-ClientID-Debug/build

env CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-ClientID-Release/clang \
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-ClientID-Release/swiftpm \
  swift test --disable-sandbox -c release \
  --scratch-path /private/tmp/NewEdenNexus-ClientID-Release/build
```

Ergebnis:

- Debug: **148 Tests, 0 Fehler**,
- Release: **148 Tests, 0 Fehler**,
- neuer Standard und Callback-URL geprüft,
- gezielte Migration des früheren Projektstandards geprüft,
- individuell konfigurierte Client-ID bleibt erhalten,
- keine übersprungenen XCTest-Tests.

### Hinweise

SwiftPM konnte im eingeschränkten Prüfumfeld seine Benutzer-Caches nicht
schreiben. SwiftData meldete bekannte Store-Notification-Diagnosen. Beide
Läufe endeten dennoch erfolgreich. Ein echter SSO-Login war nicht Teil dieser
Konfigurationsprüfung.

## 2026-07-23 – P07B: Blockweiser Low-Memory-Import

### Ausgeführte Prüfungen

```bash
swift test --disable-sandbox --enable-code-coverage
swift test --disable-sandbox -c release
swift build --disable-sandbox -c release
```

Die Befehle liefen mit isolierten Modulcaches und Scratch-Verzeichnissen
unter `/private/tmp`; die SwiftPM-Sandbox war wegen der nicht beschreibbaren
globalen Modulcaches deaktiviert.

### Ergebnis

- Debug/Coverage: **153 Tests, 0 Fehler**,
- Release: **153 Tests, 0 Fehler**,
- Release-Build: **erfolgreich**,
- keine übersprungenen XCTest-Tests,
- fünf Architekturtests erfolgreich,
- produktive Source-Coverage: **74,43 %**,
- `JSONLinesSDECatalogMapper.swift`: **84,42 %**,
- `SwiftDataStaticDataStreamingRepository.swift`: **83,29 %**,
- `SDEInstallation.swift`: **93,26 %**.

Zusätzlich geprüft:

- Batchobergrenze und vollständige Mengen,
- isoliertes Streaming-Staging mit Wiederöffnung,
- Abbruch mitten im Stream und Entfernung nur der Kandidatenzeilen,
- Schutz einer abgeschlossenen Version mit identischem Inhaltshash,
- alte aktive Version und vorhandene Charakter-/Projektdaten bleiben erhalten,
- Legacy-Vollsnapshotverdrahtung wird vor einem Download abgelehnt,
- Wiederanlauf an allen persistenten Phasengrenzen.

### Reale Speicherabnahme

Offizieller Build: `3444265`. Beide Läufe hatten den Inhaltshash
`3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`
und identische Mengen: 48 Kategorien, 1.609 Gruppen, 52.821 Typen,
5.082 Blueprints, 19.137 Aktivitäten, 36.499 Materialien, 6.329 Produkte
und 21 explizit nicht aufgelöste Referenzen.

| Lauf | Dauer | maximaler RSS | Ergebnis |
|---|---:|---:|---|
| 1 | 33,391 s | 952.057.856 Bytes | ✅ |
| 2 | 33,202 s | 948.125.696 Bytes | ✅ |

Die frühere Snapshot-Baseline lag bei 2.448.506.880 bis 2.454.126.592
Bytes. Der maximale RSS sank damit um rund 61 %. Backup, Aktivierung,
Wiederöffnung, Rifter-/Blueprintabfrage und Cleanup waren in beiden Läufen
erfolgreich. Kein produktiver Benutzerstore wurde verwendet.

## 2026-07-23 – P07C: SDE-Einstellungen, Automation und Recht

### Abschlussbefehle

```bash
swift build --scratch-path /private/tmp/NewEdenNexus-P07C-Debug -c debug
swift test --scratch-path /private/tmp/NewEdenNexus-P07C-Tests -c debug \
  --enable-code-coverage
swift build --scratch-path /private/tmp/NewEdenNexus-P07C-Release -c release
swift test --scratch-path /private/tmp/NewEdenNexus-P07C-ReleaseTests -c release
```

Der Compilerzugriff lief außerhalb der verwalteten Dateisandbox, weil der
globale Swift-Modulcache darin nicht beschreibbar war. Es wurde kein
`--disable-sandbox` verwendet.

### Ergebnis

- Debug-Build: erfolgreich,
- Debug/Coverage: **167 Tests, 0 Fehler**,
- Release-Build: erfolgreich,
- Release: **167 Tests, 0 Fehler**,
- fünf Architekturgrenztests erfolgreich,
- keine übersprungenen XCTest-Tests,
- produktive Source-Zeilenabdeckung einschließlich SwiftUI:
  **7509/11801 Zeilen, 63,63 %**.

### Neue und erweiterte Prüfungen

- konservative Automationsdefaults und Mindestintervall,
- Policy für Check, Vorabdownload und Installation,
- Startscheduler, nicht erzwungener Check und Parallelitätsschutz,
- kontaktfreie Bereinigung abgebrochener Installationen vor dem ersten
  Metadatencheck; bei Recoveryfehler startet kein neuer Check,
- Offlinezustand und sichere Diagnosecodes,
- Phasenfortschritt und Abbruchweitergabe,
- Cachewiederverwendung ohne zweiten Download,
- Erkennung und Entfernung beschädigter Cachearchive,
- vollständiger Logleser bei erhaltener Recoveryreihenfolge,
- bereinigter Diagnoseexport ohne IDs, Pfade, URLs, Hashes oder Kontakte,
- Retention mit exakter Bestätigung, Zustandsneubewertung und Schutz von
  Benutzerprojekten,
- statischer UI-/Accessibility-/Rechtstext- und Composition-Root-Test.

### Fehlgeschlagene Zwischenprüfungen und Korrekturen

1. Ein nicht eskalierter Build scheiterte, weil der Swift-Compiler seinen
   globalen Modulcache in der verwalteten Dateisandbox nicht schreiben
   konnte. Der gleiche Auftrag wurde mit freigegebenem Compilerzugriff
   wiederholt.
2. Der erste vollständige Lauf führte **165 Tests mit 2 Fehlern** aus.
   Beide `CachedSDEArchiveDownloaderTests` fanden, dass die temporäre
   Cachedatei erst verschoben und danach gehasht wurde. Die SHA-256-
   Berechnung wurde vor das Verschieben gesetzt. Der gezielte
   Zwei-Test-Lauf sowie alle anschließenden Gesamtläufe bestanden.
3. Der Review fand konkrete Adapterkonstruktion im ViewModel. Sie wurde in
   `SDEAppComposition` verschoben und durch einen statischen Regressionstest
   abgesichert.
4. Der abschließende Kontrolllauf fand, dass die vorhandene
   `recoverInterruptedInstallations()`-Funktion beim App-Start noch nicht
   aufgerufen wurde. Eine kontaktfreie Recovery-Grenze wurde vor den ersten
   Metadatencheck gesetzt und mit Erfolgs- und Fehlerpfad getestet.

### Manuelle Prüfung

Ein temporäres App-Bundle mit isoliertem Profil wurde gestartet; der Prozess
erzeugte ausschließlich seinen temporären Store. Ohne eigenständiges
Xcode-App-Bundle war kein steuerbares Fenster erreichbar. Der geforderte
manuelle Tastatur-/VoiceOver-Smoke-Test und datenschutzneutrale Screenshots
sind daher **nicht ausgeführt** und bleiben `OFF-025` für P09B.

Ein Desktopbild mit privaten Dateinamen wurde nicht gespeichert oder in die
Dokumentation übernommen.

## 2026-07-23 – P09A: Repository-Baseline

### Befehle

```bash
swift package describe
swift build --scratch-path /private/tmp/NewEdenNexus-P09A-Debug -c debug
swift test --scratch-path /private/tmp/NewEdenNexus-P09A-Tests -c debug \
  --enable-code-coverage
swift build --scratch-path /private/tmp/NewEdenNexus-P09A-Release -c release
swift test --scratch-path /private/tmp/NewEdenNexus-P09A-ReleaseTests \
  -c release
```

Der Compilerzugriff erfolgte mit getrennten Scratch-Verzeichnissen und
freigegebenem Zugriff auf den Swift-Modulcache. Es wurde kein
`--disable-sandbox` verwendet.

### Ergebnis

- SwiftPM-Paketbeschreibung: erfolgreich,
- Debug-Build: erfolgreich,
- Debug mit Coverage: **167 Tests, 0 Fehler**,
- Release-Build: erfolgreich,
- Release: **167 Tests, 0 Fehler**,
- fünf Architekturgrenztests erfolgreich,
- keine übersprungenen XCTest-Tests.

### Repositoryprüfungen

- Projekt-Git-Wurzel und Branch `main` bestätigt,
- unborn-Ausgangszustand ohne Remote bestätigt,
- 213 finale Baseline-Dateien inventarisiert,
- positive und negative `.gitignore`-Fälle geprüft,
- keine lokalen Stores, SDE-Großarchive oder Diagnoseartefakte im
  Commitumfang,
- E-Mail-Funde ausschließlich reservierte `.invalid`-Testwerte,
- kein Secretmuster in Textquellen oder Projektbuch,
- lokale Markdown-Dateiverweise vorhanden,
- gecachte Statistik und vollständiger gecachter Initialdiff geprüft.

P09A ändert keine Fachlogik und keine Coverage-Baseline.

## 2026-07-23 – P09B: Xcode-Projekt, Schemes und GUI-Abnahme

### Projekt- und Buildprüfungen

```bash
Scripts/verify_xcode_project.py
xcodebuild -list -project NewEdenNexus.xcodeproj
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexusSDEAcceptance -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build
swift build
swift build -c release
```

Ergebnis:

- 15 Package-/Xcode-Targets konsistent,
- sieben Testtargets und zwei gemeinsame Schemes,
- Xcode Debug/Release erfolgreich,
- SDE-Abnahmerunner erfolgreich gebaut, nicht ausgeführt,
- SwiftPM Debug/Release erfolgreich,
- keine Benutzerpfade, Teamwerte oder persönlichen Xcode-Metadaten in den
  Projektdateien.

### Abschließende Tests

```bash
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P09BDerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
swift test
```

- Xcode: **167 Tests, 0 Fehler, 0 übersprungen**, Testoperation
  18,086 Sekunden,
- SwiftPM: **167 Tests, 0 Fehler, 0 übersprungen**, XCTest-Dauer
  52,206 Sekunden,
- vorhandener 50.000-Item-Fall: 44,679 Sekunden, 51 geladene Zeilen bei
  Limit 50.

### Manuelle Prüfung

- echtes Debug-App-Bundle mit isoliertem `CFFIXED_USER_HOME` gestartet,
- Dashboard und EVE-Datenansicht geprüft,
- `Update verfügbar`, Offlinezustand und Schemaänderungs-Warnzustand
  sichtbar geprüft,
- `⌘⇧R` aktualisierte im isolierten Store den erfolgreichen Prüfzeitpunkt,
- Einstellungen per `⌘,`, Automation, Rechtstab und offizielle Links
  geprüft,
- VoiceOver real aktiviert, aktiver Screenreader bestätigt,
  `VO-Rechtspfeil` bei aktiver App ausgeführt und VoiceOver wieder
  deaktiviert,
- sechs ausschließlich auf App-Fenster begrenzte Screenshots gespeichert.

### Fehlgeschlagene oder verworfene Zwischenprüfungen

1. XcodeGen-Headerkopie wurde zunächst von der
   Benutzerskriptsandbox blockiert; projektlokal begrenzt korrigiert.
2. Runner-Build benötigte `-parse-as-library`; danach erfolgreich.
3. Ein erster bestandener Xcode-Testlauf war wegen paralleler manueller
   Desktopprüfung unbrauchbar langsam und wurde isoliert wiederholt.
4. Eingeschränkte Cache-/CoreSimulator-Zugriffe erzeugten nicht
   projektspezifische Warnungen; Abschlussläufe mit freigegebenem
   Cachezugriff erfolgreich.
5. Ein temporärer Screenshot einer fremden App wurde sofort gelöscht und
   nicht als Nachweis verwendet.

### Datenwirkung

Keine Schema- oder Migrationsänderung. Normal-, Offline- und Warnzustände
wurden ausschließlich in Teststores unter `.build` geprüft. Produktive
Benutzerdaten wurden nicht geöffnet oder verändert.

## 2026-07-23 – P10: Rezept- und Aktivitätsresolver

### Befehle

```bash
python3 Scripts/verify_xcode_project.py
swift test --disable-sandbox -c debug
swift test --disable-sandbox -c release
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P10DerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P10DerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexusSDEAcceptance -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P10DerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexusSDEAcceptance -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P10DerivedData \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO build
NEN_SDE_OWNER_ACCEPTED=YES \
NEN_SDE_BUILD=3444265 \
NEN_SDE_SCHEMA_REVIEWED_THROUGH=3444265 \
NEN_SDE_CONTACT=<runtime-contact> \
swift run --disable-sandbox -c release NewEdenNexusSDEAcceptance
```

### Ergebnis

- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes,
- SwiftPM Debug: **181 Tests, 0 Fehler, 0 übersprungen**,
- SwiftPM Release: **181 Tests, 0 Fehler, 0 übersprungen**,
- Xcode Debug: **181 Tests, 0 Fehler, 0 übersprungen**,
- Xcode Release: **181 Tests, 0 Fehler, 0 übersprungen**,
- SDE-Abnahmerunner Debug/Release: Build erfolgreich,
- neun Application- und fünf Persistence-Resolvertests erfolgreich,
- fünf Architekturgrenztests erfolgreich.

### Real-SDE-Abnahme

- offizieller Build: `3444265`,
- Inhaltshash:
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`,
- 52.821 Itemtypen, 5.082 Blueprints, 19.137 Aktivitäten,
  36.499 Materialien und 6.329 Produkte,
- vollständiges Fertigungs- und Reaktionsrezept aufgelöst,
- 21 tatsächliche Referenzlücken einzeln mit `NEN-RECIPE-001` geprüft,
- alle betroffenen Rezepte blockiert,
- Wiederöffnung, Sicherheitsbackup, Cleanup und Artefaktentfernung
  erfolgreich,
- Laufzeit des abschließenden Durchlaufs: 46,556 Sekunden,
- kein produktiver Benutzerstore geöffnet.

### Fehlgeschlagene Zwischenprüfungen und Korrekturen

1. Ein erster nicht freigegebener Swift-Lauf konnte den globalen
   Compiler-Modulcache in der Dateisandbox nicht schreiben. Derselbe Lauf
   wurde mit erlaubtem Cachezugriff erfolgreich wiederholt.
2. Der erste Xcode-Release-Testlauf endete mit Exitcode 65, weil
   `@testable`-Abhängigkeiten im generierten Release-Projekt ohne
   Testbarkeit gebaut wurden. `ENABLE_TESTABILITY = YES` wurde in der
   reproduzierbaren Quelle `project.yml` zentral gesetzt, das Projekt
   regeneriert und Debug/Release vollständig erneut geprüft.
3. Der Review ergänzte die Ablehnung probabilistischer Ausgaben und
   nichtpositiver Produktionslimits. Die vollständigen Suites und die
   Real-SDE-Abnahme wurden anschließend nochmals ausgeführt.

### Warnungen

Xcode meldete die bekannte Auswahl des ersten passenden macOS-Ziels und
vereinzelt eine harmlose CoreData-Migrationskoordination durch einen anderen
Testclient. Alle Abschlussbefehle endeten mit Exitcode 0; Compilerwarnungen
aus P10 blieben nach der Korrektur nicht offen.

## 2026-07-24 – P11: Projektlebenszyklus

### Abschlussbefehle

```bash
./Scripts/generate_xcode_project.sh
Scripts/verify_xcode_project.py
swift test -c debug
swift test -c release
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P11XcodeFinal \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/P11XcodeFinalRelease \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
```

### Ergebnis

- Xcode-/SwiftPM-Parität: 15 Targets, sieben Testtargets, zwei Schemes.
- SwiftPM Debug: **198 Tests, 0 Fehler, 0 übersprungen**.
- SwiftPM Release: **198 Tests, 0 Fehler, 0 übersprungen**.
- Xcode Debug: **198 Tests, 0 Fehler, 0 übersprungen**.
- Xcode Release: **198 Tests, 0 Fehler, 0 übersprungen**.
- P11-spezifisch: zwölf Application-, ein Persistence-, drei
  ViewModel-/App-Integrations- und ein Architektur-/UI-Quelltest.
- Keine neue Schemaversion; bestehende Migrations-, Backup-, SDE- und
  Resolverregressionen blieben grün.

Xcode-Debug-Ergebnis:
`.build/P11XcodeFinal/Logs/Test/Test-NewEdenNexus-2026.07.24_00-34-40-+0200.xcresult`.
Xcode-Release-Ergebnis:
`.build/P11XcodeFinalRelease/Logs/Test/Test-NewEdenNexus-2026.07.24_00-35-18-+0200.xcresult`.

### Abgedeckte P11-Fälle

- Anlegen, Validierung, Update und Listenfilter,
- jede erlaubte Statuskante, ungültige Sprünge, idempotenter No-op,
- Archivschreibschutz, Archivieren, Wiederherstellen und Duplizieren,
- fehlende ID, Cancellation und Repositoryfehler,
- dateibasierter vollständiger Lebenszyklus mit mehrfacher Storeöffnung,
- ViewModel-Loading, Auswahl, Mutationsschutz und Aktualisierung,
- `ProjectsView` ohne SwiftData/`@Query`/`modelContext`,
- Loading-/Empty-/Fehler-/Aktionszustände, Tastatur und Accessibility.

### Fehlgeschlagene oder verworfene Zwischenprüfungen

1. Ein eingeschränkter SwiftPM-Lauf konnte den globalen Clang-Modulcache
   nicht schreiben; die identische Suite bestand anschließend mit
   freigegebenem Cachezugriff.
2. Frühe vollständige Xcode-Läufe hingen im gehosteten App-Testprozess.
   Ursache waren doppelt in Host und Testbundle verlinkte statische Module,
   produktive SDE-/Keychain-Composition und eine Quellprüfung über einen
   Dokumenten-TCC-Pfad. Abhängigkeiten, XCTest-Startisolation und
   Quelltesttarget wurden korrigiert.
3. Ein Zwischenbuild meldete falsche Closure-Argumentlabels; die Signatur
   wurde korrigiert und alle Suites erneut ausgeführt.
4. Ein später erneut eingeschränkter Xcode-Lauf scheiterte an
   Benutzerskriptsandbox/Systemdienstzugriff; die bereits verifizierten
   Abschlussläufe außerhalb dieser Einschränkung blieben maßgeblich.

### Manueller Zusatzcheck

Der Debug-App-Start wurde zusätzlich versucht. Die App zeigte korrekt die
sichere Startfehleransicht `NEN-PER-001`; der lokale produktive Store war in
diesem Lauf nicht verfügbar. Dieser Lauf gilt nicht als erfolgreicher
UI-Smoke-Test. Es wurde kein Store gelöscht, ersetzt oder repariert.
Automatisierte UI-Quell-, ViewModel- und App-Integrationstests sind grün;
die isolierte Reproduktion bleibt `OFF-026`.

## 2026-07-24 – OFF-026: app-spezifischer Storepfad und Startisolation

### Abschlussbefehle

```bash
./Scripts/generate_xcode_project.sh
Scripts/verify_xcode_project.py
swift test -c debug
swift test -c release
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/OFF026XcodeDebug \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
xcodebuild -quiet -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Release \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/OFF026XcodeRelease \
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
```

### Ergebnis

- Xcode-/SwiftPM-Parität: 15 Targets, sieben Testtargets, zwei Schemes.
- SwiftPM Debug: **205 Tests, 0 Fehler, 0 übersprungen**.
- SwiftPM Release: **205 Tests, 0 Fehler, 0 übersprungen**.
- Xcode Debug: **205 Tests, 0 Fehler, 0 übersprungen**.
- Xcode Release: **205 Tests, 0 Fehler, 0 übersprungen**.
- Sieben neue Fälle: kein Legacy-Store, fremder Store, eigener Legacy-Store,
  unlesbarer Store, Vorrang des app-spezifischen Stores, expliziter
  dateibasierter Store und Startargumentvalidierung.

Xcode-Debug-Ergebnis:
`.build/OFF026XcodeDebug/Logs/Test/Test-NewEdenNexus-2026.07.24_06-54-26-+0200.xcresult`.
Xcode-Release-Ergebnis:
`.build/OFF026XcodeRelease/Logs/Test/Test-NewEdenNexus-2026.07.24_06-53-49-+0200.xcresult`.

### Echter isolierter App-Start

- App-Bundle als lokale, nur temporäre Kopie ad-hoc signiert; keine Projekt-,
  Team- oder Release-Signingwerte geändert.
- Prozessargument:
  `--new-eden-nexus-isolated-store /private/tmp/NewEdenNexus-OFF026-Store.BPuOl1/OFF026.store`.
- Prozess lief stabil und hielt laut `lsof` ausschließlich diesen Store
  einschließlich WAL/SHM offen.
- SQLite-`quick_check`: `ok`.
- Signaturtabellen: `ZCHARACTERRECORD`, `ZPRODUCTIONPROJECT`.
- Prozess anschließend geordnet beendet; Store weiterhin konsistent.

### Bestandsschutz

Der vorhandene globale
`~/Library/Application Support/default.store` wurde ausschließlich
read-only geprüft:

- Größe: 86.016 Bytes,
- Änderungszeit: `2026-07-23T10:36:45+0200`,
- SHA-256:
  `6acc13fe889a37e807f7908957e39073406667a53b99efa073c3f6040fd64ec0`,
- `quick_check`: `ok`,
- fremde Fachsignatur: `ZAPIREQUESTMODEL`.

Hash, Größe und Änderungszeit waren nach allen Prüfungen identisch. Es wurde
keine vorhandene Datei gelöscht, verschoben, ersetzt oder repariert.

### Verworfene Zwischenprüfungen

1. Ein direkt aus dem Automatisierungsprozess gestartetes App-Binary
   registrierte sich nicht über LaunchServices und brach in AppKit vor dem
   App-Code ab.
2. Unsigned CLI-Testbundles wurden von LaunchServices nicht als startbare
   App akzeptiert. Eine temporäre Kopie wurde nur für den Smoke-Test lokal
   ad-hoc signiert.
3. Ein Storepfad innerhalb des File-Provider-Workspace blieb beim echten
   Prozess unbenutzbar; der erfolgreiche Test verwendete den vorgesehenen
   neutralen `/private/tmp`-Pfad.
4. Die Computer-Use-Accessibility-Abfrage brach auf Transportebene ab.
   Deshalb wird kein visueller UI-Nachweis behauptet. Prozess, Argument,
   Dateideskriptoren und Datenbankintegrität wurden unabhängig bestätigt.
5. Ein nach den vier erfolgreichen Vollsuites gestarteter unveränderter
   Wiederholungslauf traf zunächst eine beschädigte generierte
   `.build/build.db` und anschließend File-Provider-Fehlmeldungen zu
   tatsächlich unveränderten Quelldateien. Es wurde nichts gelöscht oder
   repariert; ein Xcode-Nachlauf ohne fachliche Ausgabe wurde beendet. Die
   finalen Produktivquellen und die sieben Tests entsprechen weiterhin exakt
   dem zuvor in allen vier Vollsuites bestandenen Stand.

## 2026-07-24 – P12: Kataloggestützte Zielproduktauswahl

### Prüfkommandos

```text
swift test --disable-sandbox --scratch-path /private/tmp/NewEdenNexus-P12-debug
swift test --disable-sandbox -c release --scratch-path /private/tmp/NewEdenNexus-P12-release
Scripts/verify_xcode_project.py
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS,arch=arm64
  CODE_SIGNING_ALLOWED=NO COMPILER_INDEX_STORE_ENABLE=NO test
```

Die Xcode-Befehle wurden wegen einer reproduzierten File-Provider-Blockade
beim koordinierten Lesen der Projektdatei mit einer unveränderten isolierten
Kopie der erforderlichen Quellen und Projektmetadaten unter `/private/tmp`
ausgeführt. Signing- oder Teamwerte wurden nicht geändert.

Finale Ergebnisdateien:

- Debug:
  `/private/tmp/NewEdenNexus-P12-xcode-min-debug/Logs/Test/Test-NewEdenNexus-2026.07.24_08-21-28-+0200.xcresult`
- Release:
  `/private/tmp/NewEdenNexus-P12-xcode-min-release/Logs/Test/Test-NewEdenNexus-2026.07.24_08-21-58-+0200.xcresult`

### Ergebnis

- SwiftPM Debug: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **219 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- fokussierter P12-Lauf: **27 bestanden, 0 fehlgeschlagen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Abgedeckt sind Ziel- und Mengenvalidierung, Suche, Filter, Begrenzung,
explizite Aktivitäts-/Blueprintwahl, unvollständige Kandidaten, falsche
Blueprints, Versionswechsel, Cancellation, Projektlebenszyklus,
Repository-Roundtrip, v4→v5-Migration, vollständige Legacykette,
zweite Storeöffnung, Backups, ViewModel und UI-Architektur.

### Manueller Lauf

Das Debug-App-Bundle lief als echter isolierter Prozess. Der neu erzeugte
Store enthielt die erwarteten Schema-v5-Tabellen und alle fünf neuen
Projektzielfelder. Die Accessibility-Werkzeugverbindung brach auf
Transportebene ab und der Wiederholungsversuch endete im Werkzeugtimeout;
ein neuer visueller VoiceOver-Test wird daher nicht als bestanden behauptet.
Der finale Store
`/private/tmp/NewEdenNexus-P12-UIFinal-0822/NewEdenNexus.store` bestand
`quick_check` und enthielt alle fünf Zielspalten.

## 2026-07-24 – P13: Produktionsgraph und Schema v6

### Prüfkommandos

```text
swift test --disable-sandbox --scratch-path /private/tmp/nen-p13-final-debug
swift test -c release --disable-sandbox --scratch-path /private/tmp/nen-p13-final-release
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/nen-p13-xcode-review2-debug-escalated
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/nen-p13-xcode-review2-release-escalated
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
git diff --check
```

Die abschließenden Xcode-Befehle wurden aus der unveränderten isolierten
Prüfkopie `/private/tmp/nen-p13-xcode-review2` ausgeführt. Der direkte
sandboxgebundene Workspace-Lauf konnte das SwiftData-Makroplugin nicht
laden; der entsperrte Direktlauf blockierte an der bekannten
File-Provider-Koordination und wurde kontrolliert beendet. Das ist kein
Quellcodefehler. Signing- und Teamwerte wurden nicht geändert. Der
erfolgreiche Release-Lauf meldete vorübergehend fehlende
Module-Cache-Dateien als Warnungen; Exitcode und Tests blieben erfolgreich.
SwiftPM deaktivierte nicht beschreibbare Benutzer-Caches. Core Data meldete
bei temporären Sandbox-Teststores nicht verfügbare verteilte
Store-Change-Benachrichtigungen. Xcode wählte aus zwei passenden
My-Mac-Architekturen arm64. Keine dieser Warnungen führte zu einem
fehlgeschlagenen oder übersprungenen Test.

### Ergebnis

- SwiftPM Debug: **238 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **238 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **alle sieben Testtargets bestanden**, Exitcode 0.
- Xcode Release: **alle sieben Testtargets bestanden**, Exitcode 0.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
- Diff-Whitespaceprüfung: bestanden.

Abgedeckt sind Graphinvarianten, gleiche Type-ID in mehreren Vorkommen,
Zyklen und unerreichbare Knoten, Fertigungs- und Reaktionsrezepte,
Katalogversionsschutz, Bestandserhalt bei Fehler/Abbruch,
deterministische Topologie, Persistenzroundtrip, atomarer Ersatz,
beschädigte Payload, v5→v6-Migration, leerer v6-Store,
Backupkompatibilität, ViewModelzustände, Accessibility-Metadaten und
Schichtengrenzen.

### Manueller Lauf

Das isolierte Debug-App-Binary lief fünf Sekunden stabil und erzeugte einen
neuen Store. `PRAGMA integrity_check` meldete `ok`; die
Produktionsgraphtabelle war vorhanden. Der Prozess wurde danach kontrolliert
beendet.

Die Computer-Use-Verbindung für eine zusätzliche visuelle Prüfung war
geschlossen und der Wiederholungsversuch scheiterte am Werkzeugtransport.
Deshalb wird kein neuer visueller oder VoiceOver-Manuallauf als bestanden
behauptet.

### Reviewkorrekturen

Der gesonderte Review erkannte zwei Punkte vor der Freigabe:

1. Zyklusdiagnose war durch eine frühere Tiefenprüfung nicht in jedem Fall
   erreichbar; die Zyklusprüfung läuft nun zuerst.
2. Aktivität, Produktionszeit und Tiefe fehlten in der sichtbaren
   Graphmetadatenansicht; sie wurden ergänzt.
3. Das Graphrepository setzte bei Cancellation oder Savefehlern seine
   bereits vorgenommenen Kontextänderungen nicht ausdrücklich zurück; der
   Savepfad besitzt nun `modelContext.rollback()` und einen
   Architekturregressionstest.

Anschließend bestanden die vollständigen Debug-/Release-Nachweise.

## 2026-07-24 – P14: Runs, Graphformat 2 und Schema v7

### Prüfkommandos

```text
swift test --scratch-path /private/tmp/NewEdenNexus-P14-Debug.34groP/build -c debug
swift test --scratch-path /private/tmp/NewEdenNexus-P14-Release.dn2wzF/build -c release
Scripts/generate_xcode_project.sh
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P14-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P14-Xcode-Release
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
xcrun xcresulttool get test-results summary --path <Debug-xcresult>
xcrun xcresulttool get test-results summary --path <Release-xcresult>
git diff --check
```

SwiftPM verwendete vollständig getrennte Build- und Modulcaches.
Xcode verwendete getrennte DerivedData-Verzeichnisse. Signing und Teamwerte
blieben unverändert. Xcode wählte aus zwei passenden My-Mac-Zielen arm64.

### Ergebnis

- SwiftPM Debug: **253 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **253 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **253 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **253 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Abgedeckt sind Projektbuchreferenz 25/10, exakte Teilung, Output größer als
Ziel, `Int64.max`, Outputüberlauf, ungültige Eingaben, Codable-Manipulation,
Graphformat-1-/2-Invarianten, Fertigungs- und Reaktionsoutput,
Bestandserhalt bei Fehler/Abbruch, Repository-Roundtrip,
Formelmetadatenabgleich, v3→v7/v6→v7, zweite Storeöffnung,
Backupversionen 1.0.0 bis 7.0.0 sowie sichtbare Run-/Outputzustände.

### Gefundener und behobener Regressionsfehler

Der erste vollständige Debuglauf endete in der bestehenden
v3-Migrationsprüfung mit Signal 6 (`freed pointer was not the last
allocation`). Der Fehler war mit leerem Cache reproduzierbar. Ursache war
die zunächst nur nominelle Schema-v7-Stufe, die exakt dieselben
PersistentModel-Typen wie v6 wiederverwendete. Schema v7 erhielt daraufhin
eine echte additive `ProductionGraphRecord`-Version mit optionaler
`calculationFormulaVersion`. Die fokussierte Migrationsprüfung und alle vier
vollständigen Suites bestanden anschließend.

### Manueller Lauf

Das aus dem Xcode-Debuglauf gebaute App-Binary lief mehr als fünf Sekunden
mit einem isolierten Store unter `/private/tmp`. `PRAGMA integrity_check`
meldete `ok`; `ZPRODUCTIONGRAPHRECORD` enthielt die erwartete optionale
Spalte `ZCALCULATIONFORMULAVERSION`. Der Prozess wurde danach kontrolliert
beendet. Produktive Benutzerdaten wurden nicht verwendet.

## 2026-07-24 – P15: Material Efficiency, Graphformat 3 und Schema v8

### Prüfkommandos

```text
env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P15-Debug/module-cache
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P15-Debug/module-cache
  swift test --scratch-path /private/tmp/NewEdenNexus-P15-Debug/build -c debug

env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P15-Release/module-cache
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P15-Release/module-cache
  swift test --scratch-path /private/tmp/NewEdenNexus-P15-Release/build -c release

Scripts/generate_xcode_project.sh
python3 Scripts/verify_xcode_project.py

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P15-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P15-Xcode-Release
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test

xcrun xcresulttool get test-results summary --path <Debug-xcresult>
xcrun xcresulttool get test-results summary --path <Release-xcresult>
git diff --check
```

SwiftPM verwendete getrennte Build- und Modulcaches. Xcode verwendete
getrennte DerivedData-Verzeichnisse. Signing und Teamwerte blieben
unverändert; Xcode wählte arm64 „My Mac“.

Die ersten in der äußeren Sandbox ausgeführten SwiftPM-/Xcode-Aufrufe
scheiterten an `sandbox_apply: Operation not permitted` beziehungsweise
nicht startbaren SwiftData-Makroplugins. Die identischen Befehle wurden
außerhalb dieser äußeren Sandbox erfolgreich wiederholt.

### Ergebnis

- SwiftPM Debug: **273 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **273 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **273 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **273 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
- `git diff --check`: bestanden.

Abgedeckt sind ME 0/10, einmalige Jobaufrundung, Ein-Stück-je-Run-Schutz,
Reaktionen ohne Blueprint-ME, ungültige Werte, Formelversion,
Rohmengen-/Reduktionszählerüberlauf, Codable-Manipulation,
Projektlebenszyklus, Graphformat 1/2/3, Stale-Erkennung,
Bestandserhalt bei Fehler/Abbruch, Repository-Metadatenabgleich,
v3→v8/v7→v8, zweite Storeöffnung, Backupversionen 1.0.0 bis 8.0.0 sowie
UI-/Accessibility-/Architekturgrenzen.

### Gefundene und behobene Probleme

Der erste fokussierte Migrationstest griff nach erfolgreicher Migration mit
einem historischen Modelltyp auf den aktuellen Store zu und endete mit
Signal 6. Die Prüfung wurde auf `NexusSchemaV8` korrigiert. Ein danach
sichtbarer falsch positionierter Testparameter wurde ebenfalls korrigiert.
Fokussierte und alle vier vollständigen Suites bestanden anschließend.

### Manueller Lauf

Das Xcode-Debug-App-Binary lief länger als fünf Sekunden mit
`/private/tmp/NewEdenNexus-P15-Smoke/P15.store`.
`PRAGMA integrity_check` meldete `ok`; die Tabellen enthielten
`ZMATERIALEFFICIENCY` und `ZMATERIALFORMULAVERSION`. Der Prozess wurde
kontrolliert beendet. Produktive Benutzerdaten wurden nicht geöffnet.

## 2026-07-24 – P16: Rekursive T1-Berechnung und Graphformat 4

### Prüfkommandos

```text
env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P16-Debug/module-cache
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P16-Debug/module-cache
  swift test --scratch-path /private/tmp/NewEdenNexus-P16-Debug/build -c debug

env SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P16-Release/module-cache
  CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P16-Release/module-cache
  swift test --scratch-path /private/tmp/NewEdenNexus-P16-Release/build -c release

Scripts/generate_xcode_project.sh
python3 Scripts/verify_xcode_project.py

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P16-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test

xcodebuild -quiet -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P16-Xcode-Release
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
```

### Ergebnis

- SwiftPM Debug: **280 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **280 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **280 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **280 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Abgedeckt sind dreistufige T1-Referenzwerte, deterministische Wiederholung,
gleiche Typen in getrennten Vorkommen, Reaktionsgrenzen, Stufen-ME,
Kanten-/Sollmengenkopplung, mehrdeutige und ungelöste Rezepte, Zyklus,
Tiefe, Knotenlimit, Cancellation, Run-/Materialüberlauf, Altgraph-Erhalt,
Format 1 bis 4, Persistenzmetadaten, unverändertes Schema v8 sowie
UI-/ViewModel-/Architekturgrenzen.

Der erste vollständige Debuglauf nach Einführung von Format 4 zeigte 21
erwartbare Testfehler, weil frühere Tests den damaligen `current`-Alias als
Format 3 verwendeten. Die Altformatprüfungen wurden ausdrücklich auf Format
3 festgelegt und aktuelle Fixtures auf Format 4 ergänzt. Fokussierte und
alle vier vollständigen Abnahmeläufe bestanden danach.

### Manueller Lauf

Das Xcode-Debug-App-Binary lief sechs Sekunden mit
`/private/tmp/NewEdenNexus-P16-Smoke/P16.store`.
`PRAGMA integrity_check` meldete `ok`; das App-Log blieb leer. Der Prozess
wurde kontrolliert beendet. Produktive Benutzerdaten wurden nicht geöffnet.

## 2026-07-24 – P17: T2-Berechnung und Graphformat 5

### Prüfkommandos

```text
swift test --scratch-path /private/tmp/NewEdenNexus-P17-swiftpm/build
swift test --scratch-path /private/tmp/NewEdenNexus-P17-Release/build -c release
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P17-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P17-Xcode-Release
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test
```

Xcode wurde wegen eines mit `sample` nachgewiesenen
`NSFileCoordinator`-Locks der geöffneten Repository-Projektdatei aus einer
identischen isolierten Quellkopie ausgeführt.

### Ergebnis

- SwiftPM Debug: **292 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **292 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **292 bestanden, 0 fehlgeschlagen**.
- Xcode Release: **292 bestanden, 0 fehlgeschlagen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Der Real-SDE-Lauf für Build 3444265 bestätigte T2-Blueprint 11372 aus
Blueprint 691, Grundrun 1, Wahrscheinlichkeit 0,3, Datacores 20172/20424,
alle Katalogmengen, Wiederöffnung, Backup und Cleanup. Die acht
Decryptor-Type-IDs 34201 bis 34208 wurden über die offiziellen öffentlichen
CCP-ESI-Type-Endpunkte gegen Namen und Modifier geprüft.

### Gefundene und behobene Probleme

- Reverse Engineering/T3 wurde durch die zusätzliche
  Manufacturing-Prüfung des Ausgangs-Blueprints typisiert abgegrenzt.
- Graphformat-5-Knotenqualität wurde an Build und Inhaltshash des Graphen
  gebunden.
- Frühere aktuelle Testfixtures wurden mit expliziter Katalogprovenienz
  ergänzt.

### Manueller Lauf

Das Xcode-Debug-App-Binary lief fünf Sekunden mit
`/private/tmp/NewEdenNexus-P17-App-Smoke/NewEdenNexus.store`.
`PRAGMA integrity_check` meldete `ok`. Der Prozess wurde kontrolliert
beendet; produktive Benutzerdaten wurden nicht geöffnet. Keine neue
visuelle oder VoiceOver-Prüfung.

## 2026-07-24 – P18: Reaktionsstufen und Graphformat 6

### Prüfkommandos

```text
swift test --scratch-path /private/tmp/NewEdenNexus-P18-SwiftPM
swift test -c release --scratch-path /private/tmp/NewEdenNexus-P18-SwiftPM-Release
NEN_REAL_SDE_DIRECTORY=/private/tmp/nen-p18-sde-inspect
  NEN_REAL_SDE_BUILD=3444265 swift test
  --filter OfficialSDEPersistenceIntegrationTests
./Scripts/verify_xcode_project.py
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P18-Final-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P18-Final-Xcode-Release
  CODE_SIGNING_ALLOWED=NO test
```

### Ergebnis

- SwiftPM Debug: **310 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **310 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **310 bestanden, 0 fehlgeschlagen**.
- Xcode Release: **310 bestanden, 0 fehlgeschlagen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
- offizieller SDE-Build 3444265: isolierter Import, Wiederöffnung,
  Composite-/Hybrid-/Biochemical-Profil und reine Reaktionsaktivität
  bestanden.

Abgedeckt sind neutrale und modifizierte Kontexte, Facility/Reactor/Rig,
Securityskalierung, Skillfaktor, Rundung, Überlauf, Manipulationsschutz,
Manufacturing-/Reaction-Rekursion, Mischzyklen, Format 1 bis 6,
Schema-v8→v9, Leerstore, Backup 9.0.0 und Altgraph-Erhalt.

### Manueller Lauf

Das finale Xcode-Debug-App-Binary lief mit dem isolierten Store
`/private/tmp/NewEdenNexus-P18-Final-App.3JxBnM/P18.store`. Während und nach
dem Lauf meldete `PRAGMA integrity_check` `ok`; `ProductionProject`,
`ProductionGraphRecord` und `ReactionRuleRecord` waren im Schema vorhanden.
Der Prozess wurde kontrolliert beendet. Keine produktiven Benutzerdaten,
visuelle oder VoiceOver-Abnahme.

## 2026-07-24 – P19: Aggregation und Graphschutz

### Befehle

Aus einer per `rsync` erzeugten identischen Quellkopie
`/private/tmp/NewEdenNexus-P19-Verify.Yy0hCF`:

```text
env HOME=/private/tmp/nen-p19-home
  CLANG_MODULE_CACHE_PATH=/private/tmp/nen-p19-clang
  swift test --disable-sandbox
  --scratch-path /private/tmp/nen-p19-temp-build

swift test --disable-sandbox
  --scratch-path /private/tmp/nen-p19-temp-build-release -c release

xcodebuild -list -project NewEdenNexus.xcodeproj

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P19-Xcode-Debug
  CODE_SIGNING_ALLOWED=NO test -quiet

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P19-Xcode-Release
  CODE_SIGNING_ALLOWED=NO test -quiet

xcrun xcresulttool get test-results summary --path
  /private/tmp/NewEdenNexus-P19-Xcode-Debug/Logs/Test/
  Test-NewEdenNexus-2026.07.24_19-07-56-+0200.xcresult

xcrun xcresulttool get test-results summary --path
  /private/tmp/NewEdenNexus-P19-Xcode-Release/Logs/Test/
  Test-NewEdenNexus-2026.07.24_19-08-46-+0200.xcresult

python3 Scripts/verify_xcode_project.py
```

### Ergebnis

- SwiftPM Debug: **321 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **321 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **321 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **321 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
- Xcode-Projekt: Debug/Release sowie acht erkennbare Schemes; App-Scheme mit
  allen sieben Testtargets.

Die elf neuen P19-Fälle decken Type-ID-Gruppierung, Zwischenprodukt-
Ausschluss, Namen/IDs, Vorkommenspfade, Determinismus, `Int64.max`,
Summenüberlauf mit Altgraph-Erhalt, fehlende Mengen/Pfade, Zyklus,
Geschwister-Sortierkollision, geladene Tiefe/Knotenlimits,
Format-7-Roundtrip, Format-6-Lesbarkeit, manipulierte Aggregation und
sichtbare UI-Grenzen ab.

### Umgebungsdiagnosen

Der erste direkte Workspace-Lauf von `swift test --disable-sandbox` brach
mit „input file modified during build“ ab; ein weiterer Lauf ohne
umgeleiteten Modulcache konnte die Swift-Modulcache-Datei in der
Dateisandbox nicht schreiben. Beides ist kein bestandener Test. Die
identische temporäre Quellkopie beseitigte die konkurrierende Buildgrenze;
alle vier Abschlussläufe waren erfolgreich.

Im temporären Debug-Testhost erschienen die bereits bekannten,
nicht fehlschlagenden SwiftPM-Cache- und Core-Data-
Store-Change-Notification-Diagnosen. Es wurden keine Warnungen
unterdrückt und keine Signing- oder Teameinstellungen verändert.

### Manueller Lauf

Das finale Debug-App-Binary lief mit
`/private/tmp/NewEdenNexus-P19-App.BC5lz9/P19.store`. Während und nach dem
Lauf meldete `PRAGMA integrity_check` `ok`; `ProductionProject`,
`ProductionGraphRecord` und `ReactionRuleRecord` waren vorhanden. Der
Prozess wurde kontrolliert beendet. Keine produktiven Benutzerdaten und
keine neue visuelle oder VoiceOver-Abnahme.

## 2026-07-24 – P20: Lager und manuelle Bestände

### Prüfkommandos

```text
SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p20-module-cache
  CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p20-clang-cache
  swift test --disable-sandbox
  --scratch-path /tmp/new-eden-nexus-p20-build

SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p20-release-module-cache
  CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p20-release-clang-cache
  swift test -c release --disable-sandbox
  --scratch-path /tmp/new-eden-nexus-p20-release-build

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p20-xcode-debug
  CODE_SIGNING_ALLOWED=NO -quiet test

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p20-xcode-release
  CODE_SIGNING_ALLOWED=NO -quiet test

python3 Scripts/verify_xcode_project.py
git diff --check
```

### Ergebnis

- SwiftPM Debug: **335 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **335 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **335 erfolgreich, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **335 erfolgreich, 0 fehlgeschlagen, 0 übersprungen**.
- Die Xcode-Ergebnisdatenbanken enthalten je 335 `TestCases` und
  ausschließlich 335 `Success`-Einträge in `TestCaseRuns`.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.
- `git diff --check`: ohne Befund.

Die 14 neuen Prüfungen decken Domaininvarianten, Lagerlebenszyklus,
normalisierte Eindeutigkeit, Katalogvalidierung, positive `Int64`-Mengen,
Update-statt-Addition, getrennte Lager, Archivschreibschutz,
positionsgenaues Löschen, Repository-Roundtrip, v9→v10-Migration,
Backupkompatibilität und die UI-/Schichtengrenze ab.

### Warnungen und nicht ausgeführte Prüfungen

- SwiftPM meldete wegen der eingeschränkten Umgebung nicht schreibbare
  benutzerweite Cacheverzeichnisse; projektbezogene Modul- und Scratchpfade
  waren explizit umgeleitet. Tests und Builds waren davon nicht betroffen.
- Xcode meldete mehrere passende Mac-Ziele und verwendete wie angefordert
  das erste passende lokale Ziel. Signing und Teamwerte wurden nicht
  verändert.
- Nach `swift package clean` waren einzelne iCloud-Dateien lokal
  ausgelagert. Sie wurden über den systemeigenen Downloadmechanismus wieder
  lokal verfügbar gemacht; keine Projektdatei wurde gelöscht oder inhaltlich
  verändert.
- Der erste Xcode-Lauf innerhalb der Dateisandbox konnte den
  SwiftData-Makroserver nicht starten. Die belegten Abschlussläufe erfolgten
  deshalb mit ausdrücklicher Freigabe außerhalb der Sandbox.
- Keine neue visuelle VoiceOver-Sitzung wurde durchgeführt. Die
  P20-Oberfläche ist über Quellarchitektur-, Beschriftungs- und
  Aktionsgrenztests geprüft; die vollständige Bedienabnahme bleibt P35/P37.

## 2026-07-24 – P21: CSV-Bestandsimport

### Prüfkommandos

```text
SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p21-final-debug-module-cache
  CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p21-final-debug-clang-cache
  swift test --disable-sandbox
  --scratch-path /tmp/new-eden-nexus-p21-final-debug-build

SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p21-final-release-module-cache
  CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p21-final-release-clang-cache
  swift test -c release --disable-sandbox
  --scratch-path /tmp/new-eden-nexus-p21-final-release-build

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p21-final-xcode-debug
  -resultBundlePath /tmp/new-eden-nexus-p21-final-debug.xcresult
  CODE_SIGNING_ALLOWED=NO -quiet test

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p21-final-xcode-release
  -resultBundlePath /tmp/new-eden-nexus-p21-final-release.xcresult
  CODE_SIGNING_ALLOWED=NO -quiet test

python3 Scripts/verify_xcode_project.py
git diff --check
```

### Ergebnis

- SwiftPM Debug: **353 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **353 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **353 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **353 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Projektparität: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Die 18 neuen Prüfungen decken UTF-8/UTF-16/Windows-Kodierungen,
Delimiterwahl, Quotes, CR/LF/CRLF, mehrzeilige Felder, Datei-/Zeilenlimits,
10.000 Datenzeilen, Dateihash, Vorschau ohne Schreiben,
Mengen-/Duplikat-/Katalogfehler, Bestätigung, Einzelentscheidungen,
Abbruch, Stale-State-Schutz, atomaren Bericht, Rollback, v10→v11-Migration,
zweite Öffnung, Leerstore, Backupkompatibilität und UI-Schichtengrenzen ab.

### Fehlerhistorie und Umgebungsdiagnosen

- Der erste vollständige Lauf fand einen echten CRLF-Parserfehler. Swift
  liefert CRLF als ein `Character`; die zentrale Zeilenendeprüfung und
  Regressionstests beheben den Fehler.
- Die abschließende Reviewprüfung ergänzte einen Randfall, damit doppelte
  Type-IDs auch dann vollständig blockiert werden, wenn eine der Zeilen
  zusätzlich eine ungültige Menge enthält.
- Der erste Xcode-Lauf innerhalb der Dateisandbox konnte den
  SwiftData-Makroserver nicht starten und gilt nicht als Erfolg.
  Die nachgewiesenen Xcode-Abschlussläufe erfolgten mit freigegebener
  Ausführung und isolierten Derived-Data-Pfaden.
- SwiftPM meldete nicht schreibbare benutzerweite Cacheverzeichnisse;
  Modul- und Scratchpfade waren explizit temporär umgeleitet.
- Signing- und Teamwerte wurden nicht verändert.

### Manueller Lauf

Das Debug-App-Binary lief fünf Sekunden mit
`--new-eden-nexus-isolated-store /tmp/new-eden-nexus-p21-manual.store` und
wurde kontrolliert beendet. `PRAGMA integrity_check` meldete `ok`. Keine
produktiven Benutzerdaten und keine neue visuelle VoiceOver-Abnahme.

## 2026-07-24 – P22: Verfügbarkeit und Ausschlüsse

### Prüfkommandos

```text
env CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p22-clang-cache
  SWIFT_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p22-swift-cache
  swift test --scratch-path /tmp/new-eden-nexus-p22-full-debug

env CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p22-clang-release
  SWIFT_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p22-swift-release
  swift test -c release
  --scratch-path /tmp/new-eden-nexus-p22-full-release

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p22-xcode-debug
  -resultBundlePath /tmp/new-eden-nexus-p22-xcode-debug.xcresult
  CODE_SIGNING_ALLOWED=NO test

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p22-xcode-release
  -resultBundlePath /tmp/new-eden-nexus-p22-xcode-release.xcresult
  CODE_SIGNING_ALLOWED=NO test

xcrun xcresulttool get test-results summary --path <Ergebnisbundle>
./Scripts/generate_xcode_project.sh
sqlite3 /tmp/new-eden-nexus-p22-manual.store "PRAGMA integrity_check;"
git diff --check
```

### Ergebnis

- SwiftPM Debug: **371 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **371 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **371 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **371 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Projektgenerator: 15 Targets, sieben Testtargets, zwei gemeinsame
  Schemes; Konsistenzprüfung erfolgreich.

18 neue Tests decken Freigabemodi, Archiv- und Lagerauswahl,
Materialausschluss, Obergrenze, Ausschlusspriorität, Surplus,
Determinismus, Duplikate, `Int64`-Überlauf, fehlenden/veralteten Graph,
Preview ohne Schreiben, Bestätigung, Stale-State, Cancellation,
ungenutzte gespeicherte Regeln, Repository-Roundtrip, v11→v12-Migration,
zweite Öffnung und v12-Leerstore ab. Der bestehende Backuptest prüft nun
1.0.0 bis 12.0.0 und lehnt 13.0.0 ab.

### Fehlerhistorie und Umgebungsdiagnosen

- Der erste fokussierte Compile fand einen unzulässigen Instanzaufruf in
  einem Test-Defaultparameter; der Test verwendet nun einen expliziten
  optionalen Wert.
- Ein erster Stale-Graph-Test änderte nur den Projektzeitstempel. Da
  nichtfachliche Projektänderungen den Graph nicht veralten, prüft der
  Referenzfall nun korrekt eine geänderte Zielmenge.
- Der Review fand eine Cancellation-Prüfung nach dem atomaren Commit. Sie
  wurde entfernt; der neue Regressionstest bestätigt, dass ein bereits
  gespeichertes Ergebnis auch bei unmittelbar folgender Cancellation als
  erfolgreich zurückgegeben wird.
- SwiftPM und Xcode benötigten außerhalb der Dateisandbox Zugriff auf
  Compiler-/SwiftData-Makrocaches. Alle belegten Läufe verwendeten
  isolierte temporäre Buildpfade.
- Xcode meldete mehrere passende Architekturen desselben lokalen Mac und
  wählte arm64. Signing und Teamwerte wurden nicht verändert.

### Manueller Lauf

Das Debug-App-Binary lief mit
`--new-eden-nexus-isolated-store /tmp/new-eden-nexus-p22-manual.store`
stabil und wurde kontrolliert beendet. `PRAGMA integrity_check` meldete
`ok`; die Tabellen für Projekt, Bestand und
`InventoryAvailabilityConfigurationRecord` waren vorhanden. Keine
produktiven Benutzerdaten und keine neue visuelle VoiceOver-Abnahme.

## 2026-07-25 – P23 Sicherheitsbestände

### Befehle

```text
swift test --filter SafetyStock
swift test
swift test -c release

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p23-xcode-debug-final
  -resultBundlePath /tmp/new-eden-nexus-p23-xcode-debug-final.xcresult
  CODE_SIGNING_ALLOWED=NO test

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS
  -derivedDataPath /tmp/new-eden-nexus-p23-xcode-release-final
  -resultBundlePath /tmp/new-eden-nexus-p23-xcode-release-final.xcresult
  CODE_SIGNING_ALLOWED=NO test

xcrun xcresulttool get test-results summary --compact
  --path <Ergebnisbundle>
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
sqlite3 /tmp/new-eden-nexus-p23-manual.store "PRAGMA integrity_check;"
git diff --check
```

### Ergebnis

- Fokussierter P23-Lauf: **17 bestanden, 0 fehlgeschlagen**.
- SwiftPM Debug: **388 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- SwiftPM Release: **388 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Debug: **388 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode Release: **388 bestanden, 0 fehlgeschlagen, 0 übersprungen**.
- Xcode-Ergebnisbundles bestätigen jeweils `Passed`; Signing war
  ausgeschaltet, Teamwerte blieben unverändert.

Die 17 neuen P23-Tests prüfen unverändertes P22-Verhalten ohne Regel,
außerhalb P22 gedeckten Schutz, teilweise und vollständige Schutzwirkung,
archivierte Bestände, unabhängige Schwellen, Zielauffüllung, ungültige und
maximale Werte, schreibfreie Vorschau, Bestätigung, geänderte P22- und
Regelzustände, Repository-Rennen, Cancellation vor und nach Commit,
atomare Anlage/Änderung/Löschung, Roundtrip, v12→v13-Migration, Leerstore
und Wiederöffnung. Der Architekturtest prüft zusätzlich die
persistenzfreie UI-Schicht.

### Fehlerhistorie und Umgebungsdiagnosen

- Der Review fand, dass ein Repository-Rennen zunächst als allgemeiner
  Persistenzfehler gemeldet worden wäre. Adapter und Application-Service
  verwenden nun einen typisierten Stale-State-Vertrag; ein Regressionstest
  deckt diese Grenze.
- Die P22-ViewModel-Grenze enthielt noch eine Cancellation-Prüfung nach
  erfolgreichem Commit. Sie wurde entfernt, damit ein gespeicherter Erfolg
  nicht als Abbruch erscheint.
- Der erste SwiftPM-Lauf innerhalb der Dateisandbox konnte den
  Clang-Modulcache nicht beschreiben. Die belegten Läufe wurden mit
  isolierten temporären Cache-/Buildpfaden außerhalb dieser Beschränkung
  wiederholt.
- Xcode meldete mehrere passende Architekturen desselben Macs und wählte
  arm64. Core Data gab in Migrationstests nicht fehlschlagende Hinweise
  über bereits von einem anderen Client abgeschlossene Migrationen aus.

### Manueller Lauf

Das Debug-App-Binary lief mit
`--new-eden-nexus-isolated-store /tmp/new-eden-nexus-p23-manual.store`
stabil und wurde kontrolliert beendet. `PRAGMA integrity_check` meldete
`ok`; `StockPolicyRecord`, `InventoryAvailabilityConfigurationRecord` und
`ProductionProject` waren im isolierten Schema-v13-Store vorhanden. Keine
produktiven Benutzerdaten wurden geöffnet oder verändert.

## 2026-07-25 – P24 Projektreservierungen

### Befehle

```text
swift test --filter ProjectReservation
swift test
swift test -c release

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath <isolierter-temporaerer-Debugpfad>
  CODE_SIGNING_ALLOWED=NO test

xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Release -destination platform=macOS,arch=arm64
  -derivedDataPath <isolierter-temporaerer-Releasepfad>
  CODE_SIGNING_ALLOWED=NO test

xcrun xcresulttool get test-results summary --compact
  --path <Ergebnisbundle>
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
sqlite3 /tmp/new-eden-nexus-p24-manual.store "PRAGMA integrity_check;"
git diff --check
```

### Ergebnis

- fokussierter P24-Lauf: **20 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **408 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- SwiftPM Release: **408 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **408 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Release: **408 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Ergebnisbundles bestätigen jeweils `Passed`; Signing war
  ausgeschaltet, Teamwerte blieben unverändert.

Die P24-Prüfungen decken eigene und fremde Bindungen, Überbuchung,
`Int64`-Überlauf, Priorität, Ablaufhinweis, Teil- und Vollverbrauch,
Freigabe, Historie, schreibfreie Vorschau, Bestätigung, geänderte
P22-/P23-/Reservierungszustände, Repository-Rennen, Abbruch, atomaren
Roundtrip, unbekanntes und archiviertes Projekt, Archivschutz,
Projektduplikation ohne Reservierungen, v13→v14-Migration, v14-Leerstore,
zweite Öffnung und Backupkompatibilität ab. Der Architekturtest prüft die
persistenzfreie UI-Schicht.

### Fehlerhistorie und Umgebungsdiagnosen

- Der gesonderte Review fand vier fehlende explizite Persistenzfälle:
  Roundtrip aller vier Statuswerte, leerer v14-Initialstore, unbekanntes
  Projekt und Duplikation ohne Reservierungsübernahme. Nach Ergänzung
  bestanden 20 fokussierte und alle vollständigen Tests.
- Der erste SwiftPM-Lauf innerhalb der Dateisandbox scheiterte an
  `sandbox-exec: sandbox_apply: Operation not permitted`. Die belegten
  Läufe wurden mit isolierten temporären Buildpfaden erfolgreich
  wiederholt.
- Das direkt geöffnete Xcode-Projekt blockierte den CLI-Zugriff über
  `NSFileCoordinator`. Um ungespeicherte Benutzerarbeit nicht zu schließen,
  liefen Xcode Build und Test über eine temporäre Projektkopie mit
  verlinkten unveränderten Quellen.
- Xcode meldete nicht fehlschlagende Binäranalysehinweise für
  XCTest-Unterframeworks und einen übersprungenen AppIntents-
  Metadatenextraktor, weil keine AppIntents-Abhängigkeit besteht.

### Manueller Lauf

Das Debug-App-Binary lief mit
`--new-eden-nexus-isolated-store /tmp/new-eden-nexus-p24-manual.store`
stabil und wurde kontrolliert beendet. `PRAGMA integrity_check` meldete
während und nach dem Lauf `ok`; Projekt-, Schutzregel- und
Reservierungstabellen waren im isolierten Schema-v14-Store vorhanden.
Keine produktiven Benutzerdaten wurden geöffnet oder verändert.

## 2026-07-25 – P25 Reservierungskonflikte

### Befehle

```text
env CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p25-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p25-module-cache
  swift test --scratch-path /tmp/new-eden-nexus-p25-focused
  --filter 'ReservationConflict|ProjectReservationPersistence'

env CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p25-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p25-module-cache
  swift test --scratch-path /tmp/new-eden-nexus-p25-full-debug

env CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p25-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p25-module-cache
  swift test -c release
  --scratch-path /tmp/new-eden-nexus-p25-full-release

swift build
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py

xcodebuild test
  -project /tmp/new-eden-nexus-p25-xcode.EsBRGY/NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /tmp/new-eden-nexus-p25-xcode-debug-isolated
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES

xcodebuild test
  -project /tmp/new-eden-nexus-p25-xcode.EsBRGY/NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Release
  -destination platform=macOS,arch=arm64
  -derivedDataPath /tmp/new-eden-nexus-p25-xcode-release-isolated
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES
```

### Ergebnis

- fokussiert: **21 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **423 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- SwiftPM Release: **423 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **423 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Release: **423 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Die Tests decken Bestandsunterdeckung, Bedarfsüberschreitung, nicht mehr
benötigte Bindungen, Prioritätsreihenfolge, Ablaufwarnung,
`Int64`-Überlauf, Preview-before-write, Bestätigung, unvollständige
Auflösung, Abbruch, veralteten Source-State, atomare Mehrprojektänderung,
Fehlercodes und persistenzfreie UI-Grenzen ab.

### Fehlerhistorie und Umgebungsdiagnosen

- Der abschließende fokussierte Kontrolllauf konnte sein SwiftPM-Manifest
  innerhalb der Dateisandbox zunächst nicht kompilieren
  (`sandbox_apply: Operation not permitted`). Derselbe unveränderte Befehl
  wurde mit freigegebener SwiftPM-Ausführung wiederholt und bestand 21/21
  Tests.
- Eine fokussierte Testfixture enthielt zunächst eine zusätzliche aktive,
  verwaiste Bindung und erzeugte damit korrekt einen weiteren Konflikt.
  Die als „unverändert“ gedachte Vergleichsreservierung wurde terminal
  modelliert; danach bestanden 21/21 Tests.
- Das direkt geöffnete Repositoryprojekt blockierte den CLI-Xcode-Zugriff
  über `NSFileCoordinator`. Es wurde nur der wartende Testprozess
  abgebrochen. Debug und Release liefen anschließend erfolgreich über eine
  temporäre Projektkopie mit verlinkten unveränderten Quellen.
- Xcode meldete nicht fehlschlagende AppIntents-Metadaten- und
  Test-Preferences-Hinweise. Es wurden keine Warnungen unterdrückt und
  keine Signing-/Teamwerte geändert.

### Manueller Lauf

Das isolierte Debug-App-Binary lief zwei Sekunden stabil mit
`--new-eden-nexus-isolated-store
/tmp/new-eden-nexus-p25-manual.store` und wurde kontrolliert beendet.
`PRAGMA integrity_check` meldete während und nach dem Lauf `ok`;
Projekt- und Reservierungstabellen waren vorhanden. Der isolierte Store
enthielt keine Reservierungen. Produktive Benutzerdaten wurden nicht
geöffnet oder verändert.

## 2026-07-25 – P26 Build-or-Buy

### Befehle

```text
swift test -c debug --filter BuildOrBuy
swift test -c debug
./Scripts/generate_xcode_project.sh
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /tmp/new-eden-nexus-p26-xcode-debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES
```

### Ergebnis

- fokussiert: **11 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **434 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **434 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projektprüfung: 15 Targets, sieben Testtargets, zwei Schemes.

Geprüft wurden T1-Bauen, exakter Kaufschnitt, Zwischen- und Rohbestand,
Sicherheitsbestand, fremde Reservierungen, T2-Inventionsmaterialien,
ungültige/veraltete Entscheidungen, Bestätigung, optimistischer
Parallelitätsschutz, v14→v15-Migration, Leerstore, Wiederöffnung,
Projektduplikat-Standard und Backupformat 15.0.0.

Der erste SwiftPM-Aufruf war innerhalb der Dateisandbox nur wegen des
gesperrten Compiler-Modulcaches nicht ausführbar. Nach Freigabe bestand
derselbe Quellstand. Ein inkonsistenter generierter `.build`-Cache wurde
mit `swift package clean` bereinigt. Der Review fand zunächst fehlende
P26-Dateien im Xcode-Projekt; die bestehende XcodeGen-Quelle korrigierte
die Parität vor dem erfolgreichen Xcode-Lauf.

## 2026-07-25 – P32 Integrierter Produktionsworkspace

### Befehle

```text
swift build -c debug
swift test -c debug
swift test -c debug --filter
  'BuildOrBuyWorkspaceViewModelTests|
   ProductionWorkspaceArchitectureTests|
   ErrorHandlingTests'
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p32-xcode-debug-final
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES
xcrun xcresulttool get test-results summary
```

### Ergebnis

- fokussiert: **8 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **439 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **439 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: 15 Targets, sieben Testtargets, zwei gemeinsame Schemes.

Die fokussierten Prüfungen decken T1-Bauen/Kaufen, T2-Inventionsjob,
Lagerabzug, deterministische positive Textliste, gesperrte veraltete Liste,
projektfremde Vorschau, schmale/breite SwiftUI-Rendergröße,
persistenzfreie UI-Grenzen, Tastatur-/Accessibility-Verträge und die neue
sichere Fehlerzuordnung ab.

Der erste Testrun zeigte ausschließlich fehlerhafte neue Testprovenienz; die
Fixtures wurden an die bereits produktiv validierten Graphregeln angepasst.
Der native Computer-Use-Kanal schloss bei der isolierten GUI-Sichtprüfung vor
einer auswertbaren Antwort. Es wird daher kein manueller GUI-/VoiceOver-Test
behauptet. Render- und Quellarchitekturprüfungen bestanden reproduzierbar.

## 2026-07-25 – P37 Interne Kernabnahme

### Befehle

```text
swift test -c debug --filter
  'P37CoreAcceptanceTests|
   AppSourceArchitectureTests|
   BuildOrBuyWorkspaceViewModelTests|
   BuildOrBuyPlanningServiceTests|
   BuildOrBuyPlanTests|
   ReservationConflictTests|
   ReservationConflictServiceTests|
   ProductionWorkspaceArchitectureTests'
swift build -c debug
swift test -c debug --quiet
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p37-xcode-debug-final
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
  --path /private/tmp/new-eden-nexus-p37-xcode-debug-final/Logs/Test/
         Test-NewEdenNexus-2026.07.25_21-54-47-+0200.xcresult
```

### Ergebnis

- fokussierte P37-Matrix: **29 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **440 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **440 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projektprüfung: **15 Targets, sieben Testtargets, zwei gemeinsame
  Schemes**,
- isolierter Start des erzeugten App-Bundles: Prozess blieb lauffähig,
  der neue Schema-v15-Store wurde angelegt und `PRAGMA integrity_check`
  meldete `ok`.

Die neue persistente Kernabnahme prüft einen mehrstufigen T1-Fall mit
Zwischenbestand und Rohstofffehlmenge sowie einen T2-Fall mit Invention,
Datacores, gekauftem Zwischenprodukt und Lagerabzug. Beide Pläne werden nach
Schließen und Wiederöffnen desselben isolierten SwiftData-Stores exakt
reproduziert. Zusätzlich wurden Reservierungskonflikte, Workspace-Grenzen und
der korrigierte rechtliche Hinweis regressionsgeprüft.

Der erste SwiftPM-Aufruf innerhalb der Dateisandbox scheiterte ausschließlich
am gesperrten Compiler-Modulcache; derselbe Quellstand wurde anschließend im
freigegebenen Buildpfad geprüft. Während der Testentwicklung wurden ein
Swift-XCTest-Autoclosure-Compilefehler und eine falsche Testannahme zur
Bedeutung von `requestedQuantity` korrigiert. Produktiver Code wurde dafür
nicht verändert. Es wurden weder reale SDE-Daten noch produktive
Benutzerdaten verwendet. Ein öffentlicher Release, ein manueller
GUI-/VoiceOver-Test und der externe Prozessabbruch aus P36 sind nicht
Bestandteil dieses Nachweises.

## 2026-07-25 – P27 Manuelle Preise und Preisprofile

### Befehle

```text
swift build -c debug
swift test -c debug --filter
  'PriceProfileTests|
   PriceProfileManagementServiceTests|
   PriceProfilePersistenceTests|
   PriceProfileViewModelTests|
   PriceProfileArchitectureTests'
swift test -c debug --quiet
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p27-xcode-debug-review
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
```

### Ergebnis

- fokussiert: **13 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **453 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **453 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: **15 Targets, sieben Testtargets, zwei Schemes**,
- isolierter App-Start: Prozess blieb lauffähig; der Schema-v16-Store
  enthielt beide neuen Tabellen und `PRAGMA integrity_check` meldete `ok`.

Geprüft wurden exakte ISK-Parsierung, Profile, Aktivierung, Eindeutigkeit,
Item-/SDE-Bindung, Upsert, Gültigkeit, fehlende Preise, bestätigtes Löschen,
Kaskade, Wiederöffnung, v15→v16-Migration, Leerstore und Backupformat 16.0.0.

Der erste SwiftPM-Build und der erste Xcode-Lauf scheiterten ausschließlich
an gesperrten Sandbox-Compiler-/Makrodiensten; die freigegebenen identischen
Läufe bestanden. Ein Compilefehler in neuen Tests durch `await` innerhalb
einer XCTest-Autoclosure wurde korrigiert. Der Review ersetzte eine
localeabhängige Profilreihenfolge; danach bestanden beide vollständigen
Suiten erneut. Ein manueller GUI-/VoiceOver-Test wurde nicht durchgeführt.

## 2026-07-25 – P28 CSV-Preisimport

### Befehle

```text
swift build -c debug
swift package clean
swift test -c debug --filter
  'PriceCSVImportServiceTests|
   PriceCSVImportPersistenceTests|
   PriceCSVImportViewModelTests|
   PriceProfileArchitectureTests|
   SQLiteLocalBackupServiceTests|
   ErrorHandlingTests'
swift test -c debug --quiet
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p28-xcode-debug-review
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
```

### Ergebnis

- fokussierte Reviewmatrix: **22 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **461 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **461 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: **15 Targets, sieben Testtargets, zwei Schemes**,
- isolierter App-Start: Schema-v17-Store integer und
  `ZPRICEIMPORTRECORD` vorhanden.

Geprüft wurden Format, Mapping, ungültige/doppelte Zeilen, Katalogbindung,
Einfügung, Ersetzung, Bestätigung, Stale State, atomarer Bericht,
Löschkaskade, v16→v17-Migration und Backupformat 17.0.0.

Der Sandbox-Erstbuild scheiterte am Compilercache. Ein inkonsistenter
Objektcache wurde mit `swift package clean` bereinigt. Zwei neue
XCTest-Autoclosurefehler und die Fehleroperationsmatrix wurden während der
Testentwicklung korrigiert. Nach der Reviewhärtung wurden sowohl die
vollständige SwiftPM- als auch die vollständige Xcode-Suite auf dem finalen
Quellstand erneut ausgeführt. Kein manueller GUI-/VoiceOver-Test erfolgte.

## 2026-07-26 – P29 Kosten, Gewinn und ROI

### Befehle

```text
swift build -c debug
swift test -c debug --filter
  'ProjectEconomicsTests|
   ProjectEconomicsServiceTests|
   ProjectEconomicsPersistenceTests|
   ProjectEconomicsArchitectureTests|
   SQLiteLocalBackupServiceTests'
swift test -c debug --quiet
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p29-xcode-debug-review
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
```

### Ergebnis

- fokussierte P29-/Backup-Matrix: **22 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **473 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **473 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: **15 Targets, sieben Testtargets, zwei Schemes**,
- isolierter App-Start: Prozess blieb lauffähig; Schema-v18-Tabelle
  `ZPROJECTECONOMICSCONFIGURATIONRECORD` war vorhanden und
  `PRAGMA integrity_check` meldete `ok`.

Geprüft wurden Cash-/wirtschaftliche Kosten, Lagerbewertung, manuelle
Jobkosten, Erlös, Gewinn/Verlust, Marge, ROI, Nullkapital, Break-even-Rundung,
fehlende Preise, ungültige Planzeilen, Überlauf, Vorschau/Bestätigung,
Stale Pricing, Repository-Referenzen, v17→v18-Migration, Wiederöffnung,
Backupformat 18.0.0 und SwiftData-freie UI-Zustände.

Der erste fokussierte Lauf fand ausschließlich eine nach Schema 18 veraltete
Backup-Zukunftsfixture. Der erste Xcode-Gesamtlauf fand ausschließlich eine
vom Arbeitsverzeichnis abhängige neue Architekturprüfung. Beide Fixtures
wurden korrigiert; anschließend bestanden fokussierte und vollständige
Läufe. Ein manueller GUI-/VoiceOver-Test wurde nicht durchgeführt.

## 2026-07-26 – P30 Einkaufslisten-Aggregation

### Befehle

```text
swift build -c debug --quiet
swift test -c debug --filter Shopping --quiet
swift test -c debug --quiet
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p30-xcode-debug
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
```

### Ergebnis

- fokussierte Shopping-Matrix: **14 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **486 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **486 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: **15 Targets, sieben Testtargets, zwei Schemes**,
- isolierter App-Start: Schema-v19-Tabelle
  `ZSHOPPINGQUANTITYOVERRIDERECORD` vorhanden und
  `PRAGMA integrity_check = ok`.

Geprüft wurden Type-ID-Zusammenführung, alle P26-Quellarten,
Mengen null/kleiner/gleich/größer, Reset, ungültige/doppelte/unbekannte
Eingaben, Summenüberlauf, Vorschau/Bestätigung, Abbruch, geänderter Plan,
konkurrierender Schreibstand, veraltete Overrides, v18→v19-Migration,
Wiederöffnung, leeres Duplikatprojekt, Backup 19.0.0, SwiftData-freie UI
und schmale/breite Rendergrößen.

Der finale Xcode-Lauf meldete zweimal eine nicht zum macOS-Ziel gehörende
DTDeviceKit-Warnung, weil ein verbundenes mobiles Gerät gesperrt war und
der Dienst `com.apple.mobile.notification_proxy` nicht gestartet werden
konnte. Der macOS-Testbefehl endete mit Exitcode 0; der `.xcresult` weist
486 bestandene und keine fehlgeschlagenen oder übersprungenen Tests aus.

Der erste vollständige Lauf hatte einen Fehler: Der bestehende
P32-Architekturtest erwartete die durch P30 ersetzte Beschriftung
„Fehlmengen kopieren“. Nach Anpassung an „Einkaufsliste kopieren“
bestanden beide Gesamtsuiten. Im Review wurde außerdem eine nach dem Save
liegende Repository-Prüfung entfernt, um einen erfolgreichen Commit nicht
nachträglich mehrdeutig als Fehler melden zu können. Ein manueller
GUI-/VoiceOver-Test wurde nicht durchgeführt.

## 2026-07-26 – P31 Einkaufsworkflow und Export

### Befehle

```text
swift build -c debug --quiet
swift test --filter Purchasing --quiet
swift test --quiet
./Scripts/generate_xcode_project.sh
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p31-xcode
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
sqlite3 /private/tmp/new-eden-nexus-p31-app/P31.store
  "PRAGMA integrity_check; ..."
```

SwiftPM wurde wegen der eingeschränkten lokalen Modulcache-Sandbox mit
`CLANG_MODULE_CACHE_PATH` und `SWIFTPM_MODULECACHE_OVERRIDE` unter
`/private/tmp` ausgeführt.

### Ergebnis

- fokussierte Purchasing-Matrix: **15 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **501 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **501 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: **15 Targets, sieben Testtargets, zwei Schemes**,
- isolierter App-Start: Schema-v20-Tabelle
  `ZPURCHASEPROGRESSRECORD` vorhanden und
  `PRAGMA integrity_check = ok`.

Geprüft wurden Mehrprojektaggregation, Projektquellen, Teilkäufe,
vollständig gekauft, Zurücksetzen, überhöhte Altwerte, Sortierung,
CSV-Maskierung, nicht berechenbare und archivierte Projekte,
Vorschau/Bestätigung, veraltete Quellen, atomare Scope-Isolation,
v19→v20-Migration, Wiederöffnung, Backup 20.0.0, zentrale Fehlercodes,
SwiftData-freie UI und schmale/breite Rendergrößen.

Der erste vollständige SwiftPM-Lauf bestand 499 von 500 Tests. Der einzige
Fehler war die bestehende Vollständigkeitsmatrix der zentralen
Fehleroperationen, die die drei neuen P31-Operationen noch nicht enthielt.
Nach Ergänzung bestanden beide vollständigen Suiten.

Der Xcode-Lauf meldete wiederholt eine nicht zum macOS-Ziel gehörende
DTDeviceKit-Warnung, weil ein verbundenes mobiles Gerät gesperrt war.
Der Testbefehl endete mit Exitcode 0; das `.xcresult` weist 501 bestandene
und keine fehlgeschlagenen oder übersprungenen Tests aus. Ein manueller
interaktiver GUI-/VoiceOver-Test wurde nicht durchgeführt.

## 2026-07-26 – P33 Appweite Validierung und Fehler-UX

### Befehle und Ergebnis

```text
swift test -c debug --filter
  'ErrorHandlingTests|NewEdenNexusTests/testRuntime|
   PurchasingViewModelTests|AppSourceArchitectureTests'
swift test -c debug --quiet
./Scripts/verify_xcode_project.py
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-p33-xcode-final
  CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES -quiet
xcrun xcresulttool get test-results summary
```

- fokussiert: **16 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **507 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **507 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Projekt: **15 Targets, sieben Testtargets, zwei Schemes**.

Geprüft wurden stabile Validierungscodes, Rohwertfreiheit, eindeutige
Validierungs-IDs, UI-Verwendung, Retry-Positivliste, Einmalausführung,
Entfernen der Präsentation vor Retry, Schreib-Retry-Sperre, Cancellation,
Operations-Mapping, Redaction und schmale/breite Einkaufsansicht.

Der erste fokussierte Compile fand einen Swift-6-Actor-Isolationfehler nur in
einem neuen asynchronen Testhelper. Nach actor-sicherer Formulierung bestanden
alle Läufe. Ein früher Xcode-Lauf meldete die bekannte DTDeviceKit-Warnung
eines gesperrten Mobilgeräts; das macOS-Ziel blieb erfolgreich. Keine
manuelle vollständige VoiceOver-/Lokalisierungsprüfung; diese bleibt P35.

## 2026-07-26 – P34 Performance und große Graphen

### Befehle

```bash
swift test --filter ItemBlueprintCatalogPerformanceTests/testFiftyThousandItemCatalogAppliesDatabaseLimit
swift test --filter ProductionGraphDisplayProjectionTests
swift test --filter 'ProductionGraphDisplayProjectionTests|CCPSDEArchivePipelineTests|SDEInstallationServiceTests|PriceCSVImportServiceTests|ProjectLifecycleViewModelTests'
swift test
Scripts/generate_xcode_project.sh
xcodebuild test -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath /private/tmp/new-eden-nexus-p34-xcode-final
```

### Ergebnis

- fokussierte Vertrags-/Regressionsauswahl: **22 Tests bestanden**,
- SwiftPM Debug: **512 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **512 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Parität: **15 Targets, sieben Testtargets, zwei Schemes**,
- Katalogmessung: 50.000 Items, zehn Suchen, Limit 50,
  0,288 s SwiftPM / 0,295 s Xcode, je 51 Zeilen und ein Batch,
- Großgraphenmessung: 25.000 Knoten, 1.000 sichtbar,
  0,026 s SwiftPM / 0,026 s Xcode.

Die Zeitbudgets (< 2 s Katalog, < 3 s Projektion) bestanden. Bekannte
Core-Data-Migrationshinweise, eingeschränkte Test-UserDefaults und
AppIntents-Dienstmeldungen traten im Xcode-Testhost weiterhin auf, ohne
Testfehler zu verursachen. Kein Release- oder manueller vollständiger
Accessibility-Lauf; diese Grenzen bleiben P35/P36.

## 2026-07-26 – P35 Accessibility- und UX-Politur

### Befehle

```bash
Scripts/generate_xcode_project.sh
Scripts/verify_xcode_project.py
swift test --disable-sandbox \
  --filter 'AppNavigationAccessibilityTests|P35AccessibilityArchitectureTests|AppSourceArchitectureTests|ProductionWorkspaceArchitectureTests'
swift test --disable-sandbox
xcodebuild test -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath /private/tmp/new-eden-nexus-p35-xcode-approved
open -na /private/tmp/new-eden-nexus-p35-xcode-approved/Build/Products/Debug/NewEdenNexus.app \
  --args --new-eden-nexus-isolated-store \
  /private/tmp/new-eden-nexus-p35-ui.store
```

### Ergebnis

- fokussiert: **10 bestanden, 0 fehlgeschlagen**,
- SwiftPM Debug: **518 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **518 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode-Parität: **15 Targets, sieben Testtargets, zwei Schemes**,
- isoliertes App-Bundle startete und legte den Teststore an.

Der erste SwiftPM-Aufruf und der erste Xcode-Aufruf wurden von der lokalen
Dateisandbox am Modulcache beziehungsweise SwiftData-Makroserver blockiert.
SwiftPM bestand mit isoliertem Cache und `--disable-sandbox`; Xcode bestand
bei erlaubter Ausführung außerhalb der Dateisandbox.

Geprüft wurden Sidebar-Suche, Diakritik-Fallback, leerer Suchzustand,
Hauptfenstergrenze, adaptive Dashboard-/Workspace-/Einkaufs-/SDE-Layouts,
Fokusfolge, semantische Systemfarben und SDE-Statusansage. Der bestehende
Workspace-Renderer bestand bei 760 × 760 und 1.200 × 900.

Der native Computer-Use-Kanal schloss vor Ausgabe des Accessibility-Baums.
Eine aktuelle vollständige manuelle VoiceOver-Prüfung wird deshalb nicht
behauptet und bleibt OFF-030.

## 2026-07-26 – OFF-030 / abschließende P35-Abnahme

### Befehle und Ergebnis

```text
swift test --disable-sandbox
xcodebuild test -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/new-eden-nexus-off030-xcode-full
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=-
xcrun xcresulttool get test-results summary
python3 Scripts/verify_xcode_project.py
git diff --check
```

- SwiftPM Debug: **518 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- Xcode Debug: **520 bestanden, 0 fehlgeschlagen, 0 übersprungen**,
- darin zwei native UI-Tests für 1.280 × 800 und 780 × 560,
  Accessibility-Audit und Tab-Fokusfolge,
- Xcode-Parität: **16 Targets, acht Testtargets, zwei Schemes**.

Die temporäre Ad-hoc-Signierung wurde nur per Befehlszeile gesetzt. Projekt-
Signing und Team blieben unverändert. Explorative Fehlläufe vor dem finalen
Nachweis identifizierten die Mindestfensterhöhe, Metrikrolle,
System-Touch-Bar-Ausnahme und eine veraltete Architekturtest-Erwartung; alle
produktrelevanten Befunde wurden behoben. Der interaktive Computer-Use-Kanal
blieb ohne Baumzugriff und gilt nicht als manueller VoiceOver-Nachweis.

## 2026-07-26 – OFF-006: Migration-/Recovery-Lebenszyklus

### Befehle und Ergebnis

```text
swift test --filter
  'LocalRecoveryRuntimeTests|NexusMigrationBackupCoordinatorTests|LocalRecoveryArchitectureTests'
swift test
xcodebuild build -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
xcodebuild test ... -skip-testing:NewEdenNexusUITests
```

- fokussiert: **8/8 bestanden**,
- SwiftPM Debug: **526/526 bestanden**,
- Xcode Debug ohne UI: **526/526 bestanden**,
- Xcode-App-Build: **erfolgreich**.

Geprüft wurden v19/v20-Erkennung, automatisches `beforeMigration`, fehlendes
Backup ohne Storeänderung, v19→v20→Restore→Wiederöffnung,
Referenzdatenerhalt, read-only Restore-Vorschau, Doppelbestätigung und
Freigabe storegebundener Runtime-Zustände. Keine produktiven Daten wurden
verwendet.

Der vollständige Xcode-Lauf erreichte nach den 525 grünen Nicht-UI-Tests
keinen UI-Testbeginn. Ein isolierter UI-only-Wiederholungsversuch blieb
ebenfalls bei der Worker-Materialisierung stehen und wurde kontrolliert
beendet. Der interaktive Kanal konnte das Test-App-Bundle in seiner Sitzung
nicht bei LaunchServices registrieren. Eine aktuelle visuelle Prüfung wird
daher nicht behauptet; OFF-031 hält den erneuten Infrastrukturtest offen.

## 2026-07-26 – P36: Reale SDE-Prozessgrenzen

### Befehle und Ergebnis

```text
swift test --disable-sandbox
NewEdenNexusSDEAcceptance p36-recovery-drill --fixture-source <synthetic>
xcodebuild build -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexusSDEAcceptance -configuration Debug
xcodebuild build -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
xcrun xctest -XCTest SDEInstallationServiceTests
  NewEdenNexusApplicationTests.xctest
```

- SwiftPM Debug: **527/527 bestanden**,
- Xcode-App-Debugbuild: **erfolgreich**,
- Xcode-Acceptance-Debugbuild: **erfolgreich**,
- Xcode-kompilierter fokussierter Testbund: **6/6 bestanden**,
- externer Drill: **5/5 SIGKILL-/Neustart-Szenarien bestanden**,
- ungültige fremde Acceptance-Wurzel: **wie erwartet abgelehnt**.

Die Szenarien `downloading`, `validatingSource`,
`validatingStagingStore`, `creatingSafetyBackup` und `promoting` verwendeten
fünf verschiedene PIDs und endeten jeweils durch Signal 9. Jeder Neustart
erhielt Altbuild, Katalog und Benutzerfixtures, terminalisierte genau ein
Journal, bestätigte Rollback/Aufbewahrung, bereinigte temporäre
Operationsgrenzen und war beim zweiten Recoverylauf idempotent.

Ein normaler Xcode-Scheme-Testaufruf baute alle Testbundles, konnte in der
Codex-Sandbox jedoch keine Verbindung zu `testmanagerd.control` aufbauen.
Der vorgeschriebene Lauf außerhalb der Sandbox blieb vor Testbeginn ohne
Fortschritt und wurde kontrolliert beendet. Der bereits Xcode-kompilierte
betroffene Testbund wurde deshalb direkt mit dem nativen `xctest`-Runner
erfolgreich ausgeführt. Diese Infrastrukturgrenze bleibt OFF-031; kein
Produkttest wurde als bestanden erfunden.

## 2026-07-26 – REL-001: Öffentliche Release-/Complianceprüfung

### Befehle und Ergebnis

```text
python3 Scripts/verify_xcode_project.py
→ 16 Targets, 8 Testtargets, 2 gemeinsame Schemes

swift build -c release --disable-sandbox
→ erfolgreich

swift test -c release --disable-sandbox
→ 527/527 bestanden, 0 Fehler, 0 übersprungen

xcodebuild -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Release
  -destination platform=macOS,arch=arm64
  -derivedDataPath /tmp/NewEdenNexus-Public-Release-Xcode
  CODE_SIGNING_ALLOWED=NO OTHER_SWIFT_FLAGS=-disable-sandbox build
→ BUILD SUCCEEDED; arm64 und x86_64

xcodebuild -project NewEdenNexus.xcodeproj
  -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64
  -derivedDataPath /tmp/NewEdenNexus-OFF031-Xcode
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=-
  OTHER_SWIFT_FLAGS=-disable-sandbox
  test -only-testing:NewEdenNexusUITests/P35AccessibilityUITests
→ 2/2 bestanden, 0 Fehler, TEST SUCCEEDED
```

Der native UI-Worker startete das echte App-Bundle und prüfte
Breit-/Schmalfenster, Accessibility-Audit und Tab-Fokusfolge. OFF-031 ist
geschlossen. Die Ad-hoc-Signierung galt nur für den Testbefehl.

Das erzeugte Releaseartefakt war absichtlich unsigned:
`codesign --verify --deep --strict` meldete „code object is not signed at
all“. Bundle-ID war `com.newedennexus.local.NewEdenNexus`; Marketing- und
Buildversion fehlten. Notarisierung/Gatekeeper konnten deshalb nicht als
bestanden gewertet werden und bleiben OFF-032.

## 2026-07-26 – P38: SSO-Härtung

### Build

```bash
swift build --scratch-path .build-p38 --jobs 2
```

Ergebnis: **erfolgreich**, Debugbuild, Exit 0.

```bash
xcodegen generate --spec project.yml
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS' \
  -derivedDataPath .build-p38/XcodeDerivedData \
  CODE_SIGNING_ALLOWED=NO build
```

Ergebnis: Projektgenerierung und Xcode-App-Build **erfolgreich**
(`BUILD SUCCEEDED`). Xcode wählte beim unspezifischen macOS-Ziel die erste
von arm64/x86_64; die AppIntents-Metadatenprüfung wurde ohne vorhandene
AppIntents-Abhängigkeit übersprungen.

### Vollständige Tests

```bash
swift test --scratch-path .build-p38 --jobs 1
```

Ergebnis nach der letzten Quelländerung: **540/540 bestanden**, 0 Fehler,
0 unerwartete Fehler, 12,197 Sekunden Testlauf. Abgedeckt sind unter anderem
4 Account-Service-, 6 Authorization/JWT-/Callback-, 2 Account-Persistenz- und 1
Account-View-Architekturtest.

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build-p38/XcodeDerivedDataNoSign \
  CODE_SIGNING_ALLOWED=NO test \
  -only-testing:NewEdenNexusApplicationTests/EVEAccountConnectionServiceTests \
  -only-testing:NewEdenNexusInfrastructureTests/EVESSOAuthorizationFlowTests \
  -only-testing:NewEdenNexusPersistenceTests/CharacterAccountPersistenceTests \
  -only-testing:NewEdenNexusArchitectureTests/AppSourceArchitectureTests/testAccountViewsUseApplicationModelInsteadOfDirectPersistence
```

Ergebnis außerhalb der Codex-Sandbox: **13/13 bestanden**, 0 Fehler,
`TEST SUCCEEDED`.

### Umgebungsbefunde

- Der erste ad-hoc-signierte Xcode-Testversuch endete vor den Tests, weil
  Finder-Metadaten im erzeugten Testbundle von `codesign` abgelehnt wurden.
- Der erste unsignierte Wiederholungsversuch innerhalb der Codex-Sandbox
  konnte den SwiftData-Makroprozess nicht starten.
- Derselbe unsignierte fokussierte Befehl bestand außerhalb der Sandbox
  vollständig. Die beiden Vorläufe sind deshalb kein Produktfehler und
  wurden nicht als bestandene Tests gezählt.

### Manuelle Prüfung

Kein realer SSO-Login ausgeführt. Verbinden erzeugt externen Kontozugriff und
erfordert die ausdrückliche Bestätigung des Projekteigentümers. P38 bleibt
bis zu Verbinden, Neustart/Wiederöffnung, Refresh und bestätigtem Trennen
`⚠️`.

## 2026-07-26 – P38: SSO-Laufzeitkorrektur

### Reproduktion

Die lokalen Unified Logs ordneten sowohl `NEN-AUTH-001` als auch
`NEN-PER-004` einem `KeychainRefreshTokenVaultError` zu. Security meldete
beim Lesen des bestehenden Eintrags
`CSSMERR_CSP_OPERATION_AUTH_DENIED`. Der frühere App-Build besaß nur eine
ad-hoc-Designated-Requirement; der Login-Keychain war beim
Apple-Development-Build gesperrt.

### Automatisierte Prüfungen

```bash
swift test --package-path <immutable-temporary-snapshot> \
  --disable-sandbox --jobs 8
```

Ergebnis: **542/542 bestanden**, 0 Fehler. Darin enthalten sind die neuen
Vault-Lese-/Löschfehlerfälle und die stabile Fehlerzuordnung
`NEN-AUTH-003`.

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -only-testing:NewEdenNexusUITests/P35AccessibilityUITests/testLaunchKeepsExactlyOneMainWindow \
  test
```

Ergebnis im unveränderlichen temporären Projektabbild: **1/1 bestanden**,
`TEST SUCCEEDED`. Start und wiederholtes `⌘N` zeigten genau ein
Hauptfenster.

### Noch nicht ausführbar

Der mit der lokalen Apple-Development-Identität konfigurierte Build erreicht
den CodeSign-Schritt, endet bei gesperrtem Anmeldeschlüsselbund aber mit
`errSecInternalComponent`. Der bestehende Keychain-Eintrag wurde weder
gelesen, verändert noch gelöscht. Stabil signierter Build sowie
Verbinden/Neustart/Refresh/Trennen bleiben OFF-033.

## 2026-07-26 – P38: Buildlog-Nachprüfung

Die gemeldeten AppIntents-/`linkd.autoShortcut`-Zeilen waren
Laufzeitdiagnostik und kein Compiler- oder Linkerfehler. Ein isoliertes
Projektabbild wurde neu generiert und geprüft:

- `PurchasingWorkflowArchitectureTests`: bestanden,
- Xcode Debug arm64 mit `CODE_SIGNING_ALLOWED=NO`: `BUILD SUCCEEDED`,
- Projektkonsistenz: 16 Targets, 8 Testtargets, 2 Schemes.

Das nicht vorhandene SF Symbol `cart.badge.checkmark` wurde durch
`checkmark.circle.fill` ersetzt. Der stabil signierte Build bleibt wegen
des gesperrten Login-Keychains OFF-033.

## 2026-07-26 – P38: Keychain-Dialogkorrektur

- Fokussiert in isolierter Quellkopie: 13/13 SSO-/Diagnosetests bestanden.
- Vollständig in isolierter Quellkopie:
  `swift test --disable-sandbox` – 544/544 bestanden.
- Xcode Debug, macOS arm64, isolierte DerivedData,
  `CODE_SIGNING_ALLOWED=NO`, `COMPILER_INDEX_STORE_ENABLE=NO`:
  `BUILD SUCCEEDED`.
- Derselbe Quellstand mit der lokalen Apple-Development-Konfiguration:
  CodeSign und `BUILD SUCCEEDED`.
- Das lokale Signing-Skript bestand `zsh -n`, leitete die Team-ID aus dem
  Zertifikat-OU ab und erzeugte einen Build, der
  `codesign --verify --deep --strict` bestand.
- Regressionen: kein vorbereitender Vault-Read bei Verbinden/Trennen,
  Repository-Kompensation bei Save/Delete-Fehlern und rohwertfreier
  `error_reason`.
- Die ergänzten Xcode-Logs wurden getrennt bewertet: SDE-Updatehinweis,
  `DetachedSignatures` und Listener-Cancel sind keine Buildfehler;
  `NEN-AUTH-001/002` bleiben die relevanten Laufzeitfehler.
- Nicht ausgeführt: neuer manueller Eigentümer-SSO-Lauf; OFF-033 bleibt
  offen.

## 2026-07-26 – P38: CCP-Misch-JWKS-Korrektur

- Reale offizielle SSO-Metadaten und JWKS abgerufen: der Schlüsselsatz
  enthält gleichzeitig RSA-/RS256- und EC-/ES256-Einträge.
- Neuer Regressionstest mit gültigem RSA-Schlüssel und zusätzlichem,
  unpassendem EC-Schlüssel: bestanden.
- Fokussiert:
  `swift test --disable-sandbox --filter EVESSOAuthorizationFlowTests` –
  7/7 bestanden.
- Vollständig: `swift test --disable-sandbox` – 545/545 bestanden.
- Isolierter, lokal Apple-Development-signierter Xcode-Debugbuild für
  macOS arm64: `BUILD SUCCEEDED`.
- Quellparität und `codesign --verify --deep --strict`: bestanden.
- Nicht ausgeführt: erneuter persönlicher SSO-End-to-End-Lauf; OFF-033
  bleibt offen.

## 2026-07-26 – P38: Abschlussabnahme

- Vorhandener Techniknachweis unverändert: 7/7 fokussierte
  SSO-/JWKS-Tests und 545/545 vollständige SwiftPM-Tests bestanden.
- Vorhandener Buildnachweis unverändert: lokal Apple-Development-signierter
  Xcode-Debugbuild `BUILD SUCCEEDED`; Quellparität und
  `codesign --verify --deep --strict` bestanden.
- Manueller Eigentümer-End-to-End-Lauf wurde als funktionsfähig bestätigt.
- Read-only-Persistenzkontrolle nach dem Trennen:
  `SELECT COUNT(*) FROM ZCHARACTERRECORD;` ergab `0`.
- Zwei verwaiste Alt-Tokens wurden jeweils nach Metadatenvorschau und
  ausdrücklicher Einzelbestätigung gelöscht.
- Abschlusskontrolle:
  `security find-generic-password -s de.newedennexus.tokens` ergab
  `SecKeychainSearchCopyNext: The specified item could not be found`.
- Keine Codeänderung in der Abschlussabnahme; deshalb kein redundanter
  erneuter Build- oder Testsuitenlauf.

## 2026-07-26 – P39: ESI-Infrastruktur und Charaktere

### SwiftPM

```bash
CLANG_MODULE_CACHE_PATH=.build-p39-tests/clang-cache \
SWIFTPM_MODULECACHE_OVERRIDE=.build-p39-tests/swift-cache \
swift test --disable-sandbox --scratch-path .build-p39-tests --jobs 2
```

Ergebnis: **565/565 bestanden**, 0 Fehler in 12,324 Sekunden. Abgedeckt sind
frischer Cache ohne Netz, 200/304, ETag/Last-Modified, 420/429,
Retry-After/Error-Limit, begrenzter 5xx-Retry, Offline-Fallback, Abbruch,
Cachegrenzen, Wiederöffnung, Trennen und Kompensation.

### Xcode

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build-p39-xcode \
  CODE_SIGNING_ALLOWED=NO build
```

Ergebnis außerhalb der restriktiven Test-Sandbox: **BUILD SUCCEEDED**.
Scheme, Projektdatei und alle sechs neuen P39-Quellen waren enthalten.
Signing- und Team-Einstellungen wurden nicht verändert.

### Reale CCP-Prüfung

Ein offizieller öffentlicher Charakterabruf lieferte HTTP 200 samt
Cacheheadern. Ein Folgeabruf mit dem gelieferten ETag lieferte HTTP 304.
Der Request enthielt `User-Agent` und `X-Compatibility-Date`, aber keinen
Bearer-Token.

### Abweichungen der Prüfumgebung

Ein erster eingeschränkter SSO-Testlauf scheiterte an der blockierten
Security-/SecKey-Umgebung; außerhalb der Sandbox bestanden 8/8 Tests. Ein
erster Xcode-Lauf scheiterte ebenso an der SwiftData-Makro-Sandbox; der
identische Quellstand baute außerhalb erfolgreich. Dies waren
Umgebungsgrenzen, keine Produktfehler.

Nach der abschließenden reinen UI-Textpräzisierung bestanden zusätzlich
4/4 `AppSourceArchitectureTests`; der inkrementelle Xcode-Debugbuild
bestand auf diesem finalen Stand erneut außerhalb der restriktiven
Dateisandbox.

## 2026-07-26 – P40: Persönliche ESI-Daten

### Fokussiert

Zwei fokussierte Läufe bestanden: zunächst **33/33**, danach die um vier
Grenzfälle erweiterte `ESIPersonalDataClientTests`-Suite mit **9/9**.
Damit sind **37 eindeutige P40-Tests** fokussiert bestanden. Ein späterer
identischer Sammellauf wurde wegen eines hängen gebliebenen
SwiftPM-Dateizugriffs ohne Testergebnis abgebrochen; die vollständige Suite
unten bestätigt denselben finalen Quellstand.

Geprüft wurden exakt drei Scopes, sequenzielle Pagination, 200/304, 401/403,
420/429, ein 5xx-Retry, Offline und Abbruch, Schema- und Datensatzgrenzen,
Vorschau ohne Schreibzugriff, Apply mit Basisrevision, Dateistaging,
Wiederöffnung, Symlink-/Korruptionsschutz sowie Trennkompensation.

### Vollständig

```bash
swift test --disable-sandbox \
  --scratch-path .build-p40-full-unsandboxed --jobs 2
```

Ergebnis außerhalb der restriktiven Dateisandbox: **583/583 bestanden**,
0 Fehler. Der erste Sandboxlauf erreichte 580 bestandene Tests; drei
Security.framework-RSA-Fixtures konnten dort keinen Testschlüssel
erzeugen. Dieselben drei Tests bestanden in der normalen Umgebung.

### Xcode

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build-p40-xcode-unsandboxed \
  CODE_SIGNING_ALLOWED=NO build
```

Ergebnis: **BUILD SUCCEEDED**. Der erste eingeschränkte Lauf scheiterte am
blockierten SwiftData-Pluginserver; der identische Quellstand baute
außerhalb. `Scripts/verify_xcode_project.py` bestätigte 16 Targets,
8 Testtargets und 2 gemeinsame Schemes.

### Nicht ausgeführt

Kein persönlicher Live-ESI-Abruf und keine Scope-Zustimmung im Namen des
Eigentümers. Dieser erste Lauf bleibt eine bewusste Benutzerhandlung.

## 2026-07-27 – P41: Öffentliche Materialpreise

### Fokussiert

- `ESIMarketOrderClientTests`: 3/3 bestanden.
- Marktpreis-Service und Persistenz: 6/6 bestanden.
- P41/Schema/Backup-Sammellauf: 21/21 bestanden.
- Zentrale Fehlerbehandlung nach Ergänzung der beiden Marktoperationen:
  6/6 bestanden.

Abgedeckt sind mengenbezogene Mehrorderfüllung, Locationfilter,
Teilabdeckung, Vorschau/Bestätigung, Abbruch, Stale-Preview, 200/304,
Validatoren, 429, Offline-/Stalecache, Dateicacheidentität, atomare
Preisprovenienz, manuelle Ersetzung, v20→v21-Migration und Backupformat 21.

### Vollständig

`swift test --skip-build`: **593/593 bestanden**, 0 Fehler. Der erste
Volltestlauf fand die fehlende v21-Erkennung des Store-Inspectors; nach der
Korrektur bestanden die betroffenen 21 Tests und die finale Vollsuite.

### Xcode

`Scripts/generate_xcode_project.sh` bestand und bestätigte 16 Targets, acht
Testtargets und zwei gemeinsame Schemes. Nach vollständigem Beenden von Xcode
zeigte ein Prozesssample den Stillstand in `NSFileCoordinator` beim Lesen des
File-Provider-markierten Projektpfads. Eine hashgleiche isolierte Kopie ohne
dieses Attribut bestand `xcodebuild -list`. Der anschließende Befehl
`xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
-configuration Debug -destination 'platform=macOS,arch=arm64'
-derivedDataPath /private/tmp/NewEdenNexus-OFF034-DerivedData-Normal
CODE_SIGNING_ALLOWED=NO build` endete mit **BUILD SUCCEEDED**.

Der eingeschränkte Vorlauf erreichte die Kompilierung, konnte aber den
SwiftData-Makroserver nicht verwenden. Derselbe Build in der normalen lokalen
Xcode-Umgebung war erfolgreich. Warnung: AppIntents-Metadatenextraktion wurde
mangels AppIntents-Abhängigkeit übersprungen.

### Nicht ausgeführt

Kein persönlicher Live-Marktabruf; dieser ist für die automatisierte
P41-Abnahme nicht erforderlich.

## 2026-07-27 – P42: Persönliche Wallet und Projekt-Istwerte

### Fokussiert

`swift test --filter Wallet`: **15/15 bestanden**. Geprüft wurden exakte
Geldnormalisierung, Plan-/Ist-Trennung, Überlauf, Preview ohne Schreiben,
Bestätigung, Stale-State, Überzuordnung, Trennkompensation, offizielle
Walletpfade, Validatoren, 304/401/420/429/5xx, Offline, Größenlimit,
beschädigter Cache, Dateirundlauf, belegter Journalbezug und
v21→v22-Migration.

### Vollständig

`swift test`: **608/608 bestanden**, 0 Fehler.

### Xcode

Projektverifier: 16 Targets, 8 Testtargets, 2 gemeinsame Schemes.
Isolierter macOS-Debugbuild: **BUILD SUCCEEDED**. Der direkte Aufruf am
synchronisierten Repositorypfad wurde wegen des bekannten
`NSFileCoordinator`-Stillstands kontrolliert abgebrochen.

### Nicht ausgeführt

Kein produktiver Walletabruf; erneute SSO-Scope-Zustimmung und persönliche
Daten bleiben eine bewusste Eigentümerhandlung.

## 2026-07-27 – PLAN-005: Dokument- und Projektprüfung

### Umfang

Keine Laufzeitimplementierung. Die P50–P54-Spezifikationen und betroffenen
Steuerdateien wurden auf Scope, Abhängigkeiten, Doppelabdeckung,
Bestätigungsschutz, Datenschutz, Recovery und messbare Abnahme geprüft.

### Automatisierte Nachweise

- `swift test`: **608/608 bestanden**, 0 Fehler.
- `python3 Scripts/verify_xcode_project.py`: Projektstruktur mit 16 Targets,
  8 Testtargets und 2 gemeinsamen Schemes bestätigt.
- Lokale Markdown-Linkprüfung: 20 betroffene Dateien geprüft, 0 defekte
  Links.
- `git diff --check`: ohne Befund; sechs neue Plan-/Promptdateien mit 52 bis
  72 Zeilen innerhalb der tokenarmen Richtgröße.

### Nicht ausgeführt

Kein neuer Xcode-Build und kein produktiver ESI-/Walletabruf; reine
Planungsänderung. Die jeweiligen Laufzeit- und Eigentümernachweise sind
Abnahmekriterien von P50–P52.

## 2026-07-27 – P50: Persönliche ESI-Details und Asset-Verfügbarkeit

### Fokussiert

- `ESIAssetAvailabilityServiceTests`: **8/8 bestanden**; Projektion,
  Großmengenlimit, unbekannte IDs, Detailvorschau, Bestätigung,
  Doppelzählung, neue Filter, Snapshotrevision und nachträgliche
  Lagerüberschneidung.
- `ESIAssetAvailabilityPersistenceTests`: **2/2 bestanden**; Rundlauf,
  Löschen/Wiederherstellen, aktuelle Schemaversion und v22→v23-Migration.
- P50-UI-Architekturvertrag: **1/1 bestanden**.
- Wallet-/Trennkompensation: **5/5 bestanden**.

### Vollständig

`swift test --disable-sandbox --scratch-path .build-p50 --jobs 2`:
**619/619 bestanden**, 0 Fehler. Die bekannten Core-Data-Hinweise
`Migration was completed by another client` traten in historischen
Mehrstufenfixtures auf und verursachten keinen Fehler.

### Xcode

`python3 Scripts/verify_xcode_project.py`: 16 Targets, 8 Testtargets und
2 gemeinsame Schemes. Finaler isolierter Befehl:

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination platform=macOS \
  -derivedDataPath /private/tmp/nen-p50-final.noHm3j/DerivedData \
  CODE_SIGNING_ALLOWED=NO build
```

Ergebnis: **BUILD SUCCEEDED**. Warnungen: mehrere passende macOS-
Architekturen; AppIntents-Metadaten wurden ohne AppIntents-Abhängigkeit
übersprungen. Signing-/Team-Einstellungen blieben unverändert.

### Nicht ausgeführt

Kein produktiver P40-Liveabruf und kein manueller Eigentümer-GUI-Lauf mit
persönlichen Daten; diese bewusste Betriebsabnahme bleibt P52.

## 2026-07-27 – P51: Scope-, Fehler- und Plan-/Ist-Korrektur

### Fokussiert

- Auth, Plan/Ist, Accountpersistenz und UI-Architektur: **29/29 bestanden**.
- Backup, Migration, Walletkompensation, Fehlercodes und Schema v24:
  **29/29 bestanden**.
- Enthalten sind exakt drei/vier Scopes, Abbruch und erfolgreiche
  Neuautorisierung, Token-/Accountbestand, View-Routing, fehlende/veraltete/
  archivierte Vergleichszustände, Wiederöffnung, Trennen und Backup/Restore.

### Vollständig

```bash
env CLANG_MODULE_CACHE_PATH="$PWD/.build-p51/ModuleCache" \
  SWIFTPM_MODULECACHE_OVERRIDE="$PWD/.build-p51/ModuleCache" \
  XDG_CACHE_HOME="$PWD/.build-p51/cache" \
  swift test --disable-sandbox --scratch-path .build-p51 --jobs 2
```

Ergebnis außerhalb der Dateisystem-Sandbox: **631/631 bestanden**, 0 Fehler.
Ein erster sandboxed Gesamtlauf hatte ausschließlich acht Security-
Framework-SSO-Tests betroffen; deren isolierte Wiederholung bestand 8/8,
danach bestand die komplette Suite in einem Lauf.

### Xcode

`python3 Scripts/verify_xcode_project.py`: 16 Targets, 8 Testtargets,
2 gemeinsame Schemes. Isolierter Build:

```bash
xcodebuild -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination platform=macOS \
  -derivedDataPath /private/tmp/nen-p51-final.yBXNp2/DerivedData \
  CODE_SIGNING_ALLOWED=NO build
```

Ergebnis außerhalb der Sandbox: **BUILD SUCCEEDED**. Der erste sandboxed
Versuch scheiterte ausschließlich am nicht verfügbaren SwiftData-
Makroprozess. Signing- und Teamwerte wurden nicht geändert.

### Nicht ausgeführt

Kein produktiver P40-/P41-/P42-Eigentümerlauf; dieser bleibt P52.

## 2026-07-27 – P52: Live-Vorprüfung und Abbruchnachweis

### Automatisiert

- SwiftPM Debug: **631/631 bestanden**, 0 Fehler.
- Xcode Debug: lokaler signierter macOS-arm64-Build **BUILD SUCCEEDED**;
  strikte Signaturprüfung bestanden.
- Storemigration v20→v24, Vor-Migrations-Backup und SQLite-Integrität
  erfolgreich geprüft.

### Manuell

- Erster Drei-Scope-PKCE-Login und Trennen funktionierten.
- Refresh: `NEN-AUTH-001` mit sicherem Grund `token_exchange_http_400`.
- Öffentliche Charakterdaten: `NEN-ESI-001` mit
  `owner_contact_missing`.
- Persönlicher Inspect: `NEN-ESI-002` mit
  `token_exchange_http_400`.
- Getrennt bestätigter Wallet-Inspect: `NEN-ESI-004`; wegen
  `owner_contact_missing` beziehungsweise blockiertem Refresh nicht nutzbar.

### Regressionslücke

Die bestehende Refresh-Testfixture enthält keine reservierten Zeichen.
Ein synthetischer Kontrolllauf zeigt, dass `+` im Refresh-Token nicht als
`%2B` kodiert wird. P52 wurde ohne Apply angehalten; OFF-040/KI-043 muss
zuerst in P51 korrigiert und erneut getestet werden.

## 2026-07-27 – P51: OAuth-, Keychain- und Kontakt-UX-Nachkorrektur

- Fokussierte OAuth-/Rotation-/Fehler- und Architekturtests bestanden.
- Vier fokussierte Kontakt-UX-Tests bestanden: Erfolg, Fehler, leere Eingabe
  ohne Löschen und ausdrücklich bestätigter Löschpfad.
- SwiftPM Debug: **639/639 bestanden**, 0 Fehler.
- Xcode Debug, `NewEdenNexus`, macOS arm64: **BUILD SUCCEEDED**, signiert.
- `git diff --check`: bestanden.
- Nicht ausgeführt: echtes Speichern und Wiedererkennen nach App-Neustart,
  erneuter OAuth-Refresh und ESI-Liveabruf.

### Ergänzung: sichtbare Kontakt-Eingabe

- Manueller Speichernachweis durch den Projekteigentümer: erfolgreich.
- Eingabefeld mit Beschriftung, großem Rounded-Border-Stil und Beispielhinweis
  ergänzt.
- Betroffener Architekturtest: **1/1 bestanden**.
- Eingeschränkter SwiftPM-Vollauf: **636/639 bestanden**; genau drei
  RSA-`SecKey`-Tests konnten im Sandbox-Kontext keinen Schlüssel erzeugen.
- Vollständige Wiederholung von `EVESSOAuthorizationFlowTests` außerhalb der
  Dateisystem-Sandbox: **10/10 bestanden**, einschließlich der drei Fälle.
- Signierter Xcode-Debugbuild für macOS arm64: **BUILD SUCCEEDED**.

## 2026-07-27 – P52: ESI-Livepfad-Nachkorrektur

- Redigierte Unified Logs: persönlicher Apply `cache_write_failed`,
  Wallet-Inspect `inconsistent_pagination`; keine Token- oder Fachdatenwerte.
- Fokussiert: Refreshfeedback, Subsekunden-Cache-Roundtrip,
  Wallet-Cachewechsel-Retry und Viewzuordnung **4/4 bestanden**.
- SwiftPM Debug außerhalb der Dateisystem-Sandbox: **642/642 bestanden**,
  0 Fehler.
- Signierter Xcode Debug, Scheme `NewEdenNexus`, macOS arm64:
  **BUILD SUCCEEDED**.
- Nicht ausgeführt: erneuter produktiver Refresh, persönlicher Apply und
  Wallet-Inspect; diese Eigentümerprüfungen bleiben P52.

### Eigentümer-Nachweis

- realer Refresh nach App-Neustart: **bestanden**,
- sichtbare Erfolgsmeldung, kein `NEN-AUTH-*`,
- persönlicher Apply und Wallet-Inspect in diesem Gate nicht ausgeführt.

- persönlicher Inspect/Vorschau: **bestanden**,
- kein Apply und keine Fachdatenänderung in diesem Gate.

- persönlicher Apply nach ausdrücklicher Bestätigung: **bestanden**,
- kein `NEN-ESI-003`; lokaler Snapshot-Schreibpfad real bestätigt.

### Wallet-Unterdiagnose

- Eigentümer-Retest: weiterhin `NEN-ESI-004`.
- Fokussiert: Walletclient und Fehlerbehandlung **15/15 bestanden**.
- Vollständig außerhalb der Dateisandbox: **644/644 bestanden**; der
  eingeschränkte Vorlauf scheiterte ausschließlich bei drei
  Security.framework-`SecKey`-Fixtures.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64, Apple-Development-signiert:
  **BUILD SUCCEEDED**.
- Noch offen: einmaliger Live-Inspect zur Ermittlung des neuen redigierten
  `error_reason=inconsistent_pagination_…`; keine Walletübernahme.

## 2026-07-27 – P52: Wallet-From-ID-Korrektur

- Reproduzierter sicherer Livegrund:
  `inconsistent_pagination_conflicting_transaction`.
- Ursache: CCP liefert beim `from_id`-Paging den Cursor-Datensatz inklusiv
  erneut; nur dessen lokale `sourcePage` unterschied sich.
- Fokussiert `ESIWalletClientTests`: **9/9 bestanden**, einschließlich
  akzeptierter identischer Cursorwiederholung und abgelehnter echter
  Nutzdatenabweichung.
- SwiftPM Debug vollständig außerhalb der Dateisandbox:
  **646/646 bestanden**, 0 Fehler.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64,
  Apple-Development-signiert: **BUILD SUCCEEDED**.
- `git diff --check`: **bestanden**.
- Nicht ausgeführt: erneuter Wallet-Liveinspect und Walletübernahme.

### Eigentümer-Livenachweis

- Neuer signierter Build gestartet und „Wallet prüfen“ ausgeführt:
  **bestanden**.
- Vorschaufenster öffnet sich; kein erneutes `NEN-ESI-004` gemeldet.
- Inspect blieb schreibfrei; Walletübernahme und Projektzuordnung nicht
  ausgeführt.

### Eigentümer-Apply und Neustart

- Walletübernahme nach ausdrücklicher Freigabe ausgeführt.
- App vollständig beendet und neu gestartet.
- Wallet-Snapshot nach Neustart weiterhin vorhanden: **bestanden**.
- Keine Walletwerte oder Parteien protokolliert; keine Projektzuordnung
  ausgeführt.
- UX-Befund OFF-042: Übernehmen/Verwerfen besitzen noch kein eindeutiges
  sichtbares Abschlussfeedback.

## 2026-07-27 – OFF-042: Wallet-Aktionsfeedback

- Fokussiert: Apply-Erfolg, Apply-Fehler, Discard mit Altbestand und Discard
  ohne Altbestand: **4/4 bestanden**.
- Vollständige SwiftPM-Suite außerhalb der Dateisandbox:
  **650/650 bestanden**, 0 Fehler.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64,
  Apple-Development-signiert: **BUILD SUCCEEDED**.
- `git diff --check`: **bestanden**.
- Keine Schema-, Persistenz- oder Löschänderung.
- Nicht ausgeführt: sichtbarer UI-Liveretest des neuen Feedbacks.

### 2026-07-28 – Eigentümer-Livenachweis

- „Wallet prüfen“ und anschließend „Verwerfen“ ausgeführt.
- Sichtbare Erhaltmeldung: **bestanden**.
- Gespeicherter Wallet-Snapshot blieb erhalten.
- Nicht ausgeführt: erneuter Apply und dessen sichtbare Erfolgsmeldung.

### 2026-07-28 – Eigentümer-Livenachweis Apply

- Erneuter Apply nach ausdrücklicher Freigabe ausgeführt.
- Sichtbare Meldung „Wallet-Snapshot wurde gespeichert.“: **bestanden**.
- OFF-042 Apply- und Discard-Feedback vollständig live bestätigt.

## 2026-07-28 – P52/OFF-037 Restgate-Inventur

- Fokussierter SwiftPM-Filter für persönliche ESI-Daten,
  Assetverfügbarkeit, Marktpreise, Wallet und Projektfinanzvergleich:
  **45/45 bestanden**, 0 Fehler.
- Erster Sandboxlauf: nicht als Testfehler gewertet; Swift-Modulcache war
  nicht beschreibbar. Wiederholung mit isoliertem `/private/tmp`-Cache
  außerhalb der Dateisandbox erfolgreich.
- Kein neuer Xcode-Build: Seit dem bereits bestandenen signierten
  OFF-042-Debugbuild wurde kein Quellcode geändert.
- Nächster manueller Nachweis: P40-1, schreibfreie Online-Detailansicht.

## 2026-07-28 – OFF-043: P40-Detailfenster schließen

- P40-1-Datenpfad durch den Eigentümer live bestanden.
- Fokussierter Architekturtest für sichtbaren Schließen-Button und
  Escape-Kurzbefehl: **1/1 bestanden**.
- Vollständige SwiftPM-Suite: **650/650 bestanden**, 0 Fehler.
- Xcode Debug, Scheme `NewEdenNexus`, macOS arm64,
  Apple-Development-signiert: **BUILD SUCCEEDED**.
- Offen: einmaliger Sichttest des Buttons im neuen Build.

### Eigentümer-Livenachweis

- Sichtbarer Schließen-Button im neuen Build betätigt: **bestanden**.
- OFF-043/KI-046 technisch und live geschlossen.

### P40-2 Eigentümer-Livenachweis

- App vollständig beendet und ohne Netz neu geöffnet.
- Lokale Asset-, Blueprint- und Industry-Job-Details weiterhin lesbar:
  **bestanden**.
- Kein Refresh, Inspect, Apply oder anderer Schreibvorgang ausgeführt.

## 2026-07-28 – P52/OFF-044: Namen und Auswahlrücknahme

- Eigentümerbefund: P40-3-Vorschau und Verwerfen live bestanden; ein
  anschließender unbeabsichtigter Apply ist kein P40-4-Nachweis.
- Fokussiert mit Filter `ESI(AssetAvailability|LocationName)`:
  **18/18 bestanden**, einschließlich öffentlicher Namensroute ohne
  Authorization-Header, Offline-Cache, verschachtelter Lagerorte,
  zweiter Bestätigung, Rücknahme, Stale-Schutz und atomarer Persistenz.
- Vollständige SwiftPM-Suite außerhalb der eingeschränkten Dateisandbox:
  **658/658 bestanden**, 0 Fehler, 0 unerwartete Fehler.
- Xcode Debug, Scheme `NewEdenNexus`, Konfiguration `Debug`, Ziel
  `platform=macOS,arch=arm64`, Apple-Development-signiert:
  **BUILD SUCCEEDED**.
- `plutil -lint NewEdenNexus.xcodeproj/project.pbxproj`: bestanden.
- `git diff --check`: bestanden.
- Nicht ausgeführt: produktiver Ortsnamensabruf im neuen Build und
  bestätigte Rücknahme der vorhandenen Auswahl. Beides bleibt OFF-044.

## 2026-07-28 – P52/OFF-045/OFF-046: Struktur- und Typnamen

- Fokussierte Scope-, Struktur-, Cache-, Katalog- und Architekturtests:
  **42/42 bestanden**, 0 Fehler.
- Vollständige SwiftPM-Suite mit isoliertem Modulcache und Scratch-Pfad:
  **662/662 bestanden**, 0 Fehler.
- Xcode Debug, Scheme `NewEdenNexus`, Konfiguration `Debug`, Ziel
  `platform=macOS`, Apple-Development-signiert: **BUILD SUCCEEDED**.
- Abgedeckt: Scopekombinationen, Abbruch-/Bestandsschutz, Bearer- und
  Validatorheader, `304`, Cache, verschachtelte Strukturen, fehlender Scope,
  vollständige gebündelte SDE-Typauflösung und fehlende Typen.
- Nicht ausgeführt: reale Scope-Zustimmung und Sichtprüfung mit einer für
  den Eigentümer zugänglichen Spielerstruktur sowie produktiver Snapshot mit
  Typen jenseits der früheren 2.000-Rohzeilen-Grenze.

## 2026-07-28 – P52/P40-4 Eigentümerbetrieb

- schreibfreie Assetverfügbarkeitsvorschau: **bestanden**,
- separates ausdrückliches Speichergate: **bestanden**,
- aktive Auswahl unmittelbar nach Speicherung sichtbar: **bestanden**,
- vollständiger App-Neustart ohne Netz; gleiche Auswahl lokal lesbar:
  **bestanden**,
- kein Refresh und keine neue Vorschau im Offline-Nachweis,
- keine neuen automatisierten Tests oder Builds ausgeführt, da kein
  Quellcode geändert wurde; letzter technischer Nachweis bleibt 662/662
  SwiftPM-Tests und signierter Xcode Debug `BUILD SUCCEEDED`.

## 2026-07-28 – P52/OFF-047 Produktionsworkspace-Navigation

- `swift test --filter ProductionWorkspaceArchitectureTests`: **1/1**,
- `swift test --filter BuildOrBuyWorkspaceViewModelTests`: **5/5**,
- `swift test --filter P35AccessibilityArchitectureTests`: **3/3**,
- erster vollständiger Lauf: **661/662**; ausschließlich ein veralteter
  P35-Quelltextzähler erwartete zwei frühere `ViewThatFits`-Blöcke,
- nach Anpassung an segmentierte Navigation: **662/662**, 0 Fehler,
- Renderprüfung für Übersicht, Bauen/Kaufen, Lager/Einkauf und Kosten/ROI
  jeweils bei 760 × 760 sowie 1.360 × 900 bestanden,
- Xcode Debug, Scheme `NewEdenNexus`, Ziel `platform=macOS`, arm64,
  Apple-Development-signiert: **BUILD SUCCEEDED**,
- Xcode-Warnung: mehrere passende macOS-Ziele; arm64 wurde verwendet,
- `git diff --check`: bestanden,
- ausstehend: sichtbarer Eigentümertest der neuen Breite und aller sechs
  Bereiche; keine Fachdatenprüfung oder -änderung ausgeführt.

## 2026-07-28 – P52/P41-1 ISK-Preissätze und profilfreie Vorschau

- fokussiert:
  `swift test --filter 'MarketPriceImportServiceTests|BuildOrBuyWorkspaceViewModelTests'`:
  **12/12 bestanden**,
- vollständig: `swift test --scratch-path .build-p52 --jobs 1` mit isoliertem
  Modulcache: **664/664 bestanden**, 0 Fehler,
- Regression: Vorschau ohne Ziel-Preissatz schreibt nicht und kann nicht
  übernommen werden; Workspace öffnet den Pfad auch ohne Preissatz,
- erster signierter Xcode-Debugbuild mit Derived Data im Repository:
  **fehlgeschlagen**, ausschließlich `resource fork, Finder information, or
  similar detritus not allowed` beim finalen App-CodeSign,
- identischer Wiederholungslauf mit
  `-derivedDataPath /private/tmp/NewEdenNexus-P52-PriceSets-Xcode`:
  Apple-Development-signiert, macOS arm64, **BUILD SUCCEEDED**,
- `git diff --check`: bestanden,
- keine produktiven Markt-, Preis-, Projekt- oder anderen Benutzerdaten
  verwendet oder verändert; Eigentümer-Sichttest OFF-048 offen.

## 2026-07-28 – P52/P41-1 benannte Marktquellen

- fokussiert mit Filter
  `ESIMarketOrderClientTests|MarketPriceImportServiceTests|BuildOrBuyWorkspaceViewModelTests|ESILocationName`:
  **26/26 bestanden**, 0 Fehler,
- vollständig mit isoliertem `.build-p52`-Scratch- und Modulcache:
  **667/667 bestanden**, 0 Fehler, 0 unerwartete Fehler,
- Xcode Debug, Projekt und Scheme `NewEdenNexus`, Konfiguration `Debug`,
  Ziel `platform=macOS,arch=arm64`, isoliertes Derived Data:
  Apple-Development-signiert, **BUILD SUCCEEDED**,
- `git diff --check`: bestanden,
- abgedeckt: benannte Regionen, fünf Trade-Hub-Presets,
  Stations-/System-/Regionshierarchie, öffentliche Marktstrukturklassifikation,
  persönliche Namenszusammenführung, Offlinefallback, private
  Strukturmarkt-Sperre und profilfreie Workspace-Vorschau,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- nicht ausgeführt: Eigentümer-Sichttest mit realer Region beziehungsweise
  Home-Hub; dieser bleibt OFF-050.

## 2026-07-28 – P52/OFF-050 Eigentümerbetrieb

- benannte Marktquellenauswahl im aktuellen Build: **bestanden**,
- Vorschau in den gewählten Preissatz übernommen,
- keine neue automatisierte Prüfung und kein neuer Build, da kein Quellcode
  geändert wurde,
- letzter technischer Nachweis bleibt 26/26 fokussiert, 667/667 vollständig
  und Apple-Development-signierter Xcode Debug,
- offen: sichtbare ESI-Herkunft/Region/Cachezeit sowie Neustart-/Offline-
  Persistenz des übernommenen Preissatzes.

## 2026-07-28 – P52/P41-2 bis P41-3 Eigentümerbetrieb

- sichtbare ESI-Herkunft, Region/Standort und Cachezeit: **bestanden**,
- vollständiger App-Neustart beziehungsweise Offline-Lesbarkeit des
  übernommenen Preissatzes: **bestanden**,
- keine neue automatisierte Prüfung und kein neuer Build, da kein Quellcode
  geändert wurde,
- letzter technischer Nachweis: 26/26 fokussiert, 667/667 vollständig und
  Apple-Development-signierter Xcode Debug.

## 2026-07-28 – P52/OFF-051 gruppierte ESI-Detailansichten

- fokussierte Projektions-, Ortsindex- und Architekturprüfungen:
  **17/17 bestanden**,
- Großdatenfall: vollständige Suche fand einen Treffer hinter 5.000 Zeilen;
  Gruppierung von 5.001 Assets in rund **0,064 s**,
- vollständig: `swift test --scratch-path .build-p52` mit isoliertem
  Modulcache: **668/668 bestanden**, 0 Fehler,
- nativer Xcode Debug, macOS arm64, isoliertes Derived Data:
  Apple-Development-signiert mit aktuell gültigem Team-Override,
  **BUILD SUCCEEDED**,
- zusätzlicher unsigned Xcode Debug: **BUILD SUCCEEDED**,
- unveränderter Standard-Signinglauf: vor Kompilierung an alter Projekt-
  Teamzuordnung fehlgeschlagen; als OFF-052 nach P53 geroutet,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- Eigentümer-Sichttest für Gruppierung, Aufklappen, globale Suche und aktive
  Jobs bleibt OFF-051.

## 2026-07-28 – P52/OFF-051-Abschluss und P53-Kanonvorschau

- Eigentümer bestätigte alphabetische Stationsgruppen, Auf-/Zuklappen,
  globale Suche und ausschließlich aktive Industry Jobs,
- nach ergänzter vollständiger Stations-Klickfläche:
  `swift test --filter AppSourceArchitectureTests` mit isoliertem Scratch-
  und Modulcache: **10/10 bestanden**,
- erster SwiftPM-Versuch innerhalb der Dateisandbox: vor Testausführung an
  `sandbox_apply: Operation not permitted` beendet; außerhalb der Sandbox
  erfolgreich wiederholt,
- `Scripts/verify_xcode_project.py`: **16 Targets, acht Testtargets,
  zwei gemeinsame Schemes**, bestanden,
- `plutil -lint NewEdenNexus.xcodeproj/project.pbxproj`: bestanden,
- temporäre XcodeGen-Neugenerierung: dieselben 313 Swift-Referenzen und
  identische gemeinsame Schemes wie der Kanon,
- `xcodebuild -list -project NewEdenNexus.xcodeproj`: bestanden; zusätzlich
  automatisch sichtbare Modul-Schemes ändern die zwei gemeinsamen Schemes
  nicht,
- unveränderter `xcodebuild`-Debuglauf für macOS arm64 mit lokaler
  `AppSigning.xcconfig`/`LocalSigning.xcconfig`: Apple-Development-signiert,
  **BUILD SUCCEEDED**,
- Zertifikats-OU und konfigurierte Team-ID: beide `99K5WATB4A`; keine
  Signing-Änderung erforderlich,
- keine Projektkopie oder Promptdatei verschoben oder gelöscht;
  Eigentümerbestätigung für die P53-Verschiebungsvorschau offen.
## 2026-07-28 – P53 Kanon- und Abschlussprüfung

- `swift test --scratch-path .build-p53-final`: 668/668 Tests bestanden.
  Der erste Sandboxversuch scheiterte ausschließlich an
  `sandbox_apply: Operation not permitted`; der unveränderte Lauf außerhalb
  dieser Grenze war erfolgreich.
- `xcodebuild ... -scheme NewEdenNexus -configuration Debug
  -destination platform=macOS,arch=arm64`: `BUILD SUCCEEDED`, unverändert
  Apple-Development-signiert.
- `Scripts/verify_xcode_project.py`: 16 Targets, acht Testtargets und zwei
  gemeinsame Schemes bestätigt.
- `plutil -lint` und `xcodebuild -list`: erfolgreich; die CLI-Ausgabe enthielt
  nicht blockierende CoreSimulator-/Logstore-Sandboxwarnungen.
- `Scripts/verify_project_governance.py`: genau ein Projektkanon, neun
  Archivkopien, Promptregister und aktuelle Steuerlinks bestätigt.
- Archivprüfsummen entsprechen der P53-Einzelvorschau; nichts gelöscht.
- `git diff --check`: bestanden.

## 2026-07-28 – P52/OFF-053 Wallet-Zuordnungsrest

- `swift test --filter WalletFinanceSynchronizationTests`: **9/9
  bestanden**, einschließlich Teil-/Vollkapazität, Inkonsistenzschutz und
  schreibfreiem Verwerfen,
- `swift test --filter
  AppSourceArchitectureTests.testP52WalletAssignmentUsesRemainingCapacityAndValidPickerState`:
  **1/1 bestanden**,
- `swift test`: **673/673 bestanden**, 0 Fehler,
- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /tmp/NewEdenNexus-P42-DerivedData build`:
  Apple-Development-signiert, **BUILD SUCCEEDED**,
- separater `codesign --verify --deep --strict`-Nachlauf:
  `CSSMERR_TP_NOT_TRUSTED`; Xcodes Signierschritte selbst waren erfolgreich,
  realer Xcode-Start bleibt Bestandteil des Eigentümer-Retests,
- erste SwiftPM-Läufe innerhalb der Dateisandbox scheiterten vor
  Testausführung an `sandbox_apply: Operation not permitted`; unverändert
  außerhalb dieser Grenze wiederholt und bestanden,
- `xcrun swift-format lint --strict` ist kein bestehendes Projektgate und
  meldet flächendeckende vorbestehende Stilabweichungen; keine pauschale
  Neuformatierung durchgeführt,
- produktiver P42-1-Eigentümer-Retest offen; P42-2 nicht begonnen.

## 2026-07-28 – P55 Projektbudgetplanung

- `swift test --filter ProjectBudget`: **5/5 bestanden**,
- Budget-/Workspace-Architekturprüfungen: **2/2 bestanden**,
- `swift test`: **678/678 bestanden**, 0 Fehler,
- erster Gesamtlauf zeigte fünf veraltete Schema-v24-Erwartungen; diese
  wurden auf die additive v25-Grenze korrigiert und vollständig wiederholt,
- v24→v25-Migration erhält bestehende Projekte und erzeugt keine
  unbeauftragte Budgetkonfiguration,
- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-Budget-DerivedData build`:
  Apple-Development-signiert, **BUILD SUCCEEDED**,
- SwiftPM musste wegen `sandbox_apply: Operation not permitted` außerhalb
  der Dateisandbox wiederholt werden,
- OFF-054 Eigentümer-Sichttest bleibt offen.

## 2026-07-28 – P56 Gruppierte Build-or-Buy-Auswahl

- `swift test --filter BuildOrBuyWorkspaceViewModelTests`: **7/7
  bestanden**,
- `swift test --filter ProductionWorkspaceArchitectureTests`: **1/1
  bestanden**,
- `swift test`: **679/679 bestanden**, 0 Fehler,
- Gruppenaktionen, Reaktions-/Inventionsklassifikation und
  Stale-Vorschau geprüft,
- Xcode Debug für macOS arm64: **BUILD SUCCEEDED**,
- keine Schema-, Migrations- oder produktive Datenänderung,
- OFF-054 Eigentümer-Sichttest bleibt offen.

## 2026-07-29 – P56 Reaktionsfilter und kompakte Auswahl

- erster fokussierter SwiftPM-Lauf scheiterte vor Testausführung ausschließlich
  am gesperrten Benutzer-Modulcache; unverändert außerhalb der Dateisandbox
  wiederholt,
- `swift test --filter BuildOrBuyWorkspaceViewModelTests`: **7/7
  bestanden**,
- `swift test --filter ProductionWorkspaceArchitectureTests`: **1/1
  bestanden**,
- `swift test`: **679/679 bestanden**, 0 Fehler,
- Biochemical-/Composite-/Hybrid-/Unklassifiziert-Mapping, globale Auswahl,
  Filtertexte, kompakte Zeilen und bestehende Vorschaugates geprüft,
- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P56-Reactions-DerivedData
  build`: Apple-Development-signiert, **BUILD SUCCEEDED**,
- keine Schema-, Migrations- oder produktive Datenänderung,
- OFF-054 Eigentümer-Sichttest bleibt offen.

## 2026-07-29 – P56 Deutsche Zahlenformatierung

- `swift test --filter NewEdenNexusTests.testGerman`: **2/2 bestanden**,
- `swift test`: **681/681 bestanden**, 0 Fehler,
- Null, Tausender, Millionen, negative Mengen und negative ISK-Werte
  referenzgetestet,
- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P56-NumberFormat-DerivedData
  build`: Apple-Development-signiert, **BUILD SUCCEEDED**,
- erster SwiftPM-Sandboxlauf scheiterte vor Testausführung an gesperrtem
  Modulcache/`sandbox_apply`; mit temporärem Modulcache außerhalb dieser
  Grenze unverändert bestanden,
- keine Schema-, Migrations- oder produktive Datenänderung,
- OFF-054 Eigentümer-Sichttest bleibt offen.

## 2026-07-29 – OFF-055 SDE-Schema-Gate-Korrektur

- offizieller Read-only-Abgleich:
  - Zielbuild `3448696`, Vorgänger `3444265`,
  - höchster `schema-changelog.yaml`-Eintrag weiterhin `3407448`,
- `swift test --filter SDEInstallationServiceTests`: **7/7 bestanden**,
  einschließlich neuer Regression „neuer Datenbuild, verstandener älterer
  Schemawechsel“,
- erster vollständiger Lauf innerhalb der Dateisandbox:
  **679/682 bestanden**; ausschließlich drei RSA/JWT-Tests konnten dort keinen
  `SecKey` erzeugen,
- dieselben drei Tests außerhalb der Dateisandbox: **3/3 bestanden**,
- vollständiger unveränderter Lauf außerhalb dieser Grenze:
  `swift test`: **682/682 bestanden**, 0 Fehler,
- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-OFF055-SDEGate-DerivedData
  build`: Apple-Development-signiert, **BUILD SUCCEEDED**,
- `git diff --check`: bestanden,
- keine Schema-, Migrations- oder produktive Datenänderung,
- realer SDE-Installations-/Neustartnachweis bleibt OFF-055.

## 2026-07-29 – PLAN-006 Produktionsbuch und Metenox-Folgeplanung

- private Referenzarbeitsmappe ausschließlich schreibfrei geöffnet,
- 10/10 Tabellenblätter strukturell und als gerenderte Vorschau geprüft,
- Produktionsübersicht mit 25 Spalten und 166 Datenzeilen gegen den
  beschriebenen Eigentümer-Workflow abgeglichen,
- vorhandene Projekt-, Graph-, Budget-, Markt-, Industry-Job- und
  Walletverträge gezielt auf Wiederverwendung geprüft,
- keine Swift-, Xcode-, Datenmodell- oder produktive Datenänderung; daher kein
  erneuter Build oder Swift-Testlauf erforderlich,
- Projekt-Governance, Prompt-/ADR-Links und `git diff --check` gemäß
  PLAN-006-Abschlussbericht geprüft,
- keine private Arbeitsmappe und keine daraus stammenden persönlichen
  ESI-Werte ins Repository übernommen.

## 2026-07-29 – PLAN-006 Ausführungsprompts und Preisquellen

- P57–P61 auf 96/111/99/102/117 Zeilen erweitert,
- Live-ESI-/Cache-/manuell-/CSV-/unavailable-Priorität sowie Jita und
  änderbare benannte Marktquelle konsistent geprüft,
- Buy-/Sell-, Prognose- und Realwertgrenzen geprüft,
- keine Swift-, Schema- oder produktive Datenänderung,
- Governance, Xcode-Projektkonsistenz und `git diff --check` bestanden.

## 2026-07-29 – OFF-055 Eigentümer-Liveabnahme

- App vor Neustart: Build `3.448.696`, Status `Update abgeschlossen`,
- reales Installationsjournal: `completed`, Backup und Cleanup erfolgreich,
- App vollständig beendet und lokaler Debugbuild erneut gestartet,
- neuer Prozess für dieselbe App-Binary nachgewiesen,
- SQLite nach Neustart: `PRAGMA quick_check` = `ok`,
- genau ein aktiver Katalog: Build `3.448.696`,
- Build `3.444.265` inaktiv als Rollbackversion erhalten,
- aktiver Katalog: 52.822 Itemtypen, 5.082 Blueprints, 19.137 Aktivitäten,
- kein neuer Nexus-Diagnosecode; OFF-055 bestanden.

## 2026-07-29 – OFF-054 Eigentümer-Sichttest

- `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-OFF054-Signed-DerivedData
  build`: Apple-Development-signiert, **BUILD SUCCEEDED**,
- 3/3 fokussierte Tests bestanden:
  Gruppenwahl/Reaktionsklassifikation, deutsche Mengen- und
  ISK-Formatierung,
- Eigentümer bestätigte OFF-054 und die sichtbare Punktgruppierung,
- kein Code, Schema und keine produktiven Daten geändert,
- fehlender Ziel-Preissatz verhindert weiterhin sicher die Preisübernahme;
  Bedienlücke als OFF-058/KI-059 für P58 erfasst.

## 2026-07-29 – P57 Produktionsbuch-Domäne und Persistenz

- fokussiert:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/nen-p57-rerun-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/nen-p57-rerun-module-cache
  swift test --disable-sandbox
  --scratch-path /private/tmp/nen-p57-rerun-build
  --filter 'ProductionBatch|AppNavigationAccessibilityTests|AppSourceArchitectureTests'`
  → **27/27 bestanden**,
- vollständig mit realem macOS-Security-Zugriff:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/nen-p57-final-full-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/nen-p57-final-full-module-cache
  swift test --disable-sandbox
  --scratch-path /private/tmp/nen-p57-final-full-build`
  → **695/695 bestanden**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P57-Final-DerivedData build`
  → Apple-Development-signiert, **BUILD SUCCEEDED**,
- geprüft: Domänenvalidierung, Vorschau/Bestätigung, Stale-Schutz,
  manuelle/ESI-Vorbelegung, Filter, eindeutige Jahresnummer,
  v25→v26-Migration ohne erfundene Historie, Wiederöffnung sowie
  Backup/Restore einer Charge,
- CoreData gab in isolierten Tests informative
  Store-Changed-Registrierungsmeldungen aus; kein Test schlug fehl,
- offen: realer Eigentümertest nach App-Neustart (OFF-059).

## 2026-07-29 – OFF-059 P57-Eigentümer-Neustarttest

- fokussiert nach Korrektur:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/nen-off059-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/nen-off059-module-cache
  swift test --disable-sandbox --scratch-path /private/tmp/nen-off059-build
  --filter 'ProductionBatch|AppSourceArchitectureTests'`
  → **24/24 bestanden**,
- vollständig:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/nen-off059-full-module-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/nen-off059-full-module-cache
  swift test --disable-sandbox
  --scratch-path /private/tmp/nen-off059-full-build`
  → **695/695 bestanden**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-OFF059-DerivedData build`
  → Apple-Development-signiert, **BUILD SUCCEEDED**,
- UI-Regression: Bestätigungsdialog liegt in der modalen Erfassungsansicht;
  `productionLedger.confirmBatch` ist sichtbar und auslösbar,
- real: Charge `2026-0001`, Rhea, 1 Unit, Status Produziert, UALX-3
  gespeichert; App-Prozess vollständig beendet; derselbe Build neu gestartet;
  Charge mit unveränderter Nummer und denselben Kerndaten wieder geöffnet,
- informative CoreData-Migrationsmeldungen in isolierten Tests; keine
  Testfehler.

## 2026-07-29 – P58 Produktionskosten und Preisvorschläge

- fokussiert:
  `CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-p58-clang-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-p58-swiftpm-cache
  swift test --disable-sandbox
  --scratch-path /tmp/new-eden-nexus-p58-build
  --filter 'ProductionBatchCostManagementTests|ProductionBatchCostTests|
  ProductionBatchCostPersistenceTests|MarketPriceImportViewModelTests|
  AppSourceArchitectureTests|
  NexusMigrationBackupCoordinatorTests|SQLiteLocalBackupServiceTests'`
  → **37/37 bestanden**,
- ein vollständiger Lauf in der beschränkten Dateisandbox erreichte
  **701/704**; ausschließlich drei bestehende JWT-Security-Tests konnten dort
  keinen temporären `SecKey` erzeugen,
- abschließend mit realem macOS-Security-Zugriff:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/new-eden-nexus-p58-final-clang-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/new-eden-nexus-p58-final-swiftpm-cache
  swift test --disable-sandbox
  --scratch-path /private/tmp/new-eden-nexus-p58-final-build`
  → **704/704 bestanden**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-P58-DerivedData build`
  → Apple-Development-signiert, **BUILD SUCCEEDED**,
- geprüft: Mehrfachoutput, Rundung, unbekannte Werte, Nullkosten,
  Division durch null, Overflow, alternative Quote, unveränderte
  Projekt-/Graphbasis, v26→v27, Wiederöffnung, fehlende Charge,
  Ziel-Preissatz-Anlage und bestätigte Übernahme,
- `xcodebuild` meldete nur die bekannte Auswahl der ersten passenden
  arm64/x86_64-macOS-Destination und die informative fehlende
  AppIntents-Abhängigkeit,
- offener nichtautomatisierbarer Nachweis: realer Eigentümer-Sichttest
  Jita plus geänderte Marktquelle (OFF-060).

## 2026-07-29 – OFF-060 Sichtbarkeitskorrektur und Testvorbereitung

- fokussiert:
  `CLANG_MODULE_CACHE_PATH=/tmp/new-eden-nexus-off060-clang-cache
  SWIFTPM_MODULECACHE_OVERRIDE=/tmp/new-eden-nexus-off060-swiftpm-cache
  swift test --disable-sandbox
  --scratch-path /tmp/new-eden-nexus-off060-build
  --filter 'AppSourceArchitectureTests|ProductionBatchCostTests|
  ProductionBatchCostManagementTests'`
  → **18/18 bestanden**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS
  -derivedDataPath /private/tmp/NewEdenNexus-OFF060-DerivedData build`
  → Apple-Development-signiert, **BUILD SUCCEEDED**,
- geprüft: sichtbare Quoteherkunft, Beobachtungszeit, Preisregel,
  Mengenabdeckung sowie Marge und ROI; Kosten- und Stale-Regressionen,
- die vollständige Suite wurde nach dieser reinen UI-/Architekturteständerung
  nicht erneut ausgeführt; der unmittelbar vorherige P58-Lauf bleibt
  **704/704**,
- offen: realer Eigentümerlauf mit Jita und geänderter Marktquelle.

## 2026-07-29 – OFF-060 Eigentümerabnahme

- der Eigentümer bestätigte ausdrücklich die Schließung des sichtbaren
  Jita-/Alternativmarkt-Tests,
- damit ist die betriebliche Ebene zusätzlich zu 18/18 fokussierten Tests,
  dem vorherigen P58-Gesamtlauf mit 704/704 und dem signierten
  Xcode-Debugbuild erfüllt,
- keine Tests und kein Build wurden für die reine Statusaktualisierung erneut
  ausgeführt.

## 2026-07-29 – P59 Wallet-Verkaufszuordnung und Realgewinn

- fokussiert nach der v28-Inspector-Korrektur:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P59-clang
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P59-swiftpm
  swift test --disable-sandbox
  --scratch-path /private/tmp/NewEdenNexus-P59-build
  --filter 'NexusMigrationBackupCoordinatorTests|LocalRecoveryRuntimeTests|
  ProductionBatchSale'`
  → **15/15 bestanden**,
- vollständig außerhalb der eingeschränkten Security-Sandbox:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-P59-final-clang
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-P59-final-swiftpm
  swift test --disable-sandbox
  --scratch-path /private/tmp/NewEdenNexus-P59-final-build`
  → **713/713 bestanden**,
- der eingeschränkte Vergleichslauf erreichte 710/713; ausschließlich drei
  bestehende JWT-Tests konnten dort keinen temporären `SecKey` erzeugen,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-P59-Unsigned-DerivedData-2
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO -jobs 1 build`
  → **BUILD SUCCEEDED**,
- normaler signierter Xcode Debug: vor Codesignatur abgebrochen, weil die
  lokale `LocalSigning.xcconfig` ein nicht vorhandenes persönliches
  Apple-Development-Zertifikat auswählt; keine Signingdaten geändert,
- geprüft: Teil-/Vollverkauf, Gebühren, manuelle Belege, unveränderliche
  Kostenbindung, Quellrest, Doppel-/Überbuchung, Stale Revision, Verwerfen,
  Offline-/Accountbestand, v27→v28, Wiederöffnung und Recovery,
- offen: OFF-061 Eigentümerlauf nach Wiederherstellung der lokalen Signierung.

## 2026-07-29 – KI-060 lokale Signierung / OFF-061 Vorbereitung

- Identitätsprüfung: `security find-identity -v -p codesigning` →
  eine gültige Apple-Development-Identität; Zertifikats-OU und lokale
  Teamkonfiguration `99K5WATB4A` stimmen überein,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination platform=macOS,arch=arm64
  -derivedDataPath /private/tmp/NewEdenNexus-OFF061-Signed-DerivedData
  -jobs 1 build` → **BUILD SUCCEEDED**,
- Signatur:
  `codesign --verify --deep --strict --verbose=2 NewEdenNexus.app` →
  gültig auf Datenträger und Designated Requirement erfüllt,
- der kanonische Xcode-Build öffnete den produktiven v28-Store; die
  protokollierten `NEN-PER-001`-Starts gehörten alten P39-/P40-Buildkopien,
- keine Codeänderung und daher keine erneute SwiftPM-Suite; P59 bleibt
  **15/15 fokussiert, 713/713 vollständig**,
- offen: sichtbare OFF-061-Schritte und echter Neustart.

## 2026-07-29 – OFF-061 sichtbare Wallet-Nachweisvorbereitung

- fokussiert:
  `CLANG_MODULE_CACHE_PATH=/private/tmp/NewEdenNexus-OFF061-fix-clang
  SWIFTPM_MODULECACHE_OVERRIDE=/private/tmp/NewEdenNexus-OFF061-fix-swiftpm
  swift test --disable-sandbox
  --scratch-path /private/tmp/NewEdenNexus-OFF061-fix-build
  --filter 'ProjectEconomicsArchitectureTests|
  WalletFinanceSynchronizationTests|ProductionBatchSale'`
  → **19/19 bestanden**,
- normaler signierter arm64-Xcode-Debugbuild mit
  `/private/tmp/NewEdenNexus-OFF061-Signed-DerivedData`
  → **BUILD SUCCEEDED**,
- `codesign --verify --deep --strict --verbose=2`
  → gültig; Team `99K5WATB4A`,
- die 713er-Vollsuite wurde für die kleine UI-Verdrahtung nicht erneut
  ausgeführt; ihr unveränderter P59-Nachweis bleibt gültig,
- offen: Charge ≥2 Output-Units, Kostenbasis und Wallet-Nachweise real
  bestätigen; anschließend Teilzuordnung, Verwerfen, Gebühr, Vollzuordnung
  und Neustart.

## 2026-07-30 – OFF-061 Stale-Chargenhinweis

- fokussiert:
  `swift test --disable-sandbox
  --scratch-path /private/tmp/NewEdenNexus-OFF061-stale-build
  --filter 'ProductionBatchCostManagementTests|
  ProductionBatchSaleArchitectureTests'`
  → **2/2 bestanden**,
- normaler Apple-Development-signierter arm64-Xcode-Debugbuild mit
  `/private/tmp/NewEdenNexus-OFF061-Stale-DerivedData`
  → **BUILD SUCCEEDED**,
- geprüft: veraltete Projekt-/Graphbasis bleibt fail-closed; die UI nennt
  den sicheren Weg über eine neue Charge und behauptet keine Neuberechnung
  historischer Materialien.

## 2026-07-30 – KI-062 Graphresolver

- Reproduktion auf temporärer Kopie des aktuellen Xcode-Laufstores:
  `NEN-GRAPH-001`, Type 16672, Kandidaten 45732/46207,
- nach Korrektur auf demselben Datenstand: Graph vollständig mit
  **566 Knoten/565 Kanten**,
- fokussiert:
  `swift test --disable-sandbox
  --scratch-path /private/tmp/NewEdenNexus-GRAPH-001-build
  --filter 'RecipeResolutionTests|ProductionGraphServiceTests|
  RecipeResolutionPersistenceTests|T2IndustryDataTests'`
  → **44/44 bestanden**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination 'platform=macOS,arch=arm64'
  -derivedDataPath /private/tmp/NewEdenNexus-GRAPH-001-DerivedData
  -jobs 1 build`
  → **BUILD SUCCEEDED**, Apple-Development-signiert,
- Hinweis: Der erste sandboxierte Xcode-Aufruf konnte die lokale
  Signingidentität nicht lesen; derselbe Build außerhalb der Sandbox
  bestand. Keine Signing- oder Teamkonfiguration wurde verändert.

## 2026-07-30 – KI-062 Eigentümer-Retest

- Evidenzstufe: Eigentümerbetrieb/UI-Abnahme,
- Umgebung: realer App-Lauf nach neuem Xcode-Build,
- Ergebnis: Der Projekteigentümer bestätigt, dass der Produktionsgraph
  wieder erzeugt werden kann,
- KI-062 damit zusätzlich zu 44/44 automatisierten Tests, realer
  Storekopie mit 566 Knoten/565 Kanten und erfolgreichem signiertem
  Xcode-Debugbuild sichtbar bestanden,
- für die reine Statusbestätigung keine Tests und keinen Build erneut
  ausgeführt,
- OFF-061 bleibt als getrenntes Betriebs- und Datenzuordnungsgate offen.

## 2026-07-30 – KI-063 Budgetkosten-Beschriftungen

- fokussiert:
  `swift test --disable-sandbox --filter ProjectEconomicsArchitectureTests`
  → **1/1 bestanden**,
- SwiftPM Debug:
  `swift build --disable-sandbox` → **Build complete**,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination 'platform=macOS,arch=arm64'
  -derivedDataPath
  /private/tmp/NewEdenNexus-BudgetLabels-Signed-DerivedData
  -jobs 1 build`
  → **BUILD SUCCEEDED**, Apple-Development-signiert,
- geprüft: dauerhaft sichtbare Quellbeschriftungen für Logistik- und
  Produktionskosten sowie unveränderte Accessibility-Bezeichnungen,
- Sandbox-Erstläufe scheiterten erwartbar an Benutzercache-/SwiftData-Makro-
  und Signingzugriff; der reguläre lokale Xcode-Lauf außerhalb der Sandbox
  bestand. Keine Signing- oder Teamkonfiguration wurde verändert.

## 2026-07-30 – KI-064 Vereinfachte Chargenerfassung

- fokussiert:
  `swift test --disable-sandbox --filter ProductionBatchManagementTests`
  und
  `--filter AppSourceArchitectureTests/testProductionLedgerExposesPreviewConfirmationAndAccessibility`
  → **6/6 bestanden**,
- vollständig: **706/716 bestanden**; sieben bestehende P51-UI-Erwartungen
  beziehen sich auf die bewusst zurückgezogene Projektfinanzoberfläche,
  drei SSO-Tests konnten ihre lokalen `SecKey`-Fixtures nicht erzeugen,
- Xcode:
  `xcodebuild -project NewEdenNexus.xcodeproj -scheme NewEdenNexus
  -configuration Debug -destination 'platform=macOS,arch=arm64'
  -derivedDataPath /private/tmp/NewEdenNexus-KI064-Signed-DerivedData
  -jobs 1 build`
  → **BUILD SUCCEEDED**, Apple-Development-signiert,
- geprüft: Charge ohne Ort speicherbar, Name ohne technische ID zulässig,
  unbestätigte Vorschau bleibt schreibfrei, optionale Angaben und
  technische Zuordnung sind verständlich getrennt.

## 2026-07-30 – KI-064 Eigentümer-Sichttest

- Evidenzstufe: realer Eigentümerbetrieb,
- Ergebnis: Chargenerfassung funktioniert und ist nach der Verschlankung
  deutlich besser nutzbar,
- keine Tests und keinen Build für die reine Statusbestätigung erneut
  ausgeführt,
- KI-064 vollständig geschlossen; OFF-061 setzt bei der Kostenbasis fort.
