# Runs und Ausgabemengen

Stand: 2026-07-24 · P14

## Zweck und Umfang

P14 berechnet für jeden im aktuellen Produktionsgraph vorhandenen
Rezeptknoten die benötigten vollständigen Runs, die tatsächlich erzeugte
Ausgabemenge und den unvermeidbaren Überschuss. Die Berechnung ist
UI-unabhängig, deterministisch und versioniert.

Material Efficiency und Materialgesamtmengen gehören zu P15; Rekursion,
Aggregation, BPO-/BPC-Besitz und Jobaufteilung gehören nicht zu P14.

## Verbindliche Formel

Für positive Zielmenge `Z` und positiven Output je Run `O` gilt:

```text
Quotient = Z / O
Rest = Z % O
Runs = Quotient + (Rest == 0 ? 0 : 1)
Ausgabe = Runs × O
Überschuss = Ausgabe − Z
```

Die Implementierung verwendet ausschließlich Ganzzahlen. Die alternative
Ceiling-Formel `(Z + O - 1) / O` wird wegen ihres möglichen
Additionsüberlaufs nicht verwendet. Die Multiplikation wird geprüft; bei
Überlauf entsteht ein typisierter Fehler und kein Graph wird ersetzt.

Referenz: Ziel 25, Output 10 ergibt 3 Runs, 30 Ausgabe und 5 Überschuss.

## Domainmodell

`ProductionRunCalculation` enthält:

- Formelversion,
- angefragte Ausgabemenge,
- Output je Run,
- benötigte Runs,
- tatsächlich produzierte Ausgabe,
- Überschuss.

Der öffentliche Initialisierer berechnet alle abgeleiteten Werte zentral.
Beim Decodieren werden die gespeicherten Werte neu berechnet und verglichen.
Manipulierte oder widersprüchliche Payloads sind deshalb nicht ladbar.

## Graph- und Persistenzintegration

Graphformat 2 ergänzt `runCalculation` an jedem Rezeptknoten. Materialknoten
dürfen keine Runberechnung tragen. Rezeptoutput und Berechnungsoutput müssen
übereinstimmen; beim Zielknoten muss die angefragte Menge der
Projektzielmenge entsprechen.

Graphformat 1 bleibt lesbar, enthält keine Runwerte und gilt als veraltet.
Es wird nicht stillschweigend verändert. Der Benutzer kann den Graphen
bewusst mit der aktuellen Projekt- und Katalogprovenienz neu erzeugen.

Schema v7 ergänzt den persistenten Graphdatensatz leichtgewichtig um die
optionale `calculationFormulaVersion`. Neue Graphen tragen Formelversion 1;
migrierte Format-1-Graphen behalten `nil`. Das Repository gleicht
Metadatenspalte, Payloadformat und Domainberechnung beim Laden ab.

Backuppakete verwenden Schema 7.0.0 und akzeptieren die migrierbaren
Versionen 1.0.0 bis 7.0.0.

P15 baut auf diesen unveränderten Runwerten auf, ergänzt Graphformat 3 und
Schema v8 und dokumentiert die Materialformel getrennt in
[`MATERIAL_EFFICIENCY.md`](MATERIAL_EFFICIENCY.md).

## `maxProductionLimit`

Die SDE-Eigenschaft `maxProductionLimit` bleibt reine Rezeptprovenienz. Sie
ist in P14 weder eine Obergrenze für Projektruns noch eine Jobgröße. Ohne
persönlichen BPO-/BPC-Bestand und verbleibende lizenzierte Runs wäre eine
automatische Aufteilung fachlich unbelegt.

## UI und Fehlerverhalten

Die separate Graphansicht zeigt Zielmenge, Output je Run, Runs, tatsächliche
Ausgabe, Überschuss und Formelversion. Alte Format-1-Graphen bleiben sichtbar,
werden als veraltet markiert und zeigen keine erfundenen Runwerte.

Rechen-, Validierungs-, Cancellation- oder Persistenzfehler laufen über die
zentrale Produktionsgraph-Fehlergrenze. Ein bestehender Graph bleibt bei
jedem fehlgeschlagenen Neuberechnungsversuch erhalten.

## Nachweis

- Referenz-, Grenz-, Überlauf- und Manipulationstests,
- Fertigungs- und Reaktionsrezepte,
- Format-1-/Format-2-Graphvalidierung,
- Repository-Roundtrip und Bestandsschutz,
- vollständige v3→v7- sowie v6→v7-Migrationsprüfung,
- Backupkompatibilität 1.0.0 bis 7.0.0,
- UI-/Architekturtests,
- SwiftPM und Xcode in Debug und Release,
- isolierter Schema-v7-App-/Store-Smoke-Test.
