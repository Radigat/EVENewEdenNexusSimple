# P53 – Bereinigungsvorschau

Stand: 2026-07-28  
Status: bestätigt und vollständig ausgeführt

## Zweck und Grenze

Diese Vorschau dokumentiert die in P53 gefundenen Projekt- und
Promptkopien sowie die anschließend ausdrücklich bestätigte Ausführung.
Es wurde nichts gelöscht, committed oder gepusht. App-Daten,
ESI-Snapshots und Schlüsselbundinhalte sind nicht betroffen.

## Kanonisches Xcode-Projekt

`NewEdenNexus.xcodeproj` ist der einzige vorgesehene Kanon in der
Repositorywurzel:

- 313 Swift-Quellreferenzen, keine gegenüber dem aktuellen Kanon fehlend,
- 16 Targets, davon acht Testtargets,
- zwei gemeinsame Schemes,
- `plutil`, Projektverifier und `xcodebuild -list` bestanden,
- temporäre Neugenerierung aus `project.yml` enthält dieselben Quellen und
  identische gemeinsame Schemes,
- unveränderter Apple-Development-signierter Standard-Debugbuild bestanden.

## Xcode-Projektkopien

Die folgenden Verzeichnisse sind eigenständige historische
Generierungsstände. Ihre `project.pbxproj`-Hashes sind jeweils verschieden;
keine Kopie ist aktueller oder vollständiger als der Kanon.

| Pfad | Gitstatus | geändert | SHA-256 `project.pbxproj` | Swift-Referenzen | fehlen | Bewertung |
|---|---|---|---|---:|---:|---|
| `NewEdenNexus 2.xcodeproj` | versioniert | 2026-07-24 00:20 | `163ca5d725c1…` | 97 | 218 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 3.xcodeproj` | versioniert | 2026-07-24 00:24 | `e6373256dfdd…` | 98 | 217 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 4.xcodeproj` | versioniert | 2026-07-24 19:04 | `28971cc24370…` | 133 | 182 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 5.xcodeproj` | versioniert | 2026-07-24 20:00 | `1a21ac20a491…` | 145 | 170 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 6.xcodeproj` | versioniert | 2026-07-24 22:21 | `2dbe1107e985…` | 162 | 153 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 7.xcodeproj` | versioniert | 2026-07-25 08:33 | `89fa0e1af2d5…` | 183 | 132 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 8.xcodeproj` | versioniert | 2026-07-25 22:33 | `8e45f0635224…` | 208 | 107 | historisch, zusätzlich zwei entfernte Legacy-Dateien |
| `NewEdenNexus 9.xcodeproj` | versioniert | 2026-07-26 17:48 | `17b4873c6f32…` | 271 | 42 | historischer Vor-ESI-/Walletstand |
| `NewEdenNexus 10.xcodeproj` | untracked | 2026-07-27 08:38 | `edec7e122817…` | 305 | 8 | neueste Kopie, aber ohne aktuelle Orts-/Scope-/Schema-v24-Dateien |

Bestätigte und ausgeführte recoverbare Aktion:

1. Alle neun nummerierten Projektverzeichnisse wurden einzeln nach
   `Documentation/Archive/XcodeProjects/` verschoben.
2. Originalnamen und Inhalte blieben unverändert.
3. In der Repositorywurzel liegt nur noch `NewEdenNexus.xcodeproj`.
4. Kanon, Promptregister und aktuelle Dokumentationslinks werden durch
   `Scripts/verify_project_governance.py` sowie den bestehenden
   Xcode-Projektprüfer abgesichert.

Es erfolgt keine Löschung. Für die versionierten Kopien bleibt zusätzlich
die Git-Historie als Wiederherstellungsweg erhalten.

## Doppelter P21-Prompt

Kanon:

- `Documentation/Prompts/MVP/P21_CSV-Bestandsimport.md`
- 204 Zeilen, Status erledigt, vollständiger Vertrag und Berichtverweis.

Historischer Entwurf:

- `Documentation/Prompts/MVP/P21_CSV-Bestandsimport 2.md`
- acht Zeilen, Status offen, nicht vom Register oder Menü referenziert.

Bestätigte und ausgeführte recoverbare Aktion:

- der achtzeilige Entwurf wurde nach
  `Documentation/Prompts/Archive/P21_CSV-Bestandsimport_Entwurf.md`
  verschoben;
- der vollständige P21-Kanon blieb unverändert.

P07A/P07B/P07C und P09A/P09B sind keine Dubletten, sondern bewusst
benannte Teilpakete und bleiben unverändert.

## Signing-Prüfung

Keine Änderung vorgeschlagen:

- lokale, git-ignorierte Konfiguration verwendet die Identität
  `C30E42C7063BC7E2CD4DA1E57E4C84AA4D0FDCA7`,
- deren Zertifikats-OU und der konfigurierte Development-Teamwert sind
  beide `99K5WATB4A`,
- die sichtbare Zertifikatsbezeichnung endet zwar auf `NU3SG2232A`, dieser
  Text ist nicht die Team-ID,
- der unveränderte Standardbuild signierte erfolgreich.

OFF-052 beruht damit auf einer früheren Fehlinterpretation der sichtbaren
Zertifikatsbezeichnung. Weder `project.yml`, das Xcode-Projekt noch
`LocalSigning.xcconfig` müssen geändert werden.

## Eigentümerbestätigung und Ausführungsnachweis

Der Eigentümer bestätigte ausdrücklich:

> P53-Dateiverschiebungen wie vorgeschlagen ausführen.

Anschließend wurden ausschließlich die oben einzeln aufgeführten
Verzeichnisse und die alte P21-Entwurfsdatei in die dokumentierten
Archivpfade verschoben. Prüfsummen, Originalnamen der Projektkopien und
Inhalte blieben erhalten; es gab keine Löschung.
