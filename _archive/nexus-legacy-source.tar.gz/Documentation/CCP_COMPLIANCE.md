# CCP-Compliance und offizielle Datenquellen

Stand der technischen Vorprüfung: 2026-07-26
Geltungsbereich: SDE- und spätere ESI-Integration

## Einordnung

Dieses Dokument ist eine technische und organisatorische Prüfliste, keine
Rechtsberatung und keine Behauptung einer Freigabe durch CCP. Verträge werden
weder durch den Quellcode noch durch Codex im Namen des Projekteigentümers
akzeptiert.

## Geprüfte offizielle Quellen

| Quelle | URL | Technische beziehungsweise organisatorische Konsequenz |
|---|---|---|
| Developer License Agreement | https://developers.eveonline.com/license-agreement | Nutzung lizenzierter Materialien setzt die aktuelle Vereinbarung voraus; unabhängige Drittanbieterstellung, Eigentumshinweis, zulässiger Zweck, Marken- und Datenschutzregeln beachten. |
| SDE-Dokumentation | https://developers.eveonline.com/docs/services/static-data/ | JSON Lines und YAML sind verfügbar; JSONL ist für große Dateien der bevorzugte Streamingpfad. |
| SDE-Übersicht | https://developers.eveonline.com/static-data | ausschließlich offizielle CCP-Veröffentlichung als reguläre Quelle verwenden. |
| Aktuelle Buildmetadaten | https://developers.eveonline.com/static-data/tranquility/latest.jsonl | Datensatz `_key == "sde"` auswerten; unbekannte oder doppelte Schlüssel ablehnen. |
| Versioniertes JSONL-Archiv | `https://developers.eveonline.com/static-data/tranquility/eve-online-static-data-<build>-jsonl.zip` | Download-URL nur aus validierter offizieller Buildnummer bilden. |
| Änderungsinformationen | `https://developers.eveonline.com/static-data/tranquility/changes/<build>.jsonl` | optional nutzbar; vollständiger Import bleibt verbindlicher Rückfallweg. |
| Schema-Changelog | https://developers.eveonline.com/static-data/tranquility/schema-changelog.yaml | vor Import prüfen; unbekannte zentrale Strukturänderungen verhindern die Aktivierung. |
| ESI Best Practices | https://developers.eveonline.com/docs/services/esi/best-practices/ | aussagekräftiger User-Agent, Cacheheader und ETag beachten; keine Cacheumgehung. |
| ESI Rate Limiting | https://developers.eveonline.com/docs/services/esi/rate-limiting/ | `Retry-After` und Ratelimitheader respektieren, frühzeitig drosseln, keine Grenzwertausreizung. |
| Third Party Policies | https://support.eveonline.com/hc/en-us/articles/8564030965660-Third-Party-Policies | am 2026-07-26 erneut geprüft; keine Clientmanipulation, kein Cache Scraping und kein unfairer Spielvorteil. |
| EVE Online EULA | https://support.eveonline.com/hc/en-us/articles/8413329735580-EVE-Online-End-User-License-Agreement | am 2026-07-26 erneut geprüft; die Seite weist eine Aktualisierung vom 2026-06-04 aus. |
| EVE Online Terms of Service | https://support.eveonline.com/hc/en-us/articles/8414770561948-EVE-Online-Terms-of-Service | am 2026-07-26 erneut geprüft; keine offizielle Vertretung behaupten und keine CCP-Dienste missbräuchlich belasten. |

## Aktueller technischer Abrufnachweis

Am 2026-07-26 lieferte der offizielle Metadatenendpunkt unverändert:

- Buildnummer `3444265`,
- Veröffentlichungszeit `2026-07-23T11:06:22Z`,
- HTTP 200,
- `Cache-Control: max-age=300`,
- `ETag` und `Last-Modified`.

Der Schema-Changelog war ebenfalls mit `ETag`, `Last-Modified` und
`Cache-Control: max-age=300` erreichbar. Der höchste darin aufgeführte
`afterBuildNumber` war bei der Prüfung `3407448`.

P07A hat diese beiden offiziellen Ressourcen erneut read-only geprüft. Die
tatsächlichen Inhaltstypen `application/jsonlines+json` und `text/vnd.yaml`
werden vom Adapter akzeptiert. Die automatisierten Tests verwenden
ausschließlich injizierte HTTP-Stubs und erzeugen keine CCP-Last.

Der aktuell end-to-end geprüfte offizielle SDE-Stand ist Build `3444265`.
Er wurde am 2026-07-23 zweimal ausschließlich über die feste offizielle URL
geladen, sicher entpackt, importiert, aktiviert, wieder geöffnet und
abgefragt. Das ist ein isolierter technischer Testnachweis, keine Installation
in einem produktiven Benutzerstore und keine rechtliche Freigabe durch CCP.

P07B implementiert den Downloader technisch ausschließlich für die feste
versionierte offizielle URL. Die produktive Konfiguration lehnt eine fehlende
Kontaktangabe ab; der Installationsservice verlangt zusätzlich eine
ausdrückliche Eigentümerbestätigung. Automatisierte Tests verwenden lokale
Transportstubs und synthetische ZIP-Dateien. Die Realabnahme erhielt die
Kontaktangabe ausschließlich zur Laufzeit; sie wurde nicht in Quellcode,
Dokumentation, Journal oder Testartefakten gespeichert. Diese technischen
Gates ersetzen keine persönliche Vertragsentscheidung.

P07C verdrahtet diese Gates produktiv. Die Kontaktangabe wird erst nach
Benutzeraktion im macOS-Schlüsselbund gespeichert und nicht in UserDefaults,
Logs oder Diagnoseexporte übernommen. Automatische Installation ist
standardmäßig aus und verlangt sowohl Kontakt als auch eine ausdrücklich
gesetzte persönliche Prüfbestätigung.

Die Rechtsansicht verwendet am 2026-07-23 den auf der offiziellen
Developer-License-Seite angegebenen Hinweis:

> © 2014 CCP hf. All rights reserved. "EVE", "EVE Online", "CCP", and all
> related logos and images are trademarks or registered trademarks of CCP hf.

Die App nennt sich ausdrücklich unabhängige Drittanbieteranwendung, zeigt
aktive SDE-Buildnummer und JSONL-Format und verlinkt DLA, SDE-Dokumentation,
EULA, Terms of Service und Third Party Policies ausschließlich offiziell.
Das ist keine Rechtsberatung und keine Freigabe durch CCP.

## Relevante aktuelle Anforderungen

- Ausschließlich offizielle CCP-/EVE-Endpunkte als reguläre SDE-Quelle.
- HTTP-Validatoren und Servercache respektieren.
- Keine aggressiven Polling- oder Retryschleifen.
- Anwendung und User-Agent eindeutig identifizierbar machen.
- Keine ungeprüfte Kontaktadresse oder Geheimnisse im Quellcode.
- SDE-Daten nur für den zulässigen Anwendungszweck verwenden.
- Keine Darstellung als offizielles CCP-Produkt oder CCP-Vertreter.
- Aktuellen Eigentums- und Markenhinweis vor Veröffentlichung nochmals
  wortgetreu gegen die dann aktuelle DLA-Fassung prüfen.
- CCP-Logos und Marken nicht kombinieren oder verändern, sodass eine offizielle
  Verbindung vermutet werden könnte.
- Keine Spielerbeobachtung ohne Wissen und Einwilligung.
- ESI und SDE technisch und fachlich getrennt behandeln.

Die aktuelle DLA verlangt außerdem ein gültiges EVE-Konto in gutem Stand,
eine aktuelle erreichbare E-Mail-Adresse und die Nutzung lizenzierter
Materialien für den vorgesehenen EVE-Spielerunterstützungszweck. Eine
Monetarisierung darf nicht stillschweigend als zulässig angenommen werden.

## Vom Projekteigentümer persönlich zu erledigen

Diese Punkte können nicht durch Codex bestätigt oder stellvertretend erledigt
werden:

1. aktuelle Developer License Agreement lesen und selbst entscheiden, ob sie
   akzeptiert wird; für die P07B-Abnahme wurde diese Entscheidung am
   2026-07-23 ausdrücklich bestätigt,
2. Berechtigung, Volljährigkeit, gültiges EVE-Konto und erreichbare
   Entwickler-E-Mail nach den aktuellen Anforderungen sicherstellen,
3. eine geeignete Kontaktadresse oder andere von CCP akzeptierte
   Kontaktmöglichkeit für den zentral konfigurierten User-Agent aktuell
   halten; für P07B wurde sie ausschließlich zur Laufzeit übergeben,
4. Geschäfts-/Monetarisierungsmodell gegen DLA und gegebenenfalls mit
   Rechtsberatung prüfen,
5. Eigentums-, Marken- und Unabhängigkeitshinweis vor Release freigeben,
6. jede geplante Nutzung von CCP-Logos, Bildern oder Image-Export-Daten
   gesondert freigeben und deren aktuelle Bedingungen prüfen,
7. Datenschutzinformationen, Einwilligung, Löschung und Export spätestens vor
   Aktivierung personenbezogener ESI-Funktionen rechtlich prüfen,
8. Änderungen der offiziellen Bedingungen und Nachrichten an die hinterlegte
   Entwickleradresse regelmäßig kontrollieren.

## REL-001 – öffentliche Releaseprüfung vom 2026-07-26

Die technische Reprüfung bestätigt:

- der in der App gezeigte Eigentums-/Markenhinweis entspricht weiterhin dem
  Wortlaut auf der aktuellen DLA-Seite,
- die App behauptet keine offizielle Verbindung, Unterstützung oder
  Billigung durch CCP,
- im geprüften Repositoryumfang befinden sich keine CCP-Logos oder
  Image-Export-Dateien,
- die aktuelle offizielle SDE-Buildnummer ist weiterhin `3444265` und stimmt
  mit dem real geprüften Stand überein,
- OFF-031 ist mit zwei tatsächlich ausgeführten nativen Xcode-UI-Tests
  geschlossen.

Vor einer Veröffentlichung bleiben persönliche Entscheidungen des
Projekteigentümers zu DLA-/Markenhinweis, Monetarisierungsmodell und
Datenschutz erforderlich. Diese technische Prüfung ist keine
Rechtsberatung, keine Vertragsannahme und keine CCP-Genehmigung.

Zusätzlich ist das aktuelle Xcode-Releaseartefakt noch nicht für öffentliche
macOS-Verteilung vorbereitet: lokale Bundle-ID, fehlende Versionsfelder,
keine Developer-ID-Signatur, kein Hardened Runtime und keine Notarisierung.
Diese Apple-Distributionsgrenze ist als OFF-032 erfasst und getrennt von
CCP-Compliance sowie P38 zu behandeln.

## Betriebsentscheidung PLAN-003 vom 2026-07-26

Der verbindliche Zielbetrieb ist bis auf Weiteres die lokale Eigennutzung
auf dem Rechner des Projekteigentümers. Die technischen Anforderungen an
offizielle CCP-Datenquellen, Drittanbieterkennzeichnung, Datenschutz und
sichere Datenhaltung gelten dabei unverändert.

Eine Veröffentlichung im Mac App Store oder über eine direkte öffentliche
macOS-Distribution ist nicht Teil des lokalen MVP und kein aktuelles
Abnahmegate. OFF-020 und OFF-032 werden ausschließlich im letzten optionalen
Zukunftspaket P48 nach P47 und nur auf ausdrücklichen Auftrag bearbeitet.
REL-001 bleibt als historischer technischer Prüfstand erhalten; daraus folgt
weder eine Rechtsberatung noch eine CCP- oder Apple-Genehmigung.

## Aktueller Marken- und Datenschutzbefund

- Im Repository wurden keine CCP-Logo- oder Image-Export-Dateien gefunden.
- Die App enthält einen eigenen Bereich mit unabhängiger
  Drittanbieterkennzeichnung, Eigentumshinweis und offiziellen Links.
- Für den SDE-Netzwerkzugriff existiert eine zentral validierte
  User-Agent-Konfiguration aus Appname, Version, Zweck und optionalem
  Kontaktwert. Ein realer Kontakt wurde für P07B zur Laufzeit verwendet,
  aber bewusst nicht im Repository persistiert.
- Der vorhandene SSO-Zukunftscode ist vom MVP eingefroren und besitzt eigene
  offene Konfigurations- und Compliancearbeiten in P38/P39.

## Wiederholungsregel

P07C und REL-001 haben die Quellen an ihren Ausführungstagen erneut geprüft.
Jeder spätere Release-, ESI-, Marken- oder Bildauftrag muss die dann
aktuellen Fassungen erneut prüfen. Alte Textkopien gelten nicht als
dauerhafter Rechtsnachweis.
