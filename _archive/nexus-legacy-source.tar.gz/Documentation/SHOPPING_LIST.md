# Einkaufsliste und Beschaffungsworkflow

Stand: 2026-07-26 · P30/P31

## Zweck

P30 übernimmt die durch P26 bereits lager-, schutzbestands-,
reservierungs- und Build-or-Buy-bereinigten Fehlmengen. Gleiche CCP-Type-IDs
werden erneut defensiv zusammengeführt und erscheinen genau einmal.

## Mengen

- **Berechnete Menge:** positive Nettokaufmenge des aktuellen Plans.
- **Zielkaufmenge:** berechnete Menge oder eine ausdrücklich eingegebene
  nichtnegative Abweichung.
- Eine Zielmenge von null unterdrückt nur den wirksamen Listeneintrag.
- Entspricht die Zielmenge wieder der berechneten Menge, wird kein Override
  gespeichert.

Die Liste ist stabil nach Name und Type-ID sortiert. Fachlicher Schlüssel
bleibt ausschließlich die positive CCP-Type-ID. Summen verwenden
überlaufgeprüfte `Int64`-Arithmetik.

## Daten- und Schreibschutz

Eine Vorschau bindet Projekt, Graph, Lager, Schutzbestände, Reservierungen,
Build-or-Buy-Entscheidungen und den aktuellen Override-Stand. Vor dem
Speichern wird der bestätigte P26-Plan erneut berechnet. Ein ungespeicherter
Build-or-Buy-Entwurf, ein geänderter Quellstand oder ein konkurrierender
Override-Schreibvorgang blockiert.

Nicht mehr zum Plan passende gespeicherte Overrides bleiben sichtbar und
werden erst durch einen bestätigten vollständigen Ersatz entfernt. Abbruch
vor dem Commit schreibt nichts; nach erfolgreichem Commit wird kein
mehrdeutiger zusätzlicher Fehlerpfad ausgeführt.

## Persistenz

Schema v19 speichert `ShoppingQuantityOverrideRecord` mit Projekt-ID,
Type-ID, Zielmenge und Zeitstempeln. Pro Projekt/Type-ID ist höchstens ein
Datensatz zulässig. Archivierte Projekte behalten ihre Konfiguration;
Projektduplikate besitzen eine neue ID und starten ohne Overrides.

Die Migration v18→v19 ist additiv. Backupformat 19.0.0 akzeptiert weiterhin
1.0.0 bis 18.0.0.

## Bedienung

Im Produktionsworkspace können Zielmengen bearbeitet, auf den berechneten
Wert zurückgesetzt, neu berechnet, nach Bestätigung gespeichert und als
`Name<Tab>Menge` kopiert werden. Veraltete Overrides und eine veraltete
Vorschau werden sichtbar angezeigt.

## Projektübergreifender Einkauf

P31 führt die wirksamen P30-Zielkaufmengen aller aktuellen, nicht
archivierten Projekte erneut nach Type-ID zusammen. Projektquellen bleiben
sichtbar. Projekte ohne berechenbaren aktuellen Plan werden mit Warnung
ausgelassen, ohne gültige Projekte zu blockieren.

Je Projekt/Type-ID kann eine gekaufte Menge zwischen null und aktueller
Zielmenge zugeordnet werden. Die offene Menge ist:

`max(Zielkaufmenge - angerechnete Kaufmenge, 0)`

Diese Zuordnung ist kein Lagerbestand. Sie verändert weder Bestand,
Sicherheitsbestand noch Reservierungen. Sinkt das Ziel unter einen früher
gespeicherten Fortschritt, wird höchstens das Ziel angerechnet; der
gespeicherte Wert bleibt sichtbar und wird nicht stillschweigend gelöscht.

## Fortschritt und Export

Statusänderungen werden zuerst vollständig als Vorschau berechnet und erst
nach Bestätigung atomar gespeichert. Archivierte, vorübergehend nicht
berechenbare oder nicht mehr benötigte Zuordnungen bleiben geschützt.

Die Klartextliste enthält nur offene Positionen als `Name<Tab>Menge`. Der
UTF-8-CSV-Export enthält je Type-ID:

`type_id,item_name,target_quantity,purchased_quantity,remaining_quantity,project_count`

Der Export ist read-only. P31 führt bewusst keinen CSV-Reimport ein; ein
späterer Import benötigt einen eigenen Preview-before-write-Vertrag.

## Schema v20

`PurchaseProgressRecord` speichert UUID, Projekt-ID, Type-ID, positive
gekaufte Menge und Zeitstempel. Pro Projekt/Type-ID ist höchstens ein
Datensatz zulässig. Null wird durch einen fehlenden Datensatz dargestellt.
Die Migration v19→v20 ist additiv. Backupformat 20.0.0 akzeptiert weiterhin
1.0.0 bis 19.0.0.
