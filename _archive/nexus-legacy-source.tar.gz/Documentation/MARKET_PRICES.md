# Öffentliche ESI-Materialpreise

Stand: 2026-07-29 · P41/P52/P58

## Zweck und Grenze

P41 ergänzt den Produktionsworkspace um optionale Beschaffungspreise aus
öffentlichen CCP-ESI-Verkaufsorders. Abgerufen werden ausschließlich die
Type-IDs der aktuellen Einkaufsliste. Es gibt keine neuen SSO-Scopes, keinen
regionalen Orderbuchspiegel, keine Historien oder Prognosen und keine
automatische Bewertung des Zielerlöses.

Regionen werden über das öffentliche ESI-Universe-Verzeichnis namentlich
angeboten. Jita, Amarr, Dodixie, Rens und Hek stehen als überprüfte
NPC-Trade-Hub-Schnellwahlen bereit. Lokal bereits bekannte Stationen und
Spielerstrukturen werden mit ihrem Namen und ihrer aufgelösten Region
angezeigt. Technische Region- und Location-IDs bleiben interne Schlüssel.
Type-IDs und Itemnamen stammen aus dem aktiven lokalen SDE-Katalog; P41
benötigt dafür keinen zusätzlichen SDE-Datensatz.

Nicht öffentliche, aber für einen verbundenen Charakter bekannte Strukturen
werden sichtbar als privater Markt gekennzeichnet und bleiben derzeit
gesperrt. Private Strukturorders benötigen einen eigenen authentifizierten
Marktabruf samt zusätzlichem Scope, Kontoauswahl und separatem
Vorschauvertrag. Sie werden nicht aus dem öffentlichen Regionalorder-Endpunkt
abgeleitet.

## Preisbildung

Für jede Materialposition werden öffentliche Sell-Orders nach Preis und
Order-ID deterministisch sortiert. Die angeforderte Einkaufsmenge wird über
die günstigsten erfüllbaren Orders verteilt. Der angezeigte Einheitspreis ist
der mengenbezogene Gesamtpreis geteilt durch die Menge und wird auf den
nächsten Hundertstel-ISK aufgerundet, damit Materialkosten nie unterschätzt
werden.

Fehlende Orders und eine nicht vollständig erfüllbare Menge bleiben sichtbar
und erzeugen keinen Preis. Manuelle und CSV-Preise werden nicht im Hintergrund
überschrieben.

## Verbindliche Nutzung in P57 bis P61

P57 selbst lädt keine Preise. Ab P58 gilt für jede prognostische Bewertung
folgende Reihenfolge:

1. öffentliche Live-ESI-Quote am ausgewählten benannten Markt,
2. gültiger Cache exakt derselben Quelle,
3. sichtbar veralteter Offline-/Limit-Cache exakt derselben Quelle,
4. ausdrücklich gewählter manueller oder CSV-Preissatz,
5. `nicht verfügbar`; niemals eine stillschweigende Null.

Jita IV – Moon 4 ist die Standardvorgabe. Der Benutzer kann diese Vorgabe auf
eine andere benannte Region, einen Trade Hub oder eine bekannte öffentlich
abrufbare Station/Struktur ändern. Private Strukturen bleiben gesperrt, bis
ein eigener authentifizierter Marktvertrag existiert.

Jeder weitergegebene Preis enthält mindestens Type-ID, Region, optionale
Location, Buy-/Sell-Rolle, angefragte und erfüllte Menge, Beobachtungs- und
Prüfzeit, Cacheablauf, Quell-/Snapshotidentität, Policy-Version und Warnungen.
Ein Fallback darf nie wie eine frische Livebeobachtung dargestellt werden.

Material- und Betriebsmittelkäufe verwenden weiterhin den mengenbezogenen
Sell-Order-Fill. Ein erwarteter Angebotspreis für das Zielprodukt ist eine
gesondert benannte Sell-Referenz. Eine Sofortverkaufsbewertung benötigt
Buy-Orders und bleibt bis zu deren ausdrücklicher Implementierung
`nicht verfügbar`; ein Sell-Wert darf sie nicht ersetzen.

Realisierte Erlöse und Kosten in P59 stammen ausschließlich aus bestätigten
Wallet-/Journalbelegen oder einer ausdrücklich manuellen Istbuchung. Ein
öffentlicher Marktquote bleibt dort Vergleich oder Prognose.

## Vorschau und Speicherung

Der Ablauf ist immer:

1. Optionalen Ziel-Preissatz, benannte Region, optionalen benannten
   Marktstandort und aktuelle Einkaufsmengen prüfen.
2. Orders beziehungsweise einen gekennzeichneten Cache lesen.
3. Einfügungen, Ersetzungen, unveränderte und nicht verfügbare Positionen
   anzeigen.
4. Erst nach ausdrücklicher Bestätigung alle ausgewählten Änderungen atomar
   speichern.

Ohne Ziel-Preissatz ist die Vorschau vollständig schreibfrei; vorhandene
Preise werden dann nicht als Ersetzungsbasis gelesen und die Übernahme bleibt
gesperrt. Mit Ziel-Preissatz verfällt die Vorschau nach 15 Minuten und ist an
den gelesenen Preisstand gebunden. Abbruch, fehlender Ziel-Preissatz,
veraltete Vorschau oder Persistenzfehler lassen die bisherigen Preise
unverändert.

Schema v21 ergänzt pro ESI-Preis einen
`MarketPriceProvenanceRecord`: Region, optionale Location, angeforderte und
erfüllte Menge, Orderanzahl, Gesamtpreis, Abruf-/Prüfzeit, Cacheablauf und
Quellpfad. Ein späterer manueller oder CSV-Schreibvorgang entfernt diese
ESI-Herkunft atomar.

P58 ergänzt im eingebetteten Ablauf die fehlende sichere Zielhandlung:
Ein neuer ISK-Preissatz kann benannt und angelegt oder ein vorhandener
ausgewählt werden. Erst danach wird eine geprüfte Vorschau bestätigt
übernommen. Der neu angelegte Ziel-Preissatz wird unmittelbar ausgewählt und
das Projektbudget aus genau diesem Stand neu geladen. Ohne Auswahl bleibt der
Vorgang weiterhin schreibfrei. Damit sind OFF-058 und KI-059 technisch
geschlossen.

Für Chargenverkaufsvorschläge verwendet P58 denselben Marktclient und
dieselben benannten Regionen/Standorte. Jita und ein optionaler Alternativmarkt
werden als getrennte mengenbezogene Sell-Quotes mit vollständiger Provenienz
gespeichert. Der manuelle/CSV-Preissatz wird nur nach aktivierter
Fallbackauswahl verwendet. Ein bestätigter `ProductionBatchCostSnapshot`
bleibt auch nach späteren Markt- oder Profiländerungen unverändert.

## HTTP, Cache und Offlinebetrieb

Der Client verwendet ausschließlich `https://esi.evetech.net` und die
öffentliche Route `/markets/{region_id}/orders/` mit `order_type=sell`,
`type_id` und sequenzieller Pagination. Kein Bearer-Token wird gesendet.

ETag, Last-Modified, Expires, `304 Not Modified`, `Retry-After`,
Markt-Rate-Limit und Fehlerlimit werden ausgewertet. Eine Marktseite wird nur
bei gültiger Identität und innerhalb fester Größen-/Seitenlimits atomar in
einem separaten Dateicache gespeichert. Offline-, Limit- oder temporäre
Serverfehler dürfen einen vorhandenen Snapshot verwenden; die UI kennzeichnet
diesen als Fallback und zeigt Abruf- sowie Cachezeit.

## Bedienung

Im Produktionsworkspace öffnet `ESI-Materialpreise` die Vorschau für die
aktuelle Einkaufsliste. Nach dem bestätigten Apply wird die
Wirtschaftlichkeitsansicht aus dem aktualisierten Preissatz neu geladen. Die
Preissatzansicht zeigt Quelle und Herkunft je ESI-Preis.

Das Formular lädt das Regionsverzeichnis und die öffentlichen
Marktstruktur-IDs über ESI. Die fünf Trade Hubs sind direkt auswählbar. Ein
verwendeter Marktstandort in einem Home-System wie UALX-3 oder X-10-J
erscheint, wenn seine Struktur in einem aktuellen persönlichen Snapshot
vorkommt und ihr Name geladen wurde. Ein öffentlicher Markt ist auswählbar;
ein nur privat zugänglicher Markt wird bis zum gesonderten privaten
Marktauftrag deaktiviert dargestellt.

## Optionale spätere PLEX-Anzeige

ISK bleibt die einzige Rechen- und Speicherwährung. Eine spätere Anzeige darf
einen ISK-Betrag optional in PLEX umrechnen:

```text
PLEX-Anzeigewert = ISK-Betrag / gewählter PLEX-Preis
```

Die UI muss unterscheiden, ob der öffentliche PLEX-Verkaufspreis
(`sell`, PLEX mit ISK kaufen) oder PLEX-Kaufpreis (`buy`, PLEX verkaufen)
verwendet wird. Region beziehungsweise Location, Abrufzeit, Frische und
Fallbackstatus müssen sichtbar bleiben. Der aktuelle P41-Dienst verarbeitet
nur Sell-Orders für Materialbeschaffung; die PLEX-Anzeige bleibt daher
OFF-049 und wird nicht aus einem unvollständigen Kurs geraten.

## Nicht enthalten

- automatische Hintergrundüberschreibung,
- Kauf- und Verkaufspreisrollen in demselben Profil,
- automatische Zielerlöse,
- Marktverlauf oder Prognose,
- persönliche Orders, Wallet oder Transaktionen,
- private Strukturmarktorders,
- frei erfundene oder ungeprüfte Home-Hub-Namen.
