# Reservierungskonflikte

Stand: 2026-07-25  
Prompt: P25  
Berechnungsformel: 1  
Persistenzschema: v14 (unverändert)

## Zweck

P25 erkennt nachträglich entstandene Konflikte zwischen aktiven
Projektreservierungen, dem aktuellen P22-/P23-Verfügbarkeitsstand und dem
aktuellen Projektbedarf. Konflikte werden aus den vorhandenen Daten
berechnet; sie werden nicht als eigener, potenziell veraltender Zustand
gespeichert.

## Konfliktarten

| Konflikt | Bedingung | Wirkung |
|---|---|---|
| Bestandsunterdeckung | Summe aller aktiven Restreservierungen einer Type-ID übersteigt die für das betrachtete Projekt nach Sicherheitsbestand verfügbare Menge | konkurrierende Projekte und Fehlmenge werden ausgewiesen |
| Bedarfsüberschreitung | aktive Restreservierung des betrachteten Projekts übersteigt dessen aktuellen aggregierten Bedarf | überschüssige Bindung wird ausgewiesen |
| Nicht mehr benötigt | aktive Bindung des betrachteten Projekts verweist auf kein Material des aktuellen Graphen | vollständige Freigabe wird vorgeschlagen |

Ein abgelaufenes Reservierungsdatum ist weiterhin nur ein Warnhinweis. Die
Bindung bleibt aktiv, bis sie ausdrücklich reduziert, freigegeben oder
verbraucht wird.

## Determinismus und Priorität

Die Auswertung verwendet stabile CCP-Type-IDs und `Int64`-Mengen.
Überläufe werden als Fehler abgelehnt. Beteiligte Reservierungen und
Vorschläge werden deterministisch sortiert:

1. Reservierungspriorität aufsteigend (`1` ist hoch),
2. Projektpriorität aufsteigend,
3. Erstellungszeitpunkt,
4. Projekt-UUID,
5. Reservierungs-UUID.

Die Prioritätsauswertung ist nur ein nachvollziehbarer Vorschlag. Sie
verändert keine Daten und trifft keine Entscheidung für den Benutzer.

## Kontrollierte Auflösung

Die Konfliktansicht bietet pro beteiligter aktiver Reservierung:

- unverändert lassen,
- auf eine kleinere positive Restmenge reduzieren,
- vollständig freigeben.

Erhöhen, Verbrauchen, automatische Kürzung und Änderungen außerhalb des
angezeigten Konfliktumfangs sind in P25 nicht zulässig. Vor dem Schreiben
entsteht eine schreibfreie Vorschau. Die Anwendung verlangt eine
ausdrückliche Bestätigung und akzeptiert die Änderung nur, wenn:

- alle sichtbaren Konflikte durch die vorgeschlagenen Änderungen
  aufgelöst sind,
- Projekt-, Graph-, P22-, P23- und Reservierungszustand seit der Vorschau
  unverändert sind,
- alle betroffenen Reservierungen noch aktiv und versionsgleich sind,
- sämtliche Änderungen atomar gespeichert werden können.

Bei Abbruch, veraltetem Zustand oder Persistenzfehler wird nichts
geschrieben.

## Architektur

```text
ReservationConflictView
  -> ReservationConflictViewModel
    -> ReservationConflictManaging
      -> ReservationConflictService
        -> SafetyStockManaging
        -> ProjectReservationRepository
        -> ProductionProjectRepository
        -> StaticDataCatalog
          -> ReservationConflictCalculator
```

SwiftUI greift nicht direkt auf SwiftData zu. Die bestehende atomare
P24-Repository-Grenze schreibt ausschließlich bestätigte Reduktionen und
Freigaben.

## Bewusste Grenzen

- Die P22-Verfügbarkeitskonfiguration des betrachteten Projekts bildet den
  aktuellen Berechnungskontext. Eine allgemeingültige physische
  Lagerallokation zwischen mehreren Projekten ist fachlich nicht belegt
  und wird nicht erfunden.
- Konflikte werden beim Öffnen beziehungsweise Aktualisieren der Ansicht
  neu berechnet; es gibt keinen stillen Hintergrundschreibvorgang.
- Automatische Optimierung, Slotplanung und projektübergreifende
  Prioritätsentscheidungen bleiben außerhalb des MVP.

## Nachweis

- 21 fokussierte Konflikt-/Reservierungstests,
- 15 neue P25-Tests in Domain, Application und Persistence,
- SwiftPM Debug und Release: jeweils 423 Tests bestanden,
- Xcode Debug und Release: jeweils 423 Tests bestanden,
- isolierter App-Start mit Schema v14 und
  `PRAGMA integrity_check = ok`,
- gesonderter Review gemäß `Documentation/REVIEW_RULES.md`.
