# SDE-Archivdownload, Prüfung und Aktivierung

Stand: 2026-07-23 · P07B

## Status und Grenze

Der technische P07B-Kern ist implementiert und mit synthetischen,
bösartigen und dem aktuellen offiziellen Build `3444265` geprüft. Der
Projekteigentümer bestätigte die aktuelle persönliche DLA-Entscheidung und
stellte eine reale Kontaktangabe ausschließlich für den Laufzeit-User-Agent
bereit. Der Kontakt wurde nicht in Quellcode, Journal, Dokumentation oder
Testartefakten gespeichert.

P07B ist `✅ erledigt`: Nach dem blockweisen Umbau lagen zwei vollständige
Realimporte bei 948–952 MB Peak-RSS statt zuvor rund 2,45 GB. Inhaltshash,
Mengen, Wiederöffnung und Katalogabfragen blieben identisch.

OFF-055 korrigiert am 2026-07-29 ausschließlich die vorgelagerte
Schemaentscheidung: Ziel-Datenbuild, höchster geprüfter CCP-Changelog-Eintrag
und verstandener Parserstand sind getrennte Werte. Ein neuer Datenbuild ist
zulässig, solange der passende gespeicherte Metadatencheck keinen
unverstandenen Schemawechsel enthält.

## Feste offizielle Quelle

Archive werden ausschließlich aus einer positiven, bereits durch P07A
validierten Buildnummer gebildet:

```text
https://developers.eveonline.com/static-data/tranquility/
eve-online-static-data-<build>-jsonl.zip
```

Der Downloader akzeptiert keinen benutzerdefinierten Host und keine
Weiterleitung. Eine produktive Downloaderkonfiguration verlangt eine
Kontaktangabe für den zentralen User-Agent. Sie prüft HTTP-Status,
Inhaltstyp, Content-Length, tatsächliche Dateigröße, Obergrenze und freien
Speicher. URLSession arbeitet in einer ephemeren Sitzung; Wiederholungen sind
begrenzt und betreffen nur vorübergehende Transportfehler beziehungsweise
408, 429 und ausgewählte 5xx-Antworten.

## Private Arbeitsgrenze

Jeder Vorgang besitzt eine UUID und ein privates Arbeitsverzeichnis mit
Dateirechten `0700`; das Archiv erhält `0600`. Abbruch oder Fehler lösen eine
kontrollierte Bereinigung aus. Weder Arbeitsverzeichnis noch vollständige
lokale Pfade werden in das Updateprotokoll geschrieben.

## ZIP-Prüfung

`SecureSDEArchivePreparer` liest nur das Ende und das Central Directory des
Archivs, nicht den gesamten ZIP-Inhalt in den Arbeitsspeicher. Vor der
Extraktion werden geprüft:

- genau ein nicht mehrteiliges klassisches ZIP ohne ZIP64-Sentinelwerte,
- begrenzte Eintragszahl, Einzel- und Gesamtausgabegröße,
- begrenztes Kompressionsverhältnis,
- keine Verschlüsselung,
- nur reguläre JSONL-Dateien auf Wurzelebene,
- UTF-8- und NFC-eindeutige relative Namen,
- keine absoluten, leeren, `.`-, `..`-, Backslash- oder Laufwerkspfade,
- keine normalisiert doppelten Zielnamen,
- keine Symlinks, Geräte oder sonstigen Unix-Sonderobjekte,
- übereinstimmende Namen, Flags, Methode und Größen in lokalem Header und
  Central Directory,
- Vorhandensein von `categories.jsonl`, `groups.jsonl`, `types.jsonl` und
  `blueprints.jsonl`.

Erst nach grüner Vorprüfung ruft die injizierbare Systemgrenze den festen
macOS-Befehl `/usr/bin/ditto -x -k` mit getrennten Argumenten auf. Es gibt
keine Shell und keine benutzerdefinierte ausführbare Datei. Danach werden
alle extrahierten Einträge erneut auf realen Pfad, Dateityp, Namen,
Vollständigkeit und Gesamtgröße geprüft. Die Systemgrenze ist durch einen
echten Extraktionstest und ansonsten durch injizierbare Stubs abgedeckt.

## Isolierter Import und Aktivierung

```text
P07A Schema-Gate + Eigentümerbestätigung
  -> offizieller Download
  -> ZIP-Vorprüfung
  -> isolierte Extraktion und Nachprüfung
  -> P07 JSONL-Streamingvalidierung
  -> versioniertes .nensde-Paket
  -> P08 zeilenweises Mapping und Qualitätsprüfung in begrenzten Batches
  -> separater temporärer SwiftData-Stagingstore mit Batch-Saves
  -> Wiederöffnung und Mengenabgleich
  -> SQLite-Sicherheitsbackup des aktiven Stores
  -> blockweise Promotion und abschließende atomare Aktivierung
  -> alte Version bleibt als Rollback erhalten
```

Der aktive Store wird erst nach erfolgreicher Wiederöffnung des isolierten
Stagingstores berührt. Mapping, Staging und Promotion arbeiten mit begrenzten
Batches; Gesamtmengen und Inhaltshash werden unabhängig geprüft. Erst danach
werden `StaticDataVersion` und Aktivmarker gemeinsam gespeichert. Bei Fehler
oder Abbruch werden Kandidatenzeilen über den Inhaltshash entfernt, während
eine bereits abgeschlossene Version mit demselben Hash geschützt bleibt. Die
vorherige Version bleibt als Rollback erhalten.

## Crash-Recovery und Updateprotokoll

`SDEInstallationService` protokolliert vor jeder Phasengrenze einen
strukturierten JSON-Stand. Enthalten sind nur:

- Vorgangs-ID, Buildnummern und offizielle URL,
- HTTP-/Cacheentscheidung und Größen,
- Archivbefunde und Datensatzanzahlen,
- Parser- und Importschemaversion,
- Backup-, Cleanup- und Rollbackergebnis,
- Zeitstempel, Phase und sicherer Fehlercode.

Nichtterminale Vorgänge werden beim nächsten Start erkannt. Ist der Zielbuild
bereits aktiv, wird der Vorgang als wiederhergestellt abgeschlossen. Ist ein
anderer Stand aktiv, bleibt beziehungsweise wird der vorherige Build
reaktiviert. Temporäre Download-, Extraktions- und Staginggrenzen werden
bereinigt. Ein automatisierter Test simuliert den Wiederanlauf nach jeder
persistenten Phase von `started` bis `promoting`. P36 ergänzt den realen
Prozessnachweis: fünf getrennte Installationsprozesse wurden nach
persistiertem `downloading`, `validatingSource`, `validatingStagingStore`,
`creatingSafetyBackup` beziehungsweise `promoting` von außen durch
`SIGKILL` beendet. Eine neue Composition auf demselben isolierten Store
erhielt jeweils Altbuild und Benutzerfixtures, terminalisierte das Journal
genau einmal und bestätigte Rollback, Aufbewahrung und Cleanup. P07C
verdrahtet die kontaktfreie Recovery vor dem ersten
Metadatencheck produktiv und stellt Verlauf sowie bereinigten Diagnoseexport
sichtbar bereit.

## Realabnahme Build 3444265

Der opt-in Runner `NewEdenNexusSDEAcceptance` verlangt Owner-Gate, positive
Buildnummer, geprüften Schemastand, den höchsten aktuellen
`afterBuildNumber`-Wert über `NEN_SDE_SCHEMA_CHANGE_AFTER_BUILD` und Kontakt
zur Laufzeit. Er verwendet ausschließlich temporäre Stores.

Zwei Low-Memory-Läufe am 2026-07-23 ergaben identisch:

- Inhaltshash
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`,
- 48 Kategorien, 1.609 Gruppen, 52.821 Typen und 5.082 Blueprints,
- 19.137 Aktivitäten, 36.499 Materialien und 6.329 Produkte,
- 21 explizit erhaltene nicht aufgelöste Typreferenzen,
- erfolgreiches Sicherheitsbackup, Terminaljournal und Cleanup,
- erfolgreiche Wiederöffnung sowie Abfrage von Rifter und Blueprint 691,
- Laufzeiten 33,391 s beziehungsweise 33,202 s,
- Peak-RSS 952.057.856 beziehungsweise 948.125.696 Bytes,
- rund 61 % weniger maximaler RSS als die vorherige Snapshot-Baseline,
- keine verbleibenden temporären Abnahmeartefakte.

## Verbleibende Folgearbeiten

P36 hat den tatsächlichen Prozessabbruch-/App-Neustart-Drill abgeschlossen;
P07C hat Bedien-, Automations- und Rechtslogik umgesetzt. `CachedSDEArchiveDownloader`
ermöglicht einen explizit aktivierten Vorabdownload und prüft vor
Wiederverwendung Dateigröße sowie SHA-256; nach erfolgreicher Installation
wird der Cache entfernt. Alte Katalogversionen werden nur nach exakter
Vorschau und Bestätigung gelöscht, wobei aktive und letzte funktionierende
Version geschützt bleiben.

Der manuelle P07C-Fenster-/Accessibility-Smoke-Test bleibt `OFF-025` für
P09B. Die mechanische Aufteilung großer Quelldateien bleibt als
Wartungsarbeit P34 zugeordnet und blockiert P07B nicht.
