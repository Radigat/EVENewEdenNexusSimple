# Architekturänderungen

## 2026-07-29 – P59: Chargengebundene Istverkäufe in Schema v28

- `ProductionBatchSaleAllocationSnapshot` trennt bestätigte Verkäufe und
  Verkaufsgebühren von Marktquotes, offenen Orders und veränderlichen Plänen.
- Die Application-Schicht unterteilt nur bestätigte P42-Projektkapazität,
  erzeugt vor jedem Schreiben eine Vorschau und prüft Charge, Walletrevision
  sowie unveränderliche P58-Kostenbasis erneut.
- Die persistente Grenze sperrt Überverkauf, gemischte Kostenbasen und
  projekt-/chargenübergreifende Quellübernutzung atomar.
- Schema v28 und Backupformat `28.0.0` sind additiv; keine Historie wird
  erfunden.
- Entscheidung:
  [ADR-0062](Architecture/ADRs/ADR-0062_Chargengebundene-Verkaufszuordnung-und-Realgewinn.md).

## 2026-07-29 – P58: Unveränderliche Chargenkosten in Schema v27

- `ProductionBatchCostSnapshot` trennt bestätigte Kosten- und Quotegrundlagen
  von veränderlichen Projekten, Budgets und Preissätzen.
- Typisierte Kostenzeilen erhalten Quelle, Zeitpunkt, Zuordnungsart und
  Warnungen; unbekannte Werte bleiben unbekannt und sperren Ableitungen.
- `PriceQuoteBinding` bindet Jita beziehungsweise einen alternativen benannten
  Markt an Menge, Sell-Rolle, Zeitstand, Cache und Policy.
- Schema v27 ergänzt additive Kostensnapshots ohne erfundene Historie.
- ADR-0061 dokumentiert Entscheidung und Rollbackgrenze.

## 2026-07-29 – P57: Unveränderliches Produktionsbuch in Schema v26

- `ProductionBatchSnapshot` trennt tatsächliche Chargen von veränderbaren
  Projektplänen und bindet Projekt-, Graph-, Regel- und SDE-Versionen.
- Der Application-Service erzwingt Vorschau, Bestätigung sowie erneute
  Stale-Prüfung von Projekt, Graph, Katalog und optionalem ESI-Job.
- Schema v26 ergänzt Chargen und transaktionale Jahreszähler, ohne aus
  Altprojekten oder ESI-Jobs historische Daten zu erfinden.
- Die native Ansicht zeigt Namen vorrangig, hält technische IDs in Details
  und filtert nach Jahr, Produkt, Projekt, Charakter, Ort und Status.
- Entscheidung:
  [ADR-0060](Architecture/ADRs/ADR-0060_Produktionsbuch-und-Chargenrechnung.md).

## 2026-07-29 – PLAN-006: Produktionsbuch statt Excel-Zeile

- Plan, Produktionscharge, Kostenbeleg und Verkauf werden als getrennte,
  nachvollziehbare Zustände spezifiziert.
- Chargen binden Plan-/Graph- und Quellenstände; spätere Neuberechnungen
  überschreiben keine Historie.
- Walletquellkapazität bleibt projektweit eindeutig und darf auf Chargen nur
  unterverteilt, nicht doppelt verbraucht werden.
- Metenox wird als eigener Rechner mit versionierten Regeln geplant.
- Der Vorschlag ist in
  [ADR-0060](Architecture/ADRs/ADR-0060_Produktionsbuch-und-Chargenrechnung.md)
  dokumentiert; eine Implementierungsentscheidung erfolgt mit P57.

## 2026-07-29 – OFF-055: Konsistentes SDE-Schema-Gate

- `SDEInstallationRequest` trennt Zielbuild, höchsten geprüften
  Changelog-Eintrag und verstandenen Parserstand.
- `SDEAppComposition` verlangt vor Installation einen gespeicherten
  Metadatenstand, dessen offizieller Build exakt dem Zielbuild entspricht.
- Der Installer lehnt nur fehlende oder unverstandene Schemawechsel ab; reine
  neue Datenbuilds bleiben installierbar.
- Staging-, Backup-, atomare Aktivierungs- und Rollbackgrenzen sowie
  persistente Benutzerdaten bleiben unverändert.
- Die Umsetzung richtet den Code an der bereits akzeptierten Entscheidung
  [ADR-0010](Architecture/ADRs/ADR-0010_SDE-Metadaten-HTTP-Cache-und-Schema-Gate.md)
  aus; ein neues ADR ist nicht erforderlich.

## 2026-07-23 – P00: Scope-Baseline, keine Codeänderung

### Entscheidung

Der aktuelle Entwicklungsfokus wird vom umfassenden Projektbuch auf Stufe A – Produktionsplaner MVP reduziert. Das Projektbuch bleibt Zielbild; der reduzierte MVP ist die operative Priorität.

### Auswirkungen

- SSO, ESI, Live-Daten, Wallet, PI, Corporation, Cloud und Optimierung werden als spätere Stufen dokumentiert.
- Vorhandener SSO-/Keychain-/Charaktercode bleibt unangetastet, zählt aber nicht zum MVP-Fortschritt.
- Der Produktionskern soll künftig deterministisch, offline und getrennt von Live-Adaptern aufgebaut werden.
- P00 verändert keinen App-Quellcode und keine Datenmodelle.

### Noch nicht entschiedene Architekturfragen

- Swift-only-Fachkern oder beibehaltene Python-Prozessgrenze,
- konkrete Modul-/Package-Aufteilung,
- SwiftData-Schemaversionierung und Migrationsstrategie,
- SDE-Importformat und Aktualisierungsstrategie,
- Backupformat und Wiederherstellungsprüfung.

Diese Punkte werden nicht durch P00 vorweggenommen; P02, P03, P06 und P07 müssen sie mit Nachweisen entscheiden.

## 2026-07-23 – P02: SwiftPM-Schichten und native Berechnungsruntime

### Entscheidung

Der bisherige Ein-Target-Stand wird inkrementell in `NewEdenNexusDomain`, `NewEdenNexusApplication`, `NewEdenNexusInfrastructure` und den ausführbaren Übergangstarget `NewEdenNexus` getrennt. Die Python-Prozessgrenze für die vorhandene Materialaggregation wird durch eine native Swift-Implementierung ersetzt.

### Nachweise

- [Architekturbeschreibung](ARCHITECTURE.md)
- [ADR-0001: Modul- und Schichtenarchitektur](Architecture/ADRs/ADR-0001_Modul-und-Schichtenarchitektur.md)
- [ADR-0002: Berechnungsruntime](Architecture/ADRs/ADR-0002_Berechnungsruntime-Python-oder-Swift.md)
- SwiftPM-Targetgraph in `Package.swift`
- Importgrenzen-, Paritäts- und Regressionstests

### Auswirkungen

- neuer Fachcode kann ohne SwiftUI, SwiftData, AppKit, Network oder Security gebaut und getestet werden,
- Application-Use-Cases kennen keine konkreten Adapter,
- Python-Runtime, Prozessadapter, Skript und ungenutzte Einstellung entfallen,
- SwiftData-Modelle und bestehende View-Zugriffe bleiben unverändert im App-Target,
- P03 übernimmt Schema, Migrationen und die kontrollierte Persistenzgrenze.

### Nicht geändert

- kein neues fachliches MVP-Feature,
- kein SwiftData-Schema und keine Benutzerdaten,
- keine SSO-/ESI-Funktion,
- keine Navigation oder fachliche UI.

## 2026-07-23 – P03: Schema v1 und Persistence-Target

### Entscheidung

Die vorhandenen SwiftData-Modelle werden in `NewEdenNexusPersistence` verschoben. Ein feldgenaues Legacy-Schema 0.9.0, ein additives Schema v1 und ein Lightweight-Migrationsplan werden verbindlich. ProductionProject erhält ein separates Domainmodell und einen Application-Repository-Port.

### Nachweise

- [Datenmodell](DATA_MODEL.md)
- [ADR-0003](Architecture/ADRs/ADR-0003_SwiftData-Schema-v1-und-Persistenzgrenze.md)
- Legacy-Strukturvergleich,
- dateibasierter Migrationstest mit zweiter Öffnung,
- In-Memory- und dateibasierte Leerstore-Tests,
- Repository- und Mappingtests.

### Datenwirkung

- `CharacterRecord.recordVersion = 1`,
- `ProductionProject.recordVersion = 1`,
- keine entfernten oder umbenannten Legacy-Felder,
- keine gelöschten oder fachlich veränderten Datensätze.

### Auswirkungen

- Persistence ist ein eigener SwiftPM-Target,
- Domain und Application bleiben SwiftData-frei,
- App verwendet eine zentrale versionierte `ModelContainer`-Factory,
- direkte SwiftData-Zugriffe in vorhandenen Views bleiben bis zu ihren Fachprompts bestehen,
- App-Startfehler bleiben bis P04 als `fatalError` sichtbar und erzeugen keinen leeren Ersatzstore.

## 2026-07-23 – P04: Zentrale Fehler- und Diagnosegrenze

### Entscheidung

Application definiert die UI-unabhängige Fehlertaxonomie, strukturierte Diagnoseereignisse, Redaktionswerte und den Logger-Port. Infrastructure implementiert den Port mit Apples Unified Logging. `NexusAppRuntime` setzt Containerfactory und Logger am App-Rand zusammen und steuert Start- sowie Laufzeitfehler.

### Nachweise

- [Fehlerbehandlung und Logging](ERROR_HANDLING_AND_LOGGING.md)
- [ADR-0004](Architecture/ADRs/ADR-0004_Zentrale-Fehler-und-Diagnosegrenze.md)
- Mapping-, Secret-Sentinel-, Redaction- und Runtime-Retry-Tests,
- statischer Regressionstest gegen `fatalError` und verworfene SwiftData-Speicherfehler.

### Datenwirkung

- keine Schemaversion oder Migration geändert,
- kein Store wird gelöscht oder ersetzt,
- fehlgeschlagene SwiftData-Schreibvorgänge rollen den `ModelContext` zurück,
- Keychain-Fehler werden weitergegeben statt ignoriert.

### Auswirkungen

- Datenbankstartfehler werden als sichere Retry-Ansicht dargestellt,
- aktuelle Laufzeitfehler laufen über einen zentralen Alert,
- Logs enthalten feste Codes und redigierte Metadaten statt Rohfehler,
- direkte SwiftData-Viewzugriffe bleiben bis zu den Fachprompts bestehen,
- vollständige Lokalisierung, Diagnoseexport und SSO-Cross-Store-Kompensation bleiben Folgearbeiten.

## 2026-07-23 – P05: TestSupport-Target und versionierte Referenzdaten

### Entscheidung

Gemeinsame Testhelfer und Referenzressourcen liegen in `NewEdenNexusTestSupport`. Der Target ist kein Produkt und wird ausschließlich von Testtargets verwendet. Das erste Referenzpaket ist synthetisch, versioniert und gegen Schema v1 geprüft.

### Nachweise

- [Teststrategie](TEST_STRATEGY.md)
- [ADR-0005](Architecture/ADRs/ADR-0005_Testfundament-und-versionierte-Referenzdaten.md)
- `swift package describe`
- Debug-/Release-Build und jeweils 40 Tests
- Coverage-Baseline sowie Loader-, Builder-, Store- und Referenztests

### Datenwirkung

- keine produktive Schemaversion oder Migration geändert,
- keine produktiven Storepfade verwendet,
- keine echten EVE-, Account-, ESI- oder Tokendaten gespeichert,
- temporäre Teststores werden explizit entfernt.

### Auswirkungen

- Fachprompts können versionierte Sollwerte ergänzen, ohne Testlogik zu duplizieren,
- Persistenztests teilen einen isolierten temporären Store-Helfer,
- ein providerneutraler Prüfskript-Einstieg baut und testet Debug sowie Release,
- echte SDE-/Produktionsreferenzen bleiben P07 bis P19 vorbehalten.

## 2026-07-23 – P06: Versionierte Backup- und Restore-Grenze

### Entscheidung

Application erhält den adapterfreien Port `LocalBackupManaging` mit Manifest-, Vorschau-, Bestätigungs- und Ergebnistypen. Persistence implementiert ihn über die SQLite-Online-Backup-API und ein versioniertes `.nenbackup`-Verzeichnispaket.

### Nachweise

- [Backup und Wiederherstellung](BACKUP_AND_RESTORE.md)
- [ADR-0006](Architecture/ADRs/ADR-0006_Versioniertes-lokales-Backupformat.md)
- sieben temporäre SwiftData-Integrationstests,
- Debug-/Release-Build und vollständige Regressionstests.

### Datenwirkung

- keine neue SwiftData-Entität,
- keine Änderung an Schema v1 oder dem Migrationsplan,
- keine produktive Datenbank als Testquelle,
- vorhandene Zielstores werden nur nach Vorschau, Bestätigung, Closed-Store-Erklärung und verifiziertem Sicherheitsbackup ersetzt,
- Keychain-Tokens bleiben ausgeschlossen.

### Auswirkungen

- Backups eines geöffneten Quellstores sind konsistent,
- Pakete werden erst nach Integritätsprüfung atomar veröffentlicht,
- manipulierte oder inkompatible Pakete werden abgelehnt,
- Wiederherstellungen erzeugen vor dem Überschreiben ein restorable `beforeRestore`-Backup,
- fertige UI, automatische Vor-Migrations-Auslösung und Recovery-Drill bleiben P36 vorbehalten.

## 2026-07-23 – P07: Validierte JSONL-SDE-Staginggrenze

### Entscheidung

Application definiert den UI- und adapterfreien `SDEImporting`-Port mit Vorschau, Snapshot, Fortschritt, Manifest und strukturierten Fehlern. Infrastructure implementiert die blockweise JSONL-Dateiprüfung, SHA-256 und atomare Veröffentlichung eines `.nensde`-Pakets.

### Nachweise

- [SDE-Import und Staging](SDE_IMPORT.md)
- [ADR-0007](Architecture/ADRs/ADR-0007_JSONL-SDE-Stagingpaket.md)
- synthetische versionierte JSONL-Fixtures,
- Erfolgs-, Determinismus-, Validierungs-, Manipulations- und Abbruchtests,
- Debug-/Release-Build und vollständige Regressionstests.

### Datenwirkung

- keine SwiftData-Entität,
- keine Änderung an Schema v1 oder Migrationsplan,
- kein produktiver Storezugriff,
- keine echten CCP-SDE-Inhalte im Repository,
- P07-Pakete sind technische Stagingstände und noch keine aktiven Stammdaten.

### Auswirkungen

- die vier Pflichtdatensätze können speicherschonend formal geprüft werden,
- Vorschau und Staging sind über feste Dateihashes und einen Gesamthash gebunden,
- veränderte oder ungültige Quellen werden ohne finales Paket abgelehnt,
- Application bleibt CryptoKit- und dateiadapterfrei,
- fachliches Mapping, Referenzintegrität, Aktivierung und Katalog bleiben P08 bis P10 vorbehalten.

## 2026-07-23 – P08: Versionierter statischer Stammdatenkatalog

### Entscheidung

Application definiert validierte statische Snapshots sowie Mapper- und
Speicherports. Infrastructure mappt das erneut vollständig verifizierte
`.nensde`-Paket. Persistence ergänzt `NexusSchemaV2` 2.0.0 und aktiviert neue
SDE-Stände in einem Save unter ihrem Inhalts-SHA.

### Nachweise

- [Datenmodell](DATA_MODEL.md)
- [SDE-Import](SDE_IMPORT.md)
- [ADR-0008](Architecture/ADRs/ADR-0008_Versionierter-SDE-Stammdatenkatalog.md)
- Schema-v1-zu-v2-Migration und Legacy-Gesamtpfad,
- synthetische Mapping-, Referenz-, Aktivierungs- und Backupregressionstests,
- offizieller Build 3424810 bis zur Wiederöffnung des SwiftData-Stores,
- Debug-/Release-Build und vollständige Regressionstests.

### Datenwirkung

- acht neue SwiftData-Entitäten,
- additive Migration 1.0.0 → 2.0.0,
- bestehende Charakter- und Projektdaten bleiben feldgleich,
- alte statische Versionen bleiben inaktiv erhalten,
- 21 im offiziellen Build nicht auflösbare Typreferenzen werden explizit
  markiert und gezählt,
- keine offiziellen SDE-Dateien werden eingecheckt,
- Backups verwenden 2.0.0 und akzeptieren 1.0.0 als Vorgänger.

### Auswirkungen

- P09/P10 erhalten eine reproduzierbare lokale Datenbasis,
- unvollständige Imports werden nicht aktiv,
- gleiche Builds mit abweichendem Inhalt werden abgelehnt,
- nicht aufgelöste offizielle Referenzen werden nicht durch erfundene Daten
  verdeckt,
- Namenssuche, Rezeptresolver, Rotation und automatische Vor-Migrations-
  Sicherung bleiben Folgearbeiten.

## 2026-07-23 – P09: Deterministischer Item- und Blueprintkatalog

### Entscheidung

Application definiert einen UI- und SwiftData-freien Katalogport mit
eigenständigen Use-Cases. Persistence implementiert aktive Versionsbindung,
begrenzte Lookups und normalisierte Suche als `@ModelActor`. Schema v3 hält
den kanonischen `searchName` persistent.

### Nachweise

- [Item- und Blueprintkatalog](ITEM_BLUEPRINT_CATALOG.md)
- [ADR-0009](Architecture/ADRs/ADR-0009_Deterministischer-Item-und-Blueprintkatalog.md)
- Application- und Persistence-Katalogtests,
- v2→v3-Backfill- und Backupregressionstests,
- 50.000-Item-Messnachweis,
- offizieller Build 3424810 bis Wiederöffnung und Katalogabfrage,
- Debug-/Release-Build und jeweils 100 Tests.

### Datenwirkung

- `NexusSchemaV3` 3.0.0 ergänzt `ItemType.searchName`,
- v2→v3 berechnet den Wert für vorhandene Itemtypen,
- bestehende Charakter-, Projekt- und SDE-Felder bleiben erhalten,
- Backups verwenden 3.0.0 und akzeptieren 1.0.0/2.0.0,
- Katalogzugriffe sind read-only,
- kein produktiver Benutzerstore wurde geöffnet.

### Auswirkungen

- P10 und P12 erhalten eine testbare Kataloggrenze ohne direkten
  SwiftData-Zugriff,
- Suchergebnisse sind deterministisch, versioniert und begrenzt,
- nicht aufgelöste SDE-Referenzen bleiben sichtbar,
- Rezeptpriorisierung, UI-Auswahl und Produktionsgraph bleiben Folgearbeiten,
- ein nativer nicht-eindeutiger SwiftData-Index wird unter macOS 14 nicht
  vorausgesetzt; P34 bewertet ihn nur bei gemessenem Bedarf neu.

## 2026-07-23 – AUD-SDE-001: Geplante Härtung der CCP-SDE-Integration

### Einordnung

Der Audit ändert keine Produktarchitektur und trifft noch keine
Implementierungsentscheidung. Er gleicht den vorhandenen Offlinepfad P07–P09
mit dem vollständigen CCP-SDE-Gesamtprompt und den am Prüftag aktuellen
offiziellen Quellen ab.

### Festgestellter Architekturstand

- P07–P09 decken lokalen JSONL-Stream, formale und fachliche Validierung,
  versionierte Stammdaten, atomare Aktivierung, Rückfallstand und
  Katalogzugriff ab.
- Eine SDE-Netzwerkschicht, HTTP-Validatoren, ZIP-Sicherheitsgrenze,
  crashfester isolierter Importstore, Updateautomation, Updatehistorie und
  Benutzeroberfläche fehlen.
- Zusätzliche SDE-Datensätze werden nicht pauschal importiert, sondern nur bei
  einem belegten Fachbedarf ihres Zielprompts.

### Vorgeschlagene, noch umzusetzende Schichten

1. P07A ergänzt offizielle Metadatenabfrage, Cache-/Retryregeln,
   Schema-Changelog-Gate und zentrale Compliancekonfiguration.
2. P07B ergänzt offiziellen Archivdownload, sichere Extraktion, isolierte
   Stagingpersistenz, Promotion, Rotation und Crash-Recovery.
3. P07C ergänzt Status-/Einstellungsoberfläche, gedrosselte Automation,
   Protokoll-/Diagnosezugriff und rechtliche Hinweise.

Die konkrete Architektur wird erst in den jeweiligen Arbeitspaketen mit ADR,
Code, Migrationen und Tests verbindlich. P36 übernimmt den End-to-End-
Recovery-Drill; P37 die Release- und Eigentümer-Sign-offs.

## 2026-07-23 – P07A: SDE-Metadaten, HTTP-Cache und Schema-Gate

### Entscheidung

Application orchestriert die SDE-Aktualitätsprüfung über injizierbare Ports.
Infrastructure kapselt die zwei festen offiziellen Metadatenressourcen,
URLSession, Parser, Validatoren und begrenzte Retries. Persistence ergänzt
einen einzelnen Prüfzustand in Schema v4.

### Nachweise

- [SDE-Aktualitätsprüfung](SDE_UPDATE_CHECK.md)
- [ADR-0010](Architecture/ADRs/ADR-0010_SDE-Metadaten-HTTP-Cache-und-Schema-Gate.md)
- 30 neue Service-, HTTP-/Parser- und Persistenztests,
- v3→v4-Migration mit bestehendem Projekt und aktivem Katalog,
- Backupkompatibilität 1.0.0 bis 4.0.0,
- 130 Tests in Debug und Release.

### Datenwirkung

- neue Entität `SDEUpdateCheckRecord`,
- additive Migration 3.0.0 → 4.0.0,
- bestehende Benutzer- und SDE-Katalogdaten bleiben unverändert,
- persistiert werden nur Metadaten, Cachevalidatoren, Zeiten, Parserstand und
  sichere Status-/Fehlercodes,
- kein produktiver Benutzerstore wurde geöffnet.

### Auswirkungen

- der technische Kern kann neue Builds und Schemaänderungen erkennen,
- Servercache und 24-Stunden-Policy begrenzen Anfragen,
- Offline- und Fehlerzustände deaktivieren keinen aktiven Katalog,
- P07B ergänzt Download/Archiv/Aktivierung,
- P07C ergänzt Startverdrahtung, UI, Verlauf und rechtliche Hinweise.

## 2026-07-23 – P07B: Sicherer SDE-Archivpfad und Promotion

### Entscheidung

Application erhält eine phasenbasierte, vollständig injizierbare
`SDEInstallationService`-Orchestrierung. Infrastructure kapselt den festen
offiziellen Archivdownload, einen eigenen read-only ZIP-Metadatenprüfer, die
kontrollierte `/usr/bin/ditto`-Grenze und ein JSON-Phasenjournal. Persistence
ergänzt isolierte Staging-Wiederöffnung, SDE-Voraktivierungsbackup und
Rollback per erhaltener Buildversion.

### Nachweise

- [SDE-Archivinstallation](SDE_ARCHIVE_INSTALLATION.md)
- [ADR-0011](Architecture/ADRs/ADR-0011_Sicherer-SDE-Archivpfad-und-Promotion.md)
- 13 fokussierte Download-/ZIP-/Journal-/Orchestrierungstests,
- 6 Katalogpersistenztests einschließlich Staging-Wiederöffnung und Rollback,
- Debug und Release jeweils 145 Tests, 0 Fehler.

### Datenwirkung

- keine neue SwiftData-Schemaversion,
- neuer Backupgrund `beforeSDEUpdate`,
- neue Katalogversionen bleiben neben der alten Version gespeichert,
- Aktivmarkerwechsel und neue Datensätze bleiben in einem Save,
- Updatejournal ist eine private, pfadbereinigte JSON-Datei außerhalb des
  aktiven Stores,
- kein produktiver Benutzerstore und kein aktuelles CCP-Archiv wurden
  geöffnet.

### Auswirkungen und Grenze

- fehlerhafte Downloads, Archive oder Stagingstände berühren den aktiven
  Katalog nicht,
- ein vorheriger Build kann explizit reaktiviert werden,
- nichtterminale Vorgänge können beim nächsten Start erkannt und bereinigt
  werden,
- das finale Mapping materialisiert weiterhin einen vollständigen Snapshot,
- Eigentümerfreigabe, aktueller Real-SDE-Lauf und vollständiger
  Prozessabbruch-Drill fehlen; P07B bleibt daher teilweise/blockiert.

## 2026-07-23 – P07B: Opt-in Real-SDE-Abnahmerunner

### Entscheidung

Ein getrenntes SwiftPM-Executable `NewEdenNexusSDEAcceptance` verdrahtet die
vorhandenen Application-, Infrastructure- und Persistence-Ports
ausschließlich für eine ausdrücklich autorisierte, isolierte Realabnahme. Es
ist nicht in den App-Start eingebunden und verlangt Owner-Gate, Build,
geprüften Schemastand und Kontakt zur Laufzeit.

### Nachweise

- aktueller offizieller Build 3444265 zweimal vollständig verarbeitet,
- identischer Inhaltshash und identische Datensatzmengen,
- Sicherheitsbackup, Terminaljournal, Cleanup und Wiederöffnung erfolgreich,
- Rifter-/Blueprintabfrage erfolgreich,
- Wiederanlauf an allen persistenten Phasengrenzen automatisiert geprüft,
- Debug und Release jeweils 146 Tests, 0 Fehler.

### Datenwirkung

- kein neues SwiftData-Schema,
- kein produktiver Benutzerstore geöffnet,
- keine Kontakt- oder Accountangabe persistiert,
- erfolgreiche Abnahmeartefakte werden vollständig entfernt.

### Grenze

Der Realpfad erreichte reproduzierbar rund 2,45 GB Peak-RSS. Der Runner
liefert damit den belastbaren Ausgangswert, ersetzt aber nicht den weiterhin
notwendigen blockweisen Mapping-/Persistenzumbau.

## 2026-07-23 – CFG-001: Zentrale öffentliche EVE-Client-Konfiguration

### Entscheidung

Die öffentliche EVE-Client-ID und die lokale Callback-URL werden einmalig in
`EVEPublicConfiguration` definiert. Beim App-Start werden nur ein leerer Wert
oder der frühere Projektstandard auf die aktuelle Konfiguration migriert.
Eine vom Benutzer abweichend eingetragene Client-ID wird nicht überschrieben.

### Auswirkungen

- keine SwiftData- oder Keychain-Änderung,
- keine neue SSO-/ESI-Funktion und keine Scope-Erweiterung,
- kein Client-Secret im Repository,
- zwei Regressionstests für Defaults, gezielte Migration und Bestandsschutz,
- vollständiger Debug-/Release-Nachweis mit jeweils 148 Tests.

## 2026-07-23 – P07B: Blockweiser SDE-Katalogimport

### Entscheidung

Der P07B-Installationsdienst verlangt für reale Installationen nun
durchgängig Streamingports. `JSONLinesSDECatalogMapper` liest die vier
Pflichtdateien zeilenweise, validiert Referenzen und liefert begrenzte
`StaticDataCatalogBatch`-Pakete. Staging und Promotion speichern jedes Paket
in einem frischen SwiftData-Kontext. Die Katalogversion und ihr Aktivmarker
werden erst nach abschließendem Mengenabgleich erzeugt.

Ein Kandidaten-Inhaltshash identifiziert Zeilen eines abgebrochenen Imports.
Recovery darf diese Orphans nur entfernen, wenn keine abgeschlossene
Katalogversion mit demselben Hash existiert. Der alte aktive Build bleibt
während Mapping, Staging und Promotion unverändert.

### Nachweise

- Debug und Release jeweils 153 Tests, 0 Fehler,
- Streaming-, Batchgrenzen-, Abbruch-, Orphan- und Bestandsschutztests,
- zwei vollständige Realimporte des offiziellen Builds 3444265,
- identischer Inhaltshash und identische Datensatzmengen,
- maximaler RSS 952.057.856 und 948.125.696 Bytes statt zuvor rund 2,45 GB,
- Wiederöffnung, Rifter-/Blueprintabfrage, Backup und Cleanup erfolgreich.

### Datenwirkung und Folgen

- keine neue SwiftData-Schemaversion,
- keine produktiven Benutzerstores berührt,
- vorhandene Charaktere und Produktionsprojekte bleiben erhalten,
- Parser- und Importschemaversion für den Streamingpfad auf 2 erhöht,
- P07B ist abgenommen; Prozess-Kill-Drill bleibt P36, UI/Automation P07C und
  mechanische Dateiaufteilung P34.

## 2026-07-23 – P07C: Produktive SDE-App-Composition

### Entscheidung

Die konkrete P07A-/P07B-Verdrahtung liegt nun in `SDEAppComposition`.
`SDEManagementViewModel` erhält ausschließlich injizierbare Operationen und
importiert weder SwiftData noch konkrete Netzwerk- oder Dateiadapter.
`NexusAppRuntime` erzeugt die SDE-Verwaltung erst nach erfolgreichem
Storestart.

Automation verwendet sichere Defaults: Prüfung an, Download und Installation
aus, mindestens 24 Stunden. Installation verlangt Schlüsselbundkontakt und
persönliche Prüfbestätigung. Archivcache, Logleser, bereinigter Export und
bestätigte Katalog-Retention sind getrennte Ports beziehungsweise Adapter.
Vor dem ersten Metadatencheck verwendet die Composition eine kontaktfreie
`SDEArchiveRecoveryBoundary`, um abgebrochene Download- und Cacheartefakte
zusammen mit den vorhandenen Import-/Staginggrenzen zu bereinigen. Bei einem
Recoveryfehler beginnt kein neuer Updatevorgang.

### Nachweise

- [ADR-0012](Architecture/ADRs/ADR-0012_SDE-App-Composition-Automation-und-Retention.md),
- Debug und Release jeweils 167 Tests,
- Policy-, Scheduler-, Parallelitäts-, Offline-, Cache-, Export- und
  Retention- sowie Start-Recovery-Tests,
- statischer Composition-/UI-/Accessibility-/Rechtstexttest.

### Datenwirkung und Grenze

- keine neue SwiftData-Schemaversion,
- Automationseinstellungen in UserDefaults,
- Kontakt ausschließlich im macOS-Schlüsselbund,
- Retention berührt nur bestätigte statische Katalogversionen,
- manueller Fenster-/Tastatur-/VoiceOver-Smoke-Test bleibt OFF-025 für P09B.

## 2026-07-23 – P09B: Eigenständiges Xcode-Projekt und gemeinsame Schemes

### Entscheidung

Das Repository besitzt neben `Package.swift` nun ein versioniertes
`NewEdenNexus.xcodeproj`. `project.yml` spiegelt alle 15 SwiftPM-Targets,
referenziert dieselben Quellen und erzeugt die gemeinsamen Schemes
`NewEdenNexus` und `NewEdenNexusSDEAcceptance`. Das App-Scheme führt alle
sieben Testtargets mit isoliertem projektlokalem Testprofil aus.

Ein statisches Prüfskript vergleicht Targets, Swift-Dateien, Test-Fixtures
und Schemes und lehnt absolute Benutzerpfade, Teamwerte und persönliche
Xcode-Metadaten ab. Die Xcode-only-Bundle-Brücke bildet lediglich SwiftPMs
generierten `Bundle.module`-Zugriff auf die bestehenden Fixtures nach.

### Nachweise

- [ADR-0013](Architecture/ADRs/ADR-0013_Xcode-Projekt-und-SwiftPM-Paritaet.md),
- `xcodebuild -list`: Debug, Release und gemeinsame Schemes erkannt,
- App Debug und Release ohne Signing erfolgreich,
- SDE-Abnahmerunner gebaut, nicht ausgeführt,
- Xcode: 167 Tests bestanden, 0 fehlgeschlagen, 0 übersprungen,
- SwiftPM Debug und Release erfolgreich, 167 Tests bestanden,
- manueller Start auf My Mac sowie SDE-, Settings-, Rechts-, Tastatur- und
  VoiceOver-Smoke-Test mit isoliertem Profil.

### Datenwirkung und Grenzen

- keine neue Fachlogik,
- keine SwiftData-Schemaversion oder Migration,
- keine produktiven Benutzerstores berührt,
- keine Team-, Signing-, Distribution- oder Release-Bundle-ID eingetragen,
- die lokale Bundle-ID bleibt ein ausdrücklich nicht freigegebener
  Entwicklungsplatzhalter,
- XcodeGen ist nur zur Regeneration, nicht für normale Builds erforderlich.

## 2026-07-23 – P10: Deterministischer Rezept- und Aktivitätsresolver

### Entscheidung

Application erhält mit `ResolveRecipeUseCase` eine zentrale, SwiftData- und
UI-freie Fachgrenze für Fertigungs- und Reaktionsrezepte. Der neue Port
`RecipeCandidateReading` liefert vollständige Kandidaten aus genau einer
aktiven SDE-Version; `RecipeReferenceAuditing` ermöglicht die itemgenaue
Vollprüfung aller nicht aufgelösten Material- und Produktreferenzen.

Ohne explizite Blueprint-ID wird ausschließlich ein eindeutiger Kandidat
akzeptiert. Mehrdeutigkeit, unveröffentlichte Ziele, ungültige Mengen,
Wahrscheinlichkeitsprodukte und inkonsistente Kandidaten werden typisiert
abgelehnt. Jede nicht aufgelöste Referenz blockiert das gesamte Rezept mit
`NEN-RECIPE-001`.

### Nachweise

- [ADR-0014](Architecture/ADRs/ADR-0014_Deterministischer-Rezeptresolver.md),
- neun Application- und fünf Persistence-Resolvertests,
- vollständige SwiftPM- und Xcode-Debug-/Release-Suites mit jeweils 181
  Tests,
- aktueller offizieller Build 3444265 mit vollständigem Fertigungs- und
  Reaktionsrezept,
- alle 21 gefundenen Referenzlücken itemgenau blockiert,
- Architekturgrenztests und statische Xcode-/SwiftPM-Parität erfolgreich.

### Datenwirkung und Grenzen

- keine neue SwiftData-Schemaversion und keine Migration,
- keine produktiven Benutzerstores berührt,
- keine automatische Blueprintpriorität,
- keine Runs-, ME-, Ketten-, Graph- oder Kostenberechnung vorgezogen,
- `project.yml` aktiviert Testbarkeit für Debug und Release, damit die
  bestehenden `@testable`-Testtargets in beiden Xcode-Konfigurationen
  reproduzierbar laufen.

## 2026-07-24 – P11: Projektlebenszyklus und reversible Archivierung

### Entscheidung

Der Projektlebenszyklus liegt nun zentral in Application. Eine explizite
Statuspolicy definiert alle erlaubten Kanten. Erstellen, Bearbeiten,
Duplizieren, Archivieren und Wiederherstellen greifen ausschließlich über
`ProductionProjectRepository` zu.

`ProjectsView` wurde von `@Query`, `modelContext` und persistenten Modellen
gelöst. `ProjectAppComposition` erzeugt den SwiftData-Adapter,
`ProductionProjectLifecycleService` und das `@MainActor`-
`ProjectLifecycleViewModel`.

### Nachweise

- [ADR-0015](Architecture/ADRs/ADR-0015_Projektlebenszyklus-und-reversible-Archivierung.md),
- zwölf Application-, ein dateibasierter Persistence-, drei
  ViewModel-/App-Integrations- und ein Architektur-/UI-Quelltest,
- SwiftPM und Xcode in Debug/Release jeweils 198 Tests, 0 Fehler,
  0 übersprungen,
- statische Projektparität: 15 Targets, sieben Testtargets, zwei Schemes.

### Datenwirkung und Grenzen

- keine neue SwiftData-Schemaversion und keine Migration,
- keine Löschung; Archivierung ist reversibel,
- kein produktiver Benutzerstore wurde durch Tests verändert,
- Produkt bleibt bis P12 Freitext,
- Graph, Runs, ME und Ketten bleiben P13–P19.

## 2026-07-24 – OFF-026: App-spezifischer Storepfad

### Entscheidung

Der generische SwiftData-Standardpfad `Application Support/default.store`
wird nicht mehr ungeprüft als produktiver New-Eden-Nexus-Store verwendet.
Die Factory löst standardmäßig
`Application Support/NewEdenNexus/NewEdenNexus.store` auf.

Ein vorhandener Legacy-Store wird read-only klassifiziert:

- New-Eden-Nexus-Signatur: unverändert am bisherigen Ort verwenden,
- fremde Signatur: unangetastet lassen und den app-spezifischen Pfad nutzen,
- unlesbar: sicher über die bestehende Fehlergrenze abbrechen.

Der App-Einstieg unterstützt zusätzlich einen absoluten, testbestimmten
Storepfad. Dadurch kann ein echter App-Prozess ohne Zugriff auf produktive
Benutzerdaten geprüft werden.

### Nachweise

- [ADR-0016](Architecture/ADRs/ADR-0016_App-spezifischer-Storepfad-und-sichere-Legacy-Erkennung.md),
- sechs Storepfad-/Signaturtests und ein Startargumenttest,
- SwiftPM und Xcode in Debug/Release: jeweils 205 Tests, 0 Fehler,
  0 übersprungen,
- echter isolierter App-Prozess mit konsistentem Schema-v4-Store,
- tatsächlich geöffneter Pfad über Prozessargumente und Dateideskriptoren
  bestätigt,
- fremder globaler `default.store` byteidentisch und zeitlich unverändert.

### Datenwirkung und Grenzen

- keine Schemaversion und keine Migration geändert,
- keine vorhandene Datei gelöscht, verschoben, ersetzt oder repariert,
- ein neuer app-spezifischer leerer Store wurde beim echten App-Start regulär
  angelegt,
- eine benutzergesteuerte Recovery-/Verschiebeoberfläche bleibt P36,
- P12 wurde vollständig spezifiziert, aber fachlich nicht ausgeführt.

## 2026-07-24 – P12: Kataloggebundenes Projektziel und Schema v5

### Entscheidung

Neue und neu ausgewählte Produktionsziele werden als validierter
`ProductionTargetSelection` mit Produkt-ID, Aktivität, Blueprint-ID und
Katalogprovenienz modelliert. Der Name bleibt ausschließlich
Anzeigesnapshot. Die Application-Schicht verbindet Suche, P10-Resolver,
Auswahl und Revalidierung; SwiftUI und SwiftData bleiben aus dieser
Fachkomponente ausgeschlossen.

Schema v5 ergänzt die Projektpersistenz additiv um fünf optionale Zielfelder.
Bestandsprojekte behalten diese Felder gemeinsam leer und werden niemals
anhand ihres historischen Freitextnamens einem CCP-Typ zugeordnet.

### Nachweise

- [ADR-0017](Architecture/ADRs/ADR-0017_Kataloggebundenes-Produktionsziel-und-Schema-v5.md),
- [Zielauswahl](PRODUCT_TARGET_SELECTION.md),
- Domain-, Application-, Persistence-, ViewModel- und Architekturtests,
- v4→v5-Migration mit aktiven, abgeschlossenen und archivierten Projekten,
- Repository-Roundtrip und erneute Storeöffnung,
- SwiftPM und Xcode in Debug/Release jeweils 219 Tests, 0 Fehler,
  0 übersprungen,
- isolierter App-Prozess mit Schema-v5-Store und allen fünf Zielspalten.

### Datenwirkung und Grenzen

- ausschließlich additive optionale Projektfelder,
- Backuppakete verwenden Schema 5.0.0 und akzeptieren 1.0.0 bis 5.0.0,
- keine Bestandsdaten wurden umgedeutet oder gelöscht,
- P13-Graph, Runs, ME und Ketten wurden nicht begonnen,
- die mechanische Teilung der gewachsenen Projektview ist als
  `OFF-027`/`KI-027` P34 zugeordnet.

## 2026-07-24 – P13: Erklärbarer Produktionsgraph und Schema v6

### Änderung

- unveränderlicher Domain-Snapshot mit Vorkommens-Knoten, Rezeptreferenzen
  und gerichteten Materialkanten,
- deterministische erste Rezeptstufe über das exakt gespeicherte
  P10-Blueprintrezept,
- typisierte Validierung für Struktur, Endpunkte, Zyklen, Tiefen,
  Erreichbarkeit und Katalogprovenienz,
- Application-Port und SwiftData-Repository mit Bestandsschutz,
- additives Schema v6 mit höchstens einem Graphsnapshot je Projekt,
- eigenständige Graphansicht und ViewModel außerhalb des Projekteditors,
- Backupformat und Migrationskette bis 6.0.0.

### Begründung

Runs, ME und rekursive Produktionsketten benötigen eine deterministische,
persistierbare und UI-unabhängige Struktur. Gleiche CCP-Typen dürfen in
verschiedenen Zweigen vorkommen, weshalb Type-IDs keine Knotenidentität sind.

### Auswirkungen

- P14 bis P19 können die Graphstruktur schrittweise erweitern, ohne die
  Persistenz- oder UI-Schichten zur Berechnungsquelle zu machen,
- Bestandsprojekte bleiben bei v5→v6 unverändert und erhalten keinen
  geratenen Graphen,
- P13 zeigt nur rohe Mengen der ersten Rezeptstufe; Rundung, Runs, ME,
  Rekursion und Aggregation bleiben ausdrücklich offen.

### Nachweis

- 238 SwiftPM-Tests in Debug und Release,
- alle sieben Xcode-Testtargets in Debug und Release,
- additiver v5→v6-Migrations- und Backupnachweis,
- isolierter echter Schema-v6-App-Prozess,
- [ADR-0018](Architecture/ADRs/ADR-0018_Erklaerbarer-Produktionsgraph-und-Schema-v6.md).

## 2026-07-24 – P14: Integer-Runs, Graphformat 2 und Schema v7

### Änderung

- zentraler Domainwert für vollständige Runs, tatsächliche Ausgabe und
  Überschuss mit Formelversion 1,
- ganzzahlige Ceiling-Division und geprüfte Outputmultiplikation,
- Graphformat 2 mit konsistenter Runberechnung je Rezeptknoten,
- lesbarer, aber veralteter Graphformat-1-Bestand,
- additives Schema v7 mit optionaler Formelversion am Graphdatensatz,
- Backupkompatibilität bis 7.0.0,
- Run-/Outputdarstellung in der separaten Graphansicht.

### Begründung

Runs müssen vor ME und rekursiven Ketten deterministisch, nachvollziehbar und
ohne Fließkomma- oder Überlaufrisiko feststehen. Eine eigene Payload- und
Formelversion verhindert, dass alte oder manipulierte Werte stillschweigend
als aktuell gelten.

### Auswirkungen

- P15 kann Materialmengen auf verifizierten Runs aufbauen,
- bestehende Format-1-Graphen und Benutzerdaten bleiben unverändert,
- `maxProductionLimit` bleibt Provenienz und wird nicht als unbelegte
  Projekt-/Jobgrenze missbraucht,
- die echte additive v7-Modellstufe verhindert den bei einer nominell
  identischen Schemafortschreibung reproduzierten SwiftData-Migrationsfehler.

### Nachweis

- 253 Tests in SwiftPM Debug und Release,
- 253 Tests in Xcode Debug und Release,
- vollständige v3→v7- und direkte v6→v7-Migrationsprüfung,
- isolierter echter Schema-v7-App-Prozess mit `integrity_check = ok`,
- [ADR-0019](Architecture/ADRs/ADR-0019_Integer-Runs-Graphformat-2-und-Schema-v7.md).

## 2026-07-24 – P15: Integer-ME, Graphformat 3 und Schema v8

### Änderung

- zentraler Domainwert für Rohbedarf, ME-reduzierten Effektivbedarf und
  Ersparnis mit Formelversion 1,
- ganzzahlige Jobrundung, Ein-Stück-je-Run-Schutz und geprüfte
  Multiplikationen,
- validierter Projekt-ME-Wert 0 bis 10; Reaktionen ausschließlich mit 0,
- Graphformat 3 mit Projekt-ME und Materialberechnung je Kante,
- lesbarer, aber veralteter Graphformat-1-/2-Bestand,
- additives Schema v8 mit optionalem Projekt-ME und
  Materialformelmetadatum,
- Backupkompatibilität bis 8.0.0,
- ME- und Materialaufschlüsselung in Projekt- und Graphansicht.

### Begründung

Materialbedarf muss vor rekursiven Ketten auf der verifizierten P14-Runbasis
reproduzierbar und nach der offiziellen CCP-Jobrundung berechnet werden.
Getrennte Graph-, Run- und Materialformelversionen verhindern, dass alte
oder manipulierte Werte stillschweigend als aktuell gelten.

### Auswirkungen

- P16 bis P19 können jede spätere Rezeptstufe auf derselben zentralen
  Berechnung aufbauen,
- alte Projekte erhalten neutral ME 0; alte Graphpayloads werden nicht
  fachlich umgeschrieben,
- weitere Jobmodifikatoren werden nicht unbelegt mit Blueprint-ME
  vermischt,
- Materialprodukt- und Reduktionszählerüberlauf sind geschlossen;
  Aggregationssummen bleiben P19.

### Nachweis

- 273 Tests in SwiftPM Debug und Release,
- 273 Tests in Xcode Debug und Release,
- vollständige v3→v8- und direkte v7→v8-Migrationsprüfung,
- isolierter echter Schema-v8-App-Prozess mit `integrity_check = ok`,
- [ADR-0020](Architecture/ADRs/ADR-0020_Integer-ME-Graphformat-3-und-Schema-v8.md).

## 2026-07-24 – P16: Manufacturing-Rekursion und Graphformat 4

### Änderung

- rekursive, deterministische Auflösung eindeutiger Manufacturing-Rezepte,
- eigene Run-, Ausgabe-, Überschuss- und Materialberechnung je
  Zwischenproduktvorkommen,
- Graphformat 4 mit Expansionsrichtlinienversion, Stufen-ME-Provenienz und
  begründeten Materialblättern,
- Zykluspfad, Tiefe 64 und 25.000 Knoten als Schutzgrenzen,
- Format-1-/2-/3-Kompatibilität ohne neue SwiftData-Schemaversion,
- erweiterte rekursive Graphdarstellung.

### Begründung

T1-Ketten müssen vor T2, Reaktionen und Aggregation vollständig und
reproduzierbar berechenbar sein. Eine Manufacturing-only-Grenze nutzt die
vorhandenen verifizierten SDE-Daten, ohne Tech-Stufen oder fehlende
Blueprint-ME-Werte zu erfinden.

### Auswirkungen

- P17 und P18 können die klar markierten T2-/Reaktionsgrenzen erweitern,
- P19 kann getrennte Materialvorkommen später kontrolliert aggregieren,
- ein Fehler, Katalogwechsel oder Abbruch ersetzt keinen Altgraphen,
- Schema v8 und Backupformat 8.0.0 bleiben unverändert.

### Nachweis

- 280 Tests in SwiftPM Debug und Release,
- 280 Tests in Xcode Debug und Release,
- dreistufige feste Referenzkette und Format-4-Persistenz,
- isolierter Schema-v8-App-Prozess mit `integrity_check = ok`,
- [ADR-0021](Architecture/ADRs/ADR-0021_Manufacturing-Rekursion-und-Graphformat-4.md).

## 2026-07-24 – P17: T2-Regelvertrag und Graphformat 5

### Änderung

- versionierter, an SDE-Build und Inhaltshash gebundener
  `IndustryRuleSet`,
- Blueprint-Herkunft und -qualität einschließlich aller acht Decryptoren,
- SDE-basierte T2-Klassifikation mit ausdrücklicher T3-Grenze,
- stufenbezogene T1-/T2-Qualität und Invention-Referenz,
- Graphformat 5 und Expansionsrichtlinie 2,
- unverändertes SwiftData-Schema v8 und Backupformat 8.0.0.

### Begründung

T2-Stufen dürfen weder aus Namen noch aus neutraler Zwischenprodukt-ME
geraten werden. Die konkrete SDE-Invention-Beziehung liefert
produktspezifische Runs und Wahrscheinlichkeit; ein fertigbarer
Ausgangs-Blueprint grenzt sie von Reverse Engineering/T3 ab.

### Auswirkungen

- gemischte T1-/T2-Manufacturing-Ketten besitzen je Stufe eigene Qualität,
- reguläre Invention plant erfolgreiche BPCs, aber keine garantierten
  Versuche,
- historische T2-BPOs bleiben explizite Ausnahmen,
- Reaktionen und Materialaggregation bleiben P18/P19.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 292 Tests,
- offizieller Build 3444265 einschließlich Blueprint 691 → 11372,
- isolierter Schema-v8-App-Prozess mit `integrity_check = ok`,
- [ADR-0022](Architecture/ADRs/ADR-0022_T2-Invention-und-Graphformat-5.md).

## 2026-07-24 – P18: Reaktionsregelprofil, Graphformat 6 und Schema v9

### Änderung

- SDE-Build- und Inhaltshash-gebundenes `ReactionRuleProfile`,
- bedarfsgesteuertes Mapping relevanter Typ-Dogma-, Attribut- und
  Effektdaten,
- zentrale neutrale und modifizierte Reaktionskontexte,
- ganzzahlige, versionierte Material- und Zeitberechnung,
- rekursive Manufacturing-/Reaction-Ketten,
- Graphformat 6 und Expansionsrichtlinie 3,
- additives Schema v9 mit `ReactionRuleRecord`,
- Backupkompatibilität 1.0.0 bis 9.0.0.

### Begründung

Reaktionsmodifier dürfen weder aus Namen noch aus historischen
Standardwerten geraten werden. Das aktive SDE-Regelprofil bindet Formelart,
Facility, Reactor, Rig, Security und Skill an denselben Katalogstand wie der
Produktionsgraph. Ein neutraler Kontext bleibt ausdrücklich ein
Basisszenario.

### Auswirkungen

- Manufacturing → Reaction, Reaction → Manufacturing und
  Reaction → Reaction sind deterministisch auflösbar,
- Blueprint-ME/TE bleibt für Reaktionen ausgeschlossen,
- unbekannte oder nicht verifizierte Regeln blockieren die Berechnung,
- Formate 1 bis 5 bleiben lesbar und veraltet,
- Materialaggregation bleibt P19, vollständiges Reaktionsmanagement P43.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 310 Tests,
- offizieller Build 3444265 mit drei Reaktionsarten,
- additive v8→v9-Migration und Schema-v9-Leerstore,
- isolierter App-Prozess mit `integrity_check = ok`,
- [ADR-0023](Architecture/ADRs/ADR-0023_Reaktionskontext-und-Graphformat-6.md).

## 2026-07-24 – P19: Type-ID-Aggregation und Graphformat 7

### Änderung

- reine Domainaggregation ausschließlich tatsächlicher Materialblätter,
- Gruppierung nach stabiler CCP-Type-ID statt Name,
- gespeicherte Einzelvorkommen, effektive Mengen, Blattgründe und
  vollständige Wurzelpfade,
- `Int64`-Summenüberlauf als typisierter Abbruch vor Persistenz,
- Graphformat 7 und Aggregationsformel 1 in der vorhandenen Payload,
- Neuberechnung und exakter Payloadvergleich beim Laden,
- identische Grenzen von 64 Ebenen und 25.000 Knoten für Generierung und
  geladene Graphen,
- iterative Zyklusprüfung und eindeutige Geschwister-Sortierwerte,
- unverändertes SwiftData-Schema v9 und Backupformat 9.0.0.

### Begründung

Gleiche Endmaterialien müssen projektweit zusammengeführt werden, ohne
Zwischenprodukte doppelt zu zählen oder die Herkunft einzelner Mengen zu
verlieren. Persistierte Summen dürfen nicht ungeprüft vertraut werden.

### Auswirkungen

- T1-, T2- und Reaktionszweige liefern eine gemeinsame reproduzierbare
  Endmaterialübersicht,
- jedes Summenglied bleibt über den Wurzelpfad erklärbar,
- manipulierte, zu tiefe, zu große oder überlaufende Graphen werden
  abgelehnt,
- ein Altgraph bleibt bei jeder fehlgeschlagenen Neuberechnung erhalten,
- Bestandsabzug, Reservierungen und Build-or-Buy bleiben P20 bis P26.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 321 Tests,
- Graphformat-7-Roundtrip, Format-6-Lesbarkeit und Manipulationsablehnung,
- `Int64.max`-Grenze und Application-Bestandsschutz,
- isolierter Schema-v9-App-Prozess mit `integrity_check = ok`,
- [ADR-0024](Architecture/ADRs/ADR-0024_Graphaggregation-und-Graphformat-7.md).

## 2026-07-24 – P20: Lokale Lager, manuelle Bestände und Schema v10

### Änderung

- neue reine Domainmodelle für Lagerorte und manuelle Bestandspositionen,
- `InventoryManaging` und `InventoryRepository` als Application-Grenzen,
- SwiftData-Adapter mit normalisiert eindeutigen Lagernamen und eindeutiger
  Lager-/Type-ID-Identität,
- additives Schema v10 und leichte v9→v10-Migration,
- Backupformat und Kompatibilitätsprüfung bis 10.0.0,
- native Assets-Unteransicht mit ViewModel, Katalogsuche, Archivierung,
  Wiederherstellung und bestätigtem Löschen,
- zentrale Inventory-Fehlercodes und Abbruchgrenzen.

### Begründung

CSV-Import, Verfügbarkeit und Reservierungen benötigen eine eindeutige,
lokale Bestandsquelle. Aggregierte manuelle Mengen werden bewusst von
späteren ESI-Assetinstanzen getrennt. Archivierung und ausdrückliches
Löschen schützen Benutzerdaten vor unbeabsichtigtem Verlust.

### Auswirkungen

- derselbe Itemtyp kann in mehreren Lagern unabhängig geführt werden,
- eine Lager-/Type-ID-Kombination wird aktualisiert statt dupliziert,
- Katalogprovenienz bleibt an jeder Position nachvollziehbar,
- vorhandene SDE-, Projekt-, Graph- und Reaktionsdaten migrieren unverändert,
- CSV-Import, Verfügbarkeit, Schutzbestände und Reservierungen bleiben
  P21–P25.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 335 Tests,
- v9→v10-Bestandsschutz, zweite Öffnung und v10-Leerstore,
- Backups 1.0.0 bis 10.0.0 sowie Ablehnung 11.0.0,
- Domain-, Service-, Repository- und UI-Architekturtests,
- [ADR-0025](Architecture/ADRs/ADR-0025_Lokale-Lager-und-manuelle-Bestaende.md).

## 2026-07-24 – P21: Kontrollierter CSV-Bestandsimport und Schema v11

### Änderung

- neuer Application-Vertrag für Inspektion, Mapping, schreibfreie Vorschau
  und bestätigtes Anwenden,
- Infrastrukturadapter für begrenztes Lesen, Kodierung, Delimiter, Quotes,
  Zeilenenden und SHA-256,
- katalog- und lagergebundene Zeilenklassifikation mit vollständiger
  Duplikatablehnung,
- positionsgenaue Ersetzen-/Überspringen-Entscheidungen,
- Stale-State-Prüfung für Lager, Bestand und aktiven Katalog,
- atomarer SwiftData-Commit aus Bestandsmutationen und bereinigtem Bericht,
- additives Schema v11 und leichte v10→v11-Migration,
- Backupformat und Kompatibilitätsprüfung bis 11.0.0,
- native CSV-Importansicht ohne SwiftData-Zugriff.

### Begründung

Dateiimporte dürfen Benutzerdaten weder aufgrund stiller Annahmen noch
teilweise verändern. Vorschau, Einzelkonflikte und ausdrückliche
Bestätigung machen jede beabsichtigte Mutation nachvollziehbar; ein
atomarer Bericht liefert nach dem Schreiben einen dauerhaften Nachweis.

### Auswirkungen

- unbekannte, ungültige und doppelte Zeilen bleiben ohne Datenwirkung,
- bestehende Positionen werden nur nach zeilengenauer Entscheidung ersetzt,
- Änderungen zwischen Vorschau und Apply verhindern veraltete Schreibungen,
- Rohdaten und vollständige Dateipfade gelangen nicht in die Datenbank,
- Verfügbarkeitsnetting, Schutzbestände und Reservierungen bleiben P22–P25.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 353 Tests,
- Parser-, Preview-, Konflikt-, Abbruch-, Stale-State-, Atomaritäts- und
  Rollbackfälle,
- v10→v11-Bestandsschutz, zweite Öffnung und v11-Leerstore,
- Backups 1.0.0 bis 11.0.0 sowie Ablehnung 12.0.0,
- [ADR-0026](Architecture/ADRs/ADR-0026_Sicherer-CSV-Bestandsimport-und-Schema-v11.md).

## 2026-07-24 – P22: Projektbezogene Verfügbarkeit und Schema v12

### Änderung

- neue validierte Domainkonfiguration und überlaufgeprüfter
  Verfügbarkeitsrechner,
- feste, doppelfreie Ausschlussreihenfolge für Archiv, Lagerauswahl,
  Materialregel und Obergrenze,
- Application-Service mit schreibfreier Vorschau, Bestätigung,
  Quellzustand-Token und Stale-State-Schutz,
- additives Schema v12 mit genau einer Konfiguration je Projekt,
- atomarer SwiftData-Adapter mit optimistischer Parallelitätsprüfung,
- Backupformat und Kompatibilitätsprüfung bis 12.0.0,
- native SwiftUI-Sheet im Produktionsgraphworkflow ohne direkten
  SwiftData-Zugriff.

### Begründung

Physischer Bestand, Schutzbestand und Reservierung sind fachlich
unterschiedliche Stufen. P22 persistiert deshalb nur die vom Benutzer
kontrollierten Freigaberegeln und berechnet das Ergebnis stets neu aus einem
aktuellen Graph- und Bestandszustand.

### Auswirkungen

- jede Materialzeile weist Bedarf und Ausschlussgründe ohne Doppelzählung
  aus,
- alte Vorschauen überschreiben keine zwischenzeitlichen Änderungen,
- gespeicherte Regeln für aktuell nicht mehr benötigte Materialien bleiben
  sichtbar und ungenutzt,
- P23–P25 können Schutzbestand und Reservierungen auf die physische
  P22-Basis aufsetzen,
- v11-Benutzerdaten migrieren unverändert; es werden keine Regeln geraten.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 371 Tests,
- v11→v12-Bestandsschutz, zweite Öffnung und v12-Leerstore,
- Backups 1.0.0 bis 12.0.0 sowie Ablehnung 13.0.0,
- isolierter App-Start mit `integrity_check = ok`,
- [ADR-0027](Architecture/ADRs/ADR-0027_Projektbezogene-Verfuegbarkeit-und-Schema-v12.md).

## 2026-07-25 – P23: Globaler Sicherheitsbestand und Schema v13

### Änderung

- deterministischer Domainrechner für globale Type-ID-Schutzregeln,
- harte Sicherheitsmenge auf der P22-Basis sowie unabhängige Mindest-,
  Warn- und Zielmeldungen,
- Application-Service mit schreibfreier Vorschau, Bestätigung und
  vollständigem P22-/Regel-Source-State,
- additives Schema v13 mit höchstens einer Regel je Type-ID,
- atomarer SwiftData-Adapter mit optimistischer Parallelitätsprüfung,
- Backupformat und Kompatibilitätsprüfung bis 13.0.0,
- native SwiftUI-Sheet im Produktionsgraphworkflow ohne direkten
  SwiftData-Zugriff.

### Begründung

Schutzmenge, Bestandsschwellen und spätere Projektreservierungen sind
fachlich getrennte Stufen. P23 schützt nur die globale Sicherheitsmenge
automatisch. Mindest-, Warn- und Zielwerte informieren unabhängig, weil das
Projektbuch keine verbindliche Größenreihenfolge vorgibt. Lagerbezogene
Regeln werden ohne belegte Allokationsregel nicht erfunden.

### Auswirkungen

- P22-ausgeschlossener aktiver Bestand deckt den globalen Schutz zuerst,
- archivierter Bestand zählt nicht,
- ohne Regel bleibt das P22-Ergebnis unverändert,
- veraltete Vorschauen oder Repository-Rennen überschreiben keine Regeln,
- P24/P25 können Reservierungen getrennt auf die P23-Basis setzen,
- v12-Benutzerdaten migrieren unverändert.

### Nachweis

- SwiftPM und Xcode Debug/Release jeweils 388 Tests,
- 17 neue P23-Tests einschließlich Service- und Repository-Stale-State,
- v12→v13-Bestandsschutz, zweite Öffnung und v13-Leerstore,
- Backups 1.0.0 bis 13.0.0 sowie Ablehnung 14.0.0,
- isolierter App-Start mit `integrity_check = ok`,
- [ADR-0028](Architecture/ADRs/ADR-0028_Globaler-Sicherheitsbestand-und-Schema-v13.md).

## 2026-07-25 – P24: Globale Projektreservierungen und Schema v14

### Änderung

- validierter Reservierungssnapshot und deterministischer Domainrechner,
- globale Projekt-/Type-ID-Bindung mit vier Lebenszykluszuständen,
- Überbuchungsschutz mit geprüften `Int64`-Summen,
- Application-Service mit schreibfreier Vorschau, Bestätigung und
  vollständigem P22-/P23-/Reservierungs-Source-State,
- additives Schema v14 mit Historieneinträgen,
- atomarer SwiftData-Adapter mit optimistischer Parallelitätsprüfung,
- Archivschutz für Projekte mit aktiver Bindung,
- Backupformat und Kompatibilitätsprüfung bis 14.0.0,
- native SwiftUI-Reservierungsansicht ohne direkten SwiftData-Zugriff.

### Begründung

Das Projektbuch fordert eine Projektbindung, belegt aber keine Zuordnung zu
Charakteren oder einzelnen Lagern. P24 verwendet deshalb die kleinste
tragfähige globale Type-ID-Regel. Physischer Bestand, Sicherheitsbestand,
Reservierung und spätere Konfliktauflösung bleiben getrennte Fachstufen.

### Auswirkungen

- aktive Restbindungen anderer Projekte reduzieren die maximal neue
  Bindung,
- eigene Bindungen werden getrennt ausgewiesen und nicht doppelt
  abgezogen,
- terminale Einträge bleiben als Historie erhalten,
- Ablaufdaten informieren ohne automatische Datenänderung,
- veraltete Vorschauen und Repository-Rennen schreiben nichts,
- Projekte mit aktiven Bindungen können nicht archiviert werden,
- P25 übernimmt nur nachträglich entstandene Konflikte und deren Auflösung,
- v13-Benutzerdaten migrieren unverändert.

### Nachweis

- 20 fokussierte P24-Tests,
- SwiftPM und Xcode Debug/Release jeweils 408 Tests,
- v13→v14-Bestandsschutz, zweite Öffnung und v14-Leerstore,
- Backups 1.0.0 bis 14.0.0 sowie Ablehnung 15.0.0,
- isolierter App-Start mit `integrity_check = ok`,
- [ADR-0029](Architecture/ADRs/ADR-0029_Globale-Projektreservierungen-und-Schema-v14.md).

## 2026-07-25 – P25: Berechnete Reservierungskonflikte

### Änderung

- deterministischer Domainrechner für Bestandsunterdeckung,
  Bedarfsüberschreitung und nicht mehr benötigte aktive Bindungen,
- stabile, rein beratende Prioritätsvorschläge,
- Application-Service mit schreibfreier Vorschau, ausdrücklicher
  Bestätigung und vollständigem P22-/P23-/P24-/Projekt-Source-State,
- atomare Reduktion oder Freigabe über die vorhandene
  P24-Repository-Grenze,
- native SwiftUI-Konfliktansicht ohne direkten SwiftData-Zugriff,
- keine neue Persistenzentität und keine Schema-v15-Stufe.

### Begründung

Ein gespeicherter Konfliktstatus würde nach Bestands-, Filter-, Schutz-,
Graph- oder Reservierungsänderungen veralten. Das Projektbuch verlangt
sichtbare Konkurrenz und benutzerkontrollierte Entscheidungen; Prioritäten
dürfen daher nur eine nachvollziehbare Reihenfolge vorschlagen.

### Auswirkungen

- Konflikte entsprechen immer dem geladenen Quellzustand,
- Teilauflösungen, die sichtbare Konflikte bestehen lassen, werden
  abgelehnt,
- Abbruch, Stale-State und Repository-Rennen schreiben nichts,
- mehrere Projekte können in einer bestätigten Operation atomar angepasst
  werden,
- Schema und Backupformat bleiben v14/14.0.0,
- `OFF-005/KI-005` ist vollständig geschlossen.

### Nachweis

- 21 fokussierte Konflikt-/Reservierungstests,
- SwiftPM und Xcode Debug/Release jeweils 423 Tests,
- isolierter App-Start mit `integrity_check = ok`,
- [ADR-0030](Architecture/ADRs/ADR-0030_Berechnete-Reservierungskonflikte-und-kontrollierte-Aufloesung.md).

## 2026-07-25 – P26: Build-or-Buy und Schema v15

### Änderung

- deterministischer Produktionsentscheidungsplan mit gemeinsamem
  Type-ID-Bestandspool,
- Zwischenbestände reduzieren Runs und nachgelagerte Unterketten,
- **Kaufen** schneidet exakt den verbleibenden Zwischenprodukt-Unterbaum,
- SDE-gebundene Inventionsmaterialmengen ohne erfundene Fehlversuche,
- Wiederverwendung der P22–P24-Rechner für Filter, Schutz und Reservierung,
- Preview-before-write-Service mit vollständigem Source-State,
- additives Schema v15 und Backupformat 15.0.0,
- Xcode-/SwiftPM-Projektparität für alle neuen Quellen.

### Nachweis

- 11 fokussierte P26-Tests,
- SwiftPM und Xcode Debug jeweils 434 Tests,
- v14→v15-Migration, Leerstore, Wiederöffnung und Backups,
- [ADR-0031](Architecture/ADRs/ADR-0031_Build-or-Buy-und-Schema-v15.md).

## 2026-07-25 – P32: Integrierter Produktionsworkspace

### Änderung

- P26-Plan über ein eigenes persistenzfreies Workspace-ViewModel in den
  vorhandenen Projekt-/Graphablauf integriert,
- konkrete Projekt-, Graph-, Lager-, Schutz-, Reservierungs-, Katalog- und
  Build-or-Buy-Repositories ausschließlich in `ProjectAppComposition`
  verdrahtet,
- Produktions-/Inventionsjobs, Lagerabzug, Konfliktstatus und positive
  Fehlmengen gemeinsam dargestellt,
- Bauen/Kaufen bleibt Vorschau plus ausdrückliche Bestätigung,
- projektfremde, veraltete und unberechnete Vorschauen werden nicht
  angezeigt, gespeichert oder kopiert,
- Dashboard von direktem `@Query`-/`modelContext`-Zugriff auf
  ViewModel-/Use-Case-Grenze umgestellt,
- keine Schema- oder Backupformatänderung.

### Nachweis

- 8 fokussierte P32-Prüfungen,
- SwiftPM und Xcode Debug jeweils 439 Tests ohne Fehler oder Überspringen,
- schmale/breite SwiftUI-Rendergrößen,
- statische Tastatur-, Accessibility-, SwiftData- und Xcode-Paritätschecks,
- [ADR-0032](Architecture/ADRs/ADR-0032_Integrierter-Produktionsworkspace.md).

## 2026-07-25 – P27: Exakte ISK-Preisprofile und Schema v16

### Änderung

- exakte `Int64`-Hundertstel-ISK-Werte statt persistenter Gleitkommazahlen,
- getrennte Domain-, Application-, Persistence- und SwiftUI-Grenzen,
- aktive Profile und kataloggebundene Preise mit Gültigkeitsfenster,
- explizite fehlende Type-IDs statt erfundener Nullpreise,
- additives Schema v16 und Backupformat 16.0.0,
- Navigationsmodul „Preise“ ohne direkten SwiftData-Zugriff.

### Nachweis

- 13 fokussierte P27-Tests,
- SwiftPM und Xcode Debug jeweils 453 Tests,
- v15→v16-Migration, Leerstore, Wiederöffnung, Kaskadenlöschung und Backup,
- isolierter App-Start mit integrem Schema-v16-Store,
- [ADR-0033](Architecture/ADRs/ADR-0033_Exakte-ISK-Preisprofile-und-Schema-v16.md).

## 2026-07-25 – P28: Atomarer CSV-Preisimport und Schema v17

### Änderung

- Wiederverwendung des gehärteten P21-CSV-Transports,
- preisfachliche Vorschau mit Katalogprüfung und Einzelkonflikten,
- atomare Preis-/Berichtspersistenz nach zweiter Bestätigung,
- Quelle `csv`, gemeinsames Gültigkeitsfenster und explizites Dezimalformat,
- additives Schema v17 und Backupformat 17.0.0,
- SwiftData-freie Import-ViewModel-/SwiftUI-Grenze.

### Nachweis

- 22 fokussierte Prüfungen,
- SwiftPM und Xcode Debug jeweils 461 Tests,
- v16→v17-Migration, Stale State, Löschkaskade und isolierter App-Start,
- [ADR-0034](Architecture/ADRs/ADR-0034_Atomarer-CSV-Preisimport-und-Schema-v17.md).

## 2026-07-26 – P29: Projektwirtschaftlichkeit und Schema v18

### Änderung

- zentrale Ganzzahlberechnung für Cash-/wirtschaftliche Materialkosten,
  Jobkosten, Erlös, Gewinn, Marge, ROI und Break-even,
- fehlende Preise blockieren vollständige Kennzahlen,
- Projektworkspace um Preisprofil, Jobkosten, Vorschau und Bestätigung
  erweitert,
- nur Berechnungsbasis statt veraltbarer Ergebnisse persistiert,
- additives Schema v18 und Backupformat 18.0.0.

### Nachweis

- 22 fokussierte P29-/Backup-Prüfungen,
- SwiftPM und Xcode Debug jeweils 473 Tests,
- v17→v18-Migration, Leerstore, Wiederöffnung, Stale-State und isolierter
  App-Start mit `integrity_check = ok`,
- [ADR-0035](Architecture/ADRs/ADR-0035_Reproduzierbare-Projektwirtschaftlichkeit-und-Schema-v18.md).

## 2026-07-26 – P30: Einkaufs-Overrides und Schema v19

### Änderung

- defensive Type-ID-Aggregation der P26-Nettomengen,
- projektbezogene Zielmengen als einzige persistierte Abweichung,
- vollständige Plan-/Override-Versionsbindung vor bestätigtem Ersatz,
- integrierte Bearbeitung, Rücksetzung und Textliste im Workspace,
- additives Schema v19 und Backupformat 19.0.0.

### Nachweis

- 14 fokussierte P30-Prüfungen,
- SwiftPM und Xcode Debug jeweils 486 Tests,
- v18→v19-Migration, Wiederöffnung, Stale-State, Abbruch,
  Duplikatprojekt und isolierter App-Start mit `integrity_check = ok`,
- [ADR-0036](Architecture/ADRs/ADR-0036_Projektbezogene-Einkaufs-Overrides-und-Schema-v19.md).

## 2026-07-26 – P31: Projektübergreifender Einkauf und Schema v20

### Änderung

- zentraler Einkaufsbereich ersetzt den Navigationsplatzhalter,
- aktuelle Projektlisten werden über P26/P30 neu berechnet und Type-ID-basiert
  zusammengeführt,
- Teilkäufe werden als Projekt-/Type-ID-Zuordnung gespeichert,
- veraltete, archivierte oder nicht berechenbare Zuordnungen bleiben
  geschützt,
- Text- und RFC-4180-kompatibler UTF-8-CSV-Export bleiben read-only,
- additives Schema v20 und Backupformat 20.0.0.

### Nachweis

- 15 fokussierte P31-Prüfungen,
- SwiftPM und Xcode Debug jeweils 501 Tests,
- v19→v20-Migration, Wiederöffnung, Stale-State, Scope-Isolation,
  schmale/breite UI und isolierter App-Start mit
  `integrity_check = ok`,
- [ADR-0037](Architecture/ADRs/ADR-0037_Projektuebergreifender-Einkaufsworkflow-und-Schema-v20.md).

## 2026-07-26 – P33: Sichere Validierung und kontrollierter UI-Retry

### Änderung

- UI-unabhängiger Validierungsvertrag mit `NEN-VAL-001` bis
  `NEN-VAL-006`,
- gemeinsame SwiftUI-Zusammenfassung in den schreibenden Kernformularen,
- Retry-Positivliste nur für idempotente Lese-/Inspect-/Previewoperationen,
- einmalige Runtime-Ausführung nach vorherigem Entfernen der Präsentation,
- keine Schema- oder Benutzerdatenänderung.

### Nachweis

- 16 fokussierte P33-Prüfungen,
- SwiftPM und Xcode Debug jeweils 507 Tests,
- Redaction, Retry-Gate, Einmalausführung, Schreibschutz,
  Validierungsdarstellung und schmale/breite Einkaufsansicht,
- [ADR-0038](Architecture/ADRs/ADR-0038_Sichere-Validierung-und-kontrollierter-UI-Retry.md).

## 2026-07-26 – P34: Gestaffelte Großgraphenprojektion

### Änderung

- Graphen bis 500 Knoten behalten die bestehende `OutlineGroup`,
- größere Graphen nutzen eine iterative, deterministische Projektion mit
  initial 1.000 sichtbaren Zeilen und 1.000er-Nachladegrenze,
- große Graph- und Materiallisten verwenden `LazyVStack`,
- Materialpfade teilen einen einmal aufgebauten Knotennamenindex,
- SDE-Installation/-Archiv, Projekteditor und Preis-CSV wurden rein
  mechanisch entlang bestehender Verantwortungen geteilt,
- keine Schema-, Persistenz- oder Fachänderung.

### Nachweis

- 50.000-Item-Suche: zehn Läufe in 0,288/0,295 Sekunden, 51 Zeilen,
  ein Batch,
- 25.000-Knoten-Projektion: 0,026/0,026 Sekunden für 1.000 sichtbare Zeilen,
- SwiftPM und Xcode Debug jeweils 512 Tests,
- [ADR-0039](Architecture/ADRs/ADR-0039_Gestaffelte-Grossgraphenprojektion.md).

## 2026-07-26 – P35: Adaptive und semantische macOS-Oberfläche

### Änderung

- funktionale, normalisierte Sidebar-Suche,
- minimale Hauptansicht 780 × 560,
- adaptive Grids und `ViewThatFits` in den Kernbereichen,
- semantische macOS-Systemfarben,
- Fokusfolge und vollständige Accessibility-Statuslabels,
- keine Schema-, Daten- oder Berechnungsänderung.

### Nachweis

- sechs neue P35-Prüfungen,
- SwiftPM und Xcode Debug jeweils 518 Tests,
- isolierter App-Start,
- manueller Accessibility-Baum-Nachweis als OFF-030 offen,
- [ADR-0040](Architecture/ADRs/ADR-0040_Adaptive-und-semantische-macOS-Oberflaeche.md).

## 2026-07-26 – OFF-006: Migration-/Recovery-Lebenszyklus

### Änderung

- Schemaerkennung für Nexus-Stores vor dem SwiftData-Öffnen,
- verpflichtendes `beforeMigration`-Backup bei älteren unterstützten Stores,
- kontrolliertes Freigeben storegebundener Runtime-Zustände vor Restore,
- Recovery-Einstellungen mit read-only Vorschau, Prüfbestätigung und finaler
  Restore-Bestätigung,
- Wiederöffnung über dieselbe Migrationsgrenze; Downgrade ausgeschlossen.

### Nachweis

- acht fokussierte Recovery-/Architekturtests,
- SwiftPM Debug 526/526,
- Xcode-App-Build und Xcode Debug 526/526 ohne UI,
- [ADR-0041](Architecture/ADRs/ADR-0041_Vor-Migrations-Backup-und-kontrollierter-Restore.md).

Zum Zeitpunkt der OFF-006-Abnahme blieb OFF-024 unabhängig für den externen
SDE-Prozessabbruch offen; der folgende P36-Nachweis schließt ihn.

## 2026-07-26 – P36: Externe SDE-Prozessgrenze

### Änderung

- optionaler Acceptance-Checkpoint in `SDEInstallationService`, der erst nach
  erfolgreicher Journalpersistenz benachrichtigt,
- Mehrprozess-Koordinator im getrennten SDE-Acceptance-Executable,
- fünf isolierte SIGKILL-/Neustart-Szenarien mit exakter PID-Bindung,
- Wiederöffnung über die reale Recovery-Composition sowie Integritäts-,
  Rollback-, Aufbewahrungs- und Cleanupprüfung,
- keine Schema-, Benutzerdaten- oder produktive Composition-Änderung.

### Nachweis

- fünf verschiedene PIDs und fünf Signalstatus-9-Exits,
- fünf erfolgreiche und idempotente Recoveryläufe,
- SwiftPM Debug 527/527 und Xcode-kompilierter P36-Testbund 6/6,
- Xcode-Debugbuilds für App und Acceptance-Executable,
- [ADR-0042](Architecture/ADRs/ADR-0042_Externer-SDE-Prozess-Recovery-Drill.md).

## 2026-07-26 – OFF-030: Dauerhaftes natives UI-Abnahmegate

### Änderung

- `NewEdenNexusUITests` als Xcode-only-macOS-UI-Testtarget in die gemeinsame
  App-Scheme aufgenommen,
- Projektverifikation modelliert Xcode-only-Targets und -Quellen explizit,
- echte Außenfenstergrenze 780 × 560 durch 500 Punkte SwiftUI-Inhaltshöhe
  hergestellt,
- Dashboard-Metriken als zugängliche Textrepräsentationen modelliert,
- keine Schema-, Daten-, Berechnungs- oder Modulgrenzenänderung.

### Nachweis

- SwiftPM Debug 518/518,
- Xcode Debug 520/520 einschließlich zwei UI-Tests,
- reales App-Bundle bei 1.280 × 800 und 780 × 560,
- Accessibility-Audit und Tab-Fokusfolge,
- [ADR-0040](Architecture/ADRs/ADR-0040_Adaptive-und-semantische-macOS-Oberflaeche.md).

## 2026-07-26 – P38: Gehärtete lokale SSO-Grenze

### Änderung

- transport- und frameworkneutrale Auth-/Account-Ports in Application,
- OIDC-Discovery, PKCE S256, zufälliger `state` und begrenzter einmaliger
  Network-Loopback in Infrastructure,
- kryptografische RS256/JWKS- sowie Claim-/Scopeprüfung,
- Refresh-Token ausschließlich im Keychain, Access-Token ohne Persistenz,
- SwiftData-Account-Repository und getestete Kompensation bei Teilfehlern,
- Accounts-/Synchronisationsviews ohne direkte SwiftData-/Keychain-Zugriffe,
- keine Schemaänderung und keine ESI-Fachdatenabfrage.

### Nachweis

- SwiftPM Debugbuild und 540/540 Tests erfolgreich,
- Xcode-Debugbuild der App erfolgreich,
- [SSO-Architektur](SSO_ARCHITECTURE.md),
- [ADR-0043](Architecture/ADRs/ADR-0043_SSO-Ports-JWT-und-Kompensation.md),
- manueller Eigentümer-SSO-End-to-End-Lauf bleibt für `✅` offen.

## 2026-07-26 – P39: Öffentliche ESI-Charakterbasis

### Änderung

- transportneutrale Charakter-, Cache- und Synchronisationsports in
  Application,
- offizieller unversionierter ESI-Charakterpfad ohne Bearer-Token,
- Validator-, Frische-, Limit-, Retry-, Abbruch- und Offlinebehandlung,
- separater begrenzter, atomarer Dateicache mit restriktiven Rechten,
- Account-UI mit Frische-, Offline-, Fortschritts- und Fehlerzuständen,
- kompensierbares Löschen des Profilcaches beim Trennen,
- keine Schemaänderung und keine privaten ESI-Scopes.

### Nachweis

- SwiftPM Debug und 565/565 Tests erfolgreich,
- Xcode Debug für macOS arm64 erfolgreich,
- realer offizieller ESI-Abruf mit HTTP 200 und konditional HTTP 304,
- [ESI-Architektur](ESI_ARCHITECTURE.md),
- [ADR-0044](Architecture/ADRs/ADR-0044_Oeffentliche-ESI-Charakterbasis-und-Dateicache.md).

## 2026-07-26 – P40: Persönliche ESI-Snapshots

- exakt drei persönliche Read-Scopes und offizielle Assets-, Blueprint- und
  Industry-Job-Routen ergänzt,
- paginierter sequenzieller Abruf mit Cachevalidatoren, Last-Modified-
  Konsistenz, Rate-Limits und festen Ressourcenobergrenzen,
- nicht persistierte Differenzvorschau vor jeder ausdrücklichen Übernahme,
- getrennten versionierten Dateisnapshot mit Staging, Revisionsschutz und
  atomarer Aktivierung eingeführt,
- Trennen um kompensierbare Entfernung persönlicher Snapshots erweitert,
- keine SwiftData-Migration und keine Vermischung mit manuellen Lagern,
- [ESI-Architektur](ESI_ARCHITECTURE.md),
- [ADR-0045](Architecture/ADRs/ADR-0045_Persoenliche-ESI-Snapshots-mit-Vorschau.md).

## 2026-07-27 – P41: Öffentliche Materialpreise

- öffentlichen tokenlosen Marktclient ausschließlich für angeforderte
  regionale Sell-Orders ergänzt,
- Validator-/Rate-Limit-/Offlinecache als getrennten begrenzten Dateiadapter
  eingeführt,
- mengenbezogene Preisbildung und Vorschau-vor-Schreiben in Application
  zentralisiert,
- Schema v21 additiv um Marktpreisprovenienz erweitert; Orderbücher bleiben
  außerhalb von SwiftData,
- Produktionsworkspace und Preisprofil über injizierte Ports angebunden,
- [ADR-0046](Architecture/ADRs/ADR-0046_Mengenbezogene-ESI-Materialpreise-und-Schema-v21.md).

## 2026-07-27 – P42: Persönliche Wallet und bestätigte Projektzuordnung

- persönlichen Wallet-Read-Adapter für Kontostand, Journal und
  Transaktionen ergänzt,
- privaten revisionsgebundenen Wallet-Dateisnapshot eingeführt,
- Schema v22 additiv um bestätigte Wallet-Projektzuordnungen erweitert,
- Plan- und Istwirtschaftlichkeit bleiben getrennte Domänenwerte,
- Charaktertrennung um Walletsnapshot und Zuordnungskompensation ergänzt,
- [ADR-0047](Architecture/ADRs/ADR-0047_Persoenliche-Wallet-Snapshots-und-bestaetigte-Projektzuordnung.md).

## 2026-07-27 – P50: Detaillierte persönliche ESI-Daten und Asset-Verfügbarkeit

- begrenzte, such-, filter- und sortierbare Projektion persönlicher Assets,
  Blueprints und Industry Jobs ergänzt,
- projektbezogene ESI-Asset-Auswahl mit flüchtiger Detailvorschau,
  ausdrücklicher Bestätigung und Revisionsschutz eingeführt,
- Doppelzählung mit manuellen/CSV-Beständen vor Bestätigung blockiert und
  bei späterer Überschneidung die Verrechnung deaktiviert,
- Schema v23 additiv um die bestätigte Type-/Location-/Mengenwahl erweitert,
- Build-or-Buy-Verfügbarkeit um separat ausgewiesene externe physische
  Mengen ergänzt; Lager-, Schutz- und Reservierungsdaten bleiben unverändert,
- Charaktertrennung um kompensierbare Entfernung der Auswahlen erweitert,
- Initialisierungsfehler des persönlichen Dateistores an den zentralen
  App-Startup-Fehlerpfad weitergereicht statt die Quelle still zu deaktivieren,
- [ESI-Asset-Verfügbarkeit](ESI_ASSET_AVAILABILITY.md),
- [ADR-0048](Architecture/ADRs/ADR-0048_Projektbezogene-ESI-Asset-Verfuegbarkeit-und-Schema-v23.md).

## 2026-07-27 – P51: Zweckgebundene Scopes und Plan-/Ist-Vergleich

- zentrale Zweckkonfiguration mit exakt drei P40- und vier P42-Read-Scopes,
- ausdrückliche Wallet-Neuautorisierung mit Bestandsschutz bei Abbruch,
- Schema v24 für nicht geheime, migrationsfähige Scopemetadaten; Tokens
  verbleiben im Keychain,
- Application-Service verbindet P29-Plan und bestätigtes P42-Ist ohne
  gegenseitige Überschreibung,
- gemeinsame UI behandelt fehlende, veraltete und archivierte Zustände,
- [ADR-0049](Architecture/ADRs/ADR-0049_Zweckgebundene-ESI-Scopes-und-Plan-Ist-Vergleich.md).

## 2026-07-28 – P52/OFF-044: Semantische ESI-Darstellung und reversible Projektauswahl

- technische IDs aus der normalen persönlichen Asset-, Blueprint-,
  Vorschau- und Jobdarstellung entfernt,
- SDE-Itemnamen sowie verständliche Aktivitäts-, Status- und
  Lagerbezeichnungen als UI-Projektion eingeführt,
- öffentlichen, tokenfreien `/universe/names`-Adapter mit begrenztem,
  atomarem und offlinefähigem Ortsnamencache ergänzt,
- private Spielerstrukturnamen ohne neue Scope-Autorisierung bewusst nicht
  angefordert,
- gespeicherte Projekt-Asset-Auswahl um Vorschau, zweite Bestätigung,
  Optimistic-Stale-Schutz und gezielte atomare Rücknahme ergänzt,
- keine Schemaänderung und keine automatische Änderung vorhandener
  Benutzerdaten,
- [ADR-0050](Architecture/ADRs/ADR-0050_Semantische-ESI-Namen-und-reversible-Asset-Auswahl.md).

## 2026-07-26 – P38: Stabile lokale Code-Identität und Einzel-Fenster-Grenze

### Änderung

- lokale Apple-Development-Werte ausschließlich in einer git-ignorierten
  `LocalSigning.xcconfig`; Standard-/CI-Konfiguration bleibt unsigned,
- Keychain-Lese-, Schreib- und Löschfehler werden an der Application-Grenze
  als eigener Auth-Fehler klassifiziert,
- Hauptfenster erhalten eine eindeutige AppKit-Kennung; wiederhergestellte
  Duplikate werden geschlossen und `⌘N` aktiviert das vorhandene Fenster,
- keine Schema-, Benutzer- oder Tokendatenänderung.

### Nachweis

- 542/542 SwiftPM-Tests,
- nativer Einzel-Fenster-UI-Test bestanden,
- Apple-Development-Build erreicht den Signierschritt, ist aber durch den
  gesperrten Anmeldeschlüsselbund blockiert,
- [ADR-0043](Architecture/ADRs/ADR-0043_SSO-Ports-JWT-und-Kompensation.md),
  OFF-033 und [Korrekturbericht](Progress/Reports/2026-07-26_P38_SSO-Lokalbetrieb-Korrektur.md).

## 2026-07-28 – P52/OFF-045/OFF-046: Private Ortsnamen und vollständige Typnamen

- optionalen, separat bestätigten Scope
  `esi-universe.read_structures.v1` ergänzt,
- private Strukturauflösung auf tatsächlich referenzierte Snapshot-Orte
  begrenzt und mit HTTP-Validatoren sowie Offlinecache versehen,
- vorhandene Produktions-/Walletscopes bei der Erweiterung erhalten,
- Typnamenauflösung von der fehlerhaften 2.000-Rohzeilen-Grenze gelöst und
  auf alle referenzierten Snapshot-Typen erweitert,
- Ladezustand und einen im aktiven SDE tatsächlich fehlenden Typ getrennt,
- keine Schema- oder automatische Benutzerdatenänderung,
- [ADR-0051](Architecture/ADRs/ADR-0051_Optionale-Spielerstrukturnamen-und-vollstaendige-Typaufloesung.md).

## 2026-07-28 – P52/OFF-047: Horizontale Produktionsworkspace-Navigation

- Graph-Sheet auf 1.080 pt Mindest- und 1.360 pt Idealbreite erweitert,
- lange Gesamtseite in sechs horizontal anwählbare Bereiche gegliedert,
- jeweils nur den gewählten Bereich unterhalb der festen Navigation gezeigt,
- vorhandene ViewModels, Fachlogik, Vorschau-/Bestätigungsgates und
  Persistenz unverändert gelassen,
- permanenten Projektlisten-Split wegen unnötig großer Zustands- und
  Navigationswirkung nicht vorgezogen,
- [ADR-0052](Architecture/ADRs/ADR-0052_Horizontale-Produktionsworkspace-Navigation.md).

## 2026-07-28 – P52/P41-1: ISK-Preissätze und profilfreie Marktvorschau

- Preisstände in der UI als Preissätze statt als vermeintliche
  Währungsprofile bezeichnet,
- ISK als einzige Rechen- und Speicherwährung beibehalten,
- öffentliche Marktpreisvorschau ohne vorhandenen Ziel-Preissatz ermöglicht,
- Übernahme ohne Ziel-Preissatz weiterhin fail-closed gesperrt,
- keine Schema-, Migrations- oder automatische Benutzerdatenänderung,
- optionale PLEX-Anzeige bis zu einem getrennten Buy-/Sell-Quotevertrag
  verschoben,
- [ADR-0053](Architecture/ADRs/ADR-0053_ISK-Preissaetze-und-profilfreie-Marktvorschau.md).

## 2026-07-28 – P52/P41-1: Benannte Regionen, Trade Hubs und Marktstandorte

### Entscheidung

- technische Region-/Location-Eingaben durch benannte Auswahlverträge ersetzt,
- alle ESI-Regionen öffentlich aufgelöst und fünf NPC-Trade-Hubs als
  überprüfte Schnellwahl ergänzt,
- lokal bekannte Stationen und Spielerstrukturen nach Region zusammengeführt,
- öffentliche Strukturmärkte auswählbar, private bekannte Strukturen
  fail-closed sichtbar, aber gesperrt,
- bestehender öffentlicher Sell-Order-, Vorschau- und Bestätigungsvertrag
  unverändert erhalten.

### Nachweise und Datenwirkung

- [ADR-0054](Architecture/ADRs/ADR-0054_Benannte-Marktquellen-und-oeffentliche-Strukturen.md),
- 26 fokussierte Prüfungen, 667/667 SwiftPM-Tests und signierter
  Xcode-Debugbuild bestanden,
- keine Schema-, Migrations- oder Benutzerdatenänderung.

## 2026-07-28 – P52/OFF-051: Gruppierte ESI-Detailansichten

- Assets, Blueprints und aktive Industry Jobs nach aufgelöstem Stationsnamen
  alphabetisch gruppiert,
- Stationsgruppen zunächst geschlossen und Zeilenaufbau in 100er-Schritten,
- vollständige Suche und Sortierung außerhalb des Main Threads; Ergebnisse
  überholter Aufträge werden verworfen,
- einmaliger Ortsindex statt wiederholter vollständiger Asset-Baumauflösung,
- historische Industry Jobs nur in der Ansicht ausgeblendet; Snapshot bleibt
  unverändert,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- [ADR-0055](Architecture/ADRs/ADR-0055_Gruppierte-und-gestaffelte-ESI-Detailprojektion.md).
## 2026-07-28 – P53: Ein Xcode-Projektkanon

`NewEdenNexus.xcodeproj` ist der einzige aktive Projektkanon in der
Repositorywurzel. Neun einzeln inventarisierte ältere Generierungsstände
liegen nach Eigentümerbestätigung unverändert und recoverbar unter
`Documentation/Archive/XcodeProjects/`; der alte P21-Entwurf liegt getrennt
vom aktiven Promptregister unter `Documentation/Prompts/Archive/`.
`Scripts/verify_project_governance.py` prüft diese Grenze, die erwarteten
Prompt-IDs und die aktuellen Steuerlinks. Laufzeit-, Datenmodell- und
Persistenzarchitektur wurden nicht geändert; ein neues ADR ist daher nicht
erforderlich.

## 2026-07-28 – P55: Projektbudget statt sichtbarer Wallet-Projektfinanzen

- Der Accountbereich bietet keinen Zugang mehr zur bisherigen
  Projektfinanzansicht; Wallet-Snapshots, Zuordnungen und Dienste bleiben
  unverändert erhalten.
- Der Produktionsworkspace berechnet ein Planbudget aus wirksamer
  Einkaufsliste, manueller Logistik und manueller Produktion.
- Individuelle Build-or-Buy-Entscheidungen bestimmen, ob ein
  Zwischenprodukt direkt oder dessen Eingaben bewertet werden.
- Schema v25 ergänzt ausschließlich die getrennte
  `ProjectBudgetConfigurationRecord`; v24→v25 ist additiv.
- Siehe
  [ADR-0056](Architecture/ADRs/ADR-0056_Projektbudget-statt-sichtbarer-Wallet-Projektfinanzen.md).

## 2026-07-28 – P56: Gruppierte Build-or-Buy-Auswahl

- Zwischenstufen anhand vorhandener Graphmerkmale als Produktion,
  T2/Invention oder Reaktion projiziert,
- Gruppenaktionen als reine Entwurfstransformation vor dem bestehenden
  Vorschau-/Bestätigungsgate ergänzt,
- Einzelentscheidungen und projektbezogene Type-ID-Persistenz erhalten,
- widersprüchliche Kategorien ohne Vermutung in einer neutralen Restgruppe,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- siehe
  [ADR-0057](Architecture/ADRs/ADR-0057_Gruppierte-Build-or-Buy-Auswahl.md).

## 2026-07-29 – P56: Reaktionsuntergruppen und kompakte Auswahl

- bisherige Reaktionsgruppe anhand des vorhandenen `reactionKind` in
  Biochemical, Composite und Hybrid Polymer Reactions getrennt,
- unklassifizierte Reaktionen ohne Vermutung sichtbar erhalten,
- schreibfreien Produktionsart-Filter und globale Entwurfsaktionen ergänzt,
- wiederholte sichtbare Pickerbeschriftung durch eine gemeinsame
  Spaltenüberschrift ersetzt; VoiceOver-Kontext bleibt itembezogen,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- siehe
  [ADR-0058](Architecture/ADRs/ADR-0058_Reaktionsuntergruppen-und-kompakte-Build-or-Buy-Steuerung.md).

## 2026-07-29 – P56: Deutsche Zahlenformatierung

- `NexusNumberFormat` bündelt sichtbare Mengen- und ISK-Darstellung im
  UI-Target,
- Mengen verwenden feste deutsche Tausenderpunkte; ISK ergänzt
  Dezimalkomma, zwei Nachkommastellen und die Einheit,
- technische IDs, editierbare Rohwerte, Domänenmodelle, Persistenz,
  Berechnungen sowie CSV-/Kopierformate bleiben unverändert,
- siehe
  [ADR-0059](Architecture/ADRs/ADR-0059_Deutsche-Zahlenformatierung-in-der-UI.md).

## 2026-07-30 – KI-062: Veröffentlichte Rezeptkandidaten

- implizite Rezeptauswahl trennt veröffentlichte von unveröffentlichten
  SDE-Blueprintkandidaten,
- genau ein veröffentlichter Kandidat bleibt deterministisch nutzbar,
- mehrere veröffentlichte Kandidaten sowie explizit gewählte
  unveröffentlichte Blueprints bleiben fail-closed,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- siehe
  [ADR-0063](Architecture/ADRs/ADR-0063_Eindeutige-veroeffentlichte-Rezeptauswahl.md).

## 2026-07-30 – KI-064: Optionale Chargenprovenienz

- der lokale Chargenkern benötigt nur Projekt, Datum, Status, Runs, ME, TE
  und Output,
- Ort, Charakter, ESI-Job, Blueprintbezug und technische IDs bleiben
  optionale Provenienz,
- Namen sind ohne technische ID zulässig; fehlende Zusatzwerte bleiben
  sichtbar, werden aber nicht erfunden,
- Vorschau und ausdrückliche Bestätigung bleiben unverändert erhalten,
- keine Schema-, Migrations- oder Benutzerdatenänderung,
- siehe
  [ADR-0060](Architecture/ADRs/ADR-0060_Produktionsbuch-und-Chargenrechnung.md).
