# Kataloggestützte Zielproduktauswahl

Stand: 2026-07-24 · P12

## Zweck

Neue und geänderte Produktionsprojekte verwenden kein freies Produktwort
mehr als fachlichen Schlüssel. Ein Ziel ist erst speicherbar, nachdem Produkt,
Aktivität und Blueprint gegen genau eine aktive lokale SDE-Version geprüft
wurden.

## Fachliches Ziel

`ProductionTargetSelection` speichert:

- CCP-Produkt-Type-ID und lokalen Namenssnapshot,
- Fertigung oder Reaktion,
- die exakt validierte Blueprint-Type-ID,
- Buildnummer und Inhalts-SHA-256 des geprüften Katalogs.

Der Name dient nur der Anzeige. Identität und spätere Graphauflösung beruhen
auf den stabilen CCP-IDs.

## Auswahlablauf

1. `ProductionTargetSelectionService.search` sucht ausschließlich
   veröffentlichte, produzierbare Items und liefert höchstens 50 Treffer plus
   `hasMore`.
2. Aktivität, Kategorie und Gruppe können kombiniert werden.
3. Itemdetails und Rezeptkandidaten müssen aus derselben aktiven
   Katalogversion stammen.
4. Jeder Blueprintkandidat wird einzeln über `ResolveRecipeUseCase` geprüft.
5. Ein vollständiger Kandidat wird automatisch verwendet; mehrere
   vollständige Kandidaten verlangen eine explizite Blueprintwahl.
6. Ein unvollständiger Kandidat bleibt blockiert, verhindert aber nicht die
   Wahl eines anderen vollständigen Kandidaten.
7. Erst danach entsteht das persistierbare Zielobjekt.

Es gibt keinen stillen Wechsel auf ein anderes Produkt, eine andere Aktivität
oder einen anderen Blueprint. Unterstützt ein Item Fertigung und Reaktion,
muss der Benutzer den Aktivitätsfilter ausdrücklich festlegen.

## Zielmenge

`ProductionTargetQuantityParser` akzeptiert lokalisierte positive ganze
Zahlen bis `Int.max`. Leertext, Dezimalwerte, null, negative Werte und
Überlauf werden abgelehnt. P12 besitzt keine willkürliche
100-Millionen-Obergrenze.

## Schema v5 und Bestandsprojekte

Schema v5 ergänzt `ProductionProject` additiv um fünf optionale Felder:

- `productTypeID`,
- `productActivityRaw`,
- `productBlueprintTypeID`,
- `productCatalogBuildNumber`,
- `productCatalogContentSHA256`.

Die Migration v4→v5 erhält Altprojekte unverändert und lässt diese Felder
leer. Es wird keine Type-ID aus dem Namen geraten. Solche Projekte bleiben
lesbar, filterbar, duplizierbar, archivierbar und wiederherstellbar. Vor einer
Bearbeitung wird im Formular deutlich „Ziel erneut auswählen“ angezeigt.

## Verhalten nach einem SDE-Wechsel

Beim Bearbeiten eines Projekts wird die gespeicherte Auswahl über die
stabilen IDs erneut gegen den aktiven Katalog geprüft. Erfolgreiche
Revalidierung aktualisiert Namenssnapshot und Provenienz im Entwurf. Scheitert
sie, bleibt das bisherige Ziel sichtbar, das Speichern aber gesperrt, bis der
Benutzer ein gültiges Ziel neu auswählt. Eine Namensumdeutung findet nicht
statt.

## Grenzen

P12 startet weder Netzwerk- noch SDE-Updateoperationen und implementiert
keinen Produktionsgraphen, keine Runs, keine Materialberechnung und keine
Blueprintoptimierung. Marktgruppenobjekte werden nicht importiert; Kategorie,
Gruppe und Aktivität decken den aktuellen Auswahlbedarf ab.

