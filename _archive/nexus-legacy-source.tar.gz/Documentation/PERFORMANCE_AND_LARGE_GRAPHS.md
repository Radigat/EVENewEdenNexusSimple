# Performance und große Produktionsgraphen

Stand: 2026-07-26 · P34

## Verbindliche Profile

New Eden Nexus unterscheidet drei Lastgrenzen:

- Katalog: 50.000 lokale Itemzeilen, Suche mit Limit 50.
- normaler UI-Graph: bis 500 Knoten als bestehende aufklappbare Baumansicht.
- großer UI-Graph: bis zur fachlichen Sicherheitsgrenze von 25.000 Knoten
  als iterative, gestaffelte Projektion.

Für große Graphen werden zunächst 1.000 Knoten dargestellt. Weitere Knoten
werden nur nach Benutzeraktion in 1.000er-Schritten ergänzt. Der Graph selbst,
seine Aggregation und seine gespeicherten Berechnungsergebnisse bleiben
vollständig; nur die UI-Materialisierung ist begrenzt.

## Messungen

| Pfad | Messung | Ergebnis | Budget |
|---|---|---|---|
| Katalog | 50.000 Items, 10 Suchen, Limit 50 | SwiftPM 0,288 s; Xcode 0,295 s; 51 Zeilen/1 Batch | < 2 s |
| Graphprojektion | 25.000 Knoten, 1.000 sichtbar | SwiftPM 0,026 s; Xcode 0,026 s | < 3 s |

Gemessen wurde am 2026-07-26 im Debugbuild auf dem aktuellen
arm64-Entwicklungsrechner. Die Zeitbudgets sind Regressionstore für diese
Testumgebung, keine Garantie für jedes Zielgerät.

## Technische Konsequenzen

- Kein zusätzlicher SwiftData-Index: Die begrenzte Suche erfüllt das Budget.
- Die große Baumansicht verwendet einen iterativen Depth-First-Durchlauf,
  sortiert Geschwister stabil und materialisiert nur das aktuelle Sichtfenster.
- `LazyVStack` verzögert SwiftUI-Zeilen außerhalb des sichtbaren Bereichs.
- Der Knotenname-Index für Materialpfade wird einmal pro Aggregationsansicht
  aufgebaut und wiederverwendet.
- Fachgrenzen von Tiefe 64 und 25.000 Knoten bleiben unverändert.

## Prüfen

```bash
swift test --filter ProductionGraphDisplayProjectionTests
swift test --filter ItemBlueprintCatalogPerformanceTests
swift test
xcodebuild test -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath /private/tmp/new-eden-nexus-p34-xcode-final
```

Neue Performancebehauptungen benötigen weiterhin Datensatz, Buildart,
Zielgerät, Messbefehl und beobachteten Wert.
