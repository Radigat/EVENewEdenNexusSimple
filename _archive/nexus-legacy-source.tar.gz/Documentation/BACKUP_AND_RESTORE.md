# Backup und Wiederherstellung

Stand: 2026-07-27 · Formatversion 1 · Anwendungsschema 22

## Zweck und Grenze

P06 stellt die UI-unabhängige Sicherungsgrenze bereit. OFF-006 verdrahtet sie
mit dem App-Lebenszyklus: Vor einer erkannten Migration wird gesichert; für
Restore werden storegebundene Zustände freigegeben und anschließend neu
geöffnet. Einstellungen bieten manuelles Backup und eine kontrollierte
Restore-Vorschau. Nicht enthalten sind automatische Zeitpläne, Cloudspeicher,
Komprimierung, anwendungseigene Verschlüsselung und der externe
SDE-Prozessabbruch aus OFF-024.

## Paketformat

Ein Backup ist ein Verzeichnis mit Endung `.nenbackup`:

```text
NewEdenNexus-<UUID>.nenbackup/
├── manifest.json
└── database.sqlite
```

`manifest.json` enthält:

- Formatkennung `com.newedennexus.local-backup`,
- Formatversion `1`,
- eindeutige Backup-ID,
- Erstellungszeitpunkt,
- Art `manual`, `beforeMigration`, `beforeRestore` oder `beforeSDEUpdate`,
- tatsächlich erkannte Schemaversion des gesicherten Stores, aktuell
  `22.0.0`,
- festen Datenbankdateinamen,
- Dateigröße,
- SHA-256-Prüfsumme,
- Verschlüsselungskennzeichnung `none`.

Formatversion 1 wird weder komprimiert noch von der Anwendung verschlüsselt. OAuth- und andere Keychain-Geheimnisse sind ausdrücklich nicht enthalten. Für externe Datenträger ist ein durch den Benutzer geschützter Speicherort erforderlich.

## Backup-Ablauf

1. Quelle und Zielverzeichnis werden validiert; symbolische Links an den geprüften Grenzen werden abgelehnt.
2. Im Zielverzeichnis entsteht ein privates `.partial`-Verzeichnis.
3. Die SQLite-Online-Backup-API erstellt einen konsistenten Snapshot einschließlich bereits im WAL sichtbarer Transaktionen.
4. Der Snapshot wird mit einem unveränderlichen read-only `PRAGMA quick_check` geprüft.
5. Größe und SHA-256 werden ermittelt und das Manifest geschrieben.
6. Datenbank und Manifest erhalten Dateirechte `0600`, das Paketverzeichnis `0700`.
7. Erst danach wird die Staging-Struktur im selben Verzeichnis atomar auf `.nenbackup` umbenannt.
8. Bei einem Fehler wird die partielle Struktur entfernt; ein unvollständiges finales Paket wird nicht veröffentlicht.

Erfolgreiche Backups werden nicht automatisch gelöscht. Die P06-Aufbewahrungsregel lautet `keep all`.

## Vorschau und Wiederherstellung

`previewRestore` ist read-only. Es prüft Paketendung, Verzeichnis- und
Dateitypen, Manifest, Format- und Schemaversion, Größe, SHA-256 sowie
SQLite-Integrität. Schema 22.0.0 ist aktuell; Schema 1.0.0 bis 21.0.0 bleiben
als vorwärts migrierbare Vorgänger zulässig. Unbekannte zukünftige Versionen
werden abgelehnt. Für einen vorhandenen Zielstore bindet die Vorschau außerdem einen
Fingerabdruck aus Hauptdatei, WAL und SHM. Sie verändert weder Backup noch
Zielstore.

`restore` erfordert:

- die unveränderte zuvor erzeugte Vorschau,
- eine ausdrückliche Bestätigung,
- die Erklärung des Aufrufers, dass der Zielstore geschlossen ist.

Vor jeder Änderung werden Backup und Ziel-Fingerabdruck erneut geprüft. Ist ein Zielstore vorhanden, wird danach zuerst ein vollständig verifiziertes Backup der Art `beforeRestore` erzeugt. Anschließend wird die wiederherzustellende Datenbank im Zielverzeichnis vorbereitet und geprüft. Vorhandene `-wal`- und `-shm`-Dateien werden erst jetzt kontrolliert in eine temporäre Quarantäne verschoben. Scheitert der Austausch, werden sie zurückgelegt. Der vorbereitete Store ersetzt den Zielstore atomar; bei Erfolg wird die Quarantäne entfernt.

Der technische Dienst kann nicht selbst beweisen, dass kein
SwiftData-Container mehr geöffnet ist. OFF-006 erfüllt diese
Lebenszyklusverantwortung am App-Rand: laufende SDE-Arbeit wird abgebrochen,
storegebundene ViewModels und Containerzustand werden freigegeben, der Dienst
erhält den expliziten Zustand `closed` und die Runtime öffnet danach erneut.

## Automatische Vor-Migrations-Sicherung

`NexusStoreSchemaInspector` prüft den Store read-only vor dem SwiftData-
Öffnen. Für eine unterstützte ältere Version erstellt
`NexusMigrationBackupCoordinator` zwingend ein verifiziertes
`beforeMigration`-Paket. Fehlt der Store oder ist er bereits aktuell, erfolgt
kein unnötiges Backup. Ein nicht als Nexus-Schema erkennbarer Store und jeder
Backupfehler blockieren das Öffnen; der Altstore bleibt unverändert. Die
Verwendung eines Stores aus einer künftigen App-Version als Downgrade wird
nicht unterstützt oder als sicher behauptet.

Die Schemaversion wird aus den tatsächlich vorhandenen Tabellen/Feldern
ermittelt und im Manifest gespeichert. Namen werden nicht als Schlüssel
verwendet.

## Recovery-Oberfläche

Die Einstellungen enthalten den Bereich **Sicherung**:

1. manuelles Backup erstellen,
2. `.nenbackup` auswählen und ausschließlich prüfen,
3. Paket, Zeit, Art, Schema, Größe, Prüfsumme und Ersetzungswirkung ansehen,
4. Prüfbestätigung aktivieren,
5. finale destruktive Bestätigung auslösen,
6. Sicherheitsbackup und erfolgreiche Wiederöffnung anzeigen.

Ein älteres Backup wird nach Restore vorwärts migriert. Ein Downgrade auf
eine ältere App- oder Schemaversion wird nicht unterstützt.

P07B verwendet denselben SQLite-Onlinesnapshot vor der Promotion einer neuen
SDE-Version. Existiert bereits ein aktiver Store, erzeugt
`SQLiteSDEPromotionSafetyBackup` ein verifiziertes Paket der Art
`beforeSDEUpdate`. Existiert noch kein Store, ist kein Vorzustand zu sichern.
Die zusätzlich im Katalog erhaltene vorherige `StaticDataVersion` bleibt
unabhängig davon als schneller fachlicher Rollback erhalten.

## Application-Vertrag

`LocalBackupManaging` definiert:

- `createBackup(sourceStoreURL:destinationDirectoryURL:kind:)`,
- `previewRestore(packageURL:targetStoreURL:)`,
- `restore(preview:confirmation:targetStoreState:safetyBackupDirectoryURL:)`.

Application enthält nur UI- und adapterunabhängige Verträge, Manifeste, Vorschau-/Ergebnistypen und fachlich sichere Fehler. `SQLiteLocalBackupService` und die SQLite-Hilfsfunktionen liegen in Persistence. `NexusModelContainerFactory.defaultStoreURL` stellt den zentral ermittelten Standardpfad bereit, ohne ihn fest zu codieren.

## Fehler- und Datenschutzgrenze

Die zentrale Fehlerbehandlung kennt die Operationen Backup erstellen, prüfen und wiederherstellen mit stabilen Codes `NEN-BACKUP-001` bis `NEN-BACKUP-003`. Öffentliche UI- und Diagnosetexte enthalten keine vollständigen Pfade oder Storeinhalte.

Der Backupdienst unterscheidet unter anderem:

- fehlende oder unsichere Quelle,
- bereits vorhandenes Zielpaket,
- beschädigtes oder inkompatibles Manifest,
- Prüfsummen- und Integritätsfehler,
- fehlende Bestätigung,
- nicht geschlossenes Ziel,
- nach der Vorschau verändertes Backup oder Ziel,
- Datei- und SQLite-Operationsfehler.

## Nachweise

Die Integrationstests verwenden ausschließlich temporäre SwiftData-Stores. Geprüft werden:

- konsistentes Backup bei geöffnetem Quellcontainer,
- restriktive Dateirechte und keine `.partial`-Reste,
- Ablehnung einer manipulierten Datenbank ohne Zieländerung,
- Bestätigungs- und Closed-Store-Gate,
- automatisches, selbst wiederherstellbares Sicherheitsbackup,
- vollständiger Werterhalt nach Restore,
- Ablehnung eines nach Vorschau veränderten Pakets,
- Ablehnung eines nach Vorschau veränderten Zielstores,
- fehlende Quelle ohne Restartefakte,
- Ablehnung einer nicht unterstützten Formatversion.
- Annahme von Schema-1.0.0- bis Schema-19.0.0-Vorgängerpaketen sowie Ablehnung
  unbekannter zukünftiger Versionen,
- v19 erkennen, automatisch sichern, auf v20 migrieren, altes Backup
  wiederherstellen und erneut öffnen/migrieren,
- unveränderter v19-Store bei fehlgeschlagenem Vor-Migrations-Backup,
- read-only Vorschau, zwei Bestätigungen und Runtime-Freigabe vor Restore.

## Betriebliche Hinweise

- Ein Backup ist erst verlässlich, wenn es geprüft und auf einem getrennten Medium aufbewahrt wurde.
- P06 implementiert die technische Sicherung; eine echte 3-2-1-Strategie benötigt weiterhin eine Benutzerentscheidung über zusätzliche Speichermedien.
- Vorwärtsmigration ist unterstützt; Downgrade nicht.
- Der externe SDE-Prozess-Kill/Neustart bleibt OFF-024 in P36.
