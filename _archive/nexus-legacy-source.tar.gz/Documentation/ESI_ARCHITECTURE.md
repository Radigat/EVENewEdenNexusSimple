# ESI-Architektur

Stand: 2026-07-28 · P50/OFF-044

## Zweck und Quellen

P39 stellt eine konservative, offlinefähige Basis für öffentliche
Charakterdaten bereit. Grundlage sind die am 2026-07-26 geprüften
offiziellen CCP-Dokumente:

- [ESI Overview](https://developers.eveonline.com/docs/services/esi/overview/)
- [ESI Best Practices](https://developers.eveonline.com/docs/services/esi/best-practices/)
- [ESI Rate Limiting](https://developers.eveonline.com/docs/services/esi/rate-limiting/)
- [EVE SSO](https://developers.eveonline.com/docs/services/sso/)
- [Kompatibilitätsdatum und unversionierte Routen](https://developers.eveonline.com/blog/changing-versions-v42-was-getting-out-of-hand)
- [Offizielle ESI-OpenAPI-Spezifikation](https://esi.evetech.net/meta/openapi.json)

## Datenquelle und Scope

Die App verwendet `GET https://esi.evetech.net/characters/{character_id}/`
mit `Accept`, aussagekräftigem `User-Agent` und zentral festgelegtem
`X-Compatibility-Date`. Die Route liefert öffentliche Daten und erhält
bewusst keinen Bearer-Token. P39 fordert deshalb keine neuen SSO-Scopes an.

SDE und ESI bleiben getrennt: SDE liefert statische EVE-Stammdaten; ESI
liefert hier nur öffentliche, zeitabhängige Charakterinformationen.
Benutzerdaten, Tokens und berechnete Produktionsdaten werden nicht in den
ESI-Cache aufgenommen.

## Schichten

- **Application:** transportneutrale Profile, Cachemetadaten, Ports und
  Synchronisationsservice.
- **Infrastructure:** HTTP-Client und begrenzter atomarer Dateicache.
- **App:** Composition, ViewModel und Accountansicht mit Aktualisieren-,
  Offline-, Fehler- und Frischezuständen.
- **Persistence:** vorhandenes Charakterkonto bleibt unverändert; P39
  benötigt keine SwiftData-Migration.

## Cache- und HTTP-Verhalten

- Ein frischer Cache wird ohne HTTP-Aufruf verwendet.
- `ETag` und `Last-Modified` werden gespeichert und als
  `If-None-Match` beziehungsweise `If-Modified-Since` gesendet.
- HTTP 200 validiert und ersetzt den Cache atomar.
- HTTP 304 aktualisiert die Frische des vorhandenen Eintrags; ohne Cache
  gilt 304 als Protokollfehler.
- Offline-, Timeout-, Rate-Limit- und Serverfehler dürfen einen vorhandenen
  Eintrag sichtbar als veraltet zurückgeben.
- 420/429 beachten Serverwartezeiten und starten keine Retry-Schleife.
- 5xx erhält höchstens einen begrenzten, abbrechbaren Wiederholungsversuch.
- Response und Cachedatei besitzen feste Größenlimits. Beschädigte,
  übergroße, veraltete oder semantisch ungültige Cachedateien werden
  abgelehnt.

Der Cache liegt getrennt im Application-Support-Bereich. Verzeichnis und
Datei werden mit restriktiven Rechten angelegt, symbolische Links werden
abgelehnt und Schreibvorgänge erfolgen atomar.

## Datenschutz und Diagnose

Der reale Eigentümerkontakt wird aus dem Schlüsselbund gelesen und nicht im
Repository fest codiert. Logs enthalten weder Tokens noch Kontaktangabe oder
rohe Antworten. Fehler werden über `NEN-ESI-001` mit bereinigtem Grund
klassifiziert.

Beim bestätigten Trennen werden Refresh-Token, lokales Charakterkonto und
öffentlicher Profilcache kompensierbar entfernt.

## Grenze zu P40

P39 enthält keine privaten Daten. P40 ergänzt drei persönliche
Lesedatenquellen. P42 ergänzt genau den persönlichen Wallet-Read-Scope;
Schreib- und Corporation-Daten bleiben ausgeschlossen. Öffentliche
Marktorders aus P41 verwenden weiterhin keinen persönlichen Scope.

## P40 – Persönliche Lesedaten

P40 fordert exakt diese Scopes an:

- `esi-assets.read_assets.v1`,
- `esi-characters.read_blueprints.v1`,
- `esi-industry.read_character_jobs.v1`.

Verwendet werden ausschließlich die offiziellen GET-Routen
`/characters/{character_id}/assets`,
`/characters/{character_id}/blueprints` und
`/characters/{character_id}/industry/jobs?include_completed=true`.
Access-Tokens bleiben flüchtig; ein im SSO-Refresh rotierter Refresh-Token
wird über den vorhandenen Vault ausschließlich im Schlüsselbund ersetzt.

## P42 – Persönliche Walletdaten

P42 fordert zusätzlich ausschließlich
`esi-wallet.read_character_wallet.v1` an. Seit P51 geschieht das erst nach
einer eigenen Erklärung und ausdrücklicher Neuautorisierung desselben
Charakters; ein vorhandener Snapshot gilt nicht als Scopebeleg. Nicht geheime
Scopemetadaten liegen in Schema v24, Tokens weiterhin nur im Schlüsselbund.
P42 verwendet die drei offiziellen
GET-Routen für Kontostand, Journal und Transaktionen. Der private
Dateisnapshot bleibt getrennt von P40 und SwiftData. Nur bestätigte
Projektzuordnungen liegen in Schema v22; Einzelheiten stehen in
[Wallet und Projektfinanzen](WALLET_AND_PROJECT_FINANCE.md).

Assets und Blueprints werden von Seite 1 bis `X-Pages` sequenziell geladen.
Antwortgröße, Seitenzahl und Gesamtzahl sind fest begrenzt. Jede Seite erhält
eigene ETag-/Last-Modified-Validatoren; unterschiedliche Last-Modified-Werte
innerhalb eines Abrufs blockieren die Aktivierung. 304 verwendet nur den
passenden vorhandenen Seitenstand. 401/403, 420/429, ein einzelner
abbrechbarer 5xx-Retry, Offlinebetrieb und Schemafehler sind typisiert.

Der Abruf schreibt zunächst nichts. Der Application-Service hält einen
maximal 500 Einträge umfassenden, aber vollständig gezählten
Änderungsnachweis nur im Speicher. Erst `Übernehmen` speichert alle drei
Datensätze als einen versionierten Snapshot mit Basisrevisionsprüfung.
Der Dateistore validiert einen restriktiv geschützten Staging-Stand und
aktiviert ihn atomar. Abbruch, veraltete Vorschau oder Teilfehler erhalten
den letzten Snapshot.

Die persönlichen Snapshots liegen getrennt von SwiftData, SDE, manuellen
Lagern, Projekten, Preisen und Tokens. P50/OFF-044 zeigt alle drei
Snapshotarten detailliert, such-, filter- und sortierbar mit sichtbarer
Herkunft, Revision und Frische. Technische IDs bleiben interne Schlüssel;
die normale UI zeigt SDE-Itemnamen sowie verständliche Aktivitäts-, Status-
und Ortsbezeichnungen. P52/OFF-051 gruppiert die vollständige Projektion
alphabetisch nach Station. Eingeklappte Gruppen erzeugen keine Einzelzeilen;
geöffnete Gruppen werden in 100er-Schritten dargestellt. Ein einmaliger
Ortsindex und Hintergrundprojektionen mit verworfenen veralteten Ergebnissen
ersetzen wiederholte Asset-Baumauflösungen. Die Suche bleibt vollständig.
Industry Jobs mit einem
anderen ESI-Status als `active` bleiben gespeichert, werden in dieser
Arbeitsansicht aber nicht angezeigt.

Assets können nach Auswahl von Projekt und benannten EVE-Lagerorten als
eigene read-only Verfügbarkeitsquelle aktiviert werden. Eine
positionsgenaue Vorschau, ein zweiter Bestätigungsdialog und ausdrückliche
Bestätigung sind verpflichtend. Überschneidungen
mit manuellen/CSV-Beständen blockieren die Aktivierung; spätere
Überschneidungen oder eine neue Snapshotrevision verhindern die Verrechnung.
Manuelle Bestände werden weder kopiert noch überschrieben. Einzelheiten:
[kontrollierte ESI-Asset-Verfügbarkeit](ESI_ASSET_AVAILABILITY.md).

OFF-044 verwendet zusätzlich das öffentliche `POST /universe/names` in
höchstens 1.000 IDs umfassenden Batches. Der Request enthält keinen
Bearer-Token. Nur Stations- und Sonnensystemantworten werden akzeptiert;
Namen werden validiert und atomar in einem begrenzten,
charakterbezogenen Application-Support-Cache gespeichert. Offlinefehler
verwenden den letzten gültigen Cache. Beim Trennen wird auch dieser Cache
kompensierbar entfernt.

Private Spielerstrukturen werden ausschließlich nach einem separaten,
erklärten Opt-in über `esi-universe.read_structures.v1` aufgelöst. Die
Neuautorisierung erhält vorhandene Produktions- und Walletscopes. Erst danach
fragt die App die im Snapshot tatsächlich referenzierten Strukturen einzeln
über `GET /universe/structures/{structure_id}` ab. ETag, Last-Modified,
Expires/Cache-Control und 304 werden pro Struktur gespeichert; 403/404
erzeugen keinen erfundenen Namen. Ohne aktuellen Scope oder tatsächlichen
Zugriff zeigt die App nur „Spielerstruktur – Name nicht verfügbar“, niemals
die rohe ID. Abbruch der SSO-Freigabe verändert Token, Scopemetadaten und
Snapshots nicht.

Typnamen stammen weiterhin ausschließlich aus dem aktiven lokalen SDE. Die
Detailansicht löst alle im gespeicherten Snapshot referenzierten Type-IDs
gebündelt auf; die frühere Begrenzung auf die ersten 2.000 Rohzeilen ist
entfallen. „Name wird geladen“, „noch nicht geladen“ und „Typ im lokalen SDE
nicht enthalten“ sind getrennte Zustände. Der private Struktur-Endpunkt wird
nicht als Ersatz für fehlende statische Typdaten verwendet.

Beim bestätigten Trennen werden Snapshots und projektbezogene
Asset-Auswahlen zusammen mit Konto, öffentlichem Profilcache und
Refresh-Token kompensierbar entfernt.

Für den ersten realen Abruf muss der Eigentümer den Charakter erneut über
EVE SSO verbinden und die drei Leseberechtigungen bestätigen. Ein solcher
persönlicher Live-Abruf war nicht Teil der automatisierten P40-Abnahme.

Für die P41-Marktquellenauswahl lädt ein separater öffentlicher
Universe-Directory-Adapter Regionen, Stationshierarchie und das Verzeichnis
öffentlicher Marktstrukturen. Er kombiniert diese Daten ausschließlich mit
lokal bereits bekannten Stations- und Strukturnamen. Der bestehende
Preisabruf bleibt der öffentliche regionale Sell-Order-Endpunkt. Bekannte
nicht öffentliche Strukturen werden deshalb benannt, aber nicht als
Preisquelle aktiviert; private Strukturorders benötigen später einen
gesonderten authentifizierten ESI-Vertrag.
