# New Eden Nexus – Assets, Industry, Markets

Stand: 2026-07-27
Verbindlicher Produktfokus: Stufe A – lokal betriebener Produktionsplaner MVP

## 1. Projektvision

New Eden Nexus ist eine native, lokal arbeitende macOS-Anwendung für die
nachvollziehbare Planung industrieller Vorhaben in EVE Online. Der aktuelle
Zielbetrieb ist ausschließlich die Eigennutzung auf dem Mac des
Projekteigentümers. Für ein Zielprodukt und eine Zielmenge beantwortet die
Anwendung, welche Materialien benötigt werden, welche Mengen verfügbar oder
geschützt sind, welche Zwischenprodukte selbst gebaut werden und was
eingekauft werden muss.

Langfristig kann daraus eine umfassende Industrieplattform entstehen. Live-Daten und Optimierung dürfen jedoch weder Architektur noch Abschluss des aktuellen MVP dominieren.

### Aktuelles Distributionsziel

- Die App wird lokal aus Xcode beziehungsweise aus einem lokalen Build
  gestartet.
- Ein lokaler optimierter `Release`-Build ist eine technische
  Buildkonfiguration, kein öffentlicher Release.
- Mac App Store, öffentliche Direktverteilung, Apple-Signing, Hardened
  Runtime, Notarisierung und öffentliche Releaseprozesse sind keine
  Abnahmekriterien des MVP.
- Diese Arbeiten sind als **P48** das letzte optionale Zukunftspaket nach
  allen Fach- und Plattformpaketen eingeordnet.

## 2. Zielgruppen

Primäre Zielgruppe des MVP sind Solo-Industrialisten und Gelegenheitsspieler, die Produktionsketten ohne Tabellenkalkulation planen möchten. Fortgeschrittene Produzenten profitieren von transparenten T1-/T2-Ketten, Reaktionsstufen, Reservierungen und Build-or-Buy-Entscheidungen. Multiboxer, Händler, PI-Spezialisten und Corporation-Leiter sind langfristige Zielgruppen; ihre Live- und Mehrbenutzeranforderungen gehören nicht zum aktuellen MVP.

Grundlage: Projektbuch Kapitel 1, insbesondere Zielgruppenanalyse; für den aktuellen Umfang maßgeblich ist der reduzierte MVP vom 2026-07-23.

### Abgeschlossene Ausführungsscheibe PLAN-002

Um Entwicklungs- und Kontextkosten zu senken, wurde der damalige Restumfang
vorläufig auf einen intern nutzbaren Kern begrenzt:

- Produktion einschließlich T1/T2, Invention und vorhandener Reaktionen,
- lokaler/importierter Lagerbestand einschließlich Schutz und
  Reservierungen,
- manuelle Entscheidung **Bauen** oder **Kaufen**,
- Produktions-/Inventionsjobs und einfache Fehlmengenliste,
- integrierter Kernworkflow und interne Abnahme.

Die Kernreihenfolge **P26 → P32 → P37** ist abgeschlossen. P27 bis P36
wurden danach reaktiviert und ebenfalls abgenommen. PLAN-002 bleibt als
historische Reduktionsentscheidung erhalten; maßgeblich:
[Tokenarmer Kern-MVP](LEAN_MVP_PLAN.md).

## 3. Verbindlicher reduzierter MVP

| Bereich | Zielzustand | Nachgewiesener Ist-Stand |
|---|---|---|
| Native macOS-App | Swift/SwiftUI, lokale Ausführung auf dem Eigentümer-Mac | **Implementiert und lokal geprüft:** Swift-Package, Xcode-Projekt, SwiftUI-App, Navigation, lokale Debug-/Releasebuilds und native UI-Tests sind vorhanden. Öffentliche Distribution ist bewusst kein MVP-Kriterium. |
| Lokale Datenhaltung | Persistente Fachdaten, versionierte Migrationen | **Implementiert bis Schema v22:** Kernfachdaten, Marktpreisprovenienz und bestätigte Wallet-Projektzuordnungen; private ESI-Snapshots bleiben getrennte Dateien. Der additive Migrationspfad ist getestet. |
| Statische EVE-Daten | Items, Gruppen, Kategorien, Blueprints, Aktivitäten, Produkte, Materialien, Zeiten, Reaktionen | **Implementiert für P07–P10/P18:** validiertes JSONL-Staging, versionierte atomare Aktivierung, read-only Item-/Blueprintkatalog, deterministische Fertigungs-/Reaktionsauflösung und bedarfsgesteuertes Reaktions-Dogmaprofil; unvollständige Referenzen blockieren das gesamte Rezept. |
| Produktionsprojekte | Produkt/Menge, Speichern, Status, Duplizieren, Archivieren | **Implementiert:** kataloggebundenes Ziel, Menge, lokaler Lebenszyklus, Statusgraph, Duplizieren, reversible Archivierung und Wiederherstellung. |
| Produktionsgraph | Mehrstufiger gerichteter Graph | **Implementiert:** versionierter erklärbarer Graph mit T1-, T2- und Reaktionsstufen, Aggregation und Schutzgrenzen. |
| Berechnung | Graph, Runs, Outputs, ME, T1, T2, Reaktionen, Zusammenführung | **Implementiert für den Produktionskern:** P13 persistiert den Graphsnapshot, P14 Runs/Output, P15 Blueprint-ME/Materialbedarf, P16 T1-Rekursion, P17 T2-Klassifikation, P18 rekursive Reaktionsstufen und P19 Type-ID-Aggregation mit Erklärpfaden und Graphschutz in Graphformat 7. Bestandsnetting und Build-or-Buy folgen P20–P26. |
| Lokale/importierte Bestände | Manuell, CSV, Lagerorte, Ausschlüsse, verfügbare Menge | **Implementiert für P20–P25:** Lager, manuelle Positionen, begrenzter CSV-Import, projektbezogene Lager-/Material-/Mengenfreigaben, globale Schutzmengen, Projektreservierungen und nachträgliche Konfliktauflösung mit Preview-before-write sind vorhanden. |
| Sicherheitsbestände | Mindest-, Ziel- und Warnbestände | **Implementiert:** globale Type-ID-Regeln, harter Sicherheitsbestand, unabhängige Mindest-/Warn-/Zielmeldungen und informative Zielauffüllung. |
| Reservierungen | Projektbindung, Konkurrenz und geschützte Mengen | **Implementiert:** P24 liefert globale Projekt-/Type-ID-Bindungen, Lebenszyklus, Überbuchungsschutz und Archivschutz; P25 ergänzt berechnete Bestands-/Bedarfskonflikte, Prioritätsvorschläge und bestätigte atomare Reduktion/Freigabe. |
| Build-or-Buy | Bestand, selbst produzieren, kaufen, ignorieren | **Kern implementiert:** Bestand automatisch verwenden und Zwischenstufen manuell bauen/kaufen; Ignorieren und Empfehlungen bleiben verschoben. |
| Preise und Kosten | Manuell/CSV, Profile, Kosten, Erlös, Gewinn, Marge, ROI, Break-even | **Implementiert:** P27–P29 liefern Planwerte, P41 mengenbezogene öffentliche Beschaffungspreise und P42 bestätigte persönliche Istkosten/-erlöse, fachlich getrennt von der Planung. |
| Einkaufsliste | Fehlmengen, Zusammenführung, Bearbeitung, gekauft, CSV/Text | **Implementiert:** P30 liefert persistente Zielmengen; P31 ergänzt projektübergreifende Type-ID-Zusammenführung, Teilkäufe, gekauft-Status sowie read-only Text-/CSV-Export. |
| Backups | Lokale Sicherung und geprüfte Wiederherstellung | **Implementiert:** technischer Snapshot-/Restore-Dienst bis Schema v22, automatische Vor-Migrations-Sicherung, Recovery-UI mit Vorschau/Doppelbestätigung sowie kontrollierte Storefreigabe und Wiederöffnung. |
| Qualität | Build, Tests, Logging, Fehlerbehandlung, Dokumentation | **Für den lokalen Zielbetrieb implementiert:** SwiftPM Release 527/527, nativer Xcode-UI-Testworker 2/2, Performance-, Accessibility-, Backup- und Recoverynachweise sind vorhanden. Apple-Store-/Notarisierungshärtung ist optionaler P48-Zukunftsumfang. |

## 4. Bewusst verschobene Funktionen

Die folgenden Funktionen sind Zukunftsumfang und keine Abnahmekriterien der Stufe A:

- vollständiges Reaktionsmanagement jenseits der Rezeptauflösung,
- Planetary Industry,
- Corporation Edition, Rollen und Mehrbenutzerbetrieb,
- Cloud-Synchronisation,
- automatische Slot- und Kapazitätsplanung,
- Constraint Solver, KI und Optimierungsengine,
- Mobile App und Plugin-System.
- Mac App Store und öffentliche Direktverteilung einschließlich finaler
  Bundle-ID, Marketing-/Buildversion, Apple-Team, Signing, Hardened Runtime,
  Archivierung, Notarisierung, Stapling und Gatekeeper-Abnahme.

**Technisch umgesetzter lokaler Ausbau:** P38–P42 liefern gehärtetes SSO,
Charaktere, persönliche Assets/Blueprints/Jobs, öffentliche
Beschaffungspreise und persönliche Wallet-Snapshots mit bestätigten
Projektzuordnungen. PLAN-005 schließt vor weiterer Erweiterung die
Nutzbarkeits-, Scope-, Plan-/Ist-, Betriebs-, Steuerungs- und
Sicherungsrestbefunde in P50–P54. Diese Korrekturen verändern den
abgeschlossenen Stufe-A-Kern nicht.

## 5. Entwicklungsstufen

1. **Stufe A – Produktionsplaner MVP:** langfristig statische Daten,
   Produktionsprojekte und -graph, T1/T2/Reaktionsberechnung, Bestände,
   Schutzmengen, Reservierungen, Build-or-Buy, Preise, Einkaufsliste,
   Backups, Tests und Dokumentation. PLAN-002 lieferte zuerst den
   Produktions-/Inventions-/Lagerkern; die danach reaktivierten
   Ausbaupakete P27 bis P36 sind ebenfalls abgeschlossen.
2. **Stufe B – Persönliche EVE-Anbindung:** SSO, Charaktere, ESI-Infrastruktur, persönliche Assets, Blueprints und Industry Jobs.
3. **Stufe C – Märkte und Finanzen:** Live-Marktpreise, Wallet, Transaktionen, reale Projektkosten und realisierte Gewinne.
4. **Stufe D – Erweiterte Industrie:** vollständiges Reaktionsmanagement, PI, Logistik, Kalender und Kapazitätsplanung.
5. **Stufe E – Corporation und Optimierung:** Corporation-Daten, gemeinsame Projekte, Rollen/Rechte, Mehrbenutzerbetrieb und Optimierung.
6. **Stufe F – Optionale öffentliche Distribution:** P48 als letztes
   optionales Paket für Mac App Store oder eine dann bewusst gewählte
   öffentliche Direktverteilung. Stufe F ist keine Voraussetzung für den
   lokalen Betrieb und wird nur auf ausdrücklichen Auftrag aktiviert.

Verbindliche Folge nach PLAN-004: **P38 → P39 → P40 → P41 → P42 → P43 →
P44 → P45 → P46 → P47 → P48**. Nach P40, P42 und P44 wird geprüft, ob der
nächste Abschnitt für den lokalen Betrieb tatsächlich benötigt wird.

Verbindliche Restabnahme nach PLAN-005: **P50 → P51 → P52 → P53 → P54**.
P49 ist bewusst unbelegt. P50–P54 schließen vorhandene P40-/P42- und
Betriebsbefunde; sie ziehen P43–P48 nicht vor.

## 6. Definition of Done

Eine Aufgabe ist nur erledigt, wenn alle zutreffenden Punkte nachgewiesen sind:

- Code oder Dokumentation vollständig umgesetzt,
- Projekt erfolgreich gebaut,
- relevante automatisierte Tests erfolgreich,
- keine durch die Änderung verursachten offenen Fehler,
- Dokumentation, Feature-Matrix und Projektstatus aktualisiert,
- Abschlussbericht gespeichert,
- Eintrag im Entwickler-Menü mit Nachweis auf `✅ erledigt` gesetzt.

Eine sichtbare Oberfläche, ein kompilierender Platzhalter oder ein erfolgreicher Gesamtbuild allein belegt kein fertiges Feature.

Für lokale Arbeitspakete sind App-Store-Metadaten, Developer-ID,
Notarisierung und öffentliche Freigaben ausdrücklich keine DoD-Bedingungen.
Sie werden erst in P48 verbindlich.

## 7. Architekturprinzipien

- **Local first und offline nutzbar:** MVP-Fachdaten bleiben lokal; externe Live-Dienste sind keine Kernabhängigkeit.
- **Native Oberfläche:** SwiftUI ist die Standard-UI; AppKit nur bei belegter Lücke.
- **Deterministischer Fachkern:** Berechnungen sind reproduzierbar, unabhängig von Ansichten und mit Referenzfällen testbar.
- **Explizite Schichten und Abhängigkeiten:** UI, Anwendungsfälle, Domäne, Persistenz/Import und externe Adapter werden getrennt.
- **Versionierte Datenhaltung:** Jede Schemaänderung benötigt eine nachvollziehbare Migration und einen Wiederherstellungsweg.
- **Erklärbare Entscheidungen:** Rundung, Mengen, Reservierungen und Build-or-Buy bleiben für Benutzer und Tests nachvollziehbar.
- **Erweiterbarkeit ohne Vorwegnahme:** Ports für spätere ESI-/Marktdaten sind erlaubt; Zukunftsfunktionen werden im MVP nicht implementiert.
- **Fehler sichtbar statt verschluckt:** Kein `try?` für fachlich relevante Speicher- oder Importvorgänge im Zielzustand.

## 8. Qualitätsziele

- fachlich korrekte Mengen- und Rundungsregeln,
- reproduzierbare Ergebnisse für T1, T2 und Reaktionen,
- Datenintegrität bei Import, Reservierung, Migration und Wiederherstellung,
- robuste Behandlung zyklischer oder unvollständiger Rezeptdaten,
- gute Testbarkeit ohne Netzwerk oder Benutzerkonto,
- verständliche Fehlerdiagnose und datenschutzgerechtes Logging,
- flüssige Bedienung auch bei größeren Produktionsgraphen,
- barrierearme, konsistente macOS-Oberfläche,
- lückenlose Fortschritts- und Abschlussdokumentation.

## 9. Quellen und Priorität

1. Der am 2026-07-23 festgelegte reduzierte MVP ist für den aktuellen Umfang verbindlich.
2. `Projektbuch.docx` liefert Vision, Fachkonzepte und langfristige Architektur.
3. Der tatsächliche Quellcode und verifizierte Build-/Testnachweise bestimmen den Implementierungsstatus.
4. Bei Widerspruch zwischen umfassendem Projektbuch und reduziertem MVP gilt der reduzierte MVP.
