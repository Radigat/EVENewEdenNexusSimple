# SSO-Architektur

Stand: 2026-07-27 · P38/P51

> Betriebsbefund P52: Der erste PKCE-Codeaustausch funktioniert, der
> Refreshpfad ist jedoch bis OFF-040 nicht betriebsfreigegeben. Der bisherige
> Form-Encoder schützt ein literales `+` im Refresh-Token nicht als `%2B`;
> der reale CCP-Endpunkt antwortet deshalb mit HTTP 400. Die automatisierten
> Refresh-Tests verwendeten bislang kein Token mit reservierten Zeichen.

## Zweck und Grenze

P38 stellt einen lokal betriebenen EVE-SSO-Adapter bereit. Er verbindet,
aktualisiert und trennt Charakterkonten, führt aber keine ESI-Fachdatenabfrage
aus. Assets, Blueprints und Industry Jobs bleiben P39/P40.

Geprüfte offizielle Grundlage:

- [CCP EVE SSO](https://developers.eveonline.com/docs/services/sso/)
- [OAuth-Discovery](https://login.eveonline.com/.well-known/oauth-authorization-server)

Desktop-Clients verwenden Authorization Code mit PKCE und speichern kein
Client Secret. Redirect-URI, `state`, Signatur und Claims werden validiert.

## Schichten und Ports

```text
AccountsView / SynchronizationView
        │
        ▼
AccountsViewModel
        │ EVEAccountConnectionManaging
        ▼
EVEAccountConnectionService
   ├── EVEAuthorizationFlow
   ├── EVERefreshTokenVault
   └── EVECharacterAccountRepository
        │
        ├── EVESSOAuthorizationFlow
        │     ├── URLSession + OIDC Discovery/JWKS
        │     ├── LoopbackOAuthCallbackReceiver (Network)
        │     ├── EVEJWTAccessTokenValidator (Security)
        │     └── SystemAuthorizationURLLauncher (AppKit)
        ├── KeychainRefreshTokenVault
        └── SwiftDataCharacterAccountRepository
```

Application enthält nur Verträge, Use-Case und transportneutrale Modelle.
OS-Frameworks liegen in Infrastructure; SwiftData liegt in Persistence.
Views greifen weder direkt auf SwiftData noch auf den Keychain zu.

## Autorisierungsablauf

1. OIDC-Metadaten werden ausschließlich über HTTPS geladen und kurz
   zwischengespeichert.
2. Die App erzeugt kryptografisch zufälligen `state` und PKCE-Verifier;
   übertragen wird nur die S256-Challenge.
3. Der Listener auf `127.0.0.1:52721` wird vor dem Browser vorbereitet und
   akzeptiert ausschließlich den exakten Pfad `/callback`.
4. Callback, `state`, Ablehnung, Timeout und Abbruch besitzen eindeutige
   Terminalzustände. Die Requestgröße ist auf 16 KiB begrenzt.
5. Der Code wird ohne Client Secret gegen den entdeckten Tokenendpunkt
   getauscht.
6. Das Access-Token wird gegen den aktuell entdeckten JWKS-Schlüssel
   kryptografisch geprüft.
7. Erst danach werden Konto und Refresh-Token gespeichert.

## JWT- und Scope-Prüfung

Akzeptiert werden ausschließlich:

- `RS256` mit bekanntem `kid` und gültiger RSA-Signatur,
- erwarteter Issuer aus Discovery,
- Audience `EVE Online` sowie die konfigurierte Client-ID,
- gültiges `exp` und noch nicht aktives `nbf` wird abgelehnt,
- Subject im Format `CHARACTER:EVE:<positive ID>`,
- nichtleerer Charaktername,
- alle zentral konfigurierten minimalen Scopes.

Der offizielle JWKS darf Schlüssel unterschiedlicher Algorithmen enthalten.
Algorithmusspezifische Felder werden deshalb pro Eintrag optional dekodiert.
Ein unpassender EC-/ES256-Schlüssel verwirft nicht den gesamten
Schlüsselsatz; für das Access-Token wird weiterhin ausschließlich der zum
JWT-Header passende RSA-/RS256-Schlüssel ausgewählt. Ein Token mit einem
nicht unterstützten Signaturalgorithmus wird weiterhin abgelehnt.

Die Autorisierung ist zweckgebunden:

- P40 fordert exakt Assets, Blueprints und persönliche Industry Jobs,
- P42 ergänzt den Walletscope erst nach eigener Erklärung und ausdrücklicher
  Neuautorisierung desselben Charakters,
- ein vorhandener Snapshot ist kein Nachweis einer erteilten Berechtigung,
- ein abgebrochener oder abgelehnter Erweiterungsdialog verändert Konto,
  Token, Snapshots und Zuordnungen nicht.

Die App speichert nur die tatsächlich angeforderte normalisierte Scopeliste,
nicht zusätzliche Tokenclaims. Corporation- und Schreibscopes sind nicht
enthalten.

## Token- und Datenlebenszyklus

- Refresh-Token liegen ausschließlich im macOS-Keychain mit
  `AfterFirstUnlockThisDeviceOnly`.
- Access-Token werden nicht persistent gespeichert.
- Nicht geheime Scopemetadaten liegen getrennt in SwiftData-Schema v24. Eine
  Migration erfindet für alte Konten keine Zustimmung.
- Bei Tokenrotation ersetzt der neue Refresh-Token den alten; fehlt eine
  Rotation, bleibt der alte gültig.
- Ein Refresh darf die verknüpfte Charakteridentität nicht wechseln.
- Trennen erfordert eine sichtbare Bestätigung und entfernt Konto,
  Scopemetadaten, Refresh-Token sowie charakterbezogene ESI-Snapshots und
  bestätigte Zuordnungen. Projekte, manuelle Bestände und Preise bleiben
  erhalten.
- Scheitert SwiftData nach einer Keychain-Mutation, stellt der
  Application-Service den vorherigen Tokenzustand wieder her.

## Lokale Signierung und Keychain-Identität

Keychain-Zugriffe hängen unter macOS an der Code-Identität der App. Ein
reiner „Sign to Run Locally“-Build kann eine buildabhängige ad-hoc-
Designated-Requirement besitzen und darf deshalb nicht als dauerhafte
Identität für Refresh-Token verwendet werden.

`Scripts/configure_local_signing.sh` ermittelt die lokale
Apple-Development-Identität und schreibt ausschließlich
`XcodeSupport/LocalSigning.xcconfig`. Diese Datei ist git-ignoriert und
enthält die persönlichen Team-/Zertifikatswerte; ohne sie bleiben
CLI-/CI-Builds unsigniert. Der bestehende Alt-Token wird nicht automatisch
gelöscht. In der Abschlussabnahme wurden zwei verwaiste Alt-Tokens einzeln
vorgeprüft, ausdrücklich freigegeben und entfernt; die anschließende
Dienstkontrolle fand keinen Restbestand. OFF-033 ist geschlossen.

## Protokollierung und Fehler

Token, Authorization Code, PKCE-Verifier, `state` und ungefilterte
Antwortkörper werden nicht protokolliert. Die UI zeigt benutzbare, redigierte
Fehler- und Wiederanmeldezustände. Netzwerkausfall oder Abbruch verändern
keine vorhandene lokale Kontoverknüpfung.

## Abnahmegrenze

Automatisiert geprüft sind PKCE/State, Discovery, Tokenrequest,
JWT-Signatur/Claims/Scopes, exakt drei/vier Zweckscopes, abgebrochene und
erfolgreiche Neuautorisierung, Refreshrotation, Schema-v24-Persistenz,
Trennbestätigung, Kompensation, Vault-Fehlerzuordnung und
View-Schichtengrenzen. Der stabil
signierte Build, der vom Projekteigentümer bestätigte Realablauf sowie die
kontrollierte Alt-Token-Bereinigung sind abgeschlossen. P38 ist `✅`;
der produktive P40/P42-Eigentümerlauf folgt separat in P52.
