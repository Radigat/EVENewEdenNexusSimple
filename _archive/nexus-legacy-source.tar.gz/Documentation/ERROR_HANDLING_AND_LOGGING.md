# Fehlerbehandlung und Logging

Stand: 2026-07-26 · P04-Grundlage, erweitert durch P33

## 1. Ziel und Geltungsbereich

P04 stellt eine zentrale, UI-unabhängig testbare Fehlertaxonomie und einen datenschutzgerechten Diagnosepfad bereit. Sie gilt für App-Start, lokale Schreibvorgänge, Backup/Restore, SDE-Prüfung/-Staging/-Mapping/-Aktivierung, Katalogabfragen und den bereits vorhandenen Account-Zukunftscode.

Nicht enthalten sind Telemetrie, Cloudlogging, Logdateien, Diagnoseexport, ESI-Retry/Backoff und vollständige Lokalisierung.

## 2. Architekturfluss

```text
technischer Fehler
    │
    ▼
NexusFailureMapper (Application)
    ├──> NexusFailure ──> sichere UI-Darstellung
    └──> DiagnosticEvent ──> DiagnosticLogging
                                  │
                                  ▼
                         UnifiedDiagnosticLogger
                              (Infrastructure)
                                  │
                                  ▼
                            OSLog.Logger
```

Im App-Target hält `NexusAppRuntime` den Startzustand und den aktuell präsentierten Laufzeitfehler. Die Runtime erhält den Logger und die Containerfactory per Injection; es existiert kein globaler Logger-Singleton.

## 3. Fehlertaxonomie

| Operation | Diagnosecode | Kategorie | UI-Titel |
|---|---|---|---|
| `applicationStartup` | `NEN-PER-001` | lifecycle | Lokale Datenbank nicht verfügbar |
| `projectSave` | `NEN-PER-002` | projects | Projekt nicht gespeichert |
| `characterSave` | `NEN-PER-003` | persistence | Charakter nicht gespeichert |
| `characterDelete` | `NEN-PER-004` | persistence | Charakter nicht entfernt |
| `synchronizationStateSave` | `NEN-PER-005` | synchronization | Status nicht gespeichert |
| `authentication` | `NEN-AUTH-001` | authentication | Verbindung fehlgeschlagen |
| `keychainDelete` | `NEN-AUTH-002` | authentication | Zugangsdaten nicht entfernt |
| `backupCreate` | `NEN-BACKUP-001` | backup | Backup nicht erstellt |
| `backupInspect` | `NEN-BACKUP-002` | backup | Backup nicht geprüft |
| `backupRestore` | `NEN-BACKUP-003` | backup | Wiederherstellung fehlgeschlagen |
| `sdeInspect` | `NEN-SDE-001` | staticData | SDE-Daten nicht geprüft |
| `sdeStage` | `NEN-SDE-002` | staticData | SDE-Paket nicht erstellt |
| `sdeMap` | `NEN-SDE-003` | staticData | SDE-Felder oder Referenzen nicht verwendbar |
| `sdeActivate` | `NEN-SDE-004` | staticData | geprüfter Stand nicht aktiviert |
| `catalogQuery` | `NEN-SDE-005` | staticData | Katalogabfrage fehlgeschlagen |
| `sdeMetadataCheck` | `NEN-SDE-006` | staticData | SDE-Aktualität nicht geprüft |
| `sdeInstallation` | `NEN-SDE-007` | staticData | SDE-Archiv nicht installiert |
| `unexpected` | `NEN-GEN-001` | general | Unerwarteter Fehler |

Jedes `NexusFailure` besitzt:

- eine zufällige Korrelations-ID,
- stabilen Diagnosecode,
- Operation, Kategorie und Level,
- sicheren Titel,
- verständliche Beschreibung,
- konkrete Handlungsempfehlung,
- ausschließlich für die Diagnose den Typnamen des technischen Fehlers.

`NexusFailureMapper` übernimmt weder `localizedDescription` noch andere Instanztexte des ursprünglichen Fehlers. Damit gelangen Serverantworten, Pfade, Tokens, Namen oder Notizen nicht über diesen Weg in UI oder Logs.

## 4. Diagnoseereignis

`DiagnosticEvent` enthält:

- `level`,
- `category`,
- festen Ereignisnamen,
- Diagnosecode,
- Operation,
- Korrelations-ID,
- typisierte Metadaten.

Metadaten werden alphabetisch sortiert ausgegeben. Zeilenumbrüche öffentlicher Werte werden neutralisiert.

### Level

- `info`: erwartete technische Zustandsinformation,
- `warning`: eingeschränkter, aber fortsetzbarer Zustand,
- `error`: fehlgeschlagene Operation mit Benutzer- oder Datenwirkung.

### Kategorien

- `lifecycle`,
- `persistence`,
- `projects`,
- `authentication`,
- `backup`,
- `staticData`,
- `synchronization`,
- `general`.

Der konkrete Logger verwendet diese Kategorien zugleich als Unified-Logging-Kategorie.

## 5. Redaktionsregeln

`DiagnosticValue` zwingt den Aufrufer zur Wahl zwischen:

- `.publicValue`: nur für ausdrücklich sichere technische Werte,
- `.privateValue`: Klartext wird in der Logdarstellung immer durch `<redacted>` ersetzt.

Nie als öffentlich markieren:

- Access-/Refresh-Tokens,
- Passwörter, Client Secrets, Authorization Codes oder PKCE-Verifier,
- Serverantworten und ungefilterte Fehlermeldungen,
- Charakter-, Projekt- oder Itemnamen,
- Notizen und andere Freitexte,
- vollständige lokale Pfade,
- personenbezogene Daten.

Aktuell erzeugte Fehlerereignisse enthalten nur den stabilen Fehler-Typnamen als öffentliche Metadaten. Ein automatisierter Secret-Sentinel-Test belegt, dass die ursprüngliche Fehlerbeschreibung nicht in UI- oder Diagnoseausgaben gelangt. Ein separater Redaction-Test belegt `<redacted>` und die Abwesenheit des privaten Klartexts.

## 6. App-Start

`NexusAppRuntime.StartupState` besitzt:

- `loading`,
- `ready(ModelContainer)`,
- `failed(NexusFailure)`.

Der Start verwendet weiterhin ausschließlich `NexusModelContainerFactory.makeDefault()`. Bei einem Fehler:

1. wird ein sicherer Fehler erzeugt,
2. genau ein Diagnoseereignis geschrieben,
3. eine eigene Startfehleransicht angezeigt,
4. der Benutzer kann das Öffnen erneut versuchen.

Es gibt keinen `fatalError`, keinen Store-Reset und keinen Leerstore-Fallback.

## 7. Laufzeitfehler und Datenintegrität

Die aktuellen SwiftData-Schreibpfade verwenden `do/catch`:

- Projektanlage,
- Charakteranlage/-änderung,
- Charakterlöschung,
- simulierte Synchronisationsstatusänderung.

Bei einem Speicherfehler:

1. wird `modelContext.rollback()` ausgeführt,
2. der Fehler wird an `NexusAppRuntime` gemeldet,
3. genau ein redigiertes Diagnoseereignis geschrieben,
4. der globale Alert zeigt sicheren Text und Diagnosecode.

Die Projektanlage schließt ihr Sheet nur nach erfolgreichem Speichern.

Bestehende Keychain-Werte werden mit `SecItemUpdate` aktualisiert, statt den alten Wert vorab zu löschen. Keychain-Löschung behandelt `errSecItemNotFound` als idempotenten Erfolg. Andere OSStatus-Werte werden als `KeychainStoreError` geworfen und zentral gemeldet. SwiftData und Keychain bilden keine gemeinsame Transaktion; diese bestehende Grenze bleibt für die spätere SSO-Härtung in `OFFEN.md` sichtbar.

## 8. Benutzeroberfläche

Die Startfehleransicht verwendet `ContentUnavailableView` mit:

- verständlichem Titel,
- sicherer Erklärung,
- Wiederherstellungsempfehlung,
- Diagnosecode,
- Standardbutton „Erneut versuchen“ mit Default-Tastaturaktion.

Laufzeitfehler erscheinen über einen zentralen Alert am Root-View. Rohfehler werden nicht dargestellt.

## 9. Testnachweise

Automatisiert geprüft werden:

- Mapping aller 13 Operationen,
- stabile Codes, Kategorien und Error-Level,
- keine Secret-Sentinel-Übernahme aus `LocalizedError`,
- Redaction privater Metadaten,
- sortierte Metadaten und neutralisierte Zeilenumbrüche,
- Startfehler ohne Absturz,
- erfolgreicher Retry mit In-Memory-Store,
- genau ein Diagnoseereignis je Runtime-Fehler,
- Präsentieren und Schließen eines Laufzeitfehlers,
- Abwesenheit von `fatalError` und `try? modelContext.save()` im produktiven App-Target,
- Importgrenzen von Domain, Application, Infrastructure und Persistence,
- vollständige P02-/P03-Regression.

Die SDE-Adapterfehler enthalten Datensatzart und Zeilennummer nur als typisierte interne Werte. Der zentrale Mapper übernimmt keinen JSON-Inhalt oder vollständigen lokalen Pfad in UI oder Diagnose. Backup-, SDE- und Katalogoperationen besitzen stabile, getrennte Codes.

## 10. Erweiterungsregeln

Neue Fehlerpfade müssen:

1. eine passende `NexusOperation` oder eine begründete neue Operation verwenden,
2. einen stabilen Diagnosecode erhalten,
3. sichere UI-Texte definieren,
4. niemals Raw-Fehlertexte anzeigen,
5. genau einmal zentral gemeldet werden,
6. private Metadaten ausdrücklich redigieren,
7. einen Fehlerpfadtest erhalten,
8. in `Documentation/OFFEN.md` auf verbleibende Grenzen geprüft werden.

## 11. P33 – Validierung und kontrollierter Retry

P33 ergänzt `NexusValidationIssue` mit stabilen Codes:

| Code | Bedeutung |
|---|---|
| `NEN-VAL-001` | Pflichttext fehlt |
| `NEN-VAL-002` | Auswahl fehlt |
| `NEN-VAL-003` | Ganzzahl oder Mengenbereich ungültig |
| `NEN-VAL-004` | ISK-Betrag ungültig |
| `NEN-VAL-005` | Datumsbereich ungültig |
| `NEN-VAL-006` | Auswahl oder Vorschau veraltet |

Die Factorys übernehmen keinen eingegebenen Rohwert. Projekt-, Lager-,
Bestands-, Preisprofil-, Preis- und Einkaufsformulare verwenden die gemeinsame
SwiftUI-Zusammenfassung; die fachlichen Services validieren weiterhin erneut
vor jedem Schreiben.

`NexusOperation.userRetryPolicy` erlaubt einen Runtime-Retry ausschließlich
für eine geschlossene Liste idempotenter Lese-, Inspect- und
Previewoperationen. Die Runtime entfernt Fehler und Closure vor der Ausführung.
Schreib-, Apply-, Restore-, Aktivierungs- und Löschoperationen verwerfen einen
übergebenen Retry. Automatische Wiederholungsschleifen wurden nicht eingeführt.

Nachweis: [ADR-0038](Architecture/ADRs/ADR-0038_Sichere-Validierung-und-kontrollierter-UI-Retry.md)
und [P33-Bericht](Progress/Reports/2026-07-26_P33_Appweite-Validierung-und-Fehler-UX.md).
