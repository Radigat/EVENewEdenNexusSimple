# T2-Berechnung

Stand: 2026-07-24 · P17 · Graphformat 5

## Zweck und Grenze

P17 erweitert den rekursiven Manufacturing-Graphen um deterministische
Tech-II-Stufen. Eine Fertigungsstufe gilt genau dann als Tech II, wenn der
aktive SDE-Katalog ihren Fertigungs-Blueprint als eindeutiges Produkt einer
Invention-Aktivität ausweist und der Ausgangs-Blueprint selbst eine
Manufacturing-Aktivität besitzt. Reverse Engineering/T3 wird dadurch
typisiert abgelehnt und weder als T2 noch als T1 umgedeutet. Namen,
Gruppenbezeichnungen und numerische ID-Bereiche werden nicht als
Ersatzklassifikation verwendet.

P17 plant die Qualität benötigter T2-BPCs und die Anzahl erfolgreicher
Kopien. Es simuliert keine Zufallsergebnisse und berechnet weder erwartete
Fehlversuche noch Invention-Kosten. P18 löst notwendige Reaktionen
rekursiv auf; P19 aggregiert die daraus entstehenden Endmaterialblätter.

## Daten- und Regelquellen

Aus dem vorhandenen, versionierten SDE-Katalog stammen:

- T1-Ausgangs-Blueprint,
- T2-Fertigungs-Blueprint als Invention-Produkt,
- Grundruns des Invention-Produkts,
- produktspezifische Basiswahrscheinlichkeit,
- verbrauchte Invention-Materialien/Datacores,
- T1-/T2-Manufacturing-Rezepte.

Aus `IndustryRuleSet` Version 1 stammen:

- Basisqualität eines regulär erfundenen BPC: ME 2 / TE 4,
- die acht aktuellen Decryptor-Modifikatoren samt stabilen
  CCP-Type-IDs 34201 bis 34208,
- zulässige Blueprint-Herkünfte,
- Prüfdatum und offizielle CCP-Quellen.

Der Regelvertrag wird an SDE-Build und Inhaltshash gebunden. Ein
Versionswechsel während der Berechnung bricht ab.

## Standardplanung

Automatisch erkannte T2-Stufen verwenden:

```text
Herkunft = inventedBPC
Art = copy
Decryptor = keiner
ME = 2
TE = 4
lizenzierte Runs je Kopie = SDE-Grundruns
```

Benötigte erfolgreiche Kopien werden rein ganzzahlig berechnet:

```text
ceil(benötigte Manufacturing-Runs / lizenzierte Runs je Kopie)
```

Die Basiswahrscheinlichkeit wird sichtbar gespeichert, aber nicht in eine
behauptete Zahl garantierter oder erwarteter Versuche umgerechnet.

## Überschreibungen und historische T2-BPOs

`T2StagePlanningPolicy` erlaubt stufenbezogene Decryptor- oder
Qualitätsüberschreibungen anhand der stabilen Blueprint-Type-ID.
Historische T2-BPOs:

- tragen Herkunft `legacyT2BPO`,
- sind `original`,
- besitzen keine begrenzten lizenzierten Runs,
- verwenden ME `0...10` und TE `0...20`,
- werden nicht als reguläres Invention-Ergebnis validiert.

Die API stellt diese Ausnahme dar; P17 führt keine persönliche
Blueprintbibliothek oder ESI-Synchronisation ein.

## Materialberechnung

Jede T1- oder T2-Stufe verwendet unverändert die P14-/P15-Formeln. Der
ME-Wert stammt aus der Qualität genau dieser Stufe. Damit können Ziel,
T2-Zwischenprodukt und T1-Zwischenprodukt unterschiedliche Qualitäten
tragen.

Basismenge eins je Run bleibt geschützt:

```text
wenn Basismenge == 1:
    Effektivbedarf = Basismenge × Runs
```

## Graphformat 5

Jeder Rezeptknoten speichert zusätzlich:

- Tech-Stufe,
- Blueprint-Herkunft und BPO/BPC-Art,
- ME, TE und lizenzierte Runs je Kopie,
- optionalen Decryptor,
- Regel- und SDE-Provenienz,
- bei regulärer Invention Ausgangs-Blueprint, Basiswahrscheinlichkeit,
  Grundruns, Runs je Kopie, erfolgreiche Kopien und Material-Type-IDs.

Expansionsrichtlinie 2 klassifiziert jede Manufacturing-Stufe unabhängig.
Graphformate 1 bis 4 bleiben lesbar und gelten als veraltet. Die Daten
liegen im vorhandenen codierten Payload des SwiftData-Schemas v8; P17
benötigt keine neue Datenbankspalte und keine Backupformatänderung.

## Fail-closed-Fälle

Ohne Speichern abbrechen:

- mehr als eine Invention-Quelle,
- Invention aus einem nicht fertigbaren Ausgangs-Blueprint
  (Reverse Engineering/T3 außerhalb des P17-Umfangs),
- ungelöste Invention-Referenzen,
- fehlende oder ungültige Basiswahrscheinlichkeit,
- Grundruns kleiner oder gleich null,
- ungültige Herkunfts-/BPO-/BPC-Kombination,
- unvollständiger oder veralteter Decryptorvertrag,
- Katalog- oder Regelversionswechsel,
- vorhandene Zyklus-, Tiefen-, Knoten-, Overflow- und
  Cancellationfehler.

Ein vorhandener Graph bleibt in allen Fehlerfällen erhalten.

## Real-SDE-Nachweis

Der isolierte Abnahmelauf für offiziellen Build `3444265` bestätigte:

- Inhaltshash
  `3395237055dee03879fe26c12203b6dae235609864d8f0d3dfc132048941d23a`,
- Blueprint `691` erfindet T2-Blueprint `11372`,
- Grundrun `1`,
- Basiswahrscheinlichkeit `0,3`,
- Datacores `20172` und `20424`,
- Wiederöffnung, Aktivbuild, Referenzaudit, Backup und Cleanup erfolgreich.

## Offizielle Quellen

- [CCP – Invention](https://support.eveonline.com/hc/en-us/articles/203210642-Invention)
- [CCP – Decryptors](https://support.eveonline.com/hc/en-us/articles/203270631-Decryptors)
- [CCP – Blueprints](https://support.eveonline.com/hc/en-us/articles/203269951-Blueprints)
- [CCP – Static Data](https://developers.eveonline.com/docs/services/static-data/)
- [CCP ESI – Accelerant Decryptor, Type 34201](https://esi.evetech.net/latest/universe/types/34201/)
- [CCP ESI – Optimized Augmentation Decryptor, Type 34208](https://esi.evetech.net/latest/universe/types/34208/)
