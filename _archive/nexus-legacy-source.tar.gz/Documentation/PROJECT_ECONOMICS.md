# Projektwirtschaftlichkeit

> Historischer P29-Stand: Diese Gewinn-/ROI-Oberfläche ist seit P55 nicht
> mehr sichtbar angebunden. Daten und Berechnungscode bleiben erhalten.
> Die aktuelle Planungsoberfläche ist in
> [PROJECT_BUDGET.md](PROJECT_BUDGET.md) dokumentiert.

Stand: 2026-07-26 · P29

## Zweck und Datenquellen

P29 verbindet den aktuellen Build-or-Buy-Plan mit einem lokalen Preissatz.
Gespeichert werden je Projekt nur der ausgewählte Preissatz und die
manuellen Jobkosten. Ergebnisse werden immer neu aus Plan, Lagerabzug und
zum Stichtag gültigen Preisen berechnet.

| Wert | Quelle |
|---|---|
| Materialmengen | aktueller P26-/P32-Plan |
| Lageranteil | bereits im Plan verrechnete P22–P24-Verfügbarkeit |
| Einheitspreise | ausgewählter P27-/P28-Preissatz |
| Zielproduktpreis | Preis des Zielprodukts im selben Profil |
| Jobkosten | manuelle Projekteingabe |
| Ergebniskennzahlen | reine P29-Domainberechnung |

Fehlende Preise werden einzeln angezeigt. Eine Teilberechnung mit
stillschweigenden Nullpreisen findet nicht statt.

## Kostenansichten

- **Cash-Materialkosten:** Preis nur der noch fehlenden Menge.
- **Wirtschaftliche Materialkosten:** Preis der gesamten eingesetzten Menge,
  einschließlich vorhandenen Lagerbestands.
- **Manuelle Jobkosten:** zusammengefasste zusätzliche ISK-Kosten für
  Produktion, Reaktion, Invention oder andere Jobs.
- **Cash-Gesamtkosten:** Cash-Materialkosten plus Jobkosten.
- **Wirtschaftliche Gesamtkosten:** wirtschaftliche Materialkosten plus
  Jobkosten; zugleich das in P29 eingesetzte Kapital.

Gekaufte Zwischenprodukte und Inventionsmaterialien sind normale
Bedarfszeilen. Für Invention werden die bereits durch P17/P26 ausgewiesenen
erfolgreichen Kopien bewertet; P29 erfindet keine Fehlversuchsquote.

## Formeln

```text
Erlös = Zielmenge × Zielproduktpreis
Gewinn = Erlös − wirtschaftliche Gesamtkosten
Marge = Gewinn ÷ Erlös × 100
ROI = Gewinn ÷ wirtschaftliche Gesamtkosten × 100
Break-even gesamt = wirtschaftliche Gesamtkosten
Break-even je Einheit = ceil(Break-even gesamt ÷ Zielmenge)
```

Geldwerte sind ganzzahlige ISK-Hundertstel. Marge und ROI werden auf
0,01 Prozentpunkte gerundet. ROI ist bei 0 ISK Kapital nicht definiert.
Negative Gewinne, Margen und ROI bleiben sichtbar. Break-even je Einheit
wird auf das nächste Hundertstel aufgerundet.

## Vorschau und Speicherung

Änderungen an Preissatz oder Jobkosten machen die Vorschau sichtbar
veraltet. Erst „Kennzahlen berechnen“ erzeugt einen neuen Stand. „Basis
speichern“ verlangt eine ausdrückliche Bestätigung. Vor dem Schreiben
werden Profil und Preise erneut gelesen; ein geänderter Preisstand verwirft
die Vorschau. Optimistic Locking schützt die gespeicherte Konfiguration.

Schema v18 ergänzt dafür genau einen
`ProjectEconomicsConfigurationRecord` je Projekt. Die leichte
v17→v18-Migration erfindet keine Konfigurationen.

## Bewusste Grenzen

Nicht enthalten sind Live-Märkte, Wallet, reale Transaktionen,
Brokergebühren, Steuern, Transport, System Cost Index, Budgets,
realisierte Gewinne, zeitbezogene Slotkennzahlen und Einkaufsstatus.
Diese Werte dürfen nicht als implizite Nullwerte missverstanden werden.
