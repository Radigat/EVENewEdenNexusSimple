# Verfügbarkeit und Ausschlüsse

Stand: 2026-07-24 · P22 umgesetzt und reviewed

## Zweck und Abgrenzung

P22 gleicht die Type-ID-basiert aggregierten Endmaterialbedarfe eines
aktuellen Produktionsgraphen mit den lokalen Beständen aus P20/P21 ab.
Das Ergebnis ist der physische Bestand nach Lager-, Material- und
Mengenfreigaben.

Dieser Wert ist noch nicht der endgültig frei verfügbare Bestand:
Sicherheitsbestände und Reservierungen folgen erst in P23 bis P25.
P22 trifft keine Build-or-Buy-Entscheidung und erzeugt keine Einkaufsliste.

## Freigabemodi

Eine projektbezogene Konfiguration verwendet genau einen Modus:

- alle aktiven Lager,
- nur ausgewählte aktive Lager,
- Bestand vollständig ignorieren.

Archivierte Lager bleiben in jedem Modus ausgeschlossen. Materialregeln
können einen Type vollständig ausschließen oder seine maximal verwendbare
Menge begrenzen. Beides gleichzeitig ist nicht zulässig. Lager- und
Type-IDs sowie Obergrenzen werden kanonisch sortiert gespeichert.

## Berechnungsreihenfolge

Für jeden Bruttobedarf wird die folgende Reihenfolge überlaufgeprüft mit
`Int64` ausgewertet:

1. physischen Bestand über alle Lager summieren,
2. archivierte Lager ausschließen,
3. Freigabemodus beziehungsweise Lagerauswahl anwenden,
4. Materialausschluss anwenden,
5. optionale Mengenobergrenze anwenden,
6. verwendbare Menge auf den Bedarf begrenzen,
7. ungedeckte Menge bestimmen.

Jede Menge wird nur dem ersten zutreffenden Ausschlussgrund zugerechnet.
Die Detailvorschau weist gespeicherten Bestand, jeden Ausschluss, die
einbeziehbare, verwendbare und ungedeckte Menge getrennt aus.

## Vorschau- und Schreibgrenze

Das Ändern einer Regel erzeugt nur einen Entwurf. Eine neue Vorschau liest
Projekt, Graph, Lager, Bestände und gespeicherte Konfiguration erneut und
schreibt nichts.

Das Speichern benötigt eine ausdrückliche Bestätigung. Projekt-, Graph-,
Lager-, Bestands- und Konfigurationsversion müssen noch genau der Vorschau
entsprechen. Andernfalls wird der Vorgang abgelehnt und eine neue Vorschau
verlangt. Nur die Konfiguration wird persistiert; berechnete Mengen werden
nicht als veraltbarer Cache gespeichert.

## Persistenz

Schema v12 ergänzt je Projekt höchstens einen
`InventoryAvailabilityConfigurationRecord` mit Modus, Lagerauswahl,
Materialausschlüssen, Obergrenzen, Zeitstempeln und Recordversion.
Die Migration v11→v12 ist additiv und erzeugt keine geratenen Regeln.
Ohne Datensatz gilt der Standard „alle aktiven Lager“ ohne weitere
Ausschlüsse.

Backupformat 12.0.0 akzeptiert die Vorgänger 1.0.0 bis 12.0.0. Ein
zukünftiges 13.0.0 wird abgelehnt.

## Schichtenzuordnung

- Domain: validierte Konfiguration, Ergebniszeilen und deterministischer
  Rechner,
- Application: Laden, Preview-before-write, Bestätigung und
  Stale-State-Schutz,
- Persistence: SwiftData-Roundtrip und optimistische atomare Speicherung,
- Presentation: ViewModel und native SwiftUI-Sheet im Graphworkflow.

Die UI enthält keine SwiftData-Zugriffe und keine Mengenfachlogik.

## Nachweise

- Domain-, Service-, Persistenz-, Migrations-, Backup- und
  Architekturtests,
- additive v11→v12-Migration mit befülltem Bestand, zweiter Öffnung und
  leerem v12-Store,
- vollständige SwiftPM- und Xcode-Abnahme in Debug und Release mit jeweils
  371 Tests ohne Fehler oder übersprungene Tests,
- [ADR-0027](Architecture/ADRs/ADR-0027_Projektbezogene-Verfuegbarkeit-und-Schema-v12.md).
