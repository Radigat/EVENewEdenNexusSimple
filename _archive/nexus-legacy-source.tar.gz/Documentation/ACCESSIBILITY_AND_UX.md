# Accessibility und UX

Stand: 2026-07-26 · P35

## Verbindlicher MVP-Umfang

Die aktuelle App-Oberfläche ist deutschsprachig. EVE-Eigennamen und
Fachbegriffe werden nicht künstlich übersetzt. Weitere UI-Sprachen und
zusätzliche SDE-Übersetzungsdaten benötigen einen belegten Produktbedarf.

## Bedienprinzipien

- Standard-Steuerelemente und semantische Systemfarben verwenden.
- Information nie ausschließlich durch Farbe vermitteln.
- Symbole, Metriken, Status und Fortschritt verständlich beschriften.
- Formulare in fachlicher Reihenfolge fokussieren.
- Aktionen über sichtbaren Text und vorhandene Tastaturkürzel erreichbar
  halten.
- Empty-, Loading-, Error-, Offline- und Abbruchzustände explizit anzeigen.
- Hauptinhalte bei schmalen Fenstern stapeln und bei breiten Fenstern
  nebeneinander darstellen.

## Aktuelle Umsetzung

- Die Sidebar-Suche filtert Module anhand deutscher Begriffe und
  EVE-Terminologie; Groß-/Kleinschreibung und Diakritika sind tolerant.
- Dashboardmetriken verwenden ein adaptives Raster.
- Produktionsworkspace und Einkauf wechseln mit `ViewThatFits` zwischen
  horizontaler und vertikaler Anordnung.
- Der SDE-Bereich stapelt Aktionen, Kontakt und Logfilter bei Platzmangel.
- Der Projekteditor führt den Fokus von Projektname über Zielsuche zur
  Zielmenge.
- Akzent, Teal und Warnung folgen den adaptiven macOS-Systemfarben.
- Metriken, Projektzeilen und SDE-Status besitzen zusammengefasste
  Accessibility-Texte.

## Prüfgrößen

- schmaler Kernworkspace: 760 × 760 im vorhandenen Renderer-Test,
- breiter Kernworkspace: 1.200 × 900,
- minimales reales Hauptfenster: 780 × 560; die SwiftUI-Inhaltshöhe
  beträgt dafür 500 Punkte, da die macOS-Fensterleiste hinzukommt,
- Standardfenster: 1.280 × 800.

## Abnahmenachweis

Ein dauerhaftes Xcode-UI-Testtarget startet das echte App-Bundle mit einem
isolierten Store. Es prüft das reale Standardfenster 1.280 × 800 und das
reale Mindestfenster 780 × 560, den sicht- und zugänglichen Kernstatus, die
Sidebar-Suche, einen systemseitigen Accessibility-Audit und die
Tab-Fokusbewegung zwischen Sidebar und Suche. Deaktivierte, nicht
interaktive SwiftUI-/Touch-Bar-Strukturcontainer werden im Audit eng
begrenzt ausgenommen; produktive Elemente bleiben prüfpflichtig.

SwiftPM Debug bestand 518 Tests; Xcode Debug bestand 520 Tests einschließlich
der zwei UI-Tests. `OFF-030` ist geschlossen. Der native interaktive
Computer-Use-Kanal blieb technisch unbrauchbar; ein manueller VoiceOver-
Einmaltest wird daher nicht behauptet.

## Datenwirkung

P35 ändert weder Schema v20 noch Graphformat 7, SDE-Daten, Preisprofile,
Bestände, Reservierungen oder Projekte.
