# CSV-Bestandsimport

Stand: 2026-07-24 · P21 umgesetzt und reviewed

## Zweck und Scope

P21 importiert lokale Bestandsmengen kontrolliert in genau ein bereits
vorhandenes, aktives Lager. Der Ablauf ist bewusst zweistufig:

1. Datei, Format, Mapping, Katalogbezug und Konflikte werden ohne
   Schreibzugriff geprüft.
2. Erst eine ausdrückliche Bestätigung schreibt die sichtbaren Änderungen
   und den zeilengenauen Bericht atomar.

Lagerübergreifende Verfügbarkeit, Ausschlüsse, Sicherheitsbestände und
Reservierungen bleiben P22 bis P25.

## Unterstütztes Format

- reguläre lokale Datei bis 16 MiB,
- höchstens 100.000 Datenzeilen und 64 Spalten,
- UTF-8 einschließlich BOM, UTF-16 LE/BE mit BOM, Windows-1252 und
  ISO-8859-1,
- Komma, Semikolon oder Tabulator,
- CR, LF und CRLF, zitierte Felder, `""` und zitierte Zeilenumbrüche,
- erforderliche Zuordnung für Type-ID und Menge, optionale
  Itemname-Gegenprüfung,
- positive `Int64`-Mengen; Dezimalkomma oder -punkt nur mit ausschließlich
  nullwertigem Nachkommateil.

Mehrdeutige Trennzeichen, unvollständige Zuordnungen, Bruchteile,
Gruppierungszeichen, Null, negative Werte, Überläufe und beschädigte
Anführungszeichen werden nicht geraten.

## Vorschau und Konfliktregeln

Jede Zeile erhält eine stabile Dateizeilennummer und einen Status:

| Status | Bedeutung | Schreibwirkung |
|---|---|---|
| Hinzufügen | noch keine Position im Ziellager | neue Position |
| Unverändert | vorhandene und importierte Menge stimmen überein | keine |
| Konflikt | vorhandene Menge weicht ab | nur nach `Ersetzen`; sonst `Überspringen` |
| Fehler | Zeile ist fachlich oder syntaktisch ungültig | keine |

Doppelte Type-IDs innerhalb einer Datei werden vollständig als Fehler
markiert und nicht addiert. Type-ID, Veröffentlichungsstatus und optionaler
Name werden gegen den aktiven Katalog geprüft. Die Vorschau selbst verändert
weder Bestand noch Berichtshistorie.

## Schreib- und Wiederanlaufgrenze

Vor dem Commit werden Lager, jeder betroffene Altbestand und die
Katalogprovenienz erneut mit der Vorschau verglichen. Eine Änderung seit der
Vorschau führt zu `stalePreview`; der Benutzer muss neu prüfen.

`SwiftDataInventoryRepository.applyInventoryImport` validiert alle
Vorbedingungen zuerst und speichert anschließend alle Einfügungen,
Ersetzungen und den `InventoryImportRecord` mit einem einzigen
`ModelContext.save()`. Bei Fehler oder Cancellation wird zurückgerollt. Ein
Neustart sieht deshalb entweder den vollständigen Import samt Bericht oder
den vollständigen Altbestand.

## Datenschutz und Bericht

Gespeichert werden bereinigter Dateiname, SHA-256, Ziel-Lager,
Formatmetadaten, Zähler und zeilengenaue Resultate. Vollständige Rohdatei und
lokaler Dateipfad werden nicht persistiert oder protokolliert.

## Schichtenzuordnung

- `DelimitedInventoryCSVParser` und `LocalInventoryCSVFileReader`:
  Infrastructure,
- `InventoryCSVImportService` und Importverträge: Application,
- atomarer Commit und Bericht: Persistence,
- Workflowzustand und Darstellung: Presentation.

SwiftUI führt keine CSV-Fachlogik und keinen direkten SwiftData-Zugriff aus.

## Nachweise

- 18 zusätzliche Tests für Parser, Größen-/Zeilengrenzen, Formate,
  Fehlerzeilen, Konflikte, Bestätigung, Cancellation, Stale Preview,
  atomaren Commit, Bericht, Schema v11 und v10→v11-Migration,
- SwiftPM und Xcode Debug/Release jeweils 353 Tests ohne Fehler oder
  Überspringung,
- isolierter App-Start mit Schema-v11-Store und
  `PRAGMA integrity_check = ok`,
- [ADR-0026](Architecture/ADRs/ADR-0026_Sicherer-CSV-Bestandsimport-und-Schema-v11.md).
