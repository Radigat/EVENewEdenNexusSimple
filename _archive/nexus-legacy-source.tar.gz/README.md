# New Eden Nexus

New Eden Nexus ist eine native, lokale macOS-Anwendung für den
Produktionsplaner-MVP aus `Documentation/PROJECT_DESCRIPTION.md`. Der
aktuelle Stand enthält die modulare Swift-/SwiftUI-Grundlage, versionierte
SwiftData-Persistenz, den statischen EVE-Datenpfad und dessen sichere lokale
Verwaltung, einen deterministischen Fertigungs- und Reaktionsresolver sowie
den vollständigen lokalen Produktionsprojekt-Lebenszyklus. Lokale logische
Lager und kataloggebundene manuelle Bestandsmengen sind über `Assets` als
erste Bestandsgrundlage verfügbar.
Die technische P38-SSO-Härtung ist umgesetzt. Der stabil signierte reale
Login-/Neustart-/Refresh-/Trennen-Nachweis bleibt OFF-033; ESI-Fachdaten
beginnen erst danach in P39/P40.

Der verbindliche Betriebsweg ist derzeit die lokale Eigennutzung auf dem
Rechner des Projekteigentümers. Eine Veröffentlichung im Mac App Store oder
als direkt verteilte öffentliche macOS-App ist nicht Teil des MVP. Sie ist
als P48 nach allen übrigen Zukunftspaketen zuletzt optional eingeordnet und
wird nur auf ausdrücklichen Auftrag vorbereitet.

Die verbindliche Folgeplanung schließt zunächst P38/OFF-033 ab; danach
folgen P39/P40 für persönliche EVE-Daten. Markt, Finanzen und erweiterte
Industrie folgen abschnittsweise; kein Folgeprompt startet automatisch.

## Starten

Voraussetzung: macOS 14 oder neuer und eine Xcode-Version mit Swift 6.

Vor einem lokalen App-Lauf mit EVE-SSO den Anmeldeschlüsselbund in
„Schlüsselbundverwaltung“ entsperren und einmal ausführen:

```bash
Scripts/configure_local_signing.sh
```

Danach kann das gemeinsame App-Scheme in Xcode über
`NewEdenNexus.xcodeproj` auf **My Mac** gestartet werden. Die erzeugte
`XcodeSupport/LocalSigning.xcconfig` ist git-ignoriert und enthält nur die
lokale Signierkonfiguration.

Reproduzierbarer CLI-Build ohne Signing:

```bash
xcodebuild \
  -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus \
  -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/XcodeDerivedData \
  CODE_SIGNING_ALLOWED=NO \
  build
```

Alle im App-Scheme hinterlegten Xcode-Tests:

```bash
xcodebuild \
  -project NewEdenNexus.xcodeproj \
  -scheme NewEdenNexus \
  -configuration Debug \
  -destination 'platform=macOS,arch=arm64' \
  -derivedDataPath .build/XcodeDerivedData \
  CODE_SIGNING_ALLOWED=NO \
  test
```

Der weiterhin gleichwertige SwiftPM-Weg:

```bash
swift run NewEdenNexus
swift test
```

`swift run NewEdenNexus` ist ein unsignierter Entwicklungsweg und deshalb
nicht für dauerhafte Keychain-/SSO-Verknüpfungen vorgesehen.

Der produktive SwiftData-Store liegt app-spezifisch unter
`~/Library/Application Support/NewEdenNexus/NewEdenNexus.store`.
Ein vorhandener fremder `default.store` wird weder übernommen noch
verändert. Für kontrollierte Smoke-Tests steht ein ausschließlich
testbestimmter absoluter Storepfad zur Verfügung; Details:
[Storepfad und Startisolation](Documentation/STORE_LOCATION_AND_ISOLATION.md).

Der opt-in Runner `NewEdenNexusSDEAcceptance` darf gebaut, aber nur mit den
in seiner Dokumentation genannten Owner-, Kontakt- und Schema-Gates
ausgeführt werden.

## Xcode-Projekt regenerieren

Die vorhandenen Quellen unter `Sources/` und `Tests/` sind die einzige
Implementierung. `Package.swift` und `project.yml` beschreiben dieselben
Targets. Nach einer beabsichtigten Target- oder Dateistrukturänderung kann
das Projekt mit installiertem XcodeGen reproduziert und anschließend
statisch geprüft werden:

```bash
Scripts/generate_xcode_project.sh
Scripts/verify_xcode_project.py
```

Persönliche Xcode-Metadaten, `LocalSigning.xcconfig` und DerivedData sind
durch `.gitignore` ausgeschlossen. Die lokale Bundle-ID
`com.newedennexus.local.NewEdenNexus` ist nur ein nicht freigegebener
Entwicklungsplatzhalter; Signing- und Teamwerte sind nicht in versionierten
Projektdateien hinterlegt.

## EVE SSO konfigurieren

1. Im EVE Developer Portal eine Anwendung mit „Authentication & API Access“ registrieren.
2. Als Callback-URL exakt `http://localhost:52721/callback` eintragen.
3. Die öffentliche Client-ID ist zentral als lokale App-Konfiguration
   eingetragen und kann unter **New Eden Nexus → Einstellungen** geprüft
   werden.
4. Unter **Accounts** „Mit EVE Online verbinden“ wählen.

Die App startet für die Anmeldung kurzzeitig einen lokalen Listener auf Port `52721`, verwendet PKCE und speichert kein Client-Secret. Refresh-Tokens werden im macOS-Schlüsselbund abgelegt. Ein echter SSO-Durchlauf setzt eine eigene registrierte EVE-Anwendung voraus.

## Aktueller Umfang

- natives macOS-Fenster mit Sidebar, Dashboard und globaler Suche
- lokale Charakter- und Projektmodelle mit SwiftData
- EVE SSO PKCE inklusive State-Prüfung und Token-Austausch
- sichere Refresh-Token-Ablage im Schlüsselbund
- anlegbare Produktionsprojekte
- statischer Item-/Blueprintkatalog und lokale SDE-Verwaltung
- native deterministische Swift-Berechnungsgrundlage
- eigenständiges Xcode-Projekt und reproduzierbarer SwiftPM-Weg
- sichtbare, priorisierte Roadmap für die weiteren Etappen

## Bewusst später

Vollständiges Reaktionsmanagement, PI, Corporation-Funktionen, Cloud,
Mehrbenutzerbetrieb und KI bleiben spätere Pakete. P38–P42 mit SSO,
persönlichen ESI-Snapshots, öffentlichen Beschaffungspreisen und
bestätigten Wallet-Projektzuordnungen sind lokal umgesetzt.
